package com.bph.geotopo;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class StakeoutActivity extends BaseToolActivity {
    private static final int REQ_LOCATION = 9401;

    private LocationManager locationManager;
    private EditText firstInput;
    private EditText secondInput;
    private EditText zoneInput;
    private EditText toleranceInput;
    private CheckBox utmCheck;
    private CheckBox southCheck;
    private LinearLayout utmOptions;
    private TextView modeHelp;
    private TextView result;
    private Button startButton;
    private boolean running;
    private Location lastLocation;
    private boolean arrivalVibrated;

    private final LocationListener listener = new LocationListener() {
        @Override public void onLocationChanged(Location location) {
            if (location == null) return;
            if (lastLocation != null && lastLocation.getTime() > 0 && location.getTime() > 0
                    && location.getTime() < lastLocation.getTime()) return;
            lastLocation = location;
            updateResult(location);
        }
        @Override public void onProviderDisabled(String provider) {
            result.setText("Activa la ubicación/GPS del celular para usar el replanteo.");
        }
        @Override public void onProviderEnabled(String provider) {
            result.setText("GPS activo. Esperando una posición válida...");
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        LinearLayout root = page("Replanteo de punto", "Objetivo geográfico o UTM WGS84");
        LinearLayout content = vertical();
        LinearLayout box = card();
        box.addView(sectionTitle("Punto objetivo"));
        box.addView(small("Puedes ingresar latitud/longitud o coordenadas UTM WGS84. GeoTopo calcula distancia, azimut, desplazamientos Norte/Este y aviso de llegada."));
        box.addView(warning("El GNSS interno del teléfono es orientativo. Para replanteo centimétrico se requiere receptor RTK o estación total y control de campo."));

        utmCheck = new CheckBox(this);
        utmCheck.setText("Ingresar objetivo en UTM WGS84");
        utmCheck.setTextColor(textColor);
        utmCheck.setOnCheckedChangeListener((buttonView, isChecked) -> updateMode());
        box.addView(utmCheck);

        modeHelp = small("");
        box.addView(modeHelp);
        LinearLayout r1 = horizontal();
        firstInput = numberInput("-13.5000000");
        secondInput = numberInput("-71.9000000");
        r1.addView(labeled("Latitud / Norte UTM", firstInput), weight());
        r1.addView(labeled("Longitud / Este UTM", secondInput), weight());
        box.addView(r1);

        utmOptions = horizontal();
        zoneInput = integerInput("19"); zoneInput.setText("19");
        southCheck = new CheckBox(this); southCheck.setText("Hemisferio Sur"); southCheck.setTextColor(textColor); southCheck.setChecked(true);
        utmOptions.addView(labeled("Zona UTM", zoneInput), weight());
        utmOptions.addView(southCheck, weight());
        box.addView(utmOptions);

        toleranceInput = numberInput("2.0"); toleranceInput.setText("2.0");
        box.addView(labeled("Tolerancia de llegada (m)", toleranceInput));

        LinearLayout actions = horizontal();
        startButton = primaryButton("Iniciar replanteo"); startButton.setOnClickListener(v -> toggle()); actions.addView(startButton, weight());
        Button current = secondaryButton("Usar posición actual"); current.setOnClickListener(v -> useCurrent()); actions.addView(current, weight());
        box.addView(actions);

        result = resultBox("Replanteo detenido. Completa el objetivo y pulsa Iniciar replanteo."); box.addView(result);
        content.addView(box);
        root.addView(scrollWith(content), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        updateMode();
    }

    private void updateMode() {
        boolean utm = utmCheck != null && utmCheck.isChecked();
        if (utmOptions != null) utmOptions.setVisibility(utm ? View.VISIBLE : View.GONE);
        if (modeHelp != null) modeHelp.setText(utm
                ? "Modo UTM: primer dato = Norte, segundo dato = Este. Indica zona y hemisferio del proyecto."
                : "Modo geográfico: primer dato = latitud, segundo dato = longitud, en grados decimales.");
        if (firstInput != null && secondInput != null) {
            firstInput.setHint(utm ? "Norte UTM" : "Latitud");
            secondInput.setHint(utm ? "Este UTM" : "Longitud");
        }
    }

    private void toggle() {
        if (running) { stopUpdates(); result.setText("Replanteo detenido."); return; }
        try { readTarget(); if (parse(toleranceInput) <= 0) throw new IllegalArgumentException(); }
        catch (Exception e) { showToast("Revisa la coordenada objetivo, zona/hemisferio y tolerancia."); return; }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION); return;
        }
        startUpdates();
    }

    private Target readTarget() {
        if (!utmCheck.isChecked()) {
            double lat = parse(firstInput), lon = parse(secondInput);
            if (lat < -90 || lat > 90 || lon < -180 || lon > 180) throw new IllegalArgumentException();
            return new Target(lat, lon, null);
        }
        double northing = parse(firstInput), easting = parse(secondInput);
        int zone = (int) Math.round(parse(zoneInput));
        if (Math.abs(parse(zoneInput) - zone) > 1e-9 || zone < 1 || zone > 60) throw new IllegalArgumentException();
        CoordinateUtils.LatLon ll = CoordinateUtils.fromUtm(easting, northing, zone, southCheck.isChecked());
        if (!ll.valid) throw new IllegalArgumentException();
        return new Target(ll.latitude, ll.longitude, new CoordinateUtils.Utm(true, zone, southCheck.isChecked(), easting, northing));
    }

    private void startUpdates() {
        if (locationManager == null) { result.setText("El servicio de ubicación no está disponible."); return; }
        try {
            boolean requested = false;
            boolean gpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            if (gpsEnabled) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener);
                requested = true;
            } else if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1500L, 0f, listener);
                requested = true;
            }
            if (!requested) { result.setText("Activa la ubicación del celular."); return; }
            running = true; arrivalVibrated = false; startButton.setText("Detener replanteo");
            result.setText(gpsEnabled ? "Buscando señal GNSS... Mantén vista despejada al cielo." : "Usando ubicación de red aproximada; activa GPS para mejorar.");
        } catch (SecurityException e) { result.setText("No se concedió el permiso de ubicación."); }
    }

    private void stopUpdates() {
        if (locationManager != null) try { locationManager.removeUpdates(listener); } catch (SecurityException ignored) {}
        running = false; if (startButton != null) startButton.setText("Iniciar replanteo");
    }

    private void updateResult(Location current) {
        if (!running) return;
        try {
            Target targetData = readTarget();
            double tolerance = parse(toleranceInput);
            Location target = new Location("target"); target.setLatitude(targetData.latitude); target.setLongitude(targetData.longitude);
            float distance = current.distanceTo(target);
            float bearing = (float) normalizeBearing(current.bearingTo(target));

            double dNorth, dEast;
            String coordinateInfo;
            if (targetData.utm != null) {
                CoordinateUtils.Utm currentUtm = CoordinateUtils.toUtm(current.getLatitude(), current.getLongitude(), targetData.utm.zone);
                if (!currentUtm.valid) throw new IllegalArgumentException();
                dNorth = targetData.utm.northing - currentUtm.northing;
                dEast = targetData.utm.easting - currentUtm.easting;
                coordinateInfo = "Actual UTM " + currentUtm.zone + currentUtm.hemisphere() + ": N " + f3(currentUtm.northing) + " · E " + f3(currentUtm.easting);
            } else {
                double latRad = Math.toRadians((current.getLatitude() + targetData.latitude) / 2.0);
                dNorth = (targetData.latitude - current.getLatitude()) * 111320.0;
                dEast = (targetData.longitude - current.getLongitude()) * 111320.0 * Math.cos(latRad);
                CoordinateUtils.Utm currentUtm = CoordinateUtils.toUtm(current.getLatitude(), current.getLongitude());
                coordinateInfo = "Actual: " + f7(current.getLatitude()) + ", " + f7(current.getLongitude())
                        + (currentUtm.valid ? "\nUTM actual: " + currentUtm.zone + currentUtm.hemisphere() + " · N " + f3(currentUtm.northing) + " · E " + f3(currentUtm.easting) : "");
            }
            String arrival = distance <= tolerance ? "OBJETIVO DENTRO DE LA TOLERANCIA" : direction(dNorth, dEast);
            if (distance <= tolerance && !arrivalVibrated) { arrivalVibrated = true; vibrateArrival(); }
            if (distance > tolerance * 1.5) arrivalVibrated = false;
            String age = current.getTime() > 0 ? f1(Math.max(0, System.currentTimeMillis() - current.getTime()) / 1000.0) + " s" : "—";
            String accuracy = current.hasAccuracy() ? "±" + f1(current.getAccuracy()) + " m" : "—";
            result.setText(coordinateInfo + "\nPrecisión reportada: " + accuracy + " · Antigüedad: " + age
                    + "\nDistancia al objetivo: " + f2(distance) + " m"
                    + "\nAzimut: " + f3(bearing) + "° · " + bearingToQuadrant(bearing)
                    + "\nΔN: " + signed(dNorth) + " m · ΔE: " + signed(dEast) + " m"
                    + "\nTolerancia: " + f2(tolerance) + " m"
                    + "\nIndicación: " + arrival);
        } catch (Exception e) { result.setText("Revisa la coordenada objetivo, la zona UTM y la tolerancia."); }
    }

    private String direction(double north, double east) {
        String ns = Math.abs(north) < 0.3 ? "" : (north > 0 ? "Norte" : "Sur");
        String ew = Math.abs(east) < 0.3 ? "" : (east > 0 ? "Este" : "Oeste");
        if (!ns.isEmpty() && !ew.isEmpty()) return "Avanza hacia " + ns + " y " + ew + ".";
        if (!ns.isEmpty()) return "Avanza hacia el " + ns + ".";
        if (!ew.isEmpty()) return "Avanza hacia el " + ew + ".";
        return "Muy cerca del objetivo.";
    }

    private void vibrateArrival() {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vibrator == null || !vibrator.hasVibrator()) return;
        if (android.os.Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createWaveform(new long[]{0, 180, 100, 180}, -1));
        else vibrator.vibrate(new long[]{0, 180, 100, 180}, -1);
    }

    private void useCurrent() {
        if (lastLocation == null) { showToast("Inicia el replanteo unos segundos para obtener una posición actual."); return; }
        if (utmCheck.isChecked()) {
            int zone;
            try { zone = (int) Math.round(parse(zoneInput)); if (zone < 1 || zone > 60) throw new IllegalArgumentException(); }
            catch (Exception e) { CoordinateUtils.Utm auto = CoordinateUtils.toUtm(lastLocation.getLatitude(), lastLocation.getLongitude()); zone = auto.zone; zoneInput.setText(String.valueOf(zone)); }
            CoordinateUtils.Utm u = CoordinateUtils.toUtm(lastLocation.getLatitude(), lastLocation.getLongitude(), zone);
            if (!u.valid) { showToast("No se pudo convertir la posición a UTM."); return; }
            firstInput.setText(f3(u.northing)); secondInput.setText(f3(u.easting)); southCheck.setChecked(u.south);
        } else {
            firstInput.setText(f7(lastLocation.getLatitude())); secondInput.setText(f7(lastLocation.getLongitude()));
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startUpdates();
        else if (requestCode == REQ_LOCATION) result.setText("Sin permiso de ubicación no se puede usar el replanteo.");
    }

    @Override protected void onPause() { super.onPause(); stopUpdates(); }

    private static final class Target {
        final double latitude, longitude;
        final CoordinateUtils.Utm utm;
        Target(double latitude, double longitude, CoordinateUtils.Utm utm) { this.latitude = latitude; this.longitude = longitude; this.utm = utm; }
    }
}
