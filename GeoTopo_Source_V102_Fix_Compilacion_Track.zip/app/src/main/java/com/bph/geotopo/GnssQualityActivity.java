package com.bph.geotopo;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.GpsSatellite;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class GnssQualityActivity extends BaseToolActivity {
    private static final int REQ_LOCATION = 9550;

    // Palette dedicated to the approved GNSS design. This screen intentionally keeps
    // its own dark technical appearance without changing the rest of Geo Topo.
    private static final int GNSS_BG = Color.rgb(3, 20, 33);
    private static final int GNSS_BAR_START = Color.rgb(5, 55, 84);
    private static final int GNSS_BAR_END = Color.rgb(5, 38, 60);
    private static final int GNSS_CARD_START = Color.rgb(18, 43, 68);
    private static final int GNSS_CARD_END = Color.rgb(11, 31, 49);
    private static final int GNSS_PANEL = Color.rgb(7, 28, 44);
    private static final int GNSS_INNER = Color.rgb(6, 25, 40);
    private static final int GNSS_BORDER = Color.rgb(36, 82, 126);
    private static final int GNSS_DIVIDER = Color.rgb(18, 52, 76);
    private static final int GNSS_TEXT = Color.rgb(244, 248, 252);
    private static final int GNSS_SUBTEXT = Color.rgb(190, 205, 219);
    private static final int GNSS_BLUE = Color.rgb(45, 140, 255);
    private static final int GNSS_BLUE_2 = Color.rgb(22, 95, 236);
    private static final int GNSS_GREEN = Color.rgb(57, 217, 107);
    private static final int GNSS_AMBER = Color.rgb(255, 171, 0);
    private static final int GNSS_PURPLE = Color.rgb(164, 105, 255);
    private static final int GNSS_CYAN = Color.rgb(52, 206, 237);
    private static final int GNSS_ORANGE = Color.rgb(255, 158, 10);

    private LocationManager manager;
    private Button startButton;
    private boolean running;
    private Location lastLocation;
    private int visibleSatellites;
    private int usedSatellites;
    private double averageCn0;
    private String constellationSummary = "—";
    private Double pdop, hdop, vdop;
    private String fixQuality = "—";
    private String nmeaTime = "—";
    private GnssBridge modernBridge;

    private TextView stateValue;
    private TextView positionValue;
    private TextView horizontalValue;
    private TextView verticalValue;
    private TextView altitudeValue;
    private TextView satellitesValue;
    private TextView cn0Value;
    private TextView constellationsValue;
    private TextView dopValue;
    private TextView nmeaQualityValue;
    private TextView nmeaTimeValue;
    private TextView assessmentValue;

    private TextView metricSatellites;
    private TextView metricSignal;
    private TextView metricHorizontal;
    private TextView metricVertical;
    private TextView metricState;

    private final LocationListener locationListener = new LocationListener() {
        @Override public void onLocationChanged(Location location) { lastLocation = location; render(); }
        @Override public void onProviderEnabled(String provider) { render(); }
        @Override public void onProviderDisabled(String provider) { render(); }
    };

    private final GnssBridge.Sink modernSink = new GnssBridge.Sink() {
        @Override public void onSatellites(int visible, int used, double cn0, String summary) {
            visibleSatellites = visible;
            usedSatellites = used;
            averageCn0 = cn0;
            constellationSummary = summary == null || summary.isEmpty() ? "—" : summary;
            runOnUiThread(GnssQualityActivity.this::render);
        }

        @Override public void onNmea(String sentence) { parseNmea(sentence); }
    };

    private final GpsStatus.NmeaListener legacyNmeaListener = (timestamp, nmea) -> parseNmea(nmea);
    private final GpsStatus.Listener legacyGpsListener = event -> {
        if (event != GpsStatus.GPS_EVENT_SATELLITE_STATUS || manager == null) return;
        try {
            GpsStatus status = manager.getGpsStatus(null);
            if (status == null) return;
            visibleSatellites = 0;
            usedSatellites = 0;
            averageCn0 = 0;
            int n = 0;
            for (GpsSatellite sat : status.getSatellites()) {
                visibleSatellites++;
                if (sat.usedInFix()) usedSatellites++;
                if (sat.getSnr() > 0) {
                    averageCn0 += sat.getSnr();
                    n++;
                }
            }
            if (n > 0) averageCn0 /= n;
            constellationSummary = "No desglosado en Android 6";
            render();
        } catch (SecurityException ignored) {}
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        manager = (LocationManager) getSystemService(LOCATION_SERVICE);

        getWindow().setStatusBarColor(Color.rgb(1, 12, 25));
        getWindow().setNavigationBarColor(Color.BLACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(GNSS_BG);
        root.addView(buildTopBar(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setBackgroundColor(GNSS_BG);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int side = dp(12);
        content.setPadding(side, dp(11), side, dp(24));
        content.setBackgroundColor(GNSS_BG);

        content.addView(buildDiagnosticCard());
        content.addView(buildMetricStrip());
        content.addView(buildResultsCard());

        TextView footer = label("Los datos dependen del hardware y del entorno.", 10.5f, false, Color.rgb(144, 160, 176));
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        footerLp.setMargins(dp(8), dp(4), dp(8), dp(2));
        footer.setLayoutParams(footerLp);
        content.addView(footer);

        scroll.addView(content, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        render();
    }

    private View buildTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(7), dp(7), dp(8), dp(9));
        bar.setBackground(gradient(GNSS_BAR_START, GNSS_BAR_END, 0, 0, 0));

        TextView back = label("‹", 34f, false, Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(54), dp(58)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = label("Calidad GNSS", 23f, true, GNSS_TEXT);
        title.setMaxLines(1);
        titles.addView(title);

        TextView subtitle = label("Control de señal, satélites y precisión disponible", 12.8f, false, Color.rgb(214, 226, 238));
        subtitle.setMaxLines(2);
        subtitle.setLineSpacing(0, 1.02f);
        titles.addView(subtitle);

        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView more = label("⋮", 27f, true, Color.WHITE);
        more.setGravity(Gravity.CENTER);
        bar.addView(more, new LinearLayout.LayoutParams(dp(42), dp(54)));
        return bar;
    }

    private View buildDiagnosticCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(13), dp(12), dp(13));
        card.setBackground(gradient(GNSS_CARD_START, GNSS_CARD_END, 17, 1, GNSS_BORDER));
        if (Build.VERSION.SDK_INT >= 21) card.setElevation(dp(1.5f));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardLp.setMargins(0, 0, 0, dp(8));
        card.setLayoutParams(cardLp);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.TOP);

        TextView icon = iconBadge("✦", GNSS_BLUE, 48);
        head.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(48)));

        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setPadding(dp(11), dp(1), 0, 0);

        TextView title = label("Diagnóstico del receptor del teléfono", 17.2f, true, GNSS_TEXT);
        title.setLineSpacing(0, 1.0f);
        copy.addView(title);

        TextView description = label(
                "Muestra la información que Android y el chip GNSS entregan.\nPDOP, HDOP y VDOP aparecen cuando el equipo transmite\nmensajes NMEA compatibles.",
                12.7f, false, GNSS_SUBTEXT);
        description.setLineSpacing(0, 1.12f);
        LinearLayout.LayoutParams descLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        descLp.setMargins(0, dp(5), 0, 0);
        description.setLayoutParams(descLp);
        copy.addView(description);

        head.addView(copy, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(head);

        LinearLayout warningBox = new LinearLayout(this);
        warningBox.setOrientation(LinearLayout.HORIZONTAL);
        warningBox.setGravity(Gravity.CENTER_VERTICAL);
        warningBox.setPadding(dp(11), dp(10), dp(11), dp(10));
        GradientDrawable warningBg = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.rgb(55, 43, 12), Color.rgb(45, 38, 19)});
        warningBg.setCornerRadius(dp(13));
        warningBg.setStroke(dp(1), GNSS_AMBER);
        warningBox.setBackground(warningBg);
        LinearLayout.LayoutParams warningLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        warningLp.setMargins(0, dp(13), 0, dp(11));
        warningBox.setLayoutParams(warningLp);

        TextView warnIcon = label("⚠", 27f, true, GNSS_AMBER);
        warnIcon.setGravity(Gravity.CENTER);
        warningBox.addView(warnIcon, new LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.MATCH_PARENT));

        TextView warningText = label(
                "La precisión informada por el teléfono no garantiza exactitud\ntopográfica. Obstáculos, reflexión de señal y geometría\nsatelital pueden producir errores mayores.",
                12.6f, false, Color.rgb(234, 234, 228));
        warningText.setLineSpacing(0, 1.11f);
        warningBox.addView(warningText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(warningBox);

        startButton = new Button(this);
        startButton.setAllCaps(false);
        startButton.setText("▶   Iniciar diagnóstico");
        startButton.setTextColor(Color.WHITE);
        startButton.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
        startButton.setGravity(Gravity.CENTER);
        startButton.setPadding(dp(8), 0, dp(8), 0);
        startButton.setMinHeight(0);
        startButton.setMinWidth(0);
        ResponsiveUi.configureCompactText(startButton, 15f, 11f, 1);
        startButton.setBackground(gradient(Color.rgb(25, 137, 255), GNSS_BLUE_2, 12, 0, 0));
        if (Build.VERSION.SDK_INT >= 21) {
            startButton.setElevation(dp(2));
            startButton.setStateListAnimator(null);
        }
        startButton.setOnClickListener(v -> toggle());
        LinearLayout.LayoutParams buttonLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        buttonLp.setMargins(0, 0, 0, 0);
        startButton.setLayoutParams(buttonLp);
        card.addView(startButton);

        return card;
    }

    private View buildMetricStrip() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(4), dp(4), dp(4), dp(4));
        row.setBackground(gradient(Color.rgb(9, 31, 49), Color.rgb(7, 27, 43), 14, 1, GNSS_BORDER));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(1), 0, dp(8));
        row.setLayoutParams(lp);

        metricSatellites = metricValue("0 | 0", GNSS_TEXT);
        metricSignal = metricValue("—", GNSS_TEXT);
        metricHorizontal = metricValue("—", GNSS_TEXT);
        metricVertical = metricValue("—", GNSS_TEXT);
        metricState = metricValue("DETENIDO", GNSS_TEXT);

        row.addView(metricCard("✦", GNSS_BLUE, "Satélites", metricSatellites, "Usados"), metricWeight(1.10f));
        row.addView(metricCard("▥", GNSS_GREEN, "Señal", metricSignal, "C/N0 medio"), metricWeight(1.05f));
        row.addView(metricCard("⊙", GNSS_PURPLE, "Precisión H", metricHorizontal, "m"), metricWeight(1.10f));
        row.addView(metricCard("↕", GNSS_CYAN, "Precisión V", metricVertical, "m"), metricWeight(1.10f));
        row.addView(metricCard("∿", GNSS_ORANGE, "Estado", metricState, ""), metricWeight(1.05f));
        return row;
    }

    private LinearLayout.LayoutParams metricWeight(float weight) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(74), weight);
        lp.setMargins(dp(2), 0, dp(2), 0);
        return lp;
    }

    private View metricCard(String iconText, int iconColor, String titleText, TextView valueView, String captionText) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(5), dp(5), dp(4), dp(5));
        box.setBackground(gradient(Color.rgb(11, 34, 53), Color.rgb(7, 27, 43), 11, 1, Color.rgb(24, 59, 89)));

        TextView icon = label(iconText, 20f, true, iconColor);
        icon.setGravity(Gravity.CENTER);
        GradientDrawable ibg = new GradientDrawable();
        ibg.setColor(withAlpha(iconColor, 28));
        ibg.setCornerRadius(dp(10));
        icon.setBackground(ibg);
        box.addView(icon, new LinearLayout.LayoutParams(dp(29), dp(34)));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(4), 0, 0, 0);

        TextView title = label(titleText, 8.8f, false, GNSS_SUBTEXT);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        info.addView(title);

        valueView.setSingleLine(true);
        valueView.setEllipsize(TextUtils.TruncateAt.END);
        info.addView(valueView);

        if (!captionText.isEmpty()) {
            TextView caption = label(captionText, 8.4f, false, Color.rgb(176, 191, 207));
            caption.setSingleLine(true);
            caption.setEllipsize(TextUtils.TruncateAt.END);
            info.addView(caption);
        }

        box.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return box;
    }

    private TextView metricValue(String text, int color) {
        TextView value = label(text, 11.6f, false, color);
        value.setGravity(Gravity.START);
        return value;
    }

    private View buildResultsCard() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(8), dp(9), dp(8), dp(9));
        outer.setBackground(gradient(Color.rgb(11, 35, 55), Color.rgb(7, 28, 44), 16, 1, GNSS_BORDER));
        LinearLayout.LayoutParams outerLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        outerLp.setMargins(0, 0, 0, dp(10));
        outer.setLayoutParams(outerLp);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(2), 0, dp(2), dp(6));

        TextView headerIcon = iconBadge("∿", GNSS_BLUE, 34);
        header.addView(headerIcon, new LinearLayout.LayoutParams(dp(34), dp(34)));

        TextView headerTitle = label("Resultados y estado", 17.2f, true, GNSS_TEXT);
        headerTitle.setPadding(dp(8), 0, 0, 0);
        header.addView(headerTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView arrow = label("⌃", 22f, true, GNSS_SUBTEXT);
        arrow.setGravity(Gravity.CENTER);
        header.addView(arrow, new LinearLayout.LayoutParams(dp(38), dp(38)));
        outer.addView(header);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(5), dp(3), dp(5), dp(3));
        body.setBackground(gradient(GNSS_INNER, GNSS_INNER, 13, 1, Color.rgb(23, 61, 89)));

        stateValue = valueView("DETENIDO", GNSS_GREEN);
        positionValue = valueView("—", GNSS_SUBTEXT);
        horizontalValue = valueView("—", GNSS_SUBTEXT);
        verticalValue = valueView("—", GNSS_SUBTEXT);
        altitudeValue = valueView("—", GNSS_SUBTEXT);
        satellitesValue = valueView("0 / 0", GNSS_SUBTEXT);
        cn0Value = valueView("— dB-Hz", GNSS_SUBTEXT);
        constellationsValue = valueView("—", GNSS_SUBTEXT);
        dopValue = valueView("— / — / —", GNSS_SUBTEXT);
        dopValue.setTextSize(11.2f);
        dopValue.setSingleLine(true);
        nmeaQualityValue = valueView("—", GNSS_SUBTEXT);
        nmeaQualityValue.setTextSize(11.6f);
        nmeaQualityValue.setSingleLine(true);
        nmeaTimeValue = valueView("—", GNSS_SUBTEXT);
        nmeaTimeValue.setTextSize(11.2f);
        nmeaTimeValue.setSingleLine(true);
        assessmentValue = valueView("Sin posición", GNSS_AMBER);
        constellationsValue.setEllipsize(null);
        constellationsValue.setMaxLines(3);
        assessmentValue.setEllipsize(null);
        assessmentValue.setMaxLines(3);

        body.addView(resultRow("●", GNSS_GREEN, "Estado", stateValue));
        addDivider(body);
        body.addView(resultRow("⌖", GNSS_BLUE, "Posición", positionValue));
        addDivider(body);
        body.addView(resultRow("⊙", GNSS_BLUE, "Precisión horizontal reportada", horizontalValue));
        addDivider(body);
        body.addView(resultRow("↕", GNSS_BLUE, "Precisión vertical reportada", verticalValue));
        addDivider(body);
        body.addView(resultRow("▲", GNSS_BLUE, "Altitud GNSS", altitudeValue));
        addDivider(body);
        body.addView(resultRow("✦", GNSS_BLUE, "Satélites visibles / usados", satellitesValue));
        addDivider(body);
        body.addView(resultRow("▥", GNSS_BLUE, "C/N0 medio", cn0Value));
        addDivider(body);
        body.addView(resultRow("◎", GNSS_BLUE, "Constelaciones", constellationsValue));
        addDivider(body);
        body.addView(resultRow("⌘", GNSS_BLUE, "PDOP / HDOP / VDOP", dopValue));
        addDivider(body);
        body.addView(resultRow("▤", GNSS_BLUE, "Calidad NMEA", nmeaQualityValue));
        addDivider(body);
        body.addView(resultRow("◷", GNSS_CYAN, "Hora NMEA (UTC)", nmeaTimeValue));
        addDivider(body);
        body.addView(resultRow("ϟ", GNSS_BLUE, "Evaluación rápida", assessmentValue));

        outer.addView(body);
        header.setOnClickListener(v -> {
            boolean show = body.getVisibility() != View.VISIBLE;
            body.setVisibility(show ? View.VISIBLE : View.GONE);
            arrow.setText(show ? "⌃" : "⌄");
        });
        return outer;
    }

    private View resultRow(String iconText, int iconColor, String labelText, TextView value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(6), dp(8), dp(6), dp(8));
        row.setMinimumHeight(dp(46));

        TextView icon = label(iconText, 18f, true, iconColor);
        icon.setGravity(Gravity.CENTER);
        row.addView(icon, new LinearLayout.LayoutParams(dp(32), dp(30)));

        TextView name = label(labelText, 12.1f, false, Color.rgb(226, 233, 240));
        name.setMaxLines(2);
        name.setLineSpacing(0, 1.0f);
        name.setPadding(dp(4), 0, dp(8), 0);
        row.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.72f));

        value.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        if (value.getMaxLines() != 1) value.setMaxLines(3);
        value.setLineSpacing(0, 1.0f);
        row.addView(value, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.78f));
        return row;
    }

    private void addDivider(LinearLayout parent) {
        View line = new View(this);
        line.setBackgroundColor(GNSS_DIVIDER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        lp.setMargins(dp(38), 0, dp(4), 0);
        parent.addView(line, lp);
    }

    private TextView valueView(String value, int color) {
        TextView view = label(value, 12.2f, false, color);
        view.setEllipsize(TextUtils.TruncateAt.END);
        return view;
    }

    private TextView iconBadge(String symbol, int color, int sizeDp) {
        TextView icon = label(symbol, sizeDp >= 44 ? 23f : 18f, true, Color.rgb(132, 183, 255));
        icon.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{withAlpha(color, 95), withAlpha(Color.rgb(18, 62, 112), 180)});
        bg.setCornerRadius(dp(sizeDp / 2f));
        bg.setStroke(dp(1), withAlpha(color, 175));
        icon.setBackground(bg);
        if (Build.VERSION.SDK_INT >= 21) icon.setElevation(dp(1));
        return icon;
    }

    private TextView label(String text, float sizeSp, boolean bold, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(color);
        view.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        ResponsiveUi.configureText(view, sizeSp);
        return view;
    }

    private GradientDrawable gradient(int start, int end, float radiusDp, float strokeDp, int strokeColor) {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{start, end});
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), strokeColor);
        return drawable;
    }

    private void toggle() {
        if (running) stop();
        else requestStart();
    }

    private void requestStart() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        start();
    }

    private void start() {
        if (manager == null) {
            showDiagnosticMessage("Servicio de ubicación no disponible.");
            return;
        }
        stop();
        visibleSatellites = 0;
        usedSatellites = 0;
        averageCn0 = 0;
        constellationSummary = "—";
        pdop = null;
        hdop = null;
        vdop = null;
        fixQuality = "—";
        nmeaTime = "—";
        try {
            if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                showDiagnosticMessage("Activa el GPS del celular.");
                return;
            }
            manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locationListener);
            if (Build.VERSION.SDK_INT >= 24) {
                modernBridge = new ModernGnssBridge(modernSink);
                modernBridge.start(manager);
            } else {
                manager.addGpsStatusListener(legacyGpsListener);
                manager.addNmeaListener(legacyNmeaListener);
            }
            running = true;
            updateStartButton();
            render();
            showDiagnosticMessage("Esperando señal GNSS...");
        } catch (SecurityException e) {
            showDiagnosticMessage("No se concedió permiso de ubicación.");
        } catch (Exception e) {
            showDiagnosticMessage("El receptor GNSS no pudo iniciar el diagnóstico.");
        }
    }

    private void stop() {
        if (manager != null) {
            try { manager.removeUpdates(locationListener); } catch (Exception ignored) {}
            if (modernBridge != null) {
                modernBridge.stop(manager);
                modernBridge = null;
            }
            try { manager.removeGpsStatusListener(legacyGpsListener); } catch (Exception ignored) {}
            try { manager.removeNmeaListener(legacyNmeaListener); } catch (Exception ignored) {}
        }
        running = false;
        updateStartButton();
        render();
    }

    private void updateStartButton() {
        if (startButton == null) return;
        startButton.setText(running ? "■   Detener diagnóstico" : "▶   Iniciar diagnóstico");
    }

    private void showDiagnosticMessage(String message) {
        if (assessmentValue == null) return;
        assessmentValue.setText(message);
        assessmentValue.setTextColor(GNSS_AMBER);
    }

    private void parseNmea(String nmea) {
        if (nmea == null) return;
        String line = nmea.trim();
        if (!validChecksum(line)) return;
        String[] f = line.split(",", -1);
        try {
            String type = f.length == 0 ? "" : f[0];
            if (type.endsWith("GSA") && f.length >= 18) {
                // NMEA GSA always places PDOP/HDOP/VDOP at fields 15/16/17.
                // NMEA 4.10 can append a System ID after VDOP, so reading from the
                // end of the sentence incorrectly treats that System ID as VDOP.
                Double parsedPdop = parseDop(f[15]);
                Double parsedHdop = parseDop(f[16]);
                Double parsedVdop = parseDop(stripChecksum(f[17]));
                if (parsedPdop != null) pdop = parsedPdop;
                if (parsedHdop != null) hdop = parsedHdop;
                if (parsedVdop != null) vdop = parsedVdop;
            } else if (type.endsWith("GGA") && f.length >= 10) {
                nmeaTime = formatNmeaUtc(f[1]);
                int quality = f[6].isEmpty() ? 0 : Integer.parseInt(f[6]);
                fixQuality = fixName(quality);
                Double ggaHdop = parseDop(f[8]);
                if (ggaHdop != null) hdop = ggaHdop;
            }
        } catch (Exception ignored) {}
        runOnUiThread(this::render);
    }

    private boolean validChecksum(String line) {
        if (!line.startsWith("$") || !line.contains("*")) return true;
        int star = line.indexOf('*');
        if (star <= 1 || star + 2 >= line.length()) return false;
        int checksum = 0;
        for (int i = 1; i < star; i++) checksum ^= line.charAt(i);
        try {
            return checksum == Integer.parseInt(line.substring(star + 1, star + 3), 16);
        } catch (Exception e) {
            return false;
        }
    }

    private Double parseNullable(String value) {
        try {
            return value == null || value.isEmpty() ? null : Double.parseDouble(value);
        } catch (Exception e) {
            return null;
        }
    }

    private Double parseDop(String value) {
        Double parsed = parseNullable(value);
        if (parsed == null || parsed < 0.0 || parsed > 99.99) return null;
        return parsed;
    }

    private String formatNmeaUtc(String raw) {
        if (raw == null) return "—";
        String clean = stripChecksum(raw.trim());
        int dot = clean.indexOf('.');
        String whole = dot >= 0 ? clean.substring(0, dot) : clean;
        if (whole.length() < 6) return "—";
        try {
            int hh = Integer.parseInt(whole.substring(0, 2));
            int mm = Integer.parseInt(whole.substring(2, 4));
            int ss = Integer.parseInt(whole.substring(4, 6));
            if (hh > 23 || mm > 59 || ss > 60) return "—";
            return String.format(java.util.Locale.US, "%02d:%02d:%02d UTC", hh, mm, ss);
        } catch (Exception e) {
            return "—";
        }
    }

    private String stripChecksum(String v) {
        int i = v.indexOf('*');
        return i >= 0 ? v.substring(0, i) : v;
    }

    private void render() {
        if (stateValue == null) return;

        String position = lastLocation == null
                ? "—"
                : f7(lastLocation.getLatitude()) + ", " + f7(lastLocation.getLongitude());
        String acc = lastLocation == null || !lastLocation.hasAccuracy()
                ? "—"
                : "±" + f1(lastLocation.getAccuracy()) + " m";
        String vertical = lastLocation != null
                && Build.VERSION.SDK_INT >= 26
                && lastLocation.hasVerticalAccuracy()
                ? "±" + f1(lastLocation.getVerticalAccuracyMeters()) + " m"
                : "—";
        String altitude = lastLocation != null && lastLocation.hasAltitude()
                ? f3(lastLocation.getAltitude()) + " m"
                : "—";
        String cn0 = averageCn0 > 0 ? f1(averageCn0) + " dB-Hz" : "— dB-Hz";
        String assessment = capitalizeFirst(qualityAssessment());

        stateValue.setText(running ? "ACTIVO" : "DETENIDO");
        stateValue.setTextColor(GNSS_GREEN);
        positionValue.setText(position);
        horizontalValue.setText(acc);
        verticalValue.setText(vertical);
        altitudeValue.setText(altitude);
        satellitesValue.setText(visibleSatellites + " / " + usedSatellites);
        cn0Value.setText(cn0);
        constellationsValue.setText(constellationSummary);
        dopValue.setText(value(pdop) + " / " + value(hdop) + " / " + value(vdop));
        nmeaQualityValue.setText(fixQuality);
        nmeaTimeValue.setText(nmeaTime);
        assessmentValue.setText(assessment);
        assessmentValue.setTextColor(assessmentColor());

        metricSatellites.setText(visibleSatellites + " | " + usedSatellites);
        metricSignal.setText(averageCn0 > 0 ? f1(averageCn0) : "—");
        metricHorizontal.setText(lastLocation != null && lastLocation.hasAccuracy() ? f1(lastLocation.getAccuracy()) : "—");
        metricVertical.setText(lastLocation != null && Build.VERSION.SDK_INT >= 26 && lastLocation.hasVerticalAccuracy()
                ? f1(lastLocation.getVerticalAccuracyMeters()) : "—");
        metricState.setText(running ? "ACTIVO" : "DETENIDO");
        metricState.setTextColor(running ? GNSS_GREEN : GNSS_TEXT);
    }

    private String capitalizeFirst(String text) {
        if (text == null || text.isEmpty()) return "—";
        return Character.toUpperCase(text.charAt(0)) + text.substring(1);
    }

    private String qualityAssessment() {
        if (lastLocation == null) return "sin posición";
        float a = lastLocation.hasAccuracy() ? lastLocation.getAccuracy() : 999f;
        if (usedSatellites >= 10 && a <= 3) return "buena para orientación y captura aproximada";
        if (usedSatellites >= 6 && a <= 10) return "media; espera y promedia antes de guardar";
        return "débil; busca cielo abierto y evita obstáculos";
    }

    private int assessmentColor() {
        if (lastLocation == null) return GNSS_AMBER;
        float a = lastLocation.hasAccuracy() ? lastLocation.getAccuracy() : 999f;
        if (usedSatellites >= 10 && a <= 3f) return GNSS_GREEN;
        if (usedSatellites >= 6 && a <= 10f) return GNSS_AMBER;
        return Color.rgb(255, 105, 97);
    }

    private String value(Double d) {
        return d == null ? "—" : f2(d);
    }

    private String fixName(int q) {
        switch (q) {
            case 1: return "GPS autónomo";
            case 2: return "DGPS";
            case 4: return "RTK fijo";
            case 5: return "RTK flotante";
            case 6: return "estimado";
            case 7: return "manual";
            case 8: return "simulado";
            default: return "sin solución";
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION
                && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            start();
        } else if (requestCode == REQ_LOCATION) {
            showDiagnosticMessage("Sin permiso de ubicación no se puede leer el estado GNSS.");
        }
    }

    @Override protected void onPause() {
        stop();
        super.onPause();
    }
}
