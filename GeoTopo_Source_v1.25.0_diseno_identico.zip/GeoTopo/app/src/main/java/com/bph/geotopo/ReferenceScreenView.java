package com.bph.geotopo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** Draws a full-screen reference composition and maps normalized touch zones to real actions. */
public class ReferenceScreenView extends View {
    public interface Action { void run(); }

    private static final class Zone {
        final float left;
        final float top;
        final float right;
        final float bottom;
        final Action action;

        Zone(float left, float top, float right, float bottom, Action action) {
            this.left = left;
            this.top = top;
            this.right = right;
            this.bottom = bottom;
            this.action = action;
        }

        boolean contains(float x, float y) {
            return x >= left && x <= right && y >= top && y <= bottom;
        }
    }

    protected final Bitmap bitmap;
    protected final Paint bitmapPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final List<Zone> zones = new ArrayList<>();
    private float downX;
    private float downY;

    public ReferenceScreenView(Context context, int drawableResource) {
        super(context);
        setClickable(true);
        setFocusable(true);
        bitmap = BitmapFactory.decodeResource(getResources(), drawableResource);
        if (bitmap == null) throw new IllegalStateException("No se pudo cargar la pantalla de referencia");
    }

    public void addZone(float left, float top, float right, float bottom, Action action) {
        zones.add(new Zone(left, top, right, bottom, action));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawBitmap(bitmap, null, new RectF(0, 0, getWidth(), getHeight()), bitmapPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            downX = event.getX();
            downY = event.getY();
            return true;
        }
        if (event.getActionMasked() == MotionEvent.ACTION_UP) {
            float dx = Math.abs(event.getX() - downX);
            float dy = Math.abs(event.getY() - downY);
            if (dx > 28f || dy > 28f) return true;
            float x = event.getX() * bitmap.getWidth() / Math.max(1f, getWidth());
            float y = event.getY() * bitmap.getHeight() / Math.max(1f, getHeight());
            for (Zone zone : zones) {
                if (zone.contains(x, y)) {
                    performClick();
                    if (zone.action != null) zone.action.run();
                    return true;
                }
            }
            return true;
        }
        return true;
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }
}
