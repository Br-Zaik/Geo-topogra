package com.bph.geotopo;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

/** Visual GPS launcher matching the approved reference while preserving the full GPS tools. */
public class GpsOverviewActivity extends Activity {
    private static final String GPS_PREFS = "geo_topo_gps_points";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindow();

        ReferenceScreenView screen = new ReferenceScreenView(this, R.drawable.gps_reference);
        screen.setContentDescription("Resumen GPS y mapas");

        screen.addZone(0, 0, 120, 130, new ReferenceScreenView.Action() {
            @Override public void run() { finish(); }
        });
        screen.addZone(720, 0, 864, 145, new ReferenceScreenView.Action() {
            @Override public void run() { open(MapActivity.class); }
        });
        screen.addZone(20, 130, 310, 265, new ReferenceScreenView.Action() {
            @Override public void run() { open(OfflineMapActivity.class); }
        });
        screen.addZone(500, 475, 850, 690, new ReferenceScreenView.Action() {
            @Override public void run() { open(MapActivity.class); }
        });
        screen.addZone(20, 650, 850, 930, new ReferenceScreenView.Action() {
            @Override public void run() { open(GpsActivity.class); }
        });
        screen.addZone(20, 905, 300, 1080, new ReferenceScreenView.Action() {
            @Override public void run() { open(GpsActivity.class); }
        });
        screen.addZone(295, 905, 575, 1080, new ReferenceScreenView.Action() {
            @Override public void run() { shareLastCoordinates(); }
        });
        screen.addZone(570, 905, 850, 1080, new ReferenceScreenView.Action() {
            @Override public void run() { open(GnssQualityActivity.class); }
        });
        screen.addZone(650, 1070, 864, 1160, new ReferenceScreenView.Action() {
            @Override public void run() { open(GpsActivity.class); }
        });
        screen.addZone(20, 1130, 850, 1480, new ReferenceScreenView.Action() {
            @Override public void run() { open(GpsActivity.class); }
        });

        setContentView(screen);
    }

    private void configureWindow() {
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(3, 19, 35));
        window.setNavigationBarColor(Color.BLACK);
        window.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void open(Class<?> target) {
        startActivity(new Intent(this, target));
    }

    private void shareLastCoordinates() {
        SharedPreferences prefs = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
        String lat = prefs.getString("last_latitude", "");
        String lon = prefs.getString("last_longitude", "");
        if (lat == null || lon == null || lat.isEmpty() || lon.isEmpty()) {
            Toast.makeText(this, "Primero obtén una lectura en GPS y puntos.", Toast.LENGTH_LONG).show();
            open(GpsActivity.class);
            return;
        }
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT, "Coordenadas Geo Topo\nLatitud: " + lat + "\nLongitud: " + lon);
        startActivity(Intent.createChooser(share, "Compartir coordenadas"));
    }
}
