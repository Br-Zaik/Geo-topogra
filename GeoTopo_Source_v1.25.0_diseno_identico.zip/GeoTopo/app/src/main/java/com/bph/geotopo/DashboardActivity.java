package com.bph.geotopo;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

/** Premium visual launcher matching the approved Geo Topo dashboard. */
public class DashboardActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindow();

        ReferenceScreenView screen = new ReferenceScreenView(this, R.drawable.dashboard_reference);
        screen.setContentDescription("Panel principal de Geo Topo");

        screen.addZone(716, 0, 864, 145, new ReferenceScreenView.Action() {
            @Override public void run() { openSettings(); }
        });
        screen.addZone(28, 170, 433, 580, new ReferenceScreenView.Action() {
            @Override public void run() { open(GpsOverviewActivity.class); }
        });
        screen.addZone(432, 170, 850, 580, new ReferenceScreenView.Action() {
            @Override public void run() { open(FieldToolsActivity.class); }
        });
        screen.addZone(675, 570, 864, 660, new ReferenceScreenView.Action() {
            @Override public void run() { openCalculator(null); }
        });
        screen.addZone(25, 640, 430, 795, new ReferenceScreenView.Action() {
            @Override public void run() { open(ConverterActivity.class); }
        });
        screen.addZone(430, 640, 855, 795, new ReferenceScreenView.Action() {
            @Override public void run() { openCalculator("compass"); }
        });
        screen.addZone(25, 790, 430, 940, new ReferenceScreenView.Action() {
            @Override public void run() { openCalculator("azimuth"); }
        });
        screen.addZone(430, 790, 855, 940, new ReferenceScreenView.Action() {
            @Override public void run() { openCalculator("coordinates"); }
        });
        screen.addZone(25, 935, 430, 1085, new ReferenceScreenView.Action() {
            @Override public void run() { openCalculator("distance"); }
        });
        screen.addZone(430, 935, 855, 1085, new ReferenceScreenView.Action() {
            @Override public void run() { openCalculator("two_hair"); }
        });
        screen.addZone(20, 1120, 855, 1285, new ReferenceScreenView.Action() {
            @Override public void run() { openCalculator("polygon"); }
        });
        screen.addZone(20, 1310, 430, 1480, new ReferenceScreenView.Action() {
            @Override public void run() { openCalculator("level"); }
        });
        screen.addZone(430, 1310, 855, 1480, new ReferenceScreenView.Action() {
            @Override public void run() { openCalculator("stadia"); }
        });

        setContentView(screen);
    }

    private void configureWindow() {
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(3, 19, 35));
        window.setNavigationBarColor(Color.BLACK);
        window.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void open(Class<?> target) {
        startActivity(new Intent(this, target));
    }

    private void openCalculator(String key) {
        Intent intent = new Intent(this, MainActivity.class);
        if (key != null) intent.putExtra("open_tool", key);
        startActivity(intent);
    }

    private void openSettings() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("show_settings", true);
        startActivity(intent);
    }
}
