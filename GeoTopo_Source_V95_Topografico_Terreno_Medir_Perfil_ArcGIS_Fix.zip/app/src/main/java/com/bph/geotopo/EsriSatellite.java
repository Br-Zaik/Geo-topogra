package com.bph.geotopo;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Locale;

/**
 * ArcGIS imagery access for Geo Topo using the exact raster-tile combination
 * documented by Esri for MapLibre:
 *
 *  - World Imagery map tiles as the satellite base.
 *  - ArcGIS Imagery Labels from Static Basemap Tiles for the hybrid view.
 *
 * Both are designed to work with an ArcGIS Location Platform API key that has
 * Location services > Basemaps > Static basemap tiles enabled. The key is
 * supplied only at build time through ESRI_API_KEY.
 */
public final class EsriSatellite {
    private static final String PREFS = "geo_topo_prefs";
    // V3 resets the stale Basemap Styles lock from the previous implementation.
    private static final String KEY_LOCKED = "esri_static_tiles_locked_v3";
    private static final String KEY_LOCK_REASON = "esri_static_tiles_lock_reason_v3";
    private static final String KEY_ATTRIBUTION = "esri_static_tiles_attribution_v3";
    private static final String KEY_LAST_OK = "esri_static_tiles_last_ok_v3";
    private static final long CHECK_CACHE_MS = 15L * 60L * 1000L;

    private static final String WORLD_IMAGERY =
            "https://ibasemaps-api.arcgis.com/arcgis/rest/services/World_Imagery/MapServer";
    private static final String STATIC_BASEMAP =
            "https://static-map-tiles-api.arcgis.com/arcgis/rest/services/static-basemap-tiles-service/v1";
    private static final String IMAGERY_LABELS = STATIC_BASEMAP + "/arcgis/imagery/labels/static";

    private static final String IMAGERY_ATTRIBUTION =
            "Esri, Vantor, Earthstar Geographics, and the GIS User Community";
    private static final String LABELS_ATTRIBUTION =
            "Esri, TomTom, Garmin, FAO, NOAA, USGS, OpenStreetMap contributors, and the GIS User Community";

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private EsriSatellite() { }

    public interface Callback {
        void onResult(Result result);
    }

    public static final class Result {
        public final boolean available;
        public final boolean locked;
        public final String message;

        Result(boolean available, boolean locked, String message) {
            this.available = available;
            this.locked = locked;
            this.message = message == null ? "" : message;
        }
    }

    public static boolean isConfigured() {
        return BuildConfig.ESRI_API_KEY != null && !BuildConfig.ESRI_API_KEY.trim().isEmpty();
    }

    public static boolean isLocked(Context context) {
        if (!isConfigured()) return true;
        return prefs(context).getBoolean(KEY_LOCKED, false);
    }

    public static String lockMessage(Context context) {
        if (!isConfigured()) {
            return "Satélite no configurado todavía por el desarrollador.";
        }
        String reason = prefs(context).getString(KEY_LOCK_REASON, "");
        return reason == null || reason.trim().isEmpty()
                ? "Satélite temporalmente no disponible."
                : reason;
    }

    /** Clean World Imagery raster style, without labels. */
    public static String satelliteStyleJson() {
        return buildStyle(false);
    }

    /** World Imagery plus ArcGIS imagery labels/roads, i.e. hybrid Calles mode. */
    public static String hybridStyleJson() {
        return buildStyle(true);
    }

    private static String buildStyle(boolean labels) {
        try {
            JSONObject root = new JSONObject();
            root.put("version", 8);

            JSONObject sources = new JSONObject();
            JSONObject imagery = new JSONObject();
            imagery.put("type", "raster");
            imagery.put("tiles", new JSONArray().put(worldImageryTileUrl()));
            imagery.put("attribution", IMAGERY_ATTRIBUTION);
            sources.put("imagery", imagery);

            if (labels) {
                JSONObject reference = new JSONObject();
                reference.put("type", "raster");
                reference.put("tiles", new JSONArray().put(imageryLabelsTileUrl()));
                // Esri Static Basemap Tiles use a 512 x 512 tiling scheme.
                reference.put("tileSize", 512);
                reference.put("attribution", LABELS_ATTRIBUTION);
                sources.put("imagery-labels", reference);
            }
            root.put("sources", sources);

            JSONArray layers = new JSONArray();
            JSONObject imageryLayer = new JSONObject();
            imageryLayer.put("id", "arcgis-world-imagery");
            imageryLayer.put("type", "raster");
            imageryLayer.put("source", "imagery");
            imageryLayer.put("minzoom", 0);
            imageryLayer.put("maxzoom", 23);
            layers.put(imageryLayer);

            if (labels) {
                JSONObject labelsLayer = new JSONObject();
                labelsLayer.put("id", "arcgis-imagery-labels");
                labelsLayer.put("type", "raster");
                labelsLayer.put("source", "imagery-labels");
                labelsLayer.put("minzoom", 0);
                labelsLayer.put("maxzoom", 22);
                layers.put(labelsLayer);
            }
            root.put("layers", layers);
            return root.toString();
        } catch (Exception ignored) {
            // This JSON is entirely app-generated; fallback keeps MapLibre from crashing
            // if an unexpected platform JSON issue ever occurs.
            return "{\"version\":8,\"sources\":{},\"layers\":[]}";
        }
    }

    private static String worldImageryTileUrl() {
        return WORLD_IMAGERY + "/tile/{z}/{y}/{x}?token=" + encodedKey();
    }

    private static String imageryLabelsTileUrl() {
        return IMAGERY_LABELS + "/tile/{z}/{y}/{x}?token=" + encodedKey();
    }

    public static String attribution(Context context) {
        String saved = prefs(context).getString(KEY_ATTRIBUTION, "");
        if (saved != null && !saved.trim().isEmpty()) return saved.trim();
        return IMAGERY_ATTRIBUTION;
    }

    public static void checkAvailability(Context context, Callback callback) {
        if (context == null) return;
        Context app = context.getApplicationContext();
        if (!isConfigured()) {
            MAIN.post(() -> {
                if (callback != null) callback.onResult(new Result(false, true,
                        "Satélite no configurado todavía por el desarrollador."));
            });
            return;
        }

        SharedPreferences sp = prefs(app);
        long lastOk = sp.getLong(KEY_LAST_OK, 0L);
        boolean locked = sp.getBoolean(KEY_LOCKED, false);
        if (!locked && lastOk > 0L && System.currentTimeMillis() - lastOk < CHECK_CACHE_MS) {
            MAIN.post(() -> {
                if (callback != null) callback.onResult(new Result(true, false, ""));
            });
            return;
        }

        new Thread(() -> {
            Result result = checkNow(app);
            MAIN.post(() -> {
                if (callback != null) callback.onResult(result);
            });
        }, "GeoTopo-Esri-Check").start();
    }

    private static Result checkNow(Context context) {
        // Probe the same Static Basemap Tiles privilege used by the hybrid labels.
        String checkUrl = IMAGERY_LABELS + "?f=json&token=" + encodedKey();
        HttpURLConnection connection = null;
        try {
            connection = open(checkUrl, 8000, 10000);
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) return handleAccessCode(context, code);

            String body = readText(connection.getInputStream());
            JSONObject json = new JSONObject(body);
            Result jsonError = parseArcGisError(context, json);
            if (jsonError != null) return jsonError;

            String copyright = json.optString("copyrightText", "").trim();
            if (!copyright.isEmpty()) {
                prefs(context).edit().putString(KEY_ATTRIBUTION, copyright).apply();
            }

            clearLocked(context);
            prefs(context).edit().putLong(KEY_LAST_OK, System.currentTimeMillis()).apply();
            return new Result(true, false, "");
        } catch (Exception e) {
            return new Result(false, false, "Satélite sin conexión. Se mantiene el mapa normal.");
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static Result parseArcGisError(Context context, JSONObject json) {
        if (json == null) return null;
        JSONObject error = json.optJSONObject("error");
        if (error == null) return null;
        int code = error.optInt("code", 0);
        String message = error.optString("message", "");
        if (code == 401 || code == 402 || code == 403 || code == 429 || code == 498 || code == 499) {
            return handleAccessCode(context, code);
        }
        if (code >= 500) return new Result(false, false, "Servicio satelital temporalmente sin respuesta.");
        if (!message.trim().isEmpty()) {
            return new Result(false, false, "No se pudo abrir el satélite: " + message.trim());
        }
        return new Result(false, false, "No se pudo abrir el satélite.");
    }

    private static HttpURLConnection open(String address, int connectTimeout, int readTimeout) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        connection.setConnectTimeout(connectTimeout);
        connection.setReadTimeout(readTimeout);
        connection.setRequestProperty("User-Agent", "GeoTopo/1.30 Android (com.bph.geotopo)");
        connection.setRequestProperty("Accept", "application/json,*/*");
        return connection;
    }

    private static Result handleAccessCode(Context context, int code) {
        if (code == 401 || code == 498 || code == 499) {
            String message = "Satélite bloqueado: la clave de ArcGIS no es válida o caducó.";
            markLocked(context, message);
            return new Result(false, true, message);
        }
        if (code == 402 || code == 429) {
            String message = "Satélite bloqueado temporalmente: se alcanzó el límite o la cuota disponible de ArcGIS.";
            markLocked(context, message);
            return new Result(false, true, message);
        }
        if (code == 403) {
            // Missing developer privilege is not the same as an exhausted quota.
            clearLocked(context);
            return new Result(false, false,
                    "La clave de ArcGIS no tiene habilitado Teselas de mapas base estáticos.");
        }
        if (code >= 500) {
            return new Result(false, false, "Servicio satelital temporalmente sin respuesta.");
        }
        return new Result(false, false, "No se pudo abrir el satélite (código " + code + ").");
    }

    public static void markLocked(Context context, String reason) {
        if (context == null) return;
        prefs(context).edit()
                .putBoolean(KEY_LOCKED, true)
                .putString(KEY_LOCK_REASON, reason == null ? "Satélite temporalmente no disponible." : reason)
                .remove(KEY_LAST_OK)
                .apply();
    }

    public static void clearLocked(Context context) {
        if (context == null) return;
        prefs(context).edit()
                .putBoolean(KEY_LOCKED, false)
                .remove(KEY_LOCK_REASON)
                .apply();
    }

    public static boolean looksLikeAccessFailure(String errorMessage) {
        if (errorMessage == null) return false;
        String lower = errorMessage.toLowerCase(Locale.ROOT);
        return lower.contains("401") || lower.contains("402") || lower.contains("403") || lower.contains("429")
                || lower.contains("498") || lower.contains("499")
                || lower.contains("unauthor") || lower.contains("forbidden")
                || lower.contains("quota") || lower.contains("rate limit")
                || lower.contains("billing") || lower.contains("token");
    }

    public static boolean shouldLockForError(String errorMessage) {
        if (errorMessage == null) return false;
        String lower = errorMessage.toLowerCase(Locale.ROOT);
        return lower.contains("401") || lower.contains("402") || lower.contains("429")
                || lower.contains("498") || lower.contains("499")
                || lower.contains("unauthor") || lower.contains("quota")
                || lower.contains("rate limit") || lower.contains("billing")
                || lower.contains("invalid token") || lower.contains("token expired");
    }

    public static String accessFailureMessage(String errorMessage) {
        String lower = errorMessage == null ? "" : errorMessage.toLowerCase(Locale.ROOT);
        if (lower.contains("403") || lower.contains("forbidden")) {
            return "La clave de ArcGIS no tiene habilitado Teselas de mapas base estáticos.";
        }
        if (lower.contains("402") || lower.contains("429") || lower.contains("quota")
                || lower.contains("rate limit") || lower.contains("billing")) {
            return "Satélite bloqueado temporalmente: se alcanzó el límite o la cuota disponible de ArcGIS.";
        }
        if (lower.contains("401") || lower.contains("498") || lower.contains("499")
                || lower.contains("unauthor") || lower.contains("invalid token") || lower.contains("token expired")) {
            return "Satélite bloqueado: la clave de ArcGIS no es válida o caducó.";
        }
        return "Satélite temporalmente no disponible.";
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static String encodedKey() {
        try {
            return URLEncoder.encode(BuildConfig.ESRI_API_KEY == null ? "" : BuildConfig.ESRI_API_KEY.trim(), "UTF-8");
        } catch (Exception ignored) {
            return BuildConfig.ESRI_API_KEY == null ? "" : BuildConfig.ESRI_API_KEY.trim();
        }
    }

    private static String readText(InputStream input) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(input, "UTF-8"));
        StringBuilder out = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) out.append(line);
        return out.toString();
    }
}
