package com.bph.geotopo;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Replanteo de punto con guía gráfica Norte-arriba.
 * Mantiene el cálculo geográfico/UTM original y presenta los resultados en tiempo real.
 */
public class StakeoutActivity extends BaseToolActivity {
    private static final int REQ_LOCATION = 9401;

    private static final int NAV_BLUE = Color.rgb(45, 129, 255);
    private static final int TARGET_GREEN = Color.rgb(112, 220, 68);
    private static final int VALUE_GREEN = Color.rgb(93, 207, 57);
    private static final int WARN_AMBER = Color.rgb(255, 171, 0);
    private static final int PURPLE = Color.rgb(132, 83, 255);

    private LocationManager locationManager;
    private EditText firstInput;
    private EditText secondInput;
    private EditText zoneInput;
    private EditText toleranceInput;
    private CheckBox utmCheck;
    private CheckBox southCheck;
    private LinearLayout utmOptions;
    private TextView modeHelp;
    private TextView statusText;
    private TextView distanceValue;
    private TextView azimuthValue;
    private TextView northValue;
    private TextView eastValue;
    private TextView precisionValue;
    private TextView precisionDetail;
    private Button startButton;
    private StakeoutNavigationView navigationView;

    private boolean running;
    private Location lastLocation;
    private boolean arrivalVibrated;
    private boolean pendingUseCurrent;

    private final LocationListener listener = new LocationListener() {
        @Override public void onLocationChanged(Location location) {
            if (location == null) return;
            if (lastLocation != null && lastLocation.getTime() > 0 && location.getTime() > 0
                    && location.getTime() < lastLocation.getTime()) return;
            lastLocation = location;
            if (pendingUseCurrent) {
                pendingUseCurrent = false;
                fillTargetFromLocation(location);
                if (!running && locationManager != null) {
                    try { locationManager.removeUpdates(listener); } catch (SecurityException ignored) {}
                }
            }
            updateResult(location);
        }

        @Override public void onProviderDisabled(String provider) {
            setStatus("Activa la ubicación/GPS del celular para usar el replanteo.", WARN_AMBER);
        }

        @Override public void onProviderEnabled(String provider) {
            setStatus("GPS activo. Esperando una posición válida...", NAV_BLUE);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);
        root.addView(stakeoutTopBar());

        LinearLayout content = vertical();
        content.addView(buildTargetCard());
        content.addView(buildNavigationCard());
        content.addView(buildMetricsSection());
        content.addView(buildStatusBanner());

        root.addView(scrollWith(content), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        updateMode();
        resetLiveDisplay();
        applyLaunchTarget();
    }

    private void applyLaunchTarget() {
        Intent intent = getIntent();
        if (intent == null || !intent.hasExtra("target_lat") || !intent.hasExtra("target_lon")) return;
        double lat = intent.getDoubleExtra("target_lat", Double.NaN);
        double lon = intent.getDoubleExtra("target_lon", Double.NaN);
        if (!Double.isFinite(lat) || !Double.isFinite(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) return;
        if (utmCheck != null) utmCheck.setChecked(false);
        updateMode();
        if (firstInput != null) firstInput.setText(String.format(Locale.US, "%.8f", lat));
        if (secondInput != null) secondInput.setText(String.format(Locale.US, "%.8f", lon));
        String name = intent.getStringExtra("target_name");
        String prefix = name == null || name.trim().isEmpty() ? "Objetivo cargado desde el mapa."
                : "Objetivo cargado: " + name.trim() + ".";
        setStatus(prefix + " Pulsa Iniciar replanteo.", NAV_BLUE);
    }

    private LinearLayout stakeoutTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(8), dp(8), dp(8));
        bar.setBackgroundColor(barColor);

        Button back = topIconButton("‹", 30);
        back.setContentDescription("Volver");
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(50)));

        LinearLayout titles = vertical();
        TextView title = text("Replanteo de punto", 20, true);
        title.setTextColor(Color.WHITE);
        titles.addView(title);
        TextView subtitle = text("Objetivo geográfico o UTM WGS84", 12, false);
        subtitle.setTextColor(Color.rgb(215, 228, 240));
        titles.addView(subtitle);
        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button help = topIconButton("?", 18);
        help.setContentDescription("Ayuda de replanteo");
        help.setOnClickListener(v -> showHelp());
        bar.addView(help, new LinearLayout.LayoutParams(dp(44), dp(44)));

        Button more = topIconButton("⋮", 24);
        more.setContentDescription("Más opciones");
        more.setOnClickListener(this::showMoreMenu);
        bar.addView(more, new LinearLayout.LayoutParams(dp(44), dp(44)));
        return bar;
    }

    private Button topIconButton(String label, int sizeSp) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(sizeSp);
        button.setTextColor(Color.WHITE);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        button.setPadding(0, 0, 0, 0);
        button.setMinWidth(0);
        button.setMinHeight(0);
        button.setBackgroundColor(Color.TRANSPARENT);
        return button;
    }

    private LinearLayout buildTargetCard() {
        LinearLayout box = card();
        box.setPadding(dp(12), dp(12), dp(12), dp(12));

        TextView warningView = warning("⚠  El GNSS interno del teléfono es orientativo.\nPara replanteo centimétrico se requiere receptor RTK o estación total y control de campo.");
        warningView.setTextColor(themeMode == 0 ? Color.rgb(85, 68, 20) : Color.rgb(244, 234, 204));
        box.addView(warningView);

        Button notebookPoint = secondaryButton("Elegir punto de Libreta de campo");
        notebookPoint.setOnClickListener(v -> chooseNotebookPoint());
        box.addView(notebookPoint);

        utmCheck = new CheckBox(this);
        utmCheck.setText("Ingresar objetivo en UTM WGS84");
        utmCheck.setTextColor(textColor);
        ResponsiveUi.configureCompactText(utmCheck, 14, 11, 2);
        utmCheck.setPadding(dp(2), dp(1), dp(2), dp(1));
        utmCheck.setOnCheckedChangeListener((buttonView, isChecked) -> updateMode());
        box.addView(utmCheck);

        modeHelp = small("");
        modeHelp.setTextSize(12);
        box.addView(modeHelp);

        LinearLayout r1 = horizontal();
        firstInput = numberInput("");
        secondInput = numberInput("");
        r1.addView(labeled("Latitud / Norte UTM", firstInput), weight());
        r1.addView(labeled("Longitud / Este UTM", secondInput), weight());
        box.addView(r1);

        utmOptions = horizontal();
        zoneInput = integerInput("19");
        zoneInput.setText("19");
        southCheck = new CheckBox(this);
        southCheck.setText("Hemisferio Sur (S)");
        southCheck.setTextColor(textColor);
        ResponsiveUi.configureCompactText(southCheck, 12, 10, 2);
        southCheck.setChecked(true);
        utmOptions.addView(labeled("Zona UTM (1–60)", zoneInput), weight());
        utmOptions.addView(southCheck, weight());
        box.addView(utmOptions);

        toleranceInput = numberInput("2.0");
        toleranceInput.setText("2.0");
        box.addView(labeled("Tolerancia de llegada (m)", toleranceInput));

        LinearLayout actions = horizontal();
        startButton = primaryButton("▶  Iniciar replanteo");
        startButton.setOnClickListener(v -> toggle());
        actions.addView(startButton, weight());
        Button current = secondaryButton("⌖  Usar posición actual");
        current.setOnClickListener(v -> useCurrent());
        actions.addView(current, weight());
        box.addView(actions);
        return box;
    }

    private LinearLayout buildNavigationCard() {
        LinearLayout box = card();
        box.setPadding(dp(6), dp(6), dp(6), dp(6));
        navigationView = new StakeoutNavigationView();
        int height = ResponsiveUi.isNarrow(this) ? dp(330) : dp(360);
        box.addView(navigationView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, height));
        return box;
    }

    private LinearLayout buildMetricsSection() {
        LinearLayout section = vertical();

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setWeightSum(4f);
        row.setPadding(0, 0, 0, dp(6));

        MetricTile distance = metricTile("⚑", "Distancia restante", NAV_BLUE);
        distanceValue = distance.value;
        row.addView(distance.root, metricWeight());

        MetricTile azimuth = metricTile("◉", "Azimut", VALUE_GREEN);
        azimuthValue = azimuth.value;
        row.addView(azimuth.root, metricWeight());

        MetricTile north = metricTile("↑", "Δ Norte", VALUE_GREEN);
        northValue = north.value;
        row.addView(north.root, metricWeight());

        MetricTile east = metricTile("→", "Δ Este", VALUE_GREEN);
        eastValue = east.value;
        row.addView(east.root, metricWeight());
        section.addView(row);

        LinearLayout precisionCard = card();
        precisionCard.setOrientation(LinearLayout.HORIZONTAL);
        precisionCard.setGravity(Gravity.CENTER_VERTICAL);
        precisionCard.setPadding(dp(12), dp(10), dp(12), dp(10));

        TextView icon = text("◈", 24, true);
        icon.setTextColor(PURPLE);
        icon.setGravity(Gravity.CENTER);
        precisionCard.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(48)));

        LinearLayout labels = vertical();
        TextView pLabel = text("Precisión actual", 12, false);
        pLabel.setTextColor(subTextColor);
        labels.addView(pLabel);
        precisionValue = text("—", 18, true);
        labels.addView(precisionValue);
        precisionDetail = text("Esperando posición", 11, false);
        precisionDetail.setTextColor(subTextColor);
        precisionDetail.setMaxLines(2);
        labels.addView(precisionDetail);
        precisionCard.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView bars = text("▂▄▆█", 22, true);
        bars.setTextColor(VALUE_GREEN);
        bars.setGravity(Gravity.CENTER);
        precisionCard.addView(bars, new LinearLayout.LayoutParams(dp(72), dp(54)));
        section.addView(precisionCard);
        return section;
    }

    private LinearLayout buildStatusBanner() {
        LinearLayout banner = new LinearLayout(this);
        banner.setOrientation(LinearLayout.HORIZONTAL);
        banner.setGravity(Gravity.CENTER_VERTICAL);
        banner.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(6));
        banner.setLayoutParams(lp);

        TextView info = text("i", 16, true);
        info.setGravity(Gravity.CENTER);
        info.setTextColor(Color.WHITE);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setShape(GradientDrawable.OVAL);
        iconBg.setColor(NAV_BLUE);
        info.setBackground(iconBg);
        banner.addView(info, new LinearLayout.LayoutParams(dp(34), dp(34)));

        statusText = text("Replanteo detenido. Completa el objetivo y pulsa Iniciar replanteo.", 13, false);
        statusText.setPadding(dp(10), 0, 0, 0);
        statusText.setLineSpacing(0, 1.08f);
        banner.addView(statusText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        styleStatusBanner(banner, NAV_BLUE);
        statusText.setTag(banner);
        return banner;
    }

    private LinearLayout.LayoutParams metricWeight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(102), 1f);
        int gap = ResponsiveUi.isNarrow(this) ? dp(2) : dp(4);
        lp.setMargins(gap, 0, gap, 0);
        return lp;
    }

    private MetricTile metricTile(String iconText, String labelText, int valueColor) {
        LinearLayout root = vertical();
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(5), dp(8), dp(5), dp(7));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(cardColor);
        bg.setCornerRadius(dp(13));
        bg.setStroke(dp(1), withAlpha(borderColor, 145));
        root.setBackground(bg);

        TextView icon = text(iconText, 18, true);
        icon.setTextColor(valueColor);
        icon.setGravity(Gravity.CENTER);
        root.addView(icon, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));

        TextView label = text(labelText, 10, false);
        label.setTextColor(subTextColor);
        label.setGravity(Gravity.CENTER);
        ResponsiveUi.configureCompactText(label, 10, 8, 2);
        root.addView(label, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(30)));

        TextView value = text("—", 15, true);
        value.setTextColor(valueColor);
        value.setGravity(Gravity.CENTER);
        ResponsiveUi.configureCompactText(value, 15, 10, 2);
        root.addView(value, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(32)));
        return new MetricTile(root, value);
    }

    private void updateMode() {
        boolean utm = utmCheck != null && utmCheck.isChecked();
        if (utmOptions != null) utmOptions.setVisibility(utm ? View.VISIBLE : View.GONE);
        if (modeHelp != null) modeHelp.setText(utm
                ? "Modo UTM: Norte (Y), Este (X), zona y hemisferio del proyecto."
                : "Modo geográfico: latitud y longitud en grados decimales.");
        if (firstInput != null && secondInput != null) {
            firstInput.setHint(utm ? "Norte UTM" : "Latitud");
            secondInput.setHint(utm ? "Este UTM" : "Longitud");
        }
    }

    private void toggle() {
        if (running) {
            stopUpdates();
            setStatus("Replanteo detenido. La última guía queda visible.", NAV_BLUE);
            return;
        }
        try {
            readTarget();
            if (parse(toleranceInput) <= 0) throw new IllegalArgumentException();
        } catch (Exception e) {
            showToast("Revisa la coordenada objetivo, zona/hemisferio y tolerancia.");
            setStatus("Faltan datos válidos del punto objetivo.", WARN_AMBER);
            return;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        startUpdates();
    }

    private Target readTarget() {
        if (!utmCheck.isChecked()) {
            double lat = parse(firstInput), lon = parse(secondInput);
            if (lat < -90 || lat > 90 || lon < -180 || lon > 180) throw new IllegalArgumentException();
            return new Target(lat, lon, null);
        }
        double northing = parse(firstInput), easting = parse(secondInput);
        int zone = (int) Math.round(parse(zoneInput));
        if (Math.abs(parse(zoneInput) - zone) > 1e-9 || zone < 1 || zone > 60) throw new IllegalArgumentException();
        CoordinateUtils.LatLon ll = CoordinateUtils.fromUtm(easting, northing, zone, southCheck.isChecked());
        if (!ll.valid) throw new IllegalArgumentException();
        return new Target(ll.latitude, ll.longitude,
                new CoordinateUtils.Utm(true, zone, southCheck.isChecked(), easting, northing));
    }

    private void startUpdates() {
        if (locationManager == null) {
            setStatus("El servicio de ubicación no está disponible.", WARN_AMBER);
            return;
        }
        try {
            boolean requested = false;
            boolean gpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            if (gpsEnabled) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener);
                requested = true;
            } else if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1500L, 0f, listener);
                requested = true;
            }
            if (!requested) {
                setStatus("Activa la ubicación del celular.", WARN_AMBER);
                return;
            }
            running = true;
            arrivalVibrated = false;
            startButton.setText("■  Detener replanteo");
            setStatus(gpsEnabled
                    ? "Buscando señal GNSS... Mantén vista despejada al cielo."
                    : "Usando ubicación de red aproximada; activa GPS para mejorar.", NAV_BLUE);
        } catch (SecurityException e) {
            setStatus("No se concedió el permiso de ubicación.", WARN_AMBER);
        }
    }

    private void stopUpdates() {
        if (locationManager != null) {
            try { locationManager.removeUpdates(listener); } catch (SecurityException ignored) {}
        }
        running = false;
        pendingUseCurrent = false;
        if (startButton != null) startButton.setText("▶  Iniciar replanteo");
    }

    private void updateResult(Location current) {
        if (!running || current == null) return;
        try {
            Target targetData = readTarget();
            double tolerance = parse(toleranceInput);
            Location target = new Location("target");
            target.setLatitude(targetData.latitude);
            target.setLongitude(targetData.longitude);
            float distance = current.distanceTo(target);
            float bearing = (float) normalizeBearing(current.bearingTo(target));

            double dNorth;
            double dEast;
            String coordinateInfo;
            if (targetData.utm != null) {
                CoordinateUtils.Utm currentUtm = CoordinateUtils.toUtm(
                        current.getLatitude(), current.getLongitude(), targetData.utm.zone);
                if (!currentUtm.valid) throw new IllegalArgumentException();
                dNorth = targetData.utm.northing - currentUtm.northing;
                dEast = targetData.utm.easting - currentUtm.easting;
                coordinateInfo = "UTM " + currentUtm.zone + currentUtm.hemisphere()
                        + " · N " + f3(currentUtm.northing) + " · E " + f3(currentUtm.easting);
            } else {
                double latRad = Math.toRadians((current.getLatitude() + targetData.latitude) / 2.0);
                dNorth = (targetData.latitude - current.getLatitude()) * 111320.0;
                dEast = (targetData.longitude - current.getLongitude()) * 111320.0 * Math.cos(latRad);
                coordinateInfo = "Actual " + f7(current.getLatitude()) + ", " + f7(current.getLongitude());
            }

            boolean arrived = distance <= tolerance;
            if (arrived && !arrivalVibrated) {
                arrivalVibrated = true;
                vibrateArrival();
            }
            if (distance > tolerance * 1.5) arrivalVibrated = false;

            String age = current.getTime() > 0
                    ? f1(Math.max(0, System.currentTimeMillis() - current.getTime()) / 1000.0) + " s"
                    : "—";
            String accuracy = current.hasAccuracy() ? "±" + f1(current.getAccuracy()) + " m" : "—";

            distanceValue.setText(f2(distance) + " m");
            azimuthValue.setText(f1(bearing) + "°");
            northValue.setText(signed(dNorth) + " m");
            eastValue.setText(signed(dEast) + " m");
            precisionValue.setText(accuracy);
            String provider = current.getProvider() == null ? "ubicación" : current.getProvider().toUpperCase(Locale.US);
            precisionDetail.setText(provider + " · " + coordinateInfo + " · edad " + age);

            navigationView.setNavigation(dNorth, dEast, distance, tolerance, bearing, arrived);

            if (arrived) {
                setStatus("✓ Objetivo dentro de la tolerancia de " + f2(tolerance) + " m.", TARGET_GREEN);
            } else {
                setStatus("A " + f2(distance) + " m del objetivo · " + direction(dNorth, dEast), NAV_BLUE);
            }
        } catch (Exception e) {
            setStatus("Revisa la coordenada objetivo, la zona UTM y la tolerancia.", WARN_AMBER);
        }
    }

    private String direction(double north, double east) {
        String ns = Math.abs(north) < 0.3 ? "" : (north > 0 ? "Norte" : "Sur");
        String ew = Math.abs(east) < 0.3 ? "" : (east > 0 ? "Este" : "Oeste");
        if (!ns.isEmpty() && !ew.isEmpty()) return "avanza hacia " + ns + " y " + ew + ".";
        if (!ns.isEmpty()) return "avanza hacia el " + ns + ".";
        if (!ew.isEmpty()) return "avanza hacia el " + ew + ".";
        return "muy cerca del objetivo.";
    }

    private void vibrateArrival() {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vibrator == null || !vibrator.hasVibrator()) return;
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(VibrationEffect.createWaveform(new long[]{0, 180, 100, 180}, -1));
        } else {
            vibrator.vibrate(new long[]{0, 180, 100, 180}, -1);
        }
    }

    private void chooseNotebookPoint() {
        List<NotebookStore.Entry> entries = NotebookStore.load(this);
        List<NotebookStore.Entry> usable = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        for (NotebookStore.Entry entry : entries) {
            if (!isUsableNotebookEntry(entry)) continue;
            usable.add(entry);
            String code = entry.code == null || entry.code.trim().isEmpty() ? "Sin código" : entry.code.trim();
            String project = entry.project == null || entry.project.trim().isEmpty() ? "General" : entry.project.trim();
            String crs = entry.crs == null || entry.crs.trim().isEmpty() ? "Sistema no indicado" : entry.crs.trim();
            labels.add(code + " · " + project + "\n" + crs);
        }
        if (usable.isEmpty()) {
            showToast("No hay puntos compatibles en la Libreta de campo.");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Elegir punto de Libreta")
                .setItems(labels.toArray(new String[0]), (dialog, which) -> fillTargetFromNotebook(usable.get(which)))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private boolean isUsableNotebookEntry(NotebookStore.Entry entry) {
        if (entry == null || entry.north == null || entry.east == null) return false;
        try {
            double north = Double.parseDouble(entry.north.trim().replace(',', '.'));
            double east = Double.parseDouble(entry.east.trim().replace(',', '.'));
            String crs = entry.crs == null ? "" : entry.crs.toLowerCase(Locale.US);
            if (crs.contains("geogr") || crs.contains("lat") || crs.contains("lon")) {
                return north >= -90 && north <= 90 && east >= -180 && east <= 180;
            }
            if (crs.contains("utm")) return extractUtmZone(entry.crs) >= 1;
            return north >= -90 && north <= 90 && east >= -180 && east <= 180;
        } catch (Exception e) {
            return false;
        }
    }

    private void fillTargetFromNotebook(NotebookStore.Entry entry) {
        try {
            double north = Double.parseDouble(entry.north.trim().replace(',', '.'));
            double east = Double.parseDouble(entry.east.trim().replace(',', '.'));
            String crs = entry.crs == null ? "" : entry.crs;
            String lower = crs.toLowerCase(Locale.US);
            if (lower.contains("utm")) {
                int zone = extractUtmZone(crs);
                if (zone < 1 || zone > 60) {
                    showToast("Ese punto UTM no tiene una zona válida en la Libreta.");
                    return;
                }
                utmCheck.setChecked(true);
                zoneInput.setText(String.valueOf(zone));
                southCheck.setChecked(extractSouthHemisphere(crs));
                firstInput.setText(f3(north));
                secondInput.setText(f3(east));
            } else {
                if (north < -90 || north > 90 || east < -180 || east > 180) {
                    showToast("Ese punto no tiene un sistema de coordenadas compatible.");
                    return;
                }
                utmCheck.setChecked(false);
                firstInput.setText(f7(north));
                secondInput.setText(f7(east));
            }
            String code = entry.code == null || entry.code.trim().isEmpty() ? "punto" : entry.code.trim();
            setStatus("Objetivo cargado desde Libreta: " + code + ".", NAV_BLUE);
            showToast("Punto " + code + " cargado.");
        } catch (Exception e) {
            showToast("No se pudo cargar ese punto de la Libreta.");
        }
    }

    private int extractUtmZone(String crs) {
        if (crs == null) return -1;
        String value = crs.toUpperCase(Locale.US);
        int utm = value.indexOf("UTM");
        if (utm < 0) return -1;
        for (int i = utm + 3; i < value.length(); i++) {
            if (!Character.isDigit(value.charAt(i))) continue;
            int j = i;
            while (j < value.length() && Character.isDigit(value.charAt(j))) j++;
            try {
                int zone = Integer.parseInt(value.substring(i, j));
                return zone >= 1 && zone <= 60 ? zone : -1;
            } catch (Exception ignored) {
                return -1;
            }
        }
        return -1;
    }

    private boolean extractSouthHemisphere(String crs) {
        if (crs == null) return true;
        String value = crs.toUpperCase(Locale.US).replace(" ", "");
        int zone = extractUtmZone(crs);
        if (zone < 1) return true;
        return value.contains("UTM" + zone + "S") || value.contains("ZONA" + zone + "S") || value.endsWith(zone + "S");
    }

    private void useCurrent() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            pendingUseCurrent = true;
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        Location current = lastLocation != null ? lastLocation : bestLastKnownLocation();
        if (current == null) {
            pendingUseCurrent = true;
            showToast("Esperando una posición actual del GPS...");
            startUpdatesForCurrentPosition();
            return;
        }
        lastLocation = current;
        fillTargetFromLocation(current);
    }

    private Location bestLastKnownLocation() {
        if (locationManager == null) return null;
        Location best = null;
        try {
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                best = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            }
            Location network = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (network != null && (best == null || network.getTime() > best.getTime())) best = network;
        } catch (SecurityException ignored) {}
        return best;
    }

    private void startUpdatesForCurrentPosition() {
        if (locationManager == null) return;
        try {
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener);
            } else if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1500L, 0f, listener);
            } else {
                pendingUseCurrent = false;
                showToast("Activa la ubicación del celular.");
            }
        } catch (SecurityException ignored) {
            pendingUseCurrent = false;
        }
    }

    private void fillTargetFromLocation(Location location) {
        if (location == null) return;
        if (utmCheck.isChecked()) {
            int zone;
            try {
                zone = (int) Math.round(parse(zoneInput));
                if (zone < 1 || zone > 60) throw new IllegalArgumentException();
            } catch (Exception e) {
                CoordinateUtils.Utm auto = CoordinateUtils.toUtm(location.getLatitude(), location.getLongitude());
                if (!auto.valid) {
                    showToast("No se pudo convertir la posición a UTM.");
                    return;
                }
                zone = auto.zone;
                zoneInput.setText(String.valueOf(zone));
            }
            CoordinateUtils.Utm u = CoordinateUtils.toUtm(location.getLatitude(), location.getLongitude(), zone);
            if (!u.valid) {
                showToast("No se pudo convertir la posición a UTM.");
                return;
            }
            firstInput.setText(f3(u.northing));
            secondInput.setText(f3(u.easting));
            southCheck.setChecked(u.south);
        } else {
            firstInput.setText(f7(location.getLatitude()));
            secondInput.setText(f7(location.getLongitude()));
        }
        showToast("Objetivo cargado con la posición actual.");
    }

    private void setStatus(String message, int color) {
        if (statusText == null) return;
        statusText.setText(message);
        Object tag = statusText.getTag();
        if (tag instanceof LinearLayout) styleStatusBanner((LinearLayout) tag, color);
    }

    private void styleStatusBanner(LinearLayout banner, int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == 0 ? Color.WHITE : Color.rgb(8, 31, 49));
        bg.setCornerRadius(dp(13));
        bg.setStroke(dp(1), withAlpha(color, 220));
        banner.setBackground(bg);
    }

    private void resetLiveDisplay() {
        if (distanceValue != null) distanceValue.setText("—");
        if (azimuthValue != null) azimuthValue.setText("—");
        if (northValue != null) northValue.setText("—");
        if (eastValue != null) eastValue.setText("—");
        if (precisionValue != null) precisionValue.setText("—");
        if (precisionDetail != null) precisionDetail.setText("Esperando posición");
        if (navigationView != null) navigationView.clearNavigation("Inicia el replanteo para ver la guía");
        setStatus("Replanteo detenido. Completa el objetivo y pulsa Iniciar replanteo.", NAV_BLUE);
    }

    private void showHelp() {
        new AlertDialog.Builder(this)
                .setTitle("Replanteo de punto")
                .setMessage("1. Ingresa el objetivo en coordenadas geográficas o UTM WGS84.\n\n"
                        + "2. Define la tolerancia de llegada.\n\n"
                        + "3. Pulsa Iniciar replanteo. La vista superior muestra tu posición, el objetivo, la dirección y la zona de tolerancia.\n\n"
                        + "4. Distancia, azimut, Δ Norte, Δ Este y precisión se actualizan con cada lectura GNSS.\n\n"
                        + "El GNSS interno es orientativo; para precisión centimétrica usa RTK o estación total.")
                .setPositiveButton("Entendido", null)
                .show();
    }

    private void showMoreMenu(View anchor) {
        PopupMenu menu = new PopupMenu(this, anchor);
        menu.getMenu().add("Modo geográfico");
        menu.getMenu().add("Modo UTM WGS84");
        menu.getMenu().add("Usar posición actual");
        if (running) menu.getMenu().add("Detener replanteo");
        menu.setOnMenuItemClickListener(item -> {
            String title = String.valueOf(item.getTitle());
            if ("Modo geográfico".equals(title)) {
                utmCheck.setChecked(false);
                return true;
            }
            if ("Modo UTM WGS84".equals(title)) {
                utmCheck.setChecked(true);
                return true;
            }
            if ("Usar posición actual".equals(title)) {
                useCurrent();
                return true;
            }
            if ("Detener replanteo".equals(title)) {
                stopUpdates();
                setStatus("Replanteo detenido. La última guía queda visible.", NAV_BLUE);
                return true;
            }
            return false;
        });
        menu.show();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_LOCATION) return;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (pendingUseCurrent) startUpdatesForCurrentPosition();
            else startUpdates();
        } else {
            pendingUseCurrent = false;
            setStatus("Sin permiso de ubicación no se puede usar el replanteo.", WARN_AMBER);
        }
    }

    @Override protected void onPause() {
        super.onPause();
        stopUpdates();
    }

    private final class StakeoutNavigationView extends View {
        private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint routePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint targetPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint currentPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint subLabelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint northPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint chipPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        private boolean hasNavigation;
        private double north;
        private double east;
        private double distance;
        private double tolerance;
        private double bearing;
        private boolean arrived;
        private String emptyMessage = "Inicia el replanteo para ver la guía";
        private final RectF centerControl = new RectF();
        private final RectF zoomControl = new RectF();
        private float zoomFactor = 1.0f;

        StakeoutNavigationView() {
            super(StakeoutActivity.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            setClickable(true);
            setPadding(dp(4), dp(4), dp(4), dp(4));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(themeMode == 0 ? Color.rgb(245, 249, 253) : Color.rgb(7, 27, 43));
            bg.setCornerRadius(dp(14));
            bg.setStroke(dp(1), withAlpha(borderColor, 110));
            setBackground(bg);

            gridPaint.setColor(themeMode == 0 ? Color.argb(34, 40, 80, 120) : Color.argb(45, 72, 126, 168));
            gridPaint.setStrokeWidth(dp(1));

            ringPaint.setStyle(Paint.Style.STROKE);
            ringPaint.setStrokeWidth(dp(1));
            ringPaint.setColor(themeMode == 0 ? Color.argb(50, 32, 101, 170) : Color.argb(66, 62, 137, 198));
            ringPaint.setPathEffect(new DashPathEffect(new float[]{dp(5), dp(5)}, 0));

            routePaint.setStyle(Paint.Style.STROKE);
            routePaint.setStrokeWidth(dp(2.2f));
            routePaint.setStrokeCap(Paint.Cap.ROUND);
            routePaint.setColor(Color.rgb(77, 180, 255));
            routePaint.setPathEffect(new DashPathEffect(new float[]{dp(7), dp(5)}, 0));
            routePaint.setShadowLayer(dp(5), 0, 0, Color.argb(120, 34, 127, 255));

            targetPaint.setStyle(Paint.Style.STROKE);
            targetPaint.setStrokeWidth(dp(3));
            targetPaint.setColor(TARGET_GREEN);
            targetPaint.setShadowLayer(dp(7), 0, 0, Color.argb(150, 87, 220, 60));

            currentPaint.setStyle(Paint.Style.FILL);
            currentPaint.setColor(NAV_BLUE);
            currentPaint.setShadowLayer(dp(8), 0, 0, Color.argb(160, 45, 129, 255));

            labelPaint.setColor(textColor);
            labelPaint.setTextSize(dp(12));
            labelPaint.setTypeface(Typeface.DEFAULT_BOLD);

            subLabelPaint.setColor(subTextColor);
            subLabelPaint.setTextSize(dp(10));

            northPaint.setColor(textColor);
            northPaint.setStrokeWidth(dp(2));
            northPaint.setStyle(Paint.Style.STROKE);

            chipPaint.setColor(themeMode == 0 ? Color.argb(220, 255, 255, 255) : Color.argb(220, 12, 35, 53));
            chipPaint.setStyle(Paint.Style.FILL);
        }

        void setNavigation(double north, double east, double distance, double tolerance,
                           double bearing, boolean arrived) {
            this.hasNavigation = true;
            this.north = north;
            this.east = east;
            this.distance = Math.max(0.0, distance);
            this.tolerance = Math.max(0.0, tolerance);
            this.bearing = bearing;
            this.arrived = arrived;
            invalidate();
        }

        void clearNavigation(String message) {
            hasNavigation = false;
            emptyMessage = message == null ? "" : message;
            invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) return;

            float left = dp(16);
            float top = dp(18);
            float right = w - dp(16);
            float bottom = h - dp(18);

            drawGrid(canvas, left, top, right, bottom);
            drawRangeRings(canvas, w, h);
            drawTopLabels(canvas, w);
            drawNorth(canvas, w);
            drawControls(canvas, w, h);

            if (!hasNavigation) {
                Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
                p.setColor(subTextColor);
                p.setTextAlign(Paint.Align.CENTER);
                p.setTextSize(dp(12));
                canvas.drawText(emptyMessage, w / 2f, h / 2f + dp(4), p);
                return;
            }

            double length = Math.hypot(east, north);
            double ux = length > 1e-9 ? east / length : Math.sin(Math.toRadians(bearing));
            double uy = length > 1e-9 ? -north / length : -Math.cos(Math.toRadians(bearing));

            float cx = w * 0.5f;
            float cy = h * 0.55f;
            float span = Math.min(w * 0.62f, h * 0.52f) * zoomFactor;
            float half = span * 0.5f;
            float currentX = cx - (float) ux * half;
            float currentY = cy - (float) uy * half;
            float targetX = cx + (float) ux * half;
            float targetY = cy + (float) uy * half;

            float margin = dp(48);
            currentX = clamp(currentX, margin, w - margin);
            currentY = clamp(currentY, dp(72), h - margin);
            targetX = clamp(targetX, margin, w - margin);
            targetY = clamp(targetY, dp(72), h - margin);

            canvas.drawLine(currentX, currentY, targetX, targetY, routePaint);
            drawRouteArrow(canvas, currentX, currentY, targetX, targetY);
            drawCurrent(canvas, currentX, currentY);
            drawTarget(canvas, targetX, targetY);
            drawTolerance(canvas, targetX, targetY, currentX, currentY);

            labelPaint.setTextAlign(Paint.Align.CENTER);
            labelPaint.setColor(textColor);
            canvas.drawText("Mi posición", currentX, Math.min(h - dp(8), currentY + dp(34)), labelPaint);
            labelPaint.setColor(TARGET_GREEN);
            canvas.drawText(arrived ? "Objetivo ✓" : "Objetivo", targetX,
                    Math.max(dp(88), targetY - dp(26)), labelPaint);

            drawDistanceBadge(canvas, w, h);
        }

        private void drawGrid(Canvas canvas, float left, float top, float right, float bottom) {
            int cols = 6;
            int rows = 6;
            for (int i = 0; i <= cols; i++) {
                float x = left + (right - left) * i / cols;
                canvas.drawLine(x, top, x, bottom, gridPaint);
            }
            for (int i = 0; i <= rows; i++) {
                float y = top + (bottom - top) * i / rows;
                canvas.drawLine(left, y, right, y, gridPaint);
            }
        }

        private void drawRangeRings(Canvas canvas, int w, int h) {
            float cx = w * 0.5f;
            float cy = h * 0.55f;
            float maxR = Math.min(w, h) * 0.42f;
            double step = niceStep(hasNavigation ? Math.max(distance / 2.0, tolerance * 2.0) : 20.0);
            for (int i = 1; i <= 3; i++) {
                float r = maxR * i / 3f;
                canvas.drawCircle(cx, cy, r, ringPaint);
                subLabelPaint.setTextAlign(Paint.Align.CENTER);
                subLabelPaint.setColor(withAlpha(subTextColor, 180));
                canvas.drawText(formatRange(step * i), cx, cy + r - dp(5), subLabelPaint);
            }
        }

        private void drawTopLabels(Canvas canvas, int w) {
            RectF chip = new RectF(dp(14), dp(12), dp(126), dp(48));
            canvas.drawRoundRect(chip, dp(9), dp(9), chipPaint);
            labelPaint.setColor(textColor);
            labelPaint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("Vista superior", chip.centerX(), chip.centerY() + dp(4), labelPaint);
        }

        private void drawNorth(Canvas canvas, int w) {
            float x = w - dp(34);
            float y = dp(26);
            labelPaint.setColor(textColor);
            labelPaint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("N", x, y + dp(4), labelPaint);
            canvas.drawLine(x, y + dp(10), x, y + dp(34), northPaint);
            Path arrow = new Path();
            arrow.moveTo(x, y + dp(9));
            arrow.lineTo(x - dp(5), y + dp(17));
            arrow.moveTo(x, y + dp(9));
            arrow.lineTo(x + dp(5), y + dp(17));
            canvas.drawPath(arrow, northPaint);
        }

        private void drawControls(Canvas canvas, int w, int h) {
            float size = dp(42);
            float gap = dp(8);
            float right = w - dp(14);
            float bottom = h - dp(62);
            zoomControl.set(right - size, bottom - size, right, bottom);
            centerControl.set(right - size, bottom - size * 2f - gap, right, bottom - size - gap);

            Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
            bg.setColor(themeMode == 0 ? Color.argb(235, 255, 255, 255) : Color.argb(230, 9, 31, 48));
            Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(dp(1));
            stroke.setColor(withAlpha(borderColor, 170));
            canvas.drawRoundRect(centerControl, dp(9), dp(9), bg);
            canvas.drawRoundRect(centerControl, dp(9), dp(9), stroke);
            canvas.drawRoundRect(zoomControl, dp(9), dp(9), bg);
            canvas.drawRoundRect(zoomControl, dp(9), dp(9), stroke);

            Paint icon = new Paint(Paint.ANTI_ALIAS_FLAG);
            icon.setColor(textColor);
            icon.setStyle(Paint.Style.STROKE);
            icon.setStrokeWidth(dp(2));
            float cx = centerControl.centerX();
            float cy = centerControl.centerY();
            canvas.drawCircle(cx, cy, dp(7), icon);
            canvas.drawCircle(cx, cy, dp(2), icon);
            canvas.drawLine(cx - dp(12), cy, cx - dp(8), cy, icon);
            canvas.drawLine(cx + dp(8), cy, cx + dp(12), cy, icon);
            canvas.drawLine(cx, cy - dp(12), cx, cy - dp(8), icon);
            canvas.drawLine(cx, cy + dp(8), cx, cy + dp(12), icon);

            Paint plus = new Paint(Paint.ANTI_ALIAS_FLAG);
            plus.setColor(textColor);
            plus.setStrokeWidth(dp(2.4f));
            plus.setStrokeCap(Paint.Cap.ROUND);
            float zx = zoomControl.centerX();
            float zy = zoomControl.centerY();
            canvas.drawLine(zx - dp(8), zy, zx + dp(8), zy, plus);
            canvas.drawLine(zx, zy - dp(8), zx, zy + dp(8), plus);
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent event) {
            if (event.getAction() != android.view.MotionEvent.ACTION_UP) return true;
            float x = event.getX();
            float y = event.getY();
            if (centerControl.contains(x, y)) {
                zoomFactor = 1.0f;
                invalidate();
                performClick();
                return true;
            }
            if (zoomControl.contains(x, y)) {
                zoomFactor += 0.18f;
                if (zoomFactor > 1.45f) zoomFactor = 1.0f;
                invalidate();
                performClick();
                return true;
            }
            return super.onTouchEvent(event);
        }

        @Override public boolean performClick() {
            super.performClick();
            return true;
        }

        private void drawRouteArrow(Canvas canvas, float x1, float y1, float x2, float y2) {
            float t = 0.62f;
            float x = x1 + (x2 - x1) * t;
            float y = y1 + (y2 - y1) * t;
            double angle = Math.atan2(y2 - y1, x2 - x1);
            float size = dp(10);
            Path path = new Path();
            path.moveTo(x + (float) Math.cos(angle) * size, y + (float) Math.sin(angle) * size);
            path.lineTo(x + (float) Math.cos(angle + 2.5) * size, y + (float) Math.sin(angle + 2.5) * size);
            path.lineTo(x + (float) Math.cos(angle - 2.5) * size, y + (float) Math.sin(angle - 2.5) * size);
            path.close();
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(NAV_BLUE);
            p.setStyle(Paint.Style.FILL);
            p.setShadowLayer(dp(5), 0, 0, Color.argb(150, 45, 129, 255));
            canvas.drawPath(path, p);
        }

        private void drawCurrent(Canvas canvas, float x, float y) {
            Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
            halo.setColor(Color.argb(58, 45, 129, 255));
            halo.setStyle(Paint.Style.FILL);
            canvas.drawCircle(x, y, dp(22), halo);
            canvas.drawCircle(x, y, dp(9), currentPaint);
            Paint inner = new Paint(Paint.ANTI_ALIAS_FLAG);
            inner.setStyle(Paint.Style.FILL);
            inner.setColor(Color.WHITE);
            canvas.drawCircle(x, y, dp(4), inner);
        }

        private void drawTarget(Canvas canvas, float x, float y) {
            canvas.drawCircle(x, y, dp(14), targetPaint);
            canvas.drawCircle(x, y, dp(5), targetPaint);
            canvas.drawLine(x - dp(20), y, x - dp(10), y, targetPaint);
            canvas.drawLine(x + dp(10), y, x + dp(20), y, targetPaint);
            canvas.drawLine(x, y - dp(20), x, y - dp(10), targetPaint);
            canvas.drawLine(x, y + dp(10), x, y + dp(20), targetPaint);
        }

        private void drawTolerance(Canvas canvas, float targetX, float targetY, float currentX, float currentY) {
            float routeLength = (float) Math.hypot(targetX - currentX, targetY - currentY);
            float radius;
            if (distance <= 1e-6) radius = dp(42);
            else radius = (float) (routeLength * tolerance / Math.max(distance, 0.01));
            radius = clamp(radius, dp(18), dp(62));
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.5f));
            p.setColor(arrived ? Color.argb(230, 112, 220, 68) : Color.argb(170, 112, 220, 68));
            p.setPathEffect(new DashPathEffect(new float[]{dp(5), dp(4)}, 0));
            canvas.drawCircle(targetX, targetY, radius, p);
            Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(Color.argb(arrived ? 45 : 24, 112, 220, 68));
            canvas.drawCircle(targetX, targetY, radius, fill);
        }

        private void drawDistanceBadge(Canvas canvas, int w, int h) {
            String value = f2(distance) + " m";
            String toleranceText = "Tolerancia " + f2(tolerance) + " m";
            RectF badge = new RectF(dp(14), h - dp(50), w - dp(14), h - dp(12));
            Paint badgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            badgePaint.setColor(themeMode == 0 ? Color.argb(235, 255, 255, 255) : Color.argb(225, 8, 30, 48));
            canvas.drawRoundRect(badge, dp(10), dp(10), badgePaint);

            labelPaint.setTextAlign(Paint.Align.LEFT);
            labelPaint.setColor(textColor);
            canvas.drawText("A " + value + " del objetivo", badge.left + dp(12), badge.centerY() + dp(4), labelPaint);
            subLabelPaint.setTextAlign(Paint.Align.RIGHT);
            subLabelPaint.setColor(arrived ? TARGET_GREEN : VALUE_GREEN);
            canvas.drawText(toleranceText, badge.right - dp(12), badge.centerY() + dp(4), subLabelPaint);
        }

        private double niceStep(double value) {
            if (Double.isNaN(value) || Double.isInfinite(value) || value <= 0.0) return 20.0;
            double exponent = Math.floor(Math.log10(value));
            double power = Math.pow(10.0, exponent);
            double fraction = value / power;
            double nice;
            if (fraction <= 1.0) nice = 1.0;
            else if (fraction <= 2.0) nice = 2.0;
            else if (fraction <= 5.0) nice = 5.0;
            else nice = 10.0;
            return nice * power;
        }

        private String formatRange(double meters) {
            if (meters >= 1000.0) return String.format(Locale.US, "%.1f km", meters / 1000.0);
            if (meters >= 10.0) return String.format(Locale.US, "%.0f m", meters);
            return String.format(Locale.US, "%.1f m", meters);
        }

        private float clamp(float value, float min, float max) {
            return Math.max(min, Math.min(max, value));
        }
    }

    private static final class MetricTile {
        final LinearLayout root;
        final TextView value;
        MetricTile(LinearLayout root, TextView value) {
            this.root = root;
            this.value = value;
        }
    }

    private static final class Target {
        final double latitude;
        final double longitude;
        final CoordinateUtils.Utm utm;
        Target(double latitude, double longitude, CoordinateUtils.Utm utm) {
            this.latitude = latitude;
            this.longitude = longitude;
            this.utm = utm;
        }
    }
}
