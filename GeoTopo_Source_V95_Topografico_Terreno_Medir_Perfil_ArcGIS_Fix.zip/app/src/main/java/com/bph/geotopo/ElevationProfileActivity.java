package com.bph.geotopo;

import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;
import org.maplibre.android.geometry.LatLng;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Profile generated directly from a line measured on the map. */
public class ElevationProfileActivity extends BaseToolActivity {
    public static final String EXTRA_POINTS_JSON = "profile_points_json";
    private static final int REQ_EXPORT_CSV = 9651;
    private static final int REQ_EXPORT_DXF = 9652;

    private final List<LatLng> path = new ArrayList<>();
    private final List<TerrainElevation.Sample> samples = new ArrayList<>();
    private ProfileChartView chart;
    private TextView status;
    private TextView minValue;
    private TextView maxValue;
    private TextView gainValue;
    private TextView lossValue;
    private TextView lengthValue;
    private ProgressBar progress;
    private Button recalcButton;
    private Button csvButton;
    private Button dxfButton;
    private String csvContent;
    private String dxfContent;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        readPath();

        LinearLayout root = page("Perfil de elevación", "Perfil automático desde la línea medida en el mapa");
        LinearLayout content = vertical();
        content.addView(warning("Alturas aproximadas de un modelo digital de terreno público (~30 m). Úsalo para análisis y planificación; no sustituye una nivelación, RTK ni estación total."));
        content.addView(buildChartCard());
        content.addView(buildMetricsCard());
        content.addView(buildActionsCard());
        root.addView(scrollWith(content), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        if (path.size() >= 2) loadProfile();
        else setStatus("No se recibió una línea válida. Vuelve al mapa y mide al menos dos puntos.", false);
    }

    private void readPath() {
        try {
            String json = getIntent() == null ? null : getIntent().getStringExtra(EXTRA_POINTS_JSON);
            if (json == null || json.trim().isEmpty()) return;
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.optJSONObject(i);
                if (obj == null) continue;
                double lat = obj.optDouble("lat", Double.NaN);
                double lon = obj.optDouble("lon", Double.NaN);
                if (Double.isFinite(lat) && Double.isFinite(lon)
                        && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180) {
                    path.add(new LatLng(lat, lon));
                }
            }
        } catch (Exception ignored) { }
    }

    private LinearLayout buildChartCard() {
        LinearLayout card = card();
        card.addView(sectionTitle("Perfil del terreno"));
        TextView info = small("Se muestrea la elevación a lo largo de toda la línea y se interpola entre los puntos del mapa.");
        card.addView(info);

        chart = new ProfileChartView();
        GradientDrawable chartBg = new GradientDrawable();
        chartBg.setColor(themeMode == 0 ? Color.rgb(250, 252, 255) : Color.rgb(7, 25, 40));
        chartBg.setCornerRadius(dp(12));
        chartBg.setStroke(dp(1), withAlpha(borderColor, 150));
        chart.setBackground(chartBg);
        LinearLayout.LayoutParams chartLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(255));
        chartLp.setMargins(0, dp(3), 0, dp(8));
        card.addView(chart, chartLp);

        LinearLayout loading = horizontal();
        loading.setGravity(Gravity.CENTER_VERTICAL);
        progress = new ProgressBar(this);
        progress.setIndeterminate(true);
        loading.addView(progress, new LinearLayout.LayoutParams(dp(28), dp(28)));
        status = text("Preparando perfil…", 12.5f, true);
        status.setTextColor(subTextColor);
        status.setPadding(dp(9), 0, 0, 0);
        loading.addView(status, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(loading);
        return card;
    }

    private LinearLayout buildMetricsCard() {
        LinearLayout card = card();
        card.addView(sectionTitle("Resumen"));

        LinearLayout row1 = horizontal();
        Metric min = metric("Elevación mínima", "—", Color.rgb(0, 188, 212));
        Metric max = metric("Elevación máxima", "—", Color.rgb(255, 171, 0));
        minValue = min.value;
        maxValue = max.value;
        row1.addView(min.root, weight());
        row1.addView(max.root, weight());
        card.addView(row1);

        LinearLayout row2 = horizontal();
        Metric gain = metric("Ascenso acumulado", "—", Color.rgb(76, 175, 80));
        Metric loss = metric("Descenso acumulado", "—", Color.rgb(239, 83, 80));
        gainValue = gain.value;
        lossValue = loss.value;
        row2.addView(gain.root, weight());
        row2.addView(loss.root, weight());
        card.addView(row2);

        Metric length = metric("Longitud del perfil", "—", accent);
        lengthValue = length.value;
        card.addView(length.root);
        return card;
    }

    private LinearLayout buildActionsCard() {
        LinearLayout card = card();
        card.addView(sectionTitle("Acciones"));

        recalcButton = secondaryButton("Recalcular elevación");
        recalcButton.setOnClickListener(v -> loadProfile());
        card.addView(recalcButton);

        LinearLayout row = horizontal();
        csvButton = secondaryButton("Exportar CSV");
        csvButton.setEnabled(false);
        csvButton.setOnClickListener(v -> exportCsv());
        dxfButton = primaryButton("Exportar DXF");
        dxfButton.setEnabled(false);
        dxfButton.setOnClickListener(v -> exportDxf());
        row.addView(csvButton, weight());
        row.addView(dxfButton, weight());
        card.addView(row);

        TextView note = small("DXF exporta el perfil como una polilínea 2D: X = distancia acumulada (m), Y = elevación (m). Es compatible con CAD para continuar el trabajo.");
        note.setPadding(0, dp(6), 0, 0);
        card.addView(note);
        return card;
    }

    private Metric metric(String titleText, String valueText, int tint) {
        LinearLayout root = vertical();
        root.setPadding(dp(10), dp(10), dp(10), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == 0 ? Color.WHITE : Color.rgb(10, 29, 45));
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), withAlpha(tint, 170));
        root.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), dp(3), dp(3), dp(6));
        root.setLayoutParams(lp);

        TextView title = text(titleText, 11.5f, true);
        title.setTextColor(withAlpha(tint, 235));
        TextView value = text(valueText, 18, true);
        value.setTextColor(textColor);
        root.addView(title);
        root.addView(value);
        return new Metric(root, value);
    }

    private void loadProfile() {
        if (path.size() < 2) return;
        csvContent = null;
        dxfContent = null;
        csvButton.setEnabled(false);
        dxfButton.setEnabled(false);
        recalcButton.setEnabled(false);
        progress.setVisibility(View.VISIBLE);
        setStatus("Leyendo el terreno a lo largo de la línea…", true);
        samples.clear();
        chart.setSamples(samples);

        TerrainElevation.sampleProfile(path, result -> {
            if (isFinishing()) return;
            recalcButton.setEnabled(true);
            progress.setVisibility(View.GONE);
            if (!result.ok) {
                samples.clear();
                if (result.samples != null) samples.addAll(result.samples);
                chart.setSamples(samples);
                setStatus(result.message, false);
                return;
            }
            samples.clear();
            samples.addAll(result.samples);
            chart.setSamples(samples);
            calculateMetrics();
            csvContent = buildCsv();
            dxfContent = buildDxf();
            csvButton.setEnabled(true);
            dxfButton.setEnabled(true);
            setStatus("Perfil calculado · " + samples.size() + " muestras de terreno.", true);
        });
    }

    private void calculateMetrics() {
        if (samples.isEmpty()) return;
        double min = Double.POSITIVE_INFINITY;
        double max = Double.NEGATIVE_INFINITY;
        double gain = 0.0;
        double loss = 0.0;
        Double previous = null;
        for (TerrainElevation.Sample sample : samples) {
            if (!Double.isFinite(sample.elevationMeters)) continue;
            min = Math.min(min, sample.elevationMeters);
            max = Math.max(max, sample.elevationMeters);
            if (previous != null) {
                double delta = sample.elevationMeters - previous;
                if (delta > 0) gain += delta;
                else loss += -delta;
            }
            previous = sample.elevationMeters;
        }
        double length = samples.get(samples.size() - 1).distanceMeters;
        minValue.setText(Double.isFinite(min) ? f1(min) + " m" : "—");
        maxValue.setText(Double.isFinite(max) ? f1(max) + " m" : "—");
        gainValue.setText(f1(gain) + " m");
        lossValue.setText(f1(loss) + " m");
        lengthValue.setText(length >= 1000 ? String.format(Locale.US, "%.3f km", length / 1000.0)
                : f1(length) + " m");
    }

    private void setStatus(String value, boolean ok) {
        if (status == null) return;
        status.setText(value);
        status.setTextColor(ok ? (themeMode == 0 ? Color.rgb(30, 120, 70) : Color.rgb(126, 226, 162))
                : (themeMode == 0 ? Color.rgb(150, 74, 20) : Color.rgb(255, 196, 120)));
    }

    private String buildCsv() {
        StringBuilder out = new StringBuilder();
        out.append("distancia_m,elevacion_m,latitud,longitud\n");
        for (TerrainElevation.Sample s : samples) {
            out.append(String.format(Locale.US, "%.3f,%.3f,%.8f,%.8f\n",
                    s.distanceMeters, s.elevationMeters, s.latitude, s.longitude));
        }
        return out.toString();
    }

    private String buildDxf() {
        StringBuilder out = new StringBuilder();
        out.append("0\nSECTION\n2\nHEADER\n9\n$INSUNITS\n70\n6\n0\nENDSEC\n");
        out.append("0\nSECTION\n2\nENTITIES\n");
        out.append("0\nLWPOLYLINE\n8\nGEOTOPO_PROFILE\n90\n").append(samples.size()).append("\n70\n0\n");
        for (TerrainElevation.Sample s : samples) {
            out.append("10\n").append(String.format(Locale.US, "%.3f", s.distanceMeters)).append("\n");
            out.append("20\n").append(String.format(Locale.US, "%.3f", s.elevationMeters)).append("\n");
        }
        out.append("0\nENDSEC\n0\nEOF\n");
        return out.toString();
    }

    private void exportCsv() {
        if (csvContent == null) return;
        createDocument(REQ_EXPORT_CSV, "text/csv", "GeoTopo_Perfil_Elevacion_", ".csv");
    }

    private void exportDxf() {
        if (dxfContent == null) return;
        createDocument(REQ_EXPORT_DXF, "application/dxf", "GeoTopo_Perfil_Elevacion_", ".dxf");
    }

    private void createDocument(int requestCode, String mime, String prefix, String extension) {
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date());
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime);
        intent.putExtra(Intent.EXTRA_TITLE, prefix + stamp + extension);
        startActivityForResult(intent, requestCode);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        String content = requestCode == REQ_EXPORT_CSV ? csvContent
                : (requestCode == REQ_EXPORT_DXF ? dxfContent : null);
        if (content == null) return;
        try {
            ContentResolver resolver = getContentResolver();
            Uri uri = data.getData();
            OutputStream stream = resolver.openOutputStream(uri);
            if (stream == null) throw new IllegalStateException();
            stream.write(content.getBytes(StandardCharsets.UTF_8));
            stream.close();
            showToast("Archivo exportado.");
        } catch (Exception e) {
            showToast("No se pudo exportar el archivo.");
        }
    }

    private final class ProfileChartView extends View {
        private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint axis = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
        private List<TerrainElevation.Sample> data = new ArrayList<>();

        ProfileChartView() {
            super(ElevationProfileActivity.this);
            grid.setColor(withAlpha(borderColor, 65));
            grid.setStrokeWidth(dp(1));
            axis.setColor(withAlpha(textColor, 170));
            axis.setStrokeWidth(dp(1.2f));
            line.setColor(Color.rgb(79, 207, 111));
            line.setStrokeWidth(dp(2.3f));
            line.setStyle(Paint.Style.STROKE);
            fill.setColor(Color.argb(themeMode == 0 ? 45 : 55, 79, 207, 111));
            fill.setStyle(Paint.Style.FILL);
            label.setColor(subTextColor);
            label.setTextSize(dp(3.5f));
        }

        void setSamples(List<TerrainElevation.Sample> values) {
            data = values == null ? new ArrayList<>() : new ArrayList<>(values);
            invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float left = dp(43);
            float right = getWidth() - dp(14);
            float top = dp(18);
            float bottom = getHeight() - dp(34);

            for (int i = 0; i <= 5; i++) {
                float y = top + (bottom - top) * i / 5f;
                canvas.drawLine(left, y, right, y, grid);
            }
            for (int i = 0; i <= 6; i++) {
                float x = left + (right - left) * i / 6f;
                canvas.drawLine(x, top, x, bottom, grid);
            }
            canvas.drawLine(left, bottom, right, bottom, axis);
            canvas.drawLine(left, top, left, bottom, axis);

            List<TerrainElevation.Sample> valid = new ArrayList<>();
            for (TerrainElevation.Sample s : data) if (Double.isFinite(s.elevationMeters)) valid.add(s);
            if (valid.size() < 2) {
                canvas.drawText("El perfil aparecerá al terminar el cálculo.", left + dp(8), top + dp(26), label);
                return;
            }

            double maxX = valid.get(valid.size() - 1).distanceMeters;
            double minY = Double.POSITIVE_INFINITY;
            double maxY = Double.NEGATIVE_INFINITY;
            for (TerrainElevation.Sample s : valid) {
                minY = Math.min(minY, s.elevationMeters);
                maxY = Math.max(maxY, s.elevationMeters);
            }
            double spanY = Math.max(2.0, maxY - minY);
            minY -= spanY * 0.12;
            maxY += spanY * 0.12;
            spanY = maxY - minY;
            maxX = Math.max(1.0, maxX);

            Path profile = new Path();
            Path area = new Path();
            boolean started = false;
            float firstX = left;
            float lastX = left;
            for (TerrainElevation.Sample s : valid) {
                float x = left + (float) (s.distanceMeters / maxX) * (right - left);
                float y = bottom - (float) ((s.elevationMeters - minY) / spanY) * (bottom - top);
                if (!started) {
                    profile.moveTo(x, y);
                    area.moveTo(x, bottom);
                    area.lineTo(x, y);
                    firstX = x;
                    started = true;
                } else {
                    profile.lineTo(x, y);
                    area.lineTo(x, y);
                }
                lastX = x;
            }
            area.lineTo(lastX, bottom);
            area.lineTo(firstX, bottom);
            area.close();
            canvas.drawPath(area, fill);
            canvas.drawPath(profile, line);

            label.setColor(subTextColor);
            for (int i = 0; i <= 4; i++) {
                double value = maxY - spanY * i / 4.0;
                float y = top + (bottom - top) * i / 4f;
                canvas.drawText(String.format(Locale.US, "%.0f", value), dp(4), y + dp(4), label);
            }
            for (int i = 0; i <= 4; i++) {
                double value = maxX * i / 4.0;
                float x = left + (right - left) * i / 4f;
                String txt = maxX >= 1000 ? String.format(Locale.US, "%.1f km", value / 1000.0)
                        : String.format(Locale.US, "%.0f m", value);
                canvas.drawText(txt, x - dp(10), getHeight() - dp(10), label);
            }
        }
    }

    private static final class Metric {
        final LinearLayout root;
        final TextView value;
        Metric(LinearLayout root, TextView value) {
            this.root = root;
            this.value = value;
        }
    }
}
