package com.bph.geotopo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.GnssStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.maplibre.android.MapLibre;
import org.maplibre.android.annotations.Marker;
import org.maplibre.android.annotations.MarkerOptions;
import org.maplibre.android.camera.CameraPosition;
import org.maplibre.android.camera.CameraUpdateFactory;
import org.maplibre.android.geometry.LatLng;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapView;
import org.maplibre.android.maps.Style;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Centro único de GPS y mapas. Las acciones principales trabajan dentro de
 * esta pantalla para evitar saltos repetidos a la antigua pantalla GPS.
 */
public class GpsOverviewActivity extends Activity implements LocationListener {
    private static final String PREFS = "geo_topo_prefs";
    private static final String GPS_PREFS = "geo_topo_gps_points";
    private static final String KEY_POINTS = "points_json";
    private static final String KEY_MAP_MODE = "map_mode";
    private static final String KEY_OFFLINE_PATH = "offline_mbtiles_path";
    private static final int REQ_LOCATION = 9410;
    private static final long RECENT_MAP_LOCATION_MS = 10L * 60L * 1000L;
    private static final long FRESH_SAVE_LOCATION_MS = 45L * 1000L;
    private static final String OFM_BRIGHT = "https://tiles.openfreemap.org/styles/bright";
    private static final String OFM_DARK = "https://tiles.openfreemap.org/styles/dark";
    private static final String OFM_FIORD = "https://tiles.openfreemap.org/styles/fiord";
    private static final double OVERVIEW_CONTEXT_ZOOM = 15.0;

    private MapView overviewMapView;
    private MapLibreMap overviewMap;
    private Marker overviewMarker;
    private Bundle mapSavedState;
    private final MbtilesServer offlineServer = new MbtilesServer();
    private String currentMapMode = "standard";
    private boolean overviewStyleInitialized;

    private LocationManager locationManager;
    private Location currentLocation;
    private boolean gpsRunning;
    private boolean averaging;
    private boolean startAverageAfterPermission;
    private int satellitesVisible;
    private int satellitesUsed;
    private GnssStatus.Callback gnssCallback;
    private boolean gnssRegistered;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<Location> averageSamples = new ArrayList<>();

    private LastPosition overviewPosition;
    private TextView mapModePill;
    private TextView mapHintView;
    private TextView qualityValue;
    private TextView precisionValue;
    private TextView satellitesValue;
    private TextView timeValue;
    private TextView readingStateValue;
    private TextView latValue;
    private TextView lonValue;
    private TextView eastValue;
    private TextView northValue;
    private TextView altitudeValue;
    private TextView readingPrecisionValue;
    private TextView zoneValue;
    private TextView gpsActionLabel;
    private TextView averageActionLabel;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MapLibre.getInstance(this);
        mapSavedState = savedInstanceState;
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        currentMapMode = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_MAP_MODE, "standard");
        NativeUi.styleWindow(this);
        setContentView(buildScreen());
    }

    @Override protected void onStart() {
        super.onStart();
        if (overviewMapView != null) overviewMapView.onStart();
    }

    @Override protected void onResume() {
        super.onResume();
        if (overviewMapView != null) overviewMapView.onResume();
        LastPosition latest = readLastPosition();
        if (latest.valid) {
            overviewPosition = latest;
            updateOverviewData(latest);
            if (overviewMap != null && isRecent(latest)) centerOverviewMap(false);
        }
    }

    @Override protected void onPause() {
        stopLocationUpdates(false);
        if (overviewMapView != null) overviewMapView.onPause();
        super.onPause();
    }

    @Override protected void onStop() {
        if (overviewMapView != null) overviewMapView.onStop();
        super.onStop();
    }

    @Override public void onLowMemory() {
        super.onLowMemory();
        if (overviewMapView != null) overviewMapView.onLowMemory();
    }

    @Override protected void onDestroy() {
        stopLocationUpdates(false);
        offlineServer.stop();
        handler.removeCallbacksAndMessages(null);
        if (overviewMapView != null) overviewMapView.onDestroy();
        super.onDestroy();
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (overviewMapView != null) overviewMapView.onSaveInstanceState(outState);
    }

    private View buildScreen() {
        FrameLayout root = NativeUi.screen(this);
        LinearLayout page = NativeUi.column(this);
        page.addView(NativeUi.pageHeader(this, "GPS y mapas",
                "Ubicación, puntos y mapas", v -> finish(), "⌖",
                v -> openFullMap()));

        LinearLayout content = NativeUi.column(this);
        content.setPadding(NativeUi.dp(this, 12), NativeUi.dp(this, 9),
                NativeUi.dp(this, 12), NativeUi.dp(this, 24));

        overviewPosition = readLastPosition();

        View mapCard = buildFunctionalMapCard();
        LinearLayout.LayoutParams mapLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 228));
        mapLp.setMargins(0, 0, 0, NativeUi.dp(this, 9));
        content.addView(mapCard, mapLp);

        content.addView(buildStatusPanel(overviewPosition));
        content.addView(buildPrimaryActions());
        content.addView(buildReadingPanel(overviewPosition));
        content.addView(buildSecondaryActions());

        content.addView(NativeUi.sectionHeader(this, "◷", "PUNTOS RECIENTES", "Ver todos",
                v -> showPointsPanel()));
        content.addView(recentPointsCard());

        page.addView(NativeUi.scroll(this, content), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(page, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return root;
    }

    private View buildFunctionalMapCard() {
        FrameLayout card = new FrameLayout(this);
        card.setBackground(NativeUi.gradient(Color.rgb(5, 34, 69), Color.rgb(2, 18, 37), 18,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 160), this));
        card.setClipToOutline(true);
        card.setElevation(NativeUi.dp(this, 2));

        overviewMapView = new MapView(this);
        overviewMapView.onCreate(mapSavedState);
        card.addView(overviewMapView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        overviewMapView.getMapAsync(mapLibreMap -> {
            overviewMap = mapLibreMap;
            overviewMap.getUiSettings().setLogoEnabled(false);
            overviewMap.getUiSettings().setAttributionEnabled(true);
            overviewMap.getUiSettings().setCompassEnabled(false);
            overviewMap.setMinZoomPreference(1.0);
            overviewMap.setMaxZoomPreference(20.0);
            applyOverviewMapMode(currentMapMode);
        });

        mapModePill = NativeUi.text(this, mapModeLabel(currentMapMode), 11.5f, true, NativeUi.TEXT);
        mapModePill.setGravity(Gravity.CENTER);
        mapModePill.setBackground(NativeUi.rounded(NativeUi.withAlpha(NativeUi.BG_DEEP, 230), 14, 1,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 145), this));
        mapModePill.setOnClickListener(v -> showOverviewLayers());
        FrameLayout.LayoutParams mlp = new FrameLayout.LayoutParams(
                NativeUi.dp(this, 106), NativeUi.dp(this, 34), Gravity.START | Gravity.TOP);
        mlp.setMargins(NativeUi.dp(this, 10), NativeUi.dp(this, 10), 0, 0);
        card.addView(mapModePill, mlp);

        LinearLayout controls = NativeUi.column(this);
        controls.setGravity(Gravity.CENTER);
        controls.addView(mapControl("▱", "Capas", v -> showOverviewLayers()));
        controls.addView(mapControl("N", "Norte arriba", v -> resetOverviewBearing()));
        controls.addView(mapControl("⌖", "Centrar", v -> centerOrStartGps()));
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(
                NativeUi.dp(this, 42), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END | Gravity.CENTER_VERTICAL);
        clp.setMargins(0, 0, NativeUi.dp(this, 9), 0);
        card.addView(controls, clp);

        mapHintView = NativeUi.text(this, "", 10.8f, true, Color.WHITE);
        mapHintView.setGravity(Gravity.CENTER);
        mapHintView.setPadding(NativeUi.dp(this, 8), NativeUi.dp(this, 4), NativeUi.dp(this, 8), NativeUi.dp(this, 4));
        mapHintView.setBackground(NativeUi.rounded(NativeUi.withAlpha(NativeUi.BG_DEEP, 220), 12, 0,
                Color.TRANSPARENT, this));
        FrameLayout.LayoutParams hlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, NativeUi.dp(this, 30), Gravity.START | Gravity.BOTTOM);
        hlp.setMargins(NativeUi.dp(this, 10), 0, NativeUi.dp(this, 10), NativeUi.dp(this, 10));
        card.addView(mapHintView, hlp);

        TextView open = NativeUi.text(this, "Mapa completo  ›", 12.2f, true, Color.WHITE);
        open.setGravity(Gravity.CENTER);
        open.setBackground(NativeUi.gradient(Color.rgb(46, 133, 255), Color.rgb(23, 83, 211), 13,
                NativeUi.withAlpha(Color.WHITE, 55), this));
        open.setOnClickListener(v -> openFullMap());
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(
                NativeUi.dp(this, 136), NativeUi.dp(this, 36), Gravity.END | Gravity.BOTTOM);
        blp.setMargins(0, 0, NativeUi.dp(this, 10), NativeUi.dp(this, 10));
        card.addView(open, blp);
        return card;
    }

    private void applyOverviewMapMode(String mode) {
        if (overviewMap == null) return;
        if (mode == null || mode.trim().isEmpty()) mode = "standard";
        currentMapMode = mode;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_MAP_MODE, currentMapMode).apply();
        final CameraPosition preservedCamera = overviewStyleInitialized ? overviewMap.getCameraPosition() : null;
        if (!"offline".equals(mode)) offlineServer.stop();

        if (mapModePill != null) mapModePill.setText(mapModeLabel(mode));

        if ("dark".equals(mode)) {
            overviewMap.setStyle(new Style.Builder().fromUri(OFM_DARK), style -> onOverviewStyleReady(preservedCamera));
            return;
        }
        if ("topo".equals(mode)) {
            overviewMap.setStyle(new Style.Builder().fromUri(OFM_FIORD), style -> onOverviewStyleReady(preservedCamera));
            return;
        }
        if ("satellite".equals(mode)) {
            overviewMap.setStyle(new Style.Builder().fromJson(satelliteStyleJson()), style -> onOverviewStyleReady(preservedCamera));
            return;
        }
        if ("offline".equals(mode)) {
            if (applyOverviewOfflineStyle(preservedCamera)) return;
            currentMapMode = "standard";
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_MAP_MODE, currentMapMode).apply();
            if (mapModePill != null) mapModePill.setText("Calles");
            Toast.makeText(this, "No hay un paquete MBTiles cargado. Se mostrará Calles.", Toast.LENGTH_LONG).show();
        }
        overviewMap.setStyle(new Style.Builder().fromUri(OFM_BRIGHT), style -> onOverviewStyleReady(preservedCamera));
    }

    private void onOverviewStyleReady(CameraPosition preservedCamera) {
        if (preservedCamera != null) {
            overviewStyleInitialized = true;
            overviewMap.moveCamera(CameraUpdateFactory.newCameraPosition(preservedCamera));
            if (overviewPosition != null && isRecent(overviewPosition)) {
                drawOverviewMarker(overviewPosition.latitude, overviewPosition.longitude);
            }
            return;
        }
        overviewStyleInitialized = true;
        centerOverviewMap(false);
    }

    private boolean applyOverviewOfflineStyle(CameraPosition preservedCamera) {
        String path = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_OFFLINE_PATH, "");
        if (path == null || path.trim().isEmpty()) return false;
        File file = new File(path);
        if (!file.isFile()) return false;
        try {
            offlineServer.start(file);
            String url = "http://127.0.0.1:" + offlineServer.getPort() + "/tiles/{z}/{x}/{y}." + offlineServer.getFormat();
            String attribution = escapeJson(offlineServer.getAttribution());
            String style = "{\"version\":8,\"sources\":{\"offline\":{\"type\":\"raster\",\"tiles\":[\"" + url
                    + "\"],\"tileSize\":256,\"minzoom\":" + offlineServer.getMinZoom() + ",\"maxzoom\":" + offlineServer.getMaxZoom()
                    + ",\"attribution\":\"" + attribution + "\"}},\"layers\":[{\"id\":\"background\",\"type\":\"background\",\"paint\":{\"background-color\":\"#e8edf1\"}},{\"id\":\"offline\",\"type\":\"raster\",\"source\":\"offline\",\"paint\":{\"raster-fade-duration\":0}}]}";
            overviewMap.setStyle(new Style.Builder().fromJson(style), loaded -> onOverviewStyleReady(preservedCamera));
            return true;
        } catch (Exception e) {
            offlineServer.stop();
            return false;
        }
    }

    private String satelliteStyleJson() {
        return "{\"version\":8,\"sources\":{"
                + "\"imagery\":{\"type\":\"raster\",\"tiles\":[\"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}\"],\"tileSize\":256,\"maxzoom\":19,\"attribution\":\"Powered by Esri · Esri, Maxar, Earthstar Geographics and the GIS User Community\"},"
                + "\"roads\":{\"type\":\"raster\",\"tiles\":[\"https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Transportation/MapServer/tile/{z}/{y}/{x}\"],\"tileSize\":256,\"maxzoom\":19},"
                + "\"labels\":{\"type\":\"raster\",\"tiles\":[\"https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}\"],\"tileSize\":256,\"maxzoom\":19}"
                + "},\"layers\":["
                + "{\"id\":\"imagery\",\"type\":\"raster\",\"source\":\"imagery\",\"paint\":{\"raster-fade-duration\":80}},"
                + "{\"id\":\"roads\",\"type\":\"raster\",\"source\":\"roads\",\"paint\":{\"raster-fade-duration\":0}},"
                + "{\"id\":\"labels\",\"type\":\"raster\",\"source\":\"labels\",\"paint\":{\"raster-fade-duration\":0}}]}";
    }

    private String escapeJson(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", " ");
    }

    private String mapModeLabel(String mode) {
        if ("dark".equals(mode)) return "Oscuro";
        if ("satellite".equals(mode)) return "Satélite";
        if ("topo".equals(mode)) return "Topográfico";
        if ("offline".equals(mode)) return "Offline";
        return "Calles";
    }

    private void showOverviewLayers() {
        String[] items = {"Calles", "Oscuro", "Satélite", "Topográfico", "Offline MBTiles"};
        int checked = 0;
        if ("dark".equals(currentMapMode)) checked = 1;
        else if ("satellite".equals(currentMapMode)) checked = 2;
        else if ("topo".equals(currentMapMode)) checked = 3;
        else if ("offline".equals(currentMapMode)) checked = 4;
        new AlertDialog.Builder(this)
                .setTitle("Capas del mapa")
                .setSingleChoiceItems(items, checked, (d, which) -> {
                    d.dismiss();
                    if (which == 0) applyOverviewMapMode("standard");
                    else if (which == 1) applyOverviewMapMode("dark");
                    else if (which == 2) applyOverviewMapMode("satellite");
                    else if (which == 3) applyOverviewMapMode("topo");
                    else applyOverviewMapMode("offline");
                })
                .setNeutralButton("Gestionar offline", (d, w) -> startActivity(new Intent(this, OfflineMapActivity.class)))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void centerOverviewMap(boolean animate) {
        if (overviewMap == null) return;
        Location live = currentLocation;
        if (live != null && System.currentTimeMillis() - live.getTime() <= RECENT_MAP_LOCATION_MS) {
            moveOverviewCamera(live.getLatitude(), live.getLongitude(), OVERVIEW_CONTEXT_ZOOM, animate);
            drawOverviewMarker(live.getLatitude(), live.getLongitude());
            setMapHint("Posición actual · ±" + format1(live.hasAccuracy() ? live.getAccuracy() : 0f) + " m");
            return;
        }
        if (overviewPosition != null && isRecent(overviewPosition)) {
            moveOverviewCamera(overviewPosition.latitude, overviewPosition.longitude, OVERVIEW_CONTEXT_ZOOM, animate);
            drawOverviewMarker(overviewPosition.latitude, overviewPosition.longitude);
            setMapHint("Última lectura reciente");
            return;
        }
        if (overviewMarker != null) {
            try { overviewMap.removeMarker(overviewMarker); } catch (Exception ignored) { }
            overviewMarker = null;
        }
        moveOverviewCamera(0.0, 0.0, 1.35, animate);
        setMapHint("Ubicación aún no disponible");
    }

    private void moveOverviewCamera(double lat, double lon, double zoom, boolean animate) {
        CameraPosition camera = new CameraPosition.Builder().target(new LatLng(lat, lon)).zoom(zoom).bearing(0).tilt(0).build();
        if (animate) overviewMap.animateCamera(CameraUpdateFactory.newCameraPosition(camera), 420);
        else overviewMap.moveCamera(CameraUpdateFactory.newCameraPosition(camera));
    }

    private void drawOverviewMarker(double lat, double lon) {
        if (overviewMap == null) return;
        if (overviewMarker != null) {
            try { overviewMap.removeMarker(overviewMarker); } catch (Exception ignored) { }
        }
        overviewMarker = overviewMap.addMarker(new MarkerOptions().position(new LatLng(lat, lon)).title("Posición actual"));
    }

    private void setMapHint(String text) {
        if (mapHintView != null) mapHintView.setText(text == null ? "" : text);
    }

    private void resetOverviewBearing() {
        if (overviewMap == null) return;
        CameraPosition current = overviewMap.getCameraPosition();
        CameraPosition next = new CameraPosition.Builder(current).bearing(0).tilt(0).build();
        overviewMap.animateCamera(CameraUpdateFactory.newCameraPosition(next), 260);
    }

    private void centerOrStartGps() {
        if (currentLocation != null && System.currentTimeMillis() - currentLocation.getTime() <= RECENT_MAP_LOCATION_MS) {
            centerOverviewMap(true);
        } else {
            startGps();
        }
    }

    private View mapControl(String glyph, String description, View.OnClickListener click) {
        TextView b = NativeUi.text(this, glyph, 16.5f, true, Color.WHITE);
        b.setGravity(Gravity.CENTER);
        b.setContentDescription(description);
        b.setBackground(NativeUi.rounded(NativeUi.withAlpha(NativeUi.BG_DEEP, 235), 18, 1,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 130), this));
        b.setOnClickListener(click);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                NativeUi.dp(this, 38), NativeUi.dp(this, 38));
        lp.setMargins(0, NativeUi.dp(this, 2), 0, NativeUi.dp(this, 2));
        b.setLayoutParams(lp);
        return b;
    }

    private View buildStatusPanel(LastPosition p) {
        LinearLayout panel = NativeUi.row(this);
        panel.setPadding(NativeUi.dp(this, 5), NativeUi.dp(this, 5),
                NativeUi.dp(this, 5), NativeUi.dp(this, 5));
        panel.setBackground(NativeUi.gradient(NativeUi.CARD_LIGHT, NativeUi.CARD_DARK, 15,
                NativeUi.withAlpha(NativeUi.BORDER, 130), this));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 72));
        plp.setMargins(0, 0, 0, NativeUi.dp(this, 9));
        panel.setLayoutParams(plp);

        qualityValue = metric(panel, "Calidad", qualityLabel(p), qualityColor(p));
        precisionValue = metric(panel, "Precisión", p.valid ? "±" + format1(p.accuracy) + " m" : "—", NativeUi.BLUE_LIGHT);
        satellitesValue = metric(panel, "Satélites", p.valid ? p.satellitesUsed + " / " + p.satellitesVisible : "0 / 0", Color.rgb(170, 122, 255));
        timeValue = metric(panel, "Hora", p.valid ? formatTime(p.timestamp) : "—", Color.rgb(255, 198, 82));
        return panel;
    }

    private TextView metric(LinearLayout parent, String title, String value, int color) {
        LinearLayout box = NativeUi.column(this);
        box.setGravity(Gravity.CENTER);
        box.setPadding(NativeUi.dp(this, 5), NativeUi.dp(this, 6), NativeUi.dp(this, 5), NativeUi.dp(this, 6));
        box.setBackground(NativeUi.rounded(NativeUi.withAlpha(NativeUi.BG_DEEP, 120), 12, 1,
                NativeUi.withAlpha(NativeUi.BORDER, 85), this));
        TextView t = NativeUi.text(this, title, 10.2f, false, NativeUi.SUB);
        t.setGravity(Gravity.CENTER);
        TextView v = NativeUi.text(this, value, 12.2f, true, color);
        v.setGravity(Gravity.CENTER);
        v.setMaxLines(2);
        box.addView(t);
        box.addView(v);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lp.setMargins(NativeUi.dp(this, 2), NativeUi.dp(this, 2), NativeUi.dp(this, 2), NativeUi.dp(this, 2));
        parent.addView(box, lp);
        return v;
    }

    private View buildPrimaryActions() {
        LinearLayout row = NativeUi.row(this);
        View gpsCard = actionCard("play", "Iniciar\nGPS", v -> startOrStopGps());
        gpsActionLabel = (TextView) gpsCard.getTag();
        row.addView(gpsCard, actionLp(false, true));
        View avgCard = actionCard("clock", "Promediar\n20 s", v -> startAveraging());
        averageActionLabel = (TextView) avgCard.getTag();
        row.addView(avgCard, actionLp(true, true));
        row.addView(actionCard("pin", "Guardar\npunto", v -> showSavePointDialog()), actionLp(true, false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 88));
        lp.setMargins(0, 0, 0, NativeUi.dp(this, 9));
        row.setLayoutParams(lp);
        return row;
    }

    private View buildReadingPanel(LastPosition p) {
        LinearLayout panel = NativeUi.column(this);
        panel.setPadding(NativeUi.dp(this, 14), NativeUi.dp(this, 13), NativeUi.dp(this, 14), NativeUi.dp(this, 13));
        panel.setBackground(NativeUi.gradient(NativeUi.CARD_LIGHT, NativeUi.CARD_DARK, 18,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 135), this));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        plp.setMargins(0, 0, 0, NativeUi.dp(this, 12));
        panel.setLayoutParams(plp);

        LinearLayout head = NativeUi.row(this);
        TextView title = NativeUi.text(this, "⌁  LECTURA ACTUAL", 15.5f, true, NativeUi.TEXT);
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        readingStateValue = NativeUi.text(this, p.valid ? "●  " + relativeTime(p.timestamp) : "Sin lectura", 11.5f, true,
                p.valid ? Color.rgb(53, 220, 145) : NativeUi.SUB);
        head.addView(readingStateValue);
        panel.addView(head);

        CoordinateUtils.Utm utm = p.valid ? CoordinateUtils.toUtm(p.latitude, p.longitude) : null;
        LinearLayout row1 = NativeUi.row(this);
        latValue = readingCell(row1, "Latitud", p.valid ? format6(p.latitude) + "°" : "Sin lectura", true);
        lonValue = readingCell(row1, "Longitud", p.valid ? format6(p.longitude) + "°" : "Sin lectura", false);
        panel.addView(row1);

        LinearLayout row2 = NativeUi.row(this);
        eastValue = readingCell(row2, "Este UTM", utm != null && utm.valid ? format3(utm.easting) + " m" : "Sin lectura", true);
        northValue = readingCell(row2, "Norte UTM", utm != null && utm.valid ? format3(utm.northing) + " m" : "Sin lectura", false);
        panel.addView(row2);

        LinearLayout row3 = NativeUi.row(this);
        altitudeValue = readingCell(row3, "Altitud GNSS", !Float.isNaN(p.altitudeM) ? format1(p.altitudeM) + " m" : "No disponible", true);
        readingPrecisionValue = readingCell(row3, "Precisión", p.valid ? "±" + format1(p.accuracy) + " m" : "Sin lectura", false);
        panel.addView(row3);

        LinearLayout row4 = NativeUi.row(this);
        zoneValue = readingCell(row4, "Zona UTM", utm != null && utm.valid ? utm.zone + utm.hemisphere() : "Sin lectura", true);
        readingCell(row4, "Datum", "WGS84 / UTM", false);
        panel.addView(row4);
        return panel;
    }

    private TextView readingCell(LinearLayout row, String title, String value, boolean left) {
        LinearLayout box = NativeUi.column(this);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(NativeUi.dp(this, 9), NativeUi.dp(this, 6), NativeUi.dp(this, 7), NativeUi.dp(this, 6));
        box.setBackground(NativeUi.rounded(NativeUi.withAlpha(NativeUi.BG_DEEP, 125), 10, 1,
                NativeUi.withAlpha(NativeUi.BORDER, 85), this));
        TextView t = NativeUi.text(this, title, 9.5f, false, NativeUi.SUB);
        TextView v = NativeUi.text(this, value, 12.1f, true, NativeUi.TEXT);
        v.setPadding(0, NativeUi.dp(this, 2), 0, 0);
        v.setSingleLine(true);
        box.addView(t);
        box.addView(v);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, NativeUi.dp(this, 58), 1f);
        lp.setMargins(left ? 0 : NativeUi.dp(this, 4), NativeUi.dp(this, 4), left ? NativeUi.dp(this, 4) : 0, 0);
        row.addView(box, lp);
        return v;
    }

    private View buildSecondaryActions() {
        LinearLayout row = NativeUi.row(this);
        row.setBaselineAligned(false);
        row.addView(actionCard("bookmark", "Puntos", v -> showPointsPanel()), actionLp(false, true));
        row.addView(actionCard("satellite", "Datos GNSS", v -> showGnssPanel()), actionLp(true, true));
        row.addView(actionCard("file", "Exportar", v -> showExportPanel()), actionLp(true, false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 76));
        lp.setMargins(0, 0, 0, NativeUi.dp(this, 7));
        row.setLayoutParams(lp);
        return row;
    }

    private LinearLayout.LayoutParams actionLp(boolean leftMargin, boolean rightMargin) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lp.setMargins(leftMargin ? NativeUi.dp(this, 4) : 0, 0,
                rightMargin ? NativeUi.dp(this, 4) : 0, 0);
        return lp;
    }

    private View actionCard(String icon, String label, View.OnClickListener click) {
        LinearLayout box = NativeUi.column(this);
        box.setPadding(NativeUi.dp(this, 6), NativeUi.dp(this, 7), NativeUi.dp(this, 6), NativeUi.dp(this, 6));
        box.setGravity(Gravity.CENTER);
        box.setBackground(NativeUi.gradient(NativeUi.CARD_LIGHT, NativeUi.CARD_DARK, 13,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 110), this));
        box.setOnClickListener(click);
        FrameLayout iconBox = NativeUi.iconTile(this, icon, 31);
        box.addView(iconBox, new LinearLayout.LayoutParams(NativeUi.dp(this, 31), NativeUi.dp(this, 31)));
        TextView title = NativeUi.text(this, label, 10.6f, true, NativeUi.TEXT);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, NativeUi.dp(this, 4), 0, 0);
        title.setMaxLines(2);
        box.addView(title);
        box.setTag(title);
        return box;
    }

    private View recentPointsCard() {
        LinearLayout card = NativeUi.column(this);
        card.setBackground(NativeUi.gradient(NativeUi.CARD_LIGHT, NativeUi.CARD_DARK, 18,
                NativeUi.withAlpha(NativeUi.BORDER, 165), this));
        List<PointRow> points = readRecentPoints(3);
        if (points.isEmpty()) {
            TextView empty = NativeUi.text(this,
                    "Todavía no hay puntos guardados. Usa Guardar punto para registrar el primero.",
                    13.2f, false, NativeUi.SUB);
            empty.setPadding(NativeUi.dp(this, 16), NativeUi.dp(this, 18),
                    NativeUi.dp(this, 16), NativeUi.dp(this, 18));
            card.addView(empty);
            return card;
        }
        for (int i = 0; i < points.size(); i++) {
            PointRow point = points.get(i);
            card.addView(recentRow(point));
            if (i < points.size() - 1) {
                View divider = new View(this);
                divider.setBackgroundColor(NativeUi.withAlpha(NativeUi.BORDER, 80));
                card.addView(divider, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 1)));
            }
        }
        return card;
    }

    private View recentRow(PointRow point) {
        LinearLayout row = NativeUi.row(this);
        row.setPadding(NativeUi.dp(this, 12), NativeUi.dp(this, 13),
                NativeUi.dp(this, 10), NativeUi.dp(this, 13));
        row.setOnClickListener(v -> openPointOnMap(point));
        NativeUi.IconGlyphView icon = new NativeUi.IconGlyphView(this, "pin");
        row.addView(icon, new LinearLayout.LayoutParams(NativeUi.dp(this, 38), NativeUi.dp(this, 38)));
        LinearLayout labels = NativeUi.column(this);
        labels.setPadding(NativeUi.dp(this, 9), 0, NativeUi.dp(this, 5), 0);
        labels.addView(NativeUi.text(this, point.name, 14.5f, true, NativeUi.TEXT));
        TextView sub = NativeUi.text(this, point.summary, 11.2f, false, NativeUi.SUB);
        sub.setSingleLine(true);
        labels.addView(sub);
        row.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView time = NativeUi.text(this, point.time + "  ›", 11.5f, false, NativeUi.SUB);
        row.addView(time);
        return row;
    }

    private void startOrStopGps() {
        if (gpsRunning) {
            stopLocationUpdates(true);
        } else {
            startGps();
        }
    }

    private void startGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
            return;
        }
        if (locationManager == null) {
            Toast.makeText(this, "Servicio de ubicación no disponible.", Toast.LENGTH_LONG).show();
            return;
        }
        boolean gpsEnabled = false;
        try { gpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER); } catch (Exception ignored) { }
        if (!gpsEnabled) {
            new AlertDialog.Builder(this)
                    .setTitle("Activar ubicación")
                    .setMessage("Activa la ubicación del teléfono para obtener una lectura GPS/GNSS.")
                    .setPositiveButton("Abrir ajustes", (d, w) -> startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)))
                    .setNegativeButton("Cancelar", null)
                    .show();
            return;
        }
        try {
            locationManager.removeUpdates(this);
            currentLocation = null;
            gpsRunning = true;
            updateActionLabels();
            setMapHint("Buscando señal GPS…");
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this);
            try {
                if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                    locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1400L, 0f, this);
            } catch (Exception ignored) { }
            registerGnssStatus();
        } catch (SecurityException e) {
            gpsRunning = false;
            updateActionLabels();
            Toast.makeText(this, "Permite ubicación precisa para usar el GPS.", Toast.LENGTH_LONG).show();
        }
    }

    private void stopLocationUpdates(boolean showMessage) {
        if (locationManager != null) {
            try { locationManager.removeUpdates(this); } catch (Exception ignored) { }
        }
        unregisterGnssStatus();
        gpsRunning = false;
        if (averaging) {
            averaging = false;
            averageSamples.clear();
        }
        updateActionLabels();
        if (showMessage) Toast.makeText(this, "GPS detenido.", Toast.LENGTH_SHORT).show();
    }

    private void startAveraging() {
        if (averaging) {
            averaging = false;
            averageSamples.clear();
            updateActionLabels();
            Toast.makeText(this, "Promedio cancelado.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            startAverageAfterPermission = true;
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
            return;
        }
        if (!gpsRunning) {
            startGps();
            if (!gpsRunning) return;
        }
        averaging = true;
        averageSamples.clear();
        updateActionLabels();
        setMapHint("Promediando 20 s…");
        handler.postDelayed(this::finishAveraging, 20000L);
    }

    private void finishAveraging() {
        if (!averaging) return;
        averaging = false;
        updateActionLabels();
        if (averageSamples.isEmpty()) {
            Toast.makeText(this, "No hubo lecturas válidas durante el promedio.", Toast.LENGTH_LONG).show();
            setMapHint("Sin promedio válido");
            return;
        }
        double lat = 0, lon = 0, alt = 0;
        float acc = 0;
        int altCount = 0;
        for (Location l : averageSamples) {
            lat += l.getLatitude();
            lon += l.getLongitude();
            acc += l.hasAccuracy() ? l.getAccuracy() : 0f;
            if (l.hasAltitude()) { alt += l.getAltitude(); altCount++; }
        }
        int n = averageSamples.size();
        Location avg = new Location("promedio_gnss");
        avg.setLatitude(lat / n);
        avg.setLongitude(lon / n);
        avg.setAccuracy(acc / n);
        if (altCount > 0) avg.setAltitude(alt / altCount);
        avg.setTime(System.currentTimeMillis());
        currentLocation = avg;
        saveLastLocation(avg);
        overviewPosition = fromLocation(avg);
        updateOverviewData(overviewPosition);
        centerOverviewMap(true);
        Toast.makeText(this, "Promedio terminado con " + n + " lecturas.", Toast.LENGTH_LONG).show();
        averageSamples.clear();
    }

    private void updateActionLabels() {
        if (gpsActionLabel != null) gpsActionLabel.setText(gpsRunning ? "Detener\nGPS" : "Iniciar\nGPS");
        if (averageActionLabel != null) averageActionLabel.setText(averaging ? "Cancelar\npromedio" : "Promediar\n20 s");
    }

    @Override public void onLocationChanged(Location location) {
        if (location == null || !location.hasAccuracy()) return;
        if (currentLocation == null || isBetterLocation(location, currentLocation)) currentLocation = new Location(location);
        if (averaging) averageSamples.add(new Location(location));
        saveLastLocation(currentLocation);
        overviewPosition = fromLocation(currentLocation);
        updateOverviewData(overviewPosition);
        centerOverviewMap(false);
    }

    private boolean isBetterLocation(Location candidate, Location current) {
        if (current == null) return true;
        long dt = candidate.getTime() - current.getTime();
        if (dt > 15000L) return true;
        float ca = candidate.hasAccuracy() ? candidate.getAccuracy() : 9999f;
        float oa = current.hasAccuracy() ? current.getAccuracy() : 9999f;
        return ca <= oa + 4f || dt > 3000L;
    }

    private void registerGnssStatus() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N || locationManager == null || gnssRegistered) return;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        if (gnssCallback == null) {
            gnssCallback = new GnssStatus.Callback() {
                @Override public void onSatelliteStatusChanged(GnssStatus status) {
                    satellitesVisible = status.getSatelliteCount();
                    int used = 0;
                    for (int i = 0; i < status.getSatelliteCount(); i++) if (status.usedInFix(i)) used++;
                    satellitesUsed = used;
                    getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit()
                            .putInt("last_satellites_visible", satellitesVisible)
                            .putInt("last_satellites_used", satellitesUsed)
                            .apply();
                    if (satellitesValue != null) satellitesValue.setText(satellitesUsed + " / " + satellitesVisible);
                }
            };
        }
        try {
            locationManager.registerGnssStatusCallback(gnssCallback, handler);
            gnssRegistered = true;
        } catch (Exception ignored) { }
    }

    private void unregisterGnssStatus() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N || locationManager == null || !gnssRegistered || gnssCallback == null) return;
        try { locationManager.unregisterGnssStatusCallback(gnssCallback); } catch (Exception ignored) { }
        gnssRegistered = false;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_LOCATION) return;
        boolean precise = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if (!precise) {
            startAverageAfterPermission = false;
            Toast.makeText(this, "Para GPS/GNSS selecciona ubicación precisa.", Toast.LENGTH_LONG).show();
            return;
        }
        startGps();
        if (startAverageAfterPermission) {
            startAverageAfterPermission = false;
            handler.postDelayed(this::startAveraging, 450L);
        }
    }

    private void updateOverviewData(LastPosition p) {
        if (p == null) p = new LastPosition();
        if (qualityValue != null) {
            qualityValue.setText(qualityLabel(p));
            qualityValue.setTextColor(qualityColor(p));
        }
        if (precisionValue != null) precisionValue.setText(p.valid ? "±" + format1(p.accuracy) + " m" : "—");
        if (satellitesValue != null) satellitesValue.setText(p.valid ? p.satellitesUsed + " / " + p.satellitesVisible : "0 / 0");
        if (timeValue != null) timeValue.setText(p.valid ? formatTime(p.timestamp) : "—");
        if (readingStateValue != null) readingStateValue.setText(p.valid ? "●  " + relativeTime(p.timestamp) : "Sin lectura");
        if (latValue != null) latValue.setText(p.valid ? format6(p.latitude) + "°" : "Sin lectura");
        if (lonValue != null) lonValue.setText(p.valid ? format6(p.longitude) + "°" : "Sin lectura");
        CoordinateUtils.Utm utm = p.valid ? CoordinateUtils.toUtm(p.latitude, p.longitude) : null;
        if (eastValue != null) eastValue.setText(utm != null && utm.valid ? format3(utm.easting) + " m" : "Sin lectura");
        if (northValue != null) northValue.setText(utm != null && utm.valid ? format3(utm.northing) + " m" : "Sin lectura");
        if (altitudeValue != null) altitudeValue.setText(!Float.isNaN(p.altitudeM) ? format1(p.altitudeM) + " m" : "No disponible");
        if (readingPrecisionValue != null) readingPrecisionValue.setText(p.valid ? "±" + format1(p.accuracy) + " m" : "Sin lectura");
        if (zoneValue != null) zoneValue.setText(utm != null && utm.valid ? utm.zone + utm.hemisphere() : "Sin lectura");
    }

    private void saveLastLocation(Location location) {
        if (location == null) return;
        SharedPreferences.Editor e = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit()
                .putString("last_latitude", Double.toString(location.getLatitude()))
                .putString("last_longitude", Double.toString(location.getLongitude()))
                .putFloat("last_accuracy", location.hasAccuracy() ? location.getAccuracy() : 0f)
                .putFloat("last_speed_mps", location.hasSpeed() ? location.getSpeed() : -1f)
                .putFloat("last_altitude_m", location.hasAltitude() ? (float) location.getAltitude() : Float.NaN)
                .putString("last_provider", location.getProvider() == null ? "" : location.getProvider())
                .putLong("last_location_time", location.getTime() > 0 ? location.getTime() : System.currentTimeMillis())
                .putInt("last_satellites_visible", satellitesVisible)
                .putInt("last_satellites_used", satellitesUsed);
        e.apply();
    }

    private void showSavePointDialog() {
        Location loc = freshLocationForSave();
        if (loc == null) {
            Toast.makeText(this, "Primero inicia el GPS y espera una lectura reciente.", Toast.LENGTH_LONG).show();
            return;
        }
        if (loc.hasAccuracy() && loc.getAccuracy() > 50f) {
            Toast.makeText(this, "La precisión es demasiado baja (±" + format1(loc.getAccuracy()) + " m). Espera una lectura mejor.", Toast.LENGTH_LONG).show();
            return;
        }

        LinearLayout form = NativeUi.column(this);
        form.setPadding(NativeUi.dp(this, 18), NativeUi.dp(this, 8), NativeUi.dp(this, 18), 0);
        EditText project = new EditText(this);
        project.setHint("Proyecto");
        project.setSingleLine(true);
        project.setText(getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString("current_project", "Proyecto general"));
        EditText name = new EditText(this);
        name.setHint("Nombre del punto");
        name.setSingleLine(true);
        name.setText(nextPointName());
        EditText description = new EditText(this);
        description.setHint("Descripción opcional");
        form.addView(project);
        form.addView(name);
        form.addView(description);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Guardar punto")
                .setMessage("Se guardarán automáticamente coordenadas, UTM, precisión y hora de la lectura actual.")
                .setView(form)
                .setPositiveButton("Guardar", null)
                .setNegativeButton("Cancelar", null)
                .create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(b -> {
            String p = project.getText().toString().trim();
            if (p.isEmpty()) p = "Proyecto general";
            String n = name.getText().toString().trim();
            if (n.isEmpty()) n = nextPointName();
            getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit().putString("current_project", p).apply();
            persistPoint(p, n, description.getText().toString().trim(), loc);
            dialog.dismiss();
        }));
        dialog.show();
    }

    private Location freshLocationForSave() {
        if (currentLocation != null && System.currentTimeMillis() - currentLocation.getTime() <= FRESH_SAVE_LOCATION_MS)
            return new Location(currentLocation);
        LastPosition p = readLastPosition();
        if (!p.valid || System.currentTimeMillis() - p.timestamp > FRESH_SAVE_LOCATION_MS) return null;
        Location loc = new Location(p.provider == null || p.provider.isEmpty() ? "guardada" : p.provider);
        loc.setLatitude(p.latitude);
        loc.setLongitude(p.longitude);
        loc.setAccuracy((float) p.accuracy);
        if (!Float.isNaN(p.altitudeM)) loc.setAltitude(p.altitudeM);
        loc.setTime(p.timestamp);
        return loc;
    }

    private void persistPoint(String project, String name, String description, Location location) {
        try {
            String existing = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]");
            JSONArray array = new JSONArray(existing == null ? "[]" : existing);
            JSONObject o = new JSONObject();
            o.put("project", project);
            o.put("name", name);
            o.put("description", description == null ? "" : description);
            o.put("latitude", location.getLatitude());
            o.put("longitude", location.getLongitude());
            if (location.hasAltitude()) o.put("altitude", location.getAltitude()); else o.put("altitude", JSONObject.NULL);
            if (location.hasAccuracy()) o.put("accuracy", location.getAccuracy()); else o.put("accuracy", JSONObject.NULL);
            if (location.hasSpeed()) o.put("speedKmh", location.getSpeed() * 3.6); else o.put("speedKmh", JSONObject.NULL);
            if (location.hasBearing()) o.put("bearing", location.getBearing()); else o.put("bearing", JSONObject.NULL);
            o.put("timestamp", location.getTime() > 0 ? location.getTime() : System.currentTimeMillis());
            o.put("provider", location.getProvider() == null ? "" : location.getProvider());
            o.put("photoUri", "");
            array.put(o);
            getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit().putString(KEY_POINTS, array.toString()).apply();
            Toast.makeText(this, "Punto " + name + " guardado.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo guardar el punto.", Toast.LENGTH_LONG).show();
        }
    }

    private String nextPointName() {
        String json = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]");
        try {
            JSONArray a = new JSONArray(json == null ? "[]" : json);
            int n = 1;
            while (true) {
                String candidate = "P" + n;
                boolean exists = false;
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.optJSONObject(i);
                    if (o != null && candidate.equalsIgnoreCase(o.optString("name", ""))) { exists = true; break; }
                }
                if (!exists) return candidate;
                n++;
            }
        } catch (Exception ignored) { return "P1"; }
    }

    private void showPointsPanel() {
        List<PointRow> points = readRecentPoints(100);
        if (points.isEmpty()) {
            Toast.makeText(this, "Todavía no hay puntos guardados.", Toast.LENGTH_LONG).show();
            return;
        }
        LinearLayout list = NativeUi.column(this);
        list.setPadding(NativeUi.dp(this, 10), NativeUi.dp(this, 8), NativeUi.dp(this, 10), NativeUi.dp(this, 8));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Puntos guardados")
                .setNegativeButton("Cerrar", null)
                .create();
        for (PointRow point : points) {
            TextView row = NativeUi.text(this, point.name + "\n" + point.summary + "\n" + point.time, 12.5f, false, NativeUi.TEXT);
            row.setPadding(NativeUi.dp(this, 12), NativeUi.dp(this, 10), NativeUi.dp(this, 12), NativeUi.dp(this, 10));
            row.setBackground(NativeUi.rounded(NativeUi.withAlpha(NativeUi.BG_DEEP, 100), 12, 1,
                    NativeUi.withAlpha(NativeUi.BORDER, 80), this));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, NativeUi.dp(this, 7));
            list.addView(row, lp);
            row.setOnClickListener(v -> {
                dialog.dismiss();
                openPointOnMap(point);
            });
        }
        ScrollView scroll = new ScrollView(this);
        scroll.addView(list);
        dialog.setView(scroll);
        dialog.show();
    }

    private void showGnssPanel() {
        LastPosition p = readLastPosition();
        CoordinateUtils.Utm utm = p.valid ? CoordinateUtils.toUtm(p.latitude, p.longitude) : null;
        StringBuilder sb = new StringBuilder();
        sb.append("Estado: ").append(gpsRunning ? "GPS activo" : "GPS detenido").append("\n");
        sb.append("Calidad: ").append(qualityLabel(p)).append("\n");
        sb.append("Precisión: ").append(p.valid ? "±" + format1(p.accuracy) + " m" : "Sin lectura").append("\n");
        sb.append("Satélites usados / visibles: ").append(p.satellitesUsed).append(" / ").append(p.satellitesVisible).append("\n");
        sb.append("Proveedor: ").append(providerLabel(p.provider)).append("\n");
        sb.append("Velocidad: ").append(p.speedMps >= 0 ? format1(p.speedMps * 3.6) + " km/h" : "Sin dato").append("\n");
        sb.append("Altitud: ").append(!Float.isNaN(p.altitudeM) ? format1(p.altitudeM) + " m" : "Sin dato").append("\n");
        if (utm != null && utm.valid) sb.append("UTM: ").append(utm.zone).append(utm.hemisphere()).append(" · ").append(format3(utm.easting)).append(" E · ").append(format3(utm.northing)).append(" N\n");
        sb.append("Última lectura: ").append(p.valid ? relativeTime(p.timestamp) : "Sin lectura");
        new AlertDialog.Builder(this)
                .setTitle("Datos GNSS")
                .setMessage(sb.toString())
                .setPositiveButton("Cerrar", null)
                .show();
    }

    private void showExportPanel() {
        String[] items = {"Compartir coordenada actual", "CSV de puntos GPS", "KML de puntos GPS", "GeoJSON de puntos GPS"};
        new AlertDialog.Builder(this)
                .setTitle("Exportar")
                .setItems(items, (d, which) -> {
                    if (which == 0) shareLastCoordinates();
                    else if (which == 1) shareText("GeoTopo puntos.csv", buildGpsCsv(), "text/csv");
                    else if (which == 2) shareText("GeoTopo puntos.kml", buildGpsKml(), "application/vnd.google-earth.kml+xml");
                    else shareText("GeoTopo puntos.geojson", buildGpsGeoJson(), "application/geo+json");
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void shareText(String title, String text, String type) {
        if (text == null || text.trim().isEmpty()) {
            Toast.makeText(this, "No hay puntos para exportar.", Toast.LENGTH_LONG).show();
            return;
        }
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType(type == null ? "text/plain" : type);
        share.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(share, title));
    }

    private String buildGpsCsv() {
        JSONArray a = readPointArray();
        if (a.length() == 0) return "";
        StringBuilder sb = new StringBuilder("project,name,description,latitude,longitude,altitude,accuracy,timestamp,provider\n");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            sb.append(csv(o.optString("project", ""))).append(',')
                    .append(csv(o.optString("name", ""))).append(',')
                    .append(csv(o.optString("description", ""))).append(',')
                    .append(o.optDouble("latitude", 0)).append(',')
                    .append(o.optDouble("longitude", 0)).append(',')
                    .append(o.isNull("altitude") ? "" : o.optDouble("altitude")).append(',')
                    .append(o.isNull("accuracy") ? "" : o.optDouble("accuracy")).append(',')
                    .append(o.optLong("timestamp", 0)).append(',')
                    .append(csv(o.optString("provider", ""))).append('\n');
        }
        return sb.toString();
    }

    private String csv(String value) {
        String v = value == null ? "" : value.replace("\"", "\"\"");
        return "\"" + v + "\"";
    }

    private String buildGpsKml() {
        JSONArray a = readPointArray();
        if (a.length() == 0) return "";
        StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><kml xmlns=\"http://www.opengis.net/kml/2.2\"><Document>");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            sb.append("<Placemark><name>").append(xml(o.optString("name", "Punto"))).append("</name><description>")
                    .append(xml(o.optString("description", ""))).append("</description><Point><coordinates>")
                    .append(o.optDouble("longitude", 0)).append(',').append(o.optDouble("latitude", 0)).append(',')
                    .append(o.isNull("altitude") ? 0 : o.optDouble("altitude", 0)).append("</coordinates></Point></Placemark>");
        }
        return sb.append("</Document></kml>").toString();
    }

    private String xml(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    private String buildGpsGeoJson() {
        JSONArray points = readPointArray();
        if (points.length() == 0) return "";
        try {
            JSONObject root = new JSONObject();
            root.put("type", "FeatureCollection");
            JSONArray features = new JSONArray();
            for (int i = 0; i < points.length(); i++) {
                JSONObject p = points.optJSONObject(i);
                if (p == null) continue;
                JSONObject f = new JSONObject();
                f.put("type", "Feature");
                JSONObject geometry = new JSONObject();
                geometry.put("type", "Point");
                JSONArray coordinates = new JSONArray();
                coordinates.put(p.optDouble("longitude", 0));
                coordinates.put(p.optDouble("latitude", 0));
                if (!p.isNull("altitude")) coordinates.put(p.optDouble("altitude", 0));
                geometry.put("coordinates", coordinates);
                f.put("geometry", geometry);
                JSONObject properties = new JSONObject();
                properties.put("project", p.optString("project", ""));
                properties.put("name", p.optString("name", ""));
                properties.put("description", p.optString("description", ""));
                if (!p.isNull("accuracy")) properties.put("accuracy", p.optDouble("accuracy"));
                properties.put("timestamp", p.optLong("timestamp", 0));
                f.put("properties", properties);
                features.put(f);
            }
            root.put("features", features);
            return root.toString(2);
        } catch (Exception e) {
            return "";
        }
    }

    private JSONArray readPointArray() {
        String json = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]");
        try { return new JSONArray(json == null ? "[]" : json); }
        catch (Exception ignored) { return new JSONArray(); }
    }

    private void openPointOnMap(PointRow point) {
        Intent intent = new Intent(this, MapActivity.class);
        intent.putExtra("show_saved_points", true);
        intent.putExtra("saved_points_project", point.project == null ? "" : point.project);
        intent.putExtra("selected_saved_point_name", point.name == null ? "" : point.name);
        intent.putExtra("selected_saved_point_lat", point.latitude);
        intent.putExtra("selected_saved_point_lon", point.longitude);
        startActivity(intent);
    }

    private void openFullMap() {
        Intent intent = new Intent(this, MapActivity.class);
        Location loc = currentLocation;
        if (loc != null && System.currentTimeMillis() - loc.getTime() <= RECENT_MAP_LOCATION_MS) {
            intent.putExtra("latitude", loc.getLatitude());
            intent.putExtra("longitude", loc.getLongitude());
            intent.putExtra("location_accuracy", loc.hasAccuracy() ? loc.getAccuracy() : 0f);
            intent.putExtra("location_bearing", loc.hasBearing() ? loc.getBearing() : 0f);
        } else if (overviewPosition != null && isRecent(overviewPosition)) {
            intent.putExtra("latitude", overviewPosition.latitude);
            intent.putExtra("longitude", overviewPosition.longitude);
            intent.putExtra("location_accuracy", (float) overviewPosition.accuracy);
        }
        startActivity(intent);
    }

    private void shareLastCoordinates() {
        LastPosition p = readLastPosition();
        if (!p.valid) {
            Toast.makeText(this, "Primero obtén una lectura GPS.", Toast.LENGTH_LONG).show();
            return;
        }
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT, "Coordenadas GeoTopo\nLatitud: "
                + format6(p.latitude) + "\nLongitud: " + format6(p.longitude));
        startActivity(Intent.createChooser(share, "Compartir coordenadas"));
    }

    private LastPosition readLastPosition() {
        SharedPreferences prefs = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
        try {
            String lat = prefs.getString("last_latitude", "");
            String lon = prefs.getString("last_longitude", "");
            LastPosition p = new LastPosition();
            p.satellitesVisible = prefs.getInt("last_satellites_visible", 0);
            p.satellitesUsed = prefs.getInt("last_satellites_used", 0);
            p.speedMps = prefs.getFloat("last_speed_mps", -1f);
            p.altitudeM = prefs.getFloat("last_altitude_m", Float.NaN);
            p.provider = prefs.getString("last_provider", "");
            if (lat == null || lon == null || lat.trim().isEmpty() || lon.trim().isEmpty()) return p;
            p.latitude = Double.parseDouble(lat);
            p.longitude = Double.parseDouble(lon);
            p.accuracy = prefs.getFloat("last_accuracy", 0f);
            p.timestamp = prefs.getLong("last_location_time", 0L);
            p.valid = true;
            return p;
        } catch (Exception ignored) {
            return new LastPosition();
        }
    }

    private LastPosition fromLocation(Location location) {
        LastPosition p = new LastPosition();
        if (location == null) return p;
        p.valid = true;
        p.latitude = location.getLatitude();
        p.longitude = location.getLongitude();
        p.accuracy = location.hasAccuracy() ? location.getAccuracy() : 0f;
        p.timestamp = location.getTime() > 0 ? location.getTime() : System.currentTimeMillis();
        p.satellitesVisible = satellitesVisible;
        p.satellitesUsed = satellitesUsed;
        p.speedMps = location.hasSpeed() ? location.getSpeed() : -1f;
        p.altitudeM = location.hasAltitude() ? (float) location.getAltitude() : Float.NaN;
        p.provider = location.getProvider() == null ? "" : location.getProvider();
        return p;
    }

    private boolean isRecent(LastPosition p) {
        return p != null && p.valid && p.timestamp > 0 && System.currentTimeMillis() - p.timestamp <= RECENT_MAP_LOCATION_MS;
    }

    private List<PointRow> readRecentPoints(int limit) {
        List<PointRow> rows = new ArrayList<>();
        JSONArray array = readPointArray();
        for (int i = array.length() - 1; i >= 0 && rows.size() < limit; i--) {
            JSONObject object = array.optJSONObject(i);
            if (object == null) continue;
            PointRow row = new PointRow();
            row.project = object.optString("project", "Proyecto general");
            row.name = object.optString("name", "Punto");
            row.latitude = object.optDouble("latitude", Double.NaN);
            row.longitude = object.optDouble("longitude", Double.NaN);
            double alt = object.optDouble("altitude", Double.NaN);
            CoordinateUtils.Utm utm = CoordinateUtils.toUtm(row.latitude, row.longitude);
            if (utm.valid) {
                row.summary = "UTM " + utm.zone + utm.hemisphere() + " · "
                        + format3(utm.easting) + " E · " + format3(utm.northing) + " N"
                        + (Double.isNaN(alt) ? "" : " · " + format1(alt) + " m");
            } else {
                row.summary = format6(row.latitude) + ", " + format6(row.longitude);
            }
            row.time = relativeTime(object.optLong("timestamp", System.currentTimeMillis()));
            rows.add(row);
        }
        return rows;
    }

    private String qualityLabel(LastPosition p) {
        if (!p.valid) return "Sin lectura";
        if (p.accuracy <= 2.0) return "Excelente";
        if (p.accuracy <= 5.0) return "Buena";
        if (p.accuracy <= 10.0) return "Aceptable";
        if (p.accuracy <= 25.0) return "Media";
        return "Débil";
    }

    private int qualityColor(LastPosition p) {
        if (!p.valid) return NativeUi.SUB;
        if (p.accuracy <= 5.0) return Color.rgb(51, 220, 145);
        if (p.accuracy <= 15.0) return Color.rgb(255, 193, 74);
        return Color.rgb(255, 103, 116);
    }

    private String providerLabel(String provider) {
        if (provider == null || provider.trim().isEmpty()) return "Sin lectura";
        if ("gps".equalsIgnoreCase(provider)) return "GPS / GNSS";
        if ("network".equalsIgnoreCase(provider)) return "Red";
        if (provider.startsWith("promedio")) return "Promedio GNSS";
        return provider;
    }

    private String format3(double value) { return String.format(Locale.US, "%,.3f", value).replace(',', ' '); }
    private String format6(double value) { return String.format(Locale.US, "%.6f", value); }
    private String format1(double value) { return String.format(Locale.US, "%.1f", value); }
    private String formatTime(long timestamp) {
        if (timestamp <= 0) return "sin hora";
        return new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date(timestamp));
    }
    private String relativeTime(long timestamp) {
        if (timestamp <= 0) return "Sin lectura";
        long diff = Math.max(0, System.currentTimeMillis() - timestamp);
        String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(timestamp));
        if (diff < 60000L) return "Ahora";
        if (diff < 60L * 60000L) return "Hace " + Math.max(1, diff / 60000L) + " min";
        if (diff < 24L * 60L * 60L * 1000L) return "Hoy, " + time;
        if (diff < 48L * 60L * 60L * 1000L) return "Ayer, " + time;
        return new SimpleDateFormat("dd/MM, HH:mm", Locale.getDefault()).format(new Date(timestamp));
    }

    private static final class LastPosition {
        boolean valid;
        double latitude;
        double longitude;
        double accuracy;
        long timestamp;
        int satellitesVisible;
        int satellitesUsed;
        float speedMps = -1f;
        float altitudeM = Float.NaN;
        String provider = "";
    }

    private static final class PointRow {
        String project;
        String name;
        String summary;
        String time;
        double latitude;
        double longitude;
    }
}
