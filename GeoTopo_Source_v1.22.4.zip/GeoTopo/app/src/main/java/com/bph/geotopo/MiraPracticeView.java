package com.bph.geotopo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

import java.util.Locale;
import java.util.Random;

/**
 * Vista de práctica para lectura de mira tipo E.
 * Está optimizada para verse grande, clara y cercana
 * a la referencia mostrada por el usuario.
 */
public class MiraPracticeView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random();
    private final int subTextColor;
    private final int panelColor;
    private final float density;

    private double upperReading;
    private double middleReading;
    private double lowerReading;
    private double visibleMin;
    private double visibleMax;

    public MiraPracticeView(Context context, int accentColor, int textColor, int subTextColor, int panelColor) {
        super(context);
        this.subTextColor = subTextColor;
        this.panelColor = panelColor;
        this.density = getResources().getDisplayMetrics().density;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        newExercise();
    }

    public void newExercise() {
        int halfSpanMm = 90 + random.nextInt(61); // 90 mm a 150 mm para una separación más clara.
        int middleMm = 450 + random.nextInt(4051); // 0.450 m a 4.500 m.

        if (middleMm - halfSpanMm < 120) middleMm = 120 + halfSpanMm;
        if (middleMm + halfSpanMm > 4880) middleMm = 4880 - halfSpanMm;

        // Evita valores demasiado redondos para obligar a estimar el último milímetro.
        int remainder = middleMm % 10;
        if (remainder <= 1 || remainder >= 9) {
            middleMm += 3;
        }

        middleReading = middleMm / 1000.0;
        upperReading = (middleMm + halfSpanMm) / 1000.0;
        lowerReading = (middleMm - halfSpanMm) / 1000.0;

        visibleMin = Math.floor((middleReading - 0.15) * 10.0) / 10.0;
        visibleMax = visibleMin + 0.30;

        if (visibleMin < 0.0) {
            visibleMin = 0.0;
            visibleMax = 0.30;
        }
        if (visibleMax > 5.0) {
            visibleMax = 5.0;
            visibleMin = 4.70;
        }

        invalidate();
    }

    public double getUpperReading() {
        return upperReading;
    }

    public double getMiddleReading() {
        return middleReading;
    }

    public double getLowerReading() {
        return lowerReading;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int desiredHeight = dp(760);
        int height = resolveSize(desiredHeight, heightMeasureSpec);
        setMeasuredDimension(width, height);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(panelColor);
        canvas.drawRoundRect(new RectF(0, 0, w, h), dp(22), dp(22), paint);

        float footerHeight = dp(18);
        float topInset = dp(10);
        float cx = w / 2f;
        float cy = (h - footerHeight) / 2f + topInset;
        float radius = Math.min(w * 0.47f, (h - footerHeight) * 0.47f);

        paint.setColor(Color.rgb(12, 16, 22));
        paint.setShadowLayer(dp(16), 0f, dp(6), Color.argb(140, 0, 0, 0));
        canvas.drawCircle(cx, cy, radius + dp(12), paint);
        paint.clearShadowLayer();

        paint.setColor(Color.rgb(235, 235, 235));
        canvas.drawCircle(cx, cy, radius, paint);

        Path clip = new Path();
        clip.addCircle(cx, cy, radius - dp(2), Path.Direction.CW);
        int save = canvas.save();
        canvas.clipPath(clip);

        drawLensBackground(canvas, cx, cy, radius);
        drawStaff(canvas, cx, cy, radius);
        drawThreads(canvas, cx, cy, radius);

        canvas.restoreToCount(save);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(4));
        paint.setColor(Color.rgb(18, 20, 24));
        canvas.drawCircle(cx, cy, radius, paint);
        paint.setStrokeWidth(dp(1.2f));
        paint.setColor(Color.rgb(90, 90, 90));
        canvas.drawCircle(cx, cy, radius - dp(4), paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(subTextColor);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(dp(12));
        canvas.drawText("Vista aleatoria · estilo de campo · patrón tipo E", cx, h - dp(8), paint);
    }

    private void drawLensBackground(Canvas canvas, float cx, float cy, float radius) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(228, 228, 228));
        canvas.drawRect(cx - radius, cy - radius, cx + radius, cy + radius, paint);

        paint.setColor(Color.argb(26, 255, 255, 255));
        canvas.drawCircle(cx - radius * 0.38f, cy - radius * 0.22f, radius * 0.74f, paint);
        paint.setColor(Color.argb(18, 0, 0, 0));
        canvas.drawCircle(cx + radius * 0.22f, cy + radius * 0.10f, radius * 0.92f, paint);
    }

    private void drawStaff(Canvas canvas, float cx, float cy, float radius) {
        float staffWidth = Math.min(dp(132), radius * 0.46f);
        float staffLeft = cx - staffWidth / 2f;
        float staffRight = cx + staffWidth / 2f;
        float staffTop = cy - radius - dp(18);
        float staffBottom = cy + radius + dp(18);

        float leftOuter = staffLeft;
        float patternRight = staffLeft + staffWidth * 0.46f;
        float dividerX = staffLeft + staffWidth * 0.50f;
        float numberLeft = dividerX;
        float numberRight = staffRight;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
        canvas.drawRect(staffLeft, staffTop, staffRight, staffBottom, paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.rgb(30, 30, 30));
        paint.setStrokeWidth(dp(1.2f));
        canvas.drawLine(staffLeft, staffTop, staffLeft, staffBottom, paint);
        canvas.drawLine(dividerX, staffTop, dividerX, staffBottom, paint);
        canvas.drawLine(staffRight, staffTop, staffRight, staffBottom, paint);

        int startCm = (int) Math.floor(visibleMin * 100.0) - 2;
        int endCm = (int) Math.ceil(visibleMax * 100.0) + 2;

        for (int cm = startCm; cm <= endCm; cm++) {
            double value = cm / 100.0;
            float y = readingToY(value, staffTop, staffBottom);
            if (y < staffTop - dp(3) || y > staffBottom + dp(3)) continue;
            boolean decimeter = floorMod(cm, 10) == 0;
            paint.setColor(decimeter ? Color.rgb(120, 120, 120) : Color.rgb(198, 198, 198));
            paint.setStrokeWidth(decimeter ? dp(1.1f) : dp(0.7f));
            canvas.drawLine(staffLeft, y, staffRight, y, paint);
        }

        int startDm = (int) Math.floor(visibleMin * 10.0) - 1;
        int endDm = (int) Math.ceil(visibleMax * 10.0) + 1;
        for (int dm = startDm; dm <= endDm; dm++) {
            double dmValue = dm / 10.0;
            double nextDmValue = dmValue + 0.10;
            float y1 = readingToY(nextDmValue, staffTop, staffBottom);
            float y2 = readingToY(dmValue, staffTop, staffBottom);
            float top = Math.min(y1, y2);
            float bottom = Math.max(y1, y2);
            if (bottom < staffTop || top > staffBottom) continue;

            drawRealLikePattern(canvas, leftOuter, patternRight, top, bottom);
            drawNumber(canvas, dm, numberLeft, numberRight, top, bottom);
        }
    }

    private void drawRealLikePattern(Canvas canvas, float left, float right, float top, float bottom) {
        float width = right - left;
        float cm = (bottom - top) / 10f;
        float spineWidth = width * 0.23f;
        float spineLeft = left + width * 0.06f;
        float spineRight = spineLeft + spineWidth;
        float longRight = right - width * 0.06f;
        float midRight = left + width * 0.70f;
        float shortRight = left + width * 0.48f;
        float barHeight = cm * 0.78f;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(232, 28, 36));

        // Columna roja continua al lado izquierdo, parecida a la referencia.
        canvas.drawRect(spineLeft, top, spineRight, bottom, paint);

        // Rectángulos rojos alternados con espacios blancos, estilo mira tipo E.
        drawPatternBar(canvas, spineLeft, top + cm * 0.15f, longRight, barHeight);
        drawPatternBar(canvas, spineLeft, top + cm * 1.15f, shortRight, barHeight);
        drawPatternBar(canvas, spineLeft, top + cm * 2.15f, midRight, barHeight);
        drawPatternBar(canvas, spineLeft, top + cm * 3.15f, shortRight, barHeight);
        drawPatternBar(canvas, spineLeft, top + cm * 4.15f, longRight, barHeight);
        drawPatternBar(canvas, spineLeft, top + cm * 5.15f, shortRight, barHeight);
        drawPatternBar(canvas, spineLeft, top + cm * 6.15f, midRight, barHeight);
        drawPatternBar(canvas, spineLeft, top + cm * 7.15f, shortRight, barHeight);
        drawPatternBar(canvas, spineLeft, top + cm * 8.15f, longRight, barHeight);

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.rgb(20, 20, 20));
        paint.setStrokeWidth(dp(0.7f));
        canvas.drawLine(left, top, left, bottom, paint);
        canvas.drawLine(right, top, right, bottom, paint);
    }

    private void drawPatternBar(Canvas canvas, float left, float top, float right, float height) {
        canvas.drawRect(left, top, right, top + height, paint);
    }

    private void drawNumber(Canvas canvas, int dm, float left, float right, float top, float bottom) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.BLACK);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(Math.min(dp(32), Math.max(dp(24), (bottom - top) * 0.48f)));
        float x = left + (right - left) * 0.57f;
        float y = (top + bottom) / 2f;
        canvas.drawText(String.format(Locale.US, "%02d", Math.max(0, dm)), x, centeredTextBaseline(y), paint);
    }

    private void drawThreads(Canvas canvas, float cx, float cy, float radius) {
        float staffTop = cy - radius - dp(18);
        float staffBottom = cy + radius + dp(18);

        drawThread(canvas, "LS", upperReading, cx, radius, staffTop, staffBottom, false);
        drawThread(canvas, "LM", middleReading, cx, radius, staffTop, staffBottom, true);
        drawThread(canvas, "LI", lowerReading, cx, radius, staffTop, staffBottom, false);

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.BLACK);
        paint.setStrokeWidth(dp(1.0f));
        float centralTop = cy - radius * 0.98f;
        float centralBottom = cy + radius * 0.98f;
        canvas.drawLine(cx, centralTop, cx, centralBottom, paint);
    }

    private void drawThread(Canvas canvas, String label, double reading, float cx, float radius,
                            float staffTop, float staffBottom, boolean middle) {
        float y = readingToY(reading, staffTop, staffBottom);
        float left = cx - radius + dp(4);
        float right = cx + radius - dp(4);

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.BLACK);
        paint.setStrokeWidth(middle ? dp(2.3f) : dp(1.5f));
        canvas.drawLine(left, y, right, y, paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(26, 26, 26));
        paint.setTextAlign(Paint.Align.LEFT);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(dp(15));
        canvas.drawText(label, left + dp(3), y - dp(8), paint);
    }

    private float centeredTextBaseline(float centerY) {
        Paint.FontMetrics fm = paint.getFontMetrics();
        return centerY - (fm.ascent + fm.descent) / 2f;
    }

    private float readingToY(double reading, float top, float bottom) {
        double range = Math.max(0.01, visibleMax - visibleMin);
        double t = (visibleMax - reading) / range;
        return (float) (top + t * (bottom - top));
    }

    private int floorMod(int value, int divisor) {
        int result = value % divisor;
        return result < 0 ? result + divisor : result;
    }

    private int dp(float value) {
        return Math.round(value * density);
    }
}
