package com.bph.geotopo;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

public class MiraPracticeActivity extends Activity {
    private static final String PREFS = "geo_topo_prefs";
    private static final int THEME_LIGHT = 0;
    private static final int THEME_DARK = 1;
    private static final int THEME_BLACK = 2;

    private static final int[] ACCENTS = {
            Color.rgb(41, 121, 255),
            Color.rgb(0, 188, 212),
            Color.rgb(0, 150, 136),
            Color.rgb(0, 184, 148),
            Color.rgb(118, 210, 34),
            Color.rgb(255, 214, 10),
            Color.rgb(255, 171, 0),
            Color.rgb(255, 112, 20),
            Color.rgb(244, 67, 54),
            Color.rgb(255, 64, 129),
            Color.rgb(142, 68, 173),
            Color.rgb(92, 92, 210),
            Color.rgb(149, 96, 68),
            Color.rgb(158, 169, 181),
            Color.rgb(20, 20, 22),
            Color.rgb(255, 255, 255)
    };

    private int themeMode;
    private int accentIndex;

    private int bgColor;
    private int appBarColor;
    private int cardColor;
    private int textColor;
    private int subTextColor;
    private int borderColor;
    private int inputFillColor;
    private int inputStrokeColor;
    private int resultFillColor;
    private int resultStrokeColor;

    private MiraPracticeView miraPracticeView;
    private EditText miraLsInput;
    private EditText miraLmInput;
    private EditText miraLiInput;
    private TextView miraPracticeResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadPrefs();
        applyPalette();
        buildUi();
        newMiraExercise();
    }

    private void loadPrefs() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        themeMode = sp.getInt("theme", THEME_DARK);
        accentIndex = sp.getInt("accent", 0);
    }

    private void applyPalette() {
        borderColor = ACCENTS[accentIndex % ACCENTS.length];
        if (themeMode == THEME_LIGHT) {
            bgColor = Color.rgb(241, 244, 248);
            appBarColor = Color.rgb(20, 33, 61);
            cardColor = Color.WHITE;
            textColor = Color.rgb(30, 33, 40);
            subTextColor = Color.rgb(96, 104, 118);
            inputFillColor = Color.WHITE;
            inputStrokeColor = Color.rgb(178, 184, 196);
            resultFillColor = Color.rgb(245, 252, 248);
            resultStrokeColor = Color.rgb(29, 185, 84);
        } else if (themeMode == THEME_BLACK) {
            bgColor = Color.BLACK;
            appBarColor = Color.rgb(3, 20, 34);
            cardColor = Color.rgb(9, 11, 15);
            textColor = Color.rgb(245, 245, 247);
            subTextColor = Color.rgb(179, 184, 192);
            inputFillColor = Color.rgb(14, 16, 22);
            inputStrokeColor = Color.rgb(79, 85, 96);
            resultFillColor = Color.rgb(14, 31, 23);
            resultStrokeColor = Color.rgb(0, 200, 83);
        } else {
            bgColor = Color.rgb(7, 22, 36);
            appBarColor = Color.rgb(3, 45, 73);
            cardColor = Color.rgb(17, 38, 58);
            textColor = Color.rgb(248, 250, 252);
            subTextColor = Color.rgb(199, 211, 222);
            inputFillColor = Color.rgb(10, 29, 45);
            inputStrokeColor = Color.rgb(92, 112, 132);
            resultFillColor = Color.rgb(9, 50, 42);
            resultStrokeColor = Color.rgb(0, 210, 125);
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);
        root.addView(topBar());

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(10), dp(10), dp(10), dp(18));
        content.setBackgroundColor(bgColor);

        LinearLayout card = card();
        card.addView(small("Observa una mira tipo E grande y clara. Lee LS, LM y LI como en campo. Cada nueva mira se genera aleatoriamente."));

        miraPracticeView = new MiraPracticeView(this, borderColor, textColor, subTextColor, inputFillColor);
        LinearLayout.LayoutParams viewLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(760)
        );
        viewLp.setMargins(0, dp(8), 0, dp(10));
        miraPracticeView.setLayoutParams(viewLp);
        card.addView(miraPracticeView);

        card.addView(small("Escribe las lecturas en metros con tres decimales. Ejemplo: 1.455. Se acepta una tolerancia visual de ±2 mm."));

        LinearLayout inputLabels = new LinearLayout(this);
        inputLabels.setOrientation(LinearLayout.HORIZONTAL);
        inputLabels.addView(labelTitle("LS superior"), weightParams());
        inputLabels.addView(labelTitle("LM medio"), weightParams());
        inputLabels.addView(labelTitle("LI inferior"), weightParams());
        card.addView(inputLabels);

        LinearLayout inputs = new LinearLayout(this);
        inputs.setOrientation(LinearLayout.HORIZONTAL);
        miraLsInput = edit("1.505");
        miraLmInput = edit("1.455");
        miraLiInput = edit("1.405");
        inputs.addView(miraLsInput, weightParams());
        inputs.addView(miraLmInput, weightParams());
        inputs.addView(miraLiInput, weightParams());
        card.addView(inputs);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button newExercise = btn("Nueva mira");
        newExercise.setOnClickListener(v -> newMiraExercise());
        buttons.addView(newExercise, weightParams());
        Button check = btn("Comprobar lectura");
        check.setOnClickListener(v -> checkMiraReading());
        buttons.addView(check, weightParams());
        card.addView(buttons);

        miraPracticeResult = resultBox("Ejercicio listo. Observa la mira grande, calcula LS, LM y LI, y luego comprueba.");
        card.addView(miraPracticeResult);

        content.addView(card);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));

        setContentView(root);
    }

    private View topBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(appBarColor);
        bar.setPadding(dp(10), dp(14), dp(12), dp(14));

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextColor(Color.WHITE);
        back.setTextSize(28);
        back.setTypeface(Typeface.DEFAULT_BOLD);
        back.setGravity(Gravity.CENTER);
        back.setPadding(dp(8), dp(2), dp(8), dp(4));
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(42), dp(42)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = new TextView(this);
        title.setText("Distancia por hilos");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        titles.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Mira tipo E · práctica topográfica");
        subtitle.setTextColor(Color.argb(220, 255, 255, 255));
        subtitle.setTextSize(12);
        titles.addView(subtitle);
        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        return bar;
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(12), dp(12), dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(cardColor);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), Color.argb(70, Color.red(borderColor), Color.green(borderColor), Color.blue(borderColor)));
        box.setBackground(bg);
        return box;
    }

    private TextView small(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(subTextColor);
        tv.setTextSize(14);
        tv.setLineSpacing(0f, 1.1f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(dp(2), 0, dp(2), dp(6));
        tv.setLayoutParams(lp);
        return tv;
    }

    private TextView labelTitle(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(textColor);
        tv.setTextSize(14);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(dp(4), dp(2), dp(4), dp(4));
        return tv;
    }

    private EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextColor(textColor);
        e.setHintTextColor(Color.argb(170, Color.red(subTextColor), Color.green(subTextColor), Color.blue(subTextColor)));
        e.setTextSize(16);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setSelectAllOnFocus(true);
        e.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(inputFillColor);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), inputStrokeColor);
        e.setBackground(bg);
        return e;
    }

    private Button btn(String text) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(16));
        bg.setColor(borderColor);
        b.setBackground(bg);
        b.setPadding(dp(10), dp(14), dp(10), dp(14));
        return b;
    }

    private TextView resultBox(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(textColor);
        tv.setTextSize(15);
        tv.setLineSpacing(0f, 1.12f);
        tv.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(resultFillColor);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), resultStrokeColor);
        tv.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(10), 0, 0);
        tv.setLayoutParams(lp);
        return tv;
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        return lp;
    }

    private void newMiraExercise() {
        miraPracticeView.newExercise();
        miraLsInput.setText("");
        miraLmInput.setText("");
        miraLiInput.setText("");
        miraPracticeResult.setText("Nueva mira generada. Observa la vista y escribe las lecturas LS, LM y LI con tres decimales.");
    }

    private void checkMiraReading() {
        try {
            double lsUser = Double.parseDouble(miraLsInput.getText().toString().trim());
            double lmUser = Double.parseDouble(miraLmInput.getText().toString().trim());
            double liUser = Double.parseDouble(miraLiInput.getText().toString().trim());

            double lsReal = miraPracticeView.getUpperReading();
            double lmReal = miraPracticeView.getMiddleReading();
            double liReal = miraPracticeView.getLowerReading();

            boolean okLs = Math.abs(lsUser - lsReal) <= 0.002;
            boolean okLm = Math.abs(lmUser - lmReal) <= 0.002;
            boolean okLi = Math.abs(liUser - liReal) <= 0.002;
            boolean centered = Math.abs(lmReal - ((lsReal + liReal) / 2.0)) <= 0.002;

            StringBuilder sb = new StringBuilder();
            if (okLs && okLm && okLi && centered) {
                sb.append("¡Correcto!\n");
                sb.append("LS = ").append(fmt(lsReal)).append(" m\n");
                sb.append("LM = ").append(fmt(lmReal)).append(" m\n");
                sb.append("LI = ").append(fmt(liReal)).append(" m\n");
                sb.append("Comprobación: LM ≈ (LS + LI) / 2");
            } else {
                sb.append("Revisa la lectura.\n");
                sb.append("Lecturas esperadas:\n");
                sb.append("LS = ").append(fmt(lsReal)).append(" m\n");
                sb.append("LM = ").append(fmt(lmReal)).append(" m\n");
                sb.append("LI = ").append(fmt(liReal)).append(" m\n");
                sb.append("Consejo: usa las líneas de 1 cm y estima el último milímetro visualmente.");
            }
            miraPracticeResult.setText(sb.toString());
        } catch (Exception e) {
            miraPracticeResult.setText("Ingresa LS, LM y LI en formato decimal. Ejemplo: 1.455");
        }
    }

    private String fmt(double value) {
        return String.format(Locale.US, "%.3f", value);
    }

    private int dp(float value) {
        return Math.round(getResources().getDisplayMetrics().density * value);
    }
}
