package com.bph.geotopo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

/** Native, responsive Geo Topo dashboard. No full-screen reference bitmap is used. */
public class DashboardActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NativeUi.styleWindow(this);
        setContentView(buildScreen());
    }

    private View buildScreen() {
        FrameLayout root = NativeUi.screen(this);
        LinearLayout content = NativeUi.column(this);
        content.setPadding(NativeUi.dp(this, 15), 0, NativeUi.dp(this, 15), NativeUi.dp(this, 22));

        content.addView(NativeUi.dashboardHeader(this, v -> openSettings()));

        LinearLayout heroes = NativeUi.row(this);
        heroes.setBaselineAligned(false);
        View gps = NativeUi.heroImageCard(this, true, v -> open(GpsOverviewActivity.class));
        View field = NativeUi.heroImageCard(this, false, v -> open(FieldToolsActivity.class));
        LinearLayout.LayoutParams heroLeft = new LinearLayout.LayoutParams(0, NativeUi.dp(this, 228), 1f);
        heroLeft.setMargins(0, NativeUi.dp(this, 4), NativeUi.dp(this, 6), 0);
        LinearLayout.LayoutParams heroRight = new LinearLayout.LayoutParams(0, NativeUi.dp(this, 228), 1f);
        heroRight.setMargins(NativeUi.dp(this, 6), NativeUi.dp(this, 4), 0, 0);
        heroes.addView(gps, heroLeft);
        heroes.addView(field, heroRight);
        content.addView(heroes);

        content.addView(NativeUi.sectionHeader(this, "ϟ", "ACCESO RÁPIDO", "Ver todo",
                v -> open(CalculatorsActivity.class)));
        content.addView(twoCardRow(
                NativeUi.dashboardPhotoCard(this, "converter",
                        v -> open(ConverterActivity.class)),
                NativeUi.dashboardPhotoCard(this, "compass",
                        v -> openTool("compass"))));
        content.addView(twoCardRow(
                NativeUi.dashboardPhotoCard(this, "azimuth",
                        v -> openTool("azimuth")),
                NativeUi.dashboardPhotoCard(this, "coordinates",
                        v -> openTool("coordinates"))));
        content.addView(twoCardRow(
                NativeUi.dashboardPhotoCard(this, "distance",
                        v -> openTool("distance")),
                NativeUi.dashboardPhotoCard(this, "two_hair",
                        v -> openTool("two_hair"))));

        content.addView(NativeUi.sectionHeader(this, "▦", "CÁLCULOS", null, null));
        View polygon = NativeUi.dashboardPhotoCard(this, "polygon",
                v -> openTool("polygon"));
        LinearLayout.LayoutParams wide = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 92));
        wide.setMargins(0, 0, 0, NativeUi.dp(this, 2));
        content.addView(polygon, wide);

        content.addView(NativeUi.sectionHeader(this, "≋", "NIVELACIÓN", null, null));
        content.addView(twoCardRow(
                NativeUi.menuCard(this, "level", "Nivelación", null,
                        v -> openTool("level"), 106),
                NativeUi.menuCard(this, "staff", "Nivelación con tres hilos", null,
                        v -> openTool("stadia"), 106)));

        root.addView(NativeUi.scroll(this, content), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        return root;
    }

    private View twoCardRow(View left, View right) {
        LinearLayout row = NativeUi.row(this);
        row.setBaselineAligned(false);
        LinearLayout.LayoutParams lpLeft = new LinearLayout.LayoutParams(0, NativeUi.dp(this, 114), 1f);
        lpLeft.setMargins(0, 0, NativeUi.dp(this, 6), NativeUi.dp(this, 8));
        LinearLayout.LayoutParams lpRight = new LinearLayout.LayoutParams(0, NativeUi.dp(this, 114), 1f);
        lpRight.setMargins(NativeUi.dp(this, 6), 0, 0, NativeUi.dp(this, 8));
        row.addView(left, lpLeft);
        row.addView(right, lpRight);
        return row;
    }

    private void open(Class<?> target) {
        startActivity(new Intent(this, target));
    }

    private void openTool(String key) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("single_tool", key);
        startActivity(intent);
    }

    private void openSettings() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("show_settings", true);
        intent.putExtra("settings_only", true);
        startActivity(intent);
    }
}
