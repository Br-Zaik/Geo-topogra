package com.bph.geotopo;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Locale;

/**
 * Official ArcGIS imagery access for GeoTopo through the Basemap Styles service.
 *
 * The API key is supplied at build time with the Gradle property or environment
 * variable ESRI_API_KEY. End users never need an ArcGIS account or login.
 */
public final class EsriSatellite {
    private static final String PREFS = "geo_topo_prefs";
    // V2 intentionally ignores the old persistent lock produced by the legacy
    // World_Imagery endpoint so an app update starts with a clean state.
    private static final String KEY_LOCKED = "esri_basemap_locked_v2";
    private static final String KEY_LOCK_REASON = "esri_basemap_lock_reason_v2";
    private static final String KEY_ATTRIBUTION = "esri_basemap_attribution_v2";
    private static final String KEY_LAST_OK = "esri_basemap_last_ok_v2";
    private static final long CHECK_CACHE_MS = 15L * 60L * 1000L;

    private static final String BASEMAP_STYLES =
            "https://basemapstyles-api.arcgis.com/arcgis/rest/services/styles/v2/styles/arcgis/imagery";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private EsriSatellite() { }

    public interface Callback {
        void onResult(Result result);
    }

    public static final class Result {
        public final boolean available;
        public final boolean locked;
        public final String message;

        Result(boolean available, boolean locked, String message) {
            this.available = available;
            this.locked = locked;
            this.message = message == null ? "" : message;
        }
    }

    public static boolean isConfigured() {
        return BuildConfig.ESRI_API_KEY != null && !BuildConfig.ESRI_API_KEY.trim().isEmpty();
    }

    public static boolean isLocked(Context context) {
        if (!isConfigured()) return true;
        return prefs(context).getBoolean(KEY_LOCKED, false);
    }

    public static String lockMessage(Context context) {
        if (!isConfigured()) {
            return "Satélite no configurado todavía por el desarrollador.";
        }
        String reason = prefs(context).getString(KEY_LOCK_REASON, "");
        return reason == null || reason.trim().isEmpty()
                ? "Satélite temporalmente no disponible."
                : reason;
    }

    /** Clean aerial imagery without reference labels. */
    public static String satelliteStyleUrl() {
        return BASEMAP_STYLES + "/standard?token=" + encodedKey() + "&echoToken=true";
    }

    /** Aerial imagery with streets and geographic labels. */
    public static String hybridStyleUrl() {
        return BASEMAP_STYLES + "?language=es&places=all&token=" + encodedKey() + "&echoToken=true";
    }

    public static String attribution(Context context) {
        String saved = prefs(context).getString(KEY_ATTRIBUTION, "");
        if (saved != null && !saved.trim().isEmpty()) return saved.trim();
        return "Esri, Vantor, Earthstar Geographics, and the GIS User Community";
    }

    public static void checkAvailability(Context context, Callback callback) {
        if (context == null) return;
        Context app = context.getApplicationContext();
        if (!isConfigured()) {
            MAIN.post(() -> {
                if (callback != null) callback.onResult(new Result(false, true,
                        "Satélite no configurado todavía por el desarrollador."));
            });
            return;
        }

        SharedPreferences sp = prefs(app);
        long lastOk = sp.getLong(KEY_LAST_OK, 0L);
        boolean locked = sp.getBoolean(KEY_LOCKED, false);
        if (!locked && lastOk > 0L && System.currentTimeMillis() - lastOk < CHECK_CACHE_MS) {
            MAIN.post(() -> {
                if (callback != null) callback.onResult(new Result(true, false, ""));
            });
            return;
        }

        new Thread(() -> {
            Result result = checkNow(app);
            MAIN.post(() -> {
                if (callback != null) callback.onResult(result);
            });
        }, "GeoTopo-Esri-Check").start();
    }

    private static Result checkNow(Context context) {
        String checkUrl = BASEMAP_STYLES + "/standard?f=json&echoToken=false&token=" + encodedKey();
        HttpURLConnection connection = null;
        try {
            connection = open(checkUrl, 8000, 10000);
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) return handleAccessCode(context, code);

            String body = readText(connection.getInputStream());
            JSONObject json = new JSONObject(body);
            Result jsonError = parseArcGisError(context, json);
            if (jsonError != null) return jsonError;

            String copyright = json.optString("copyrightText", "").trim();
            if (!copyright.isEmpty()) {
                prefs(context).edit().putString(KEY_ATTRIBUTION, copyright).apply();
            }

            clearLocked(context);
            prefs(context).edit().putLong(KEY_LAST_OK, System.currentTimeMillis()).apply();
            return new Result(true, false, "");
        } catch (Exception e) {
            return new Result(false, false, "Satélite sin conexión. Se mantiene el mapa normal.");
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static Result parseArcGisError(Context context, JSONObject json) {
        if (json == null) return null;
        JSONObject error = json.optJSONObject("error");
        if (error == null) return null;
        int code = error.optInt("code", 0);
        String message = error.optString("message", "");
        if (code == 401 || code == 402 || code == 403 || code == 429 || code == 498 || code == 499) {
            return handleAccessCode(context, code);
        }
        if (code >= 500) return new Result(false, false, "Servicio satelital temporalmente sin respuesta.");
        if (!message.trim().isEmpty()) {
            return new Result(false, false, "No se pudo abrir el satélite: " + message.trim());
        }
        return new Result(false, false, "No se pudo abrir el satélite.");
    }

    private static HttpURLConnection open(String address, int connectTimeout, int readTimeout) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        connection.setConnectTimeout(connectTimeout);
        connection.setReadTimeout(readTimeout);
        connection.setRequestProperty("User-Agent", "GeoTopo/1.29 Android (com.bph.geotopo)");
        connection.setRequestProperty("Accept", "application/json,*/*");
        return connection;
    }

    private static Result handleAccessCode(Context context, int code) {
        if (code == 401 || code == 498 || code == 499) {
            String message = "Satélite bloqueado: la clave de ArcGIS no es válida o caducó.";
            markLocked(context, message);
            return new Result(false, true, message);
        }
        if (code == 402 || code == 429) {
            String message = "Satélite bloqueado temporalmente: se alcanzó el límite o la cuota disponible de ArcGIS.";
            markLocked(context, message);
            return new Result(false, true, message);
        }
        if (code == 403) {
            // A 403 is a developer permission/configuration problem, not an exhausted
            // free quota. Do not leave the user with a persistent quota padlock.
            clearLocked(context);
            return new Result(false, false,
                    "La clave de ArcGIS no tiene habilitado Basemap styles service.");
        }
        if (code >= 500) {
            return new Result(false, false, "Servicio satelital temporalmente sin respuesta.");
        }
        return new Result(false, false, "No se pudo abrir el satélite (código " + code + ").");
    }

    public static void markLocked(Context context, String reason) {
        if (context == null) return;
        prefs(context).edit()
                .putBoolean(KEY_LOCKED, true)
                .putString(KEY_LOCK_REASON, reason == null ? "Satélite temporalmente no disponible." : reason)
                .remove(KEY_LAST_OK)
                .apply();
    }

    public static void clearLocked(Context context) {
        if (context == null) return;
        prefs(context).edit()
                .putBoolean(KEY_LOCKED, false)
                .remove(KEY_LOCK_REASON)
                .apply();
    }

    public static boolean looksLikeAccessFailure(String errorMessage) {
        if (errorMessage == null) return false;
        String lower = errorMessage.toLowerCase(Locale.ROOT);
        return lower.contains("401") || lower.contains("402") || lower.contains("403") || lower.contains("429")
                || lower.contains("498") || lower.contains("499")
                || lower.contains("unauthor") || lower.contains("forbidden")
                || lower.contains("quota") || lower.contains("rate limit")
                || lower.contains("billing") || lower.contains("token");
    }

    public static boolean shouldLockForError(String errorMessage) {
        if (errorMessage == null) return false;
        String lower = errorMessage.toLowerCase(Locale.ROOT);
        return lower.contains("401") || lower.contains("402") || lower.contains("429")
                || lower.contains("498") || lower.contains("499")
                || lower.contains("unauthor") || lower.contains("quota")
                || lower.contains("rate limit") || lower.contains("billing")
                || lower.contains("invalid token") || lower.contains("token expired");
    }

    public static String accessFailureMessage(String errorMessage) {
        String lower = errorMessage == null ? "" : errorMessage.toLowerCase(Locale.ROOT);
        if (lower.contains("403") || lower.contains("forbidden")) {
            return "La clave de ArcGIS no tiene habilitado Basemap styles service.";
        }
        if (lower.contains("402") || lower.contains("429") || lower.contains("quota")
                || lower.contains("rate limit") || lower.contains("billing")) {
            return "Satélite bloqueado temporalmente: se alcanzó el límite o la cuota disponible de ArcGIS.";
        }
        if (lower.contains("401") || lower.contains("498") || lower.contains("499")
                || lower.contains("unauthor") || lower.contains("invalid token") || lower.contains("token expired")) {
            return "Satélite bloqueado: la clave de ArcGIS no es válida o caducó.";
        }
        return "Satélite temporalmente no disponible.";
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static String encodedKey() {
        try {
            return URLEncoder.encode(BuildConfig.ESRI_API_KEY == null ? "" : BuildConfig.ESRI_API_KEY.trim(), "UTF-8");
        } catch (Exception ignored) {
            return BuildConfig.ESRI_API_KEY == null ? "" : BuildConfig.ESRI_API_KEY.trim();
        }
    }

    private static String readText(InputStream input) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(input, "UTF-8"));
        StringBuilder out = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) out.append(line);
        return out.toString();
    }
}
