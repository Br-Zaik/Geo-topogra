package com.bph.geotopo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.GeomagneticField;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;

/** Radar de orientación a punto guardado, distancia horizontal y rumbo real cuando disponible. */
public class GotoPointActivity extends Activity implements LocationListener, SensorEventListener {
    private LocationManager manager;
    private SensorManager sensors;
    private Sensor rotation;
    private TextView targetTitle, distance, bearing, heading, accuracy, hint;
    private Radar radar;
    private double targetLat=Double.NaN,targetLon=Double.NaN;
    private String targetName="";
    private Location current;
    private double headingTrue=Double.NaN;
    private double azimuthTrue=Double.NaN;
    private boolean gpsEnabled;
    private static final int REQ=7791;
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);NativeUi.styleWindow(this);
        manager=(LocationManager)getSystemService(LOCATION_SERVICE);
        sensors=(SensorManager)getSystemService(SENSOR_SERVICE);
        rotation=sensors==null?null:sensors.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        LinearLayout page=NativeUi.column(this);
        page.addView(NativeUi.pageHeader(this,"Ir a punto / Radar","Navegación de campo hacia un punto",v->finish(),"⌖",v->selectPoint()));
        LinearLayout body=NativeUi.column(this);body.setPadding(NativeUi.dp(this,16),NativeUi.dp(this,12),NativeUi.dp(this,16),NativeUi.dp(this,22));
        Button choose=new Button(this);choose.setText("▾  Elegir punto guardado");choose.setAllCaps(false);choose.setOnClickListener(v->selectPoint());body.addView(choose);
        targetTitle=NativeUi.text(this,"Selecciona un punto",19,true,NativeUi.TEXT);body.addView(targetTitle);
        radar=new Radar();body.addView(radar,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,NativeUi.dp(this,300)));
        distance=measure(body,"DISTANCIA HORIZONTAL","—");
        bearing=measure(body,"AZIMUT AL OBJETIVO (NORTE VERDADERO)","—");
        heading=measure(body,"ORIENTACIÓN DEL TELÉFONO","—");
        accuracy=measure(body,"PRECISIÓN DE POSICIÓN","—");
        hint=NativeUi.text(this,"Para navegar, activa ubicación precisa y espera fijación GPS. La flecha usa el sensor de orientación disponible; aleja el celular de metal.",12,false,NativeUi.SUB);
        hint.setPadding(0,NativeUi.dp(this,15),0,0);body.addView(hint);
        page.addView(NativeUi.scroll(this,body),new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));setContentView(page);
        if(getIntent().hasExtra("target_lat")&&getIntent().hasExtra("target_lon")){
            targetLat=getIntent().getDoubleExtra("target_lat",Double.NaN);targetLon=getIntent().getDoubleExtra("target_lon",Double.NaN);
            targetName=getIntent().getStringExtra("target_name");if(targetName==null)targetName="Punto";
        }
        update();
    }
    private TextView measure(LinearLayout parent,String name,String value){
        TextView t=NativeUi.text(this,name+"\n"+value,16,true,NativeUi.TEXT);
        t.setPadding(NativeUi.dp(this,13),NativeUi.dp(this,9),NativeUi.dp(this,13),NativeUi.dp(this,9));
        t.setBackground(NativeUi.rounded(NativeUi.CARD_LIGHT,12,1,NativeUi.BORDER,this));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);lp.setMargins(0,NativeUi.dp(this,7),0,0);parent.addView(t,lp);return t;
    }
    private void selectPoint(){
        JSONArray points;
        try{points=new JSONArray(getSharedPreferences("geo_topo_gps_points",MODE_PRIVATE).getString("points_json","[]"));}catch(Exception ex){points=new JSONArray();}
        if(points.length()==0){new AlertDialog.Builder(this).setTitle("No hay puntos guardados").setMessage("Crea un punto manual o guarda una lectura GPS desde Puntos.").setPositiveButton("Entendido",null).show();return;}
        final JSONArray items=points;
        String[] labels=new String[points.length()];
        for(int i=0;i<points.length();i++){JSONObject p=points.optJSONObject(i);labels[i]=p==null?"Punto":p.optString("name","Punto")+" · "+p.optString("project","Proyecto general");}
        new AlertDialog.Builder(this).setTitle("Ir a punto").setItems(labels,(d,which)->{
            JSONObject p=items.optJSONObject(which);if(p==null)return;
            targetLat=p.optDouble("latitude",Double.NaN);targetLon=p.optDouble("longitude",Double.NaN);targetName=p.optString("name","Punto");update();
        }).setNegativeButton("Cancelar",null).show();
    }
    @Override protected void onResume(){super.onResume();start();}
    @Override protected void onPause(){stop();super.onPause();}
    private void start(){
        if(sensors!=null&&rotation!=null)sensors.registerListener(this,rotation,SensorManager.SENSOR_DELAY_UI);
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQ);return;}
        try{
            gpsEnabled=manager!=null&&manager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            if(manager!=null){manager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000L,0,this);Location last=manager.getLastKnownLocation(LocationManager.GPS_PROVIDER);if(last!=null && gpsEnabled && System.currentTimeMillis()-last.getTime()<15000L)current=last;}
        }catch(Exception e){hint.setText("No fue posible iniciar la ubicación GPS. Comprueba los permisos y el servicio del teléfono.");}
        update();
    }
    private void stop(){try{if(manager!=null)manager.removeUpdates(this);}catch(Exception ignored){}if(sensors!=null)sensors.unregisterListener(this);}
    @Override public void onRequestPermissionsResult(int code,String[] perms,int[] results){super.onRequestPermissionsResult(code,perms,results);if(code==REQ&&results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)start();else if(code==REQ)Toast.makeText(this,"Permiso GPS necesario para navegar.",Toast.LENGTH_LONG).show();}
    @Override public void onLocationChanged(Location loc){current=loc;if(rotation==null&&loc.hasBearing()&&loc.hasSpeed()&&loc.getSpeed()>=1.2f)headingTrue=loc.getBearing();update();}
    @Override public void onProviderEnabled(String p){gpsEnabled=true;update();}
    @Override public void onProviderDisabled(String p){gpsEnabled=false;current=null;update();}
    @Override public void onSensorChanged(SensorEvent event){if(event.sensor.getType()!=Sensor.TYPE_ROTATION_VECTOR)return;float[] r=new float[9],o=new float[3];SensorManager.getRotationMatrixFromVector(r,event.values);SensorManager.getOrientation(r,o);double magnetic=(Math.toDegrees(o[0])+360)%360;
        if(current!=null){GeomagneticField model=new GeomagneticField((float)current.getLatitude(),(float)current.getLongitude(),current.hasAltitude()?(float)current.getAltitude():0,System.currentTimeMillis());headingTrue=(magnetic+model.getDeclination()+360)%360;}
        else headingTrue=magnetic;update();}
    @Override public void onAccuracyChanged(Sensor s,int a){}
    private void update(){
        if(targetTitle==null)return;
        targetTitle.setText(Double.isFinite(targetLat)&&Double.isFinite(targetLon)?"Destino: "+targetName:"Selecciona un punto guardado");
        if(current!=null && (current.getTime()<=0 || System.currentTimeMillis()-current.getTime()>15000L)) current=null;
        if(current==null||!Double.isFinite(targetLat)||!Double.isFinite(targetLon)){
            distance.setText("DISTANCIA HORIZONTAL\n—");bearing.setText("AZIMUT AL OBJETIVO\n—");
            accuracy.setText("PRECISIÓN DE POSICIÓN\n"+(current==null?"Esperando GPS":current.hasAccuracy()?"±"+fmt(current.getAccuracy())+" m":"Sin dato"));
            hint.setText(gpsEnabled?"Esperando ubicación GPS y punto de destino.":"Activa el GPS y selecciona un punto guardado.");
            radar.invalidate();return;
        }
        float[] result=new float[3];Location.distanceBetween(current.getLatitude(),current.getLongitude(),targetLat,targetLon,result);
        azimuthTrue=(result[1]+360)%360;
        distance.setText("DISTANCIA HORIZONTAL\n"+fmt(result[0])+" m");
        bearing.setText("AZIMUT AL OBJETIVO (NORTE VERDADERO)\n"+fmt(azimuthTrue)+"°");
        accuracy.setText("PRECISIÓN DE POSICIÓN\n"+(current.hasAccuracy()?"±"+fmt(current.getAccuracy())+" m (Android)":"No disponible"));
        if(rotation==null&&current.hasBearing()&&current.hasSpeed()&&current.getSpeed()>=1.2f)headingTrue=current.getBearing();
        heading.setText("ORIENTACIÓN DEL TELÉFONO\n"+(Double.isNaN(headingTrue)?"Sin rumbo de brújula":""+fmt(headingTrue)+"°"));
        hint.setText(result[0]<=Math.max(3,current.hasAccuracy()?current.getAccuracy():3)?"Cerca del destino según la precisión disponible. Comprueba físicamente el punto.":"La flecha indica cómo girar hacia el destino. Distancia en línea recta, no por caminos.");
        radar.invalidate();
    }
    private String fmt(double d){return String.format(Locale.US,"%.1f",d);}
    private class Radar extends View{
        final Paint p=new Paint(3);Radar(){super(GotoPointActivity.this);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float cx=getWidth()/2f,cy=getHeight()/2f,rad=Math.min(getWidth(),getHeight())*.39f;
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(Color.rgb(66,115,152));c.drawCircle(cx,cy,rad,p);c.drawCircle(cx,cy,rad*.5f,p);c.drawLine(cx-rad,cy,cx+rad,cy,p);c.drawLine(cx,cy-rad,cx,cy+rad,p);
            p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(NativeUi.dp(GotoPointActivity.this,17));
            String[] dirs={"N","E","S","O"};for(int i=0;i<4;i++){double a=Math.toRadians(i*90-(Double.isFinite(headingTrue)?headingTrue:0));c.drawText(dirs[i],cx+(float)Math.sin(a)*(rad+NativeUi.dp(GotoPointActivity.this,18)),cy-(float)Math.cos(a)*(rad+NativeUi.dp(GotoPointActivity.this,18))+6,p);}
            if(Double.isFinite(azimuthTrue)&&Double.isFinite(headingTrue)){
                double a=Math.toRadians(azimuthTrue-headingTrue);float dx=(float)Math.sin(a),dy=-(float)Math.cos(a);
                p.setColor(Color.rgb(61,218,144));p.setStrokeWidth(9);c.drawLine(cx,cy,cx+dx*rad*.8f,cy+dy*rad*.8f,p);
                android.graphics.Path triangle=new android.graphics.Path();float tx=cx+dx*rad*.93f,ty=cy+dy*rad*.93f;triangle.moveTo(tx,ty);triangle.lineTo(cx+dx*rad*.68f-dy*15,cy+dy*rad*.68f+dx*15);triangle.lineTo(cx+dx*rad*.68f+dy*15,cy+dy*rad*.68f-dx*15);triangle.close();c.drawPath(triangle,p);
            }else{p.setColor(Color.rgb(255,195,80));p.setTextSize(NativeUi.dp(GotoPointActivity.this,12));c.drawText("Esperando rumbo",cx,cy+rad*.7f,p);}
            p.setColor(Color.rgb(54,178,255));c.drawCircle(cx,cy,9,p);
        }
    }
    @Override public void onContentChanged(){super.onContentChanged();NativeUi.applySystemBarInsets(this);}
}
