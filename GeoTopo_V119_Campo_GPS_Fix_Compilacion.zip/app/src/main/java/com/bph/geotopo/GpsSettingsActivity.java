package com.bph.geotopo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.graphics.Color;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;

/** Opciones de visualización; ninguna opción altera las lecturas brutas del receptor. */
public class GpsSettingsActivity extends Activity {
    static final String PREFS="geo_topo_gps_points";
    static final String FORMAT="coordinate_display_format";
    static final String HEIGHT_OFFSET="manual_height_offset_m";
    @Override public void onCreate(Bundle state){super.onCreate(state);NativeUi.styleWindow(this);
        SharedPreferences sp=getSharedPreferences(PREFS,MODE_PRIVATE);
        LinearLayout page=NativeUi.column(this);
        page.addView(NativeUi.pageHeader(this,"Ajustes GPS","Formatos y correcciones de campo",v->finish(),"⌖",v->finish()));
        LinearLayout body=NativeUi.column(this);body.setPadding(NativeUi.dp(this,16),NativeUi.dp(this,16),NativeUi.dp(this,16),NativeUi.dp(this,25));
        body.addView(label("FORMATO DE COORDENADAS"));
        Spinner formats=new Spinner(this);
        formats.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Grados decimales (DD)","Grados y minutos (DM)","Grados, minutos y segundos (DMS)"}));
        formats.setSelection(Math.max(0,Math.min(2,sp.getInt(FORMAT,0))));body.addView(formats);
        body.addView(label("La lectura UTM sigue mostrándose en metros, con zona, banda y hemisferio separados. El formato seleccionado afecta a la lectura de latitud y longitud."));
        body.addView(label("CORRECCIÓN MANUAL DE ALTITUD"));
        EditText offset=new EditText(this);offset.setHint("Desplazamiento en metros (ej. -28.5)");offset.setText(String.format(Locale.US,"%.2f",Double.longBitsToDouble(sp.getLong(HEIGHT_OFFSET,Double.doubleToLongBits(0d)))));offset.setTextColor(Color.WHITE);body.addView(offset);
        body.addView(label("Altitud ajustada = altitud que informa Android + desplazamiento manual. Este ajuste NO modifica los puntos GPS brutos, ni calcula un modelo geoidal EGM. Solo aplícalo si conoces la corrección verificada para tu zona y datum."));
        Button zone=new Button(this);zone.setText("Calcular zona UTM por longitud");zone.setAllCaps(false);zone.setOnClickListener(v->zoneTool());body.addView(zone);
        Button save=new Button(this);save.setText("✓ Guardar ajustes");save.setAllCaps(false);save.setOnClickListener(v->{
            try {double d=Double.parseDouble(offset.getText().toString().trim().replace(',','.'));if(!Double.isFinite(d)||Math.abs(d)>300)throw new IllegalArgumentException("Comprueba el desplazamiento: máximo ±300 m para este ajuste manual.");
                sp.edit().putInt(FORMAT,formats.getSelectedItemPosition()).putLong(HEIGHT_OFFSET,Double.doubleToLongBits(d)).apply();Toast.makeText(this,"Ajustes guardados.",Toast.LENGTH_SHORT).show();finish();
            }catch(Exception ex){new AlertDialog.Builder(this).setTitle("Revisa la corrección").setMessage(ex.getMessage()==null?"Introduce un número válido.":ex.getMessage()).setPositiveButton("Entendido",null).show();}
        });body.addView(save);
        page.addView(NativeUi.scroll(this,body),new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));setContentView(page);
    }
    private TextView label(String t){TextView v=NativeUi.text(this,t,13f,false,NativeUi.TEXT);v.setPadding(0,NativeUi.dp(this,12),0,NativeUi.dp(this,12));return v;}
    private void zoneTool(){EditText longitude=new EditText(this);longitude.setHint("Longitud, ej.: -71.42");longitude.setTextColor(Color.BLACK);
        new AlertDialog.Builder(this).setTitle("Longitud → zona UTM").setMessage("Ingrese longitud entre -180° y 180°. La zona se calcula con intervalos de 6°; para excepciones de Noruega/Svalbard también se necesita latitud.")
            .setView(longitude).setPositiveButton("Calcular",(d,w)->{try{double lon=Double.parseDouble(longitude.getText().toString().trim().replace(',','.'));if(!Double.isFinite(lon)||lon < -180||lon >180)throw new Exception();int z=lon==180?60:(int)Math.floor((lon+180)/6)+1;double central=z*6-183;
                new AlertDialog.Builder(this).setTitle("Zona UTM "+z).setMessage(String.format(Locale.US,"Meridiano central: %.0f°\nLímites nominales: %.0f° a %.0f°\n\nLa banda latitudinal y el hemisferio se calculan a partir de la latitud.",central,central-3,central+3)).setPositiveButton("Cerrar",null).show();}
                catch(Exception ex){Toast.makeText(this,"Longitud inválida (−180 a 180).",Toast.LENGTH_LONG).show();}}).setNegativeButton("Cancelar",null).show();
    }
    static String latLon(double x,boolean latitude,int format){
        if(!Double.isFinite(x))return "Sin lectura";
        String axis=latitude?(x<0?"S":"N"):(x<0?"O":"E");
        if(format==0)return String.format(Locale.US,"%.6f°",x);
        double val=Math.abs(x);int deg=(int)Math.floor(val);double minutes=(val-deg)*60;
        if(format==1)return String.format(Locale.US,"%d° %.4f′ %s",deg,minutes,axis);
        int min=(int)Math.floor(minutes);double seconds=(minutes-min)*60;
        if(seconds>=59.995){seconds=0;min++;if(min>=60){min=0;deg++;}}
        return String.format(Locale.US,"%d° %02d′ %05.2f″ %s",deg,min,seconds,axis);
    }
    @Override public void onContentChanged(){super.onContentChanged();NativeUi.applySystemBarInsets(this);}
}
