package com.bph.geotopo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;

/** Puntos topográficos manuales o edición de puntos GPS existentes. No requiere señal GPS. */
public class PointEditorActivity extends Activity {
    private static final String PREFS = "geo_topo_gps_points";
    private static final int PICK_IMAGE = 6801;
    private Spinner format, hemisphere, symbol;
    private EditText project, name, description, first, second, zone, altitude;
    private TextView firstLabel, secondLabel, photoLabel, preview;
    private int editIndex = -1;
    private JSONObject original;
    private String photoUri = "";
    private double lastLat = Double.NaN, lastLon = Double.NaN;
    private int previousFormat = 0;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NativeUi.styleWindow(this);
        editIndex = getIntent().getIntExtra("edit_index", -1);
        JSONArray all = points();
        original = editIndex >= 0 && editIndex < all.length() ? all.optJSONObject(editIndex) : null;
        if (original != null) {
            photoUri = original.optString("photoUri", "");
            lastLat = original.optDouble("latitude", Double.NaN);
            lastLon = original.optDouble("longitude", Double.NaN);
        }
        LinearLayout page = NativeUi.column(this);
        page.addView(NativeUi.pageHeader(this, original == null ? "Crear punto manual" : "Editar punto",
                "WGS84 · UTM y coordenadas geográficas", v -> finish(), "⌖", v -> previewOnMap()));
        LinearLayout body = NativeUi.column(this);
        body.setPadding(NativeUi.dp(this, 17), NativeUi.dp(this, 13), NativeUi.dp(this, 17), NativeUi.dp(this, 25));
        body.addView(label("PROYECTO Y PUNTO"));
        project = field("Proyecto", original == null ? getSharedPreferences(PREFS, MODE_PRIVATE).getString("current_project", "Proyecto general") : original.optString("project", "Proyecto general"));
        name = field("Nombre del punto", original == null ? nextName(all) : original.optString("name", ""));
        description = field("Descripción o referencia de campo", original == null ? "" : original.optString("description", ""));
        body.addView(project); body.addView(name); body.addView(description);
        symbol = drop(new String[]{"● Punto", "◆ Vértice", "▲ Cumbre", "⚑ Estación", "■ Referencia", "★ Importante"});
        body.addView(label("SÍMBOLO")); body.addView(symbol);
        if (original != null) {
            String[] syms = {"●", "◆", "▲", "⚑", "■", "★"};
            for (int i=0;i<syms.length;i++) if (original.optString("symbol", "●").equals(syms[i])) symbol.setSelection(i);
        }
        body.addView(label("COORDENADAS DEL PUNTO"));
        format = drop(new String[]{"Geográficas · grados decimales", "UTM · Este / Norte"});
        body.addView(format);
        firstLabel = label("Latitud (- Sur / + Norte)");
        secondLabel = label("Longitud (- Oeste / + Este)");
        first = field("Ej.: -14.782345", original == null ? "" : fmt(lastLat));
        second = field("Ej.: -71.418765", original == null ? "" : fmt(lastLon));
        body.addView(firstLabel); body.addView(first); body.addView(secondLabel); body.addView(second);
        zone = field("Zona UTM 1–60", "19");
        hemisphere = drop(new String[]{"Sur (S)", "Norte (N)"});
        body.addView(label("ZONA UTM / HEMISFERIO")); body.addView(zone); body.addView(hemisphere);
        if (original != null && Double.isFinite(lastLat) && Double.isFinite(lastLon)) {
            CoordinateUtils.Utm utm = CoordinateUtils.toUtm(lastLat, lastLon);
            if (utm.valid) { zone.setText(String.valueOf(utm.zone)); hemisphere.setSelection(utm.south ? 0 : 1); }
        }
        altitude = field("Altitud opcional (metros)", original == null || original.isNull("altitude") ? "" : fmt(original.optDouble("altitude", Double.NaN)));
        body.addView(label("ALTITUD (OPCIONAL)")); body.addView(altitude);
        photoLabel = label(photoUri.isEmpty() ? "Sin foto adjunta" : "Foto adjunta al punto");
        Button photo = button("Adjuntar / cambiar foto");
        photo.setOnClickListener(v -> { Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*"); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION); startActivityForResult(i, PICK_IMAGE); });
        body.addView(photo); body.addView(photoLabel);
        preview = NativeUi.text(this, "Introduce las coordenadas y toca Ver en mapa para comprobar la posición.", 12f, false, NativeUi.SUB);
        preview.setPadding(0, NativeUi.dp(this, 10), 0, NativeUi.dp(this, 8));
        body.addView(preview);
        Button map = button("⌖  Ver coordenadas en mapa");
        map.setOnClickListener(v -> previewOnMap()); body.addView(map);
        Button save = button(original == null ? "✓  Guardar punto manual" : "✓  Guardar cambios");
        save.setOnClickListener(v -> save()); body.addView(save);
        format.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View v, int position, long id) {
                boolean utm = position == 1;
                if (previousFormat != position) {
                    try {
                        double a = number(first), b = number(second);
                        if (previousFormat == 0 && a >= -90 && a <= 90 && b >= -180 && b <= 180) {
                            lastLat = a; lastLon = b;
                        } else if (previousFormat == 1) {
                            int z = Integer.parseInt(zone.getText().toString().trim());
                            CoordinateUtils.LatLon ll = CoordinateUtils.fromUtm(a, b, z, hemisphere.getSelectedItemPosition() == 0);
                            if (ll.valid) { lastLat = ll.latitude; lastLon = ll.longitude; }
                        }
                    } catch (Exception ignored) { }
                }
                previousFormat = position;
                firstLabel.setText(utm ? "Este / Easting (m)" : "Latitud (- Sur / + Norte)");
                secondLabel.setText(utm ? "Norte / Northing (m)" : "Longitud (- Oeste / + Este)");
                zone.setEnabled(utm); hemisphere.setEnabled(utm);
                first.setHint(utm ? "Ej.: 240514.000" : "Ej.: -14.782345");
                second.setHint(utm ? "Ej.: 8363678.000" : "Ej.: -71.418765");
                if (Double.isFinite(lastLat) && Double.isFinite(lastLon)) {
                    if (utm) {
                        CoordinateUtils.Utm u = CoordinateUtils.toUtm(lastLat,lastLon);
                        if (u.valid) { first.setText(fmt(u.easting)); second.setText(fmt(u.northing)); zone.setText(String.valueOf(u.zone)); hemisphere.setSelection(u.south ? 0 : 1); }
                    } else { first.setText(fmt(lastLat)); second.setText(fmt(lastLon)); }
                } else { first.setText(""); second.setText(""); }
            }
        });
        ScrollView scroll = NativeUi.scroll(this, body);
        page.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));
        setContentView(page);
    }
    private String nextName(JSONArray all) {
        int n=1; boolean found;
        do { found=false; for (int i=0;i<all.length();i++) if (("P"+n).equalsIgnoreCase(all.optJSONObject(i)==null ? "" : all.optJSONObject(i).optString("name"))) {found=true;break;} if (found)n++; } while(found && n<100000);
        return "P"+n;
    }
    private String fmt(double number) { return Double.isFinite(number) ? String.format(Locale.US,"%.8f",number).replaceAll("0+$", "").replaceAll("\\.$", "") : ""; }
    private EditText field(String hint,String value) { EditText e=new EditText(this); e.setHint(hint);e.setText(value);e.setTextColor(Color.WHITE);e.setHintTextColor(NativeUi.SUB);e.setTextSize(16);e.setSelectAllOnFocus(false);return e; }
    private TextView label(String text){TextView v=NativeUi.text(this,text,12.5f,true,NativeUi.TEXT);v.setPadding(0,NativeUi.dp(this,12),0,NativeUi.dp(this,5));return v;}
    private Button button(String text){Button v=new Button(this);v.setText(text);v.setAllCaps(false);ResponsiveUi.configureCompactText(v,15,11,2);return v;}
    private Spinner drop(String[] choices){Spinner s=new Spinner(this);ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,choices);s.setAdapter(a);return s;}
    private double number(EditText e){return Double.parseDouble(e.getText().toString().trim().replace(" ","").replace(',','.'));}
    private double[] getCoordinates() {
        double a=number(first),b=number(second),lat,lon;
        if (!Double.isFinite(a)||!Double.isFinite(b))throw new IllegalArgumentException("Introduce números válidos.");
        if (format.getSelectedItemPosition()==0) {lat=a;lon=b;}
        else {
            int z=Integer.parseInt(zone.getText().toString().trim());
            CoordinateUtils.LatLon c=CoordinateUtils.fromUtm(a,b,z,hemisphere.getSelectedItemPosition()==0);
            if (!c.valid || c.latitude < -80 || c.latitude >84 || (hemisphere.getSelectedItemPosition()==0 && c.latitude > 0.000001) || (hemisphere.getSelectedItemPosition()==1 && c.latitude < -0.000001))throw new IllegalArgumentException("UTM inválida: comprueba zona, Este, Norte y hemisferio.");
            lat=c.latitude;lon=c.longitude;
        }
        if(lat < -90||lat>90||lon < -180||lon>180)throw new IllegalArgumentException("Latitud [-90,90] y longitud [-180,180].");
        return new double[]{lat,lon};
    }
    private void previewOnMap(){
        try {
            double[] c=getCoordinates();
            Intent map=new Intent(this,MapActivity.class);
            map.putExtra("camera_lat",c[0]);map.putExtra("camera_lon",c[1]);map.putExtra("camera_zoom",16d);
            map.putExtra("preview_manual_lat",c[0]);map.putExtra("preview_manual_lon",c[1]);
            startActivity(map);
        }catch(Exception e){new AlertDialog.Builder(this).setTitle("Revisa las coordenadas").setMessage(e instanceof NumberFormatException ? "Introduce los dos valores numéricos y la zona UTM cuando corresponda." : e.getMessage()).setPositiveButton("Entendido",null).show();}
    }
    private void save(){
        try {
            double[] c=getCoordinates();
            String n=name.getText().toString().trim();if(n.isEmpty()){name.setError("Escribe un nombre");return;}
            String p=project.getText().toString().trim();if(p.isEmpty())p="Proyecto general";
            double alt=Double.NaN;
            if(!altitude.getText().toString().trim().isEmpty()){alt=number(altitude);if (!Double.isFinite(alt)||alt < -12000||alt>12000)throw new IllegalArgumentException("Altitud fuera de rango.");}
            JSONArray a=points(); JSONObject o=original==null ? new JSONObject() : new JSONObject(original.toString());
            o.put("name",n);o.put("project",p);o.put("description",description.getText().toString().trim());
            o.put("latitude",c[0]);o.put("longitude",c[1]);o.put("altitude",Double.isFinite(alt)?alt:JSONObject.NULL);
            o.put("symbol",new String[]{"●","◆","▲","⚑","■","★"}[symbol.getSelectedItemPosition()]);
            o.put("photoUri",photoUri);o.put("timestamp",original==null?System.currentTimeMillis():original.optLong("timestamp",System.currentTimeMillis()));
            if(original==null){o.put("provider","manual");o.put("accuracy",JSONObject.NULL);a.put(o);}
            else a.put(editIndex,o);
            boolean ok=getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString("points_json",a.toString()).putString("current_project",p).commit();
            if(!ok)throw new IllegalStateException("No se pudieron guardar los cambios en el dispositivo.");
            setResult(RESULT_OK);Toast.makeText(this,"Punto guardado: "+n,Toast.LENGTH_SHORT).show();finish();
        }catch(Exception e){new AlertDialog.Builder(this).setTitle("No se pudo guardar").setMessage(e instanceof NumberFormatException?"Revisa los números y la zona UTM.":e.getMessage()).setPositiveButton("Entendido",null).show();}
    }
    private JSONArray points(){try{return new JSONArray(getSharedPreferences(PREFS,MODE_PRIVATE).getString("points_json","[]"));}catch(Exception e){return new JSONArray();}}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==PICK_IMAGE&&result==RESULT_OK&&data!=null&&data.getData()!=null){Uri uri=data.getData();try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}photoUri=uri.toString();photoLabel.setText("Foto adjunta: "+uri.getLastPathSegment());}}
    @Override public void onContentChanged(){super.onContentChanged();NativeUi.applySystemBarInsets(this);}
}
