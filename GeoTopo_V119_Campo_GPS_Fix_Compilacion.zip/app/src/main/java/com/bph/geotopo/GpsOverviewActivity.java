package com.bph.geotopo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.location.GnssStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.maplibre.android.MapLibre;
import org.maplibre.android.annotations.IconFactory;
import org.maplibre.android.annotations.Marker;
import org.maplibre.android.annotations.MarkerOptions;
import org.maplibre.android.camera.CameraPosition;
import org.maplibre.android.camera.CameraUpdateFactory;
import org.maplibre.android.geometry.LatLng;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapView;
import org.maplibre.android.maps.Style;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Centro único de GPS y mapas. Las acciones principales trabajan dentro de
 * esta pantalla para evitar saltos repetidos a la antigua pantalla GPS.
 */
public class GpsOverviewActivity extends Activity implements LocationListener {
    private static final String PREFS = "geo_topo_prefs";
    private static final String GPS_PREFS = "geo_topo_gps_points";
    private static final String KEY_POINTS = "points_json";
    private static final String KEY_OVERVIEW_MAP_MODE = "overview_map_mode";
    private static final String KEY_OFFLINE_PATH = "offline_mbtiles_path";
    private static final int REQ_LOCATION = 9410;
    private static final int REQ_PHOTO = 9411;
    private static final int REQ_EXPORT = 9412;
    private static final int REQ_IMPORT = 9413;
    private static final float MAX_AVERAGE_SAMPLE_ACCURACY_M = 300f;
    private static final long MAX_AVERAGE_SAMPLE_AGE_MS = 5000L;
    private static final float MAX_STATIONARY_SPEED_MPS = 3.5f;
    private static final long RECENT_MAP_LOCATION_MS = 10L * 60L * 1000L;
    private static final long FRESH_SAVE_LOCATION_MS = 45L * 1000L;
    private static final long FRESH_LIVE_LOCATION_MS = 45L * 1000L;
    private static final long PROVISIONAL_LOCATION_MAX_AGE_MS = 2L * 60L * 1000L;
    private static final long NO_FIX_GUIDANCE_DELAY_MS = 15L * 1000L;
    private static final String OFM_STANDARD = "https://tiles.openfreemap.org/styles/bright";
    private static final String OPEN_TOPO_TILE = "https://a.tile.opentopomap.org/{z}/{x}/{y}.png";
    private static final String MAPTERHORN_TERRAIN = "https://tiles.mapterhorn.com/{z}/{x}/{y}.webp";
    private static final double OVERVIEW_CONTEXT_ZOOM = 15.0;
    private static final double SATELLITE_DISPLAY_MAX_ZOOM = 22.0;

    private MapView overviewMapView;
    private MapLibreMap overviewMap;
    private Marker overviewMarker;
    private Bundle mapSavedState;
    private final MbtilesServer offlineServer = new MbtilesServer();
    private String currentMapMode = "standard";
    private boolean overviewStyleInitialized;
    private int overviewStyleRequestId;
    private int overviewStyleLoadedId;
    private TextView overviewLoadingOverlay;
    private LinearLayout recentPointsContainer;
    private TextView overviewWaitingOverlay;

    private LocationManager locationManager;
    private Location currentLocation;
    private boolean gpsRunning;
    private boolean averaging;
    private boolean startAverageAfterPermission;
    private long pendingAverageDurationMs = 20000L;
    private long averageDurationMs = 20000L;
    private long averageStartedAt;
    private Runnable averageProgressRunnable;
    private final Runnable averageFinishRunnable = this::finishAveraging;
    private boolean overviewAutoCenterPending;
    private int satellitesVisible;
    private int satellitesUsed;
    private GnssStatus.Callback gnssCallback;
    private boolean gnssRegistered;
    private TextView qualityValue;
    private TextView readingStateValue;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private LocationListener singleFixListener;
    private final Runnable gpsNoFixRunnable = () -> {
        if (!gpsRunning || hasFreshGnssFix()) return;
        if (qualityValue != null) {
            qualityValue.setText(currentLocation != null ? "Asistida" : "Sin fix");
            qualityValue.setTextColor(currentLocation != null ? Color.rgb(255, 193, 74) : Color.rgb(255, 103, 116));
        }
        if (readingStateValue != null) {
            String sats = satellitesVisible > 0 ? " · " + satellitesVisible + " sat. visibles" : "";
            readingStateValue.setText(currentLocation != null
                    ? "Red asistida · esperando GNSS" + sats
                    : "Sin fix GNSS" + sats + " · prueba con cielo despejado");
        }
        if (overviewWaitingOverlay != null && currentLocation == null) {
            overviewWaitingOverlay.setText("Sin fix GNSS · prueba al aire libre");
            overviewWaitingOverlay.setVisibility(View.VISIBLE);
        }
    };
    private final List<Location> averageSamples = new ArrayList<>();
    private int averagingRejectedSamples;
    private int totalAverageReadings;
    private int maxSatellitesUsedDuringAverage;
    private int maxSatellitesVisibleDuringAverage;
    private long sumSatellitesUsedDuringAverage;
    private int satelliteStatusSamplesDuringAverage;
    private boolean hadGnssFixDuringAverage;
    private Location lastAcceptedAverageSample;
    private float bestAverageAccuracy = Float.NaN;
    private float finalAverageStability = Float.NaN;
    private float finalAverageAccuracy = Float.NaN;
    private float finalMedianReportedAccuracy = Float.NaN;
    private int finalEffectiveSampleCount;
    private int finalAverageSatellitesUsed;
    private String finalAverageQuality = "Sin promedio";
    private int finalValidSampleCount;
    private int finalRejectedSampleCount;
    private long finalAverageDurationSeconds;
    private String pendingPhotoUri = "";
    private TextView photoStatusView;
    private String pendingExportType;

    private LastPosition overviewPosition;
    private TextView mapAttributionView;
    private TextView precisionValue;
    private TextView satellitesValue;
    private TextView timeValue;
    private TextView latValue;
    private TextView lonValue;
    private TextView eastValue;
    private TextView northValue;
    private TextView altitudeValue;
    private TextView readingPrecisionValue;
    private TextView zoneValue;
    private TextView gpsActionLabel;
    private TextView averageActionLabel;
    private ActionCardRefs gpsActionCard;
    private ActionCardRefs saveActionCard;

    private static class ActionCardRefs {
        LinearLayout box;
        FrameLayout iconBox;
        TextView title;
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MapLibre.getInstance(this);
        MapEngineConfig.configure(this);
        mapSavedState = savedInstanceState;
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        // Cada entrada nueva a GPS y mapas abre el mini mapa en el mapa vectorial claro.
        // Una recreación de la misma Activity conserva la capa elegida durante esa sesión.
        if (savedInstanceState == null) {
            currentMapMode = "standard";
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_OVERVIEW_MAP_MODE, currentMapMode).apply();
        } else {
            currentMapMode = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_OVERVIEW_MAP_MODE, "standard");
            if ("hybrid".equals(currentMapMode)) currentMapMode = "labels"; // migración V21
            if ("topo".equals(currentMapMode) || "relief".equals(currentMapMode)) currentMapMode = "topographic";
            if (currentMapMode == null || currentMapMode.trim().isEmpty() || "dark".equals(currentMapMode)) currentMapMode = "standard";
            if (isOverviewImageryMode(currentMapMode) && (!EsriSatellite.isConfigured() || EsriSatellite.isLocked(this))) {
                currentMapMode = "standard";
            }
        }
        long savedAverage = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getLong("average_duration_ms", 20000L);
        averageDurationMs = savedAverage == 10000L || savedAverage == 20000L || savedAverage == 30000L || savedAverage == 60000L ? savedAverage : 20000L;
        NativeUi.styleWindow(this);
        setContentView(buildScreen());
    }

    @Override protected void onStart() {
        super.onStart();
        if (overviewMapView != null) overviewMapView.onStart();
    }

    @Override protected void onResume() {
        super.onResume();
        if (overviewMapView != null) overviewMapView.onResume();
        if (recentPointsContainer != null) {
            recentPointsContainer.removeAllViews();
            recentPointsContainer.addView(recentPointsCard());
        }
        LastPosition latest = readLastPosition();
        if (latest.valid) {
            overviewPosition = latest;
            updateOverviewData(latest);
            if (overviewMap != null && isRecent(latest)) centerOverviewMap(false);
        }
    }

    @Override protected void onPause() {
        stopLocationUpdates(false);
        if (overviewMapView != null) overviewMapView.onPause();
        super.onPause();
    }

    @Override protected void onStop() {
        if (overviewMapView != null) overviewMapView.onStop();
        super.onStop();
    }

    @Override public void onLowMemory() {
        super.onLowMemory();
        if (overviewMapView != null) overviewMapView.onLowMemory();
    }

    @Override protected void onDestroy() {
        stopLocationUpdates(false);
        offlineServer.stop();
        handler.removeCallbacksAndMessages(null);
        if (overviewMapView != null) overviewMapView.onDestroy();
        super.onDestroy();
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (overviewMapView != null) overviewMapView.onSaveInstanceState(outState);
    }

    private View buildScreen() {
        FrameLayout root = NativeUi.screen(this);
        LinearLayout page = NativeUi.column(this);
        page.addView(NativeUi.pageHeader(this, "GPS y mapas",
                "Ubicación, puntos y mapas", v -> finish(), "⌖",
                v -> openFullMap()));

        LinearLayout content = NativeUi.column(this);
        content.setPadding(NativeUi.dp(this, 12), NativeUi.dp(this, 9),
                NativeUi.dp(this, 12), NativeUi.dp(this, 24));

        overviewPosition = readLastPosition();

        View mapCard = buildFunctionalMapCard();
        LinearLayout.LayoutParams mapLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 228));
        mapLp.setMargins(0, 0, 0, NativeUi.dp(this, 9));
        content.addView(mapCard, mapLp);

        content.addView(buildStatusPanel(overviewPosition));
        content.addView(buildPrimaryActions());
        content.addView(buildReadingPanel(overviewPosition));
        content.addView(buildSecondaryActions());
        Button moreTools = new Button(this);
        moreTools.setText("☰  Más herramientas GPS");
        moreTools.setAllCaps(false);
        ResponsiveUi.configureCompactText(moreTools, 14, 11, 2);
        moreTools.setOnClickListener(v -> showMoreTools());
        LinearLayout.LayoutParams moreLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 51));
        moreLp.setMargins(0, 0, 0, NativeUi.dp(this, 9));
        content.addView(moreTools, moreLp);

        content.addView(NativeUi.sectionHeader(this, "◷", "PUNTOS RECIENTES", "Ver todos",
                v -> showPointsPanel()));
        recentPointsContainer = NativeUi.column(this);
        recentPointsContainer.addView(recentPointsCard());
        content.addView(recentPointsContainer);

        page.addView(NativeUi.scroll(this, content), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(page, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return root;
    }

    private View buildFunctionalMapCard() {
        FrameLayout card = new FrameLayout(this);
        card.setBackground(NativeUi.gradient(Color.rgb(5, 34, 69), Color.rgb(2, 18, 37), 18,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 160), this));
        card.setClipToOutline(true);
        card.setElevation(NativeUi.dp(this, 2));

        overviewMapView = new MapView(this);
        overviewMapView.onCreate(mapSavedState);
        overviewMapView.addOnDidFailLoadingMapListener(this::handleOverviewMapLoadFailure);
        // Si el gesto empieza dentro del mini mapa, el ScrollView padre no debe robarlo.
        overviewMapView.setOnTouchListener((view, event) -> {
            int action = event.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE || action == MotionEvent.ACTION_POINTER_DOWN) {
                if (view.getParent() != null) view.getParent().requestDisallowInterceptTouchEvent(true);
            } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                if (view.getParent() != null) view.getParent().requestDisallowInterceptTouchEvent(false);
            }
            return false;
        });
        card.addView(overviewMapView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        overviewWaitingOverlay = NativeUi.text(this, "Esperando ubicación GPS…", 11.8f, true, Color.WHITE);
        overviewWaitingOverlay.setGravity(Gravity.CENTER);
        overviewWaitingOverlay.setPadding(NativeUi.dp(this, 12), NativeUi.dp(this, 7), NativeUi.dp(this, 12), NativeUi.dp(this, 7));
        overviewWaitingOverlay.setBackground(NativeUi.rounded(Color.argb(218, 8, 25, 40), 14, 1,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 125), this));
        overviewWaitingOverlay.setClickable(false);
        overviewWaitingOverlay.setVisibility(overviewPosition != null && overviewPosition.valid ? View.GONE : View.VISIBLE);
        FrameLayout.LayoutParams waitingLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        card.addView(overviewWaitingOverlay, waitingLp);

        overviewLoadingOverlay = NativeUi.text(this, "", 1f, false, Color.TRANSPARENT);
        overviewLoadingOverlay.setGravity(Gravity.CENTER);
        overviewLoadingOverlay.setBackgroundColor(Color.argb(118, 18, 46, 66));
        overviewLoadingOverlay.setClickable(false);
        overviewLoadingOverlay.setVisibility(View.VISIBLE);
        card.addView(overviewLoadingOverlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        overviewMapView.getMapAsync(mapLibreMap -> {
            overviewMap = mapLibreMap;
            overviewMap.getUiSettings().setLogoEnabled(false);
            overviewMap.getUiSettings().setAttributionEnabled(true);
            overviewMap.getUiSettings().setAttributionGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
            overviewMap.getUiSettings().setAttributionMargins(0, 0, 0, NativeUi.dp(this, 4));
            overviewMap.getUiSettings().setCompassEnabled(false);
            overviewMap.getUiSettings().setAllGesturesEnabled(true);
            overviewMap.setMinZoomPreference(1.0);
            overviewMap.setMaxZoomPreference(20.0);
            applyOverviewMapMode(currentMapMode);
        });

        ImageButton layers = miniMapIcon(R.drawable.ic_map_layers, "Capas", v -> showOverviewLayers());
        FrameLayout.LayoutParams layersLp = new FrameLayout.LayoutParams(
                NativeUi.dp(this, 40), NativeUi.dp(this, 40), Gravity.END | Gravity.TOP);
        layersLp.setMargins(0, NativeUi.dp(this, 9), NativeUi.dp(this, 9), 0);
        card.addView(layers, layersLp);

        ImageButton locate = miniMapIcon(R.drawable.ic_map_location, "Centrar ubicación", v -> centerOrStartGps());
        FrameLayout.LayoutParams locateLp = new FrameLayout.LayoutParams(
                NativeUi.dp(this, 40), NativeUi.dp(this, 40), Gravity.END | Gravity.BOTTOM);
        locateLp.setMargins(0, 0, NativeUi.dp(this, 9), NativeUi.dp(this, 9));
        card.addView(locate, locateLp);

        TextView expand = NativeUi.text(this, "⛶", 19f, true, Color.WHITE);
        expand.setGravity(Gravity.CENTER);
        expand.setContentDescription("Abrir mapa completo");
        expand.setBackground(NativeUi.rounded(NativeUi.withAlpha(Color.rgb(36, 41, 48), 242), 20, 1,
                NativeUi.withAlpha(Color.WHITE, 90), this));
        expand.setElevation(NativeUi.dp(this, 4));
        expand.setOnClickListener(v -> openFullMap());
        FrameLayout.LayoutParams expandLp = new FrameLayout.LayoutParams(
                NativeUi.dp(this, 40), NativeUi.dp(this, 40), Gravity.START | Gravity.BOTTOM);
        expandLp.setMargins(NativeUi.dp(this, 9), 0, 0, NativeUi.dp(this, 9));
        card.addView(expand, expandLp);

        // Mini mapa deliberadamente limpio: sin precisión, estado GNSS ni textos
        // superpuestos. La atribución del proveedor se conserva mediante el
        // control nativo de MapLibre para no ensuciar la imagen.
        mapAttributionView = null;
        return card;
    }

    private ImageButton miniMapIcon(int drawable, String description, View.OnClickListener click) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(drawable);
        b.setColorFilter(Color.WHITE);
        b.setScaleType(android.widget.ImageView.ScaleType.CENTER);
        b.setPadding(NativeUi.dp(this, 9), NativeUi.dp(this, 9), NativeUi.dp(this, 9), NativeUi.dp(this, 9));
        b.setContentDescription(description);
        b.setBackground(NativeUi.rounded(NativeUi.withAlpha(Color.rgb(36, 41, 48), 242), 20, 1,
                NativeUi.withAlpha(Color.WHITE, 90), this));
        b.setElevation(NativeUi.dp(this, 4));
        b.setOnClickListener(click);
        return b;
    }

    private void applyOverviewMapMode(String mode) {
        if (overviewMap == null) return;
        if (mode == null || mode.trim().isEmpty()) mode = "standard";
        if ("topo".equals(mode) || "relief".equals(mode)) mode = "topographic";
        if ("dark".equals(mode)) mode = "standard";
        if ("hybrid".equals(mode)) mode = "labels";
        if (!("standard".equals(mode) || "satellite".equals(mode) || "labels".equals(mode)
                || "topographic".equals(mode) || "terrain".equals(mode) || "offline".equals(mode))) {
            mode = "standard";
        }
        final CameraPosition preservedCamera = overviewStyleInitialized ? overviewMap.getCameraPosition() : null;
        if (!"offline".equals(mode)) offlineServer.stop();

        if ("offline".equals(mode)) {
            currentMapMode = "offline";
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_OVERVIEW_MAP_MODE, currentMapMode).apply();
            overviewMap.setMaxZoomPreference(20.0);
            setOverviewAttribution("Offline · atribución del paquete");
            if (applyOverviewOfflineStyle(preservedCamera)) return;
            Toast.makeText(this, "No hay MBTiles cargado. Se mostrará Mapa.", Toast.LENGTH_SHORT).show();
            useOverviewStandardMap(preservedCamera);
            return;
        }
        if (isOverviewImageryMode(mode)) {
            requestOverviewImageryMode(mode, preservedCamera);
            return;
        }
        if ("topographic".equals(mode)) {
            useOverviewTopographicMap(preservedCamera);
            return;
        }
        if ("terrain".equals(mode)) {
            useOverviewTerrainMap(preservedCamera);
            return;
        }
        useOverviewStandardMap(preservedCamera);
    }

    private void useOverviewStandardMap(CameraPosition preservedCamera) {
        currentMapMode = "standard";
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_OVERVIEW_MAP_MODE, currentMapMode).apply();
        if (overviewMap == null) return;
        overviewMap.setMaxZoomPreference(20.0);
        setOverviewAttribution("© OpenStreetMap contributors · OpenFreeMap · OpenMapTiles");
        loadOverviewRemoteStyle(OFM_STANDARD, normalizeOverviewCamera(preservedCamera, false), "standard");
    }

    private void useOverviewTopographicMap(CameraPosition preservedCamera) {
        currentMapMode = "topographic";
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_OVERVIEW_MAP_MODE, currentMapMode).apply();
        if (overviewMap == null) return;
        overviewMap.setMaxZoomPreference(18.0);
        setOverviewAttribution("© OpenStreetMap contributors, SRTM · OpenTopoMap CC-BY-SA");
        loadOverviewTopographicStyle(normalizeOverviewCamera(preservedCamera, false));
    }

    private void useOverviewTerrainMap(CameraPosition preservedCamera) {
        currentMapMode = "terrain";
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_OVERVIEW_MAP_MODE, currentMapMode).apply();
        if (overviewMap == null) return;
        overviewMap.setMaxZoomPreference(18.0);
        setOverviewAttribution("OpenTopoMap + © Mapterhorn terrain");
        loadOverviewTerrainStyle(normalizeOverviewCamera(preservedCamera, true));
    }

    private void requestOverviewImageryMode(String requestedMode, CameraPosition preservedCamera) {
        final CameraPosition imageryCamera = normalizeOverviewCamera(preservedCamera, false);
        showOverviewLoading("Comprobando satélite…");
        EsriSatellite.checkAvailability(this, result -> {
            if (isFinishing() || overviewMap == null) return;
            if (!result.available) {
                hideOverviewLoading();
                Toast.makeText(this, result.message, Toast.LENGTH_LONG).show();
                useOverviewStandardMap(imageryCamera);
                return;
            }
            currentMapMode = requestedMode;
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_OVERVIEW_MAP_MODE, currentMapMode).apply();
            overviewMap.setMaxZoomPreference(SATELLITE_DISPLAY_MAX_ZOOM);
            if ("labels".equals(currentMapMode)) {
                setOverviewAttribution(EsriSatellite.attribution(this));
                loadOverviewLabelsStyle(imageryCamera);
            } else {
                setOverviewAttribution(EsriSatellite.attribution(this));
                loadOverviewSatelliteStyle(imageryCamera, false);
            }
        });
    }

    private boolean isOverviewImageryMode(String mode) {
        return "satellite".equals(mode) || "labels".equals(mode);
    }

    private void loadOverviewRemoteStyle(String uri, CameraPosition preservedCamera, String requestedMode) {
        final int requestId = ++overviewStyleRequestId;
        overviewStyleInitialized = false;
        showOverviewLoading("Cargando " + mapModeLabel(requestedMode).toLowerCase(Locale.ROOT) + "…");
        overviewMap.setStyle(new Style.Builder().fromUri(uri), style -> onOverviewStyleReady(preservedCamera, requestId));
        handler.postDelayed(() -> {
            if (overviewMap == null || requestId != overviewStyleRequestId || overviewStyleLoadedId == requestId) return;
            hideOverviewLoading();
            setMapHint("Mapa base esperando conexión");
        }, 5500L);
    }

    private void loadOverviewTopographicStyle(CameraPosition preservedCamera) {
        final int requestId = ++overviewStyleRequestId;
        overviewStyleInitialized = false;
        showOverviewLoading("Cargando topográfico…");
        String styleJson = "{\"version\":8,\"sources\":{\"topo\":{\"type\":\"raster\",\"tiles\":[\""
                + OPEN_TOPO_TILE + "\"],\"tileSize\":256,\"minzoom\":0,\"maxzoom\":17,\"attribution\":\"© OpenStreetMap contributors, SRTM | OpenTopoMap (CC-BY-SA)\"}},"
                + "\"layers\":[{\"id\":\"topo\",\"type\":\"raster\",\"source\":\"topo\",\"paint\":{\"raster-fade-duration\":0}}]}";
        overviewMap.setStyle(new Style.Builder().fromJson(styleJson), style -> onOverviewStyleReady(preservedCamera, requestId));
        handler.postDelayed(() -> {
            if (overviewMap == null || requestId != overviewStyleRequestId || overviewStyleLoadedId == requestId) return;
            hideOverviewLoading();
            setMapHint("Topográfico esperando conexión");
        }, 6500L);
    }

    private void loadOverviewTerrainStyle(CameraPosition preservedCamera) {
        final int requestId = ++overviewStyleRequestId;
        overviewStyleInitialized = false;
        showOverviewLoading("Cargando terreno 3D…");
        String styleJson = "{\"version\":8,"
                + "\"sources\":{"
                + "\"topo\":{\"type\":\"raster\",\"tiles\":[\"" + OPEN_TOPO_TILE + "\"],\"tileSize\":256,\"minzoom\":0,\"maxzoom\":17,\"attribution\":\"© OpenStreetMap contributors, SRTM | OpenTopoMap (CC-BY-SA)\"},"
                + "\"dem\":{\"type\":\"raster-dem\",\"tiles\":[\"" + MAPTERHORN_TERRAIN + "\"],\"tileSize\":512,\"minzoom\":0,\"maxzoom\":12,\"encoding\":\"terrarium\",\"attribution\":\"© Mapterhorn terrain data\"}},"
                + "\"terrain\":{\"source\":\"dem\",\"exaggeration\":1.18},"
                + "\"layers\":["
                + "{\"id\":\"topo\",\"type\":\"raster\",\"source\":\"topo\",\"paint\":{\"raster-opacity\":0.88,\"raster-saturation\":-0.12,\"raster-contrast\":0.10}},"
                + "{\"id\":\"terrain-hillshade\",\"type\":\"hillshade\",\"source\":\"dem\",\"paint\":{\"hillshade-exaggeration\":0.82,\"hillshade-shadow-color\":\"#5d4127\",\"hillshade-highlight-color\":\"#fff3cf\",\"hillshade-accent-color\":\"#9a7a4d\"}}]}";
        overviewMap.setStyle(new Style.Builder().fromJson(styleJson), style -> onOverviewStyleReady(preservedCamera, requestId));
        handler.postDelayed(() -> {
            if (overviewMap == null || requestId != overviewStyleRequestId || overviewStyleLoadedId == requestId) return;
            hideOverviewLoading();
            setMapHint("Terreno esperando conexión");
        }, 7000L);
    }

    private CameraPosition normalizeOverviewCamera(CameraPosition camera, boolean terrain) {
        if (camera == null) return null;
        CameraPosition.Builder builder = new CameraPosition.Builder(camera);
        if (terrain) builder.tilt(Math.max(45.0, camera.tilt));
        else if (camera.tilt > 1.0) builder.tilt(0.0);
        return builder.build();
    }

    private void loadOverviewLabelsStyle(CameraPosition preservedCamera) {
        final int requestId = ++overviewStyleRequestId;
        overviewStyleInitialized = false;
        overviewMap.setMaxZoomPreference(SATELLITE_DISPLAY_MAX_ZOOM);
        showOverviewLoading("Cargando calles y lugares…");
        overviewMap.setStyle(new Style.Builder().fromJson(EsriSatellite.hybridStyleJson()),
                style -> onOverviewStyleReady(clampOverviewCameraForMode(preservedCamera), requestId));
    }

    private void loadOverviewSatelliteStyle(CameraPosition preservedCamera, boolean fallback) {
        final int requestId = ++overviewStyleRequestId;
        overviewStyleInitialized = false;
        overviewMap.setMaxZoomPreference(SATELLITE_DISPLAY_MAX_ZOOM);
        showOverviewLoading(fallback ? "Abriendo satélite…" : "Cargando satélite…");
        overviewMap.setStyle(new Style.Builder().fromJson(EsriSatellite.satelliteStyleJson()),
                style -> onOverviewStyleReady(clampOverviewCameraForMode(preservedCamera), requestId));
    }

    private CameraPosition clampOverviewCameraForMode(CameraPosition camera) {
        if (camera == null || !isOverviewImageryMode(currentMapMode) || camera.zoom <= SATELLITE_DISPLAY_MAX_ZOOM) return camera;
        return new CameraPosition.Builder(camera)
                .zoom(SATELLITE_DISPLAY_MAX_ZOOM)
                .build();
    }

    private void onOverviewStyleReady(CameraPosition preservedCamera, int requestId) {
        if (requestId != overviewStyleRequestId) return;
        overviewStyleLoadedId = requestId;
        overviewStyleInitialized = true;
        overviewMarker = null;
        if (overviewMap != null) overviewMap.getUiSettings().setAllGesturesEnabled(true);
        if (preservedCamera != null) {
            CameraPosition safeCamera = clampOverviewCameraForMode(preservedCamera);
            overviewMap.moveCamera(CameraUpdateFactory.newCameraPosition(safeCamera));
            if (overviewPosition != null && overviewPosition.valid) {
                hideOverviewWaiting();
                drawOverviewMarker(overviewPosition.latitude, overviewPosition.longitude);
            }
        } else {
            centerOverviewMap(false);
        }
        handler.postDelayed(this::hideOverviewLoading, 650L);
    }

    private void showOverviewLoading(String text) {
        if (overviewLoadingOverlay == null) return;
        overviewLoadingOverlay.setText(text == null ? "Cargando mapa…" : text);
        overviewLoadingOverlay.setVisibility(View.VISIBLE);
    }

    private void hideOverviewLoading() {
        if (overviewLoadingOverlay != null) overviewLoadingOverlay.setVisibility(View.GONE);
    }

    private void showOverviewWaiting() {
        if (overviewWaitingOverlay != null) {
            overviewWaitingOverlay.setText(gpsRunning ? "Buscando ubicación GPS…" : "Esperando ubicación GPS…");
            overviewWaitingOverlay.setVisibility(View.VISIBLE);
        }
    }

    private void hideOverviewWaiting() {
        if (overviewWaitingOverlay != null) overviewWaitingOverlay.setVisibility(View.GONE);
    }

    private boolean applyOverviewOfflineStyle(CameraPosition preservedCamera) {
        String path = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_OFFLINE_PATH, "");
        if (path == null || path.trim().isEmpty()) return false;
        File file = new File(path);
        if (!file.isFile()) return false;
        try {
            offlineServer.start(file);
            String url = "http://127.0.0.1:" + offlineServer.getPort() + "/tiles/{z}/{x}/{y}." + offlineServer.getFormat();
            String attribution = escapeJson(offlineServer.getAttribution());
            String style = "{\"version\":8,\"sources\":{\"offline\":{\"type\":\"raster\",\"tiles\":[\"" + url
                    + "\"],\"tileSize\":256,\"minzoom\":" + offlineServer.getMinZoom() + ",\"maxzoom\":" + offlineServer.getMaxZoom()
                    + ",\"attribution\":\"" + attribution + "\"}},\"layers\":[{\"id\":\"background\",\"type\":\"background\",\"paint\":{\"background-color\":\"#091827\"}},{\"id\":\"offline\",\"type\":\"raster\",\"source\":\"offline\",\"paint\":{\"raster-fade-duration\":0}}]}";
            final int requestId = ++overviewStyleRequestId;
            overviewStyleInitialized = false;
            showOverviewLoading("Abriendo mapa offline…");
            overviewMap.setStyle(new Style.Builder().fromJson(style), loaded -> onOverviewStyleReady(preservedCamera, requestId));
            return true;
        } catch (Exception e) {
            offlineServer.stop();
            return false;
        }
    }

    private void handleOverviewMapLoadFailure(String errorMessage) {
        runOnUiThread(() -> {
            hideOverviewLoading();
            if (isOverviewImageryMode(currentMapMode) && EsriSatellite.looksLikeAccessFailure(errorMessage)) {
                String message = EsriSatellite.accessFailureMessage(errorMessage);
                if (EsriSatellite.shouldLockForError(errorMessage)) EsriSatellite.markLocked(this, message);
                else EsriSatellite.clearLocked(this);
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                CameraPosition camera = overviewMap == null ? null : overviewMap.getCameraPosition();
                useOverviewStandardMap(camera);
                return;
            }
            if ("satellite".equals(currentMapMode)) setMapHint("Satélite · conexión inestable");
            else if ("labels".equals(currentMapMode)) setMapHint("Calles · conexión inestable");
            else if ("topographic".equals(currentMapMode)) setMapHint("Topográfico · conexión inestable");
            else if ("terrain".equals(currentMapMode)) setMapHint("Terreno · conexión inestable");
            else setMapHint("Mapa · conexión inestable");
        });
    }

    private String escapeJson(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", " ");
    }

    private String mapModeLabel(String mode) {
        if ("satellite".equals(mode)) return "Satélite";
        if ("labels".equals(mode)) return "Calles";
        if ("topographic".equals(mode) || "relief".equals(mode) || "topo".equals(mode)) return "Topográfico";
        if ("terrain".equals(mode)) return "Terreno";
        if ("offline".equals(mode)) return "Offline";
        return "Mapa";
    }

    private void showOverviewLayers() {
        MapLayerPicker.show(this, currentMapMode, new MapLayerPicker.Listener() {
            @Override public void onLayerSelected(String mode) {
                applyOverviewMapMode(mode);
            }

            @Override public void onManageOffline() {
                startActivity(new Intent(GpsOverviewActivity.this, OfflineMapActivity.class));
            }
        });
    }

    private void centerOverviewMap(boolean animate) {
        if (overviewMap == null) return;
        Location live = currentLocation;
        if (live != null && locationAgeMs(live) <= RECENT_MAP_LOCATION_MS) {
            moveOverviewCamera(live.getLatitude(), live.getLongitude(), OVERVIEW_CONTEXT_ZOOM, animate);
            drawOverviewMarker(live.getLatitude(), live.getLongitude());
            setMapHint("±" + format1(live.hasAccuracy() ? live.getAccuracy() : 0f) + " m");
            return;
        }
        if (overviewPosition != null && overviewPosition.valid) {
            moveOverviewCamera(overviewPosition.latitude, overviewPosition.longitude, OVERVIEW_CONTEXT_ZOOM, animate);
            drawOverviewMarker(overviewPosition.latitude, overviewPosition.longitude);
            String prefix = isRecent(overviewPosition) ? "" : "Última ubicación · ";
            setMapHint(prefix + (overviewPosition.accuracy > 0 ? "±" + format1(overviewPosition.accuracy) + " m" : "posición guardada"));
            return;
        }
        if (overviewMarker != null) {
            try { overviewMap.removeMarker(overviewMarker); } catch (Exception ignored) { }
            overviewMarker = null;
        }
        showOverviewWaiting();
        setMapHint("");
    }

    private void moveOverviewCamera(double lat, double lon, double zoom, boolean animate) {
        hideOverviewWaiting();
        CameraPosition camera = new CameraPosition.Builder().target(new LatLng(lat, lon)).zoom(zoom).bearing(0).tilt("terrain".equals(currentMapMode) ? 45.0 : 0.0).build();
        if (animate) overviewMap.animateCamera(CameraUpdateFactory.newCameraPosition(camera), 420);
        else overviewMap.moveCamera(CameraUpdateFactory.newCameraPosition(camera));
    }

    private void drawOverviewMarker(double lat, double lon) {
        if (overviewMap == null) return;
        if (overviewMarker != null) {
            try { overviewMap.removeMarker(overviewMarker); } catch (Exception ignored) { }
        }
        LatLng center = new LatLng(lat, lon);
        overviewMarker = overviewMap.addMarker(new MarkerOptions()
                .position(center)
                .title("Posición actual")
                .icon(IconFactory.getInstance(this).fromBitmap(createOverviewLocationDotBitmap())));
    }

    private Bitmap createOverviewLocationDotBitmap() {
        int size = NativeUi.dp(this, 22);
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        float center = size / 2f;
        paint.setColor(Color.argb(70, 66, 133, 244));
        canvas.drawCircle(center, center, NativeUi.dp(this, 8), paint);
        paint.setColor(Color.WHITE);
        canvas.drawCircle(center, center, NativeUi.dp(this, 5), paint);
        paint.setColor(Color.rgb(66, 133, 244));
        canvas.drawCircle(center, center, NativeUi.dp(this, 4), paint);
        return bitmap;
    }

    private void setMapHint(String text) {
        // V20: el mini mapa no muestra textos superpuestos. Los estados se
        // presentan en controles externos (Calidad, Precisión, Hora, botón
        // Promediar y Datos GNSS).
    }

    private void setOverviewAttribution(String value) {
        if (mapAttributionView != null) mapAttributionView.setText(value == null ? "" : value);
    }


    private void centerOrStartGps() {
        if (currentLocation != null && locationAgeMs(currentLocation) <= RECENT_MAP_LOCATION_MS) {
            overviewAutoCenterPending = true;
            centerOverviewMap(true);
            overviewAutoCenterPending = false;
        } else {
            overviewAutoCenterPending = true;
            startGps();
        }
    }


    private View buildStatusPanel(LastPosition p) {
        LinearLayout panel = NativeUi.row(this);
        panel.setPadding(NativeUi.dp(this, 5), NativeUi.dp(this, 5),
                NativeUi.dp(this, 5), NativeUi.dp(this, 5));
        panel.setBackground(NativeUi.gradient(NativeUi.CARD_LIGHT, NativeUi.CARD_DARK, 15,
                NativeUi.withAlpha(NativeUi.BORDER, 130), this));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 72));
        plp.setMargins(0, 0, 0, NativeUi.dp(this, 9));
        panel.setLayoutParams(plp);

        qualityValue = metric(panel, "Calidad", qualityLabel(p), qualityColor(p));
        precisionValue = metric(panel, "Precisión", p.valid ? "±" + format1(p.accuracy) + " m" : "—", NativeUi.BLUE_LIGHT);
        // Los satélites quedan fuera del panel principal. Se consultan en
        // “Datos GNSS”; así el mini mapa y su zona inmediata no se llenan de
        // cifras técnicas durante el trabajo de campo.
        satellitesValue = null;
        timeValue = metric(panel, "Hora", p.valid ? formatTime(p.timestamp) : "—", Color.rgb(255, 198, 82));
        return panel;
    }

    private TextView metric(LinearLayout parent, String title, String value, int color) {
        LinearLayout box = NativeUi.column(this);
        box.setGravity(Gravity.CENTER);
        box.setPadding(NativeUi.dp(this, 5), NativeUi.dp(this, 6), NativeUi.dp(this, 5), NativeUi.dp(this, 6));
        box.setBackground(NativeUi.rounded(NativeUi.withAlpha(NativeUi.BG_DEEP, 120), 12, 1,
                NativeUi.withAlpha(NativeUi.BORDER, 85), this));
        TextView t = NativeUi.text(this, title, 10.2f, false, NativeUi.SUB);
        t.setGravity(Gravity.CENTER);
        TextView v = NativeUi.text(this, value, 12.2f, true, color);
        v.setGravity(Gravity.CENTER);
        v.setMaxLines(2);
        box.addView(t);
        box.addView(v);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lp.setMargins(NativeUi.dp(this, 2), NativeUi.dp(this, 2), NativeUi.dp(this, 2), NativeUi.dp(this, 2));
        parent.addView(box, lp);
        return v;
    }

    private View buildPrimaryActions() {
        LinearLayout row = NativeUi.row(this);
        View gpsCard = actionCard("play", "Iniciar\nGPS",
                Color.rgb(61, 218, 144), Color.rgb(15, 88, 63), Color.rgb(9, 45, 35),
                v -> startOrStopGps());
        gpsActionCard = (ActionCardRefs) gpsCard.getTag();
        gpsActionLabel = gpsActionCard.title;
        row.addView(gpsCard, actionLp(false, true));
        View avgCard = actionCard("clock", "Promediar",
                Color.rgb(145, 111, 255), Color.rgb(60, 39, 124), Color.rgb(26, 18, 56),
                v -> onAverageAction());
        averageActionLabel = ((ActionCardRefs) avgCard.getTag()).title;
        row.addView(avgCard, actionLp(true, true));
        View saveCard = actionCard("pin", "Guardar\npunto",
                Color.rgb(255, 182, 74), Color.rgb(114, 66, 21), Color.rgb(52, 30, 10),
                v -> showSavePointDialog());
        saveActionCard = (ActionCardRefs) saveCard.getTag();
        row.addView(saveCard, actionLp(true, false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 96));
        lp.setMargins(0, 0, 0, NativeUi.dp(this, 9));
        row.setLayoutParams(lp);
        return row;
    }

    private View buildReadingPanel(LastPosition p) {
        LinearLayout panel = NativeUi.column(this);
        panel.setPadding(NativeUi.dp(this, 14), NativeUi.dp(this, 13), NativeUi.dp(this, 14), NativeUi.dp(this, 13));
        panel.setBackground(NativeUi.gradient(NativeUi.CARD_LIGHT, NativeUi.CARD_DARK, 18,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 135), this));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        plp.setMargins(0, 0, 0, NativeUi.dp(this, 12));
        panel.setLayoutParams(plp);

        LinearLayout head = NativeUi.row(this);
        TextView title = NativeUi.text(this, "⌁  LECTURA ACTUAL", 15.5f, true, NativeUi.TEXT);
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        readingStateValue = NativeUi.text(this, p.valid ? "●  " + relativeTime(p.timestamp) : "Sin lectura", 11.5f, true,
                p.valid ? Color.rgb(53, 220, 145) : NativeUi.SUB);
        head.addView(readingStateValue);
        panel.addView(head);

        CoordinateUtils.Utm utm = p.valid ? CoordinateUtils.toUtm(p.latitude, p.longitude) : null;
        LinearLayout row1 = NativeUi.row(this);
        latValue = readingCell(row1, "Latitud", p.valid ? formatGeographic(p.latitude, true) : "Sin lectura", true);
        lonValue = readingCell(row1, "Longitud", p.valid ? formatGeographic(p.longitude, false) : "Sin lectura", false);
        panel.addView(row1);

        LinearLayout row2 = NativeUi.row(this);
        eastValue = readingCell(row2, "Este UTM", utm != null && utm.valid ? format3(utm.easting) + " m" : "Sin lectura", true);
        northValue = readingCell(row2, "Norte UTM", utm != null && utm.valid ? format3(utm.northing) + " m" : "Sin lectura", false);
        panel.addView(row2);

        LinearLayout row3 = NativeUi.row(this);
        altitudeValue = readingCell(row3, "Altitud GNSS", !Float.isNaN(p.altitudeM) ? adjustedAltitude(p.altitudeM) : "No disponible", true);
        readingPrecisionValue = readingCell(row3, "Precisión", p.valid ? "±" + format1(p.accuracy) + " m" : "Sin lectura", false);
        panel.addView(row3);

        LinearLayout row4 = NativeUi.row(this);
        zoneValue = readingCell(row4, "Zona UTM", utm != null && utm.valid ? CoordinateUtils.zoneWithBand(p.latitude, p.longitude) : "Sin lectura", true);
        readingCell(row4, "Datum", "WGS84 / UTM", false);
        panel.addView(row4);
        return panel;
    }

    private TextView readingCell(LinearLayout row, String title, String value, boolean left) {
        LinearLayout box = NativeUi.column(this);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(NativeUi.dp(this, 9), NativeUi.dp(this, 6), NativeUi.dp(this, 7), NativeUi.dp(this, 6));
        box.setBackground(NativeUi.rounded(NativeUi.withAlpha(NativeUi.BG_DEEP, 125), 10, 1,
                NativeUi.withAlpha(NativeUi.BORDER, 85), this));
        TextView t = NativeUi.text(this, title, 9.5f, false, NativeUi.SUB);
        TextView v = NativeUi.text(this, value, 12.1f, true, NativeUi.TEXT);
        v.setPadding(0, NativeUi.dp(this, 2), 0, 0);
        v.setSingleLine(true);
        box.addView(t);
        box.addView(v);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, NativeUi.dp(this, 58), 1f);
        lp.setMargins(left ? 0 : NativeUi.dp(this, 4), NativeUi.dp(this, 4), left ? NativeUi.dp(this, 4) : 0, 0);
        row.addView(box, lp);
        return v;
    }

    private View buildSecondaryActions() {
        LinearLayout row = NativeUi.row(this);
        row.setBaselineAligned(false);
        row.addView(actionCard("bookmark", "Puntos",
                Color.rgb(80, 198, 255), Color.rgb(17, 74, 112), Color.rgb(9, 38, 58),
                v -> showPointsPanel()), actionLp(false, true));
        row.addView(actionCard("satellite", "Datos GNSS",
                Color.rgb(83, 229, 142), Color.rgb(15, 86, 57), Color.rgb(8, 41, 30),
                v -> startActivity(new Intent(this, GnssQualityActivity.class))), actionLp(true, true));
        row.addView(actionCard("file", "Exportar",
                Color.rgb(84, 229, 205), Color.rgb(12, 87, 80), Color.rgb(8, 41, 38),
                v -> showExportPanel()), actionLp(true, false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 88));
        lp.setMargins(0, 0, 0, NativeUi.dp(this, 7));
        row.setLayoutParams(lp);
        return row;
    }

    private LinearLayout.LayoutParams actionLp(boolean leftMargin, boolean rightMargin) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lp.setMargins(leftMargin ? NativeUi.dp(this, 4) : 0, 0,
                rightMargin ? NativeUi.dp(this, 4) : 0, 0);
        return lp;
    }

    private View actionCard(String icon, String label, int accentColor, int iconBgStart, int iconBgEnd, View.OnClickListener click) {
        LinearLayout box = NativeUi.column(this);
        box.setPadding(NativeUi.dp(this, 8), NativeUi.dp(this, 9), NativeUi.dp(this, 8), NativeUi.dp(this, 8));
        box.setGravity(Gravity.CENTER);
        box.setBackground(NativeUi.gradient(NativeUi.CARD_LIGHT, NativeUi.CARD_DARK, 14,
                NativeUi.withAlpha(NativeUi.BORDER, 155), this));
        box.setOnClickListener(click);
        FrameLayout iconBox = buildActionIcon(icon, accentColor, false);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(NativeUi.dp(this, 38), NativeUi.dp(this, 38));
        box.addView(iconBox, iconLp);
        TextView title = NativeUi.text(this, label, 12.4f, true, NativeUi.TEXT);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, NativeUi.dp(this, 6), 0, 0);
        title.setLineSpacing(0f, 1.0f);
        title.setMaxLines(2);
        box.addView(title);
        ActionCardRefs refs = new ActionCardRefs();
        refs.box = box;
        refs.iconBox = iconBox;
        refs.title = title;
        box.setTag(refs);
        return box;
    }

    private FrameLayout buildActionIcon(String icon, int glyphColor, boolean dimmed) {
        FrameLayout box = new FrameLayout(this);
        int borderColor = NativeUi.withAlpha(NativeUi.BORDER, dimmed ? 85 : 115);
        box.setBackground(NativeUi.gradient(Color.rgb(21, 43, 77), Color.rgb(11, 28, 56), 15, borderColor, this));
        NativeUi.IconGlyphView glyph = new NativeUi.IconGlyphView(this, icon);
        glyph.setGlyphColor(dimmed ? Color.rgb(122, 135, 162) : glyphColor);
        glyph.setAlpha(dimmed ? 0.78f : 1f);
        int margin = NativeUi.dp(this, 10);
        FrameLayout.LayoutParams glp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        glp.setMargins(margin, margin, margin, margin);
        box.addView(glyph, glp);
        return box;
    }

    private void setActionCardIcon(ActionCardRefs refs, String icon, int glyphColor, boolean dimmed) {
        if (refs == null || refs.iconBox == null) return;
        ViewGroup parent = (ViewGroup) refs.iconBox.getParent();
        if (parent == null) return;
        int index = parent.indexOfChild(refs.iconBox);
        ViewGroup.LayoutParams existingLp = refs.iconBox.getLayoutParams();
        parent.removeView(refs.iconBox);
        FrameLayout replacement = buildActionIcon(icon, glyphColor, dimmed);
        parent.addView(replacement, index, existingLp);
        refs.iconBox = replacement;
    }

    private View recentPointsCard() {
        LinearLayout card = NativeUi.column(this);
        card.setBackground(NativeUi.gradient(NativeUi.CARD_LIGHT, NativeUi.CARD_DARK, 18,
                NativeUi.withAlpha(NativeUi.BORDER, 165), this));
        List<PointRow> points = readRecentPoints(3);
        if (points.isEmpty()) {
            TextView empty = NativeUi.text(this,
                    "Todavía no hay puntos. Usa Puntos → Crear punto manual o Guarda una lectura GPS.",
                    13.2f, false, NativeUi.SUB);
            empty.setPadding(NativeUi.dp(this, 16), NativeUi.dp(this, 18),
                    NativeUi.dp(this, 16), NativeUi.dp(this, 18));
            card.addView(empty);
            return card;
        }
        for (int i = 0; i < points.size(); i++) {
            PointRow point = points.get(i);
            card.addView(recentRow(point));
            if (i < points.size() - 1) {
                View divider = new View(this);
                divider.setBackgroundColor(NativeUi.withAlpha(NativeUi.BORDER, 80));
                card.addView(divider, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 1)));
            }
        }
        return card;
    }

    private View recentRow(PointRow point) {
        LinearLayout row = NativeUi.row(this);
        row.setPadding(NativeUi.dp(this, 12), NativeUi.dp(this, 13),
                NativeUi.dp(this, 10), NativeUi.dp(this, 13));
        row.setOnClickListener(v -> openPointOnMap(point));
        NativeUi.IconGlyphView icon = new NativeUi.IconGlyphView(this, "pin");
        row.addView(icon, new LinearLayout.LayoutParams(NativeUi.dp(this, 38), NativeUi.dp(this, 38)));
        LinearLayout labels = NativeUi.column(this);
        labels.setPadding(NativeUi.dp(this, 9), 0, NativeUi.dp(this, 5), 0);
        labels.addView(NativeUi.text(this, point.symbol + "  " + point.name, 14.5f, true, NativeUi.TEXT));
        TextView sub = NativeUi.text(this, point.summary, 11.2f, false, NativeUi.SUB);
        sub.setSingleLine(true);
        labels.addView(sub);
        row.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView time = NativeUi.text(this, point.time + "  ›", 11.5f, false, NativeUi.SUB);
        row.addView(time);
        return row;
    }

    private void startOrStopGps() {
        if (gpsRunning) {
            stopLocationUpdates(true);
        } else {
            startGps();
        }
    }

    private void startGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
            return;
        }
        if (locationManager == null) {
            Toast.makeText(this, "Servicio de ubicación no disponible.", Toast.LENGTH_LONG).show();
            return;
        }
        boolean gpsEnabled = false;
        try { gpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER); } catch (Exception ignored) { }
        if (!gpsEnabled) {
            new AlertDialog.Builder(this)
                    .setTitle("Activar ubicación")
                    .setMessage("Activa la ubicación del teléfono para obtener una lectura GPS/GNSS.")
                    .setPositiveButton("Abrir ajustes", (d, w) -> startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)))
                    .setNegativeButton("Cancelar", null)
                    .show();
            return;
        }
        try {
            locationManager.removeUpdates(this);
            handler.removeCallbacks(gpsNoFixRunnable);
            currentLocation = null;
            satellitesVisible = 0;
            satellitesUsed = 0;
            gpsRunning = true;
            overviewAutoCenterPending = true;
            updateActionLabels();
            showGpsSearchingState();

            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this);
            try {
                if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                    locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1400L, 0f, this);
            } catch (Exception ignored) { }

            registerGnssStatus();
            requestImmediateGpsFix();
            useRecentLastKnownLocation();
            handler.postDelayed(gpsNoFixRunnable, NO_FIX_GUIDANCE_DELAY_MS);
        } catch (SecurityException e) {
            gpsRunning = false;
            handler.removeCallbacks(gpsNoFixRunnable);
            updateActionLabels();
            Toast.makeText(this, "Permite ubicación precisa para usar el GPS.", Toast.LENGTH_LONG).show();
        }
    }

    private void stopLocationUpdates(boolean showMessage) {
        if (locationManager != null) {
            try { locationManager.removeUpdates(this); } catch (Exception ignored) { }
            if (singleFixListener != null) {
                try { locationManager.removeUpdates(singleFixListener); } catch (Exception ignored) { }
            }
        }
        unregisterGnssStatus();
        handler.removeCallbacks(gpsNoFixRunnable);
        gpsRunning = false;
        if (averaging) {
            averaging = false;
            averageSamples.clear();
            handler.removeCallbacks(averageFinishRunnable);
            if (averageProgressRunnable != null) handler.removeCallbacks(averageProgressRunnable);
        }
        updateActionLabels();
        if (showMessage) Toast.makeText(this, "GPS detenido.", Toast.LENGTH_SHORT).show();
    }

    private void onAverageAction() {
        if (averaging) {
            cancelAveraging(true);
            return;
        }
        showAverageDurationChooser();
    }

    private void showAverageDurationChooser() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout sheet = NativeUi.column(this);
        sheet.setPadding(NativeUi.dp(this, 16), NativeUi.dp(this, 10),
                NativeUi.dp(this, 16), NativeUi.dp(this, 16));
        sheet.setBackground(NativeUi.gradient(Color.rgb(10, 29, 48), Color.rgb(4, 20, 36), 22,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 120), this));

        View handle = new View(this);
        handle.setBackground(NativeUi.rounded(Color.rgb(111, 132, 151), 3, 0, Color.TRANSPARENT, this));
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(NativeUi.dp(this, 42), NativeUi.dp(this, 4));
        hlp.gravity = Gravity.CENTER_HORIZONTAL;
        hlp.setMargins(0, 0, 0, NativeUi.dp(this, 12));
        sheet.addView(handle, hlp);

        sheet.addView(NativeUi.text(this, "Promediar ubicación", 19f, true, NativeUi.TEXT));
        TextView sub = NativeUi.text(this,
                "Elige el tiempo de observación. GeoTopo filtra lecturas inestables y prioriza GNSS cuando está disponible.",
                11.5f, false, NativeUi.SUB);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.setMargins(0, NativeUi.dp(this, 3), 0, NativeUi.dp(this, 12));
        sheet.addView(sub, slp);

        LinearLayout row1 = NativeUi.row(this);
        row1.addView(averageDurationCard("10 s", "Rápido", "Comprobación breve", 10000L, dialog), durationOptionLp(false));
        row1.addView(averageDurationCard("20 s", "Normal", "Uso general", 20000L, dialog), durationOptionLp(true));
        sheet.addView(row1);

        LinearLayout row2 = NativeUi.row(this);
        row2.addView(averageDurationCard("30 s", "Recomendado", "Mejor estabilidad", 30000L, dialog), durationOptionLp(false));
        row2.addView(averageDurationCard("60 s", "Máxima estabilidad", "Trabajo de campo", 60000L, dialog), durationOptionLp(true));
        LinearLayout.LayoutParams r2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        r2.setMargins(0, NativeUi.dp(this, 8), 0, 0);
        sheet.addView(row2, r2);

        TextView cancel = NativeUi.text(this, "Cancelar", 12.5f, true, NativeUi.SUB);
        cancel.setGravity(Gravity.CENTER);
        cancel.setPadding(0, NativeUi.dp(this, 13), 0, NativeUi.dp(this, 3));
        cancel.setOnClickListener(v -> dialog.dismiss());
        sheet.addView(cancel);

        dialog.setContentView(sheet);
        dialog.setCanceledOnTouchOutside(true);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setGravity(Gravity.BOTTOM);
            WindowManager.LayoutParams params = window.getAttributes();
            params.width = WindowManager.LayoutParams.MATCH_PARENT;
            params.height = WindowManager.LayoutParams.WRAP_CONTENT;
            params.dimAmount = 0.38f;
            window.setAttributes(params);
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
        dialog.show();
        if (window != null) window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams durationOptionLp(boolean leftMargin) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, NativeUi.dp(this, 98), 1f);
        lp.setMargins(leftMargin ? NativeUi.dp(this, 5) : 0, 0, leftMargin ? 0 : NativeUi.dp(this, 5), 0);
        return lp;
    }

    private View averageDurationCard(String duration, String title, String subtitle, long durationMs, Dialog dialog) {
        LinearLayout card = NativeUi.column(this);
        card.setGravity(Gravity.CENTER);
        card.setPadding(NativeUi.dp(this, 8), NativeUi.dp(this, 8), NativeUi.dp(this, 8), NativeUi.dp(this, 8));
        card.setBackground(NativeUi.gradient(NativeUi.CARD_LIGHT, NativeUi.CARD_DARK, 15,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 130), this));
        TextView big = NativeUi.text(this, duration, 21f, true, NativeUi.BLUE_LIGHT);
        big.setGravity(Gravity.CENTER);
        card.addView(big);
        TextView t = NativeUi.text(this, title, 12.3f, true, NativeUi.TEXT);
        t.setGravity(Gravity.CENTER);
        card.addView(t);
        TextView st = NativeUi.text(this, subtitle, 9.6f, false, NativeUi.SUB);
        st.setGravity(Gravity.CENTER);
        st.setMaxLines(2);
        card.addView(st);
        card.setOnClickListener(v -> {
            dialog.dismiss();
            beginAveraging(durationMs);
        });
        return card;
    }

    private void beginAveraging(long durationMs) {
        if (averaging) {
            cancelAveraging(true);
            return;
        }
        pendingAverageDurationMs = durationMs;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            startAverageAfterPermission = true;
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
            return;
        }
        if (!gpsRunning) {
            startGps();
            if (!gpsRunning) return;
        }
        averageDurationMs = durationMs == 10000L || durationMs == 20000L || durationMs == 30000L || durationMs == 60000L
                ? durationMs : 20000L;
        getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit().putLong("average_duration_ms", averageDurationMs).apply();
        averageStartedAt = System.currentTimeMillis();
        averaging = true;
        averageSamples.clear();
        averagingRejectedSamples = 0;
        totalAverageReadings = 0;
        maxSatellitesUsedDuringAverage = satellitesUsed;
        maxSatellitesVisibleDuringAverage = satellitesVisible;
        // Los satélites del promedio se cuentan únicamente desde estados GNSS
        // recibidos durante esta observación. El valor previo solo sirve como
        // indicación instantánea, no como muestra estadística del promedio.
        sumSatellitesUsedDuringAverage = 0L;
        satelliteStatusSamplesDuringAverage = 0;
        hadGnssFixDuringAverage = satellitesUsed > 0;
        lastAcceptedAverageSample = null;
        bestAverageAccuracy = Float.NaN;
        finalAverageStability = Float.NaN;
        finalAverageAccuracy = Float.NaN;
        finalMedianReportedAccuracy = Float.NaN;
        finalEffectiveSampleCount = 0;
        finalAverageSatellitesUsed = 0;
        finalAverageQuality = "Observando";
        finalValidSampleCount = 0;
        finalRejectedSampleCount = 0;
        finalAverageDurationSeconds = 0L;
        updateActionLabels();
        handler.removeCallbacks(averageFinishRunnable);
        if (averageProgressRunnable != null) handler.removeCallbacks(averageProgressRunnable);
        averageProgressRunnable = new Runnable() {
            @Override public void run() {
                if (!averaging) return;
                long elapsed = Math.max(0L, System.currentTimeMillis() - averageStartedAt);
                int totalSec = Math.max(1, (int) (averageDurationMs / 1000L));
                int elapsedSec = Math.min(totalSec, (int) (elapsed / 1000L));
                if (averageActionLabel != null) averageActionLabel.setText("Promediando\n" + elapsedSec + "/" + totalSec + " s");
                // La información técnica (satélites, lecturas y precisión del
                // promedio) se sigue calculando internamente y queda disponible
                // en Datos GNSS, pero no se pinta encima del mini mapa.
                handler.postDelayed(this, 1000L);
            }
        };
        handler.post(averageProgressRunnable);
        handler.postDelayed(averageFinishRunnable, averageDurationMs);
    }

    private void cancelAveraging(boolean showMessage) {
        averaging = false;
        averageSamples.clear();
        averagingRejectedSamples = 0;
        totalAverageReadings = 0;
        maxSatellitesUsedDuringAverage = 0;
        maxSatellitesVisibleDuringAverage = 0;
        sumSatellitesUsedDuringAverage = 0L;
        satelliteStatusSamplesDuringAverage = 0;
        hadGnssFixDuringAverage = false;
        lastAcceptedAverageSample = null;
        handler.removeCallbacks(averageFinishRunnable);
        if (averageProgressRunnable != null) handler.removeCallbacks(averageProgressRunnable);
        updateActionLabels();
        if (showMessage) {
            setMapHint("Promedio cancelado");
            Toast.makeText(this, "Promedio cancelado.", Toast.LENGTH_SHORT).show();
        }
    }

    private void finishAveraging() {
        if (!averaging) return;
        averaging = false;
        handler.removeCallbacks(averageFinishRunnable);
        if (averageProgressRunnable != null) handler.removeCallbacks(averageProgressRunnable);
        updateActionLabels();

        if (averageSamples.isEmpty() && currentLocation != null && isReasonableAverageSample(currentLocation)
                && locationBelongsToAverageWindow(currentLocation, averageStartedAt)) {
            averageSamples.add(new Location(currentLocation));
            totalAverageReadings = Math.max(1, totalAverageReadings);
        }
        if (averageSamples.isEmpty()) {
            setMapHint("Sin promedio válido · revisa GPS, precisión y cielo despejado");
            Toast.makeText(this, "No hubo lecturas válidas durante el promedio.", Toast.LENGTH_LONG).show();
            return;
        }

        List<Location> preferred = preferBestAvailableSamples(averageSamples);
        boolean hasGpsProviderSamples = hasGnssSamples(preferred);
        boolean assistedOnly = !hasGpsProviderSamples;
        List<Location> filtered = selectStableCluster(preferred);
        if (filtered.isEmpty()) filtered = new ArrayList<>(preferred);
        int rejectedByFilter = Math.max(0, averageSamples.size() - filtered.size());
        Location avg = averageLocationsWeighted(filtered);
        avg.setProvider(assistedOnly ? "promedio_asistido" : "promedio_gnss");
        float best = bestReportedAccuracy(filtered);
        float medianReported = medianReportedAccuracy(filtered);
        float stability = calculateStability68(filtered, avg);
        int averageSatUsed = satelliteStatusSamplesDuringAverage > 0
                ? Math.round((float) sumSatellitesUsedDuringAverage / satelliteStatusSamplesDuringAverage)
                : Math.max(0, satellitesUsed);
        int effectiveSamples = effectiveIndependentSampleCount(filtered.size(), averageDurationMs);
        float finalAcc = estimateFinalAverageAccuracy(best, medianReported, stability, assistedOnly,
                filtered.size(), effectiveSamples, averageSatUsed, averageDurationMs);
        if (!Float.isNaN(finalAcc)) avg.setAccuracy(finalAcc);

        bestAverageAccuracy = best;
        finalMedianReportedAccuracy = medianReported;
        finalAverageStability = stability;
        finalAverageAccuracy = finalAcc;
        finalEffectiveSampleCount = effectiveSamples;
        finalAverageSatellitesUsed = averageSatUsed;
        finalValidSampleCount = filtered.size();
        finalRejectedSampleCount = averagingRejectedSamples + rejectedByFilter;
        finalAverageDurationSeconds = Math.max(1L, averageDurationMs / 1000L);
        finalAverageQuality = averageQualityLabel(assistedOnly, finalValidSampleCount, averageSatUsed, finalAcc, averageDurationMs);
        satellitesUsed = Math.max(0, averageSatUsed);
        satellitesVisible = Math.max(satellitesVisible, maxSatellitesVisibleDuringAverage);
        currentLocation = new Location(avg);
        saveLastLocation(avg);
        saveAverageMetrics();
        overviewPosition = fromLocation(avg);
        updateOverviewData(overviewPosition);
        if (overviewMap != null) {
            drawOverviewMarker(avg.getLatitude(), avg.getLongitude());
            centerOverviewMap(true);
        }
        stopLocationUpdates(false);
        if (assistedOnly) {
            setMapHint("Promedio asistido " + finalAverageDurationSeconds + " s · calidad " + finalAverageQuality
                    + "\n" + finalValidSampleCount + " usadas · " + finalRejectedSampleCount + " descartadas · "
                    + formatAverageAccuracy(finalAcc));
            Toast.makeText(this, "Promedio de " + finalAverageDurationSeconds + " s completado · "
                    + formatAverageAccuracy(finalAcc) + " · ubicación asistida.", Toast.LENGTH_LONG).show();
        } else {
            setMapHint("Promedio GNSS " + finalAverageDurationSeconds + " s · calidad " + finalAverageQuality
                    + "\nSat. usados prom. " + averageSatUsed + " · máx. " + maxSatellitesUsedDuringAverage
                    + " · " + finalValidSampleCount + " usadas · " + finalRejectedSampleCount + " descartadas · "
                    + formatAverageAccuracy(finalAcc));
            String satInfo = averageSatUsed > 0 ? " · " + averageSatUsed + " sat. usados prom." : "";
            Toast.makeText(this, "Promedio GNSS de " + finalAverageDurationSeconds + " s completado · "
                    + formatAverageAccuracy(finalAcc) + satInfo + ".", Toast.LENGTH_LONG).show();
        }
        averageSamples.clear();
    }

    private void updateActionLabels() {
        if (gpsActionLabel != null) gpsActionLabel.setText(gpsRunning ? "Pausar\nGPS" : "Iniciar\nGPS");
        if (averageActionLabel != null) averageActionLabel.setText(averaging ? "Cancelar\npromedio" : "Promediar");
        setActionCardIcon(gpsActionCard, gpsRunning ? "pause" : "play", Color.rgb(61, 218, 144), false);
    }

    private void updateSaveActionState(boolean canSave) {
        setActionCardIcon(saveActionCard, "pin", Color.rgb(255, 182, 74), !canSave);
    }

    @Override public void onLocationChanged(Location location) {
        if (location == null || !validCoordinates(location)) return;
        updateSatelliteFallbackFromLocation(location);
        if (locationAgeMs(location) > FRESH_LIVE_LOCATION_MS) return;

        boolean firstLiveFix = currentLocation == null;
        boolean accepted = currentLocation == null || isBetterLocation(location, currentLocation);
        if (accepted) currentLocation = new Location(location);

        if (averaging) {
            maxSatellitesUsedDuringAverage = Math.max(maxSatellitesUsedDuringAverage, satellitesUsed);
            maxSatellitesVisibleDuringAverage = Math.max(maxSatellitesVisibleDuringAverage, satellitesVisible);
            if (satellitesUsed > 0) hadGnssFixDuringAverage = true;
            totalAverageReadings++;
            if (isSampleAllowedForAverage(location) && passesAverageJumpFilter(location)) {
                addAverageSample(location);
            } else {
                averagingRejectedSamples++;
            }
        }

        if (!accepted || currentLocation == null) return;
        if (isGpsSample(currentLocation)) handler.removeCallbacks(gpsNoFixRunnable);
        saveLastLocation(currentLocation);
        overviewPosition = fromLocation(currentLocation);
        updateOverviewData(overviewPosition);
        if (overviewMap != null) {
            drawOverviewMarker(currentLocation.getLatitude(), currentLocation.getLongitude());
            if (overviewAutoCenterPending || firstLiveFix || overviewMap.getCameraPosition().zoom < 4.0) {
                centerOverviewMap(false);
                overviewAutoCenterPending = false;
            }
        }
    }

    private void updateSatelliteFallbackFromLocation(Location location) {
        if (location == null || !LocationManager.GPS_PROVIDER.equals(location.getProvider())) return;
        try {
            Bundle extras = location.getExtras();
            if (extras == null || !extras.containsKey("satellites")) return;
            int legacyUsed = extras.getInt("satellites", -1);
            if (legacyUsed <= 0) return;
            // Algunos fabricantes entregan usedInFix=0 en GnssStatus aunque la
            // propia lectura GPS incluya el número de satélites en extras.
            // Lo usamos solo como fallback, nunca para reducir un conteo real.
            satellitesUsed = Math.max(satellitesUsed, legacyUsed);
            satellitesVisible = Math.max(satellitesVisible, legacyUsed);
            if (averaging) {
                maxSatellitesUsedDuringAverage = Math.max(maxSatellitesUsedDuringAverage, satellitesUsed);
                maxSatellitesVisibleDuringAverage = Math.max(maxSatellitesVisibleDuringAverage, satellitesVisible);
                hadGnssFixDuringAverage = true;
            }
        } catch (Exception ignored) { }
    }

    private boolean isGpsSample(Location location) {
        return location != null && (LocationManager.GPS_PROVIDER.equals(location.getProvider())
                || "promedio_gnss".equals(location.getProvider()));
    }

    private boolean hasGnssSamples(List<Location> samples) {
        if (samples == null) return false;
        for (Location sample : samples) if (isGpsSample(sample)) return true;
        return false;
    }

    private boolean isSampleAllowedForAverage(Location location) {
        if (location == null) return false;
        long timestamp = location.getTime() > 0 ? location.getTime() : System.currentTimeMillis();
        if (System.currentTimeMillis() - timestamp > MAX_AVERAGE_SAMPLE_AGE_MS) return false;
        if (location.hasSpeed() && location.getSpeed() > MAX_STATIONARY_SPEED_MPS) return false;
        if (location.hasAccuracy() && location.getAccuracy() > MAX_AVERAGE_SAMPLE_ACCURACY_M) return false;
        return true;
    }

    private boolean locationBelongsToAverageWindow(Location location, long startedAt) {
        if (location == null || startedAt <= 0L) return false;
        long timestamp = location.getTime() > 0 ? location.getTime() : System.currentTimeMillis();
        return timestamp >= startedAt - 1500L;
    }

    private boolean isReasonableAverageSample(Location location) {
        if (location == null) return false;
        return locationAgeMs(location) <= 20000L
                && (!location.hasAccuracy() || location.getAccuracy() <= MAX_AVERAGE_SAMPLE_ACCURACY_M)
                && (!location.hasSpeed() || location.getSpeed() <= MAX_STATIONARY_SPEED_MPS);
    }

    private void addAverageSample(Location location) {
        Location sample = new Location(location);
        averageSamples.add(sample);
        lastAcceptedAverageSample = sample;
        maxSatellitesUsedDuringAverage = Math.max(maxSatellitesUsedDuringAverage, satellitesUsed);
        if (sample.hasAccuracy() && (Float.isNaN(bestAverageAccuracy) || sample.getAccuracy() < bestAverageAccuracy))
            bestAverageAccuracy = sample.getAccuracy();
    }

    private boolean passesAverageJumpFilter(Location location) {
        if (lastAcceptedAverageSample == null) return true;
        float ca = location.hasAccuracy() ? location.getAccuracy() : 30f;
        float pa = lastAcceptedAverageSample.hasAccuracy() ? lastAcceptedAverageSample.getAccuracy() : 30f;
        // Una lectura claramente más precisa puede proceder de GPS o de la
        // ubicación fusionada de Android; no la rechazamos solo por cambiar de
        // proveedor. El filtro se basa en distancia y precisión real.
        if (ca + 3f < pa * 0.60f) return true;
        float base = Math.max(8f, Math.min(ca, pa) * 1.5f);
        float cap = 90f;
        float threshold = Math.max(base, Math.min(cap, (ca + pa) * 1.55f));
        return location.distanceTo(lastAcceptedAverageSample) <= threshold;
    }

    private List<Location> preferBestAvailableSamples(List<Location> samples) {
        List<Location> result = new ArrayList<>();
        if (samples == null) return result;
        for (Location sample : samples) {
            if (sample != null && isStoredAverageSample(sample)) result.add(new Location(sample));
        }
        return result;
    }

    private boolean isStoredAverageSample(Location location) {
        if (location == null) return false;
        if (location.hasAccuracy() && location.getAccuracy() > MAX_AVERAGE_SAMPLE_ACCURACY_M) return false;
        return !location.hasSpeed() || location.getSpeed() <= MAX_STATIONARY_SPEED_MPS;
    }

    private List<Location> selectStableCluster(List<Location> samples) {
        List<Location> clean = new ArrayList<>();
        if (samples == null) return clean;
        for (Location sample : samples) if (isStoredAverageSample(sample)) clean.add(new Location(sample));
        int minimum = minimumRequiredAverageSamples(averageDurationMs);
        if (clean.size() <= minimum) return clean;
        Location medoid = clean.get(0);
        double bestScore = Double.MAX_VALUE;
        for (Location candidate : clean) {
            List<Float> distances = new ArrayList<>();
            for (Location other : clean) distances.add(candidate.distanceTo(other));
            java.util.Collections.sort(distances);
            double score = distances.get(distances.size() / 2);
            if (score < bestScore) { bestScore = score; medoid = candidate; }
        }
        final Location center = medoid;
        java.util.Collections.sort(clean, (a, b) -> Float.compare(a.distanceTo(center), b.distanceTo(center)));
        // Un promedio largo permite ser más estricto con valores atípicos sin
        // quedarse sin datos. 10 s conserva ~85%; 60 s conserva ~70%.
        double keepFraction = stableKeepFraction(averageDurationMs);
        int keep = Math.max(minimum, (int) Math.ceil(clean.size() * keepFraction));
        keep = Math.min(keep, clean.size());
        return new ArrayList<>(clean.subList(0, keep));
    }

    private int minimumRequiredAverageSamples(long durationMs) {
        if (durationMs >= 60000L) return 12;
        if (durationMs >= 30000L) return 8;
        if (durationMs >= 20000L) return 6;
        return 4;
    }

    private double stableKeepFraction(long durationMs) {
        if (durationMs >= 60000L) return 0.70;
        if (durationMs >= 30000L) return 0.75;
        if (durationMs >= 20000L) return 0.80;
        return 0.85;
    }

    private Location averageLocationsWeighted(List<Location> samples) {
        double totalWeight = 0, lat = 0, lon = 0, alt = 0, altWeight = 0, speed = 0, speedWeight = 0;
        double bearingSin = 0, bearingCos = 0, bearingWeight = 0;
        for (Location sample : samples) {
            double reported = sample.hasAccuracy() ? Math.max(2.0, Math.min(100.0, sample.getAccuracy())) : 20.0;
            double weight = 1.0 / (reported * reported);
            totalWeight += weight;
            lat += sample.getLatitude() * weight;
            lon += sample.getLongitude() * weight;
            if (sample.hasAltitude()) { alt += sample.getAltitude() * weight; altWeight += weight; }
            if (sample.hasSpeed()) { speed += sample.getSpeed() * weight; speedWeight += weight; }
            if (sample.hasBearing() && sample.hasSpeed() && sample.getSpeed() >= 0.8f) {
                double rad = Math.toRadians(sample.getBearing());
                bearingSin += Math.sin(rad) * weight; bearingCos += Math.cos(rad) * weight; bearingWeight += weight;
            }
        }
        if (totalWeight <= 0) totalWeight = Math.max(1, samples.size());
        Location result = new Location(hasGnssSamples(samples) ? "promedio_gnss" : "promedio_asistido");
        result.setLatitude(lat / totalWeight);
        result.setLongitude(lon / totalWeight);
        if (altWeight > 0) result.setAltitude(alt / altWeight);
        if (speedWeight > 0) result.setSpeed((float) (speed / speedWeight));
        if (bearingWeight > 0) {
            double bearing = Math.toDegrees(Math.atan2(bearingSin, bearingCos));
            if (bearing < 0) bearing += 360.0;
            result.setBearing((float) bearing);
        }
        result.setTime(System.currentTimeMillis());
        return result;
    }

    private float bestReportedAccuracy(List<Location> samples) {
        float best = Float.NaN;
        for (Location sample : samples) if (sample != null && sample.hasAccuracy() && (Float.isNaN(best) || sample.getAccuracy() < best)) best = sample.getAccuracy();
        return best;
    }

    private float calculateStability68(List<Location> samples, Location center) {
        if (samples == null || samples.size() < 2 || center == null) return Float.NaN;
        List<Float> distances = new ArrayList<>();
        for (Location sample : samples) if (sample != null) distances.add(sample.distanceTo(center));
        if (distances.isEmpty()) return Float.NaN;
        java.util.Collections.sort(distances);
        int index = Math.max(0, Math.min(distances.size() - 1, (int) Math.ceil(distances.size() * 0.68) - 1));
        return distances.get(index);
    }

    private float medianReportedAccuracy(List<Location> samples) {
        List<Float> values = new ArrayList<>();
        if (samples != null) {
            for (Location sample : samples) if (sample != null && sample.hasAccuracy()) values.add(sample.getAccuracy());
        }
        if (values.isEmpty()) return Float.NaN;
        java.util.Collections.sort(values);
        int middle = values.size() / 2;
        if ((values.size() & 1) == 1) return values.get(middle);
        return (values.get(middle - 1) + values.get(middle)) / 2f;
    }

    private int effectiveIndependentSampleCount(int validSamples, long durationMs) {
        if (validSamples <= 0) return 0;
        // Las lecturas GNSS a 1 Hz están correlacionadas; no fingimos que 60
        // muestras equivalen a 60 observaciones independientes. Aproximamos
        // una observación independiente cada ~5 s para una estimación prudente.
        int byTime = 1 + (int) Math.max(0L, durationMs / 5000L);
        return Math.max(1, Math.min(validSamples, byTime));
    }

    private float estimateFinalAverageAccuracy(float best, float medianReported, float stability, boolean assistedOnly,
                                               int validSamples, int effectiveSamples, int averageSatUsed, long durationMs) {
        int n = Math.max(1, effectiveSamples);
        double sqrtN = Math.sqrt(n);
        float result = Float.NaN;

        if (!Float.isNaN(medianReported)) result = (float) (medianReported / sqrtN);
        if (!Float.isNaN(stability)) {
            float scatterOfMean = (float) (stability / sqrtN);
            result = Float.isNaN(result) ? scatterOfMean : Math.max(result, scatterOfMean);
        }
        if (Float.isNaN(result) && !Float.isNaN(best)) result = best;
        if (Float.isNaN(result)) return Float.NaN;

        // Nunca inventamos una mejora enorme. Con ubicación asistida, el
        // promedio mejora estabilidad pero no declara una precisión menor que
        // la mejor lectura reportada por Android. Con GPS/GNSS sí permitimos
        // una mejora prudente cuando hay suficientes muestras estables.
        if (!Float.isNaN(best)) {
            float floorFactor;
            if (assistedOnly) floorFactor = 1.00f;
            else if (durationMs >= 60000L) floorFactor = 0.72f;
            else if (durationMs >= 30000L) floorFactor = 0.78f;
            else if (durationMs >= 20000L) floorFactor = 0.84f;
            else floorFactor = 0.90f;
            result = Math.max(result, best * floorFactor);
        }

        int target = minimumRequiredAverageSamples(durationMs);
        if (validSamples < target) {
            float missingRatio = (float) (target - validSamples) / Math.max(1, target);
            result *= 1f + 0.75f * missingRatio;
        }
        // Los satélites usados ayudan a valorar un promedio GNSS, pero un
        // contador usedInFix=0 no invalida una ubicación asistida de 2-5 m.
        if (!assistedOnly && averageSatUsed > 0 && averageSatUsed < 4) result *= 1.20f;
        else if (!assistedOnly && averageSatUsed > 0 && averageSatUsed < 6) result *= 1.08f;
        return Math.max(1.5f, result);
    }

    private String averageQualityLabel(boolean assistedOnly, int validSamples, int averageSatUsed, float finalAccuracy, long durationMs) {
        if (validSamples < minimumRequiredAverageSamples(durationMs)) return "limitada";
        if (Float.isNaN(finalAccuracy)) return "sin estimación";
        if (assistedOnly) {
            if (finalAccuracy <= 5.0f) return "buena asistida";
            if (finalAccuracy <= 12.0f) return "moderada asistida";
            return "limitada asistida";
        }
        if (durationMs >= 30000L && finalAccuracy <= 3.0f && (averageSatUsed == 0 || averageSatUsed >= 6)) return "alta";
        if (finalAccuracy <= 6.0f) return "buena";
        if (finalAccuracy <= 12.0f) return "moderada";
        return "limitada";
    }

    private String formatAverageAccuracy(float value) {
        return Float.isNaN(value) ? "no disponible" : "±" + format1(value) + " m";
    }

    private void saveAverageMetrics() {
        getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit()
                .putFloat("last_average_best_accuracy", bestAverageAccuracy)
                .putFloat("last_average_stability", finalAverageStability)
                .putFloat("last_average_final_accuracy", finalAverageAccuracy)
                .putFloat("last_average_median_accuracy", finalMedianReportedAccuracy)
                .putInt("last_average_effective_samples", finalEffectiveSampleCount)
                .putInt("last_average_satellites_used_average", finalAverageSatellitesUsed)
                .putString("last_average_quality", finalAverageQuality)
                .putInt("last_average_valid", finalValidSampleCount)
                .putInt("last_average_rejected", finalRejectedSampleCount)
                .putInt("last_average_max_satellites", maxSatellitesUsedDuringAverage)
                .putInt("last_average_max_visible_satellites", maxSatellitesVisibleDuringAverage)
                .putInt("last_average_satellite_status_samples", satelliteStatusSamplesDuringAverage)
                .putLong("last_average_satellites_used_sum", sumSatellitesUsedDuringAverage)
                .putBoolean("last_average_had_gnss_fix", hadGnssFixDuringAverage)
                .putLong("last_average_duration_s", finalAverageDurationSeconds)
                .putLong("last_average_time", System.currentTimeMillis())
                .apply();
    }

    private void requestImmediateGpsFix() {
        if (locationManager == null || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        if (singleFixListener == null) {
            singleFixListener = new LocationListener() {
                @Override public void onLocationChanged(Location location) {
                    if (location != null) GpsOverviewActivity.this.onLocationChanged(location);
                }
                @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
                @Override public void onProviderEnabled(String provider) { }
                @Override public void onProviderDisabled(String provider) { }
            };
        }
        try {
            locationManager.requestSingleUpdate(LocationManager.GPS_PROVIDER, singleFixListener, Looper.getMainLooper());
        } catch (Exception ignored) { }
    }

    private void showGpsSearchingState() {
        if (qualityValue != null) {
            qualityValue.setText("Buscando");
            qualityValue.setTextColor(NativeUi.SUB);
        }
        if (precisionValue != null) precisionValue.setText("—");
        if (timeValue != null) timeValue.setText("—");
        if (satellitesValue != null) {
            satellitesValue.setText(satelliteMetricText(0, 0));
            satellitesValue.setTextColor(Color.rgb(255, 103, 116));
        }
        if (readingStateValue != null) readingStateValue.setText("Buscando GNSS…");
        showOverviewWaiting();
    }

    private void useRecentLastKnownLocation() {
        if (locationManager == null) return;
        Location best = null;
        try {
            Location gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (isUsableProvisionalLocation(gps)) best = gps;
        } catch (Exception ignored) { }
        try {
            Location network = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (isUsableProvisionalLocation(network) && (best == null || isBetterLocation(network, best))) best = network;
        } catch (Exception ignored) { }
        if (best == null) return;

        currentLocation = new Location(best);
        overviewPosition = fromLocation(currentLocation);
        updateOverviewData(overviewPosition);
        if (overviewMap != null) {
            drawOverviewMarker(currentLocation.getLatitude(), currentLocation.getLongitude());
            centerOverviewMap(false);
            overviewAutoCenterPending = false;
        }
    }

    private boolean isUsableProvisionalLocation(Location location) {
        if (location == null || !validCoordinates(location)) return false;
        long age = locationAgeMs(location);
        if (age < 0 || age > PROVISIONAL_LOCATION_MAX_AGE_MS) return false;
        return !location.hasAccuracy() || location.getAccuracy() <= 5000f;
    }

    private boolean validCoordinates(Location location) {
        if (location == null) return false;
        double lat = location.getLatitude();
        double lon = location.getLongitude();
        return !Double.isNaN(lat) && !Double.isNaN(lon) && lat >= -90.0 && lat <= 90.0 && lon >= -180.0 && lon <= 180.0;
    }

    private long locationAgeMs(Location location) {
        if (location == null) return Long.MAX_VALUE;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            long elapsedNanos = location.getElapsedRealtimeNanos();
            if (elapsedNanos > 0L) {
                long nowNanos = SystemClock.elapsedRealtimeNanos();
                if (nowNanos >= elapsedNanos) return (nowNanos - elapsedNanos) / 1_000_000L;
            }
        }
        long timestamp = location.getTime();
        return timestamp > 0L ? Math.max(0L, System.currentTimeMillis() - timestamp) : Long.MAX_VALUE;
    }

    private long locationDeltaMs(Location newer, Location older) {
        if (newer == null || older == null) return 0L;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            long a = newer.getElapsedRealtimeNanos();
            long b = older.getElapsedRealtimeNanos();
            if (a > 0L && b > 0L) return (a - b) / 1_000_000L;
        }
        return newer.getTime() - older.getTime();
    }

    private boolean hasFreshGnssFix() {
        return currentLocation != null && isGpsSample(currentLocation) && locationAgeMs(currentLocation) <= FRESH_LIVE_LOCATION_MS;
    }

    private boolean isBetterLocation(Location candidate, Location current) {
        if (candidate == null) return false;
        if (current == null) return true;

        boolean candidateGps = isGpsSample(candidate);
        boolean currentGps = isGpsSample(current);
        long candidateAge = locationAgeMs(candidate);
        long currentAge = locationAgeMs(current);

        // Una lectura GPS/GNSS real debe sustituir a una posición asistida por red,
        // aunque Android reporte momentáneamente una precisión numérica peor.
        if (candidateGps && !currentGps && candidateAge <= FRESH_LIVE_LOCATION_MS) return true;
        if (!candidateGps && currentGps && currentAge <= FRESH_LIVE_LOCATION_MS) return false;

        long dt = locationDeltaMs(candidate, current);
        if (dt > 15000L) return true;
        float ca = candidate.hasAccuracy() ? candidate.getAccuracy() : 9999f;
        float oa = current.hasAccuracy() ? current.getAccuracy() : 9999f;
        return ca <= oa + 4f || dt > 3000L;
    }

    private void registerGnssStatus() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N || locationManager == null || gnssRegistered) return;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        if (gnssCallback == null) {
            gnssCallback = new GnssStatus.Callback() {
                @Override public void onSatelliteStatusChanged(GnssStatus status) {
                    satellitesVisible = status.getSatelliteCount();
                    int used = 0;
                    for (int i = 0; i < status.getSatelliteCount(); i++) if (status.usedInFix(i)) used++;
                    satellitesUsed = used;
                    if (averaging) {
                        maxSatellitesUsedDuringAverage = Math.max(maxSatellitesUsedDuringAverage, satellitesUsed);
                        maxSatellitesVisibleDuringAverage = Math.max(maxSatellitesVisibleDuringAverage, satellitesVisible);
                        sumSatellitesUsedDuringAverage += satellitesUsed;
                        satelliteStatusSamplesDuringAverage++;
                        if (satellitesUsed > 0) hadGnssFixDuringAverage = true;
                    }
                    getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit()
                            .putInt("last_satellites_visible", satellitesVisible)
                            .putInt("last_satellites_used", satellitesUsed)
                            .apply();
                    if (satellitesValue != null) {
                        satellitesValue.setText(satelliteMetricText(satellitesUsed, satellitesVisible));
                        satellitesValue.setTextColor(satellitesUsed > 0 ? Color.rgb(170, 122, 255) : Color.rgb(255, 103, 116));
                    }
                    if (gpsRunning && !hasFreshGnssFix()) {
                        if (qualityValue != null) {
                            qualityValue.setText(satellitesUsed > 0 ? "Buscando fix" : "Buscando");
                            qualityValue.setTextColor(satellitesUsed > 0 ? Color.rgb(255, 193, 74) : NativeUi.SUB);
                        }
                        if (readingStateValue != null) {
                            readingStateValue.setText((satellitesUsed > 0 ? "GNSS preparando posición" : "Buscando GNSS")
                                    + " · " + satellitesUsed + "/" + satellitesVisible + " sat.");
                        }
                    }
                }
            };
        }
        try {
            locationManager.registerGnssStatusCallback(gnssCallback, handler);
            gnssRegistered = true;
        } catch (Exception ignored) { }
    }

    private void unregisterGnssStatus() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N || locationManager == null || !gnssRegistered || gnssCallback == null) return;
        try { locationManager.unregisterGnssStatusCallback(gnssCallback); } catch (Exception ignored) { }
        gnssRegistered = false;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_LOCATION) return;
        boolean precise = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if (!precise) {
            startAverageAfterPermission = false;
            Toast.makeText(this, "Para GPS/GNSS selecciona ubicación precisa.", Toast.LENGTH_LONG).show();
            return;
        }
        startGps();
        if (startAverageAfterPermission) {
            startAverageAfterPermission = false;
            handler.postDelayed(() -> beginAveraging(pendingAverageDurationMs), 450L);
        }
    }

    private void updateOverviewData(LastPosition p) {
        if (p == null) p = new LastPosition();
        overviewPosition = p;
        updateSaveActionState(freshLocationForSave() != null || p.valid);
        if (qualityValue != null) {
            qualityValue.setText(qualityLabel(p));
            qualityValue.setTextColor(qualityColor(p));
        }
        if (precisionValue != null) precisionValue.setText(p.valid ? "±" + format1(p.accuracy) + " m" : "—");
        if (satellitesValue != null) {
            int used = p.valid ? p.satellitesUsed : 0;
            int visible = p.valid ? p.satellitesVisible : 0;
            satellitesValue.setText(satelliteMetricText(used, visible));
            satellitesValue.setTextColor(used > 0 ? Color.rgb(170, 122, 255) : Color.rgb(255, 103, 116));
        }
        if (timeValue != null) timeValue.setText(p.valid ? formatTime(p.timestamp) : "—");
        if (readingStateValue != null) {
            if (p.valid) {
                String source = providerLabel(p.provider);
                readingStateValue.setText("●  " + source + " · " + relativeTime(p.timestamp));
            } else if (gpsRunning) {
                readingStateValue.setText("Buscando GNSS…");
            } else {
                readingStateValue.setText("Sin lectura");
            }
        }
        if (latValue != null) latValue.setText(p.valid ? formatGeographic(p.latitude, true) : "Sin lectura");
        if (lonValue != null) lonValue.setText(p.valid ? formatGeographic(p.longitude, false) : "Sin lectura");
        CoordinateUtils.Utm utm = p.valid ? CoordinateUtils.toUtm(p.latitude, p.longitude) : null;
        if (eastValue != null) eastValue.setText(utm != null && utm.valid ? format3(utm.easting) + " m" : "Sin lectura");
        if (northValue != null) northValue.setText(utm != null && utm.valid ? format3(utm.northing) + " m" : "Sin lectura");
        if (altitudeValue != null) altitudeValue.setText(!Float.isNaN(p.altitudeM) ? adjustedAltitude(p.altitudeM) : "No disponible");
        if (readingPrecisionValue != null) readingPrecisionValue.setText(p.valid ? "±" + format1(p.accuracy) + " m" : "Sin lectura");
        if (zoneValue != null) zoneValue.setText(utm != null && utm.valid ? CoordinateUtils.zoneWithBand(p.latitude, p.longitude) : "Sin lectura");
    }

    private void saveLastLocation(Location location) {
        if (location == null) return;
        SharedPreferences.Editor e = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit()
                .putString("last_latitude", Double.toString(location.getLatitude()))
                .putString("last_longitude", Double.toString(location.getLongitude()))
                .putFloat("last_accuracy", location.hasAccuracy() ? location.getAccuracy() : 0f)
                .putFloat("last_speed_mps", location.hasSpeed() ? location.getSpeed() : -1f)
                .putFloat("last_altitude_m", location.hasAltitude() ? (float) location.getAltitude() : Float.NaN)
                .putString("last_provider", location.getProvider() == null ? "" : location.getProvider())
                .putLong("last_location_time", location.getTime() > 0 ? location.getTime() : System.currentTimeMillis())
                .putInt("last_satellites_visible", satellitesVisible)
                .putInt("last_satellites_used", satellitesUsed);
        e.apply();
    }

    private void showSavePointDialog() {
        Location loc = freshLocationForSave();
        if (loc == null) {
            Toast.makeText(this, "Primero inicia el GPS y espera una lectura reciente.", Toast.LENGTH_LONG).show();
            return;
        }
        if (loc.hasAccuracy() && loc.getAccuracy() > 50f) {
            final Location lowAccuracy = new Location(loc);
            new AlertDialog.Builder(this)
                    .setTitle("Precisión baja")
                    .setMessage("La lectura actual es ±" + format1(loc.getAccuracy()) + " m. Para trabajo topográfico conviene esperar una lectura mejor. ¿Guardar de todos modos como punto referencial?")
                    .setPositiveButton("Guardar referencial", (d, w) -> showSavePointForm(lowAccuracy))
                    .setNegativeButton("Esperar mejor GPS", null)
                    .show();
            return;
        }
        showSavePointForm(loc);
    }

    private void showSavePointForm(Location loc) {
        pendingPhotoUri = "";
        LinearLayout form = NativeUi.column(this);
        form.setPadding(NativeUi.dp(this, 18), NativeUi.dp(this, 8), NativeUi.dp(this, 18), 0);
        EditText project = new EditText(this);
        project.setHint("Proyecto");
        project.setSingleLine(true);
        project.setText(getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString("current_project", "Proyecto general"));
        EditText name = new EditText(this);
        name.setHint("Nombre del punto");
        name.setSingleLine(true);
        name.setText(nextPointName());
        EditText description = new EditText(this);
        description.setHint("Descripción opcional");
        form.addView(project);
        form.addView(name);
        form.addView(description);

        Button photo = new Button(this);
        photo.setText("Agregar foto");
        ResponsiveUi.configureCompactText(photo, 14, 10, 2);
        photo.setOnClickListener(v -> choosePointPhoto());
        form.addView(photo);
        photoStatusView = NativeUi.text(this, "Sin foto adjunta", 11.5f, false, NativeUi.SUB);
        form.addView(photoStatusView);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Guardar punto")
                .setMessage("Se guardarán coordenadas, UTM, precisión, proveedor, hora y la foto si la adjuntas.")
                .setView(form)
                .setPositiveButton("Guardar", null)
                .setNegativeButton("Cancelar", null)
                .create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(b -> {
            String p = project.getText().toString().trim();
            if (p.isEmpty()) p = "Proyecto general";
            String n = name.getText().toString().trim();
            if (n.isEmpty()) n = nextPointName();
            getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit().putString("current_project", p).apply();
            persistPoint(p, n, description.getText().toString().trim(), loc);
            pendingPhotoUri = "";
            photoStatusView = null;
            dialog.dismiss();
        }));
        dialog.show();
    }

    private void choosePointPhoto() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, REQ_PHOTO);
    }

    private Location freshLocationForSave() {
        if (currentLocation != null && locationAgeMs(currentLocation) <= FRESH_SAVE_LOCATION_MS)
            return new Location(currentLocation);
        LastPosition p = readLastPosition();
        if (!p.valid || System.currentTimeMillis() - p.timestamp > FRESH_SAVE_LOCATION_MS) return null;
        Location loc = new Location(p.provider == null || p.provider.isEmpty() ? "guardada" : p.provider);
        loc.setLatitude(p.latitude);
        loc.setLongitude(p.longitude);
        loc.setAccuracy((float) p.accuracy);
        if (!Float.isNaN(p.altitudeM)) loc.setAltitude(p.altitudeM);
        loc.setTime(p.timestamp);
        return loc;
    }

    private void persistPoint(String project, String name, String description, Location location) {
        try {
            String existing = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]");
            JSONArray array = new JSONArray(existing == null ? "[]" : existing);
            JSONObject o = new JSONObject();
            o.put("project", project);
            o.put("name", name);
            o.put("description", description == null ? "" : description);
            o.put("latitude", location.getLatitude());
            o.put("longitude", location.getLongitude());
            if (location.hasAltitude()) o.put("altitude", location.getAltitude()); else o.put("altitude", JSONObject.NULL);
            if (location.hasAccuracy()) o.put("accuracy", location.getAccuracy()); else o.put("accuracy", JSONObject.NULL);
            if (location.hasSpeed()) o.put("speedKmh", location.getSpeed() * 3.6); else o.put("speedKmh", JSONObject.NULL);
            if (location.hasBearing()) o.put("bearing", location.getBearing()); else o.put("bearing", JSONObject.NULL);
            o.put("timestamp", location.getTime() > 0 ? location.getTime() : System.currentTimeMillis());
            o.put("provider", location.getProvider() == null ? "" : location.getProvider());
            o.put("photoUri", pendingPhotoUri == null ? "" : pendingPhotoUri);
            o.put("symbol", "●");
            array.put(o);
            getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit().putString(KEY_POINTS, array.toString()).apply();
            Toast.makeText(this, "Punto " + name + " guardado.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo guardar el punto.", Toast.LENGTH_LONG).show();
        }
    }

    private String nextPointName() {
        String json = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]");
        try {
            JSONArray a = new JSONArray(json == null ? "[]" : json);
            int n = 1;
            while (true) {
                String candidate = "P" + n;
                boolean exists = false;
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.optJSONObject(i);
                    if (o != null && candidate.equalsIgnoreCase(o.optString("name", ""))) { exists = true; break; }
                }
                if (!exists) return candidate;
                n++;
            }
        } catch (Exception ignored) { return "P1"; }
    }

    private void showPointsPanel() {
        List<PointRow> points = readRecentPoints(200);
        if (points.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Puntos")
                    .setMessage("Aún no hay puntos. Puedes crear uno escribiendo las coordenadas sin iniciar el GPS.")
                    .setPositiveButton("Crear punto manual", (d, w) -> openManualPoint())
                    .setNegativeButton("Cancelar", null).show();
            return;
        }
        LinearLayout list = NativeUi.column(this);
        list.setPadding(NativeUi.dp(this, 10), NativeUi.dp(this, 8), NativeUi.dp(this, 10), NativeUi.dp(this, 8));
        Button allMap = new Button(this);
        allMap.setText("Ver todos en el mapa");
        ResponsiveUi.configureCompactText(allMap, 14, 10, 2);
        list.addView(allMap);
        Button manual = new Button(this);
        manual.setAllCaps(false); manual.setText("+  Crear punto manual");
        ResponsiveUi.configureCompactText(manual, 14, 10, 2);
        list.addView(manual);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Puntos guardados · " + points.size())
                .setNegativeButton("Cerrar", null)
                .create();
        allMap.setOnClickListener(v -> { dialog.dismiss(); openAllPointsOnMap(); });
        manual.setOnClickListener(v -> { dialog.dismiss(); openManualPoint(); });
        for (PointRow point : points) {
            TextView row = NativeUi.text(this, point.name + " · " + point.project + "\n" + point.summary + "\n" + point.time, 12.3f, false, NativeUi.TEXT);
            row.setPadding(NativeUi.dp(this, 12), NativeUi.dp(this, 10), NativeUi.dp(this, 12), NativeUi.dp(this, 10));
            row.setBackground(NativeUi.rounded(NativeUi.withAlpha(NativeUi.BG_DEEP, 100), 12, 1, NativeUi.withAlpha(NativeUi.BORDER, 80), this));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, NativeUi.dp(this, 7), 0, 0);
            list.addView(row, lp);
            row.setOnClickListener(v -> showPointActions(point, dialog));
            row.setOnLongClickListener(v -> { showPointActions(point, dialog); return true; });
        }
        ScrollView scroll = new ScrollView(this);
        scroll.addView(list);
        dialog.setView(scroll);
        dialog.show();
    }

    private void showPointActions(PointRow point, AlertDialog parent) {
        String[] items = {"Ver en mapa", "Ir a punto / Radar", "Editar punto", "Ver foto", "Compartir punto", "Eliminar punto"};
        new AlertDialog.Builder(this)
                .setTitle(point.name)
                .setItems(items, (d, which) -> {
                    if (which == 0) { parent.dismiss(); openPointOnMap(point); }
                    else if (which == 1) { parent.dismiss(); navigatePoint(point); }
                    else if (which == 2) { parent.dismiss(); Intent editor = new Intent(this, PointEditorActivity.class); editor.putExtra("edit_index", point.sourceIndex); startActivity(editor); }
                    else if (which == 3) showPointPhoto(point);
                    else if (which == 4) sharePoint(point);
                    else deletePoint(point, parent);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void sharePoint(PointRow point) {
        String text = point.name + " · " + point.project + "\n" + point.summary + "\n"
                + format6(point.latitude) + ", " + format6(point.longitude);
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(send, "Compartir punto"));
    }

    private void deletePoint(PointRow point, AlertDialog parent) {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar " + point.name + "")
                .setMessage("Esta acción no se puede deshacer.")
                .setPositiveButton("Eliminar", (d, w) -> {
                    JSONArray a = readPointArray();
                    JSONArray out = new JSONArray();
                    for (int i = 0; i < a.length(); i++) if (i != point.sourceIndex) out.put(a.opt(i));
                    getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit().putString(KEY_POINTS, out.toString()).apply();
                    parent.dismiss();
                    Toast.makeText(this, "Punto eliminado.", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void openAllPointsOnMap() {
        Intent intent = new Intent(this, MapActivity.class);
        intent.putExtra("show_saved_points", true);
        intent.putExtra("show_all_saved_points", true);
        startActivity(intent);
    }

    private void openManualPoint() { startActivity(new Intent(this, PointEditorActivity.class)); }

    private void navigatePoint(PointRow p) {
        Intent i = new Intent(this, GotoPointActivity.class);
        i.putExtra("target_lat", p.latitude);
        i.putExtra("target_lon", p.longitude);
        i.putExtra("target_name", p.name);
        startActivity(i);
    }

    private void showPointPhoto(PointRow p) {
        JSONObject point = readPointArray().optJSONObject(p.sourceIndex);
        String uri = point == null ? "" : point.optString("photoUri", "");
        if (uri.isEmpty()) { Toast.makeText(this, "Este punto no tiene foto.", Toast.LENGTH_SHORT).show(); return; }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(Uri.parse(uri), "image/*");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "Ver foto del punto"));
        } catch (Exception e) {
            Toast.makeText(this, "La foto ya no está disponible en el dispositivo.", Toast.LENGTH_LONG).show();
        }
    }

    private void showMoreTools() {
        String[] choices = {"Nueva sesión / Recorridos", "Crear punto manual", "Ir a punto / Radar",
                "Datos GNSS y satélites", "Ajustes GPS", "Compartir ubicación"};
        new AlertDialog.Builder(this).setTitle("Herramientas GPS")
                .setItems(choices, (d, n) -> {
                    switch (n) {
                        case 0: showSessionChooser(); break;
                        case 1: openManualPoint(); break;
                        case 2: startActivity(new Intent(this, GotoPointActivity.class)); break;
                        case 3: startActivity(new Intent(this, GnssQualityActivity.class)); break;
                        case 4: startActivity(new Intent(this, GpsSettingsActivity.class)); break;
                        case 5: shareLastCoordinates(); break;
                    }
                }).setNegativeButton("Cerrar", null).show();
    }

    private void showSessionChooser() {
        SharedPreferences sp = getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE);
        boolean active = sp.getBoolean(TrackService.KEY_RUNNING, false);
        new AlertDialog.Builder(this).setTitle("Sesiones de campo")
                .setMessage(active ? "Hay un recorrido en curso. Ábrelo para pausarlo, continuar o finalizar sin perder su traza."
                        : "Abre Recorridos para empezar una sesión GPS, pausarla y exportarla.")
                .setPositiveButton("Abrir sesiones", (d,w) -> startActivity(new Intent(this, TrackActivity.class)))
                .setNegativeButton("Cancelar", null).show();
    }

    private void showGnssPanel() {
        LastPosition p = readLastPosition();
        CoordinateUtils.Utm utm = p.valid ? CoordinateUtils.toUtm(p.latitude, p.longitude) : null;
        SharedPreferences sp = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
        float best = sp.getFloat("last_average_best_accuracy", Float.NaN);
        float stability = sp.getFloat("last_average_stability", Float.NaN);
        float finalAcc = sp.getFloat("last_average_final_accuracy", Float.NaN);
        float medianAcc = sp.getFloat("last_average_median_accuracy", Float.NaN);
        int effectiveSamples = sp.getInt("last_average_effective_samples", 0);
        String averageQuality = sp.getString("last_average_quality", "sin clasificar");
        int valid = sp.getInt("last_average_valid", 0);
        int rejected = sp.getInt("last_average_rejected", 0);
        int maxSat = sp.getInt("last_average_max_satellites", 0);
        int maxVisibleSat = sp.getInt("last_average_max_visible_satellites", 0);
        int satStatusSamples = sp.getInt("last_average_satellite_status_samples", 0);
        long satUsedSum = sp.getLong("last_average_satellites_used_sum", 0L);
        boolean averageHadFix = sp.getBoolean("last_average_had_gnss_fix", false);
        int savedAvgSatUsed = sp.getInt("last_average_satellites_used_average", -1);
        int avgSatUsed = savedAvgSatUsed >= 0 ? savedAvgSatUsed
                : (satStatusSamples > 0 ? Math.round((float) satUsedSum / satStatusSamples) : 0);
        long duration = sp.getLong("last_average_duration_s", 0L);
        StringBuilder sb = new StringBuilder();
        sb.append("Estado: " ).append(gpsRunning ? "GPS activo" : "GPS detenido").append("\n");
        sb.append("Calidad: " ).append(qualityLabel(p)).append("\n");
        sb.append("Precisión actual: " ).append(p.valid ? "±" + format1(p.accuracy) + " m" : "Sin lectura").append("\n");
        sb.append("Satélites usados / visibles: " ).append(p.satellitesUsed).append(" / " ).append(p.satellitesVisible).append("\n");
        sb.append("Proveedor: " ).append(providerLabel(p.provider)).append("\n");
        sb.append("Velocidad: " ).append(p.speedMps >= 0 ? format1(p.speedMps * 3.6) + " km/h" : "Sin dato").append("\n");
        sb.append("Altitud: " ).append(!Float.isNaN(p.altitudeM) ? format1(p.altitudeM) + " m" : "Sin dato").append("\n");
        if (utm != null && utm.valid) sb.append("UTM: " ).append(utm.zone).append(utm.hemisphere()).append(" · " ).append(format3(utm.easting)).append(" E · " ).append(format3(utm.northing)).append(" N\n");
        sb.append("Última lectura: " ).append(p.valid ? relativeTime(p.timestamp) : "Sin lectura");
        if (duration > 0) {
            sb.append("\n\nÚltimo promedio: " ).append(duration).append(" s");
            sb.append("\nCalidad del promedio: " ).append(averageQuality);
            sb.append("\nMejor lectura individual: " ).append(formatAverageAccuracy(best));
            sb.append("\nMediana de precisión: " ).append(formatAverageAccuracy(medianAcc));
            sb.append("\nDispersión 68%: " ).append(formatAverageAccuracy(stability));
            sb.append("\nPrecisión estimada del promedio: " ).append(formatAverageAccuracy(finalAcc));
            sb.append("\nMuestras efectivas: " ).append(effectiveSamples).append(" de " ).append(valid).append(" usadas");
            sb.append("\nFijación GNSS: " ).append(averageHadFix ? "Sí" : "No (resultado asistido/referencial)");
            sb.append("\nSatélites usados promedio: " ).append(avgSatUsed);
            sb.append("\nSatélites usados máx.: " ).append(maxSat).append(" · visibles máx.: " ).append(maxVisibleSat);
            sb.append("\nLecturas: " ).append(valid).append(" usadas · " ).append(rejected).append(" descartadas");
        }
        new AlertDialog.Builder(this).setTitle("Datos GNSS").setMessage(sb.toString()).setPositiveButton("Cerrar", null).show();
    }

    private void showExportPanel() {
        String[] items = {"Copiar coordenada actual", "Compartir coordenada actual", "Exportar CSV", "Exportar KML", "Exportar KMZ", "Exportar GPX", "Exportar GeoJSON", "Exportar TXT", "Importar KML/KMZ", "Compartir resumen del proyecto"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                TextView tv = (TextView) super.getView(position, convertView, parent);
                tv.setTextColor(Color.WHITE);
                tv.setTextSize(22f);
                int py = NativeUi.dp(GpsOverviewActivity.this, 12);
                int px = NativeUi.dp(GpsOverviewActivity.this, 10);
                tv.setPadding(px, py, px, py);
                return tv;
            }
        };
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Archivos y exportación")
                .setAdapter(adapter, (d, which) -> {
                    if (which == 0) copyLastCoordinates();
                    else if (which == 1) shareLastCoordinates();
                    else if (which >= 2 && which <= 7) beginExport(new String[]{"csv","kml","kmz","gpx","geojson","txt"}[which - 2]);
                    else if (which == 8) beginImport();
                    else shareProjectSummary();
                })
                .setNegativeButton("Cancelar", null)
                .create();
        dialog.setOnShowListener(v -> {
            Button cancel = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
            if (cancel != null) {
                cancel.setTextColor(NativeUi.BLUE_LIGHT);
                cancel.setTextSize(18f);
            }
        });
        dialog.show();
    }

    private void beginExport(String type) {
        if (readPointArray().length() == 0) {
            Toast.makeText(this, "No hay puntos guardados para exportar.", Toast.LENGTH_LONG).show();
            return;
        }
        pendingExportType = type;
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date());
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        if ("kml".equals(type)) { intent.setType("application/vnd.google-earth.kml+xml"); intent.putExtra(Intent.EXTRA_TITLE, "GeoTopo_puntos_" + stamp + ".kml"); }
        else if ("kmz".equals(type)) { intent.setType("application/vnd.google-earth.kmz"); intent.putExtra(Intent.EXTRA_TITLE, "GeoTopo_puntos_" + stamp + ".kmz"); }
        else if ("gpx".equals(type)) { intent.setType("application/gpx+xml"); intent.putExtra(Intent.EXTRA_TITLE, "GeoTopo_puntos_" + stamp + ".gpx"); }
        else if ("geojson".equals(type)) { intent.setType("application/geo+json"); intent.putExtra(Intent.EXTRA_TITLE, "GeoTopo_puntos_" + stamp + ".geojson"); }
        else if ("txt".equals(type)) { intent.setType("text/plain"); intent.putExtra(Intent.EXTRA_TITLE, "GeoTopo_puntos_" + stamp + ".txt"); }
        else { intent.setType("text/csv"); intent.putExtra(Intent.EXTRA_TITLE, "GeoTopo_puntos_" + stamp + ".csv"); }
        startActivityForResult(intent, REQ_EXPORT);
    }

    private void beginImport() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/vnd.google-earth.kml+xml", "application/vnd.google-earth.kmz", "application/zip", "text/xml", "application/xml"});
        startActivityForResult(intent, REQ_IMPORT);
    }

    private void shareProjectSummary() {
        JSONArray a = readPointArray();
        if (a.length() == 0) { Toast.makeText(this, "No hay puntos guardados para compartir.", Toast.LENGTH_LONG).show(); return; }
        StringBuilder sb = new StringBuilder("GeoTopo · Proyecto de campo\nPuntos: " + a.length() + "\n\n");
        for (int i = 0; i < a.length(); i++) {
            JSONObject p = a.optJSONObject(i); if (p == null) continue;
            sb.append('[').append(p.optString("project", "Proyecto general")).append("] " ).append(p.optString("name", "Punto")).append("\n")
                    .append(format6(p.optDouble("latitude", 0))).append(", " ).append(format6(p.optDouble("longitude", 0)));
            if (!p.isNull("accuracy")) sb.append(" · ±" ).append(format1(p.optDouble("accuracy"))).append(" m");
            String desc = p.optString("description", ""); if (!desc.isEmpty()) sb.append("\n" ).append(desc);
            sb.append("\n\n");
        }
        Intent send = new Intent(Intent.ACTION_SEND); send.setType("text/plain"); send.putExtra(Intent.EXTRA_TEXT, sb.toString());
        startActivity(Intent.createChooser(send, "Compartir proyecto"));
    }

    private String buildGpsTxt() {
        JSONArray points = readPointArray();
        StringBuilder txt = new StringBuilder("GeoTopo · Puntos de campo\nDatum WGS84\n\n");
        for (int i = 0; i < points.length(); i++) {
            JSONObject p = points.optJSONObject(i); if (p == null) continue;
            double lat = p.optDouble("latitude", Double.NaN), lon = p.optDouble("longitude", Double.NaN);
            if (!Double.isFinite(lat) || !Double.isFinite(lon)) continue;
            CoordinateUtils.Utm u = CoordinateUtils.toUtm(lat, lon);
            txt.append(p.optString("name", "Punto")).append(" · ")
                    .append(p.optString("project", "Proyecto general")).append('\n')
                    .append("Latitud: ").append(format6(lat)).append(" | Longitud: ").append(format6(lon)).append('\n');
            if (u.valid) txt.append("UTM: ").append(CoordinateUtils.zoneWithBand(lat, lon))
                    .append(" · E ").append(format3(u.easting)).append(" m · N ")
                    .append(format3(u.northing)).append(" m\n");
            if (!p.isNull("altitude")) txt.append("Altitud: ").append(format1(p.optDouble("altitude"))).append(" m\n");
            txt.append(p.optString("description", "")).append("\n\n");
        }
        return txt.toString();
    }

    private String buildGpsCsv() {
        JSONArray a = readPointArray();
        if (a.length() == 0) return "";
        StringBuilder sb = new StringBuilder("project,name,description,latitude,longitude,altitude,accuracy,timestamp,provider\n");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            sb.append(csv(o.optString("project", ""))).append(',')
                    .append(csv(o.optString("name", ""))).append(',')
                    .append(csv(o.optString("description", ""))).append(',')
                    .append(o.optDouble("latitude", 0)).append(',')
                    .append(o.optDouble("longitude", 0)).append(',')
                    .append(o.isNull("altitude") ? "" : o.optDouble("altitude")).append(',')
                    .append(o.isNull("accuracy") ? "" : o.optDouble("accuracy")).append(',')
                    .append(o.optLong("timestamp", 0)).append(',')
                    .append(csv(o.optString("provider", ""))).append('\n');
        }
        return sb.toString();
    }

    private String csv(String value) {
        String v = value == null ? "" : value.replace("\"", "\"\"");
        return "\"" + v + "\"";
    }

    private String buildGpsKml() {
        JSONArray a = readPointArray();
        if (a.length() == 0) return "";
        StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><kml xmlns=\"http://www.opengis.net/kml/2.2\"><Document>");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            sb.append("<Placemark><name>").append(xml(o.optString("name", "Punto"))).append("</name><description>")
                    .append(xml(o.optString("description", ""))).append("</description><Point><coordinates>")
                    .append(o.optDouble("longitude", 0)).append(',').append(o.optDouble("latitude", 0)).append(',')
                    .append(o.isNull("altitude") ? 0 : o.optDouble("altitude", 0)).append("</coordinates></Point></Placemark>");
        }
        return sb.append("</Document></kml>").toString();
    }

    private String xml(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    private String buildGpsGpx() {
        JSONArray a = readPointArray();
        if (a.length() == 0) return "";
        SimpleDateFormat iso = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        iso.setTimeZone(TimeZone.getTimeZone("UTC"));
        StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<gpx version=\"1.1\" creator=\"GeoTopo\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n");
        for (int i = 0; i < a.length(); i++) {
            JSONObject p = a.optJSONObject(i); if (p == null) continue;
            sb.append("<wpt lat=\"" ).append(format6(p.optDouble("latitude",0))).append("\" lon=\"" ).append(format6(p.optDouble("longitude",0))).append("\">\n");
            if (!p.isNull("altitude")) sb.append("<ele>" ).append(p.optDouble("altitude",0)).append("</ele>\n");
            sb.append("<time>" ).append(iso.format(new Date(p.optLong("timestamp", System.currentTimeMillis())))).append("</time>\n")
                    .append("<name>" ).append(xml(p.optString("name","Punto"))).append("</name>\n")
                    .append("<desc>" ).append(xml(p.optString("project","Proyecto general") + " · " + p.optString("description",""))).append("</desc>\n</wpt>\n");
        }
        return sb.append("</gpx>\n").toString();
    }

    private String buildGpsGeoJson() {
        JSONArray points = readPointArray();
        if (points.length() == 0) return "";
        try {
            JSONObject root = new JSONObject();
            root.put("type", "FeatureCollection");
            JSONArray features = new JSONArray();
            for (int i = 0; i < points.length(); i++) {
                JSONObject p = points.optJSONObject(i);
                if (p == null) continue;
                JSONObject f = new JSONObject();
                f.put("type", "Feature");
                JSONObject geometry = new JSONObject();
                geometry.put("type", "Point");
                JSONArray coordinates = new JSONArray();
                coordinates.put(p.optDouble("longitude", 0));
                coordinates.put(p.optDouble("latitude", 0));
                if (!p.isNull("altitude")) coordinates.put(p.optDouble("altitude", 0));
                geometry.put("coordinates", coordinates);
                f.put("geometry", geometry);
                JSONObject properties = new JSONObject();
                properties.put("project", p.optString("project", ""));
                properties.put("name", p.optString("name", ""));
                properties.put("description", p.optString("description", ""));
                if (!p.isNull("accuracy")) properties.put("accuracy", p.optDouble("accuracy"));
                properties.put("timestamp", p.optLong("timestamp", 0));
                f.put("properties", properties);
                features.put(f);
            }
            root.put("features", features);
            return root.toString(2);
        } catch (Exception e) {
            return "";
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_PHOTO) {
            try {
                int flags = data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;
                getContentResolver().takePersistableUriPermission(uri, flags);
            } catch (Exception ignored) { }
            pendingPhotoUri = uri.toString();
            if (photoStatusView != null) photoStatusView.setText("Foto adjunta correctamente");
            return;
        }
        if (requestCode == REQ_IMPORT) { importKmlOrKmz(uri); return; }
        if (requestCode != REQ_EXPORT) return;
        try (OutputStream output = getContentResolver().openOutputStream(uri, "w")) {
            if (output == null) throw new IOException("No se pudo abrir el destino");
            if ("kmz".equals(pendingExportType)) {
                try (ZipOutputStream zip = new ZipOutputStream(output)) {
                    zip.putNextEntry(new ZipEntry("doc.kml"));
                    zip.write(buildGpsKml().getBytes(StandardCharsets.UTF_8));
                    zip.closeEntry();
                }
            } else {
                String text = "kml".equals(pendingExportType) ? buildGpsKml()
                        : ("gpx".equals(pendingExportType) ? buildGpsGpx()
                        : ("geojson".equals(pendingExportType) ? buildGpsGeoJson()
                        : ("txt".equals(pendingExportType) ? buildGpsTxt() : buildGpsCsv())));
                try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(output, StandardCharsets.UTF_8))) {
                    writer.write(text);
                }
            }
            Toast.makeText(this, "Archivo exportado correctamente.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo exportar: " + safeMessage(e), Toast.LENGTH_LONG).show();
        }
    }

    private void importKmlOrKmz(Uri uri) {
        try (InputStream raw = getContentResolver().openInputStream(uri)) {
            if (raw == null) throw new IOException("No se pudo abrir el archivo");
            BufferedInputStream input = new BufferedInputStream(raw);
            input.mark(4);
            int b1 = input.read(), b2 = input.read();
            input.reset();
            String kml = (b1 == 'P' && b2 == 'K') ? readKmlFromKmz(input)
                    : new String(readAllBytes(input, 20 * 1024 * 1024), StandardCharsets.UTF_8);
            List<JSONObject> imported = parseKmlPoints(kml);
            if (imported.isEmpty()) { Toast.makeText(this, "El archivo no contiene puntos KML compatibles.", Toast.LENGTH_LONG).show(); return; }
            JSONArray array = readPointArray();
            for (JSONObject o : imported) array.put(o);
            getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit().putString(KEY_POINTS, array.toString()).apply();
            Toast.makeText(this, "Importados " + imported.size() + " puntos.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo importar: " + safeMessage(e), Toast.LENGTH_LONG).show();
        }
    }

    private String readKmlFromKmz(InputStream input) throws IOException {
        try (ZipInputStream zip = new ZipInputStream(input)) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                if (!entry.isDirectory() && entry.getName().toLowerCase(Locale.US).endsWith(".kml"))
                    return new String(readAllBytes(zip, 20 * 1024 * 1024), StandardCharsets.UTF_8);
            }
        }
        throw new IOException("El KMZ no contiene KML");
    }

    private byte[] readAllBytes(InputStream input, int maxBytes) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int total = 0, read;
        while ((read = input.read(buffer)) != -1) {
            total += read;
            if (total > maxBytes) throw new IOException("El archivo es demasiado grande");
            output.write(buffer, 0, read);
        }
        return output.toByteArray();
    }

    private List<JSONObject> parseKmlPoints(String kml) {
        List<JSONObject> out = new ArrayList<>();
        if (kml == null) return out;
        Matcher placemarks = Pattern.compile("(?is)<Placemark\\b[^>]*>(.*?)</Placemark>").matcher(kml);
        int count = 1;
        while (placemarks.find()) {
            String block = placemarks.group(1);
            String coords = firstTagValue(block, "coordinates");
            if (coords.isEmpty()) continue;
            String[] parts = coords.trim().split("\\s+")[0].split(",");
            if (parts.length < 2) continue;
            try {
                double lon = Double.parseDouble(parts[0].trim()), lat = Double.parseDouble(parts[1].trim());
                if (lat < -90 || lat > 90 || lon < -180 || lon > 180) continue;
                JSONObject o = new JSONObject();
                o.put("project", "Importado KML/KMZ");
                String name = decodeXml(firstTagValue(block, "name"));
                o.put("name", name.isEmpty() ? "KML" + count : name);
                o.put("description", stripHtml(decodeXml(firstTagValue(block, "description"))));
                o.put("latitude", lat); o.put("longitude", lon);
                if (parts.length >= 3) { try { o.put("altitude", Double.parseDouble(parts[2].trim())); } catch (Exception e) { o.put("altitude", JSONObject.NULL); } }
                else o.put("altitude", JSONObject.NULL);
                o.put("accuracy", JSONObject.NULL); o.put("speedKmh", JSONObject.NULL); o.put("bearing", JSONObject.NULL);
                o.put("timestamp", System.currentTimeMillis()); o.put("provider", "KML/KMZ importado"); o.put("photoUri", "");
                out.add(o); count++;
            } catch (Exception ignored) { }
        }
        return out;
    }

    private String firstTagValue(String block, String tag) {
        Matcher m = Pattern.compile("(?is)<" + Pattern.quote(tag) + "\\b[^>]*>(.*?)</" + Pattern.quote(tag) + ">").matcher(block);
        return m.find() ? m.group(1).trim() : "";
    }

    private String decodeXml(String value) {
        return value == null ? "" : value.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
                .replace("&apos;", "'").replace("&amp;", "&");
    }

    private String stripHtml(String value) {
        return value == null ? "" : value.replaceAll("(?is)<[^>]+>", " ").replaceAll("\\s+", " ").trim();
    }

    private String safeMessage(Exception e) {
        String m = e == null ? "" : e.getMessage();
        return m == null || m.trim().isEmpty() ? "error desconocido" : m;
    }

    private JSONArray readPointArray() {
        String json = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]");
        try { return new JSONArray(json == null ? "[]" : json); }
        catch (Exception ignored) { return new JSONArray(); }
    }

    private void openPointOnMap(PointRow point) {
        Intent intent = new Intent(this, MapActivity.class);
        intent.putExtra("show_saved_points", true);
        intent.putExtra("saved_points_project", point.project == null ? "" : point.project);
        intent.putExtra("selected_saved_point_name", point.name == null ? "" : point.name);
        intent.putExtra("selected_saved_point_lat", point.latitude);
        intent.putExtra("selected_saved_point_lon", point.longitude);
        startActivity(intent);
    }

    private void openFullMap() {
        Intent intent = new Intent(this, MapActivity.class);
        intent.putExtra("map_mode", currentMapMode);
        if (overviewMap != null && overviewStyleInitialized) {
            CameraPosition camera = overviewMap.getCameraPosition();
            if (camera != null && camera.target != null) {
                intent.putExtra("camera_lat", camera.target.getLatitude());
                intent.putExtra("camera_lon", camera.target.getLongitude());
                intent.putExtra("camera_zoom", camera.zoom);
                intent.putExtra("camera_bearing", camera.bearing);
            }
        }
        Location loc = currentLocation;
        if (loc != null && System.currentTimeMillis() - loc.getTime() <= RECENT_MAP_LOCATION_MS) {
            intent.putExtra("latitude", loc.getLatitude());
            intent.putExtra("longitude", loc.getLongitude());
            intent.putExtra("location_accuracy", loc.hasAccuracy() ? loc.getAccuracy() : 0f);
            intent.putExtra("location_bearing", loc.hasBearing() ? loc.getBearing() : 0f);
        } else if (overviewPosition != null && isRecent(overviewPosition)) {
            intent.putExtra("latitude", overviewPosition.latitude);
            intent.putExtra("longitude", overviewPosition.longitude);
            intent.putExtra("location_accuracy", (float) overviewPosition.accuracy);
        }
        startActivity(intent);
    }

    private void copyLastCoordinates() {
        LastPosition p = readLastPosition();
        if (!p.valid) {
            Toast.makeText(this, "Primero obtén una lectura GPS.", Toast.LENGTH_LONG).show();
            return;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null) {
            String value = "Latitud: " + format6(p.latitude) + "\nLongitud: " + format6(p.longitude);
            cm.setPrimaryClip(ClipData.newPlainText("Coordenadas GeoTopo", value));
            Toast.makeText(this, "Coordenada actual copiada.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "No se pudo acceder al portapapeles.", Toast.LENGTH_LONG).show();
        }
    }

    private void shareLastCoordinates() {
        LastPosition p = readLastPosition();
        if (!p.valid) {
            Toast.makeText(this, "Primero obtén una lectura GPS.", Toast.LENGTH_LONG).show();
            return;
        }
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT, "Coordenadas GeoTopo\nLatitud: "
                + format6(p.latitude) + "\nLongitud: " + format6(p.longitude));
        startActivity(Intent.createChooser(share, "Compartir coordenadas"));
    }

    private LastPosition readLastPosition() {
        SharedPreferences prefs = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
        try {
            String lat = prefs.getString("last_latitude", "");
            String lon = prefs.getString("last_longitude", "");
            LastPosition p = new LastPosition();
            p.satellitesVisible = prefs.getInt("last_satellites_visible", 0);
            p.satellitesUsed = prefs.getInt("last_satellites_used", 0);
            p.speedMps = prefs.getFloat("last_speed_mps", -1f);
            p.altitudeM = prefs.getFloat("last_altitude_m", Float.NaN);
            p.provider = prefs.getString("last_provider", "");
            if (lat == null || lon == null || lat.trim().isEmpty() || lon.trim().isEmpty()) return p;
            p.latitude = Double.parseDouble(lat);
            p.longitude = Double.parseDouble(lon);
            p.accuracy = prefs.getFloat("last_accuracy", 0f);
            p.timestamp = prefs.getLong("last_location_time", 0L);
            p.valid = true;
            return p;
        } catch (Exception ignored) {
            return new LastPosition();
        }
    }

    private LastPosition fromLocation(Location location) {
        LastPosition p = new LastPosition();
        if (location == null) return p;
        p.valid = true;
        p.latitude = location.getLatitude();
        p.longitude = location.getLongitude();
        p.accuracy = location.hasAccuracy() ? location.getAccuracy() : 0f;
        p.timestamp = location.getTime() > 0 ? location.getTime() : System.currentTimeMillis();
        p.satellitesVisible = satellitesVisible;
        p.satellitesUsed = satellitesUsed;
        p.speedMps = location.hasSpeed() ? location.getSpeed() : -1f;
        p.altitudeM = location.hasAltitude() ? (float) location.getAltitude() : Float.NaN;
        p.provider = location.getProvider() == null ? "" : location.getProvider();
        return p;
    }

    private boolean isRecent(LastPosition p) {
        return p != null && p.valid && p.timestamp > 0 && System.currentTimeMillis() - p.timestamp <= RECENT_MAP_LOCATION_MS;
    }

    private List<PointRow> readRecentPoints(int limit) {
        List<PointRow> rows = new ArrayList<>();
        JSONArray array = readPointArray();
        for (int i = array.length() - 1; i >= 0 && rows.size() < limit; i--) {
            JSONObject object = array.optJSONObject(i);
            if (object == null) continue;
            PointRow row = new PointRow();
            row.sourceIndex = i;
            row.project = object.optString("project", "Proyecto general");
            row.name = object.optString("name", "Punto");
            row.symbol = object.optString("symbol", "●");
            row.description = object.optString("description", "");
            row.latitude = object.optDouble("latitude", Double.NaN);
            row.longitude = object.optDouble("longitude", Double.NaN);
            double alt = object.optDouble("altitude", Double.NaN);
            CoordinateUtils.Utm utm = CoordinateUtils.toUtm(row.latitude, row.longitude);
            if (utm.valid) {
                row.summary = "UTM " + CoordinateUtils.zoneWithBand(row.latitude, row.longitude) + " · "
                        + format3(utm.easting) + " E · " + format3(utm.northing) + " N"
                        + (Double.isNaN(alt) ? "" : " · " + format1(alt) + " m");
            } else {
                row.summary = format6(row.latitude) + ", " + format6(row.longitude);
            }
            row.time = relativeTime(object.optLong("timestamp", System.currentTimeMillis()));
            rows.add(row);
        }
        return rows;
    }

    private String qualityLabel(LastPosition p) {
        if (!p.valid) return gpsRunning ? "Buscando" : "Sin lectura";
        if ("network".equalsIgnoreCase(p.provider)) return "Asistida";
        if (p.accuracy <= 2.0) return "Excelente";
        if (p.accuracy <= 5.0) return "Buena";
        if (p.accuracy <= 10.0) return "Aceptable";
        if (p.accuracy <= 25.0) return "Media";
        return "Débil";
    }

    private int qualityColor(LastPosition p) {
        if (!p.valid) return NativeUi.SUB;
        if ("network".equalsIgnoreCase(p.provider)) return Color.rgb(255, 193, 74);
        if (p.accuracy <= 5.0) return Color.rgb(51, 220, 145);
        if (p.accuracy <= 15.0) return Color.rgb(255, 193, 74);
        return Color.rgb(255, 103, 116);
    }

    private String satelliteMetricText(int used, int visible) {
        return Math.max(0, used) + " usados\n" + Math.max(0, visible) + " visibles";
    }

    private String providerLabel(String provider) {
        if (provider == null || provider.trim().isEmpty()) return "Sin lectura";
        if ("gps".equalsIgnoreCase(provider)) return "GPS / GNSS";
        if ("network".equalsIgnoreCase(provider)) return "Red";
        if ("promedio_gnss".equalsIgnoreCase(provider)) return "Promedio GNSS";
        if (provider.startsWith("promedio")) return "Promedio asistido";
        return provider;
    }

    private String adjustedAltitude(double altitude) {
        double offset = Double.longBitsToDouble(getSharedPreferences(GPS_PREFS, MODE_PRIVATE)
                .getLong(GpsSettingsActivity.HEIGHT_OFFSET, Double.doubleToLongBits(0d)));
        return format1(altitude + offset) + " m" + (Math.abs(offset) >= 0.001 ? " (ajustada)" : "");
    }
    private String formatGeographic(double value, boolean latitude) {
        int mode = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getInt(GpsSettingsActivity.FORMAT, 0);
        return GpsSettingsActivity.latLon(value, latitude, mode);
    }
    private String format3(double value) { return String.format(Locale.US, "%,.3f", value).replace(',', ' '); }
    private String format6(double value) { return String.format(Locale.US, "%.6f", value); }
    private String format1(double value) { return String.format(Locale.US, "%.1f", value); }
    private String formatTime(long timestamp) {
        if (timestamp <= 0) return "sin hora";
        return new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date(timestamp));
    }
    private String relativeTime(long timestamp) {
        if (timestamp <= 0) return "Sin lectura";
        long diff = Math.max(0, System.currentTimeMillis() - timestamp);
        String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(timestamp));
        if (diff < 60000L) return "Ahora";
        if (diff < 60L * 60000L) return "Hace " + Math.max(1, diff / 60000L) + " min";
        if (diff < 24L * 60L * 60L * 1000L) return "Hoy, " + time;
        if (diff < 48L * 60L * 60L * 1000L) return "Ayer, " + time;
        return new SimpleDateFormat("dd/MM, HH:mm", Locale.getDefault()).format(new Date(timestamp));
    }

    private static final class LastPosition {
        boolean valid;
        double latitude;
        double longitude;
        double accuracy;
        long timestamp;
        int satellitesVisible;
        int satellitesUsed;
        float speedMps = -1f;
        float altitudeM = Float.NaN;
        String provider = "";
    }

    private static final class PointRow {
        int sourceIndex;
        String project;
        String name;
        String symbol;
        String description;
        String summary;
        String time;
        double latitude;
        double longitude;
    }

    @Override public void onContentChanged() {
        super.onContentChanged();
        NativeUi.applySystemBarInsets(this);
    }
}
