plugins {
    id("com.android.application")
}

val esriApiKeyProvider = providers.gradleProperty("ESRI_API_KEY")
    .orElse(providers.environmentVariable("ESRI_API_KEY"))
    .orElse("")

// Datos de firma para el AAB de release. Se leen de variables de entorno o de
// gradle.properties, nunca se escriben en el repositorio.
val storeFileProvider = providers.gradleProperty("GEOTOPO_STORE_FILE")
    .orElse(providers.environmentVariable("GEOTOPO_STORE_FILE")).orElse("")
val storePasswordProvider = providers.gradleProperty("GEOTOPO_STORE_PASSWORD")
    .orElse(providers.environmentVariable("GEOTOPO_STORE_PASSWORD")).orElse("")
val keyAliasProvider = providers.gradleProperty("GEOTOPO_KEY_ALIAS")
    .orElse(providers.environmentVariable("GEOTOPO_KEY_ALIAS")).orElse("")
val keyPasswordProvider = providers.gradleProperty("GEOTOPO_KEY_PASSWORD")
    .orElse(providers.environmentVariable("GEOTOPO_KEY_PASSWORD")).orElse("")

fun quotedBuildConfig(value: String): String = "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"") + "\""

android {
    namespace = "com.bph.geotopo"
    compileSdk = 36

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    defaultConfig {
        applicationId = "com.bph.geotopo"
        minSdk = 23
        targetSdk = 36
        versionCode = 63
        versionName = "1.30.2-campo-gps"
        buildConfigField("String", "ESRI_API_KEY", quotedBuildConfig(esriApiKeyProvider.get()))
    }

    signingConfigs {
        create("release") {
            val path = storeFileProvider.get()
            if (path.isNotEmpty()) {
                storeFile = file(path)
                storePassword = storePasswordProvider.get()
                keyAlias = keyAliasProvider.get()
                keyPassword = keyPasswordProvider.get()
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Solo se firma si se proporcionaron las credenciales.
            if (storeFileProvider.get().isNotEmpty()) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
        debug {
            isMinifyEnabled = false
        }
    }

    packaging {
        resources {
            excludes += setOf(
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE*",
                "META-INF/NOTICE*",
                "META-INF/*.kotlin_module"
            )
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("org.maplibre.gl:android-sdk:11.13.5")
}
