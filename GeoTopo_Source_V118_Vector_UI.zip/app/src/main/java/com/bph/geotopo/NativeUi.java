package com.bph.geotopo;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Native, scalable visual components for the Geo Topo interface. */
public final class NativeUi {
    public static final int BG = Color.rgb(2, 17, 32);
    public static final int BG_DEEP = Color.rgb(1, 12, 25);
    public static final int HEADER = Color.rgb(3, 35, 61);
    public static final int CARD = Color.rgb(12, 36, 58);
    public static final int CARD_DARK = Color.rgb(7, 28, 48);
    public static final int CARD_LIGHT = Color.rgb(18, 50, 78);
    public static final int BLUE = Color.rgb(43, 121, 255);
    public static final int BLUE_LIGHT = Color.rgb(92, 159, 255);
    public static final int TEXT = Color.rgb(248, 250, 253);
    public static final int SUB = Color.rgb(169, 193, 219);
    public static final int BORDER = Color.rgb(72, 112, 150);

    private NativeUi() {}

    public static int dp(Context c, int value) {
        return Math.round(value * c.getResources().getDisplayMetrics().density);
    }

    public static int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    public static void styleWindow(Activity activity) {
        Window window = activity.getWindow();
        // En Android 15+ (targetSdk 35+) estas llamadas ya no tienen efecto: el sistema
        // fuerza el modo borde a borde. Se conservan solo para versiones anteriores.
        if (Build.VERSION.SDK_INT < 35) {
            window.setStatusBarColor(BG_DEEP);
            window.setNavigationBarColor(Color.BLACK);
        }
    }

    /**
     * Reserva el espacio de la barra de estado y de navegacion.
     * Necesario porque con targetSdk 35+ Android dibuja la app debajo de las barras
     * del sistema y, sin esto, la cabecera y los botones inferiores quedan tapados.
     */
    public static void applySystemBarInsets(Activity activity) {
        if (activity == null) return;
        final View content = activity.findViewById(android.R.id.content);
        if (content == null) return;
        View root = content;
        if (content instanceof ViewGroup && ((ViewGroup) content).getChildCount() > 0) {
            root = ((ViewGroup) content).getChildAt(0);
        }
        final View target = root;
        final int left = target.getPaddingLeft();
        final int top = target.getPaddingTop();
        final int right = target.getPaddingRight();
        final int bottom = target.getPaddingBottom();
        target.setOnApplyWindowInsetsListener((v, insets) -> {
            int insetTop, insetBottom, insetLeft, insetRight;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(
                        android.view.WindowInsets.Type.systemBars()
                                | android.view.WindowInsets.Type.displayCutout());
                insetTop = bars.top; insetBottom = bars.bottom;
                insetLeft = bars.left; insetRight = bars.right;
            } else {
                insetTop = insets.getSystemWindowInsetTop();
                insetBottom = insets.getSystemWindowInsetBottom();
                insetLeft = insets.getSystemWindowInsetLeft();
                insetRight = insets.getSystemWindowInsetRight();
            }
            v.setPadding(left + insetLeft, top + insetTop, right + insetRight, bottom + insetBottom);
            return insets;
        });
        target.requestApplyInsets();
    }

    public static FrameLayout screen(Context context) {
        FrameLayout root = new FrameLayout(context);
        root.setBackgroundColor(BG);
        TopoBackgroundView background = new TopoBackgroundView(context);
        root.addView(background, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        return root;
    }

    public static ScrollView scroll(Context context, View child) {
        ScrollView scroll = new ScrollView(context);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.addView(child, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        return scroll;
    }

    public static LinearLayout column(Context context) {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    public static LinearLayout row(Context context) {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    public static TextView text(Context context, String value, float sp, boolean bold, int color) {
        TextView text = new TextView(context);
        text.setText(value);
        ResponsiveUi.configureText(text, sp);
        text.setTextColor(color);
        text.setGravity(Gravity.CENTER_VERTICAL);
        text.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        text.setIncludeFontPadding(false);
        return text;
    }

    public static GradientDrawable rounded(int color, int radiusDp, int strokeDp, int strokeColor, Context c) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(c, radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(c, strokeDp), strokeColor);
        return drawable;
    }

    public static GradientDrawable gradient(int start, int end, int radiusDp, int strokeColor, Context c) {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{start, end});
        drawable.setCornerRadius(dp(c, radiusDp));
        drawable.setStroke(dp(c, 1), strokeColor);
        return drawable;
    }

    public static View dashboardHeader(Context context, View.OnClickListener settingsClick) {
        LinearLayout bar = row(context);
        bar.setPadding(dp(context, 12), dp(context, 5), dp(context, 10), dp(context, 4));
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.TRANSPARENT);

        TextView title = text(context, "Cálculos topográficos", 17.0f, true, TEXT);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setIncludeFontPadding(false);
        bar.addView(title, new LinearLayout.LayoutParams(0, dp(context, 34), 1f));

        TextView settings = text(context, "⚙", 15.5f, true, Color.WHITE);
        settings.setGravity(Gravity.CENTER);
        settings.setIncludeFontPadding(false);
        settings.setContentDescription("Ajustes");
        settings.setBackground(rounded(withAlpha(BLUE, 24), 17, 1,
                withAlpha(BLUE_LIGHT, 125), context));
        settings.setElevation(dp(context, 1));
        settings.setOnClickListener(settingsClick);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(dp(context, 34), dp(context, 34));
        slp.setMargins(dp(context, 8), 0, 0, 0);
        bar.addView(settings, slp);
        return bar;
    }

    public static View pageHeader(Context context, String titleValue, String subtitleValue,
                                  View.OnClickListener backClick, String actionIcon,
                                  View.OnClickListener actionClick) {
        LinearLayout bar = row(context);
        bar.setPadding(dp(context, 3), dp(context, 4), dp(context, 8), dp(context, 4));
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(withAlpha(HEADER, 235));

        TextView back = text(context, "‹", 29, false, Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setIncludeFontPadding(false);
        back.setContentDescription("Volver");
        back.setOnClickListener(backClick);
        bar.addView(back, new LinearLayout.LayoutParams(dp(context, 36), dp(context, 44)));

        LinearLayout labels = column(context);
        labels.setGravity(Gravity.CENTER_VERTICAL);
        int len = titleValue == null ? 0 : titleValue.length();
        float titleSp = len > 24 ? 15.6f : (len > 19 ? 16.4f : 17.4f);
        TextView title = text(context, titleValue, titleSp, true, TEXT);
        ResponsiveUi.configureCompactText(title, titleSp, 12, 1);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setIncludeFontPadding(false);
        TextView subtitle = text(context, subtitleValue, 10.2f, false, SUB);
        ResponsiveUi.configureCompactText(subtitle, 10.2f, 8, 1);
        subtitle.setSingleLine(true);
        subtitle.setEllipsize(TextUtils.TruncateAt.END);
        subtitle.setIncludeFontPadding(false);
        subtitle.setPadding(0, dp(context, 1), 0, 0);
        labels.addView(title);
        labels.addView(subtitle);
        bar.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        if (actionIcon != null) {
            TextView action = text(context, actionIcon, 15.5f, true, Color.WHITE);
            action.setGravity(Gravity.CENTER);
            action.setIncludeFontPadding(false);
            action.setBackground(rounded(withAlpha(BLUE, 22), 17, 1, withAlpha(BLUE_LIGHT, 135), context));
            action.setOnClickListener(actionClick);
            LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(context, 34), dp(context, 34));
            alp.setMargins(dp(context, 6), 0, 0, 0);
            bar.addView(action, alp);
        }
        return bar;
    }

    public static View fieldToolsHeader(Context context, View.OnClickListener backClick) {
        // V24: cabecera compacta y coherente con GPS y el resto de pantallas.
        // Sin divisor alto ni flecha sobredimensionada; el título cabe completo.
        return pageHeader(context,
                "Herramientas de campo",
                "Trabajo de campo topográfico",
                backClick,
                null,
                null);
    }

    /** Dashboard hero card with code-drawn topographic artwork and native text/actions. */
    public static View dashboardHeroImageCard(Context context, boolean gps, View.OnClickListener click) {
        String key = gps ? "gps" : "field";
        String title = gps ? "GPS y mapas" : "Herramientas de campo";
        String subtitle = gps ? "Posición, mapas y datos GNSS" : "Instrumentos y utilidades de campo";
        return dashboardImageCardInternal(context, key, title, subtitle, 0.58f, true, click);
    }

    /** Dashboard medium card: vector artwork + title + chevron, with no bitmap dependency. */
    public static View dashboardToolImageCard(Context context, String key, String title,
                                              View.OnClickListener click) {
        switch (key) {
            case "converter":
            case "compass":
            case "azimuth":
            case "coordinates":
            case "distance":
            case "two_hair":
            case "level":
            case "stadia":
                break;
            default: throw new IllegalArgumentException("Unsupported dashboard card: " + key);
        }
        return dashboardImageCardInternal(context, key, title, null, 1.04f, false, click);
    }

    /** Wide dashboard card used for the closed traverse. */
    public static View dashboardWideImageCard(Context context, String title,
                                              View.OnClickListener click) {
        return dashboardImageCardInternal(context, "polygon",
                title, null, 2.25f, false, click);
    }

    private static View dashboardImageCardInternal(Context context, String artKey,
                                                   String titleValue, String subtitleValue,
                                                   float aspectRatio, boolean hero,
                                                   View.OnClickListener click) {
        RatioCardLayout card = new RatioCardLayout(context, aspectRatio);
        card.setBackground(gradient(Color.rgb(11, 42, 69), Color.rgb(3, 19, 37),
                hero ? 20 : 17, withAlpha(BLUE_LIGHT, hero ? 150 : 120), context));
        card.setClipToOutline(true);
        card.setElevation(dp(context, 2));
        card.setOnClickListener(click);

        TopoCardArtView art = new TopoCardArtView(context, artKey, hero);
        card.addView(art, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        View tint = new View(context);
        tint.setBackgroundColor(withAlpha(Color.rgb(0, 16, 36), hero ? 18 : 34));
        card.addView(tint, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        GradientDrawable shade = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{withAlpha(Color.rgb(0, 14, 33), 0), withAlpha(Color.rgb(0, 10, 26), hero ? 135 : 160)});
        shade.setCornerRadius(dp(context, hero ? 20 : 17));
        View shadeView = new View(context);
        shadeView.setBackground(shade);
        card.addView(shadeView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        if (hero) {
            // Title gets the full card width so long names never become compressed by the arrow.
            TextView title = text(context, titleValue, 18.4f, true, TEXT);
            ResponsiveUi.configureCompactText(title, 18.4f, 12, 2);
            title.setGravity(Gravity.BOTTOM | Gravity.START);
            title.setMaxLines(2);
            title.setEllipsize(TextUtils.TruncateAt.END);
            title.setLineSpacing(0, 1.0f);
            title.setPadding(dp(context, 15), 0, dp(context, 15), dp(context, 66));
            card.addView(title, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));

            TextView subtitle = text(context, subtitleValue, 12.2f, false, Color.rgb(190, 220, 248));
            ResponsiveUi.configureCompactText(subtitle, 12.2f, 9, 3);
            subtitle.setGravity(Gravity.BOTTOM | Gravity.START);
            subtitle.setMaxLines(3);
            subtitle.setLineSpacing(0, 1.04f);
            subtitle.setPadding(dp(context, 15), 0, dp(context, 38), dp(context, 16));
            card.addView(subtitle, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));

            TextView arrow = text(context, "›", 35, false, Color.WHITE);
            arrow.setGravity(Gravity.CENTER);
            FrameLayout.LayoutParams alp = new FrameLayout.LayoutParams(
                    dp(context, 32), dp(context, 42), Gravity.END | Gravity.BOTTOM);
            alp.setMargins(0, 0, dp(context, 8), dp(context, 9));
            card.addView(arrow, alp);
        } else {
            TextView title = text(context, titleValue, 15.8f, true, TEXT);
            ResponsiveUi.configureCompactText(title, 15.8f, 10, 2);
            title.setGravity(Gravity.BOTTOM | Gravity.START);
            title.setMaxLines(2);
            title.setEllipsize(TextUtils.TruncateAt.END);
            title.setLineSpacing(0, 1.0f);
            title.setPadding(dp(context, 14), 0, dp(context, 34), dp(context, 14));
            card.addView(title, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));

            TextView arrow = text(context, "›", 31, false, Color.WHITE);
            arrow.setGravity(Gravity.CENTER);
            FrameLayout.LayoutParams alp = new FrameLayout.LayoutParams(
                    dp(context, 34), dp(context, 46), Gravity.END | Gravity.BOTTOM);
            alp.setMargins(0, 0, dp(context, 8), dp(context, 8));
            card.addView(arrow, alp);
        }
        return card;
    }

    public static View fieldToolImageCard(Context context, String key, String titleValue,
                                          String subtitleValue, View.OnClickListener click) {
        switch (key) {
            case "stakeout":
            case "track":
            case "quality":
            case "external":
            case "cogo":
            case "area":
            case "traverse":
            case "leveling":
            case "profile":
            case "offline":
            case "notebook":
                break;
            default: throw new IllegalArgumentException("Unsupported field card: " + key);
        }

        FrameLayout card = new FrameLayout(context);
        card.setBackground(gradient(Color.rgb(12, 43, 70), Color.rgb(4, 20, 38),
                18, withAlpha(BLUE_LIGHT, 120), context));
        card.setClipToOutline(true);
        card.setElevation(dp(context, 2));
        card.setOnClickListener(click);

        TopoCardArtView art = new TopoCardArtView(context, key, false);
        card.addView(art, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        View tint = new View(context);
        tint.setBackgroundColor(withAlpha(Color.rgb(0, 20, 46), 28));
        card.addView(tint, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        GradientDrawable shade = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{withAlpha(Color.rgb(0, 13, 30), 25), withAlpha(Color.rgb(0, 13, 30), 150)});
        shade.setCornerRadius(dp(context, 18));
        View shadeView = new View(context);
        shadeView.setBackground(shade);
        card.addView(shadeView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout labels = column(context);
        labels.setGravity(Gravity.CENTER_VERTICAL);
        labels.setPadding(dp(context, 16), dp(context, 13), dp(context, 48), dp(context, 13));
        TextView title = text(context, titleValue, 18.2f, true, TEXT);
        title.setMaxLines(2);
        title.setLineSpacing(0, 1.0f);
        TextView subtitle = text(context, subtitleValue, 13.4f, false, Color.rgb(201, 216, 233));
        subtitle.setMaxLines(2);
        subtitle.setLineSpacing(0, 1.05f);
        subtitle.setPadding(0, dp(context, 6), 0, 0);
        labels.addView(title);
        labels.addView(subtitle);
        card.addView(labels, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        TextView arrow = text(context, "›", 31, false, Color.WHITE);
        arrow.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams alp = new FrameLayout.LayoutParams(
                dp(context, 34), dp(context, 48), Gravity.END | Gravity.CENTER_VERTICAL);
        alp.setMargins(0, 0, dp(context, 8), 0);
        card.addView(arrow, alp);
        return card;
    }

    /** Keeps each photographic card proportional on narrow and wide Android screens. */
    public static class RatioCardLayout extends FrameLayout {
        private final float aspectRatio;

        public RatioCardLayout(Context context, float aspectRatio) {
            super(context);
            this.aspectRatio = aspectRatio <= 0f ? 1f : aspectRatio;
        }

        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int width = MeasureSpec.getSize(widthMeasureSpec);
            if (width <= 0) {
                super.onMeasure(widthMeasureSpec, heightMeasureSpec);
                return;
            }
            int height = Math.max(1, Math.round(width / aspectRatio));
            super.onMeasure(widthMeasureSpec,
                    MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY));
        }
    }

    public static View sectionHeader(Context context, String icon, String titleValue, String rightText,
                                     View.OnClickListener rightClick) {
        LinearLayout row = row(context);
        row.setPadding(dp(context, 2), dp(context, 10), dp(context, 2), dp(context, 7));
        TextView iconView = text(context, icon, 18.5f, true, BLUE_LIGHT);
        iconView.setGravity(Gravity.CENTER);
        row.addView(iconView, new LinearLayout.LayoutParams(dp(context, 36), dp(context, 36)));
        TextView title = text(context, titleValue, 15.6f, true, TEXT);
        title.setLetterSpacing(0.06f);
        row.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(context, 36)));
        View line = new View(context);
        line.setBackgroundColor(withAlpha(BORDER, 80));
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(0, dp(context, 1), 1f);
        llp.setMargins(dp(context, 12), 0, dp(context, 10), 0);
        row.addView(line, llp);
        if (rightText != null) {
            TextView right = text(context, rightText + "  ›", 13.5f, false, BLUE_LIGHT);
            right.setOnClickListener(rightClick);
            row.addView(right);
        }
        return row;
    }

    public static View simpleSectionHeader(Context context, String titleValue, String rightText,
                                           View.OnClickListener rightClick) {
        LinearLayout row = row(context);
        row.setPadding(dp(context, 2), dp(context, 14), dp(context, 2), dp(context, 9));
        TextView title = text(context, titleValue, 15.8f, true, TEXT);
        title.setLetterSpacing(0.055f);
        row.addView(title, new LinearLayout.LayoutParams(0, dp(context, 34), 1f));
        if (rightText != null) {
            TextView right = text(context, rightText + "  ›", 13.8f, false, BLUE_LIGHT);
            right.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            right.setOnClickListener(rightClick);
            row.addView(right, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(context, 34)));
        }
        return row;
    }

    public static View menuCard(Context context, String iconType, String titleValue,
                                String subtitleValue, View.OnClickListener click, int minHeightDp) {
        LinearLayout card = column(context);
        card.setGravity(Gravity.TOP);
        card.setPadding(dp(context, 11), dp(context, 11), dp(context, 11), dp(context, 11));
        card.setMinimumHeight(dp(context, minHeightDp));
        card.setBackground(gradient(CARD_LIGHT, CARD_DARK, 17, withAlpha(BORDER, 170), context));
        card.setElevation(dp(context, 2));
        card.setOnClickListener(click);

        LinearLayout topRow = row(context);
        topRow.setGravity(Gravity.TOP | Gravity.CENTER_VERTICAL);
        FrameLayout iconBox = iconTile(context, iconType, 54);
        topRow.addView(iconBox, new LinearLayout.LayoutParams(dp(context, 52), dp(context, 52)));
        View spacer = new View(context);
        topRow.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));
        TextView arrow = text(context, "›", 28, false, Color.rgb(203, 220, 237));
        arrow.setGravity(Gravity.CENTER);
        topRow.addView(arrow, new LinearLayout.LayoutParams(dp(context, 26), dp(context, 36)));
        card.addView(topRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        float menuTitleSp = subtitleValue == null ? 15.1f : 14.7f;
        TextView title = text(context, titleValue, menuTitleSp, true, TEXT);
        ResponsiveUi.configureCompactText(title, menuTitleSp, 10, 2);
        title.setPadding(0, dp(context, 8), 0, 0);
        title.setMaxLines(2);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setLineSpacing(0, 0.98f);
        card.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        if (subtitleValue != null && !subtitleValue.isEmpty()) {
            TextView sub = text(context, subtitleValue, 12.4f, false, SUB);
            ResponsiveUi.configureCompactText(sub, 12.4f, 9, 2);
            sub.setPadding(0, dp(context, 4), 0, 0);
            sub.setMaxLines(2);
            sub.setEllipsize(TextUtils.TruncateAt.END);
            sub.setLineSpacing(0, 1.05f);
            card.addView(sub);
        }
        return card;
    }

    public static FrameLayout iconTile(Context context, String type, int sizeDp) {
        return iconTile(context, type, sizeDp,
                Color.rgb(27, 84, 175), Color.rgb(13, 54, 119), Color.rgb(76, 145, 255));
    }

    public static FrameLayout iconTile(Context context, String type, int sizeDp,
                                       int backgroundStart, int backgroundEnd, int glyphColor) {
        FrameLayout box = new FrameLayout(context);
        box.setBackground(gradient(backgroundStart, backgroundEnd, 15,
                withAlpha(glyphColor, 105), context));
        IconGlyphView glyph = new IconGlyphView(context, type);
        glyph.setGlyphColor(glyphColor);
        int margin = dp(context, 10);
        FrameLayout.LayoutParams glp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        glp.setMargins(margin, margin, margin, margin);
        box.addView(glyph, glp);
        return box;
    }

    public static class TopoBackgroundView extends View {
        private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        public TopoBackgroundView(Context context) {
            super(context);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            linePaint.setStyle(Paint.Style.STROKE);
            linePaint.setStrokeWidth(dp(context, 1));
            linePaint.setColor(withAlpha(BLUE_LIGHT, 22));
            glowPaint.setStyle(Paint.Style.STROKE);
            glowPaint.setStrokeWidth(dp(context, 1));
            glowPaint.setColor(withAlpha(BLUE, 12));
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            canvas.drawColor(BG);
            int w = getWidth();
            int h = getHeight();
            for (int i = -4; i < 18; i++) {
                float baseY = i * h / 12f;
                path.reset();
                path.moveTo(-40, baseY + 30);
                for (int x = 0; x <= w + 60; x += 45) {
                    float y = baseY + (float) Math.sin((x * 0.015) + i * 0.7) * 24f
                            + (float) Math.cos((x * 0.007) - i) * 16f;
                    path.lineTo(x, y);
                }
                canvas.drawPath(path, i % 3 == 0 ? glowPaint : linePaint);
            }
        }
    }

    /** Lightweight card artwork that replaces the old photographic PNG panels. */
    public static class TopoCardArtView extends View {
        private final String key;
        private final boolean hero;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        public TopoCardArtView(Context context, String key, boolean hero) {
            super(context);
            this.key = key == null ? "map" : key;
            this.hero = hero;
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            fill.setStyle(Paint.Style.FILL);
            textPaint.setTypeface(Typeface.create("sans", Typeface.BOLD));
            textPaint.setTextAlign(Paint.Align.LEFT);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            if (w <= 0 || h <= 0) return;
            drawBase(canvas, w, h);
            String visual = normalizedKey(key);
            switch (visual) {
                case "gps": drawRouteMap(canvas, w, h, true); break;
                case "field": drawInstrument(canvas, w, h); break;
                case "converter": drawConverter(canvas, w, h); break;
                case "compass": drawCompass(canvas, w, h); break;
                case "azimuth": drawAzimuth(canvas, w, h); break;
                case "coordinates": drawCoordinates(canvas, w, h); break;
                case "distance": drawSlope(canvas, w, h); break;
                case "two_hair": drawTwoHair(canvas, w, h); break;
                case "polygon": drawPolygon(canvas, w, h); break;
                case "level": drawLevel(canvas, w, h); break;
                case "stadia": drawStaff(canvas, w, h); break;
                case "stakeout": drawInstrument(canvas, w, h); drawTarget(canvas, w * .30f, h * .62f, Math.min(w, h) * .13f); break;
                case "track": drawRouteMap(canvas, w, h, false); break;
                case "quality": drawSatellite(canvas, w, h); break;
                case "external": drawReceiver(canvas, w, h); break;
                case "cogo": drawCoordinates(canvas, w, h); drawTarget(canvas, w * .68f, h * .42f, Math.min(w, h) * .10f); break;
                case "area": drawArea(canvas, w, h); break;
                case "traverse": drawTraverse(canvas, w, h); break;
                case "leveling": drawLevel(canvas, w, h); break;
                case "profile": drawProfile(canvas, w, h); break;
                case "offline": drawMapLayers(canvas, w, h); break;
                case "notebook": drawNotebook(canvas, w, h); break;
                default: drawCoordinates(canvas, w, h); break;
            }
        }

        private String normalizedKey(String value) {
            if ("field".equals(value)) return "field";
            if ("gps".equals(value)) return "gps";
            return value;
        }

        private void drawBase(Canvas canvas, float w, float h) {
            fill.setColor(Color.rgb(5, 25, 46));
            canvas.drawRect(0, 0, w, h, fill);
            fill.setColor(withAlpha(BLUE, hero ? 28 : 20));
            canvas.drawCircle(w * .82f, h * .10f, Math.max(w, h) * .55f, fill);
            fill.setColor(withAlpha(Color.rgb(41, 255, 190), 13));
            canvas.drawCircle(w * .18f, h * .86f, Math.max(w, h) * .42f, fill);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(getContext(), 1));
            paint.setColor(withAlpha(BLUE_LIGHT, hero ? 42 : 34));
            for (int i = -2; i < 8; i++) {
                float baseY = h * (.18f + i * .13f);
                path.reset();
                path.moveTo(-w * .10f, baseY);
                for (float x = -w * .05f; x <= w * 1.08f; x += Math.max(18f, w / 9f)) {
                    float y = baseY + (float) Math.sin(x * .025f + i * .9f) * h * .045f
                            + (float) Math.cos(x * .014f - i) * h * .025f;
                    path.lineTo(x, y);
                }
                canvas.drawPath(path, paint);
            }
        }

        private void drawRouteMap(Canvas canvas, float w, float h, boolean withCoords) {
            paint.setStrokeWidth(dp(getContext(), 2));
            paint.setColor(BLUE_LIGHT);
            path.reset();
            path.moveTo(w * .18f, h * .40f);
            path.cubicTo(w * .35f, h * .20f, w * .38f, h * .70f, w * .58f, h * .45f);
            path.cubicTo(w * .70f, h * .30f, w * .74f, h * .52f, w * .87f, h * .28f);
            canvas.drawPath(path, paint);
            drawPoint(canvas, w * .18f, h * .40f, w);
            drawPoint(canvas, w * .41f, h * .52f, w);
            drawPoint(canvas, w * .62f, h * .42f, w);
            drawPin(canvas, w * .78f, h * .30f, Math.min(w, h) * .18f);
            if (withCoords) {
                textPaint.setTextSize(Math.max(10f, w * .045f));
                textPaint.setColor(Color.rgb(130, 193, 255));
                canvas.drawText("N 4897532", w * .12f, h * .63f, textPaint);
                canvas.drawText("E 324621", w * .12f, h * .76f, textPaint);
            }
        }

        private void drawInstrument(Canvas canvas, float w, float h) {
            float cx = w * .66f, cy = h * .42f, s = Math.min(w, h) * .30f;
            paint.setStrokeWidth(dp(getContext(), 2));
            paint.setColor(Color.rgb(119, 213, 204));
            fill.setColor(withAlpha(Color.rgb(92, 159, 255), 30));
            canvas.drawRoundRect(new RectF(cx - s * .34f, cy - s * .62f, cx + s * .34f, cy + s * .42f), s * .10f, s * .10f, fill);
            canvas.drawRoundRect(new RectF(cx - s * .34f, cy - s * .62f, cx + s * .34f, cy + s * .42f), s * .10f, s * .10f, paint);
            canvas.drawCircle(cx, cy - s * .10f, s * .20f, paint);
            canvas.drawCircle(cx, cy - s * .10f, s * .09f, paint);
            canvas.drawLine(cx - s * .15f, cy + s * .42f, cx - s * .44f, cy + s * .92f, paint);
            canvas.drawLine(cx + s * .15f, cy + s * .42f, cx + s * .44f, cy + s * .92f, paint);
            canvas.drawLine(cx, cy + s * .42f, cx, cy + s * .96f, paint);
            paint.setColor(withAlpha(BLUE_LIGHT, 140));
            canvas.drawLine(w * .13f, h * .52f, w * .46f, h * .52f, paint);
            canvas.drawLine(w * .30f, h * .36f, w * .30f, h * .68f, paint);
        }

        private void drawConverter(Canvas canvas, float w, float h) {
            float x = w * .20f, y = h * .22f, s = Math.min(w, h) * .34f;
            paint.setStrokeWidth(dp(getContext(), 2));
            paint.setColor(Color.rgb(176, 218, 255));
            fill.setColor(withAlpha(BLUE_LIGHT, 35));
            canvas.drawRoundRect(new RectF(x, y, x + s, y + s * 1.18f), s * .09f, s * .09f, fill);
            canvas.drawRoundRect(new RectF(x, y, x + s, y + s * 1.18f), s * .09f, s * .09f, paint);
            canvas.drawRect(x + s * .18f, y + s * .14f, x + s * .82f, y + s * .34f, paint);
            for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) {
                canvas.drawRoundRect(new RectF(x + s * (.18f + c * .23f), y + s * (.47f + r * .20f),
                        x + s * (.31f + c * .23f), y + s * (.60f + r * .20f)), 4, 4, paint);
            }
            textPaint.setTextSize(Math.max(11f, w * .07f));
            textPaint.setColor(Color.rgb(140, 201, 255));
            canvas.drawText("m   ft", w * .58f, h * .34f, textPaint);
            canvas.drawText("km  ha", w * .58f, h * .52f, textPaint);
        }

        private void drawCompass(Canvas canvas, float w, float h) {
            float cx = w * .58f, cy = h * .36f, r = Math.min(w, h) * .28f;
            paint.setStrokeWidth(dp(getContext(), 2));
            paint.setColor(Color.rgb(141, 201, 255));
            canvas.drawCircle(cx, cy, r, paint);
            for (int i = 0; i < 16; i++) {
                double a = Math.PI * 2 * i / 16.0;
                float r1 = r * (i % 4 == 0 ? .75f : .86f);
                canvas.drawLine(cx + (float) Math.cos(a) * r1, cy + (float) Math.sin(a) * r1,
                        cx + (float) Math.cos(a) * r, cy + (float) Math.sin(a) * r, paint);
            }
            fill.setColor(Color.rgb(58, 154, 255));
            path.reset();
            path.moveTo(cx + r * .16f, cy - r * .78f);
            path.lineTo(cx + r * .04f, cy + r * .12f);
            path.lineTo(cx - r * .58f, cy + r * .62f);
            path.lineTo(cx - r * .10f, cy - r * .05f);
            path.close();
            canvas.drawPath(path, fill);
            drawLabel(canvas, "N", cx - r * .07f, cy - r * .68f, w);
        }

        private void drawAzimuth(Canvas canvas, float w, float h) {
            paint.setStrokeWidth(dp(getContext(), 2));
            paint.setColor(BLUE_LIGHT);
            float ax = w * .25f, ay = h * .70f, bx = w * .78f, by = h * .28f;
            canvas.drawLine(ax, ay, bx, by, paint);
            canvas.drawLine(ax, ay, ax, h * .22f, paint);
            canvas.drawArc(new RectF(ax - w * .10f, ay - w * .10f, ax + w * .30f, ay + w * .30f), 270, 50, false, paint);
            drawPoint(canvas, ax, ay, w);
            drawPoint(canvas, bx, by, w);
            drawLabel(canvas, "135.6°", ax + w * .22f, ay - h * .28f, w);
        }

        private void drawCoordinates(Canvas canvas, float w, float h) {
            paint.setStrokeWidth(dp(getContext(), 1));
            paint.setColor(withAlpha(BLUE_LIGHT, 105));
            for (int i = 1; i < 5; i++) {
                float x = w * (.15f + i * .14f);
                canvas.drawLine(x, h * .18f, x, h * .76f, paint);
                float y = h * (.16f + i * .12f);
                canvas.drawLine(w * .12f, y, w * .85f, y, paint);
            }
            paint.setStrokeWidth(dp(getContext(), 2));
            paint.setColor(BLUE_LIGHT);
            canvas.drawLine(w * .50f, h * .14f, w * .50f, h * .80f, paint);
            canvas.drawLine(w * .12f, h * .46f, w * .88f, h * .46f, paint);
            drawTarget(canvas, w * .50f, h * .46f, Math.min(w, h) * .12f);
            drawLabel(canvas, "E 324621", w * .60f, h * .31f, w);
            drawLabel(canvas, "N 4897532", w * .60f, h * .44f, w);
        }

        private void drawSlope(Canvas canvas, float w, float h) {
            paint.setStrokeWidth(dp(getContext(), 2));
            paint.setColor(BLUE_LIGHT);
            float x1 = w * .16f, y1 = h * .68f, x2 = w * .84f, y2 = h * .28f;
            canvas.drawLine(x1, y1, x2, y2, paint);
            canvas.drawLine(x1, y1, x2, y1, paint);
            canvas.drawLine(x2, y2, x2, y1, paint);
            drawPoint(canvas, x1, y1, w);
            drawPoint(canvas, x2, y2, w);
            drawLabel(canvas, "125.4 m", w * .42f, h * .43f, w);
            drawLabel(canvas, "Δh 12.6", w * .68f, h * .58f, w);
        }

        private void drawTwoHair(Canvas canvas, float w, float h) {
            float cx = w * .63f, cy = h * .43f, r = Math.min(w, h) * .30f;
            paint.setStrokeWidth(dp(getContext(), 2));
            paint.setColor(Color.rgb(150, 208, 255));
            canvas.drawCircle(cx, cy, r, paint);
            canvas.drawLine(cx - r, cy, cx + r, cy, paint);
            canvas.drawLine(cx, cy - r, cx, cy + r, paint);
            drawStaffAt(canvas, cx, cy, r * .95f);
            drawLabel(canvas, "H sup 1.832", w * .08f, h * .34f, w);
            drawLabel(canvas, "H cen 1.275", w * .08f, h * .49f, w);
            drawLabel(canvas, "H inf 0.718", w * .08f, h * .64f, w);
        }

        private void drawPolygon(Canvas canvas, float w, float h) {
            float[] xs = { .14f, .36f, .70f, .86f, .58f, .25f };
            float[] ys = { .55f, .24f, .30f, .58f, .76f, .72f };
            paint.setStrokeWidth(dp(getContext(), 2));
            paint.setColor(BLUE_LIGHT);
            path.reset();
            for (int i = 0; i < xs.length; i++) {
                float x = xs[i] * w, y = ys[i] * h;
                if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
            }
            path.close();
            canvas.drawPath(path, paint);
            fill.setColor(withAlpha(BLUE, 35));
            canvas.drawPath(path, fill);
            for (int i = 0; i < xs.length; i++) drawPoint(canvas, xs[i] * w, ys[i] * h, w);
            drawLabel(canvas, "2.35 ha", w * .43f, h * .55f, w);
        }

        private void drawArea(Canvas canvas, float w, float h) {
            drawPolygon(canvas, w, h);
        }

        private void drawTraverse(Canvas canvas, float w, float h) {
            paint.setStrokeWidth(dp(getContext(), 2));
            paint.setColor(BLUE_LIGHT);
            float[] xs = { .16f, .36f, .50f, .68f, .84f };
            float[] ys = { .67f, .45f, .61f, .36f, .55f };
            for (int i = 0; i < xs.length - 1; i++) {
                canvas.drawLine(xs[i] * w, ys[i] * h, xs[i + 1] * w, ys[i + 1] * h, paint);
                drawPoint(canvas, xs[i] * w, ys[i] * h, w);
            }
            drawPoint(canvas, xs[xs.length - 1] * w, ys[ys.length - 1] * h, w);
        }

        private void drawLevel(Canvas canvas, float w, float h) {
            paint.setStrokeWidth(dp(getContext(), 2));
            paint.setColor(Color.rgb(131, 210, 255));
            float x = w * .26f, y = h * .50f, s = Math.min(w, h) * .27f;
            canvas.drawRoundRect(new RectF(x - s * .75f, y - s * .28f, x + s * .65f, y + s * .18f), 8, 8, paint);
            canvas.drawCircle(x - s * .05f, y - s * .05f, s * .16f, paint);
            canvas.drawLine(x - s * .40f, y + s * .18f, x - s * .75f, y + s * .82f, paint);
            canvas.drawLine(x + s * .32f, y + s * .18f, x + s * .72f, y + s * .82f, paint);
            drawStaffAt(canvas, w * .72f, h * .50f, Math.min(w, h) * .42f);
        }

        private void drawStaff(Canvas canvas, float w, float h) {
            drawStaffAt(canvas, w * .66f, h * .43f, Math.min(w, h) * .62f);
            paint.setColor(BLUE_LIGHT);
            paint.setStrokeWidth(dp(getContext(), 1));
            canvas.drawLine(w * .20f, h * .35f, w * .84f, h * .35f, paint);
            canvas.drawLine(w * .20f, h * .50f, w * .84f, h * .50f, paint);
            canvas.drawLine(w * .20f, h * .65f, w * .84f, h * .65f, paint);
        }

        private void drawProfile(Canvas canvas, float w, float h) {
            paint.setStrokeWidth(dp(getContext(), 2));
            paint.setColor(Color.rgb(160, 216, 255));
            path.reset();
            path.moveTo(w * .10f, h * .70f);
            path.cubicTo(w * .22f, h * .62f, w * .28f, h * .46f, w * .42f, h * .54f);
            path.cubicTo(w * .58f, h * .64f, w * .66f, h * .24f, w * .86f, h * .34f);
            canvas.drawPath(path, paint);
            for (int i = 1; i <= 3; i++) {
                float x = w * (.22f + i * .17f);
                canvas.drawLine(x, h * .75f, x, h * (.70f - i * .10f), paint);
            }
        }

        private void drawSatellite(Canvas canvas, float w, float h) {
            paint.setStrokeWidth(dp(getContext(), 2));
            paint.setColor(Color.rgb(133, 203, 255));
            float cx = w * .50f, cy = h * .36f, s = Math.min(w, h) * .20f;
            canvas.drawRoundRect(new RectF(cx - s * .35f, cy - s * .20f, cx + s * .35f, cy + s * .20f), 6, 6, paint);
            canvas.drawRect(cx - s * 1.20f, cy - s * .55f, cx - s * .52f, cy + s * .10f, paint);
            canvas.drawRect(cx + s * .52f, cy - s * .10f, cx + s * 1.20f, cy + s * .55f, paint);
            paint.setColor(Color.rgb(64, 232, 170));
            canvas.drawArc(new RectF(cx - s * .15f, cy + s * .35f, cx + s * 1.8f, cy + s * 2.3f), 205, 52, false, paint);
            canvas.drawArc(new RectF(cx - s * .45f, cy + s * .10f, cx + s * 2.25f, cy + s * 2.8f), 205, 52, false, paint);
        }

        private void drawReceiver(Canvas canvas, float w, float h) {
            paint.setStrokeWidth(dp(getContext(), 2));
            paint.setColor(Color.rgb(128, 213, 255));
            float cx = w * .70f, cy = h * .34f, r = Math.min(w, h) * .25f;
            canvas.drawOval(new RectF(cx - r, cy - r * .40f, cx + r, cy + r * .35f), paint);
            canvas.drawLine(cx, cy + r * .35f, cx, h * .82f, paint);
            canvas.drawRoundRect(new RectF(cx - r * .55f, h * .80f, cx + r * .55f, h * .88f), 8, 8, paint);
            drawLabel(canvas, "Bluetooth", w * .10f, h * .42f, w);
        }

        private void drawMapLayers(Canvas canvas, float w, float h) {
            paint.setStrokeWidth(dp(getContext(), 2));
            paint.setColor(Color.rgb(132, 205, 255));
            float cx = w * .57f, cy = h * .46f, sw = w * .42f, sh = h * .24f;
            for (int i = 0; i < 3; i++) {
                float off = i * h * .10f;
                path.reset();
                path.moveTo(cx - sw * .55f, cy - sh * .25f + off);
                path.lineTo(cx + sw * .10f, cy - sh * .48f + off);
                path.lineTo(cx + sw * .58f, cy - sh * .12f + off);
                path.lineTo(cx - sw * .05f, cy + sh * .25f + off);
                path.close();
                canvas.drawPath(path, paint);
            }
            drawPin(canvas, w * .58f, h * .34f, Math.min(w, h) * .15f);
        }

        private void drawNotebook(Canvas canvas, float w, float h) {
            paint.setStrokeWidth(dp(getContext(), 2));
            paint.setColor(Color.rgb(161, 218, 255));
            float x = w * .56f, y = h * .18f, ww = w * .25f, hh = h * .58f;
            canvas.drawRoundRect(new RectF(x, y, x + ww, y + hh), 8, 8, paint);
            for (int i = 1; i <= 4; i++) canvas.drawLine(x + ww * .20f, y + hh * i / 5f, x + ww * .82f, y + hh * i / 5f, paint);
            canvas.drawLine(x - ww * .18f, y + hh * .10f, x - ww * .18f, y + hh * .90f, paint);
            canvas.drawLine(x - ww * .06f, y + hh * .12f, x - ww * .06f, y + hh * .88f, paint);
        }

        private void drawStaffAt(Canvas canvas, float cx, float cy, float h) {
            paint.setStrokeWidth(dp(getContext(), 2));
            paint.setColor(Color.rgb(207, 232, 250));
            canvas.drawLine(cx, cy - h * .50f, cx, cy + h * .50f, paint);
            for (int i = -4; i <= 4; i++) {
                float y = cy + i * h / 10f;
                paint.setColor(i % 2 == 0 ? Color.rgb(255, 94, 94) : Color.rgb(207, 232, 250));
                canvas.drawLine(cx, y, cx + (i % 2 == 0 ? h * .13f : h * .08f), y, paint);
            }
        }

        private void drawTarget(Canvas canvas, float cx, float cy, float r) {
            paint.setStrokeWidth(dp(getContext(), 2));
            paint.setColor(Color.rgb(76, 222, 204));
            canvas.drawCircle(cx, cy, r, paint);
            canvas.drawCircle(cx, cy, r * .32f, paint);
            canvas.drawLine(cx - r * 1.35f, cy, cx - r * .62f, cy, paint);
            canvas.drawLine(cx + r * .62f, cy, cx + r * 1.35f, cy, paint);
            canvas.drawLine(cx, cy - r * 1.35f, cx, cy - r * .62f, paint);
            canvas.drawLine(cx, cy + r * .62f, cx, cy + r * 1.35f, paint);
        }

        private void drawPin(Canvas canvas, float cx, float cy, float r) {
            fill.setColor(BLUE);
            path.reset();
            path.addCircle(cx, cy - r * .20f, r * .52f, Path.Direction.CW);
            canvas.drawPath(path, fill);
            path.reset();
            path.moveTo(cx - r * .30f, cy + r * .12f);
            path.lineTo(cx, cy + r * .90f);
            path.lineTo(cx + r * .30f, cy + r * .12f);
            path.close();
            canvas.drawPath(path, fill);
            fill.setColor(Color.WHITE);
            canvas.drawCircle(cx, cy - r * .20f, r * .17f, fill);
        }

        private void drawPoint(Canvas canvas, float cx, float cy, float w) {
            float r = Math.max(5f, w * .028f);
            fill.setColor(Color.rgb(9, 37, 70));
            canvas.drawCircle(cx, cy, r * 1.35f, fill);
            fill.setColor(Color.rgb(130, 199, 255));
            canvas.drawCircle(cx, cy, r, fill);
            fill.setColor(Color.WHITE);
            canvas.drawCircle(cx, cy, r * .45f, fill);
        }

        private void drawLabel(Canvas canvas, String value, float x, float y, float w) {
            textPaint.setTextSize(Math.max(10f, w * .045f));
            textPaint.setColor(Color.rgb(139, 202, 255));
            canvas.drawText(value, x, y, textPaint);
        }
    }

    public static class IconGlyphView extends View {
        private final String type;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        public IconGlyphView(Context context, String type) {
            super(context);
            this.type = type == null ? "dot" : type;
            paint.setColor(Color.rgb(76, 145, 255));
            paint.setStrokeWidth(dp(context, 2));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
        }

        public void setGlyphColor(int color) {
            paint.setColor(color);
            invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2f, cy = h / 2f;
            float r = Math.min(w, h) * 0.34f;
            path.reset();
            switch (type) {
                case "target":
                    canvas.drawCircle(cx, cy, r * 0.72f, paint);
                    canvas.drawCircle(cx, cy, r * 0.23f, paint);
                    canvas.drawLine(cx - r, cy, cx - r * 0.52f, cy, paint);
                    canvas.drawLine(cx + r * 0.52f, cy, cx + r, cy, paint);
                    canvas.drawLine(cx, cy - r, cx, cy - r * 0.52f, paint);
                    canvas.drawLine(cx, cy + r * 0.52f, cx, cy + r, paint);
                    break;
                case "grid":
                    for (int i = -1; i <= 1; i++) {
                        for (int j = -1; j <= 1; j++) {
                            canvas.drawRect(cx + i * r * 0.65f - r * 0.17f,
                                    cy + j * r * 0.65f - r * 0.17f,
                                    cx + i * r * 0.65f + r * 0.17f,
                                    cy + j * r * 0.65f + r * 0.17f, paint);
                        }
                    }
                    break;
                case "swap":
                    canvas.drawLine(cx - r, cy - r * 0.4f, cx + r * 0.65f, cy - r * 0.4f, paint);
                    canvas.drawLine(cx + r * 0.65f, cy - r * 0.4f, cx + r * 0.25f, cy - r * 0.8f, paint);
                    canvas.drawLine(cx + r * 0.65f, cy - r * 0.4f, cx + r * 0.25f, cy, paint);
                    canvas.drawLine(cx + r, cy + r * 0.4f, cx - r * 0.65f, cy + r * 0.4f, paint);
                    canvas.drawLine(cx - r * 0.65f, cy + r * 0.4f, cx - r * 0.25f, cy, paint);
                    canvas.drawLine(cx - r * 0.65f, cy + r * 0.4f, cx - r * 0.25f, cy + r * 0.8f, paint);
                    break;
                case "compass":
                    canvas.drawCircle(cx, cy, r * 0.85f, paint);
                    path.moveTo(cx + r * 0.45f, cy - r * 0.6f);
                    path.lineTo(cx + r * 0.10f, cy + r * 0.18f);
                    path.lineTo(cx - r * 0.45f, cy + r * 0.6f);
                    path.lineTo(cx - r * 0.10f, cy - r * 0.18f);
                    path.close();
                    canvas.drawPath(path, paint);
                    break;
                case "angle":
                    canvas.drawLine(cx - r * 0.85f, cy + r * 0.65f, cx + r * 0.75f, cy + r * 0.65f, paint);
                    canvas.drawLine(cx - r * 0.85f, cy + r * 0.65f, cx + r * 0.1f, cy - r * 0.65f, paint);
                    canvas.drawArc(new RectF(cx - r * 0.65f, cy - r * 0.15f, cx + r * 0.25f, cy + r * 0.75f), 205, 72, false, paint);
                    break;
                case "triangle":
                    path.moveTo(cx, cy - r * 0.85f);
                    path.lineTo(cx + r * 0.8f, cy + r * 0.7f);
                    path.lineTo(cx - r * 0.8f, cy + r * 0.7f);
                    path.close();
                    canvas.drawPath(path, paint);
                    break;
                case "slope":
                    canvas.drawLine(cx - r * 0.85f, cy + r * 0.65f, cx + r * 0.55f, cy - r * 0.55f, paint);
                    canvas.drawLine(cx - r * 0.85f, cy + r * 0.65f, cx + r * 0.65f, cy + r * 0.65f, paint);
                    canvas.drawLine(cx + r * 0.55f, cy - r * 0.55f, cx + r * 0.1f, cy - r * 0.5f, paint);
                    canvas.drawLine(cx + r * 0.55f, cy - r * 0.55f, cx + r * 0.52f, cy - r * 0.1f, paint);
                    break;
                case "hair":
                    canvas.drawLine(cx - r * 0.55f, cy - r * 0.7f, cx - r * 0.55f, cy + r * 0.7f, paint);
                    canvas.drawLine(cx + r * 0.55f, cy - r * 0.7f, cx + r * 0.55f, cy + r * 0.7f, paint);
                    canvas.drawCircle(cx - r * 0.55f, cy - r * 0.7f, r * 0.13f, paint);
                    canvas.drawCircle(cx + r * 0.55f, cy - r * 0.7f, r * 0.13f, paint);
                    canvas.drawLine(cx - r * 0.25f, cy, cx + r * 0.25f, cy, paint);
                    break;
                case "polygon":
                    float[] px = {0f, .78f, .52f, -.54f, -.82f};
                    float[] py = {-.86f, -.27f, .75f, .72f, -.22f};
                    for (int i = 0; i < px.length; i++) {
                        int j = (i + 1) % px.length;
                        canvas.drawLine(cx + px[i] * r, cy + py[i] * r, cx + px[j] * r, cy + py[j] * r, paint);
                        canvas.drawCircle(cx + px[i] * r, cy + py[i] * r, r * .12f, paint);
                    }
                    break;
                case "level":
                    canvas.drawRect(cx - r * .75f, cy - r * .45f, cx + r * .75f, cy + r * .05f, paint);
                    canvas.drawCircle(cx, cy - r * .2f, r * .18f, paint);
                    canvas.drawLine(cx - r * .35f, cy + r * .05f, cx - r * .65f, cy + r * .8f, paint);
                    canvas.drawLine(cx + r * .35f, cy + r * .05f, cx + r * .65f, cy + r * .8f, paint);
                    canvas.drawLine(cx, cy + r * .05f, cx, cy + r * .8f, paint);
                    break;
                case "staff":
                    canvas.drawLine(cx, cy - r, cx, cy + r, paint);
                    for (int i = -4; i <= 4; i++) {
                        float y = cy + i * r / 4f;
                        canvas.drawLine(cx, y, cx + (i % 2 == 0 ? r * .45f : r * .28f), y, paint);
                    }
                    break;
                case "pin":
                    canvas.drawCircle(cx, cy - r * .22f, r * .45f, paint);
                    canvas.drawCircle(cx, cy - r * .22f, r * .13f, paint);
                    canvas.drawLine(cx - r * .34f, cy + r * .08f, cx, cy + r * .9f, paint);
                    canvas.drawLine(cx + r * .34f, cy + r * .08f, cx, cy + r * .9f, paint);
                    break;
                case "book":
                    canvas.drawRect(cx - r * .8f, cy - r * .9f, cx + r * .7f, cy + r * .9f, paint);
                    canvas.drawLine(cx - r * .45f, cy - r * .6f, cx + r * .4f, cy - r * .6f, paint);
                    canvas.drawLine(cx - r * .45f, cy - r * .2f, cx + r * .4f, cy - r * .2f, paint);
                    canvas.drawLine(cx - r * .45f, cy + r * .2f, cx + r * .4f, cy + r * .2f, paint);
                    break;
                case "share":
                    canvas.drawCircle(cx - r * .65f, cy, r * .18f, paint);
                    canvas.drawCircle(cx + r * .58f, cy - r * .55f, r * .18f, paint);
                    canvas.drawCircle(cx + r * .58f, cy + r * .55f, r * .18f, paint);
                    canvas.drawLine(cx - r * .47f, cy - r * .05f, cx + r * .4f, cy - r * .48f, paint);
                    canvas.drawLine(cx - r * .47f, cy + r * .05f, cx + r * .4f, cy + r * .48f, paint);
                    break;
                case "satellite":
                    canvas.drawOval(new RectF(cx - r * .35f, cy - r * .2f, cx + r * .25f, cy + r * .25f), paint);
                    canvas.drawLine(cx - r * .05f, cy + r * .2f, cx - r * .35f, cy + r * .75f, paint);
                    canvas.drawLine(cx - r * .65f, cy + r * .75f, cx - r * .05f, cy + r * .75f, paint);
                    canvas.drawArc(new RectF(cx + r * .05f, cy - r * .75f, cx + r * .75f, cy - r * .05f), 205, 75, false, paint);
                    break;
                case "clock":
                    canvas.drawCircle(cx, cy, r * .82f, paint);
                    canvas.drawLine(cx, cy, cx, cy - r * .48f, paint);
                    canvas.drawLine(cx, cy, cx + r * .42f, cy + r * .22f, paint);
                    break;
                case "play":
                    canvas.drawCircle(cx, cy, r * .82f, paint);
                    path.moveTo(cx - r * .22f, cy - r * .42f);
                    path.lineTo(cx + r * .48f, cy);
                    path.lineTo(cx - r * .22f, cy + r * .42f);
                    path.close();
                    canvas.drawPath(path, paint);
                    break;
                case "pause":
                    canvas.drawCircle(cx, cy, r * .82f, paint);
                    canvas.drawLine(cx - r * .22f, cy - r * .44f, cx - r * .22f, cy + r * .44f, paint);
                    canvas.drawLine(cx + r * .22f, cy - r * .44f, cx + r * .22f, cy + r * .44f, paint);
                    break;
                case "list":
                    for (int i = -1; i <= 1; i++) {
                        float y = cy + i * r * .55f;
                        canvas.drawCircle(cx - r * .72f, y, r * .08f, paint);
                        canvas.drawLine(cx - r * .42f, y, cx + r * .82f, y, paint);
                    }
                    break;
                case "map":
                    path.moveTo(cx - r * .85f, cy - r * .65f);
                    path.lineTo(cx - r * .25f, cy - r * .85f);
                    path.lineTo(cx + r * .25f, cy - r * .62f);
                    path.lineTo(cx + r * .85f, cy - r * .82f);
                    path.lineTo(cx + r * .85f, cy + r * .65f);
                    path.lineTo(cx + r * .25f, cy + r * .85f);
                    path.lineTo(cx - r * .25f, cy + r * .62f);
                    path.lineTo(cx - r * .85f, cy + r * .82f);
                    path.close();
                    canvas.drawPath(path, paint);
                    canvas.drawLine(cx - r * .25f, cy - r * .85f, cx - r * .25f, cy + r * .62f, paint);
                    canvas.drawLine(cx + r * .25f, cy - r * .62f, cx + r * .25f, cy + r * .85f, paint);
                    break;
                case "bookmark":
                    path.moveTo(cx - r * .55f, cy - r * .85f);
                    path.lineTo(cx + r * .55f, cy - r * .85f);
                    path.lineTo(cx + r * .55f, cy + r * .82f);
                    path.lineTo(cx, cy + r * .45f);
                    path.lineTo(cx - r * .55f, cy + r * .82f);
                    path.close();
                    canvas.drawPath(path, paint);
                    break;
                case "file":
                    canvas.drawRect(cx - r * .62f, cy - r * .85f, cx + r * .42f, cy + r * .85f, paint);
                    canvas.drawLine(cx + r * .10f, cy - r * .85f, cx + r * .62f, cy - r * .35f, paint);
                    canvas.drawLine(cx + r * .10f, cy - r * .85f, cx + r * .10f, cy - r * .35f, paint);
                    canvas.drawLine(cx + r * .10f, cy - r * .35f, cx + r * .62f, cy - r * .35f, paint);
                    break;
                default:
                    canvas.drawCircle(cx, cy, r * .55f, paint);
                    break;
            }
        }
    }
}
