package com.bph.geotopo;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Native, scalable visual components for the Geo Topo interface. */
public final class NativeUi {
    public static final int BG = Color.rgb(2, 17, 32);
    public static final int BG_DEEP = Color.rgb(1, 12, 25);
    public static final int HEADER = Color.rgb(3, 35, 61);
    public static final int CARD = Color.rgb(12, 36, 58);
    public static final int CARD_DARK = Color.rgb(7, 28, 48);
    public static final int CARD_LIGHT = Color.rgb(18, 50, 78);
    public static final int BLUE = Color.rgb(43, 121, 255);
    public static final int BLUE_LIGHT = Color.rgb(92, 159, 255);
    public static final int TEXT = Color.rgb(248, 250, 253);
    public static final int SUB = Color.rgb(169, 193, 219);
    public static final int BORDER = Color.rgb(72, 112, 150);

    private NativeUi() {}

    public static int dp(Context c, int value) {
        return Math.round(value * c.getResources().getDisplayMetrics().density);
    }

    public static int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    public static void styleWindow(Activity activity) {
        Window window = activity.getWindow();
        window.setStatusBarColor(BG_DEEP);
        window.setNavigationBarColor(Color.BLACK);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.getDecorView().setSystemUiVisibility(0);
        }
    }

    public static FrameLayout screen(Context context) {
        FrameLayout root = new FrameLayout(context);
        root.setBackgroundColor(BG);
        TopoBackgroundView background = new TopoBackgroundView(context);
        root.addView(background, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        return root;
    }

    public static ScrollView scroll(Context context, View child) {
        ScrollView scroll = new ScrollView(context);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.addView(child, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        return scroll;
    }

    public static LinearLayout column(Context context) {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    public static LinearLayout row(Context context) {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    public static TextView text(Context context, String value, float sp, boolean bold, int color) {
        TextView text = new TextView(context);
        text.setText(value);
        text.setTextSize(sp);
        text.setTextColor(color);
        text.setGravity(Gravity.CENTER_VERTICAL);
        text.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        text.setIncludeFontPadding(false);
        return text;
    }

    public static GradientDrawable rounded(int color, int radiusDp, int strokeDp, int strokeColor, Context c) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(c, radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(c, strokeDp), strokeColor);
        return drawable;
    }

    public static GradientDrawable gradient(int start, int end, int radiusDp, int strokeColor, Context c) {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{start, end});
        drawable.setCornerRadius(dp(c, radiusDp));
        drawable.setStroke(dp(c, 1), strokeColor);
        return drawable;
    }

    public static View dashboardHeader(Context context, View.OnClickListener settingsClick) {
        LinearLayout bar = row(context);
        bar.setPadding(dp(context, 18), dp(context, 18), dp(context, 16), dp(context, 10));
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.TRANSPARENT);

        TextView title = text(context, "Cálculos topográficos", 22.5f, true, TEXT);
        title.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(title, new LinearLayout.LayoutParams(0, dp(context, 52), 1f));

        TextView settings = text(context, "⚙", 21, true, Color.WHITE);
        settings.setGravity(Gravity.CENTER);
        settings.setContentDescription("Ajustes");
        settings.setBackground(rounded(withAlpha(BLUE, 36), 23, 1,
                withAlpha(BLUE_LIGHT, 145), context));
        settings.setElevation(dp(context, 2));
        settings.setOnClickListener(settingsClick);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(dp(context, 46), dp(context, 46));
        bar.addView(settings, slp);
        return bar;
    }

    public static View pageHeader(Context context, String titleValue, String subtitleValue,
                                  View.OnClickListener backClick, String actionIcon,
                                  View.OnClickListener actionClick) {
        LinearLayout bar = row(context);
        bar.setPadding(dp(context, 8), dp(context, 12), dp(context, 14), dp(context, 12));
        bar.setBackgroundColor(withAlpha(HEADER, 235));

        TextView back = text(context, "‹", 43, false, Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription("Volver");
        back.setOnClickListener(backClick);
        bar.addView(back, new LinearLayout.LayoutParams(dp(context, 56), dp(context, 62)));

        LinearLayout labels = column(context);
        TextView title = text(context, titleValue, 27, true, TEXT);
        TextView subtitle = text(context, subtitleValue, 14, false, SUB);
        subtitle.setPadding(0, dp(context, 4), 0, 0);
        labels.addView(title);
        labels.addView(subtitle);
        bar.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        if (actionIcon != null) {
            TextView action = text(context, actionIcon, 24, true, Color.WHITE);
            action.setGravity(Gravity.CENTER);
            action.setBackground(rounded(withAlpha(BLUE, 40), 28, 1, withAlpha(BLUE_LIGHT, 170), context));
            action.setOnClickListener(actionClick);
            bar.addView(action, new LinearLayout.LayoutParams(dp(context, 56), dp(context, 56)));
        }
        return bar;
    }

    public static View fieldToolsHeader(Context context, View.OnClickListener backClick) {
        LinearLayout bar = row(context);
        bar.setPadding(dp(context, 8), dp(context, 12), dp(context, 16), dp(context, 10));
        bar.setBackgroundColor(withAlpha(HEADER, 220));

        TextView back = text(context, "‹", 40, false, Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription("Volver");
        back.setOnClickListener(backClick);
        bar.addView(back, new LinearLayout.LayoutParams(dp(context, 52), dp(context, 58)));

        View divider = new View(context);
        divider.setBackgroundColor(withAlpha(BLUE_LIGHT, 110));
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(context, 1), dp(context, 48));
        dlp.setMargins(0, 0, dp(context, 14), 0);
        bar.addView(divider, dlp);

        LinearLayout labels = column(context);
        TextView title = text(context, "Herramientas de campo", 23.5f, true, TEXT);
        title.setMaxLines(1);
        title.setEllipsize(TextUtils.TruncateAt.END);
        TextView subtitle = text(context, "Trabajo de campo topográfico", 13.8f, false, SUB);
        subtitle.setPadding(0, dp(context, 4), 0, 0);
        labels.addView(title);
        labels.addView(subtitle);
        bar.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return bar;
    }

    public static View heroCard(Context context, boolean gps, View.OnClickListener click) {
        FrameLayout card = new FrameLayout(context);
        card.setClipToOutline(true);
        card.setBackground(gradient(gps ? Color.rgb(10, 47, 101) : Color.rgb(28, 73, 110),
                gps ? Color.rgb(3, 27, 58) : Color.rgb(8, 34, 57), 20,
                withAlpha(BLUE_LIGHT, 185), context));
        card.setElevation(dp(context, 3));
        card.setOnClickListener(click);

        if (gps) {
            MiniTopoView map = new MiniTopoView(context, true);
            card.addView(map, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            MiniTopoView backdrop = new MiniTopoView(context, false);
            card.addView(backdrop, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
            ImageView station = new ImageView(context);
            station.setImageResource(R.drawable.station_total_card);
            station.setScaleType(ImageView.ScaleType.CENTER_CROP);
            station.setAlpha(0.92f);
            FrameLayout.LayoutParams ilp = new FrameLayout.LayoutParams(dp(context, 114), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END);
            station.setLayoutParams(ilp);
            card.addView(station);
        }

        GradientDrawable shade = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{withAlpha(BG_DEEP, 40), withAlpha(BG_DEEP, 185)});
        shade.setCornerRadius(dp(context, 20));
        View shadeView = new View(context);
        shadeView.setBackground(shade);
        card.addView(shadeView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout labels = column(context);
        labels.setPadding(dp(context, 16), dp(context, 16), dp(context, 16), dp(context, 14));
        labels.setGravity(Gravity.BOTTOM);

        TextView title = text(context, gps ? "GPS y mapas" : "Herramientas de campo", 19.4f, true, TEXT);
        title.setMaxLines(2);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setLineSpacing(0, 1.02f);

        TextView sub = text(context,
                gps ? "Posición, mapas y datos GNSS" : "Instrumentos y utilidades de campo",
                13.2f, false, Color.rgb(169, 214, 255));
        sub.setMaxLines(2);
        sub.setEllipsize(TextUtils.TruncateAt.END);
        sub.setLineSpacing(0, 1.12f);
        sub.setPadding(0, dp(context, 6), dp(context, 44), 0);

        labels.addView(title);
        labels.addView(sub);
        card.addView(labels, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        TextView arrow = text(context, "›", 34, false, Color.WHITE);
        arrow.setGravity(Gravity.CENTER);
        arrow.setBackground(gradient(Color.rgb(38, 111, 236), Color.rgb(16, 61, 145), 24,
                withAlpha(BLUE_LIGHT, 130), context));
        FrameLayout.LayoutParams alp = new FrameLayout.LayoutParams(dp(context, 52), dp(context, 52), Gravity.END | Gravity.BOTTOM);
        alp.setMargins(0, 0, dp(context, 12), dp(context, 12));
        card.addView(arrow, alp);
        return card;
    }


    public static View heroImageCard(Context context, boolean gps, View.OnClickListener click) {
        return photoCard(context,
                gps ? R.drawable.dashboard_gps_hero : R.drawable.dashboard_field_hero,
                20, click);
    }

    public static View dashboardPhotoCard(Context context, String key, View.OnClickListener click) {
        int resId;
        switch (key) {
            case "converter":
                resId = R.drawable.dashboard_converter;
                break;
            case "compass":
                resId = R.drawable.dashboard_compass;
                break;
            case "azimuth":
                resId = R.drawable.dashboard_azimuth;
                break;
            case "coordinates":
                resId = R.drawable.dashboard_coordinates;
                break;
            case "distance":
                resId = R.drawable.dashboard_distance;
                break;
            case "two_hair":
                resId = R.drawable.dashboard_two_hair;
                break;
            case "polygon":
                resId = R.drawable.dashboard_polygon;
                break;
            default:
                resId = 0;
                break;
        }
        if (resId == 0) {
            return menuCard(context, key, "", null, click, 106);
        }
        return photoCard(context, resId, 17, click);
    }

    private static View photoCard(Context context, int drawableRes, int radiusDp, View.OnClickListener click) {
        FrameLayout card = new FrameLayout(context);
        card.setBackground(rounded(withAlpha(Color.WHITE, 10), radiusDp, 1, withAlpha(BLUE_LIGHT, 120), context));
        card.setClipToOutline(true);
        card.setElevation(dp(context, 2));
        card.setOnClickListener(click);

        ImageView image = new ImageView(context);
        image.setImageResource(drawableRes);
        image.setScaleType(ImageView.ScaleType.FIT_XY);
        card.addView(image, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        return card;
    }


    /** Dashboard hero card with a real photographic background and native text/actions. */
    public static View dashboardHeroImageCard(Context context, boolean gps, View.OnClickListener click) {
        int resId = gps ? R.drawable.dashboard2_gps : R.drawable.dashboard2_field;
        String title = gps ? "GPS y mapas" : "Herramientas de campo";
        String subtitle = gps ? "Posición, mapas y datos GNSS" : "Instrumentos y utilidades de campo";
        return dashboardImageCardInternal(context, resId, title, subtitle, 0.58f, true, click);
    }

    /** Dashboard medium card: image + title + chevron, with no icon/vignette badge. */
    public static View dashboardToolImageCard(Context context, String key, String title,
                                              View.OnClickListener click) {
        int resId;
        switch (key) {
            case "converter": resId = R.drawable.dashboard2_converter; break;
            case "compass": resId = R.drawable.dashboard2_compass; break;
            case "azimuth": resId = R.drawable.dashboard2_azimuth; break;
            case "coordinates": resId = R.drawable.dashboard2_coordinates; break;
            case "distance": resId = R.drawable.dashboard2_distance; break;
            case "two_hair": resId = R.drawable.dashboard2_two_hair; break;
            case "level": resId = R.drawable.dashboard2_level; break;
            case "stadia": resId = R.drawable.dashboard2_level_stadia; break;
            default: throw new IllegalArgumentException("Unsupported dashboard card: " + key);
        }
        return dashboardImageCardInternal(context, resId, title, null, 1.04f, false, click);
    }

    /** Wide dashboard card used for the closed traverse. */
    public static View dashboardWideImageCard(Context context, String title,
                                              View.OnClickListener click) {
        return dashboardImageCardInternal(context, R.drawable.dashboard2_polygon,
                title, null, 2.25f, false, click);
    }

    private static View dashboardImageCardInternal(Context context, int drawableRes,
                                                   String titleValue, String subtitleValue,
                                                   float aspectRatio, boolean hero,
                                                   View.OnClickListener click) {
        RatioCardLayout card = new RatioCardLayout(context, aspectRatio);
        card.setBackground(rounded(withAlpha(Color.WHITE, 8), hero ? 20 : 17,
                1, withAlpha(BLUE_LIGHT, 120), context));
        card.setClipToOutline(true);
        card.setElevation(dp(context, 2));
        card.setOnClickListener(click);

        ImageView image = new ImageView(context);
        image.setImageResource(drawableRes);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        card.addView(image, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        // Geo Topo blue treatment, now slightly lighter on the main dashboard so the photos are easier to appreciate.
        View tint = new View(context);
        tint.setBackgroundColor(withAlpha(Color.rgb(0, 34, 74), 77));
        card.addView(tint, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        GradientDrawable shade = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{withAlpha(Color.rgb(0, 14, 33), 0), withAlpha(Color.rgb(0, 14, 33), 0)});
        shade.setCornerRadius(dp(context, hero ? 20 : 17));
        View shadeView = new View(context);
        shadeView.setBackground(shade);
        card.addView(shadeView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        if (hero) {
            // Title gets the full card width so long names never become compressed by the arrow.
            TextView title = text(context, titleValue, 20.8f, true, TEXT);
            title.setGravity(Gravity.BOTTOM | Gravity.START);
            title.setMaxLines(2);
            title.setLineSpacing(0, 1.0f);
            title.setPadding(dp(context, 15), 0, dp(context, 15), dp(context, 66));
            card.addView(title, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));

            TextView subtitle = text(context, subtitleValue, 13.9f, false, Color.rgb(190, 220, 248));
            subtitle.setGravity(Gravity.BOTTOM | Gravity.START);
            subtitle.setMaxLines(3);
            subtitle.setLineSpacing(0, 1.04f);
            subtitle.setPadding(dp(context, 15), 0, dp(context, 38), dp(context, 16));
            card.addView(subtitle, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));

            TextView arrow = text(context, "›", 35, false, Color.WHITE);
            arrow.setGravity(Gravity.CENTER);
            FrameLayout.LayoutParams alp = new FrameLayout.LayoutParams(
                    dp(context, 32), dp(context, 42), Gravity.END | Gravity.BOTTOM);
            alp.setMargins(0, 0, dp(context, 8), dp(context, 9));
            card.addView(arrow, alp);
        } else {
            TextView title = text(context, titleValue, 17.6f, true, TEXT);
            title.setGravity(Gravity.BOTTOM | Gravity.START);
            title.setMaxLines(2);
            title.setLineSpacing(0, 1.0f);
            title.setPadding(dp(context, 14), 0, dp(context, 34), dp(context, 14));
            card.addView(title, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));

            TextView arrow = text(context, "›", 31, false, Color.WHITE);
            arrow.setGravity(Gravity.CENTER);
            FrameLayout.LayoutParams alp = new FrameLayout.LayoutParams(
                    dp(context, 34), dp(context, 46), Gravity.END | Gravity.BOTTOM);
            alp.setMargins(0, 0, dp(context, 8), dp(context, 8));
            card.addView(arrow, alp);
        }
        return card;
    }

    public static View fieldToolImageCard(Context context, String key, String titleValue,
                                          String subtitleValue, View.OnClickListener click) {
        int resId;
        switch (key) {
            case "stakeout": resId = R.drawable.field_stakeout; break;
            case "track": resId = R.drawable.field_track; break;
            case "quality": resId = R.drawable.field_quality; break;
            case "external": resId = R.drawable.field_external; break;
            case "cogo": resId = R.drawable.field_cogo; break;
            case "area": resId = R.drawable.field_area; break;
            case "traverse": resId = R.drawable.field_traverse; break;
            case "leveling": resId = R.drawable.field_leveling; break;
            case "profile": resId = R.drawable.field_profile; break;
            case "offline": resId = R.drawable.field_offline; break;
            case "notebook": resId = R.drawable.field_notebook; break;
            case "exchange": resId = R.drawable.field_exchange; break;
            default: throw new IllegalArgumentException("Unsupported field card: " + key);
        }

        FrameLayout card = new FrameLayout(context);
        card.setBackground(rounded(withAlpha(Color.WHITE, 7), 18, 1,
                withAlpha(BLUE_LIGHT, 105), context));
        card.setClipToOutline(true);
        card.setElevation(dp(context, 2));
        card.setOnClickListener(click);

        ImageView image = new ImageView(context);
        image.setImageResource(resId);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        card.addView(image, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        View tint = new View(context);
        tint.setBackgroundColor(withAlpha(Color.rgb(0, 29, 66), 0));
        card.addView(tint, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        GradientDrawable shade = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{withAlpha(Color.rgb(0, 13, 30), 0), withAlpha(Color.rgb(0, 13, 30), 18)});
        shade.setCornerRadius(dp(context, 18));
        View shadeView = new View(context);
        shadeView.setBackground(shade);
        card.addView(shadeView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout labels = column(context);
        labels.setGravity(Gravity.CENTER_VERTICAL);
        labels.setPadding(dp(context, 16), dp(context, 13), dp(context, 48), dp(context, 13));
        TextView title = text(context, titleValue, 18.2f, true, TEXT);
        title.setMaxLines(2);
        title.setLineSpacing(0, 1.0f);
        TextView subtitle = text(context, subtitleValue, 13.4f, false, Color.rgb(201, 216, 233));
        subtitle.setMaxLines(2);
        subtitle.setLineSpacing(0, 1.05f);
        subtitle.setPadding(0, dp(context, 6), 0, 0);
        labels.addView(title);
        labels.addView(subtitle);
        card.addView(labels, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        TextView arrow = text(context, "›", 31, false, Color.WHITE);
        arrow.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams alp = new FrameLayout.LayoutParams(
                dp(context, 34), dp(context, 48), Gravity.END | Gravity.CENTER_VERTICAL);
        alp.setMargins(0, 0, dp(context, 8), 0);
        card.addView(arrow, alp);
        return card;
    }

    /** Keeps each photographic card proportional on narrow and wide Android screens. */
    public static class RatioCardLayout extends FrameLayout {
        private final float aspectRatio;

        public RatioCardLayout(Context context, float aspectRatio) {
            super(context);
            this.aspectRatio = aspectRatio <= 0f ? 1f : aspectRatio;
        }

        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int width = MeasureSpec.getSize(widthMeasureSpec);
            if (width <= 0) {
                super.onMeasure(widthMeasureSpec, heightMeasureSpec);
                return;
            }
            int height = Math.max(1, Math.round(width / aspectRatio));
            super.onMeasure(widthMeasureSpec,
                    MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY));
        }
    }

    public static View sectionHeader(Context context, String icon, String titleValue, String rightText,
                                     View.OnClickListener rightClick) {
        LinearLayout row = row(context);
        row.setPadding(dp(context, 2), dp(context, 10), dp(context, 2), dp(context, 7));
        TextView iconView = text(context, icon, 18.5f, true, BLUE_LIGHT);
        iconView.setGravity(Gravity.CENTER);
        row.addView(iconView, new LinearLayout.LayoutParams(dp(context, 36), dp(context, 36)));
        TextView title = text(context, titleValue, 15.6f, true, TEXT);
        title.setLetterSpacing(0.06f);
        row.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(context, 36)));
        View line = new View(context);
        line.setBackgroundColor(withAlpha(BORDER, 80));
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(0, dp(context, 1), 1f);
        llp.setMargins(dp(context, 12), 0, dp(context, 10), 0);
        row.addView(line, llp);
        if (rightText != null) {
            TextView right = text(context, rightText + "  ›", 13.5f, false, BLUE_LIGHT);
            right.setOnClickListener(rightClick);
            row.addView(right);
        }
        return row;
    }

    public static View simpleSectionHeader(Context context, String titleValue, String rightText,
                                           View.OnClickListener rightClick) {
        LinearLayout row = row(context);
        row.setPadding(dp(context, 2), dp(context, 14), dp(context, 2), dp(context, 9));
        TextView title = text(context, titleValue, 15.8f, true, TEXT);
        title.setLetterSpacing(0.055f);
        row.addView(title, new LinearLayout.LayoutParams(0, dp(context, 34), 1f));
        if (rightText != null) {
            TextView right = text(context, rightText + "  ›", 13.8f, false, BLUE_LIGHT);
            right.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            right.setOnClickListener(rightClick);
            row.addView(right, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(context, 34)));
        }
        return row;
    }

    public static View menuCard(Context context, String iconType, String titleValue,
                                String subtitleValue, View.OnClickListener click, int minHeightDp) {
        LinearLayout card = column(context);
        card.setGravity(Gravity.TOP);
        card.setPadding(dp(context, 11), dp(context, 11), dp(context, 11), dp(context, 11));
        card.setMinimumHeight(dp(context, minHeightDp));
        card.setBackground(gradient(CARD_LIGHT, CARD_DARK, 17, withAlpha(BORDER, 170), context));
        card.setElevation(dp(context, 2));
        card.setOnClickListener(click);

        LinearLayout topRow = row(context);
        topRow.setGravity(Gravity.TOP | Gravity.CENTER_VERTICAL);
        FrameLayout iconBox = iconTile(context, iconType, 54);
        topRow.addView(iconBox, new LinearLayout.LayoutParams(dp(context, 52), dp(context, 52)));
        View spacer = new View(context);
        topRow.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));
        TextView arrow = text(context, "›", 28, false, Color.rgb(203, 220, 237));
        arrow.setGravity(Gravity.CENTER);
        topRow.addView(arrow, new LinearLayout.LayoutParams(dp(context, 26), dp(context, 36)));
        card.addView(topRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text(context, titleValue, subtitleValue == null ? 15.1f : 14.7f, true, TEXT);
        title.setPadding(0, dp(context, 8), 0, 0);
        title.setMaxLines(2);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setLineSpacing(0, 0.98f);
        card.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        if (subtitleValue != null && !subtitleValue.isEmpty()) {
            TextView sub = text(context, subtitleValue, 12.4f, false, SUB);
            sub.setPadding(0, dp(context, 4), 0, 0);
            sub.setMaxLines(2);
            sub.setEllipsize(TextUtils.TruncateAt.END);
            sub.setLineSpacing(0, 1.05f);
            card.addView(sub);
        }
        return card;
    }

    public static FrameLayout iconTile(Context context, String type, int sizeDp) {
        FrameLayout box = new FrameLayout(context);
        box.setBackground(gradient(Color.rgb(27, 84, 175), Color.rgb(13, 54, 119), 15,
                withAlpha(BLUE_LIGHT, 105), context));
        IconGlyphView glyph = new IconGlyphView(context, type);
        int margin = dp(context, 10);
        FrameLayout.LayoutParams glp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        glp.setMargins(margin, margin, margin, margin);
        box.addView(glyph, glp);
        return box;
    }

    public static View infoCard(Context context, String iconType, String titleValue, String body) {
        LinearLayout card = column(context);
        card.setPadding(dp(context, 14), dp(context, 13), dp(context, 14), dp(context, 13));
        card.setBackground(gradient(CARD_LIGHT, CARD_DARK, 17, withAlpha(BORDER, 165), context));
        LinearLayout titleRow = row(context);
        IconGlyphView icon = new IconGlyphView(context, iconType);
        titleRow.addView(icon, new LinearLayout.LayoutParams(dp(context, 28), dp(context, 28)));
        TextView title = text(context, titleValue, 15, false, TEXT);
        title.setPadding(dp(context, 8), 0, 0, 0);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, dp(context, 30), 1f));
        card.addView(titleRow);
        View line = new View(context);
        line.setBackgroundColor(withAlpha(BORDER, 100));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 1));
        lp.setMargins(0, dp(context, 8), 0, dp(context, 10));
        card.addView(line, lp);
        TextView bodyView = text(context, body, 13.5f, false, SUB);
        bodyView.setLineSpacing(dp(context, 2), 1f);
        card.addView(bodyView);
        return card;
    }

    public static View gpsMapCard(Context context, View.OnClickListener offlineClick, View.OnClickListener openMapClick) {
        FrameLayout card = new FrameLayout(context);
        card.setBackground(gradient(Color.rgb(5, 32, 68), Color.rgb(2, 20, 43), 20,
                withAlpha(BORDER, 180), context));
        card.setClipToOutline(true);
        MiniTopoView map = new MiniTopoView(context, true);
        card.addView(map, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        TextView offline = text(context, "⇩  Mapa offline", 14, false, TEXT);
        offline.setGravity(Gravity.CENTER);
        offline.setBackground(rounded(withAlpha(BG_DEEP, 210), 26, 1, withAlpha(BLUE, 185), context));
        offline.setOnClickListener(offlineClick);
        FrameLayout.LayoutParams olp = new FrameLayout.LayoutParams(dp(context, 190), dp(context, 50), Gravity.START | Gravity.TOP);
        olp.setMargins(dp(context, 16), dp(context, 15), 0, 0);
        card.addView(offline, olp);

        TextView open = text(context, "▱  Abrir mapa", 17, false, Color.WHITE);
        open.setGravity(Gravity.CENTER);
        open.setBackground(gradient(Color.rgb(48, 130, 255), Color.rgb(31, 91, 222), 18,
                withAlpha(Color.WHITE, 60), context));
        open.setElevation(dp(context, 4));
        open.setOnClickListener(openMapClick);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(dp(context, 205), dp(context, 64), Gravity.END | Gravity.BOTTOM);
        blp.setMargins(0, 0, dp(context, 15), dp(context, 15));
        card.addView(open, blp);
        return card;
    }

    public static class TopoBackgroundView extends View {
        private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        public TopoBackgroundView(Context context) {
            super(context);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            linePaint.setStyle(Paint.Style.STROKE);
            linePaint.setStrokeWidth(dp(context, 1));
            linePaint.setColor(withAlpha(BLUE_LIGHT, 22));
            glowPaint.setStyle(Paint.Style.STROKE);
            glowPaint.setStrokeWidth(dp(context, 1));
            glowPaint.setColor(withAlpha(BLUE, 12));
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            canvas.drawColor(BG);
            int w = getWidth();
            int h = getHeight();
            for (int i = -4; i < 18; i++) {
                float baseY = i * h / 12f;
                path.reset();
                path.moveTo(-40, baseY + 30);
                for (int x = 0; x <= w + 60; x += 45) {
                    float y = baseY + (float) Math.sin((x * 0.015) + i * 0.7) * 24f
                            + (float) Math.cos((x * 0.007) - i) * 16f;
                    path.lineTo(x, y);
                }
                canvas.drawPath(path, i % 3 == 0 ? glowPaint : linePaint);
            }
        }
    }

    public static class MiniTopoView extends View {
        private final Paint contour = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint contourSoft = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint route = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint routeGlow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint patch = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint patchDark = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint white = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint accent = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path p = new Path();
        private final boolean showPin;

        public MiniTopoView(Context context, boolean showPin) {
            super(context);
            this.showPin = showPin;

            contour.setStyle(Paint.Style.STROKE);
            contour.setStrokeWidth(dp(context, 1));
            contour.setColor(withAlpha(BLUE_LIGHT, 58));

            contourSoft.setStyle(Paint.Style.STROKE);
            contourSoft.setStrokeWidth(dp(context, 1));
            contourSoft.setColor(withAlpha(Color.WHITE, 22));

            grid.setStyle(Paint.Style.STROKE);
            grid.setStrokeWidth(dp(context, 1));
            grid.setColor(withAlpha(BLUE_LIGHT, 18));

            route.setStyle(Paint.Style.STROKE);
            route.setStrokeWidth(dp(context, 2));
            route.setStrokeCap(Paint.Cap.ROUND);
            route.setPathEffect(new android.graphics.DashPathEffect(new float[]{dp(context, 10), dp(context, 7)}, 0));
            route.setColor(Color.rgb(88, 170, 255));

            routeGlow.setStyle(Paint.Style.STROKE);
            routeGlow.setStrokeWidth(dp(context, 4));
            routeGlow.setStrokeCap(Paint.Cap.ROUND);
            routeGlow.setPathEffect(new android.graphics.DashPathEffect(new float[]{dp(context, 10), dp(context, 7)}, 0));
            routeGlow.setColor(withAlpha(Color.WHITE, 36));

            patch.setStyle(Paint.Style.FILL);
            patch.setColor(withAlpha(Color.rgb(43, 102, 182), 78));
            patchDark.setStyle(Paint.Style.FILL);
            patchDark.setColor(withAlpha(Color.rgb(14, 48, 92), 122));

            white.setColor(Color.WHITE);
            white.setStyle(Paint.Style.STROKE);
            white.setStrokeWidth(dp(context, 2));

            accent.setColor(Color.rgb(57, 131, 255));
            accent.setStyle(Paint.Style.FILL);

            label.setColor(withAlpha(Color.WHITE, 155));
            label.setTextSize(dp(context, 10));
            label.setTypeface(Typeface.DEFAULT_BOLD);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();

            for (int x = dp(getContext(), 22); x < w; x += dp(getContext(), 40)) {
                canvas.drawLine(x, 0, x, h, grid);
            }
            for (int y = dp(getContext(), 18); y < h; y += dp(getContext(), 36)) {
                canvas.drawLine(0, y, w, y, grid);
            }

            drawPatch(canvas, w * 0.07f, h * 0.14f, w * 0.38f, h * 0.30f, patchDark);
            drawPatch(canvas, w * 0.50f, h * 0.12f, w * 0.84f, h * 0.31f, patch);
            drawPatch(canvas, w * 0.22f, h * 0.52f, w * 0.62f, h * 0.70f, patch);

            for (int i = -2; i < 14; i++) {
                float baseY = i * h / 8.5f;
                p.reset();
                p.moveTo(-20, baseY + h * 0.06f);
                for (int x = 0; x <= w + 30; x += 26) {
                    float y = baseY + (float) Math.sin(x * 0.032 + i * 0.8f) * 12f
                            + (float) Math.cos(x * 0.015 - i * 0.55f) * 7f;
                    p.lineTo(x, y);
                }
                canvas.drawPath(p, i % 2 == 0 ? contour : contourSoft);
            }

            if (showPin) {
                Path routePath = new Path();
                routePath.moveTo(w * 0.18f, h * 0.86f);
                routePath.cubicTo(w * 0.34f, h * 0.70f, w * 0.40f, h * 0.55f, w * 0.54f, h * 0.54f);
                routePath.cubicTo(w * 0.66f, h * 0.53f, w * 0.70f, h * 0.32f, w * 0.78f, h * 0.22f);
                canvas.drawPath(routePath, routeGlow);
                canvas.drawPath(routePath, route);
                drawWaypoint(canvas, w * 0.18f, h * 0.86f);
                drawWaypoint(canvas, w * 0.47f, h * 0.57f);
                drawWaypoint(canvas, w * 0.78f, h * 0.22f);
                drawPin(canvas, w * 0.78f, h * 0.22f);
                drawNorthMark(canvas, w, h);
                drawScaleBar(canvas, w, h);
            } else {
                Paint beam = new Paint(Paint.ANTI_ALIAS_FLAG);
                beam.setStyle(Paint.Style.FILL);
                beam.setColor(withAlpha(Color.rgb(82, 161, 255), 32));
                Path cone = new Path();
                cone.moveTo(w * 0.70f, h * 0.30f);
                cone.lineTo(w * 0.89f, h * 0.08f);
                cone.lineTo(w * 0.98f, h * 0.16f);
                cone.lineTo(w * 0.79f, h * 0.40f);
                cone.close();
                canvas.drawPath(cone, beam);
            }
        }

        private void drawPatch(Canvas canvas, float l, float t, float r, float b, Paint paint) {
            Path patchPath = new Path();
            patchPath.moveTo(l, t + (b - t) * 0.12f);
            patchPath.cubicTo(l + (r - l) * 0.18f, t - (b - t) * 0.08f, r - (r - l) * 0.10f, t + (b - t) * 0.03f, r, t + (b - t) * 0.20f);
            patchPath.cubicTo(r + (r - l) * 0.03f, b - (b - t) * 0.28f, r - (r - l) * 0.22f, b + (b - t) * 0.05f, r - (r - l) * 0.05f, b);
            patchPath.cubicTo(l + (r - l) * 0.55f, b + (b - t) * 0.04f, l - (r - l) * 0.05f, b - (b - t) * 0.12f, l, t + (b - t) * 0.12f);
            patchPath.close();
            canvas.drawPath(patchPath, paint);
        }

        private void drawWaypoint(Canvas canvas, float cx, float cy) {
            Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
            glow.setStyle(Paint.Style.FILL);
            glow.setColor(withAlpha(Color.WHITE, 50));
            canvas.drawCircle(cx, cy, dp(getContext(), 7), glow);
            canvas.drawCircle(cx, cy, dp(getContext(), 3), accent);
        }

        private void drawPin(Canvas canvas, float cx, float cy) {
            Paint shadow = new Paint(Paint.ANTI_ALIAS_FLAG);
            shadow.setColor(withAlpha(Color.BLACK, 50));
            canvas.drawCircle(cx, cy + dp(getContext(), 23), dp(getContext(), 20), shadow);

            Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
            glow.setColor(withAlpha(Color.WHITE, 28));
            glow.setStyle(Paint.Style.FILL);
            canvas.drawCircle(cx, cy + dp(getContext(), 12), dp(getContext(), 26), glow);

            Path drop = new Path();
            drop.moveTo(cx, cy + dp(getContext(), 46));
            drop.cubicTo(cx - dp(getContext(), 28), cy + dp(getContext(), 12), cx - dp(getContext(), 25), cy - dp(getContext(), 14), cx, cy - dp(getContext(), 14));
            drop.cubicTo(cx + dp(getContext(), 25), cy - dp(getContext(), 14), cx + dp(getContext(), 28), cy + dp(getContext(), 12), cx, cy + dp(getContext(), 46));
            drop.close();

            Paint pinFill = new Paint(Paint.ANTI_ALIAS_FLAG);
            pinFill.setColor(Color.rgb(41, 117, 247));
            pinFill.setStyle(Paint.Style.FILL);
            canvas.drawPath(drop, pinFill);
            Paint pinStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
            pinStroke.setColor(withAlpha(Color.WHITE, 120));
            pinStroke.setStyle(Paint.Style.STROKE);
            pinStroke.setStrokeWidth(dp(getContext(), 1));
            canvas.drawPath(drop, pinStroke);

            Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
            ring.setStyle(Paint.Style.FILL);
            ring.setColor(withAlpha(Color.WHITE, 40));
            canvas.drawCircle(cx, cy + dp(getContext(), 2), dp(getContext(), 16), ring);
            canvas.drawCircle(cx, cy + dp(getContext(), 2), dp(getContext(), 7), white);
        }

        private void drawNorthMark(Canvas canvas, int w, int h) {
            float left = dp(getContext(), 14);
            float top = dp(getContext(), 14);
            Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(dp(getContext(), 1));
            stroke.setColor(withAlpha(Color.WHITE, 120));
            canvas.drawRoundRect(new RectF(left, top, left + dp(getContext(), 32), top + dp(getContext(), 46)), dp(getContext(), 10), dp(getContext(), 10), stroke);
            Paint nPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            nPaint.setColor(withAlpha(Color.WHITE, 200));
            nPaint.setTextSize(dp(getContext(), 12));
            nPaint.setTextAlign(Paint.Align.CENTER);
            nPaint.setTypeface(Typeface.DEFAULT_BOLD);
            canvas.drawText("N", left + dp(getContext(), 16), top + dp(getContext(), 14), nPaint);
            Path arrow = new Path();
            arrow.moveTo(left + dp(getContext(), 16), top + dp(getContext(), 19));
            arrow.lineTo(left + dp(getContext(), 10), top + dp(getContext(), 32));
            arrow.lineTo(left + dp(getContext(), 22), top + dp(getContext(), 32));
            arrow.close();
            Paint arrowFill = new Paint(Paint.ANTI_ALIAS_FLAG);
            arrowFill.setColor(Color.rgb(69, 144, 255));
            canvas.drawPath(arrow, arrowFill);
            canvas.drawLine(left + dp(getContext(), 16), top + dp(getContext(), 19), left + dp(getContext(), 16), top + dp(getContext(), 38), white);
        }

        private void drawScaleBar(Canvas canvas, int w, int h) {
            float left = dp(getContext(), 14);
            float baseY = h - dp(getContext(), 18);
            Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
            bar.setStyle(Paint.Style.FILL);
            bar.setColor(withAlpha(Color.WHITE, 185));
            canvas.drawRect(left, baseY - dp(getContext(), 6), left + dp(getContext(), 54), baseY - dp(getContext(), 2), bar);
            bar.setColor(withAlpha(Color.rgb(56, 128, 255), 190));
            canvas.drawRect(left, baseY - dp(getContext(), 6), left + dp(getContext(), 27), baseY - dp(getContext(), 2), bar);
            canvas.drawText("25 m", left + dp(getContext(), 57), baseY - dp(getContext(), 1), label);
        }
    }

    public static class IconGlyphView extends View {
        private final String type;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        public IconGlyphView(Context context, String type) {
            super(context);
            this.type = type == null ? "dot" : type;
            paint.setColor(Color.rgb(76, 145, 255));
            paint.setStrokeWidth(dp(context, 2));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2f, cy = h / 2f;
            float r = Math.min(w, h) * 0.34f;
            path.reset();
            switch (type) {
                case "target":
                    canvas.drawCircle(cx, cy, r * 0.72f, paint);
                    canvas.drawCircle(cx, cy, r * 0.23f, paint);
                    canvas.drawLine(cx - r, cy, cx - r * 0.52f, cy, paint);
                    canvas.drawLine(cx + r * 0.52f, cy, cx + r, cy, paint);
                    canvas.drawLine(cx, cy - r, cx, cy - r * 0.52f, paint);
                    canvas.drawLine(cx, cy + r * 0.52f, cx, cy + r, paint);
                    break;
                case "grid":
                    for (int i = -1; i <= 1; i++) {
                        for (int j = -1; j <= 1; j++) {
                            canvas.drawRect(cx + i * r * 0.65f - r * 0.17f,
                                    cy + j * r * 0.65f - r * 0.17f,
                                    cx + i * r * 0.65f + r * 0.17f,
                                    cy + j * r * 0.65f + r * 0.17f, paint);
                        }
                    }
                    break;
                case "swap":
                    canvas.drawLine(cx - r, cy - r * 0.4f, cx + r * 0.65f, cy - r * 0.4f, paint);
                    canvas.drawLine(cx + r * 0.65f, cy - r * 0.4f, cx + r * 0.25f, cy - r * 0.8f, paint);
                    canvas.drawLine(cx + r * 0.65f, cy - r * 0.4f, cx + r * 0.25f, cy, paint);
                    canvas.drawLine(cx + r, cy + r * 0.4f, cx - r * 0.65f, cy + r * 0.4f, paint);
                    canvas.drawLine(cx - r * 0.65f, cy + r * 0.4f, cx - r * 0.25f, cy, paint);
                    canvas.drawLine(cx - r * 0.65f, cy + r * 0.4f, cx - r * 0.25f, cy + r * 0.8f, paint);
                    break;
                case "compass":
                    canvas.drawCircle(cx, cy, r * 0.85f, paint);
                    path.moveTo(cx + r * 0.45f, cy - r * 0.6f);
                    path.lineTo(cx + r * 0.10f, cy + r * 0.18f);
                    path.lineTo(cx - r * 0.45f, cy + r * 0.6f);
                    path.lineTo(cx - r * 0.10f, cy - r * 0.18f);
                    path.close();
                    canvas.drawPath(path, paint);
                    break;
                case "angle":
                    canvas.drawLine(cx - r * 0.85f, cy + r * 0.65f, cx + r * 0.75f, cy + r * 0.65f, paint);
                    canvas.drawLine(cx - r * 0.85f, cy + r * 0.65f, cx + r * 0.1f, cy - r * 0.65f, paint);
                    canvas.drawArc(new RectF(cx - r * 0.65f, cy - r * 0.15f, cx + r * 0.25f, cy + r * 0.75f), 205, 72, false, paint);
                    break;
                case "triangle":
                    path.moveTo(cx, cy - r * 0.85f);
                    path.lineTo(cx + r * 0.8f, cy + r * 0.7f);
                    path.lineTo(cx - r * 0.8f, cy + r * 0.7f);
                    path.close();
                    canvas.drawPath(path, paint);
                    break;
                case "slope":
                    canvas.drawLine(cx - r * 0.85f, cy + r * 0.65f, cx + r * 0.55f, cy - r * 0.55f, paint);
                    canvas.drawLine(cx - r * 0.85f, cy + r * 0.65f, cx + r * 0.65f, cy + r * 0.65f, paint);
                    canvas.drawLine(cx + r * 0.55f, cy - r * 0.55f, cx + r * 0.1f, cy - r * 0.5f, paint);
                    canvas.drawLine(cx + r * 0.55f, cy - r * 0.55f, cx + r * 0.52f, cy - r * 0.1f, paint);
                    break;
                case "hair":
                    canvas.drawLine(cx - r * 0.55f, cy - r * 0.7f, cx - r * 0.55f, cy + r * 0.7f, paint);
                    canvas.drawLine(cx + r * 0.55f, cy - r * 0.7f, cx + r * 0.55f, cy + r * 0.7f, paint);
                    canvas.drawCircle(cx - r * 0.55f, cy - r * 0.7f, r * 0.13f, paint);
                    canvas.drawCircle(cx + r * 0.55f, cy - r * 0.7f, r * 0.13f, paint);
                    canvas.drawLine(cx - r * 0.25f, cy, cx + r * 0.25f, cy, paint);
                    break;
                case "polygon":
                    float[] px = {0f, .78f, .52f, -.54f, -.82f};
                    float[] py = {-.86f, -.27f, .75f, .72f, -.22f};
                    for (int i = 0; i < px.length; i++) {
                        int j = (i + 1) % px.length;
                        canvas.drawLine(cx + px[i] * r, cy + py[i] * r, cx + px[j] * r, cy + py[j] * r, paint);
                        canvas.drawCircle(cx + px[i] * r, cy + py[i] * r, r * .12f, paint);
                    }
                    break;
                case "level":
                    canvas.drawRect(cx - r * .75f, cy - r * .45f, cx + r * .75f, cy + r * .05f, paint);
                    canvas.drawCircle(cx, cy - r * .2f, r * .18f, paint);
                    canvas.drawLine(cx - r * .35f, cy + r * .05f, cx - r * .65f, cy + r * .8f, paint);
                    canvas.drawLine(cx + r * .35f, cy + r * .05f, cx + r * .65f, cy + r * .8f, paint);
                    canvas.drawLine(cx, cy + r * .05f, cx, cy + r * .8f, paint);
                    break;
                case "staff":
                    canvas.drawLine(cx, cy - r, cx, cy + r, paint);
                    for (int i = -4; i <= 4; i++) {
                        float y = cy + i * r / 4f;
                        canvas.drawLine(cx, y, cx + (i % 2 == 0 ? r * .45f : r * .28f), y, paint);
                    }
                    break;
                case "pin":
                    canvas.drawCircle(cx, cy - r * .22f, r * .45f, paint);
                    canvas.drawCircle(cx, cy - r * .22f, r * .13f, paint);
                    canvas.drawLine(cx - r * .34f, cy + r * .08f, cx, cy + r * .9f, paint);
                    canvas.drawLine(cx + r * .34f, cy + r * .08f, cx, cy + r * .9f, paint);
                    break;
                case "book":
                    canvas.drawRect(cx - r * .8f, cy - r * .9f, cx + r * .7f, cy + r * .9f, paint);
                    canvas.drawLine(cx - r * .45f, cy - r * .6f, cx + r * .4f, cy - r * .6f, paint);
                    canvas.drawLine(cx - r * .45f, cy - r * .2f, cx + r * .4f, cy - r * .2f, paint);
                    canvas.drawLine(cx - r * .45f, cy + r * .2f, cx + r * .4f, cy + r * .2f, paint);
                    break;
                case "share":
                    canvas.drawCircle(cx - r * .65f, cy, r * .18f, paint);
                    canvas.drawCircle(cx + r * .58f, cy - r * .55f, r * .18f, paint);
                    canvas.drawCircle(cx + r * .58f, cy + r * .55f, r * .18f, paint);
                    canvas.drawLine(cx - r * .47f, cy - r * .05f, cx + r * .4f, cy - r * .48f, paint);
                    canvas.drawLine(cx - r * .47f, cy + r * .05f, cx + r * .4f, cy + r * .48f, paint);
                    break;
                case "satellite":
                    canvas.drawOval(new RectF(cx - r * .35f, cy - r * .2f, cx + r * .25f, cy + r * .25f), paint);
                    canvas.drawLine(cx - r * .05f, cy + r * .2f, cx - r * .35f, cy + r * .75f, paint);
                    canvas.drawLine(cx - r * .65f, cy + r * .75f, cx - r * .05f, cy + r * .75f, paint);
                    canvas.drawArc(new RectF(cx + r * .05f, cy - r * .75f, cx + r * .75f, cy - r * .05f), 205, 75, false, paint);
                    break;
                case "clock":
                    canvas.drawCircle(cx, cy, r * .82f, paint);
                    canvas.drawLine(cx, cy, cx, cy - r * .48f, paint);
                    canvas.drawLine(cx, cy, cx + r * .42f, cy + r * .22f, paint);
                    break;
                default:
                    canvas.drawCircle(cx, cy, r * .55f, paint);
                    break;
            }
        }
    }
}
