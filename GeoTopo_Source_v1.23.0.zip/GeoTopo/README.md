# GeoTopo

Versión actual: **1.23.0**

## Herramientas principales

- GPS/GNSS y captura de puntos por proyectos.
- Mapas, búsqueda, medición, importación y exportación.
- Conversor de unidades.
- Orientación, brújula, azimut, rumbo y coordenadas parciales.
- Distancia, pendiente, poligonal y nivelación.
- Práctica de lectura de mira tipo E con LS, LM y LI.

## Herramientas de campo añadidas

- Replanteo de punto con GPS en primer plano.
- COGO directo e inverso.
- Área y perímetro por coordenadas.
- Libreta de campo local con exportación CSV.

## Comportamiento de la interfaz

- Todas las secciones comienzan cerradas.
- Se retiró la fila de accesos rápidos duplicados de la parte superior.
- Las herramientas existentes conservan sus cálculos y su funcionamiento.

## Precisión

La precisión depende del dispositivo, la geometría satelital, el entorno y las condiciones de observación. Para trabajos centimétricos se necesita un receptor GNSS RTK o instrumental topográfico adecuado.
