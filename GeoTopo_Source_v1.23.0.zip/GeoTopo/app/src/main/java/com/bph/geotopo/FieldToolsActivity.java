package com.bph.geotopo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class FieldToolsActivity extends Activity {
    private static final String PREFS = "geo_topo_prefs";
    private static final String NOTEBOOK_KEY = "field_notebook_entries_v1";
    private static final int REQ_LOCATION = 9401;
    private static final int REQ_EXPORT_CSV = 9402;
    private static final int REQ_NOTEBOOK_LOCATION = 9403;

    private int themeMode;
    private int accent;
    private int bgColor;
    private int barColor;
    private int cardColor;
    private int textColor;
    private int subTextColor;
    private int inputColor;
    private int borderColor;

    private LocationManager locationManager;
    private EditText targetLatInput;
    private EditText targetLonInput;
    private TextView stakeoutResult;
    private Button stakeoutButton;
    private boolean stakeoutRunning;
    private Location lastFieldLocation;

    private EditText directNorthInput;
    private EditText directEastInput;
    private EditText directAzimuthInput;
    private EditText directDistanceInput;
    private TextView directResult;

    private EditText inverseNorth1Input;
    private EditText inverseEast1Input;
    private EditText inverseNorth2Input;
    private EditText inverseEast2Input;
    private TextView inverseResult;

    private final List<PointRow> areaRows = new ArrayList<>();
    private LinearLayout areaRowsContainer;
    private TextView areaResult;

    private EditText notebookCodeInput;
    private EditText notebookNorthInput;
    private EditText notebookEastInput;
    private EditText notebookElevationInput;
    private EditText notebookDescriptionInput;
    private TextView notebookList;
    private final List<NotebookEntry> notebookEntries = new ArrayList<>();

    private final LocationListener fieldLocationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            lastFieldLocation = location;
            updateStakeout(location);
        }

        @Override
        public void onProviderEnabled(String provider) {
            updateStakeoutMessage("GPS activo. Esperando una posición válida...");
        }

        @Override
        public void onProviderDisabled(String provider) {
            updateStakeoutMessage("Activa la ubicación/GPS del celular para usar el replanteo.");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        buildUi();
        loadNotebook();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopStakeout();
    }

    private void applyPalette() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        themeMode = sp.getInt("theme", 1);
        int accentIndex = sp.getInt("accent", 0);
        int[] accents = {
                Color.rgb(41, 121, 255), Color.rgb(0, 188, 212), Color.rgb(0, 150, 136),
                Color.rgb(0, 184, 148), Color.rgb(118, 210, 34), Color.rgb(255, 214, 10),
                Color.rgb(255, 171, 0), Color.rgb(255, 112, 20), Color.rgb(244, 67, 54),
                Color.rgb(255, 64, 129), Color.rgb(142, 68, 173), Color.rgb(92, 92, 210)
        };
        accent = accents[Math.abs(accentIndex) % accents.length];
        borderColor = accent;

        if (themeMode == 0) {
            bgColor = Color.rgb(241, 244, 248);
            barColor = Color.rgb(20, 33, 61);
            cardColor = Color.WHITE;
            textColor = Color.rgb(30, 33, 40);
            subTextColor = Color.rgb(96, 104, 118);
            inputColor = Color.WHITE;
        } else if (themeMode == 2) {
            bgColor = Color.BLACK;
            barColor = Color.rgb(3, 20, 34);
            cardColor = Color.rgb(9, 11, 15);
            textColor = Color.rgb(245, 245, 247);
            subTextColor = Color.rgb(179, 184, 192);
            inputColor = Color.rgb(14, 16, 22);
        } else {
            bgColor = Color.rgb(7, 22, 36);
            barColor = Color.rgb(3, 45, 73);
            cardColor = Color.rgb(17, 38, 58);
            textColor = Color.rgb(248, 250, 252);
            subTextColor = Color.rgb(199, 211, 222);
            inputColor = Color.rgb(10, 29, 45);
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);
        root.addView(topBar());

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(12), dp(14), dp(28));
        content.setBackgroundColor(bgColor);

        content.addView(collapsibleCard(stakeoutBlock(), "⌖", "Replanteo de punto", false));
        content.addView(collapsibleCard(cogoBlock(), "Δ", "COGO directo e inverso", false));
        content.addView(collapsibleCard(areaBlock(), "◇", "Área y perímetro", false));
        content.addView(collapsibleCard(notebookBlock(), "▤", "Libreta de campo", false));

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private View topBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(8), dp(12), dp(8));
        bar.setBackgroundColor(barColor);

        Button back = new Button(this);
        back.setText("‹");
        back.setTextSize(30);
        back.setTextColor(Color.WHITE);
        back.setBackgroundColor(Color.TRANSPARENT);
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(50), dp(50)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("Herramientas de campo", 20, true);
        title.setTextColor(Color.WHITE);
        titles.addView(title);
        TextView sub = text("Trabajo local, sin alterar las demás calculadoras", 12, false);
        sub.setTextColor(Color.rgb(215, 228, 240));
        titles.addView(sub);
        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return bar;
    }

    private LinearLayout stakeoutBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("Replanteo con GPS del celular"));
        box.addView(small("Escribe la latitud y longitud del punto objetivo. La app mostrará distancia, azimut y desplazamiento aproximado Norte/Este en tiempo real."));
        box.addView(warning("La precisión depende del GPS del equipo. No reemplaza un receptor GNSS RTK ni una estación total para trabajos centimétricos."));

        LinearLayout row = horizontal();
        targetLatInput = numberInput("Latitud objetivo");
        targetLonInput = numberInput("Longitud objetivo");
        row.addView(labeled("Latitud", targetLatInput), weight());
        row.addView(labeled("Longitud", targetLonInput), weight());
        box.addView(row);

        LinearLayout buttons = horizontal();
        stakeoutButton = primaryButton("Iniciar replanteo");
        stakeoutButton.setOnClickListener(v -> toggleStakeout());
        buttons.addView(stakeoutButton, weight());
        Button useCurrent = secondaryButton("Usar posición actual");
        useCurrent.setOnClickListener(v -> fillTargetWithCurrentPosition());
        buttons.addView(useCurrent, weight());
        box.addView(buttons);

        stakeoutResult = resultBox("Replanteo detenido. Ingresa el punto objetivo y pulsa Iniciar replanteo.");
        box.addView(stakeoutResult);
        return box;
    }

    private LinearLayout cogoBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("Cálculo directo"));
        box.addView(small("Calcula la coordenada final desde una coordenada inicial, azimut y distancia. El azimut se mide desde el Norte en sentido horario."));

        LinearLayout r1 = horizontal();
        directNorthInput = numberInput("N inicial");
        directEastInput = numberInput("E inicial");
        r1.addView(labeled("N inicial", directNorthInput), weight());
        r1.addView(labeled("E inicial", directEastInput), weight());
        box.addView(r1);

        LinearLayout r2 = horizontal();
        directAzimuthInput = numberInput("Azimut °");
        directDistanceInput = numberInput("Distancia m");
        r2.addView(labeled("Azimut", directAzimuthInput), weight());
        r2.addView(labeled("Distancia", directDistanceInput), weight());
        box.addView(r2);

        Button directCalc = primaryButton("Calcular directa");
        directCalc.setOnClickListener(v -> calculateDirect());
        box.addView(directCalc);
        directResult = resultBox("Resultado directo: —");
        box.addView(directResult);

        box.addView(divider());
        box.addView(sectionTitle("Cálculo inverso"));
        box.addView(small("Calcula distancia, azimut, rumbo y diferencias Norte/Este entre dos coordenadas."));

        LinearLayout r3 = horizontal();
        inverseNorth1Input = numberInput("N1");
        inverseEast1Input = numberInput("E1");
        r3.addView(labeled("N1", inverseNorth1Input), weight());
        r3.addView(labeled("E1", inverseEast1Input), weight());
        box.addView(r3);

        LinearLayout r4 = horizontal();
        inverseNorth2Input = numberInput("N2");
        inverseEast2Input = numberInput("E2");
        r4.addView(labeled("N2", inverseNorth2Input), weight());
        r4.addView(labeled("E2", inverseEast2Input), weight());
        box.addView(r4);

        Button inverseCalc = primaryButton("Calcular inversa");
        inverseCalc.setOnClickListener(v -> calculateInverse());
        box.addView(inverseCalc);
        inverseResult = resultBox("Resultado inverso: —");
        box.addView(inverseResult);
        return box;
    }

    private LinearLayout areaBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("Área y perímetro por coordenadas"));
        box.addView(small("Ingresa al menos tres vértices en orden alrededor del terreno. La app cierra automáticamente el último punto con el primero."));

        areaRowsContainer = new LinearLayout(this);
        areaRowsContainer.setOrientation(LinearLayout.VERTICAL);
        box.addView(areaRowsContainer);
        for (int i = 0; i < 4; i++) addAreaRow();

        LinearLayout buttons = horizontal();
        Button add = secondaryButton("+ Punto");
        add.setOnClickListener(v -> addAreaRow());
        buttons.addView(add, weight());
        Button remove = secondaryButton("− Punto");
        remove.setOnClickListener(v -> removeAreaRow());
        buttons.addView(remove, weight());
        Button clear = secondaryButton("Limpiar");
        clear.setOnClickListener(v -> clearAreaRows());
        buttons.addView(clear, weight());
        box.addView(buttons);

        Button calculate = primaryButton("Calcular área y perímetro");
        calculate.setOnClickListener(v -> calculateArea());
        box.addView(calculate);
        areaResult = resultBox("Área: —\nPerímetro: —");
        box.addView(areaResult);
        return box;
    }

    private LinearLayout notebookBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("Libreta de campo local"));
        box.addView(small("Guarda puntos en el celular y expórtalos a CSV. Usa el mismo sistema de coordenadas en todos los registros del proyecto."));

        LinearLayout r1 = horizontal();
        notebookCodeInput = textInput("Código");
        notebookElevationInput = numberInput("Cota");
        r1.addView(labeled("Código", notebookCodeInput), weight());
        r1.addView(labeled("Cota", notebookElevationInput), weight());
        box.addView(r1);

        LinearLayout r2 = horizontal();
        notebookNorthInput = numberInput("N / Latitud");
        notebookEastInput = numberInput("E / Longitud");
        r2.addView(labeled("N / Latitud", notebookNorthInput), weight());
        r2.addView(labeled("E / Longitud", notebookEastInput), weight());
        box.addView(r2);

        notebookDescriptionInput = textInput("Descripción u observación");
        box.addView(labeled("Descripción", notebookDescriptionInput));

        LinearLayout actions1 = horizontal();
        Button capture = secondaryButton("Tomar GPS actual");
        capture.setOnClickListener(v -> captureCurrentForNotebook());
        actions1.addView(capture, weight());
        Button add = primaryButton("Guardar punto");
        add.setOnClickListener(v -> addNotebookEntry());
        actions1.addView(add, weight());
        box.addView(actions1);

        LinearLayout actions2 = horizontal();
        Button export = secondaryButton("Exportar CSV");
        export.setOnClickListener(v -> exportNotebookCsv());
        actions2.addView(export, weight());
        Button clear = secondaryButton("Borrar libreta");
        clear.setOnClickListener(v -> confirmClearNotebook());
        actions2.addView(clear, weight());
        box.addView(actions2);

        notebookList = resultBox("No hay puntos guardados.");
        box.addView(notebookList);
        return box;
    }

    private void toggleStakeout() {
        if (stakeoutRunning) {
            stopStakeout();
            return;
        }
        try {
            double lat = parse(targetLatInput);
            double lon = parse(targetLonInput);
            if (lat < -90 || lat > 90 || lon < -180 || lon > 180) {
                showToast("La latitud o longitud está fuera del rango válido.");
                return;
            }
        } catch (Exception e) {
            showToast("Completa la latitud y longitud objetivo.");
            return;
        }

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        startStakeoutUpdates();
    }

    private void startStakeoutUpdates() {
        if (locationManager == null) {
            updateStakeoutMessage("El servicio de ubicación no está disponible en este dispositivo.");
            return;
        }
        try {
            boolean requested = false;
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, fieldLocationListener);
                requested = true;
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1500L, 0f, fieldLocationListener);
                requested = true;
            }
            if (!requested) {
                updateStakeoutMessage("Activa la ubicación del celular.");
                return;
            }
            stakeoutRunning = true;
            stakeoutButton.setText("Detener replanteo");
            updateStakeoutMessage("Buscando posición... Mantén el celular con vista despejada al cielo.");
        } catch (SecurityException e) {
            updateStakeoutMessage("No se concedió permiso de ubicación.");
        }
    }

    private void stopStakeout() {
        if (locationManager != null) {
            try {
                locationManager.removeUpdates(fieldLocationListener);
            } catch (SecurityException ignored) {
            }
        }
        stakeoutRunning = false;
        if (stakeoutButton != null) stakeoutButton.setText("Iniciar replanteo");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startStakeoutUpdates();
            } else {
                updateStakeoutMessage("Sin permiso de ubicación no se puede usar el replanteo.");
            }
        } else if (requestCode == REQ_NOTEBOOK_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                captureCurrentForNotebook();
            } else {
                showToast("Sin permiso de ubicación no se puede copiar la posición GPS.");
            }
        }
    }

    private void updateStakeout(Location current) {
        if (!stakeoutRunning || stakeoutResult == null) return;
        try {
            double targetLat = parse(targetLatInput);
            double targetLon = parse(targetLonInput);
            Location target = new Location("target");
            target.setLatitude(targetLat);
            target.setLongitude(targetLon);

            float distance = current.distanceTo(target);
            float bearing = normalizeBearing(current.bearingTo(target));
            double latRad = Math.toRadians((current.getLatitude() + targetLat) / 2.0);
            double dNorth = (targetLat - current.getLatitude()) * 111320.0;
            double dEast = (targetLon - current.getLongitude()) * 111320.0 * Math.cos(latRad);
            String direction = directionInstruction(dNorth, dEast, distance);

            stakeoutResult.setText(
                    "Posición actual: " + f7(current.getLatitude()) + ", " + f7(current.getLongitude()) + "\n"
                            + "Precisión estimada: ±" + f1(current.getAccuracy()) + " m\n"
                            + "Distancia al objetivo: " + f2(distance) + " m\n"
                            + "Azimut al objetivo: " + f3(bearing) + "° · " + bearingToQuadrant(bearing) + "\n"
                            + "ΔN: " + signed(dNorth) + " m · ΔE: " + signed(dEast) + " m\n"
                            + "Indicación: " + direction);
        } catch (Exception e) {
            updateStakeoutMessage("Revisa la coordenada objetivo.");
        }
    }

    private String directionInstruction(double dNorth, double dEast, double distance) {
        if (distance <= 2.0) return "Punto alcanzado dentro de 2 m. Verifica la precisión GPS antes de marcar.";
        String ns = Math.abs(dNorth) < 0.5 ? "" : (dNorth > 0 ? "Norte" : "Sur");
        String ew = Math.abs(dEast) < 0.5 ? "" : (dEast > 0 ? "Este" : "Oeste");
        if (ns.length() > 0 && ew.length() > 0) return "Avanza hacia " + ns + " y " + ew + ".";
        if (ns.length() > 0) return "Avanza hacia el " + ns + ".";
        if (ew.length() > 0) return "Avanza hacia el " + ew + ".";
        return "Estás muy cerca del punto.";
    }

    private void fillTargetWithCurrentPosition() {
        if (lastFieldLocation == null) {
            showToast("Primero inicia el replanteo o captura una posición GPS.");
            return;
        }
        targetLatInput.setText(f7(lastFieldLocation.getLatitude()));
        targetLonInput.setText(f7(lastFieldLocation.getLongitude()));
    }

    private void updateStakeoutMessage(String message) {
        if (stakeoutResult != null) stakeoutResult.setText(message);
    }

    private void calculateDirect() {
        try {
            double n0 = parse(directNorthInput);
            double e0 = parse(directEastInput);
            double az = normalizeBearing((float) parse(directAzimuthInput));
            double distance = parse(directDistanceInput);
            if (distance < 0) throw new IllegalArgumentException();
            double rad = Math.toRadians(az);
            double dN = distance * Math.cos(rad);
            double dE = distance * Math.sin(rad);
            double n2 = n0 + dN;
            double e2 = e0 + dE;
            directResult.setText("ΔN: " + signed(dN) + " m\n"
                    + "ΔE: " + signed(dE) + " m\n"
                    + "N final: " + f3(n2) + "\n"
                    + "E final: " + f3(e2));
        } catch (Exception e) {
            directResult.setText("Revisa N inicial, E inicial, azimut y distancia.");
        }
    }

    private void calculateInverse() {
        try {
            double n1 = parse(inverseNorth1Input);
            double e1 = parse(inverseEast1Input);
            double n2 = parse(inverseNorth2Input);
            double e2 = parse(inverseEast2Input);
            double dN = n2 - n1;
            double dE = e2 - e1;
            double distance = Math.hypot(dN, dE);
            if (distance == 0.0) {
                inverseResult.setText("Los dos puntos tienen la misma coordenada.");
                return;
            }
            double az = Math.toDegrees(Math.atan2(dE, dN));
            if (az < 0) az += 360.0;
            inverseResult.setText("ΔN: " + signed(dN) + " m\n"
                    + "ΔE: " + signed(dE) + " m\n"
                    + "Distancia: " + f3(distance) + " m\n"
                    + "Azimut: " + f4(az) + "°\n"
                    + "Rumbo: " + bearingToQuadrant(az));
        } catch (Exception e) {
            inverseResult.setText("Completa correctamente las cuatro coordenadas.");
        }
    }

    private void addAreaRow() {
        final int number = areaRows.size() + 1;
        LinearLayout row = horizontal();
        TextView label = text("P" + number, 14, true);
        label.setGravity(Gravity.CENTER);
        row.addView(label, new LinearLayout.LayoutParams(dp(42), dp(52)));
        EditText north = numberInput("N");
        EditText east = numberInput("E");
        row.addView(north, weight());
        row.addView(east, weight());
        PointRow item = new PointRow(row, north, east);
        areaRows.add(item);
        areaRowsContainer.addView(row);
    }

    private void removeAreaRow() {
        if (areaRows.size() <= 3) {
            showToast("Se necesitan al menos tres puntos.");
            return;
        }
        PointRow item = areaRows.remove(areaRows.size() - 1);
        areaRowsContainer.removeView(item.container);
    }

    private void clearAreaRows() {
        for (PointRow row : areaRows) {
            row.north.setText("");
            row.east.setText("");
        }
        areaResult.setText("Área: —\nPerímetro: —");
    }

    private void calculateArea() {
        try {
            List<double[]> points = new ArrayList<>();
            for (PointRow row : areaRows) {
                String nText = row.north.getText().toString().trim();
                String eText = row.east.getText().toString().trim();
                if (nText.isEmpty() && eText.isEmpty()) continue;
                if (nText.isEmpty() || eText.isEmpty()) throw new IllegalArgumentException();
                points.add(new double[]{parse(row.north), parse(row.east)});
            }
            if (points.size() < 3) {
                areaResult.setText("Ingresa por lo menos tres puntos completos.");
                return;
            }
            double twiceArea = 0.0;
            double perimeter = 0.0;
            for (int i = 0; i < points.size(); i++) {
                double[] a = points.get(i);
                double[] b = points.get((i + 1) % points.size());
                twiceArea += a[1] * b[0] - b[1] * a[0];
                perimeter += Math.hypot(b[0] - a[0], b[1] - a[1]);
            }
            double area = Math.abs(twiceArea) / 2.0;
            areaResult.setText("Vértices usados: " + points.size() + "\n"
                    + "Área: " + f3(area) + " m²\n"
                    + "Área: " + f4(area / 10000.0) + " ha\n"
                    + "Perímetro: " + f3(perimeter) + " m");
        } catch (Exception e) {
            areaResult.setText("Revisa los puntos. Cada fila usada debe tener Norte y Este.");
        }
    }

    private void captureCurrentForNotebook() {
        if (lastFieldLocation != null) {
            notebookNorthInput.setText(f7(lastFieldLocation.getLatitude()));
            notebookEastInput.setText(f7(lastFieldLocation.getLongitude()));
            if (lastFieldLocation.hasAltitude()) notebookElevationInput.setText(f3(lastFieldLocation.getAltitude()));
            showToast("Se copió la última posición GPS disponible.");
            return;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_NOTEBOOK_LOCATION);
            return;
        }
        try {
            Location gps = locationManager == null ? null : locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location network = locationManager == null ? null : locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            lastFieldLocation = newest(gps, network);
            if (lastFieldLocation == null) {
                showToast("Todavía no existe una posición reciente. Inicia el replanteo unos segundos.");
            } else {
                captureCurrentForNotebook();
            }
        } catch (SecurityException e) {
            showToast("No se pudo leer la ubicación.");
        }
    }

    private Location newest(Location a, Location b) {
        if (a == null) return b;
        if (b == null) return a;
        return a.getTime() >= b.getTime() ? a : b;
    }

    private void addNotebookEntry() {
        String code = notebookCodeInput.getText().toString().trim();
        String north = notebookNorthInput.getText().toString().trim();
        String east = notebookEastInput.getText().toString().trim();
        String elevation = notebookElevationInput.getText().toString().trim();
        String description = notebookDescriptionInput.getText().toString().trim();
        if (code.isEmpty() || north.isEmpty() || east.isEmpty()) {
            showToast("Código, N/Latitud y E/Longitud son obligatorios.");
            return;
        }
        try {
            Double.parseDouble(north.replace(',', '.'));
            Double.parseDouble(east.replace(',', '.'));
            if (!elevation.isEmpty()) Double.parseDouble(elevation.replace(',', '.'));
        } catch (Exception e) {
            showToast("Revisa las coordenadas y la cota.");
            return;
        }
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
        notebookEntries.add(new NotebookEntry(code, north.replace(',', '.'), east.replace(',', '.'), elevation.replace(',', '.'), description, timestamp));
        saveNotebook();
        renderNotebook();
        notebookCodeInput.setText("");
        notebookNorthInput.setText("");
        notebookEastInput.setText("");
        notebookElevationInput.setText("");
        notebookDescriptionInput.setText("");
    }

    private void loadNotebook() {
        notebookEntries.clear();
        String raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString(NOTEBOOK_KEY, "[]");
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.getJSONObject(i);
                notebookEntries.add(new NotebookEntry(
                        o.optString("code"), o.optString("north"), o.optString("east"),
                        o.optString("elevation"), o.optString("description"), o.optString("time")));
            }
        } catch (Exception ignored) {
        }
        renderNotebook();
    }

    private void saveNotebook() {
        JSONArray array = new JSONArray();
        try {
            for (NotebookEntry entry : notebookEntries) {
                JSONObject o = new JSONObject();
                o.put("code", entry.code);
                o.put("north", entry.north);
                o.put("east", entry.east);
                o.put("elevation", entry.elevation);
                o.put("description", entry.description);
                o.put("time", entry.time);
                array.put(o);
            }
        } catch (Exception ignored) {
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(NOTEBOOK_KEY, array.toString()).apply();
    }

    private void renderNotebook() {
        if (notebookList == null) return;
        if (notebookEntries.isEmpty()) {
            notebookList.setText("No hay puntos guardados.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Puntos guardados: ").append(notebookEntries.size()).append("\n");
        for (int i = notebookEntries.size() - 1; i >= 0; i--) {
            NotebookEntry e = notebookEntries.get(i);
            sb.append("\n").append(i + 1).append(". ").append(e.code)
                    .append(" · N/Lat ").append(e.north)
                    .append(" · E/Lon ").append(e.east);
            if (!e.elevation.isEmpty()) sb.append(" · Cota ").append(e.elevation);
            if (!e.description.isEmpty()) sb.append("\n   ").append(e.description);
            sb.append("\n   ").append(e.time);
        }
        notebookList.setText(sb.toString());
    }

    private void exportNotebookCsv() {
        if (notebookEntries.isEmpty()) {
            showToast("No hay puntos para exportar.");
            return;
        }
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/csv");
        intent.putExtra(Intent.EXTRA_TITLE, "GeoTopo_Libreta_" + new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date()) + ".csv");
        startActivityForResult(intent, REQ_EXPORT_CSV);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_EXPORT_CSV && resultCode == RESULT_OK && data != null && data.getData() != null) {
            writeNotebookCsv(data.getData());
        }
    }

    private void writeNotebookCsv(Uri uri) {
        StringBuilder csv = new StringBuilder("codigo,norte_o_latitud,este_o_longitud,cota,descripcion,fecha_hora\n");
        for (NotebookEntry e : notebookEntries) {
            csv.append(csvCell(e.code)).append(',')
                    .append(csvCell(e.north)).append(',')
                    .append(csvCell(e.east)).append(',')
                    .append(csvCell(e.elevation)).append(',')
                    .append(csvCell(e.description)).append(',')
                    .append(csvCell(e.time)).append('\n');
        }
        try {
            ContentResolver resolver = getContentResolver();
            OutputStream out = resolver.openOutputStream(uri);
            if (out == null) throw new IllegalStateException();
            out.write(csv.toString().getBytes(StandardCharsets.UTF_8));
            out.flush();
            out.close();
            showToast("Libreta exportada correctamente.");
        } catch (Exception e) {
            showToast("No se pudo exportar el archivo CSV.");
        }
    }

    private String csvCell(String value) {
        String safe = value == null ? "" : value.replace("\"", "\"\"");
        return "\"" + safe + "\"";
    }

    private void confirmClearNotebook() {
        if (notebookEntries.isEmpty()) return;
        new AlertDialog.Builder(this)
                .setTitle("Borrar libreta")
                .setMessage("Se eliminarán todos los puntos guardados en esta libreta local.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Borrar", (dialog, which) -> {
                    notebookEntries.clear();
                    saveNotebook();
                    renderNotebook();
                })
                .show();
    }

    private View collapsibleCard(LinearLayout body, String iconText, String titleText, boolean open) {
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.setPadding(dp(12), dp(10), dp(12), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(cardColor);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), withAlpha(borderColor, 120));
        wrapper.setBackground(bg);
        LinearLayout.LayoutParams wrapperLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wrapperLp.setMargins(0, 0, 0, dp(10));
        wrapper.setLayoutParams(wrapperLp);

        LinearLayout header = horizontal();
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = text(iconText, 19, true);
        icon.setTextColor(borderColor);
        icon.setGravity(Gravity.CENTER);
        header.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(42)));
        TextView title = text(titleText, 18, true);
        title.setPadding(dp(8), 0, 0, 0);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView arrow = text(open ? "⌄" : "›", 28, true);
        arrow.setTextColor(subTextColor);
        arrow.setGravity(Gravity.CENTER);
        header.addView(arrow, new LinearLayout.LayoutParams(dp(42), dp(42)));
        body.setVisibility(open ? View.VISIBLE : View.GONE);
        header.setOnClickListener(v -> {
            boolean show = body.getVisibility() != View.VISIBLE;
            body.setVisibility(show ? View.VISIBLE : View.GONE);
            arrow.setText(show ? "⌄" : "›");
        });
        wrapper.addView(header);
        wrapper.addView(body);
        return wrapper;
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        return box;
    }

    private TextView sectionTitle(String value) {
        TextView view = text(value, 17, true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(6), 0, dp(5));
        view.setLayoutParams(lp);
        return view;
    }

    private TextView small(String value) {
        TextView view = text(value, 13, false);
        view.setTextColor(subTextColor);
        view.setLineSpacing(0, 1.12f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(8));
        view.setLayoutParams(lp);
        return view;
    }

    private TextView warning(String value) {
        TextView view = small(value);
        view.setPadding(dp(10), dp(9), dp(10), dp(9));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == 0 ? Color.rgb(255, 248, 225) : Color.rgb(60, 47, 14));
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Color.rgb(255, 171, 0));
        view.setBackground(bg);
        return view;
    }

    private TextView divider() {
        TextView line = new TextView(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(withAlpha(borderColor, 90));
        line.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        lp.setMargins(0, dp(14), 0, dp(8));
        line.setLayoutParams(lp);
        return line;
    }

    private LinearLayout horizontal() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(8));
        row.setLayoutParams(lp);
        return row;
    }

    private LinearLayout labeled(String label, View child) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        TextView title = text(label, 12, true);
        title.setTextColor(subTextColor);
        box.addView(title);
        box.addView(child, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), 0, dp(3), 0);
        box.setLayoutParams(lp);
        return box;
    }

    private EditText numberInput(String hint) {
        EditText input = textInput(hint);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        return input;
    }

    private EditText textInput(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setHintTextColor(subTextColor);
        input.setTextColor(textColor);
        input.setTextSize(14);
        input.setSingleLine(true);
        input.setPadding(dp(10), 0, dp(10), 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(inputColor);
        bg.setCornerRadius(dp(9));
        bg.setStroke(dp(1), withAlpha(borderColor, 150));
        input.setBackground(bg);
        return input;
    }

    private TextView resultBox(String value) {
        TextView view = text(value, 14, false);
        view.setPadding(dp(11), dp(10), dp(11), dp(10));
        view.setLineSpacing(0, 1.12f);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == 0 ? Color.rgb(245, 250, 255) : Color.rgb(10, 31, 46));
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), withAlpha(borderColor, 160));
        view.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(6), 0, dp(4));
        view.setLayoutParams(lp);
        return view;
    }

    private Button primaryButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        button.setTextSize(14);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(accent);
        bg.setCornerRadius(dp(10));
        button.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        lp.setMargins(dp(3), dp(2), dp(3), dp(4));
        button.setLayoutParams(lp);
        return button;
    }

    private Button secondaryButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextColor(textColor);
        button.setTextSize(13);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(inputColor);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), borderColor);
        button.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        lp.setMargins(dp(3), dp(2), dp(3), dp(4));
        button.setLayoutParams(lp);
        return button;
    }

    private TextView text(String value, int size, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(textColor);
        view.setTextSize(size);
        view.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return view;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private double parse(EditText input) {
        return Double.parseDouble(input.getText().toString().trim().replace(',', '.'));
    }

    private float normalizeBearing(float value) {
        float result = value % 360f;
        return result < 0 ? result + 360f : result;
    }

    private String bearingToQuadrant(double azimuth) {
        double az = azimuth % 360.0;
        if (az < 0) az += 360.0;
        if (az <= 90.0) return "N " + f4(az) + "° E";
        if (az <= 180.0) return "S " + f4(180.0 - az) + "° E";
        if (az <= 270.0) return "S " + f4(az - 180.0) + "° O";
        return "N " + f4(360.0 - az) + "° O";
    }

    private String f1(double value) { return String.format(Locale.US, "%.1f", value); }
    private String f2(double value) { return String.format(Locale.US, "%.2f", value); }
    private String f3(double value) { return String.format(Locale.US, "%.3f", value); }
    private String f4(double value) { return String.format(Locale.US, "%.4f", value); }
    private String f7(double value) { return String.format(Locale.US, "%.7f", value); }
    private String signed(double value) { return String.format(Locale.US, "%+.3f", value); }

    private int withAlpha(int color, int alpha) {
        return Color.argb(Math.max(0, Math.min(255, alpha)), Color.red(color), Color.green(color), Color.blue(color));
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void showToast(String value) {
        Toast.makeText(this, value, Toast.LENGTH_LONG).show();
    }

    private static class PointRow {
        final LinearLayout container;
        final EditText north;
        final EditText east;

        PointRow(LinearLayout container, EditText north, EditText east) {
            this.container = container;
            this.north = north;
            this.east = east;
        }
    }

    private static class NotebookEntry {
        final String code;
        final String north;
        final String east;
        final String elevation;
        final String description;
        final String time;

        NotebookEntry(String code, String north, String east, String elevation, String description, String time) {
            this.code = code;
            this.north = north;
            this.east = east;
            this.elevation = elevation;
            this.description = description;
            this.time = time;
        }
    }
}
