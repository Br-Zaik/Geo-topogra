package com.bph.geotopo;

import android.app.Activity;
import android.app.AlertDialog;
import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.hardware.GeomagneticField;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.Surface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final String PREFS = "geo_topo_prefs";
    private static final int THEME_LIGHT = 0;
    private static final int THEME_DARK = 1;
    private static final int THEME_BLACK = 2;
    private static final int REQ_LOCATION = 9101;

    private static final int[] ACCENTS = {
            Color.rgb(41, 121, 255),
            Color.rgb(0, 188, 212),
            Color.rgb(0, 150, 136),
            Color.rgb(0, 184, 148),
            Color.rgb(118, 210, 34),
            Color.rgb(255, 214, 10),
            Color.rgb(255, 171, 0),
            Color.rgb(255, 112, 20),
            Color.rgb(244, 67, 54),
            Color.rgb(255, 64, 129),
            Color.rgb(142, 68, 173),
            Color.rgb(92, 92, 210),
            Color.rgb(149, 96, 68),
            Color.rgb(158, 169, 181),
            Color.rgb(20, 20, 22),
            Color.rgb(255, 255, 255)
    };
    private static final int[] COMPASS_ARROW_COLORS = {
            Color.rgb(41, 121, 255),
            Color.rgb(0, 188, 212),
            Color.rgb(0, 150, 136),
            Color.rgb(0, 184, 148),
            Color.rgb(118, 210, 34),
            Color.rgb(255, 214, 10),
            Color.rgb(255, 171, 0),
            Color.rgb(255, 112, 20),
            Color.rgb(231, 76, 60),
            Color.rgb(255, 64, 129),
            Color.rgb(142, 68, 173),
            Color.rgb(92, 92, 210),
            Color.rgb(149, 96, 68),
            Color.rgb(158, 169, 181),
            Color.rgb(20, 20, 22),
            Color.rgb(255, 255, 255)
    };
    private static final int[] COMPASS_RING_COLORS = {
            Color.rgb(41, 121, 255),
            Color.rgb(0, 188, 212),
            Color.rgb(0, 150, 136),
            Color.rgb(0, 184, 148),
            Color.rgb(118, 210, 34),
            Color.rgb(255, 214, 10),
            Color.rgb(255, 171, 0),
            Color.rgb(255, 112, 20),
            Color.rgb(231, 76, 60),
            Color.rgb(255, 64, 129),
            Color.rgb(142, 68, 173),
            Color.rgb(92, 92, 210),
            Color.rgb(149, 96, 68),
            Color.rgb(158, 169, 181),
            Color.rgb(20, 20, 22),
            Color.rgb(255, 255, 255)
    };

    private int themeMode;
    private int accentIndex;
    private int arrowColorIndex;
    private int ringColorIndex;

    private int bgColor;
    private int appBarColor;
    private int cardColor;
    private int textColor;
    private int subTextColor;
    private int borderColor;
    private int inputFillColor;
    private int inputStrokeColor;
    private int resultFillColor;
    private int resultStrokeColor;
    private int cellEditColor;
    private int cellLockedColor;
    private int tableLineColor;
    private int compassArrowColor;
    private int compassRingColor;
    private int sinColor;
    private int cosColor;

    private ZoomLayout zoomLayout;

    private EditText azInput;
    private EditText activeAngleInput;
    private TextView compassCaption;
    private TextView azModeHint;
    private Button modeAzBtn;
    private Button modeRumboBtn;
    private Button modeContraAzBtn;
    private Button modeContraRumboBtn;
    private TextView compassAzLabel;
    private TextView compassRumboLabel;
    private TextView compassContraAzLabel;
    private TextView compassContraRumboLabel;
    private TextView azQuadrantChip;
    private TextView azDecimalLabel;
    private TextView azExplainLabel;
    private int azInputMode = 0;
    private CompassView compassAzView;
    private CompassView compassRumboView;
    private CompassView compassContraAzView;
    private CompassView compassContraRumboView;

    private SensorManager sensorManager;
    private Sensor accelerometerSensor;
    private Sensor magneticSensor;
    private final float[] accelValues = new float[3];
    private final float[] magneticValues = new float[3];
    private boolean hasAccelValues = false;
    private boolean hasMagneticValues = false;
    private CompassView liveMagCompassView;
    private CompassView gpsCompassView;
    private CompassView selectedOrientationCompassView;
    private TextView liveCompassTitle;
    private TextView liveMagStatus;
    private TextView gpsCompassStatus;
    private int orientationCompassMode = 0; // 0 auto, 1 magnética, 2 GPS
    private LocationManager locationManager;
    private Location lastGpsLocation;
    private boolean gpsCompassRunning = false;
    private Location gpsStartLocation;
    private double gpsWalkDistanceMeters = 0.0;
    private long gpsStartMillis = 0L;
    private Double gpsDetectedBearing = null;
    private final Handler gpsUiHandler = new Handler(Looper.getMainLooper());
    private int magneticAccuracy = SensorManager.SENSOR_STATUS_UNRELIABLE;
    private boolean useTrueNorth = true;
    private double smoothedMagneticAzimuth = Double.NaN;
    private double smoothedGpsBearing = Double.NaN;
    private float lastGpsBearingAccuracy = Float.NaN;
    private int invalidGpsBearingUpdates = 0;
    private final List<Location> orientationRecentLocations = new ArrayList<>();
    private final List<Location> orientationAverageSamples = new ArrayList<>();
    private boolean orientationAverageRunning = false;
    private boolean orientationAverageForA = true;
    private long orientationAverageEndsAt = 0L;

    private EditText coordAzInput;
    private EditText distanceInput;
    private TextView coordResult;

    private EditText dhInput;
    private EditText diInput;
    private EditText angleInput;
    private EditText desnivelInput;
    private TextView distanceCalcResult;

    private EditText polyX0Input;
    private EditText polyY0Input;
    private TextView polyCheckResult;
    private TextView polyProcedureResult;
    private EditText hiloSupCalcInput;
    private EditText hiloInfCalcInput;
    private TextView hiloDistValue;
    private TextView hiloDistCalcResult;

    private View miraPracticeSection;
    private MiraPracticeView miraPracticeView;
    private EditText miraLsInput;
    private EditText miraLmInput;
    private EditText miraLiInput;
    private TextView miraPracticeResult;

    private TextView levelCheckResult;
    private TextView stadiaCheckResult;

    private final List<TableDataRow> tableRows = new ArrayList<>();
    private final List<LevelDataRow> levelRows = new ArrayList<>();
    private final List<StadiaLevelRow> stadiaRows = new ArrayList<>();
    private TableLayout coordTable;
    private TableLayout levelTable;
    private TableLayout stadiaTable;
    private boolean suppressWorkCapture = false;
    private boolean showingSettings = false;
    private ScrollView mainScroll;
    private Location orientationPointA;
    private Location orientationPointB;
    private TextView twoPointStatus;
    private Button viewOrientationMapButton;

    private View selectedColorCell;
    private TableLayout selectedColorTable;
    private int selectedColorRow = -1;
    private int selectedColorCol = -1;
    private EditText selectedDistCell;
    private int manualTextColorIndex = 0;
    private int manualBgColorIndex = 0;
    private final int[] manualTextColors = {
            Color.rgb(245, 245, 247),
            Color.rgb(255, 171, 0),
            Color.rgb(0, 184, 148),
            Color.rgb(64, 158, 255),
            Color.rgb(255, 82, 82),
            Color.rgb(30, 33, 40)
    };
    private final int[] manualBgColors = {
            Color.rgb(25, 31, 42),
            Color.rgb(51, 38, 10),
            Color.rgb(9, 45, 35),
            Color.rgb(12, 44, 82),
            Color.rgb(70, 24, 24),
            Color.rgb(245, 246, 250)
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadPrefs();
        initOrientationServices();
        buildUi();
    }

    @Override
    protected void onPause() {
        saveCurrentWork();
        unregisterMagneticCompass();
        stopGpsCompass();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean useMagnetic = orientationCompassMode == 1 || (orientationCompassMode == 0 && magneticSensor != null && accelerometerSensor != null);
        if (useMagnetic) registerMagneticCompass();
        else applyOrientationModeToViews();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            boolean granted = false;
            for (int r : grantResults) {
                if (r == PackageManager.PERMISSION_GRANTED) {
                    granted = true;
                    break;
                }
            }
            if (granted) startGpsCompass();
            else if (gpsCompassStatus != null) gpsCompassStatus.setText("Permiso de ubicación denegado.");
        }
    }

    @Override
    public void onBackPressed() {
        if (showingSettings) {
            showingSettings = false;
            buildUi();
        } else {
            super.onBackPressed();
        }
    }

    private void loadPrefs() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        themeMode = sp.getInt("theme", THEME_DARK);
        accentIndex = sp.getInt("accent", 0);
        arrowColorIndex = sp.getInt("arrow_color", 0);
        ringColorIndex = sp.getInt("ring_color", 0);
        orientationCompassMode = sp.getInt("orientation_compass_mode", 0);
        useTrueNorth = sp.getBoolean("true_north", true);
    }

    private void savePrefs() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt("theme", themeMode)
                .putInt("accent", accentIndex)
                .putInt("arrow_color", arrowColorIndex)
                .putInt("ring_color", ringColorIndex)
                .putInt("orientation_compass_mode", orientationCompassMode)
                .putBoolean("true_north", useTrueNorth)
                .apply();
    }

    private void applyPalette() {
        borderColor = ACCENTS[accentIndex % ACCENTS.length];
        compassArrowColor = COMPASS_ARROW_COLORS[arrowColorIndex % COMPASS_ARROW_COLORS.length];
        compassRingColor = COMPASS_RING_COLORS[ringColorIndex % COMPASS_RING_COLORS.length];

        sinColor = Color.rgb(255, 171, 0);
        cosColor = Color.rgb(0, 184, 148);

        if (themeMode == THEME_LIGHT) {
            bgColor = Color.rgb(241, 244, 248);
            appBarColor = Color.rgb(20, 33, 61);
            cardColor = Color.WHITE;
            textColor = Color.rgb(30, 33, 40);
            subTextColor = Color.rgb(96, 104, 118);
            inputFillColor = Color.WHITE;
            inputStrokeColor = Color.rgb(178, 184, 196);
            resultFillColor = Color.rgb(245, 252, 248);
            resultStrokeColor = Color.rgb(29, 185, 84);
            cellEditColor = Color.rgb(252, 253, 255);
            cellLockedColor = Color.rgb(244, 246, 250);
            tableLineColor = Color.rgb(190, 196, 206);
        } else if (themeMode == THEME_BLACK) {
            bgColor = Color.BLACK;
            appBarColor = Color.rgb(3, 20, 34);
            cardColor = Color.rgb(9, 11, 15);
            textColor = Color.rgb(245, 245, 247);
            subTextColor = Color.rgb(179, 184, 192);
            inputFillColor = Color.rgb(14, 16, 22);
            inputStrokeColor = Color.rgb(79, 85, 96);
            resultFillColor = Color.rgb(14, 31, 23);
            resultStrokeColor = Color.rgb(0, 200, 83);
            cellEditColor = Color.rgb(12, 18, 28);
            cellLockedColor = Color.rgb(21, 23, 28);
            tableLineColor = Color.rgb(74, 78, 88);
        } else {
            bgColor = Color.rgb(7, 22, 36);
            appBarColor = Color.rgb(3, 45, 73);
            cardColor = Color.rgb(17, 38, 58);
            textColor = Color.rgb(248, 250, 252);
            subTextColor = Color.rgb(199, 211, 222);
            inputFillColor = Color.rgb(10, 29, 45);
            inputStrokeColor = Color.rgb(92, 112, 132);
            resultFillColor = Color.rgb(9, 50, 42);
            resultStrokeColor = Color.rgb(0, 210, 125);
            cellEditColor = Color.rgb(10, 31, 50);
            cellLockedColor = Color.rgb(21, 40, 57);
            tableLineColor = Color.rgb(86, 105, 123);
        }
    }

    private void buildUi() {
        if (!suppressWorkCapture) saveCurrentWork();
        showingSettings = false;
        applyPalette();
        tableRows.clear();
        levelRows.clear();
        stadiaRows.clear();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);

        root.addView(topBar());

        mainScroll = new ScrollView(this);
        mainScroll.setFillViewport(true);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(10), dp(14), dp(24));
        content.setBackgroundColor(bgColor);

        View gpsSection = collapsibleCard((LinearLayout) gpsLoggerEntryBlock(), "⌖", "GPS y mapas", false);
        View fieldToolsSection = collapsibleCard((LinearLayout) fieldToolsEntryBlock(), "▦", "Herramientas de campo", false);
        View converterSection = collapsibleCard((LinearLayout) converterEntryBlock(), "⇄", "Conversor de unidades", false);
        View compassSection = collapsibleCard((LinearLayout) orientationCompassBlock(), "N", "Orientación y brújula", false);
        View azimuthSection = collapsibleCard((LinearLayout) azimuthBlock(), "∠", "Azimut y rumbo", false);
        View coordSection = collapsibleCard((LinearLayout) coordBlock(), "Δ", "Coordenadas parciales", false);
        View distanceSection = collapsibleCard((LinearLayout) distanceBlock(), "↗", "Distancia y pendiente", false);
        miraPracticeSection = collapsibleCard((LinearLayout) miraPracticeBlock(), "E", "Práctica de lectura de mira", false);
        View twoHairSection = collapsibleCard((LinearLayout) twoHairDistanceMiniBlock(), "Ⅱ", "Distancia por dos hilos", false);
        View polygonSection = collapsibleCard((LinearLayout) partialTableBlock(), "◇", "Poligonal cerrada", false);
        View levelSection = collapsibleCard((LinearLayout) levelingBlock(), "≋", "Nivelación", false);
        View stadiaSection = collapsibleCard((LinearLayout) stadiaLevelingBlock(), "Ⅲ", "Nivelación con tres hilos", false);

        content.addView(gpsSection);
        content.addView(fieldToolsSection);
        content.addView(converterSection);
        content.addView(compassSection);
        content.addView(azimuthSection);
        content.addView(coordSection);
        content.addView(distanceSection);
        content.addView(miraPracticeSection);
        content.addView(twoHairSection);
        content.addView(polygonSection);
        content.addView(levelSection);
        content.addView(stadiaSection);

        mainScroll.addView(content);
        root.addView(mainScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));
        setContentView(root);
        restoreCurrentWork();
    }

    private void saveCurrentWork() {
        if (azInput == null) return;

        SharedPreferences.Editor ed = getSharedPreferences(PREFS, MODE_PRIVATE).edit();

        putText(ed, "work_az_input", azInput);
        putText(ed, "work_az_label", compassAzLabel);
        putText(ed, "work_rumbo_label", compassRumboLabel);
        putText(ed, "work_contraaz_label", compassContraAzLabel);
        putText(ed, "work_contrarumbo_label", compassContraRumboLabel);
        putText(ed, "work_compass_caption", compassCaption);

        putText(ed, "work_coord_az", coordAzInput);
        putText(ed, "work_coord_dist", distanceInput);
        putText(ed, "work_coord_result", coordResult);

        putText(ed, "work_dh", dhInput);
        putText(ed, "work_di", diInput);
        putText(ed, "work_angle", angleInput);
        putText(ed, "work_desnivel", desnivelInput);
        putText(ed, "work_distance_result", distanceCalcResult);
        putText(ed, "work_hilo_sup_calc", hiloSupCalcInput);
        putText(ed, "work_hilo_inf_calc", hiloInfCalcInput);
        putText(ed, "work_hilo_dist_value", hiloDistValue);
        putText(ed, "work_hilo_dist_result", hiloDistCalcResult);
        putText(ed, "work_poly_x0", polyX0Input);
        putText(ed, "work_poly_y0", polyY0Input);
        putText(ed, "work_poly_check", polyCheckResult);
        putText(ed, "work_poly_proc", polyProcedureResult);

        putText(ed, "work_level_check", levelCheckResult);
        putText(ed, "work_stadia_check", stadiaCheckResult);

        ed.putInt("work_coord_count", tableRows.size());
        for (int i = 0; i < tableRows.size(); i++) {
            TableDataRow r = tableRows.get(i);
            putText(ed, "work_coord_" + i + "_est", r.est);
            putText(ed, "work_coord_" + i + "_pv", r.pv);
            putText(ed, "work_coord_" + i + "_az", r.az);
            putText(ed, "work_coord_" + i + "_dist", r.dist);
            putText(ed, "work_coord_" + i + "_rumbo", r.rumbo);
            putText(ed, "work_coord_" + i + "_sen", r.sen);
            putText(ed, "work_coord_" + i + "_cos", r.cos);
            putText(ed, "work_coord_" + i + "_este", r.este);
            putText(ed, "work_coord_" + i + "_oeste", r.oeste);
            putText(ed, "work_coord_" + i + "_norte", r.norte);
            putText(ed, "work_coord_" + i + "_sur", r.sur);
            putText(ed, "work_coord_" + i + "_ec", r.eCorr);
            putText(ed, "work_coord_" + i + "_wc", r.wCorr);
            putText(ed, "work_coord_" + i + "_nc", r.nCorr);
            putText(ed, "work_coord_" + i + "_sc", r.sCorr);
            putText(ed, "work_coord_" + i + "_x", r.x);
            putText(ed, "work_coord_" + i + "_y", r.y);
        }

        ed.putInt("work_level_count", levelRows.size());
        for (int i = 0; i < levelRows.size(); i++) {
            LevelDataRow r = levelRows.get(i);
            putText(ed, "work_level_" + i + "_pv", r.pv);
            putText(ed, "work_level_" + i + "_va", r.vAtras);
            putText(ed, "work_level_" + i + "_vi", r.vIntermedia);
            putText(ed, "work_level_" + i + "_vf", r.vAdelante);
            putText(ed, "work_level_" + i + "_ct", r.cotaTerreno);
            putText(ed, "work_level_" + i + "_cn", r.cotaNivel);
        }

        ed.putInt("work_stadia_count", stadiaRows.size());
        for (int i = 0; i < stadiaRows.size(); i++) {
            StadiaLevelRow r = stadiaRows.get(i);
            putText(ed, "work_stadia_" + i + "_pv", r.pv);
            putText(ed, "work_stadia_" + i + "_tipo", r.tipo);
            putText(ed, "work_stadia_" + i + "_hi", r.hInf);
            putText(ed, "work_stadia_" + i + "_hm", r.hMedio);
            putText(ed, "work_stadia_" + i + "_hs", r.hSup);
            putText(ed, "work_stadia_" + i + "_dist", r.distancia);
            putText(ed, "work_stadia_" + i + "_ct", r.cotaTerreno);
            putText(ed, "work_stadia_" + i + "_cn", r.cotaNivel);
        }

        ed.apply();
    }

    private void restoreCurrentWork() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);

        setTextIfExists(sp, "work_az_input", azInput);
        setTextIfExists(sp, "work_az_label", compassAzLabel);
        setTextIfExists(sp, "work_rumbo_label", compassRumboLabel);
        setTextIfExists(sp, "work_contraaz_label", compassContraAzLabel);
        setTextIfExists(sp, "work_contrarumbo_label", compassContraRumboLabel);
        setTextIfExists(sp, "work_compass_caption", compassCaption);

        setTextIfExists(sp, "work_coord_az", coordAzInput);
        setTextIfExists(sp, "work_coord_dist", distanceInput);
        setTextIfExists(sp, "work_coord_result", coordResult);

        setTextIfExists(sp, "work_dh", dhInput);
        setTextIfExists(sp, "work_di", diInput);
        setTextIfExists(sp, "work_angle", angleInput);
        setTextIfExists(sp, "work_desnivel", desnivelInput);
        setTextIfExists(sp, "work_distance_result", distanceCalcResult);
        setTextIfExists(sp, "work_hilo_sup_calc", hiloSupCalcInput);
        setTextIfExists(sp, "work_hilo_inf_calc", hiloInfCalcInput);
        setTextIfExists(sp, "work_hilo_dist_value", hiloDistValue);
        setTextIfExists(sp, "work_hilo_dist_result", hiloDistCalcResult);
        setTextIfExists(sp, "work_poly_x0", polyX0Input);
        setTextIfExists(sp, "work_poly_y0", polyY0Input);
        setTextIfExists(sp, "work_poly_check", polyCheckResult);
        setTextIfExists(sp, "work_poly_proc", polyProcedureResult);

        setTextIfExists(sp, "work_level_check", levelCheckResult);
        setTextIfExists(sp, "work_stadia_check", stadiaCheckResult);

        for (int i = 0; i < tableRows.size(); i++) {
            TableDataRow r = tableRows.get(i);
            setTextIfExists(sp, "work_coord_" + i + "_est", r.est);
            setTextIfExists(sp, "work_coord_" + i + "_pv", r.pv);
            setTextIfExists(sp, "work_coord_" + i + "_az", r.az);
            setTextIfExists(sp, "work_coord_" + i + "_dist", r.dist);
            setTextIfExists(sp, "work_coord_" + i + "_rumbo", r.rumbo);
            setTextIfExists(sp, "work_coord_" + i + "_sen", r.sen);
            setTextIfExists(sp, "work_coord_" + i + "_cos", r.cos);
            setTextIfExists(sp, "work_coord_" + i + "_este", r.este);
            setTextIfExists(sp, "work_coord_" + i + "_oeste", r.oeste);
            setTextIfExists(sp, "work_coord_" + i + "_norte", r.norte);
            setTextIfExists(sp, "work_coord_" + i + "_sur", r.sur);
            setTextIfExists(sp, "work_coord_" + i + "_ec", r.eCorr);
            setTextIfExists(sp, "work_coord_" + i + "_wc", r.wCorr);
            setTextIfExists(sp, "work_coord_" + i + "_nc", r.nCorr);
            setTextIfExists(sp, "work_coord_" + i + "_sc", r.sCorr);
            setTextIfExists(sp, "work_coord_" + i + "_x", r.x);
            setTextIfExists(sp, "work_coord_" + i + "_y", r.y);
        }

        for (int i = 0; i < levelRows.size(); i++) {
            LevelDataRow r = levelRows.get(i);
            setTextIfExists(sp, "work_level_" + i + "_pv", r.pv);
            setTextIfExists(sp, "work_level_" + i + "_va", r.vAtras);
            setTextIfExists(sp, "work_level_" + i + "_vi", r.vIntermedia);
            setTextIfExists(sp, "work_level_" + i + "_vf", r.vAdelante);
            setTextIfExists(sp, "work_level_" + i + "_ct", r.cotaTerreno);
            setTextIfExists(sp, "work_level_" + i + "_cn", r.cotaNivel);
        }

        for (int i = 0; i < stadiaRows.size(); i++) {
            StadiaLevelRow r = stadiaRows.get(i);
            setTextIfExists(sp, "work_stadia_" + i + "_pv", r.pv);
            setTextIfExists(sp, "work_stadia_" + i + "_tipo", r.tipo);
            setTextIfExists(sp, "work_stadia_" + i + "_hi", r.hInf);
            setTextIfExists(sp, "work_stadia_" + i + "_hm", r.hMedio);
            setTextIfExists(sp, "work_stadia_" + i + "_hs", r.hSup);
            setTextIfExists(sp, "work_stadia_" + i + "_dist", r.distancia);
            setTextIfExists(sp, "work_stadia_" + i + "_ct", r.cotaTerreno);
            setTextIfExists(sp, "work_stadia_" + i + "_cn", r.cotaNivel);
        }

        try {
            String s = azInput.getText().toString().trim();
            if (!s.isEmpty()) {
                double az = normalize(parseAngle(s));
                double contra = contraAzimuth(az);
                if (compassAzView != null) compassAzView.setAzimuth(az);
                if (compassRumboView != null) compassRumboView.setAzimuth(az);
                if (compassContraAzView != null) compassContraAzView.setAzimuth(contra);
                if (compassContraRumboView != null) compassContraRumboView.setAzimuth(contra);
            }
        } catch (Exception ignored) {
        }
    }

    private void putText(SharedPreferences.Editor ed, String key, TextView view) {
        if (view != null) ed.putString(key, view.getText().toString());
    }

    private void setTextIfExists(SharedPreferences sp, String key, TextView view) {
        if (view != null && sp.contains(key)) view.setText(sp.getString(key, ""));
    }

    private void clearWorkAndRebuild() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        for (String key : sp.getAll().keySet()) {
            if (key.startsWith("work_")) ed.remove(key);
        }
        ed.commit();
        suppressWorkCapture = true;
        buildUi();
        suppressWorkCapture = false;
    }

    private View topBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(14), dp(14), dp(14));
        bar.setBackgroundColor(appBarColor);

        LinearLayout titleWrap = new LinearLayout(this);
        titleWrap.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        titleWrap.setLayoutParams(titleParams);

        TextView title = new TextView(this);
        title.setText("Geo Topo");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        titleWrap.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Cálculos topográficos");
        sub.setTextColor(Color.rgb(193, 218, 240));
        sub.setTextSize(13);
        titleWrap.addView(sub);
        bar.addView(titleWrap);

        TextView settings = new TextView(this);
        settings.setText("⚙");
        settings.setContentDescription("Ajustes");
        settings.setGravity(Gravity.CENTER);
        settings.setTextColor(Color.WHITE);
        settings.setTextSize(25);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(withAlpha(borderColor, 210));
        gd.setCornerRadius(dp(24));
        settings.setBackground(gd);
        settings.setOnClickListener(v -> showSettingsScreen());
        bar.addView(settings, new LinearLayout.LayoutParams(dp(50), dp(50)));

        return bar;
    }

    private void showSettingsScreen() {
        saveCurrentWork();
        applyPalette();
        showingSettings = true;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);

        root.addView(settingsBar());

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(18), dp(14), dp(24));
        content.setBackgroundColor(bgColor);

        content.addView(settingHeader("APARIENCIA"));
        content.addView(themeRow("☀", "Tema claro", "Fondo blanco limpio", THEME_LIGHT));
        content.addView(themeRow("☾", "Tema oscuro", "Fondo azul oscuro", THEME_DARK));
        content.addView(themeRow("●", "Tema negro", "Fondo negro AMOLED", THEME_BLACK));

        content.addView(settingHeader("COLORES"));
        content.addView(valueRow("▣", "Color de cuadros", accentName(accentIndex), v ->
                showColorPickerDialog("Color de cuadros", accentNames(), ACCENTS, accentIndex, index -> {
                    accentIndex = index;
                    savePrefs();
                    showSettingsScreen();
                })));
        content.addView(valueRow("➤", "Flecha de brújula", arrowName(arrowColorIndex), v ->
                showColorPickerDialog("Flecha de brújula", arrowNames(), COMPASS_ARROW_COLORS, arrowColorIndex, index -> {
                    arrowColorIndex = index;
                    savePrefs();
                    showSettingsScreen();
                })));
        content.addView(valueRow("◎", "Círculo de brújula", ringName(ringColorIndex), v ->
                showColorPickerDialog("Círculo de brújula", ringNames(), COMPASS_RING_COLORS, ringColorIndex, index -> {
                    ringColorIndex = index;
                    savePrefs();
                    showSettingsScreen();
                })));

        content.addView(settingHeader("TABLAS Y DATOS"));
        content.addView(infoRow("＋", "Agregar filas", "Usa + Fila o + Punto dentro de cada cuadro"));
        content.addView(infoRow("□", "Recordar datos", "Abrir donde te quedaste"));
        content.addView(valueRow("🧹", "Limpiar datos guardados", "Borra todos los cuadros", v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Limpiar datos")
                    .setMessage("¿Quieres borrar los datos guardados de los cuadros?")
                    .setPositiveButton("Borrar", (d, w) -> {
                        clearWorkAndRebuild();
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        }));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private View settingsBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(16), dp(14), dp(16));
        bar.setBackgroundColor(appBarColor);

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextColor(Color.WHITE);
        back.setTextSize(40);
        back.setGravity(Gravity.CENTER);
        back.setTypeface(Typeface.DEFAULT_BOLD);
        back.setOnClickListener(v -> {
            showingSettings = false;
            buildUi();
        });
        bar.addView(back, new LinearLayout.LayoutParams(dp(54), dp(54)));

        TextView title = new TextView(this);
        title.setText("Ajustes");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView ok = new TextView(this);
        ok.setText("✓");
        ok.setTextColor(Color.WHITE);
        ok.setTextSize(34);
        ok.setGravity(Gravity.CENTER);
        ok.setTypeface(Typeface.DEFAULT_BOLD);
        ok.setOnClickListener(v -> {
            savePrefs();
            showingSettings = false;
            buildUi();
        });
        bar.addView(ok, new LinearLayout.LayoutParams(dp(54), dp(54)));
        return bar;
    }

    private TextView settingHeader(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(borderColor);
        v.setTextSize(14);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setPadding(dp(4), dp(18), dp(4), dp(8));
        return v;
    }

    private View themeRow(String icon, String title, String subtitle, int mode) {
        return settingRow(icon, title, subtitle, themeMode == mode ? "◉" : "○", v -> {
            themeMode = mode;
            savePrefs();
            showSettingsScreen();
        });
    }

    private View valueRow(String icon, String title, String subtitle, View.OnClickListener listener) {
        return settingRow(icon, title, subtitle, "›", listener);
    }

    private View infoRow(String icon, String title, String subtitle) {
        return settingRow(icon, title, subtitle, "", null);
    }

    private View settingRow(String icon, String title, String subtitle, String right, View.OnClickListener listener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == THEME_LIGHT ? Color.WHITE : Color.rgb(12, 35, 52));
        bg.setStroke(dp(1), themeMode == THEME_LIGHT ? Color.rgb(225, 230, 238) : Color.rgb(16, 48, 70));
        row.setBackground(bg);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.setMargins(0, 0, 0, dp(6));
        row.setLayoutParams(rlp);
        if (listener != null) row.setOnClickListener(listener);

        TextView ico = new TextView(this);
        ico.setText(icon);
        ico.setTextSize(24);
        ico.setTextColor(borderColor);
        ico.setGravity(Gravity.CENTER);
        row.addView(ico, new LinearLayout.LayoutParams(dp(58), dp(54)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(textColor);
        t.setTextSize(18);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        texts.addView(t);
        TextView s = new TextView(this);
        s.setText(subtitle);
        s.setTextColor(subTextColor);
        s.setTextSize(13);
        texts.addView(s);
        row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView rr = new TextView(this);
        rr.setText(right);
        rr.setTextColor(right.equals("◉") ? borderColor : subTextColor);
        rr.setTextSize(right.equals("›") ? 30 : 20);
        rr.setGravity(Gravity.CENTER);
        row.addView(rr, new LinearLayout.LayoutParams(dp(42), dp(54)));
        return row;
    }

    private String accentName(int idx) {
        String[] names = accentNames();
        return names[idx % names.length];
    }

    private String arrowName(int idx) {
        String[] names = arrowNames();
        return names[idx % names.length];
    }

    private String ringName(int idx) {
        String[] names = ringNames();
        return names[idx % names.length];
    }

    private String[] accentNames() {
        return fullColorNames();
    }

    private String[] arrowNames() {
        return fullColorNames();
    }

    private String[] ringNames() {
        return fullColorNames();
    }

    private String[] fullColorNames() {
        return new String[]{
                "Azul", "Cian", "Turquesa", "Verde", "Verde lima", "Amarillo",
                "Ámbar", "Naranja", "Rojo", "Rosa", "Morado", "Índigo",
                "Marrón", "Gris", "Negro", "Blanco"
        };
    }

    private void showColorPickerDialog(String title, String[] names, int[] colors, int currentIndex, ColorPickListener listener) {
        final int[] selected = {currentIndex};
        final AlertDialog[] dialogRef = new AlertDialog[1];

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(14), dp(14), dp(12));
        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setColor(themeMode == THEME_LIGHT ? Color.WHITE : Color.rgb(12, 25, 39));
        panelBg.setCornerRadius(dp(18));
        panelBg.setStroke(dp(1), themeMode == THEME_LIGHT ? Color.rgb(210, 218, 230) : Color.rgb(58, 76, 100));
        panel.setBackground(panelBg);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);

        TextView icon = new TextView(this);
        icon.setText("◉");
        icon.setGravity(Gravity.CENTER);
        icon.setTextSize(23);
        icon.setTextColor(borderColor);
        head.addView(icon, new LinearLayout.LayoutParams(dp(46), dp(46)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(textColor);
        titleView.setTextSize(22);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        texts.addView(titleView);
        TextView help = new TextView(this);
        help.setText("Elige el color que quieres aplicar.");
        help.setTextColor(subTextColor);
        help.setTextSize(13);
        texts.addView(help);
        head.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView close = new TextView(this);
        close.setText("×");
        close.setGravity(Gravity.CENTER);
        close.setTextColor(subTextColor);
        close.setTextSize(30);
        close.setOnClickListener(v -> {
            if (dialogRef[0] != null) dialogRef[0].dismiss();
        });
        head.addView(close, new LinearLayout.LayoutParams(dp(44), dp(44)));
        panel.addView(head);

        ScrollView scroller = new ScrollView(this);
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        grid.setPadding(0, dp(10), 0, dp(6));

        int columns = 2;
        for (int i = 0; i < names.length && i < colors.length; i += columns) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < columns; c++) {
                int index = i + c;
                if (index >= names.length || index >= colors.length) {
                    SpaceView spacer = new SpaceView(this);
                    row.addView(spacer, weightParams());
                    continue;
                }
                View option = colorOptionView(names[index], colors[index], index == currentIndex);
                final int picked = index;
                option.setOnClickListener(v -> {
                    selected[0] = picked;
                    listener.onPick(picked);
                    if (dialogRef[0] != null) dialogRef[0].dismiss();
                });
                row.addView(option, weightParams());
            }
            grid.addView(row);
        }
        scroller.addView(grid);
        panel.addView(scroller, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(380)));

        TextView note = new TextView(this);
        note.setText("Se aplica al instante y queda guardado al volver.");
        note.setTextColor(subTextColor);
        note.setTextSize(12);
        note.setPadding(dp(4), dp(2), dp(4), dp(8));
        panel.addView(note);

        Button cancel = btn("Cerrar");
        cancel.setOnClickListener(v -> {
            if (dialogRef[0] != null) dialogRef[0].dismiss();
        });
        panel.addView(cancel);

        ScrollView graphScroll = new ScrollView(this);
        graphScroll.addView(panel);
        AlertDialog dialog = new AlertDialog.Builder(this).setView(graphScroll).create();
        dialogRef[0] = dialog;
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            }
        });
        dialog.show();
    }

    private View colorOptionView(String name, int color, boolean selected) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(8), dp(8), dp(8));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == THEME_LIGHT ? Color.rgb(248, 250, 255) : Color.rgb(15, 26, 40));
        bg.setCornerRadius(dp(11));
        bg.setStroke(dp(selected ? 2 : 1), selected ? color : inputStrokeColor);
        row.setBackground(bg);

        TextView chip = new TextView(this);
        chip.setText(selected ? "✓" : "");
        chip.setGravity(Gravity.CENTER);
        chip.setTextColor(bestContrastColor(color));
        chip.setTextSize(15);
        chip.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable chipBg = new GradientDrawable();
        chipBg.setShape(GradientDrawable.OVAL);
        chipBg.setColor(color);
        chipBg.setStroke(dp(1), Color.rgb(188, 194, 205));
        chip.setBackground(chipBg);
        row.addView(chip, new LinearLayout.LayoutParams(dp(34), dp(34)));

        TextView label = new TextView(this);
        label.setText(name);
        label.setTextColor(textColor);
        label.setTextSize(14);
        label.setTypeface(selected ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        label.setPadding(dp(10), 0, 0, 0);
        row.addView(label, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return row;
    }

    public static class SpaceView extends View {
        public SpaceView(Context context) { super(context); }
    }

    private int bestContrastColor(int color) {
        int r = Color.red(color);
        int g = Color.green(color);
        int b = Color.blue(color);
        double luminance = (0.299 * r + 0.587 * g + 0.114 * b);
        return luminance > 170 ? Color.rgb(30, 33, 40) : Color.WHITE;
    }


    private final SensorEventListener magneticCompassListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                lowPassSensor(event.values, accelValues, hasAccelValues);
                hasAccelValues = true;
            } else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
                lowPassSensor(event.values, magneticValues, hasMagneticValues);
                hasMagneticValues = true;
            }
            updateMagneticCompass();
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
            if (sensor.getType() != Sensor.TYPE_MAGNETIC_FIELD) return;
            magneticAccuracy = accuracy;
            if (liveMagStatus != null && accuracy == SensorManager.SENSOR_STATUS_UNRELIABLE) {
                liveMagStatus.setText("Sensor magnético sin calibrar. Aléjate de metal y mueve el celular en forma de 8.");
            }
        }
    };

    private final LocationListener gpsCompassListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            updateGpsCompass(location);
        }

        @Override
        public void onProviderEnabled(String provider) {
            if (gpsCompassStatus != null) gpsCompassStatus.setText("GPS activo. Camina en línea recta hasta obtener una dirección estable.");
        }

        @Override
        public void onProviderDisabled(String provider) {
            if (gpsCompassStatus != null) gpsCompassStatus.setText("Activa ubicación/GPS del celular.");
        }
    };

    private void initOrientationServices() {
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (sensorManager != null) {
            accelerometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            magneticSensor = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        }
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
    }

    private View gpsLoggerEntryBlock() {
        LinearLayout box = card();
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(sectionTitle("GPS y mapas"));
        box.addView(small("Captura puntos, exporta CSV/KML/GPX y trabaja con mapas online u offline."));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button openGps = btn("GPS y puntos");
        openGps.setOnClickListener(v -> startActivity(new android.content.Intent(this, GpsActivity.class)));
        actions.addView(openGps, weightParams());
        Button openMap = btn("Abrir mapa");
        openMap.setOnClickListener(v -> startActivity(new android.content.Intent(this, MapActivity.class)));
        actions.addView(openMap, weightParams());
        box.addView(actions);
        return box;
    }

    private View fieldToolsEntryBlock() {
        LinearLayout box = card();
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(sectionTitle("Herramientas de campo"));
        box.addView(small("Replanteo con GPS, COGO directo e inverso, área y perímetro por coordenadas, y libreta de campo guardada en el celular."));

        Button open = btn("Abrir herramientas de campo");
        open.setOnClickListener(v -> startActivity(new android.content.Intent(this, FieldToolsActivity.class)));
        box.addView(open);
        return box;
    }

    private View converterEntryBlock() {
        LinearLayout box = card();
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(sectionTitle("Conversor de unidades"));
        box.addView(small("Convierte longitud, área, volumen, velocidad, ángulos y pendiente. Funciona sin internet y sin anuncios."));

        Button open = btn("Abrir conversor");
        open.setOnClickListener(v -> startActivity(new android.content.Intent(this, ConverterActivity.class)));
        box.addView(open);
        return box;
    }

    private View orientationCompassBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("Brújula de orientación"));
        box.addView(small("La app usa el sensor magnético cuando existe; si no, calcula dirección por movimiento o por una línea GPS A–B."));

        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        liveCompassTitle = tv("Modo: automático", 15, true);
        liveCompassTitle.setGravity(Gravity.CENTER_VERTICAL);
        modeRow.addView(liveCompassTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button choose = btn("⚙ Elegir brújula");
        choose.setOnClickListener(v -> showOrientationModeDialog());
        modeRow.addView(choose, new LinearLayout.LayoutParams(dp(170), ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(modeRow);

        LinearLayout compassCard = new LinearLayout(this);
        compassCard.setOrientation(LinearLayout.VERTICAL);
        compassCard.setGravity(Gravity.CENTER);
        compassCard.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(themeMode == THEME_LIGHT ? Color.rgb(248, 250, 255) : Color.rgb(12, 24, 38));
        cardBg.setStroke(dp(1), borderColor);
        cardBg.setCornerRadius(dp(16));
        compassCard.setBackground(cardBg);
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardLp.setMargins(0, dp(8), 0, dp(8));
        compassCard.setLayoutParams(cardLp);

        selectedOrientationCompassView = new CompassView(this);
        selectedOrientationCompassView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(360)));
        compassCard.addView(selectedOrientationCompassView);

        TextView status = small("Selecciona una brújula.");
        status.setGravity(Gravity.CENTER);
        status.setPadding(dp(8), dp(8), dp(8), dp(2));
        compassCard.addView(status);
        liveMagStatus = status;
        gpsCompassStatus = status;
        box.addView(compassCard);

        LinearLayout gpsBtns = new LinearLayout(this);
        gpsBtns.setOrientation(LinearLayout.HORIZONTAL);
        Button start = btn("Iniciar GPS");
        start.setOnClickListener(v -> {
            orientationCompassMode = 2;
            savePrefs();
            applyOrientationModeToViews();
            startGpsCompass();
        });
        gpsBtns.addView(start, weightParams());
        Button stop = btn("Detener GPS");
        stop.setOnClickListener(v -> stopGpsCompass());
        gpsBtns.addView(stop, weightParams());
        box.addView(gpsBtns);

        LinearLayout twoPointBtns = new LinearLayout(this);
        twoPointBtns.setOrientation(LinearLayout.HORIZONTAL);
        Button pointA = btn("Guardar punto A");
        pointA.setOnClickListener(v -> captureOrientationPointA());
        twoPointBtns.addView(pointA, weightParams());
        Button pointB = btn("Calcular A → B");
        pointB.setOnClickListener(v -> calculateOrientationPointB());
        twoPointBtns.addView(pointB, weightParams());
        box.addView(twoPointBtns);
        twoPointStatus = resultBox("Orientación A–B: registra A, camina en línea recta y registra B. La distancia recomendada depende de la precisión GPS.");
        box.addView(twoPointStatus);
        viewOrientationMapButton = btn("Ver línea A–B en el mapa");
        viewOrientationMapButton.setEnabled(false);
        viewOrientationMapButton.setAlpha(0.45f);
        viewOrientationMapButton.setOnClickListener(v -> openOrientationInMap());
        box.addView(viewOrientationMapButton);

        applyOrientationModeToViews();
        return box;
    }

    private void showOrientationModeDialog() {
        final String[] names = {"Automática", "Magnética", "GPS / movimiento"};
        final String[] desc = {
                "Usa magnética si hay sensor; si no, usa GPS.",
                "Funciona sin GPS, solo si el celular tiene magnetómetro.",
                "Para celulares sin magnetómetro. Pide ubicación y debes caminar recto."
        };
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == THEME_LIGHT ? Color.WHITE : Color.rgb(12, 25, 39));
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), borderColor);
        panel.setBackground(bg);

        TextView title = tv("Elegir brújula", 21, true);
        title.setPadding(dp(4), 0, dp(4), dp(8));
        panel.addView(title);

        CheckBox trueNorth = new CheckBox(this);
        trueNorth.setText("Corregir a norte verdadero cuando haya ubicación");
        trueNorth.setTextColor(textColor);
        trueNorth.setChecked(useTrueNorth);
        trueNorth.setPadding(dp(4), dp(2), dp(4), dp(8));
        trueNorth.setOnCheckedChangeListener((button, checked) -> {
            useTrueNorth = checked;
            savePrefs();
            smoothedMagneticAzimuth = Double.NaN;
            updateMagneticCompass();
        });
        panel.addView(trueNorth);

        TextView sensorState = small(magneticSensor == null
                ? "Este equipo no tiene magnetómetro: usa GPS / movimiento o A–B."
                : "Magnetómetro detectado: " + magneticSensor.getName());
        sensorState.setPadding(dp(4), 0, dp(4), dp(8));
        panel.addView(sensorState);

        final AlertDialog[] dialogRef = new AlertDialog[1];
        for (int i = 0; i < names.length; i++) {
            final int mode = i;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(10), dp(10), dp(10), dp(10));
            GradientDrawable rowBg = new GradientDrawable();
            rowBg.setColor(themeMode == THEME_LIGHT ? Color.rgb(248, 250, 255) : Color.rgb(15, 26, 40));
            rowBg.setCornerRadius(dp(12));
            rowBg.setStroke(dp(1), orientationCompassMode == mode ? borderColor : inputStrokeColor);
            row.setBackground(rowBg);
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.setMargins(0, dp(5), 0, dp(5));
            row.setLayoutParams(rlp);

            TextView check = tv(orientationCompassMode == mode ? "✓" : "○", 22, true);
            check.setTextColor(orientationCompassMode == mode ? borderColor : subTextColor);
            check.setGravity(Gravity.CENTER);
            row.addView(check, new LinearLayout.LayoutParams(dp(44), dp(48)));

            LinearLayout texts = new LinearLayout(this);
            texts.setOrientation(LinearLayout.VERTICAL);
            TextView n = tv(names[i], 16, true);
            texts.addView(n);
            TextView d = tv(desc[i], 12, false);
            d.setTextColor(subTextColor);
            texts.addView(d);
            row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.setOnClickListener(v -> {
                orientationCompassMode = mode;
                savePrefs();
                applyOrientationModeToViews();
                if (dialogRef[0] != null) dialogRef[0].dismiss();
            });
            panel.addView(row);
        }
        Button close = btn("Cerrar");
        close.setOnClickListener(v -> { if (dialogRef[0] != null) dialogRef[0].dismiss(); });
        panel.addView(close);
        AlertDialog dialog = new AlertDialog.Builder(this).setView(panel).create();
        dialogRef[0] = dialog;
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        });
        dialog.show();
    }

    private void applyOrientationModeToViews() {
        if (selectedOrientationCompassView == null) return;
        boolean magneticAvailable = magneticSensor != null && accelerometerSensor != null;
        int effective = orientationCompassMode;
        if (effective == 0) effective = magneticAvailable ? 1 : 2;

        if (effective == 1) {
            liveMagCompassView = selectedOrientationCompassView;
            gpsCompassView = null;
            selectedOrientationCompassView.setDirectionAvailable(magneticAvailable);
            if (liveCompassTitle != null) liveCompassTitle.setText(orientationCompassMode == 0 ? "Modo: automático → magnética" : "Modo: brújula magnética");
            if (!magneticAvailable) {
                if (liveMagStatus != null) liveMagStatus.setText("No disponible: tu celular no tiene magnetómetro. Cambia a GPS.");
            } else {
                if (liveMagStatus != null) liveMagStatus.setText("Sensor magnético disponible. Mantén el celular horizontal y lejos de metal.");
                registerMagneticCompass();
            }
        } else {
            unregisterMagneticCompass();
            gpsCompassView = selectedOrientationCompassView;
            liveMagCompassView = null;
            selectedOrientationCompassView.setDirectionAvailable(false);
            if (liveCompassTitle != null) liveCompassTitle.setText(orientationCompassMode == 0 ? "Modo: automático → GPS" : "Modo: brújula GPS");
            if (gpsCompassStatus != null) gpsCompassStatus.setText("GPS detenido. Inícialo y camina en línea recta; si estás quieto usa puntos A–B.");
        }
    }

    private void registerMagneticCompass() {
        if (sensorManager == null || accelerometerSensor == null || magneticSensor == null) {
            if (liveMagStatus != null) liveMagStatus.setText("No disponible: este celular no tiene magnetómetro. Usa GPS o A–B.");
            return;
        }
        sensorManager.unregisterListener(magneticCompassListener);
        sensorManager.registerListener(magneticCompassListener, accelerometerSensor, SensorManager.SENSOR_DELAY_GAME);
        sensorManager.registerListener(magneticCompassListener, magneticSensor, SensorManager.SENSOR_DELAY_GAME);
        updateLastKnownLocationForDeclination();
        if (liveMagStatus != null) liveMagStatus.setText("Leyendo sensor magnético… Mantén el celular horizontal.");
    }

    private void unregisterMagneticCompass() {
        if (sensorManager != null) sensorManager.unregisterListener(magneticCompassListener);
    }

    private void lowPassSensor(float[] input, float[] output, boolean initialized) {
        if (!initialized) {
            System.arraycopy(input, 0, output, 0, Math.min(3, input.length));
            return;
        }
        final float alpha = 0.18f;
        for (int i = 0; i < 3; i++) output[i] += alpha * (input[i] - output[i]);
    }

    private void updateLastKnownLocationForDeclination() {
        if (locationManager == null || !hasLocationPermission()) return;
        try {
            Location gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location net = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            Location best = gps;
            if (best == null || (net != null && net.getTime() > best.getTime())) best = net;
            if (best != null && (lastGpsLocation == null || best.getTime() > lastGpsLocation.getTime())) lastGpsLocation = new Location(best);
        } catch (SecurityException ignored) {}
    }

    private void updateMagneticCompass() {
        if (!hasAccelValues || !hasMagneticValues || liveMagCompassView == null) return;
        float[] rotation = new float[9];
        float[] inclination = new float[9];
        if (!SensorManager.getRotationMatrix(rotation, inclination, accelValues, magneticValues)) return;

        float[] remapped = new float[9];
        int displayRotation = getWindowManager().getDefaultDisplay().getRotation();
        int axisX = SensorManager.AXIS_X;
        int axisY = SensorManager.AXIS_Y;
        if (displayRotation == Surface.ROTATION_90) {
            axisX = SensorManager.AXIS_Y;
            axisY = SensorManager.AXIS_MINUS_X;
        } else if (displayRotation == Surface.ROTATION_180) {
            axisX = SensorManager.AXIS_MINUS_X;
            axisY = SensorManager.AXIS_MINUS_Y;
        } else if (displayRotation == Surface.ROTATION_270) {
            axisX = SensorManager.AXIS_MINUS_Y;
            axisY = SensorManager.AXIS_X;
        }
        if (!SensorManager.remapCoordinateSystem(rotation, axisX, axisY, remapped)) return;

        float[] orientation = new float[3];
        SensorManager.getOrientation(remapped, orientation);
        double magneticAzimuth = normalizeBearing(Math.toDegrees(orientation[0]));
        double azimuth = magneticAzimuth;
        String reference = "magnético";
        if (useTrueNorth && lastGpsLocation != null) {
            float altitude = lastGpsLocation.hasAltitude() ? (float) lastGpsLocation.getAltitude() : 0f;
            GeomagneticField field = new GeomagneticField(
                    (float) lastGpsLocation.getLatitude(),
                    (float) lastGpsLocation.getLongitude(), altitude, System.currentTimeMillis());
            azimuth = normalizeBearing(magneticAzimuth + field.getDeclination());
            reference = "verdadero";
        }
        smoothedMagneticAzimuth = smoothBearing(smoothedMagneticAzimuth, azimuth, 0.20);
        liveMagCompassView.setDirectionAvailable(true);
        liveMagCompassView.setAzimuth(smoothedMagneticAzimuth);

        String quality = magneticAccuracyLabel(magneticAccuracy);
        if (liveMagStatus != null) {
            String calibration = magneticAccuracy == SensorManager.SENSOR_STATUS_UNRELIABLE
                    ? "\nCalibra en forma de 8 y aléjate de metal."
                    : "";
            liveMagStatus.setText("Norte " + reference + ": " + formatDms(smoothedMagneticAzimuth)
                    + " · calidad " + quality + calibration);
        }
    }

    private String magneticAccuracyLabel(int accuracy) {
        if (accuracy == SensorManager.SENSOR_STATUS_ACCURACY_HIGH) return "alta";
        if (accuracy == SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM) return "media";
        if (accuracy == SensorManager.SENSOR_STATUS_ACCURACY_LOW) return "baja";
        return "no confiable";
    }

    private double smoothBearing(double previous, double next, double alpha) {
        next = normalizeBearing(next);
        if (Double.isNaN(previous)) return next;
        double diff = ((next - previous + 540.0) % 360.0) - 180.0;
        return normalizeBearing(previous + alpha * diff);
    }

    private double normalizeBearing(double value) {
        value %= 360.0;
        if (value < 0) value += 360.0;
        return value;
    }

    private boolean hasLocationPermission() {
        if (Build.VERSION.SDK_INT < 23) return true;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestLocationPermission() {
        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
        }
    }

    private void startGpsCompass() {
        if (locationManager == null) {
            if (gpsCompassStatus != null) gpsCompassStatus.setText("Ubicación no disponible en este equipo.");
            return;
        }
        if (!hasLocationPermission()) {
            if (gpsCompassStatus != null) gpsCompassStatus.setText("Acepta el permiso de ubicación para usar GPS.");
            requestLocationPermission();
            return;
        }
        try {
            gpsCompassRunning = true;
            lastGpsLocation = null;
            gpsStartLocation = null;
            gpsWalkDistanceMeters = 0.0;
            gpsDetectedBearing = null;
            smoothedGpsBearing = Double.NaN;
            lastGpsBearingAccuracy = Float.NaN;
            invalidGpsBearingUpdates = 0;
            orientationRecentLocations.clear();
            gpsStartMillis = System.currentTimeMillis();
            updateGpsProgressStatus();
            gpsUiHandler.removeCallbacksAndMessages(null);
            gpsUiHandler.postDelayed(new Runnable() {
                @Override public void run() {
                    if (!gpsCompassRunning) return;
                    updateGpsProgressStatus();
                    gpsUiHandler.postDelayed(this, 1000);
                }
            }, 1000);
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 800, 1.0f, gpsCompassListener);
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1200, 2.0f, gpsCompassListener);
            }
        } catch (SecurityException e) {
            if (gpsCompassStatus != null) gpsCompassStatus.setText("Permiso de ubicación requerido.");
        } catch (Exception e) {
            if (gpsCompassStatus != null) gpsCompassStatus.setText("No se pudo iniciar GPS. Activa ubicación.");
        }
    }

    private void stopGpsCompass() {
        if (locationManager != null) {
            try { locationManager.removeUpdates(gpsCompassListener); } catch (Exception ignored) {}
        }
        gpsCompassRunning = false;
        if (gpsCompassStatus != null) gpsCompassStatus.setText("GPS detenido. La orientación por movimiento no está disponible.");
        gpsDetectedBearing = null;
        smoothedGpsBearing = Double.NaN;
        invalidGpsBearingUpdates = 0;
        if (gpsCompassView != null) gpsCompassView.setDirectionAvailable(false);
        orientationAverageRunning = false;
        orientationAverageSamples.clear();
        gpsStartLocation = null;
        gpsWalkDistanceMeters = 0.0;
        gpsStartMillis = 0L;
        gpsUiHandler.removeCallbacksAndMessages(null);
    }

    private void updateGpsProgressStatus() {
        if (gpsCompassStatus == null) return;
        long secs = gpsStartMillis > 0 ? Math.max(0L, (System.currentTimeMillis() - gpsStartMillis) / 1000L) : 0L;
        String distText = String.format(Locale.US, "%.1f", gpsWalkDistanceMeters);
        String accuracyText = lastGpsLocation != null && lastGpsLocation.hasAccuracy()
                ? String.format(Locale.US, "±%.1f m", lastGpsLocation.getAccuracy()) : "sin precisión";
        if (orientationAverageRunning) {
            long remaining = Math.max(0L, (orientationAverageEndsAt - System.currentTimeMillis() + 999L) / 1000L);
            gpsCompassStatus.setText("Promediando punto " + (orientationAverageForA ? "A" : "B") + "… " + remaining + " s"
                    + "\nLecturas válidas: " + orientationAverageSamples.size() + " · precisión actual " + accuracyText);
        } else if (gpsDetectedBearing != null) {
            String bearingAcc = Float.isNaN(lastGpsBearingAccuracy) ? "" : String.format(Locale.US, " · rumbo ±%.0f°", lastGpsBearingAccuracy);
            gpsCompassStatus.setText("Dirección de movimiento: " + formatDms(gpsDetectedBearing)
                    + bearingAcc + "\nGPS " + accuracyText + " · recorrido " + distText + " m · " + secs + " s");
        } else if (gpsCompassRunning) {
            gpsCompassStatus.setText("GPS activo, pero sin rumbo confiable. Camina en línea recta a paso normal."
                    + "\nGPS " + accuracyText + " · recorrido " + distText + " m · " + secs + " s");
        }
    }

    private void updateGpsCompass(Location location) {
        if (location == null) return;
        long age = Math.abs(System.currentTimeMillis() - location.getTime());
        if (age > 15000L) return;
        if (location.hasAccuracy() && location.getAccuracy() > 60f) {
            lastGpsLocation = new Location(location);
            invalidGpsBearingUpdates++;
            if (invalidGpsBearingUpdates >= 2) {
                gpsDetectedBearing = null;
                lastGpsBearingAccuracy = Float.NaN;
                if (gpsCompassView != null) gpsCompassView.setDirectionAvailable(false);
            }
            updateGpsProgressStatus();
            return;
        }

        if (orientationAverageRunning && (!location.hasAccuracy() || location.getAccuracy() <= 25f)) {
            orientationAverageSamples.add(new Location(location));
            if (orientationAverageSamples.size() > 80) orientationAverageSamples.remove(0);
        }
        orientationRecentLocations.add(new Location(location));
        while (orientationRecentLocations.size() > 30) orientationRecentLocations.remove(0);

        if (lastGpsLocation != null) {
            float step = lastGpsLocation.distanceTo(location);
            float noise = ((lastGpsLocation.hasAccuracy() ? lastGpsLocation.getAccuracy() : 8f)
                    + (location.hasAccuracy() ? location.getAccuracy() : 8f)) * 0.25f;
            if (step > Math.max(1.5f, noise) && step < 100f) gpsWalkDistanceMeters += step;
        }

        double bearing = Double.NaN;
        float bearingAccuracy = Float.NaN;
        boolean goodPosition = !location.hasAccuracy() || location.getAccuracy() <= 25f;
        if (goodPosition && location.hasBearing() && location.hasSpeed() && location.getSpeed() >= 1.0f) {
            bearing = location.getBearing();
            if (Build.VERSION.SDK_INT >= 26 && location.hasBearingAccuracy()) bearingAccuracy = location.getBearingAccuracyDegrees();
            if (!Float.isNaN(bearingAccuracy) && bearingAccuracy > 55f) bearing = Double.NaN;
        }
        if (Double.isNaN(bearing) && goodPosition) {
            Location baseline = findGpsBearingBaseline(location);
            if (baseline != null) bearing = bearingBetween(baseline, location);
        }

        if (!Double.isNaN(bearing)) {
            invalidGpsBearingUpdates = 0;
            smoothedGpsBearing = smoothBearing(smoothedGpsBearing, bearing, 0.28);
            gpsDetectedBearing = smoothedGpsBearing;
            lastGpsBearingAccuracy = bearingAccuracy;
            if (gpsCompassView != null) {
                gpsCompassView.setDirectionAvailable(true);
                gpsCompassView.setAzimuth(smoothedGpsBearing);
            }
        } else {
            invalidGpsBearingUpdates++;
            if ((!location.hasSpeed() || location.getSpeed() < 0.8f) || invalidGpsBearingUpdates >= 3) {
                gpsDetectedBearing = null;
                lastGpsBearingAccuracy = Float.NaN;
                if (gpsCompassView != null) gpsCompassView.setDirectionAvailable(false);
            }
        }
        lastGpsLocation = new Location(location);
        updateGpsProgressStatus();
    }

    private Location findGpsBearingBaseline(Location current) {
        for (Location candidate : orientationRecentLocations) {
            if (candidate == current) continue;
            if (candidate.hasAccuracy() && candidate.getAccuracy() > 25f) continue;
            float required = Math.max(8f,
                    ((candidate.hasAccuracy() ? candidate.getAccuracy() : 6f)
                            + (current.hasAccuracy() ? current.getAccuracy() : 6f)) * 1.2f);
            if (candidate.distanceTo(current) >= required) return candidate;
        }
        return null;
    }

    private void captureOrientationPointA() {
        startOrientationPointAverage(true);
    }

    private void calculateOrientationPointB() {
        if (orientationPointA == null) {
            if (twoPointStatus != null) twoPointStatus.setText("Primero registra el punto A.");
            return;
        }
        startOrientationPointAverage(false);
    }

    private void startOrientationPointAverage(boolean forPointA) {
        orientationCompassMode = 2;
        savePrefs();
        applyOrientationModeToViews();
        if (!gpsCompassRunning) startGpsCompass();
        if (!hasLocationPermission()) return;
        if (orientationAverageRunning) {
            if (twoPointStatus != null) twoPointStatus.setText("Ya se está promediando un punto. Espera a que termine.");
            return;
        }
        orientationAverageRunning = true;
        orientationAverageForA = forPointA;
        orientationAverageSamples.clear();
        orientationAverageEndsAt = System.currentTimeMillis() + 10000L;
        if (twoPointStatus != null) twoPointStatus.setText("Promediando punto " + (forPointA ? "A" : "B")
                + " durante 10 segundos. Mantén el teléfono quieto y con cielo despejado.");
        gpsUiHandler.post(new Runnable() {
            @Override public void run() {
                if (!orientationAverageRunning) return;
                updateGpsProgressStatus();
                if (System.currentTimeMillis() >= orientationAverageEndsAt) finishOrientationPointAverage();
                else gpsUiHandler.postDelayed(this, 500L);
            }
        });
    }

    private void finishOrientationPointAverage() {
        orientationAverageRunning = false;
        Location averaged = averageLocations(orientationAverageSamples);
        orientationAverageSamples.clear();
        if (averaged == null) {
            if (twoPointStatus != null) twoPointStatus.setText("No hubo suficientes lecturas GPS válidas. Ve a un lugar despejado e inténtalo otra vez.");
            return;
        }
        if (orientationAverageForA) {
            orientationPointA = averaged;
            orientationPointB = null;
            if (viewOrientationMapButton != null) {
                viewOrientationMapButton.setEnabled(false);
                viewOrientationMapButton.setAlpha(0.45f);
            }
            float recommended = recommendedOrientationDistance(orientationPointA.getAccuracy(), orientationPointA.getAccuracy());
            if (twoPointStatus != null) twoPointStatus.setText(String.format(Locale.US,
                    "Punto A registrado: %.7f, %.7f\nPrecisión declarada: ±%.1f m. Camina en línea recta; distancia orientativa mínima: %.0f m.",
                    orientationPointA.getLatitude(), orientationPointA.getLongitude(), orientationPointA.getAccuracy(), recommended));
        } else {
            orientationPointB = averaged;
            calculateOrientationFromAtoB();
        }
    }

    private Location averageLocations(List<Location> samples) {
        if (samples == null || samples.size() < 3) return null;
        double sumW = 0.0, lat = 0.0, lon = 0.0, altitude = 0.0;
        int altitudeCount = 0;
        float accuracySum = 0f;
        for (Location l : samples) {
            float acc = l.hasAccuracy() ? Math.max(3f, l.getAccuracy()) : 12f;
            double w = 1.0 / (acc * acc);
            sumW += w;
            lat += l.getLatitude() * w;
            lon += l.getLongitude() * w;
            accuracySum += acc;
            if (l.hasAltitude()) { altitude += l.getAltitude(); altitudeCount++; }
        }
        if (sumW <= 0) return null;
        Location result = new Location(LocationManager.GPS_PROVIDER);
        result.setLatitude(lat / sumW);
        result.setLongitude(lon / sumW);
        if (altitudeCount > 0) result.setAltitude(altitude / altitudeCount);
        result.setAccuracy(accuracySum / samples.size());
        result.setTime(System.currentTimeMillis());
        return result;
    }

    private void calculateOrientationFromAtoB() {
        if (orientationPointA == null || orientationPointB == null) return;
        float distance = orientationPointA.distanceTo(orientationPointB);
        double bearing = bearingBetween(orientationPointA, orientationPointB);
        double combined = Math.hypot(orientationPointA.getAccuracy(), orientationPointB.getAccuracy());
        double uncertainty = Math.toDegrees(Math.atan2(combined, Math.max(0.1, distance)));
        float recommended = recommendedOrientationDistance(orientationPointA.getAccuracy(), orientationPointB.getAccuracy());
        if (selectedOrientationCompassView != null) {
            selectedOrientationCompassView.setDirectionAvailable(true);
            selectedOrientationCompassView.setAzimuth(bearing);
        }
        gpsDetectedBearing = bearing;
        String quality = uncertainty <= 5.0 ? "buena" : uncertainty <= 10.0 ? "media" : "baja";
        String advice = distance < recommended
                ? String.format(Locale.US, "\nContinúa hasta aproximadamente %.0f m para reducir el error angular.", recommended)
                : "\nSeparación suficiente para orientación aproximada de campo.";
        if (twoPointStatus != null) {
            twoPointStatus.setText("Azimut A → B: " + formatDms(bearing)
                    + "\nRumbo: " + rumbo(bearing)
                    + String.format(Locale.US, "\nDistancia: %.2f m · incertidumbre estimada ±%.1f° · calidad %s", distance, uncertainty, quality)
                    + advice);
        }
        if (viewOrientationMapButton != null) {
            viewOrientationMapButton.setEnabled(true);
            viewOrientationMapButton.setAlpha(1f);
        }
    }

    private float recommendedOrientationDistance(float accuracyA, float accuracyB) {
        double combined = Math.hypot(Math.max(3f, accuracyA), Math.max(3f, accuracyB));
        return (float) Math.max(30.0, Math.min(250.0, combined / Math.tan(Math.toRadians(5.0))));
    }

    private void openOrientationInMap() {
        if (orientationPointA == null || orientationPointB == null) {
            Toast.makeText(this, "Primero registra A y B.", Toast.LENGTH_SHORT).show();
            return;
        }
        android.content.Intent intent = new android.content.Intent(this, MapActivity.class);
        intent.putExtra("ab_a_lat", orientationPointA.getLatitude());
        intent.putExtra("ab_a_lon", orientationPointA.getLongitude());
        intent.putExtra("ab_a_acc", orientationPointA.getAccuracy());
        intent.putExtra("ab_b_lat", orientationPointB.getLatitude());
        intent.putExtra("ab_b_lon", orientationPointB.getLongitude());
        intent.putExtra("ab_b_acc", orientationPointB.getAccuracy());
        intent.putExtra("ab_bearing", bearingBetween(orientationPointA, orientationPointB));
        intent.putExtra("ab_distance", orientationPointA.distanceTo(orientationPointB));
        startActivity(intent);
    }

    private double bearingBetween(Location from, Location to) {
        double lat1 = Math.toRadians(from.getLatitude());
        double lat2 = Math.toRadians(to.getLatitude());
        double dLon = Math.toRadians(to.getLongitude() - from.getLongitude());
        double y = Math.sin(dLon) * Math.cos(lat2);
        double x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
        return normalizeBearing(Math.toDegrees(Math.atan2(y, x)));
    }

    private View azimuthBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("1. Azimut y rumbo"));
        azModeHint = small("¿Qué dato tienes? Azimut");
        azModeHint.setPadding(0, dp(6), 0, dp(2));
        box.addView(azModeHint);

        LinearLayout modeRow1 = new LinearLayout(this);
        modeRow1.setOrientation(LinearLayout.HORIZONTAL);
        modeAzBtn = smallModeBtn("Azimut", 0);
        modeRumboBtn = smallModeBtn("Rumbo", 1);
        modeRow1.addView(modeAzBtn, weightParams());
        modeRow1.addView(modeRumboBtn, weightParams());
        box.addView(modeRow1);

        LinearLayout modeRow2 = new LinearLayout(this);
        modeRow2.setOrientation(LinearLayout.HORIZONTAL);
        modeContraAzBtn = smallModeBtn("Contraazimut", 2);
        modeContraRumboBtn = smallModeBtn("Contrarumbo", 3);
        modeRow2.addView(modeContraAzBtn, weightParams());
        modeRow2.addView(modeContraRumboBtn, weightParams());
        box.addView(modeRow2);

        azInput = edit("Ejemplo: 150°00'00\"");
        trackAngleEdit(azInput);
        box.addView(azInput);
        box.addView(angleShortcutBar());
        setAzInputMode(0);

        Button calc = btn("Calcular");
        calc.setOnClickListener(v -> calculateAzimuth());
        box.addView(calc);

        box.addView(azimuthResultPanel());
        return box;
    }

    private Button smallModeBtn(String text, int mode) {
        Button b = btn(text);
        b.setTextSize(13);
        b.setOnClickListener(v -> setAzInputMode(mode));
        return b;
    }

    private void setAzInputMode(int mode) {
        azInputMode = mode;
        if (azModeHint != null) {
            String[] names = {"Azimut", "Rumbo", "Contraazimut", "Contrarumbo"};
            azModeHint.setText("¿Qué dato tienes? " + names[mode]);
        }
        if (azInput != null) {
            if (mode == 0) azInput.setHint("Ejemplo: 150°00'00\"");
            else if (mode == 1) azInput.setHint("Ejemplo: S 30°00'00\" E");
            else if (mode == 2) azInput.setHint("Ejemplo: 330°00'00\"");
            else azInput.setHint("Ejemplo: N 30°00'00\" W");
        }
        styleModeButton(modeAzBtn, mode == 0);
        styleModeButton(modeRumboBtn, mode == 1);
        styleModeButton(modeContraAzBtn, mode == 2);
        styleModeButton(modeContraRumboBtn, mode == 3);
    }

    private void styleModeButton(Button b, boolean active) {
        if (b == null) return;
        GradientDrawable gd = new GradientDrawable();
        gd.setCornerRadius(dp(18));
        gd.setColor(active ? borderColor : inputFillColor);
        gd.setStroke(dp(active ? 2 : 1), active ? borderColor : inputStrokeColor);
        b.setBackground(gd);
        b.setTextColor(active ? Color.WHITE : textColor);
    }

    private View azimuthResultPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout.LayoutParams panelLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        panelLp.setMargins(0, dp(10), 0, dp(8));
        panel.setLayoutParams(panelLp);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == THEME_LIGHT ? Color.rgb(248, 250, 255) : Color.rgb(11, 24, 38));
        bg.setStroke(dp(1), borderColor);
        bg.setCornerRadius(dp(14));
        panel.setBackground(bg);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        TextView title = tv("Resultado con 4 brújulas", 17, true);
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        azQuadrantChip = miniChip("Cuadrante: —", borderColor);
        head.addView(azQuadrantChip);
        panel.addView(head);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(compassItem("Azimut", 0), weightParams());
        row1.addView(compassItem("Rumbo", 1), weightParams());
        panel.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(compassItem("Contraazimut", 2), weightParams());
        row2.addView(compassItem("Contrarrumbo", 3), weightParams());
        panel.addView(row2);

        azDecimalLabel = compactInfoText("FORMATO DECIMAL\n—");
        panel.addView(azDecimalLabel);

        return panel;
    }

    private TextView miniChip(String text, int color) {
        TextView v = tv(text, 12, true);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(10), dp(5), dp(10), dp(5));
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(themeMode == THEME_LIGHT ? Color.rgb(240, 247, 255) : Color.rgb(12, 42, 28));
        gd.setStroke(dp(1), color);
        gd.setCornerRadius(dp(18));
        v.setBackground(gd);
        return v;
    }

    private TextView bigDirectionText(String text) {
        TextView v = compassResultChip("", "");
        v.setText(text);
        v.setTextSize(22);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(6), dp(12), dp(6), dp(12));
        return v;
    }

    private TextView compactInfoText(String text) {
        TextView v = compassResultChip("", "");
        v.setText(text);
        v.setTextSize(12);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(5), dp(7), dp(5), dp(7));
        return v;
    }

    private View quadrantReferencePanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(2), dp(6), dp(2), 0);
        panel.addView(small("Referencia rápida de cuadrantes"));

        LinearLayout r1 = new LinearLayout(this);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        r1.addView(quadrantCard("NE", "0° a 90°", "Rumbo: N θ E", Color.rgb(0, 184, 148)), weightParams());
        r1.addView(quadrantCard("SE", "90° a 180°", "Rumbo: S θ E", Color.rgb(0, 188, 212)), weightParams());
        panel.addView(r1);

        LinearLayout r2 = new LinearLayout(this);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        r2.addView(quadrantCard("SW", "180° a 270°", "Rumbo: S θ W", Color.rgb(255, 171, 0)), weightParams());
        r2.addView(quadrantCard("NW", "270° a 360°", "Rumbo: N θ W", Color.rgb(142, 68, 173)), weightParams());
        panel.addView(r2);
        return panel;
    }

    private View quadrantCard(String quadrant, String range, String formula, int color) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(8), dp(8), dp(8), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == THEME_LIGHT ? Color.WHITE : Color.rgb(14, 26, 39));
        bg.setStroke(dp(1), color);
        bg.setCornerRadius(dp(12));
        card.setBackground(bg);
        TextView title = tv(quadrant + "  " + range, 13, true);
        title.setTextColor(color);
        TextView body = tv(formula, 12, false);
        body.setGravity(Gravity.CENTER);
        card.addView(title);
        card.addView(body);
        return card;
    }

    private View compassItem(String title, int type) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(4), dp(8), dp(4), dp(8));

        CompassView cv = new CompassView(this);
        cv.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(245)));
        if (type == 0) compassAzView = cv;
        else if (type == 1) compassRumboView = cv;
        else if (type == 2) compassContraAzView = cv;
        else compassContraRumboView = cv;
        wrap.addView(cv);

        TextView t = compassResultChip(title, "—");
        if (type == 0) compassAzLabel = t;
        else if (type == 1) compassRumboLabel = t;
        else if (type == 2) compassContraAzLabel = t;
        else compassContraRumboLabel = t;
        wrap.addView(t);
        return wrap;
    }

    private TextView compassResultChip(String title, String value) {
        TextView v = tv(title.toUpperCase(Locale.US) + "\n" + value, 13, true);
        v.setGravity(Gravity.CENTER);
        v.setLineSpacing(0, 1.12f);
        v.setPadding(dp(6), dp(8), dp(6), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(dp(2), dp(6), dp(2), 0);
        v.setLayoutParams(lp);

        GradientDrawable gd = new GradientDrawable();
        gd.setColor(themeMode == THEME_LIGHT ? Color.rgb(248, 250, 255) : Color.rgb(16, 25, 38));
        gd.setCornerRadius(dp(10));
        gd.setStroke(dp(1), borderColor);
        v.setBackground(gd);
        return v;
    }

    private View coordBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("2. Distancia y coordenadas parciales"));
        box.addView(small("Calcula ΔEste y ΔNorte con azimut y distancia."));

        coordAzInput = edit("Azimut");
        trackAngleEdit(coordAzInput);
        distanceInput = edit("Distancia horizontal");
        distanceInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);

        box.addView(coordAzInput);
        box.addView(angleShortcutBar());
        box.addView(distanceInput);

        Button calc = btn("Calcular E/O/N/S");
        calc.setOnClickListener(v -> calculateCoordinateSingle());
        box.addView(calc);

        coordResult = resultBox("Resultado pendiente");
        box.addView(coordResult);
        return box;
    }

    private View distanceBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("3. Distancia, desnivel y pendiente"));
        box.addView(small("Calcula distancia, desnivel, pendiente y ángulo."));

        dhInput = edit("Distancia horizontal");
        diInput = edit("Distancia inclinada");
        angleInput = edit("Ángulo vertical");
        trackAngleEdit(angleInput);
        desnivelInput = edit("Desnivel / diferencia de cota");

        dhInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        diInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        desnivelInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);

        box.addView(dhInput);
        box.addView(diInput);
        box.addView(angleInput);
        box.addView(angleShortcutBar());
        box.addView(desnivelInput);

        Button calc = btn("Calcular distancia");
        calc.setOnClickListener(v -> calculateDistanceData());
        box.addView(calc);

        distanceCalcResult = resultBox("Resultado pendiente");
        box.addView(distanceCalcResult);
        return box;
    }

    private View miraPracticeBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("Práctica de lectura de mira tipo E"));
        box.addView(small("Simulación semi real de una mira topográfica de campo. Lee los tres hilos LS, LM y LI en el visor y escribe tus lecturas en metros."));

        miraPracticeView = new MiraPracticeView(this, borderColor, textColor, subTextColor, inputFillColor);
        LinearLayout.LayoutParams viewLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        viewLp.setMargins(0, dp(10), 0, dp(8));
        miraPracticeView.setLayoutParams(viewLp);
        box.addView(miraPracticeView);

        box.addView(small("Escribe tres decimales, por ejemplo 1.455. La comprobación acepta ±2 mm, valida LS > LM > LI y revisa que LM coincida aproximadamente con el promedio de LS y LI."));

        LinearLayout inputs = new LinearLayout(this);
        inputs.setOrientation(LinearLayout.HORIZONTAL);
        miraLsInput = edit("1.505");
        miraLmInput = edit("1.455");
        miraLiInput = edit("1.405");
        miraLsInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        miraLmInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        miraLiInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        miraLsInput.setSelectAllOnFocus(true);
        miraLmInput.setSelectAllOnFocus(true);
        miraLiInput.setSelectAllOnFocus(true);
        inputs.addView(labeledInput("LS superior", miraLsInput), weightParams());
        inputs.addView(labeledInput("LM medio", miraLmInput), weightParams());
        inputs.addView(labeledInput("LI inferior", miraLiInput), weightParams());
        box.addView(inputs);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button newExercise = btn("Nueva mira");
        newExercise.setOnClickListener(v -> newMiraExercise());
        buttons.addView(newExercise, weightParams());
        Button check = btn("Comprobar lectura");
        check.setOnClickListener(v -> checkMiraReading());
        buttons.addView(check, weightParams());
        box.addView(buttons);

        miraPracticeResult = resultBox("Ejercicio listo. Lee LS, LM y LI antes de comprobar.");
        box.addView(miraPracticeResult);
        return box;
    }

    private View twoHairDistanceMiniBlock() {
        LinearLayout box = card();
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(sectionTitle("4. Distancia por 2 hilos"));

        box.addView(small("Distancia = (hilo superior − hilo inferior) × 100."));

        LinearLayout inputs = new LinearLayout(this);
        inputs.setOrientation(LinearLayout.HORIZONTAL);
        hiloSupCalcInput = edit("Hilo superior");
        hiloInfCalcInput = edit("Hilo inferior");
        hiloDistValue = smallResultCell("—");
        hiloSupCalcInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        hiloInfCalcInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        inputs.addView(labeledInput("Hilo superior", hiloSupCalcInput), weightParams());
        inputs.addView(labeledInput("Hilo inferior", hiloInfCalcInput), weightParams());
        inputs.addView(labeledText("Distancia", hiloDistValue), weightParams());
        box.addView(inputs);

        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        Button calc = btn("Calcular 2 hilos");
        calc.setOnClickListener(v -> calculateTwoHairDistance());
        btns.addView(calc, weightParams());
        Button copy = btn("Copiar distancia");
        copy.setOnClickListener(v -> copyTwoHairDistance());
        btns.addView(copy, weightParams());
        Button paste = btn("Pegar en DIST.");
        paste.setOnClickListener(v -> pasteTwoHairDistanceIntoSelectedCell());
        btns.addView(paste, weightParams());
        box.addView(btns);

        hiloDistCalcResult = resultBox("Distancia calculada: —");
        box.addView(hiloDistCalcResult);
        return box;
    }

    private View partialTableBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("5. Poligonal cerrada"));
        box.addView(small("Calcula cierre, correcciones y coordenadas de los vértices."));

        box.addView(small("Coordenada inicial: usa 0.000 cuando no exista un valor dado."));
        LinearLayout xyRow = new LinearLayout(this);
        xyRow.setOrientation(LinearLayout.HORIZONTAL);
        polyX0Input = edit("X inicial");
        polyY0Input = edit("Y inicial");
        polyX0Input.setText("0.000");
        polyY0Input.setText("0.000");
        polyX0Input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        polyY0Input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        xyRow.addView(labeledInput("X inicial", polyX0Input), weightParams());
        xyRow.addView(labeledInput("Y inicial", polyY0Input), weightParams());
        box.addView(xyRow);
        LinearLayout tableOptions = new LinearLayout(this);
        tableOptions.setOrientation(LinearLayout.VERTICAL);
        tableOptions.setVisibility(View.GONE);
        tableOptions.addView(small("Selecciona una celda para cambiar su apariencia. El cálculo no se modifica."));
        tableOptions.addView(tableColorBar());
        tableOptions.addView(small("Selecciona una celda AZIMUT para usar los accesos rápidos."));
        tableOptions.addView(angleShortcutBar());
        Button tableOptionsButton = secondaryButton("⋮ Opciones de tabla");
        tableOptionsButton.setOnClickListener(v -> tableOptions.setVisibility(tableOptions.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
        box.addView(tableOptionsButton);
        box.addView(tableOptions);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        coordTable = new TableLayout(this);
        coordTable.setStretchAllColumns(false);
        coordTable.addView(headerRow("EST.", "P.V.", "AZIMUT", "DIST.", "RB", "E", "W", "N", "S", "E CORR.", "W CORR.", "N CORR.", "S CORR.", "X", "Y"));
        int coordCount = Math.max(6, getSharedPreferences(PREFS, MODE_PRIVATE).getInt("work_coord_count", 6));
        for (int i = 0; i < coordCount; i++) addCoordRow();
        hsv.addView(coordTable);
        box.addView(hsv);

        LinearLayout rowButtons = new LinearLayout(this);
        rowButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button add = btn("+ Fila");
        add.setOnClickListener(v -> addCoordRow());
        rowButtons.addView(add, weightParams());
        Button calc = btn("Calcular poligonal");
        calc.setOnClickListener(v -> calculateTable());
        rowButtons.addView(calc, weightParams());
        Button clear = btn("Limpiar");
        clear.setOnClickListener(v -> clearWorkAndRebuild());
        rowButtons.addView(clear, weightParams());
        box.addView(rowButtons);

        polyCheckResult = resultBox("Verificación pendiente");
        box.addView(polyCheckResult);
        polyProcedureResult = resultBox("Procedimiento pendiente. Aquí verás las fórmulas usadas, dónde va seno y dónde va coseno.");
        LinearLayout moreBtns = new LinearLayout(this);
        moreBtns.setOrientation(LinearLayout.HORIZONTAL);
        Button procBtn = btn("Ver procedimiento");
        procBtn.setOnClickListener(v -> showProcedureDialog("Procedimiento de poligonal", polyProcedureResult.getText()));
        moreBtns.addView(procBtn, weightParams());
        Button graphBtn = btn("Ver gráfico");
        graphBtn.setOnClickListener(v -> showPolyGraphDialog());
        moreBtns.addView(graphBtn, weightParams());
        box.addView(moreBtns);
        return box;
    }

    private View levelingBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("6. Nivelación: cota terreno y cota nivel"));
        box.addView(small("Calcula cotas con vistas atrás, intermedias y adelante."));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        levelTable = new TableLayout(this);
        levelTable.setStretchAllColumns(false);
        levelTable.addView(headerRowCompact("P.V.", "V. ATRÁS (+)", "V. INTERMEDIA (-)", "V. ADELANTE (-)", "COTA TERRENO", "COTA NIVEL"));
        int levelCount = Math.max(12, getSharedPreferences(PREFS, MODE_PRIVATE).getInt("work_level_count", 12));
        for (int i = 0; i < levelCount; i++) addLevelRow(i == 0 ? "BM1" : "", i == 0 ? "1000.000" : "");
        hsv.addView(levelTable);
        box.addView(hsv);

        LinearLayout rowButtons = new LinearLayout(this);
        rowButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button add = btn("+ Punto");
        add.setOnClickListener(v -> addLevelRow("", ""));
        rowButtons.addView(add, weightParams());
        Button calc = btn("Calcular cotas");
        calc.setOnClickListener(v -> calculateLeveling());
        rowButtons.addView(calc, weightParams());
        Button clear = btn("Limpiar");
        clear.setOnClickListener(v -> clearWorkAndRebuild());
        rowButtons.addView(clear, weightParams());
        box.addView(rowButtons);
        levelCheckResult = resultBox("Verificación pendiente");
        box.addView(levelCheckResult);
        return box;
    }


    private View stadiaLevelingBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("7. Nivelación con tres hilos"));
        box.addView(small("Calcula distancia y cotas mediante tres hilos."));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        stadiaTable = new TableLayout(this);
        stadiaTable.setStretchAllColumns(false);
        stadiaTable.addView(headerRow("P.V.", "TIPO", "H. INF.", "H. MEDIO", "H. SUP.", "DIST.", "COTA TERRENO", "COTA NIVEL"));
        int stadiaCount = Math.max(10, getSharedPreferences(PREFS, MODE_PRIVATE).getInt("work_stadia_count", 10));
        for (int i = 0; i < stadiaCount; i++) addStadiaRow(i == 0 ? "BM1" : "", i == 0 ? "A" : "");
        hsv.addView(stadiaTable);
        box.addView(hsv);

        box.addView(small("Tipo: A = atrás, I = intermedia, D = adelante."));

        LinearLayout rowButtons = new LinearLayout(this);
        rowButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button add = btn("+ Fila");
        add.setOnClickListener(v -> addStadiaRow("", ""));
        rowButtons.addView(add, weightParams());
        Button calc = btn("Calcular hilos");
        calc.setOnClickListener(v -> calculateStadiaLeveling());
        rowButtons.addView(calc, weightParams());
        Button clear = btn("Limpiar");
        clear.setOnClickListener(v -> clearWorkAndRebuild());
        rowButtons.addView(clear, weightParams());
        box.addView(rowButtons);
        stadiaCheckResult = resultBox("Verificación pendiente");
        box.addView(stadiaCheckResult);
        return box;
    }

    private void addCoordRow() {
        TableDataRow row = new TableDataRow();
        TableRow tr = new TableRow(this);
        row.est = cellEdit("", false);
        row.pv = cellEdit("", false);
        row.az = cellEdit("", false);
        trackAngleEdit(row.az);
        row.dist = cellEdit("", true);
        row.rumbo = cellText("—");
        row.sen = cellText("—");
        row.cos = cellText("—");
        row.este = cellText("—");
        row.oeste = cellText("—");
        row.norte = cellText("—");
        row.sur = cellText("—");
        row.eCorr = cellText("—");
        row.wCorr = cellText("—");
        row.nCorr = cellText("—");
        row.sCorr = cellText("—");
        row.x = cellText("—");
        row.y = cellText("—");
        applyDefaultPolyColors(row);
        tr.addView(row.est); tr.addView(row.pv); tr.addView(row.az); tr.addView(row.dist);
        tr.addView(row.rumbo); tr.addView(row.este); tr.addView(row.oeste); tr.addView(row.norte); tr.addView(row.sur);
        tr.addView(row.eCorr); tr.addView(row.wCorr); tr.addView(row.nCorr); tr.addView(row.sCorr); tr.addView(row.x); tr.addView(row.y);
        int visualRow = coordTable.getChildCount();
        for (int c = 0; c < tr.getChildCount(); c++) {
            registerColorCell(tr.getChildAt(c), coordTable, visualRow, c);
        }
        coordTable.addView(tr);
        tableRows.add(row);
    }

    private void addLevelRow(String label, String cotaDefault) {
        LevelDataRow row = new LevelDataRow();
        TableRow tr = new TableRow(this);
        row.pv = cellEditCompact(label, false);
        row.vAtras = cellEditCompact("", true);
        row.vIntermedia = cellEditCompact("", true);
        row.vAdelante = cellEditCompact("", true);
        row.cotaTerreno = cellEditCompact(cotaDefault, true);
        row.cotaNivel = cellTextCompact("—");
        tr.addView(row.pv); tr.addView(row.vAtras); tr.addView(row.vIntermedia); tr.addView(row.vAdelante); tr.addView(row.cotaTerreno); tr.addView(row.cotaNivel);
        levelTable.addView(tr);
        levelRows.add(row);
    }

    private void addStadiaRow(String label, String tipoDefault) {
        StadiaLevelRow row = new StadiaLevelRow();
        TableRow tr = new TableRow(this);
        row.pv = cellEdit(label, false);
        row.tipo = cellEdit(tipoDefault, false);
        row.hInf = cellEdit("", true);
        row.hMedio = cellEdit("", true);
        row.hSup = cellEdit("", true);
        row.distancia = cellText("—");
        row.cotaTerreno = cellEdit("", true);
        row.cotaNivel = cellText("—");
        tr.addView(row.pv); tr.addView(row.tipo); tr.addView(row.hInf); tr.addView(row.hMedio); tr.addView(row.hSup); tr.addView(row.distancia); tr.addView(row.cotaTerreno); tr.addView(row.cotaNivel);
        stadiaTable.addView(tr);
        stadiaRows.add(row);
    }

    private void calculateStadiaLeveling() {
        double currentHI = Double.NaN;
        double sumBack = 0;
        double sumForesight = 0;
        Double firstCota = null;
        Double lastCota = null;
        int calculated = 0;

        for (StadiaLevelRow row : stadiaRows) {
            String pv = row.pv.getText().toString().trim();
            String tipoText = row.tipo.getText().toString().trim();
            Double hInf = optNumber(row.hInf.getText().toString());
            Double hMedio = optNumber(row.hMedio.getText().toString());
            Double hSup = optNumber(row.hSup.getText().toString());
            Double cota = optNumber(row.cotaTerreno.getText().toString());

            boolean empty = pv.isEmpty() && tipoText.isEmpty() && hInf == null && hMedio == null && hSup == null && cota == null;
            if (empty) {
                row.distancia.setText("—");
                row.cotaNivel.setText("—");
                continue;
            }

            try {
                if (hInf != null && hSup != null) {
                    double dist = (hSup - hInf) * 100.0;
                    if (dist < 0) throw new IllegalArgumentException("bad stadia order");
                    row.distancia.setText(f3(dist));
                } else {
                    row.distancia.setText("");
                }

                if (hMedio == null) throw new IllegalArgumentException("missing middle hair");

                int tipo = parseViewType(tipoText, cota != null, currentHI);
                if (tipo == 1) {
                    if (cota == null && lastCota != null) cota = lastCota;
                    if (cota == null) throw new IllegalArgumentException("missing cota");
                    row.cotaTerreno.setText(f3(cota));
                    currentHI = cota + hMedio;
                    sumBack += hMedio;
                    row.cotaNivel.setText(f3(currentHI));
                    if (firstCota == null) firstCota = cota;
                    lastCota = cota;
                } else {
                    if (Double.isNaN(currentHI)) throw new IllegalArgumentException("no HI");
                    cota = currentHI - hMedio;
                    row.cotaTerreno.setText(f3(cota));
                    row.cotaNivel.setText("");
                    if (tipo == 3) sumForesight += hMedio;
                    if (firstCota == null) firstCota = cota;
                    lastCota = cota;
                }

                calculated++;
            } catch (Exception e) {
                row.distancia.setText(row.distancia.getText().toString().equals("—") ? "ERROR" : row.distancia.getText().toString());
                row.cotaNivel.setText("ERROR");
            }
        }

        String check = "Filas procesadas: " + calculated + "\n"
                + "Fórmula distancia: (H. superior - H. inferior) × 100\n"
                + "Σ Vista atrás: " + f3(sumBack) + "\n"
                + "Σ Vista adelante: " + f3(sumForesight);

        if (firstCota != null && lastCota != null) {
            double diffReadings = sumBack - sumForesight;
            double diffCotas = lastCota - firstCota;
            double error = diffReadings - diffCotas;
            check += "\nΣA - ΣD: " + f3(diffReadings)
                    + "\nCota final - Cota inicial: " + f3(diffCotas)
                    + "\nError de comprobación: " + f3(error);
        }

        stadiaCheckResult.setText(check);
        Toast.makeText(this, "Nivelación con hilos calculada", Toast.LENGTH_SHORT).show();
    }

    private int parseViewType(String tipoText, boolean hasKnownCota, double currentHI) {
        String t = tipoText.trim().toUpperCase(Locale.US);
        t = t.replace("Á", "A");
        if (t.isEmpty()) {
            if (Double.isNaN(currentHI) || hasKnownCota) return 1;
            return 2;
        }
        if (t.equals("A") || t.equals("VA") || t.contains("ATRAS")) return 1;
        if (t.equals("I") || t.equals("VI") || t.contains("INTER")) return 2;
        if (t.equals("D") || t.equals("F") || t.equals("FS") || t.equals("VAD") || t.contains("ADEL")) return 3;
        throw new IllegalArgumentException("bad view type");
    }


    private void calculateDistanceData() {
        try {
            Double dh = optNumber(dhInput.getText().toString());
            Double di = optNumber(diInput.getText().toString());
            Double angle = optAngle(angleInput.getText().toString());
            Double dn = optNumber(desnivelInput.getText().toString());

            double horizontal;
            double inclinada;
            double desnivel;
            double angulo;

            if (dh != null && dn != null) {
                horizontal = dh;
                desnivel = dn;
                inclinada = Math.sqrt(horizontal * horizontal + desnivel * desnivel);
                angulo = Math.toDegrees(Math.atan2(desnivel, horizontal));
            } else if (di != null && angle != null) {
                inclinada = di;
                angulo = angle;
                horizontal = inclinada * Math.cos(Math.toRadians(angulo));
                desnivel = inclinada * Math.sin(Math.toRadians(angulo));
            } else if (dh != null && angle != null) {
                horizontal = dh;
                angulo = angle;
                desnivel = horizontal * Math.tan(Math.toRadians(angulo));
                inclinada = Math.sqrt(horizontal * horizontal + desnivel * desnivel);
            } else if (di != null && dn != null) {
                inclinada = di;
                desnivel = dn;
                double inside = inclinada * inclinada - desnivel * desnivel;
                if (inside < 0) throw new IllegalArgumentException("invalid");
                horizontal = Math.sqrt(inside);
                angulo = Math.toDegrees(Math.asin(desnivel / inclinada));
            } else {
                showError("Faltan datos. Usa DH + desnivel, DI + ángulo, DH + ángulo, o DI + desnivel.");
                return;
            }

            if (Math.abs(horizontal) < 0.0000001) throw new IllegalArgumentException("zero horizontal");
            double pendiente = (desnivel / horizontal) * 100.0;

            distanceCalcResult.setText("Distancia horizontal: " + f3(horizontal) + "\n"
                    + "Distancia inclinada: " + f3(inclinada) + "\n"
                    + "Desnivel: " + f3(desnivel) + "\n"
                    + "Ángulo vertical: " + formatDms(angulo) + "\n"
                    + "Pendiente: " + f3(pendiente) + " %");
        } catch (Exception e) {
            showError("Revisa los datos. Ejemplo: DH 100 y desnivel 5, o DI 100 y ángulo 3°00'00\".");
        }
    }

    private void newMiraExercise() {
        if (miraPracticeView != null) miraPracticeView.newExercise();
        if (miraLsInput != null) miraLsInput.setText("");
        if (miraLmInput != null) miraLmInput.setText("");
        if (miraLiInput != null) miraLiInput.setText("");
        if (miraPracticeResult != null) {
            miraPracticeResult.setText("Nueva práctica cargada. Lee LS, LM y LI en el visor y pulsa Comprobar lectura.");
            miraPracticeResult.setBackground(inputBg(true));
            miraPracticeResult.setTextColor(textColor);
        }
    }

    private void checkMiraReading() {
        if (miraPracticeView == null || miraPracticeResult == null) return;
        try {
            double enteredLs = parseNumber(miraLsInput.getText().toString());
            double enteredLm = parseNumber(miraLmInput.getText().toString());
            double enteredLi = parseNumber(miraLiInput.getText().toString());

            if (!(enteredLs > enteredLm && enteredLm > enteredLi)) {
                setMiraPracticeResult(false,
                        "Lectura incorrecta. Debe cumplirse LS > LM > LI. Revisa el orden de los tres hilos.");
                return;
            }

            double targetLs = miraPracticeView.getUpperReading();
            double targetLm = miraPracticeView.getMiddleReading();
            double targetLi = miraPracticeView.getLowerReading();
            double tolerance = 0.002;

            double errLs = enteredLs - targetLs;
            double errLm = enteredLm - targetLm;
            double errLi = enteredLi - targetLi;
            boolean lsOk = Math.abs(errLs) <= tolerance;
            boolean lmOk = Math.abs(errLm) <= tolerance;
            boolean liOk = Math.abs(errLi) <= tolerance;
            boolean allOk = lsOk && lmOk && liOk;

            double targetDistance = Math.abs(targetLs - targetLi) * 100.0;
            double enteredDistance = Math.abs(enteredLs - enteredLi) * 100.0;
            double middleDifferenceMm = Math.abs(enteredLm - ((enteredLs + enteredLi) / 2.0)) * 1000.0;
            boolean middleCheckOk = middleDifferenceMm <= 3.0;

            String detail = miraLineResult("LS", enteredLs, targetLs, errLs, lsOk)
                    + "\n" + miraLineResult("LM", enteredLm, targetLm, errLm, lmOk)
                    + "\n" + miraLineResult("LI", enteredLi, targetLi, errLi, liOk);

            if (allOk) {
                setMiraPracticeResult(true,
                        "Lectura correcta dentro de ±2 mm.\n"
                                + detail + "\n"
                                + "Distancia por hilos: " + f3(enteredDistance) + " m\n"
                                + "Control LM ≈ (LS + LI) / 2: " + (middleCheckOk ? "correcto" : "revisar")
                                + " · diferencia " + f3(middleDifferenceMm) + " mm.");
            } else {
                setMiraPracticeResult(false,
                        "Todavía no coincide. Revisa cada hilo: \n"
                                + detail + "\n"
                                + "Respuesta correcta: LS " + f3(targetLs) + " m · LM " + f3(targetLm) + " m · LI " + f3(targetLi) + " m\n"
                                + "Distancia correcta: " + f3(targetDistance) + " m");
            }
        } catch (Exception e) {
            setMiraPracticeResult(false,
                    "Completa LS, LM y LI con números válidos en metros. Ejemplo: 1.455");
        }
    }

    private String signedMillimeters(double errorMeters) {
        double mm = errorMeters * 1000.0;
        return String.format(Locale.US, "%+.1f mm", mm);
    }

    private String miraLineResult(String label, double entered, double target, double error, boolean ok) {
        return (ok ? "✓ " : "✗ ") + label + ": " + f3(entered) + " m"
                + " · correcto " + f3(target) + " m"
                + " · error " + signedMillimeters(error);
    }

    private void setMiraPracticeResult(boolean success, String message) {
        if (miraPracticeResult == null) return;
        miraPracticeResult.setText(message);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(9));
        if (success) {
            bg.setColor(themeMode == THEME_LIGHT ? Color.rgb(236, 249, 241) : Color.rgb(9, 50, 42));
            bg.setStroke(dp(1), Color.rgb(0, 184, 105));
        } else {
            bg.setColor(themeMode == THEME_LIGHT ? Color.rgb(255, 244, 235) : Color.rgb(65, 37, 18));
            bg.setStroke(dp(1), Color.rgb(255, 152, 0));
        }
        miraPracticeResult.setBackground(bg);
        miraPracticeResult.setTextColor(textColor);
    }

    private void calculateTwoHairDistance() {
        try {
            double sup = parseNumber(hiloSupCalcInput.getText().toString());
            double inf = parseNumber(hiloInfCalcInput.getText().toString());
            double dist = Math.abs(sup - inf) * 100.0;
            if (hiloDistValue != null) hiloDistValue.setText(f3(dist));
            hiloDistCalcResult.setText("Distancia calculada: " + f3(dist) + " m\n"
                    + "Operación: |" + f3(sup) + " - " + f3(inf) + "| × 100");
        } catch (Exception e) {
            if (hiloDistValue != null) hiloDistValue.setText("—");
            hiloDistCalcResult.setText("Distancia calculada: —\nRevisa los 2 hilos. Escribe números válidos.");
        }
    }

    private Double getTwoHairDistanceValue() {
        try {
            double sup = parseNumber(hiloSupCalcInput.getText().toString());
            double inf = parseNumber(hiloInfCalcInput.getText().toString());
            return Math.abs(sup - inf) * 100.0;
        } catch (Exception e) {
            return null;
        }
    }

    private void copyTwoHairDistance() {
        Double dist = getTwoHairDistanceValue();
        if (dist == null) {
            showError("Primero calcula una distancia válida con los 2 hilos.");
            return;
        }
        if (hiloDistValue != null) hiloDistValue.setText(f3(dist));
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("distancia", f3(dist)));
            Toast.makeText(this, "Distancia copiada: " + f3(dist), Toast.LENGTH_SHORT).show();
        }
    }

    private void pasteTwoHairDistanceIntoSelectedCell() {
        Double dist = getTwoHairDistanceValue();
        if (dist == null) {
            showError("Primero calcula una distancia válida con los 2 hilos.");
            return;
        }
        if (selectedDistCell == null) {
            showError("Primero toca una celda de DIST. en la poligonal.");
            return;
        }
        if (hiloDistValue != null) hiloDistValue.setText(f3(dist));
        selectedDistCell.setText(f3(dist));
        selectedDistCell.requestFocus();
        selectedDistCell.setSelection(selectedDistCell.getText().length());
        Toast.makeText(this, "Distancia pegada en DIST.", Toast.LENGTH_SHORT).show();
    }

    private void calculateLeveling() {
        double currentHI = Double.NaN;
        double sumBack = 0;
        double sumForesight = 0;
        Double firstCota = null;
        Double lastCota = null;
        int calculated = 0;

        for (LevelDataRow row : levelRows) {
            String pv = row.pv.getText().toString().trim();
            Double va = optNumber(row.vAtras.getText().toString());
            Double vi = optNumber(row.vIntermedia.getText().toString());
            Double vad = optNumber(row.vAdelante.getText().toString());
            Double cota = optNumber(row.cotaTerreno.getText().toString());

            boolean empty = pv.isEmpty() && va == null && vi == null && vad == null && cota == null;
            if (empty) {
                row.cotaNivel.setText("—");
                continue;
            }

            try {
                if (cota == null && !Double.isNaN(currentHI)) {
                    if (vi != null) cota = currentHI - vi;
                    else if (vad != null) cota = currentHI - vad;
                }

                if (cota != null) {
                    row.cotaTerreno.setText(f3(cota));
                    if (firstCota == null) firstCota = cota;
                    lastCota = cota;
                }

                if (vad != null) sumForesight += vad;
                if (va != null) {
                    if (cota == null) throw new IllegalArgumentException("missing cota");
                    sumBack += va;
                    currentHI = cota + va;
                    row.cotaNivel.setText(f3(currentHI));
                } else {
                    row.cotaNivel.setText(vi != null || vad != null ? "" : "—");
                }
                calculated++;
            } catch (Exception e) {
                row.cotaNivel.setText("ERROR");
            }
        }

        String check = "Filas procesadas: " + calculated + "\n"
                + "Σ Vista atrás: " + f3(sumBack) + "\n"
                + "Σ Vista adelante: " + f3(sumForesight);
        if (firstCota != null && lastCota != null) {
            double diffReadings = sumBack - sumForesight;
            double diffCotas = lastCota - firstCota;
            double error = diffReadings - diffCotas;
            check += "\nΣVA - ΣVAdelante: " + f3(diffReadings)
                    + "\nCota final - Cota inicial: " + f3(diffCotas)
                    + "\nError de comprobación: " + f3(error);
        }
        levelCheckResult.setText(check);
        Toast.makeText(this, "Nivelación calculada", Toast.LENGTH_SHORT).show();
    }

    private void calculateAzimuth() {
        try {
            String raw = azInput.getText().toString().trim();
            double az;
            if (azInputMode == 0) {
                az = normalize(parseAngle(raw));
            } else if (azInputMode == 1) {
                az = normalize(parseRumbo(raw));
            } else if (azInputMode == 2) {
                double contraAz = normalize(parseAngle(raw));
                az = contraAzimuth(contraAz);
            } else {
                double contraAz = normalize(parseRumbo(raw));
                az = contraAzimuth(contraAz);
            }
            double contra = contraAzimuth(az);
            if (compassAzView != null) compassAzView.setAzimuth(az);
            if (compassRumboView != null) compassRumboView.setAzimuth(az);
            if (compassContraAzView != null) compassContraAzView.setAzimuth(contra);
            if (compassContraRumboView != null) compassContraRumboView.setAzimuth(contra);
            if (compassAzLabel != null) compassAzLabel.setText("AZIMUT\n" + formatDms(az));
            if (compassRumboLabel != null) compassRumboLabel.setText("RUMBO\n" + rumbo(az));
            if (compassContraAzLabel != null) compassContraAzLabel.setText("CONTRAAZIMUT\n" + formatDms(contra));
            if (compassContraRumboLabel != null) compassContraRumboLabel.setText("CONTRARUMBO\n" + rumbo(contra));
            if (azQuadrantChip != null) azQuadrantChip.setText("Cuadrante: " + quadrantLabel(az));
            if (azDecimalLabel != null) azDecimalLabel.setText("FORMATO DECIMAL\n" + rumboDecimal(az));
            if (azExplainLabel != null) azExplainLabel.setText(azimuthStudyText(az));
            if (compassCaption != null) compassCaption.setText(azimuthStudyText(az));
        } catch (Exception e) {
            if (azInputMode == 0 || azInputMode == 2) {
                showError("Revisa el dato angular. Ejemplo correcto: 150°00'00\"");
            } else {
                showError("Revisa el rumbo. Ejemplo correcto: N 30°00'00\" W");
            }
        }
    }

    private void calculateCoordinateSingle() {
        try {
            double az = normalize(parseAngle(coordAzInput.getText().toString()));
            double distance = parseNumber(distanceInput.getText().toString());
            CoordinateResult r = coordinateResult(az, distance);
            coordResult.setText(coordinateOutput(az, distance, r));
        } catch (Exception e) {
            showError("Revisa azimut y distancia. Ejemplo: azimut 326°30'00\" y distancia 75.00");
        }
    }

    private void calculateTable() {
        ArrayList<TableDataRow> validRows = new ArrayList<>();
        ArrayList<Double> distances = new ArrayList<>();
        ArrayList<Double> azimuths = new ArrayList<>();
        ArrayList<Double> dxs = new ArrayList<>();
        ArrayList<Double> dys = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();
        ArrayList<String> estLabels = new ArrayList<>();
        ArrayList<String> pvLabels = new ArrayList<>();
        double sumDx = 0;
        double sumDy = 0;
        double perimeter = 0;
        int ok = 0;
        int referenceRows = 0;
        String lastEst = "";

        for (TableDataRow row : tableRows) {
            String azText = row.az.getText().toString().trim();
            String distText = row.dist.getText().toString().trim();
            String estText = row.est.getText().toString().trim();
            String pvText = row.pv.getText().toString().trim();
            if (!estText.isEmpty()) lastEst = estText;
            String effectiveEst = estText.isEmpty() ? lastEst : estText;

            if (azText.isEmpty() && distText.isEmpty() && estText.isEmpty() && pvText.isEmpty()) {
                blankPolyRow(row);
                continue;
            }

            try {
                double az = normalize(parseAngle(azText));
                row.rumbo.setText(rumbo(az));

                if (distText.isEmpty()) {
                    blankPolyNumbers(row);
                    referenceRows++;
                    continue;
                }

                double distance = parseNumber(distText);
                CoordinateResult r = coordinateResult(az, distance);

                row.sen.setText(f6(r.sen));
                row.cos.setText(f6(r.cos));
                setDirection(row.este, row.oeste, r.dx);
                setDirection(row.norte, row.sur, r.dy);

                blankPolyCorrections(row);

                validRows.add(row);
                distances.add(distance);
                azimuths.add(az);
                dxs.add(r.dx);
                dys.add(r.dy);
                labels.add((effectiveEst.isEmpty() ? "?" : effectiveEst) + " - " + (pvText.isEmpty() ? "?" : pvText));
                estLabels.add(effectiveEst);
                pvLabels.add(pvText);

                sumDx += r.dx;
                sumDy += r.dy;
                perimeter += Math.abs(distance);
                ok++;
            } catch (Exception e) {
                row.rumbo.setText("ERROR");
                blankPolyNumbers(row);
            }
        }

        if (validRows.isEmpty() || perimeter == 0) {
            if (polyCheckResult != null) polyCheckResult.setText("Agrega azimut y distancia para calcular la poligonal.");
            if (polyProcedureResult != null) {
                polyProcedureResult.setText("Procedimiento pendiente. Primero llena una fila con azimut y distancia.");
            }
            Toast.makeText(this, "No hay filas válidas", Toast.LENGTH_SHORT).show();
            return;
        }

        SpannableStringBuilder procedure = buildPolyProcedureHeader();
        for (int i = 0; i < validRows.size(); i++) {
            appendPartialProcedureRow(procedure, labels.get(i), azimuths.get(i), distances.get(i), dxs.get(i), dys.get(i), i + 1);
        }

        boolean closedChain = isClosedPolygonChain(estLabels, pvLabels);
        if (validRows.size() < 3 || !closedChain) {
            for (TableDataRow row : validRows) {
                blankPolyCorrections(row);
            }
            String check = "Parciales calculadas: " + ok
                    + "\nFilas solo referencia: " + referenceRows
                    + "\nPerímetro ingresado: " + f3(perimeter)
                    + "\nFaltan lados o la secuencia no cierra."
                    + "\nPara compensar debe ser: A-B, B-C, C-D... y terminar regresando al inicio.";
            if (polyCheckResult != null) polyCheckResult.setText(check);
            appendPlain(procedure, "\nPara corregidas, X/Y y gráfico completo, llena una poligonal cerrada: el último P.V. debe volver al primer EST.\n");
            if (polyProcedureResult != null) polyProcedureResult.setText(procedure);
            Toast.makeText(this, "Parciales calculadas. La poligonal todavía no cierra.", Toast.LENGTH_SHORT).show();
            return;
        }

        Double x0 = optNumber(polyX0Input.getText().toString());
        Double y0 = optNumber(polyY0Input.getText().toString());
        double x = x0 != null ? x0 : 0;
        double y = y0 != null ? y0 : 0;
        double startX = x;
        double startY = y;
        ArrayList<Double> correctedXs = new ArrayList<>();
        ArrayList<Double> correctedYs = new ArrayList<>();
        correctedXs.add(startX);
        correctedYs.add(startY);

        for (int i = 0; i < validRows.size(); i++) {
            TableDataRow row = validRows.get(i);
            double distance = distances.get(i);
            double dx = dxs.get(i);
            double dy = dys.get(i);
            double corrX = -sumDx * (Math.abs(distance) / perimeter);
            double corrY = -sumDy * (Math.abs(distance) / perimeter);
            double cdx = dx + corrX;
            double cdy = dy + corrY;

            setDirection(row.eCorr, row.wCorr, cdx);
            setDirection(row.nCorr, row.sCorr, cdy);
            x += cdx;
            y += cdy;
            row.x.setText(f3(x));
            row.y.setText(f3(y));
            correctedXs.add(x);
            correctedYs.add(y);

            appendCorrectionProcedureRow(procedure, labels.get(i), corrX, corrY, cdx, cdy, x, y);
        }

        double closeError = Math.sqrt(sumDx * sumDx + sumDy * sumDy);
        double precision = closeError == 0 ? 0 : perimeter / closeError;
        double signedArea = signedPolygonArea(correctedXs, correctedYs);
        double area = Math.abs(signedArea);
        String orientation = signedArea < 0 ? "horario" : signedArea > 0 ? "antihorario" : "sin orientación";
        String check = "Filas calculadas: " + ok
                + "\nFilas solo referencia: " + referenceRows
                + "\nPerímetro: " + f3(perimeter)
                + "\nError X: " + f3(sumDx)
                + "\nError Y: " + f3(sumDy)
                + "\nError de cierre: " + f3(closeError)
                + "\nPrecisión aprox.: 1/" + (precision == 0 ? "∞" : String.format(Locale.US, "%.0f", precision))
                + "\nÁrea: " + f3(area) + " m²  (" + String.format(Locale.US, "%.4f", area / 10000.0) + " ha)"
                + "\nSentido: " + orientation
                + "\nInicio: X " + f3(startX) + "  Y " + f3(startY)
                + "\nFinal corregido: X " + f3(x) + "  Y " + f3(y);
        if (polyCheckResult != null) polyCheckResult.setText(check);
        appendProcedureSummary(procedure, sumDx, sumDy, perimeter, closeError);
        if (polyProcedureResult != null) polyProcedureResult.setText(procedure);
        Toast.makeText(this, "Poligonal calculada: " + ok + " lados", Toast.LENGTH_SHORT).show();
    }

    private double signedPolygonArea(List<Double> xs, List<Double> ys) {
        if (xs == null || ys == null || xs.size() < 4 || xs.size() != ys.size()) return 0;
        double sum = 0;
        for (int i = 0; i < xs.size() - 1; i++) {
            sum += xs.get(i) * ys.get(i + 1) - xs.get(i + 1) * ys.get(i);
        }
        if (Math.abs(xs.get(xs.size() - 1) - xs.get(0)) > 0.000001
                || Math.abs(ys.get(ys.size() - 1) - ys.get(0)) > 0.000001) {
            int last = xs.size() - 1;
            sum += xs.get(last) * ys.get(0) - xs.get(0) * ys.get(last);
        }
        return sum / 2.0;
    }

    private void setDirection(TextView positive, TextView negative, double value) {
        double v = cleanZero(value);
        if (v > 0) {
            positive.setText(f3(v));
            negative.setText("—");
        } else if (v < 0) {
            positive.setText("—");
            negative.setText(f3(-v));
        } else {
            positive.setText("0.000");
            negative.setText("—");
        }
    }

    private void blankPolyRow(TableDataRow row) {
        row.rumbo.setText("—");
        blankPolyNumbers(row);
    }

    private void blankPolyNumbers(TableDataRow row) {
        row.sen.setText("—"); row.cos.setText("—");
        row.este.setText("—"); row.oeste.setText("—"); row.norte.setText("—"); row.sur.setText("—");
        blankPolyCorrections(row);
    }

    private void blankPolyCorrections(TableDataRow row) {
        row.eCorr.setText("—"); row.wCorr.setText("—"); row.nCorr.setText("—"); row.sCorr.setText("—");
        row.x.setText("—"); row.y.setText("—");
    }

    private boolean isClosedPolygonChain(List<String> ests, List<String> pvs) {
        if (ests == null || pvs == null || ests.size() < 3 || ests.size() != pvs.size()) return false;
        String first = normalizeLabel(ests.get(0));
        String last = normalizeLabel(pvs.get(pvs.size() - 1));
        if (first.isEmpty() || last.isEmpty() || !first.equals(last)) return false;
        for (int i = 1; i < ests.size(); i++) {
            String prevPv = normalizeLabel(pvs.get(i - 1));
            String currentEst = normalizeLabel(ests.get(i));
            if (prevPv.isEmpty() || currentEst.isEmpty() || !prevPv.equals(currentEst)) return false;
        }
        return true;
    }

    private String normalizeLabel(String value) {
        return value == null ? "" : value.trim().toUpperCase(Locale.US);
    }

    private CoordinateResult coordinateResult(double az, double distance) {
        double rad = Math.toRadians(az);
        double sen = Math.sin(rad);
        double cos = Math.cos(rad);
        double dx = distance * sen;
        double dy = distance * cos;
        CoordinateResult r = new CoordinateResult();
        r.sen = sen;
        r.cos = cos;
        r.dx = dx;
        r.dy = dy;
        r.este = dx > 0 ? dx : 0;
        r.oeste = dx < 0 ? -dx : 0;
        r.norte = dy > 0 ? dy : 0;
        r.sur = dy < 0 ? -dy : 0;
        return r;
    }

    private String coordinateOutput(double az, double distance, CoordinateResult r) {
        return "Azimut: " + formatDms(az) + "\n"
                + "Rumbo: " + rumbo(az) + "\n"
                + "Distancia: " + f3(distance) + "\n"
                + "Seno: " + f6(r.sen) + "\n"
                + "Coseno: " + f6(r.cos) + "\n"
                + "ΔX = D × sen(Az): " + f3(r.dx) + "\n"
                + "ΔY = D × cos(Az): " + f3(r.dy) + "\n"
                + "Este: " + f3(r.este) + "   Oeste: " + f3(r.oeste) + "\n"
                + "Norte: " + f3(r.norte) + "   Sur: " + f3(r.sur);
    }

    private double parseAngle(String value) {
        String s = value.trim().replace(',', '.');
        if (s.isEmpty()) throw new IllegalArgumentException("empty");

        Matcher m = Pattern.compile("-?\\d+(?:\\.\\d+)?").matcher(s);
        ArrayList<Double> nums = new ArrayList<>();
        while (m.find()) nums.add(Double.parseDouble(m.group()));
        if (nums.isEmpty()) throw new IllegalArgumentException("no number");

        double deg = nums.get(0);
        double sign = deg < 0 ? -1 : 1;
        deg = Math.abs(deg);
        double min = nums.size() > 1 ? Math.abs(nums.get(1)) : 0;
        double sec = nums.size() > 2 ? Math.abs(nums.get(2)) : 0;

        if (nums.size() == 1 && !s.contains("°") && !s.contains("º") && !s.contains("'") && !s.contains("\"") && !s.contains(" ")) {
            String clean = s.startsWith("-") ? s.substring(1) : s;
            if (clean.matches("\\d+\\.\\d{2}")) {
                String[] parts = clean.split("\\.");
                double d = Double.parseDouble(parts[0]);
                double mm = Double.parseDouble(parts[1]);
                if (mm < 60) return sign * (d + mm / 60.0);
            }
            if (clean.matches("\\d+\\.\\d{4}")) {
                String[] parts = clean.split("\\.");
                double d = Double.parseDouble(parts[0]);
                double mm = Double.parseDouble(parts[1].substring(0, 2));
                double ss = Double.parseDouble(parts[1].substring(2, 4));
                if (mm < 60 && ss < 60) return sign * (d + mm / 60.0 + ss / 3600.0);
            }
            return nums.get(0);
        }
        return sign * (deg + min / 60.0 + sec / 3600.0);
    }

    private Double optNumber(String value) {
        String s = value.trim();
        if (s.isEmpty() || s.equals("—")) return null;
        return parseNumber(s);
    }

    private Double optAngle(String value) {
        String s = value.trim();
        if (s.isEmpty() || s.equals("—")) return null;
        return parseAngle(s);
    }

    private double parseRumbo(String value) {
        String s = value.trim().toUpperCase(Locale.US).replace("º", "°").replace("O", "W");
        if (s.isEmpty()) throw new IllegalArgumentException("empty");
        s = s.replaceAll("\\s+", " ").trim();
        char first = 0;
        char last = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == 'N' || c == 'S') { first = c; break; }
        }
        for (int i = s.length() - 1; i >= 0; i--) {
            char c = s.charAt(i);
            if (c == 'E' || c == 'W') { last = c; break; }
        }
        if (first == 0 || last == 0) throw new IllegalArgumentException("bad rumbo");
        int i1 = s.indexOf(first);
        int i2 = s.lastIndexOf(last);
        if (i2 <= i1) throw new IllegalArgumentException("bad rumbo");
        String middle = s.substring(i1 + 1, i2).trim();
        double ang = parseAngle(middle);
        if (ang < 0 || ang > 90) throw new IllegalArgumentException("angle out of range");
        if (first == 'N' && last == 'E') return ang;
        if (first == 'S' && last == 'E') return 180.0 - ang;
        if (first == 'S' && last == 'W') return 180.0 + ang;
        return 360.0 - ang;
    }

    private double parseNumber(String value) {
        String s = value.trim().replace(',', '.');
        if (s.isEmpty()) throw new IllegalArgumentException("empty");
        return Double.parseDouble(s);
    }

    private double normalize(double angle) {
        double a = angle % 360.0;
        if (a < 0) a += 360.0;
        if (Math.abs(a - 360.0) < 0.0000001) a = 0;
        return a;
    }

    private double contraAzimuth(double az) {
        return normalize(az + 180.0);
    }

    private String rumbo(double az) {
        double a = normalize(az);
        if (near(a, 0) || near(a, 360)) return "N";
        if (near(a, 90)) return "E";
        if (near(a, 180)) return "S";
        if (near(a, 270)) return "W";
        if (a > 0 && a < 90) return "N " + formatDms(a) + " E";
        if (a > 90 && a < 180) return "S " + formatDms(180 - a) + " E";
        if (a > 180 && a < 270) return "S " + formatDms(a - 180) + " W";
        return "N " + formatDms(360 - a) + " W";
    }

    private double rumboAngle(double az) {
        double a = normalize(az);
        if (a <= 90) return a;
        if (a <= 180) return 180.0 - a;
        if (a <= 270) return a - 180.0;
        return 360.0 - a;
    }

    private String quadrantLabel(double az) {
        double a = normalize(az);
        if (near(a, 0) || near(a, 90) || near(a, 180) || near(a, 270) || near(a, 360)) {
            return "Eje cardinal";
        }
        if (a > 0 && a < 90) return "NE";
        if (a > 90 && a < 180) return "SE";
        if (a > 180 && a < 270) return "SW";
        return "NW";
    }

    private String rumboDecimal(double az) {
        double a = normalize(az);
        if (near(a, 0) || near(a, 360)) return "N / 0.0000°";
        if (near(a, 90)) return "E / 90.0000°";
        if (near(a, 180)) return "S / 180.0000°";
        if (near(a, 270)) return "W / 270.0000°";
        double rb = rumboAngle(a);
        if (a > 0 && a < 90) return String.format(Locale.US, "N %.4f° E", rb);
        if (a > 90 && a < 180) return String.format(Locale.US, "S %.4f° E", rb);
        if (a > 180 && a < 270) return String.format(Locale.US, "S %.4f° W", rb);
        return String.format(Locale.US, "N %.4f° W", rb);
    }

    private String azimuthStudyText(double az) {
        double a = normalize(az);
        String azTxt = formatDms(a);
        if (near(a, 0) || near(a, 360)) return "Explicación: azimut 0° está sobre el Norte. Rumbo = N.";
        if (near(a, 90)) return "Explicación: azimut 90° está sobre el Este. Rumbo = E.";
        if (near(a, 180)) return "Explicación: azimut 180° está sobre el Sur. Rumbo = S.";
        if (near(a, 270)) return "Explicación: azimut 270° está sobre el Oeste. Rumbo = W.";
        double rb = rumboAngle(a);
        if (a > 0 && a < 90) {
            return "Explicación: " + azTxt + " está en NE (0° a 90°). El rumbo conserva el ángulo: N " + formatDms(rb) + " E.";
        }
        if (a > 90 && a < 180) {
            return "Explicación: " + azTxt + " está en SE. Se calcula 180° - azimut = " + formatDms(rb) + ". Rumbo: S " + formatDms(rb) + " E.";
        }
        if (a > 180 && a < 270) {
            return "Explicación: " + azTxt + " está en SW. Se calcula azimut - 180° = " + formatDms(rb) + ". Rumbo: S " + formatDms(rb) + " W.";
        }
        return "Explicación: " + azTxt + " está en NW. Se calcula 360° - azimut = " + formatDms(rb) + ". Rumbo: N " + formatDms(rb) + " W.";
    }

    private boolean near(double a, double b) {
        return Math.abs(a - b) < 0.0000001;
    }

    private String formatDms(double angle) {
        double a = Math.abs(angle);
        int deg = (int) Math.floor(a);
        double minFloat = (a - deg) * 60.0;
        int min = (int) Math.floor(minFloat);
        double secFloat = (minFloat - min) * 60.0;
        int sec = (int) Math.round(secFloat);
        if (sec == 60) { sec = 0; min++; }
        if (min == 60) { min = 0; deg++; }
        return String.format(Locale.US, "%02d°%02d'%02d\"", deg, min, sec);
    }

    private String f3(double v) {
        return String.format(Locale.US, "%.3f", cleanZero(v));
    }

    private String f6(double v) {
        return String.format(Locale.US, "%.6f", cleanZero(v));
    }

    private double cleanZero(double v) {
        return Math.abs(v) < 0.0000000001 ? 0 : v;
    }

    private void showError(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    private View collapsibleCard(LinearLayout box, String iconText, String titleText, boolean open) {
        if (box.getChildCount() > 0) box.removeViewAt(0); // El título interno se reemplaza por una cabecera plegable.

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        while (box.getChildCount() > 0) {
            View child = box.getChildAt(0);
            box.removeViewAt(0);
            body.addView(child);
        }
        body.setVisibility(open ? View.VISIBLE : View.GONE);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(2), dp(2), dp(2), dp(8));

        TextView icon = tv(iconText, 19, true);
        icon.setTextColor(borderColor);
        icon.setGravity(Gravity.CENTER);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setColor(withAlpha(borderColor, themeMode == THEME_LIGHT ? 28 : 42));
        iconBg.setCornerRadius(dp(12));
        icon.setBackground(iconBg);
        header.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(42)));

        TextView title = tv(titleText, 18, true);
        title.setPadding(dp(10), 0, 0, 0);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView arrow = tv(open ? "⌄" : "›", 28, true);
        arrow.setTextColor(subTextColor);
        arrow.setGravity(Gravity.CENTER);
        header.addView(arrow, new LinearLayout.LayoutParams(dp(42), dp(42)));

        SectionState state = new SectionState(body, arrow);
        box.setTag(state);
        header.setOnClickListener(v -> setSectionOpen(box, body.getVisibility() != View.VISIBLE));
        box.addView(header);
        box.addView(body);
        return box;
    }

    private View quickNavigation(ScrollView scroll, String[] labels, View[] sections) {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(10));
        hsv.setLayoutParams(lp);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(2), 0, dp(2));
        int count = Math.min(labels.length, sections.length);
        for (int i = 0; i < count; i++) {
            final View section = sections[i];
            Button chip = secondaryButton(labels[i]);
            chip.setTextSize(12);
            LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42));
            chipLp.setMargins(dp(3), 0, dp(3), 0);
            chip.setLayoutParams(chipLp);
            chip.setOnClickListener(v -> {
                setSectionOpen(section, true);
                scroll.post(() -> scroll.smoothScrollTo(0, Math.max(0, section.getTop() - dp(6))));
            });
            row.addView(chip);
        }
        hsv.addView(row);
        hsv.post(() -> hsv.scrollTo(0, 0));
        return hsv;
    }

    private void setSectionOpen(View section, boolean open) {
        Object tag = section.getTag();
        if (!(tag instanceof SectionState)) return;
        SectionState state = (SectionState) tag;
        boolean wasOpen = state.body.getVisibility() == View.VISIBLE;
        state.body.setVisibility(open ? View.VISIBLE : View.GONE);
        state.arrow.setText(open ? "⌄" : "›");
        if (open && !wasOpen && section == miraPracticeSection) newMiraExercise();
    }

    private Button secondaryButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextColor(textColor);
        button.setTextSize(13);
        button.setPadding(dp(8), dp(7), dp(8), dp(7));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(inputFillColor);
        bg.setCornerRadius(dp(11));
        bg.setStroke(dp(1), borderColor);
        button.setBackground(bg);
        return button;
    }

    private int withAlpha(int color, int alpha) {
        return Color.argb(Math.max(0, Math.min(255, alpha)), Color.red(color), Color.green(color), Color.blue(color));
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, 0, 0, dp(12));
        box.setLayoutParams(lp);

        GradientDrawable gd = new GradientDrawable();
        gd.setColor(cardColor);
        gd.setCornerRadius(dp(14));
        gd.setStroke(dp(1), inputStrokeColor);
        box.setBackground(gd);
        return box;
    }

    private TextView sectionTitle(String text) {
        TextView v = tv(text, 20, true);
        v.setTextColor(borderColor);
        v.setPadding(0, 0, 0, dp(8));
        return v;
    }

    private TextView small(String text) {
        TextView v = tv(text, 13, false);
        v.setTextColor(subTextColor);
        v.setLineSpacing(0, 1.15f);
        return v;
    }

    private TextView smallCenter(String text) {
        TextView v = small(text);
        v.setGravity(Gravity.CENTER);
        v.setPadding(0, dp(2), 0, 0);
        return v;
    }

    private TextView tv(String text, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(textColor);
        v.setTextSize(sp);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private LinearLayout labeledInput(String label, EditText input) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        TextView title = small(label);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(dp(4), 0, 0, 0);
        wrap.addView(title);
        wrap.addView(input);
        return wrap;
    }

    private LinearLayout labeledText(String label, TextView value) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        TextView title = small(label);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(dp(4), 0, 0, 0);
        wrap.addView(title);
        wrap.addView(value);
        return wrap;
    }

    private TextView smallResultCell(String text) {
        TextView v = tv(text, 16, false);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(8), 0, dp(8));
        v.setLayoutParams(lp);
        v.setBackground(inputBg(false));
        return v;
    }

    private void trackAngleEdit(EditText input) {
        if (input == null) return;
        input.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus && v instanceof EditText) activeAngleInput = (EditText) v;
        });
        input.setOnClickListener(v -> {
            if (v instanceof EditText) activeAngleInput = (EditText) v;
        });
    }

    private LinearLayout angleShortcutBar() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.HORIZONTAL);
        wrap.setPadding(0, dp(2), 0, dp(6));
        String[] keys = {"°", "'", "\"", "00'", "00\"", "⌫"};
        for (String k : keys) {
            Button b = btn(k);
            b.setTextSize(13);
            b.setPadding(dp(2), dp(6), dp(2), dp(6));
            b.setOnClickListener(v -> {
                if ("⌫".equals(k)) deleteFromAngleInput();
                else insertIntoAngleInput(k);
            });
            wrap.addView(b, weightParams());
        }
        return wrap;
    }

    private void insertIntoAngleInput(String text) {
        EditText target = activeAngleInput;
        if (target == null) target = azInput;
        if (target == null) return;
        target.requestFocus();
        int start = Math.max(0, target.getSelectionStart());
        int end = Math.max(0, target.getSelectionEnd());
        if (end < start) { int tmp = start; start = end; end = tmp; }
        target.getText().replace(start, end, text);
        target.setSelection(start + text.length());
    }

    private void deleteFromAngleInput() {
        EditText target = activeAngleInput;
        if (target == null) target = azInput;
        if (target == null) return;
        target.requestFocus();
        int start = Math.max(0, target.getSelectionStart());
        int end = Math.max(0, target.getSelectionEnd());
        if (end > start) {
            target.getText().delete(start, end);
            target.setSelection(start);
        } else if (start > 0) {
            target.getText().delete(start - 1, start);
            target.setSelection(start - 1);
        }
    }

    private EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextColor(textColor);
        e.setHintTextColor(subTextColor);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        e.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(8), 0, dp(8));
        e.setLayoutParams(lp);
        e.setBackground(inputBg(false));
        return e;
    }

    private Button btn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setPadding(dp(6), dp(10), dp(6), dp(10));
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(borderColor);
        gd.setCornerRadius(dp(10));
        b.setBackground(gd);
        return b;
    }

    private TextView resultBox(String text) {
        TextView v = tv(text, 15, false);
        v.setPadding(dp(10), dp(10), dp(10), dp(10));
        v.setBackground(inputBg(true));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(10), 0, 0);
        v.setLayoutParams(lp);
        return v;
    }

    private GradientDrawable inputBg(boolean result) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(result ? resultFillColor : inputFillColor);
        gd.setCornerRadius(dp(9));
        gd.setStroke(dp(1), result ? resultStrokeColor : inputStrokeColor);
        return gd;
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), dp(4), dp(3), dp(4));
        return lp;
    }

    private SpannableStringBuilder buildPolyProcedureHeader() {
        SpannableStringBuilder sb = new SpannableStringBuilder();
        appendColored(sb, "PROCEDIMIENTO SIMPLE DE POLIGONAL\n", borderColor);
        appendPlain(sb, "Datos que tú llenas: estación, P.V., azimut y distancia.\n");
        appendPlain(sb, "La app hace 4 pasos:\n");
        appendPlain(sb, "1) Convierte el azimut a rumbo.\n");
        appendPlain(sb, "2) Del rumbo toma solo el ángulo interior. Ejemplo: N 33°30' W → se usa 33°30'.\n");
        appendPlain(sb, "3) La letra final E/W usa ");
        appendColored(sb, "seno", Color.rgb(255, 171, 0));
        appendPlain(sb, ":  E/W = Distancia × seno(ángulo del rumbo).\n");
        appendPlain(sb, "4) La letra inicial N/S usa ");
        appendColored(sb, "coseno", Color.rgb(0, 184, 148));
        appendPlain(sb, ":  N/S = Distancia × coseno(ángulo del rumbo).\n");
        appendPlain(sb, "5) Después reparte el error con Bowditch y saca X/Y acumuladas.\n\n");
        return sb;
    }

    private void appendProcedureRow(SpannableStringBuilder sb, String label, double az, double distance, double dx, double dy,
                                    double corrX, double corrY, double cdx, double cdy, double x, double y, int index) {
        appendColored(sb, "Lado " + index + ": " + label + "\n", Color.rgb(41, 121, 255));
        appendPlain(sb, "Azimut: ");
        appendColored(sb, formatDms(az), Color.rgb(41, 121, 255));
        appendPlain(sb, "   Rumbo: ");
        appendColored(sb, rumbo(az), Color.rgb(194, 170, 120));
        appendPlain(sb, "\nDistancia: ");
        appendColored(sb, f3(distance), Color.rgb(41, 121, 255));
        appendPlain(sb, "\nΔE/ΔW = ");
        appendColored(sb, f3(distance), Color.rgb(41, 121, 255));
        appendPlain(sb, " × ");
        appendColored(sb, "sen(" + formatDms(az) + ")", Color.rgb(255, 171, 0));
        appendPlain(sb, " = ");
        appendColored(sb, f3(Math.abs(dx)), dx >= 0 ? Color.rgb(0, 184, 148) : Color.rgb(231, 76, 60));
        appendPlain(sb, dx >= 0 ? "  → E\n" : "  → W\n");
        appendPlain(sb, "ΔN/ΔS = ");
        appendColored(sb, f3(distance), Color.rgb(41, 121, 255));
        appendPlain(sb, " × ");
        appendColored(sb, "cos(" + formatDms(az) + ")", Color.rgb(0, 184, 148));
        appendPlain(sb, " = ");
        appendColored(sb, f3(Math.abs(dy)), dy >= 0 ? Color.rgb(0, 184, 148) : Color.rgb(231, 76, 60));
        appendPlain(sb, dy >= 0 ? "  → N\n" : "  → S\n");
        appendPlain(sb, "Corrección X: ");
        appendColored(sb, f3(corrX), Color.rgb(142, 68, 173));
        appendPlain(sb, "   Corrección Y: ");
        appendColored(sb, f3(corrY), Color.rgb(142, 68, 173));
        appendPlain(sb, "\nE/W corregida: ");
        appendColored(sb, f3(Math.abs(cdx)), cdx >= 0 ? Color.rgb(0, 184, 148) : Color.rgb(231, 76, 60));
        appendPlain(sb, cdx >= 0 ? "  → E" : "  → W");
        appendPlain(sb, "   N/S corregida: ");
        appendColored(sb, f3(Math.abs(cdy)), cdy >= 0 ? Color.rgb(0, 184, 148) : Color.rgb(231, 76, 60));
        appendPlain(sb, cdy >= 0 ? "  → N\n" : "  → S\n");
        appendPlain(sb, "X = ");
        appendColored(sb, f3(x), Color.rgb(41, 121, 255));
        appendPlain(sb, "   Y = ");
        appendColored(sb, f3(y), Color.rgb(41, 121, 255));
        appendPlain(sb, "\n\n");
    }

    private void appendPartialProcedureRow(SpannableStringBuilder sb, String label, double az, double distance, double dx, double dy, int index) {
        String rb = rumbo(az);
        double rbAngle = rumboAngle(az);
        String ew = dx >= 0 ? "E" : "W";
        String ns = dy >= 0 ? "N" : "S";
        appendColored(sb, "Fila " + index + ": " + label + "\n", Color.rgb(41, 121, 255));
        appendPlain(sb, "Dato escrito: azimut + distancia.\n");
        appendPlain(sb, "Azimut: ");
        appendColored(sb, formatDms(az), Color.rgb(41, 121, 255));
        appendPlain(sb, "  →  Rumbo: ");
        appendColored(sb, rb, Color.rgb(194, 170, 120));
        appendPlain(sb, "\nDistancia: ");
        appendColored(sb, f3(distance), Color.rgb(41, 121, 255));
        appendPlain(sb, "\nÁngulo útil del rumbo: ");
        appendColored(sb, formatDms(rbAngle), Color.rgb(41, 121, 255));
        appendPlain(sb, "  (sale del rumbo, no del azimut completo)");
        appendPlain(sb, "\nComo el rumbo termina en ");
        appendColored(sb, ew, Color.rgb(255, 171, 0));
        appendPlain(sb, ", se usa SENO:\n");
        appendColored(sb, ew + " = " + f3(distance) + " × sen(" + formatDms(rbAngle) + ") = " + f3(Math.abs(dx)), Color.rgb(255, 171, 0));
        appendPlain(sb, "\nComo el rumbo empieza en ");
        appendColored(sb, ns, Color.rgb(0, 184, 148));
        appendPlain(sb, ", se usa COSENO:\n");
        appendColored(sb, ns + " = " + f3(distance) + " × cos(" + formatDms(rbAngle) + ") = " + f3(Math.abs(dy)), Color.rgb(0, 184, 148));
        appendPlain(sb, "\nEntonces en la tabla va: ");
        appendColored(sb, ew + " = " + f3(Math.abs(dx)), Color.rgb(255, 171, 0));
        appendPlain(sb, " y ");
        appendColored(sb, ns + " = " + f3(Math.abs(dy)), Color.rgb(0, 184, 148));
        appendPlain(sb, "\n\n");
    }

    private void appendCorrectionProcedureRow(SpannableStringBuilder sb, String label,
                                             double corrX, double corrY, double cdx, double cdy, double x, double y) {
        appendColored(sb, "Corrección " + label + "\n", Color.rgb(142, 68, 173));
        appendPlain(sb, "Cx: ");
        appendColored(sb, f3(corrX), Color.rgb(142, 68, 173));
        appendPlain(sb, "   Cy: ");
        appendColored(sb, f3(corrY), Color.rgb(142, 68, 173));
        appendPlain(sb, "\nE/W corregida: ");
        appendColored(sb, f3(Math.abs(cdx)), Color.rgb(255, 171, 0));
        appendPlain(sb, cdx >= 0 ? " → E" : " → W");
        appendPlain(sb, "   N/S corregida: ");
        appendColored(sb, f3(Math.abs(cdy)), Color.rgb(0, 184, 148));
        appendPlain(sb, cdy >= 0 ? " → N" : " → S");
        appendPlain(sb, "\nX: ");
        appendColored(sb, f3(x), Color.rgb(41, 121, 255));
        appendPlain(sb, "   Y: ");
        appendColored(sb, f3(y), Color.rgb(41, 121, 255));
        appendPlain(sb, "\n\n");
    }

    private void appendProcedureSummary(SpannableStringBuilder sb, double sumDx, double sumDy, double perimeter, double closeError) {
        appendColored(sb, "RESUMEN FINAL\n", borderColor);
        appendPlain(sb, "Σ parciales X: ");
        appendColored(sb, f3(sumDx), Color.rgb(142, 68, 173));
        appendPlain(sb, "\nΣ parciales Y: ");
        appendColored(sb, f3(sumDy), Color.rgb(142, 68, 173));
        appendPlain(sb, "\nPerímetro: ");
        appendColored(sb, f3(perimeter), Color.rgb(41, 121, 255));
        appendPlain(sb, "\nError de cierre: ");
        appendColored(sb, f3(closeError), Color.rgb(231, 76, 60));
    }

    private void appendPlain(SpannableStringBuilder sb, String text) {
        sb.append(text);
    }

    private void appendColored(SpannableStringBuilder sb, String text, int color) {
        int start = sb.length();
        sb.append(text);
        sb.setSpan(new ForegroundColorSpan(color), start, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private void showProcedureDialog(String title, CharSequence content) {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.WHITE);
        TextView tv = new TextView(this);
        tv.setText(content);
        tv.setTextColor(Color.rgb(30, 33, 40));
        tv.setTextSize(13);
        tv.setLineSpacing(0, 1.08f);
        tv.setPadding(dp(12), dp(12), dp(12), dp(12));
        scroll.addView(tv);
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(scroll)
                .setPositiveButton("Cerrar", null)
                .show();
    }

    private void showPolyGraphDialog() {
        ArrayList<GraphPoint> points = buildPolyGraphPoints();
        if (points.size() < 2) {
            showError("Primero calcula la poligonal cerrada para generar el gráfico.");
            return;
        }

        final AlertDialog[] dialogRef = new AlertDialog[1];
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(14), dp(14), dp(12));
        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setColor(themeMode == THEME_LIGHT ? Color.WHITE : Color.rgb(10, 24, 39));
        panelBg.setCornerRadius(dp(18));
        panelBg.setStroke(dp(1), themeMode == THEME_LIGHT ? Color.rgb(210, 218, 230) : Color.rgb(58, 76, 100));
        panel.setBackground(panelBg);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);

        TextView icon = new TextView(this);
        icon.setText("⌁");
        icon.setGravity(Gravity.CENTER);
        icon.setTextSize(24);
        icon.setTextColor(Color.WHITE);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setColor(borderColor);
        iconBg.setCornerRadius(dp(10));
        icon.setBackground(iconBg);
        head.addView(icon, new LinearLayout.LayoutParams(dp(46), dp(46)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(10), 0, 0, 0);
        TextView title = new TextView(this);
        title.setText("Gráfico de poligonal");
        title.setTextColor(textColor);
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        texts.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Croquis con cuadrícula, puntos y brújula norte.");
        subtitle.setTextColor(subTextColor);
        subtitle.setTextSize(13);
        texts.addView(subtitle);
        head.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView close = new TextView(this);
        close.setText("×");
        close.setGravity(Gravity.CENTER);
        close.setTextColor(subTextColor);
        close.setTextSize(30);
        close.setOnClickListener(v -> { if (dialogRef[0] != null) dialogRef[0].dismiss(); });
        head.addView(close, new LinearLayout.LayoutParams(dp(44), dp(44)));
        panel.addView(head);

        TextView hint = small("Sale de las coordenadas X/Y calculadas. La brújula es referencia de orientación.");
        hint.setPadding(0, dp(10), 0, dp(4));
        panel.addView(hint);

        LinearLayout legend = new LinearLayout(this);
        legend.setOrientation(LinearLayout.HORIZONTAL);
        legend.setGravity(Gravity.CENTER_VERTICAL);
        legend.addView(legendItem("━", "Poligonal", Color.rgb(41, 121, 255)));
        legend.addView(legendItem("●", "Vértice", textColor));
        legend.addView(legendItem("✥", "Brújula", textColor));
        panel.addView(legend);

        PolyGraphView graph = new PolyGraphView(this, points);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(560));
        gp.setMargins(0, dp(8), 0, dp(8));
        panel.addView(graph, gp);

        TextView info = resultBox("ⓘ El croquis no está a escala exacta. Sirve para revisar la forma y verificar las coordenadas en la tabla.");
        info.setTextSize(12);
        panel.addView(info);

        Button closeBtn = btn("Cerrar ✓");
        closeBtn.setOnClickListener(v -> { if (dialogRef[0] != null) dialogRef[0].dismiss(); });
        panel.addView(closeBtn);

        ScrollView graphScroll = new ScrollView(this);
        graphScroll.addView(panel);
        AlertDialog dialog = new AlertDialog.Builder(this).setView(graphScroll).create();
        dialogRef[0] = dialog;
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            }
        });
        dialog.show();
    }

    private View legendItem(String symbol, String text, int color) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.HORIZONTAL);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(0, 0, dp(14), 0);
        TextView s = new TextView(this);
        s.setText(symbol);
        s.setTextColor(color);
        s.setTextSize(18);
        s.setTypeface(Typeface.DEFAULT_BOLD);
        item.addView(s);
        TextView t = new TextView(this);
        t.setText("  " + text);
        t.setTextColor(subTextColor);
        t.setTextSize(12);
        item.addView(t);
        return item;
    }

    private ArrayList<GraphPoint> buildPolyGraphPoints() {
        ArrayList<GraphPoint> points = new ArrayList<>();
        double startX = optNumber(polyX0Input.getText().toString()) != null ? optNumber(polyX0Input.getText().toString()) : 0;
        double startY = optNumber(polyY0Input.getText().toString()) != null ? optNumber(polyY0Input.getText().toString()) : 0;
        String startLabel = "Inicio";
        for (TableDataRow r : tableRows) {
            String est = r.est.getText().toString().trim();
            String pv = r.pv.getText().toString().trim();
            String dist = r.dist.getText().toString().trim();
            if (!est.isEmpty() && !pv.isEmpty() && !dist.isEmpty()) {
                startLabel = est.toUpperCase(Locale.US);
                break;
            }
        }
        points.add(new GraphPoint(startLabel, startX, startY));
        for (int i = 0; i < tableRows.size(); i++) {
            TableDataRow row = tableRows.get(i);
            Double x = optNumber(row.x.getText().toString());
            Double y = optNumber(row.y.getText().toString());
            if (x == null || y == null) continue;
            String label = row.pv.getText().toString().trim();
            if (label.isEmpty()) label = String.valueOf(i + 1);
            label = label.toUpperCase(Locale.US);
            points.add(new GraphPoint(label, x, y));
        }
        return points;
    }

    private LinearLayout tableColorBar() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.HORIZONTAL);
        Button text = btn("Texto");
        text.setTextSize(12);
        text.setOnClickListener(v -> applyManualTextColor());
        wrap.addView(text, weightParams());
        Button bg = btn("Fondo");
        bg.setTextSize(12);
        bg.setOnClickListener(v -> applyManualBgColor(false, false));
        wrap.addView(bg, weightParams());
        Button row = btn("Fila");
        row.setTextSize(12);
        row.setOnClickListener(v -> applyManualBgColor(true, false));
        wrap.addView(row, weightParams());
        Button col = btn("Col.");
        col.setTextSize(12);
        col.setOnClickListener(v -> applyManualBgColor(false, true));
        wrap.addView(col, weightParams());
        Button reset = btn("Normal");
        reset.setTextSize(12);
        reset.setOnClickListener(v -> resetCoordTableColors());
        wrap.addView(reset, weightParams());
        return wrap;
    }

    private void registerColorCell(View cell, TableLayout table, int row, int col) {
        cell.setOnClickListener(v -> {
            selectColorCell(v, table, row, col);
            if (v instanceof EditText && col == 2) activeAngleInput = (EditText) v;
            if (v instanceof EditText && col == 3) selectedDistCell = (EditText) v;
        });
        cell.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                selectColorCell(v, table, row, col);
                if (v instanceof EditText && col == 2) activeAngleInput = (EditText) v;
                if (v instanceof EditText && col == 3) selectedDistCell = (EditText) v;
            }
        });
    }

    private void selectColorCell(View cell, TableLayout table, int row, int col) {
        selectedColorCell = cell;
        selectedColorTable = table;
        selectedColorRow = row;
        selectedColorCol = col;
    }

    private void applyManualTextColor() {
        if (selectedColorCell == null) {
            Toast.makeText(this, "Primero toca una celda de la tabla", Toast.LENGTH_SHORT).show();
            return;
        }
        manualTextColorIndex = (manualTextColorIndex + 1) % manualTextColors.length;
        if (selectedColorCell instanceof TextView) {
            ((TextView) selectedColorCell).setTextColor(manualTextColors[manualTextColorIndex]);
        }
    }

    private void applyManualBgColor(boolean wholeRow, boolean wholeColumn) {
        if (selectedColorCell == null || selectedColorTable == null) {
            Toast.makeText(this, "Primero toca una celda de la tabla", Toast.LENGTH_SHORT).show();
            return;
        }
        manualBgColorIndex = (manualBgColorIndex + 1) % manualBgColors.length;
        int color = manualBgColors[manualBgColorIndex];
        if (wholeRow) {
            TableRow row = (TableRow) selectedColorTable.getChildAt(selectedColorRow);
            for (int c = 0; c < row.getChildCount(); c++) setCellManualBg(row.getChildAt(c), color);
        } else if (wholeColumn) {
            for (int r = 1; r < selectedColorTable.getChildCount(); r++) {
                View rv = selectedColorTable.getChildAt(r);
                if (rv instanceof TableRow) {
                    TableRow tr = (TableRow) rv;
                    if (selectedColorCol >= 0 && selectedColorCol < tr.getChildCount()) setCellManualBg(tr.getChildAt(selectedColorCol), color);
                }
            }
        } else {
            setCellManualBg(selectedColorCell, color);
        }
    }

    private void setCellManualBg(View cell, int color) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setStroke(1, tableLineColor);
        cell.setBackground(gd);
    }

    private void resetCoordTableColors() {
        if (coordTable == null) return;
        for (int r = 1; r < coordTable.getChildCount(); r++) {
            View rv = coordTable.getChildAt(r);
            if (!(rv instanceof TableRow)) continue;
            TableRow tr = (TableRow) rv;
            for (int c = 0; c < tr.getChildCount(); c++) {
                View cell = tr.getChildAt(c);
                boolean locked = !(cell instanceof EditText);
                cell.setBackground(cellBg(locked));
                if (cell instanceof TextView) ((TextView) cell).setTextColor(textColor);
            }
        }
        for (TableDataRow row : tableRows) applyDefaultPolyColors(row);
    }

    private void applyDefaultPolyColors(TableDataRow row) {
        row.este.setTextColor(sinColor);
        row.oeste.setTextColor(sinColor);
        row.eCorr.setTextColor(sinColor);
        row.wCorr.setTextColor(sinColor);
        row.norte.setTextColor(cosColor);
        row.sur.setTextColor(cosColor);
        row.nCorr.setTextColor(cosColor);
        row.sCorr.setTextColor(cosColor);
    }

    private TableRow headerRowCompact(String... headers) {
        TableRow tr = new TableRow(this);
        for (String h : headers) {
            TextView v = cellTextCompact(h);
            v.setTypeface(Typeface.DEFAULT_BOLD);
            v.setBackgroundColor(borderColor);
            v.setTextColor(Color.WHITE);
            tr.addView(v);
        }
        return tr;
    }

    private EditText cellEditCompact(String text, boolean number) {
        EditText e = new EditText(this);
        e.setText(text);
        e.setTextColor(textColor);
        e.setHintTextColor(subTextColor);
        e.setTextSize(12);
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER);
        e.setPadding(dp(4), dp(2), dp(4), dp(2));
        e.setMinWidth(dp(82));
        e.setBackground(cellBg(false));
        e.setInputType(number ? (InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED) : InputType.TYPE_CLASS_TEXT);
        return e;
    }

    private TextView cellTextCompact(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(textColor);
        v.setTextSize(12);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(4), dp(6), dp(4), dp(6));
        v.setMinWidth(dp(82));
        v.setBackground(cellBg(true));
        return v;
    }

    private TableRow headerSpanRow(String[] headers, int[] spans) {
        TableRow tr = new TableRow(this);
        for (int i = 0; i < headers.length; i++) {
            TextView v = cellText(headers[i]);
            v.setTypeface(Typeface.DEFAULT_BOLD);
            v.setBackgroundColor(borderColor);
            v.setTextColor(Color.WHITE);
            v.setMinWidth(dp(96 * spans[i]));
            tr.addView(v);
        }
        return tr;
    }

    private TableRow headerRow(String... headers) {
        TableRow tr = new TableRow(this);
        for (String h : headers) {
            TextView v = cellText(h);
            v.setTypeface(Typeface.DEFAULT_BOLD);
            v.setBackgroundColor(borderColor);
            v.setTextColor(Color.WHITE);
            tr.addView(v);
        }
        return tr;
    }

    private EditText cellEdit(String text, boolean number) {
        EditText e = new EditText(this);
        e.setText(text);
        e.setTextColor(textColor);
        e.setHintTextColor(subTextColor);
        e.setTextSize(13);
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER);
        e.setPadding(dp(6), dp(3), dp(6), dp(3));
        e.setMinWidth(dp(96));
        e.setBackground(cellBg(false));
        e.setInputType(number ? (InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED) : InputType.TYPE_CLASS_TEXT);
        return e;
    }

    private TextView cellText(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(textColor);
        v.setTextSize(13);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(6), dp(7), dp(6), dp(7));
        v.setMinWidth(dp(96));
        v.setBackground(cellBg(true));
        return v;
    }

    private GradientDrawable cellBg(boolean locked) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(locked ? cellLockedColor : cellEditColor);
        gd.setStroke(1, tableLineColor);
        return gd;
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }

    private static class CoordinateResult {
        double sen;
        double cos;
        double dx;
        double dy;
        double este;
        double oeste;
        double norte;
        double sur;
    }

    private interface ColorPickListener {
        void onPick(int index);
    }

    private static final class SectionState {
        final LinearLayout body;
        final TextView arrow;

        SectionState(LinearLayout body, TextView arrow) {
            this.body = body;
            this.arrow = arrow;
        }
    }

    private static class TableDataRow {
        EditText est;
        EditText pv;
        EditText az;
        EditText dist;
        TextView rumbo;
        TextView sen;
        TextView cos;
        TextView este;
        TextView oeste;
        TextView norte;
        TextView sur;
        TextView eCorr;
        TextView wCorr;
        TextView nCorr;
        TextView sCorr;
        TextView x;
        TextView y;
    }

    private static class LevelDataRow {
        EditText pv;
        EditText vAtras;
        EditText vIntermedia;
        EditText vAdelante;
        EditText cotaTerreno;
        TextView cotaNivel;
    }

    private static class StadiaLevelRow {
        EditText pv;
        EditText tipo;
        EditText hInf;
        EditText hMedio;
        EditText hSup;
        TextView distancia;
        EditText cotaTerreno;
        TextView cotaNivel;
    }

    private static class GraphPoint {
        String label;
        double x;
        double y;

        GraphPoint(String label, double x, double y) {
            this.label = label;
            this.x = x;
            this.y = y;
        }
    }

    public static class ZoomLayout extends FrameLayout {
        private final ScaleGestureDetector detector;
        private float scale = 1.0f;

        public ZoomLayout(Context context) {
            super(context);
            detector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScale(ScaleGestureDetector d) {
                    scale *= d.getScaleFactor();
                    scale = Math.max(0.80f, Math.min(scale, 3.00f));
                    setScaleX(scale);
                    setScaleY(scale);
                    setPivotX(0);
                    setPivotY(0);
                    return true;
                }
            });
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            detector.onTouchEvent(event);
            return true;
        }

        @Override
        public boolean dispatchTouchEvent(MotionEvent ev) {
            detector.onTouchEvent(ev);
            return super.dispatchTouchEvent(ev);
        }

        public void resetZoom() {
            scale = 1.0f;
            setScaleX(scale);
            setScaleY(scale);
        }
    }


    public class PolyGraphView extends View {
        private final List<GraphPoint> points;
        private final Paint plotBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint minorGridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint majorGridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint framePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint lineGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pointPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pointStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint compassPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint compassWhitePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint compassStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        public PolyGraphView(Context context, List<GraphPoint> points) {
            super(context);
            this.points = points;

            plotBgPaint.setColor(Color.rgb(250, 252, 255));
            plotBgPaint.setStyle(Paint.Style.FILL);

            minorGridPaint.setColor(Color.rgb(232, 238, 246));
            minorGridPaint.setStrokeWidth(dp(1));

            majorGridPaint.setColor(Color.rgb(190, 207, 230));
            majorGridPaint.setStrokeWidth(dp(1));

            framePaint.setColor(Color.rgb(98, 120, 146));
            framePaint.setStyle(Paint.Style.STROKE);
            framePaint.setStrokeWidth(dp(1));

            lineGlowPaint.setColor(Color.rgb(122, 176, 255));
            lineGlowPaint.setStrokeWidth(dp(9));
            lineGlowPaint.setStyle(Paint.Style.STROKE);
            lineGlowPaint.setStrokeCap(Paint.Cap.ROUND);
            lineGlowPaint.setStrokeJoin(Paint.Join.ROUND);
            lineGlowPaint.setAlpha(75);

            linePaint.setColor(Color.rgb(41, 121, 255));
            linePaint.setStrokeWidth(dp(5));
            linePaint.setStyle(Paint.Style.STROKE);
            linePaint.setStrokeCap(Paint.Cap.ROUND);
            linePaint.setStrokeJoin(Paint.Join.ROUND);

            pointPaint.setColor(Color.rgb(18, 20, 24));
            pointPaint.setStyle(Paint.Style.FILL);

            pointStrokePaint.setColor(Color.WHITE);
            pointStrokePaint.setStyle(Paint.Style.STROKE);
            pointStrokePaint.setStrokeWidth(dp(2));

            labelPaint.setColor(Color.rgb(18, 20, 24));
            labelPaint.setTextSize(dp(16));
            labelPaint.setTypeface(Typeface.DEFAULT_BOLD);

            compassPaint.setColor(Color.rgb(18, 20, 24));
            compassPaint.setStyle(Paint.Style.FILL);
            compassWhitePaint.setColor(Color.WHITE);
            compassWhitePaint.setStyle(Paint.Style.FILL);
            compassStrokePaint.setColor(Color.rgb(18, 20, 24));
            compassStrokePaint.setStyle(Paint.Style.STROKE);
            compassStrokePaint.setStrokeWidth(dp(1));
            compassStrokePaint.setTextSize(dp(12));
            compassStrokePaint.setTypeface(Typeface.DEFAULT_BOLD);
            compassStrokePaint.setTextAlign(Paint.Align.CENTER);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();

            float left = dp(8);
            float top = dp(8);
            float right = w - dp(8);
            float bottom = h - dp(8);
            canvas.drawRoundRect(left, top, right, bottom, dp(12), dp(12), plotBgPaint);

            float plotLeft = left + dp(18);
            float plotTop = top + dp(18);
            float plotRight = right - dp(18);
            float plotBottom = bottom - dp(18);

            for (int i = 0; i <= 24; i++) {
                float x = plotLeft + (plotRight - plotLeft) * i / 24f;
                float y = plotTop + (plotBottom - plotTop) * i / 24f;
                canvas.drawLine(x, plotTop, x, plotBottom, (i % 4 == 0) ? majorGridPaint : minorGridPaint);
                canvas.drawLine(plotLeft, y, plotRight, y, (i % 4 == 0) ? majorGridPaint : minorGridPaint);
            }

            double minX = Double.POSITIVE_INFINITY, maxX = Double.NEGATIVE_INFINITY;
            double minY = Double.POSITIVE_INFINITY, maxY = Double.NEGATIVE_INFINITY;
            for (GraphPoint p : points) {
                minX = Math.min(minX, p.x);
                maxX = Math.max(maxX, p.x);
                minY = Math.min(minY, p.y);
                maxY = Math.max(maxY, p.y);
            }
            if (!Double.isFinite(minX) || !Double.isFinite(minY)) return;
            double spanX = Math.max(1.0, maxX - minX);
            double spanY = Math.max(1.0, maxY - minY);
            minX -= spanX * 0.16;
            maxX += spanX * 0.16;
            minY -= spanY * 0.16;
            maxY += spanY * 0.16;
            spanX = Math.max(1.0, maxX - minX);
            spanY = Math.max(1.0, maxY - minY);
            double scaleX = (plotRight - plotLeft) / spanX;
            double scaleY = (plotBottom - plotTop) / spanY;

            Path poly = new Path();
            for (int i = 0; i < points.size(); i++) {
                GraphPoint p = points.get(i);
                float px = (float) (plotLeft + (p.x - minX) * scaleX);
                float py = (float) (plotBottom - (p.y - minY) * scaleY);
                if (i == 0) poly.moveTo(px, py); else poly.lineTo(px, py);
            }
            canvas.drawPath(poly, lineGlowPaint);
            canvas.drawPath(poly, linePaint);

            for (GraphPoint p : points) {
                float px = (float) (plotLeft + (p.x - minX) * scaleX);
                float py = (float) (plotBottom - (p.y - minY) * scaleY);
                canvas.drawCircle(px, py, dp(7), pointPaint);
                canvas.drawCircle(px, py, dp(7), pointStrokePaint);
                canvas.drawText(p.label, px + dp(10), py - dp(10), labelPaint);
            }

            drawCompassRose(canvas, right - dp(72), top + dp(76), dp(50));
            canvas.drawRoundRect(left, top, right, bottom, dp(12), dp(12), framePaint);
        }

        private void drawCompassRose(Canvas canvas, float cx, float cy, float r) {
            canvas.drawCircle(cx, cy, r, compassStrokePaint);
            canvas.drawCircle(cx, cy, r * 0.70f, compassStrokePaint);
            for (int i = 0; i < 16; i++) {
                double a = Math.toRadians(i * 22.5 - 90);
                float len = (i % 2 == 0) ? r * 0.92f : r * 0.62f;
                float x = (float) (cx + Math.cos(a) * len);
                float y = (float) (cy + Math.sin(a) * len);
                canvas.drawLine(cx, cy, x, y, compassStrokePaint);
            }
            for (int i = 0; i < 8; i++) {
                double a = Math.toRadians(i * 45 - 90);
                double leftA = a - Math.toRadians(10);
                double rightA = a + Math.toRadians(10);
                float tipR = (i % 2 == 0) ? r * 0.86f : r * 0.58f;
                float baseR = r * 0.13f;
                Path path = new Path();
                path.moveTo((float) (cx + Math.cos(a) * tipR), (float) (cy + Math.sin(a) * tipR));
                path.lineTo((float) (cx + Math.cos(leftA) * baseR), (float) (cy + Math.sin(leftA) * baseR));
                path.lineTo((float) (cx + Math.cos(rightA) * baseR), (float) (cy + Math.sin(rightA) * baseR));
                path.close();
                canvas.drawPath(path, (i % 2 == 0) ? compassPaint : compassWhitePaint);
                canvas.drawPath(path, compassStrokePaint);
            }
            compassStrokePaint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("N", cx, cy - r - dp(4), compassStrokePaint);
            canvas.drawText("S", cx, cy + r + dp(12), compassStrokePaint);
            canvas.drawText("E", cx + r + dp(11), cy + dp(4), compassStrokePaint);
            canvas.drawText("W", cx - r - dp(11), cy + dp(4), compassStrokePaint);
        }
    }

    public class CompassView extends View {
        private final Paint circlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint crossPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint arrowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private double azimuth;
        private boolean directionAvailable = true;

        public CompassView(Context context) {
            super(context);
            circlePaint.setStyle(Paint.Style.STROKE);
            circlePaint.setStrokeWidth(dp(2));
            circlePaint.setColor(compassRingColor);

            crossPaint.setStyle(Paint.Style.STROKE);
            crossPaint.setStrokeWidth(dp(1));
            crossPaint.setColor(subTextColor);

            textPaint.setColor(textColor);
            textPaint.setTextSize(dp(13));
            textPaint.setTypeface(Typeface.DEFAULT_BOLD);
            textPaint.setTextAlign(Paint.Align.CENTER);

            arrowPaint.setStyle(Paint.Style.STROKE);
            arrowPaint.setStrokeWidth(dp(4));
            arrowPaint.setStrokeCap(Paint.Cap.ROUND);
            arrowPaint.setStrokeJoin(Paint.Join.ROUND);
            arrowPaint.setColor(compassArrowColor);
        }

        public void setAzimuth(double azimuth) {
            this.azimuth = azimuth;
            this.directionAvailable = true;
            invalidate();
        }

        public void setDirectionAvailable(boolean available) {
            this.directionAvailable = available;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            float cx = w / 2f;
            float cy = h / 2f;
            float r = Math.min(w, h) * 0.455f;

            Paint face = new Paint(Paint.ANTI_ALIAS_FLAG);
            face.setStyle(Paint.Style.FILL);
            face.setColor(themeMode == THEME_LIGHT ? Color.rgb(252, 253, 255) : Color.rgb(18, 28, 42));
            canvas.drawCircle(cx, cy, r, face);

            Paint outer = new Paint(Paint.ANTI_ALIAS_FLAG);
            outer.setStyle(Paint.Style.STROKE);
            outer.setStrokeWidth(dp(6));
            outer.setColor(compassRingColor);
            canvas.drawCircle(cx, cy, r, outer);
            outer.setStrokeWidth(dp(2));
            outer.setColor(themeMode == THEME_LIGHT ? Color.rgb(70, 77, 90) : Color.rgb(210, 216, 225));
            canvas.drawCircle(cx, cy, r * 0.93f, outer);
            outer.setStrokeWidth(dp(1));
            outer.setColor(themeMode == THEME_LIGHT ? Color.rgb(176, 184, 196) : Color.rgb(96, 106, 120));
            canvas.drawCircle(cx, cy, r * 0.70f, outer);

            Paint tick = new Paint(Paint.ANTI_ALIAS_FLAG);
            tick.setStyle(Paint.Style.STROKE);
            tick.setStrokeCap(Paint.Cap.ROUND);
            for (int i = 0; i < 72; i++) {
                double a = Math.toRadians(i * 5 - 90);
                boolean major = i % 6 == 0;
                boolean mid = i % 2 == 0;
                tick.setStrokeWidth(major ? dp(2) : dp(1));
                tick.setColor(major ? textColor : subTextColor);
                float outerR = r * 0.90f;
                float innerR = major ? r * 0.78f : (mid ? r * 0.82f : r * 0.85f);
                canvas.drawLine(
                        (float) (cx + Math.cos(a) * innerR),
                        (float) (cy + Math.sin(a) * innerR),
                        (float) (cx + Math.cos(a) * outerR),
                        (float) (cy + Math.sin(a) * outerR),
                        tick
                );
            }

            Paint roseLight = new Paint(Paint.ANTI_ALIAS_FLAG);
            roseLight.setStyle(Paint.Style.FILL);
            roseLight.setColor(themeMode == THEME_LIGHT ? Color.rgb(205, 216, 224) : Color.rgb(56, 74, 90));
            Paint roseDark = new Paint(Paint.ANTI_ALIAS_FLAG);
            roseDark.setStyle(Paint.Style.FILL);
            roseDark.setColor(themeMode == THEME_LIGHT ? Color.rgb(140, 151, 164) : Color.rgb(109, 128, 145));
            for (int i = 0; i < 8; i++) {
                double a = Math.toRadians(i * 45 - 90);
                double la = a - Math.toRadians(9);
                double ra = a + Math.toRadians(9);
                float tipR = (i % 2 == 0) ? r * 0.58f : r * 0.42f;
                float baseR = r * 0.10f;
                Path star = new Path();
                star.moveTo((float) (cx + Math.cos(a) * tipR), (float) (cy + Math.sin(a) * tipR));
                star.lineTo((float) (cx + Math.cos(la) * baseR), (float) (cy + Math.sin(la) * baseR));
                star.lineTo((float) (cx + Math.cos(ra) * baseR), (float) (cy + Math.sin(ra) * baseR));
                star.close();
                canvas.drawPath(star, (i % 2 == 0) ? roseDark : roseLight);
            }

            Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
            label.setColor(textColor);
            label.setTypeface(Typeface.DEFAULT_BOLD);
            label.setTextAlign(Paint.Align.CENTER);
            label.setTextSize(dp(24));
            canvas.drawText("N", cx, cy - r * 0.48f, label);
            canvas.drawText("S", cx, cy + r * 0.58f, label);
            canvas.drawText("E", cx + r * 0.54f, cy + dp(6), label);
            canvas.drawText("W", cx - r * 0.54f, cy + dp(6), label);

            label.setColor(subTextColor);
            label.setTextSize(dp(12));
            canvas.drawText("NE", cx + r * 0.37f, cy - r * 0.35f, label);
            canvas.drawText("SE", cx + r * 0.37f, cy + r * 0.40f, label);
            canvas.drawText("SW", cx - r * 0.37f, cy + r * 0.40f, label);
            canvas.drawText("NW", cx - r * 0.37f, cy - r * 0.35f, label);

            if (directionAvailable) {
                double rad = Math.toRadians(azimuth - 90.0);
                drawNeedle(canvas, cx, cy, r, rad, true);
                drawNeedle(canvas, cx, cy, r, rad + Math.PI, false);
            } else {
                Paint unavailable = new Paint(Paint.ANTI_ALIAS_FLAG);
                unavailable.setColor(subTextColor);
                unavailable.setTextAlign(Paint.Align.CENTER);
                unavailable.setTypeface(Typeface.DEFAULT_BOLD);
                unavailable.setTextSize(dp(13));
                canvas.drawText("SIN RUMBO", cx, cy + r * 0.18f, unavailable);
            }

            Paint center = new Paint(Paint.ANTI_ALIAS_FLAG);
            center.setStyle(Paint.Style.FILL);
            center.setColor(Color.rgb(230, 233, 238));
            canvas.drawCircle(cx, cy, dp(13), center);
            center.setStyle(Paint.Style.STROKE);
            center.setStrokeWidth(dp(3));
            center.setColor(themeMode == THEME_LIGHT ? Color.rgb(96, 104, 118) : Color.rgb(180, 188, 198));
            canvas.drawCircle(cx, cy, dp(13), center);
            center.setStyle(Paint.Style.FILL);
            center.setColor(compassRingColor);
            canvas.drawCircle(cx, cy, dp(4), center);
        }

        private void drawNeedle(Canvas canvas, float cx, float cy, float r, double rad, boolean northNeedle) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setStyle(Paint.Style.FILL);
            p.setColor(northNeedle ? Color.rgb(220, 30, 38) : Color.rgb(22, 91, 180));
            float tipR = northNeedle ? r * 0.79f : r * 0.70f;
            float baseR = r * 0.14f;
            double left = rad + Math.toRadians(12);
            double right = rad - Math.toRadians(12);
            Path path = new Path();
            path.moveTo((float) (cx + Math.cos(rad) * tipR), (float) (cy + Math.sin(rad) * tipR));
            path.lineTo((float) (cx + Math.cos(left) * baseR), (float) (cy + Math.sin(left) * baseR));
            path.lineTo((float) (cx + Math.cos(right) * baseR), (float) (cy + Math.sin(right) * baseR));
            path.close();
            canvas.drawPath(path, p);

            Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
            edge.setStyle(Paint.Style.STROKE);
            edge.setStrokeWidth(dp(1));
            edge.setColor(northNeedle ? Color.rgb(120, 0, 0) : Color.rgb(0, 35, 100));
            canvas.drawPath(path, edge);
        }
    }
}
