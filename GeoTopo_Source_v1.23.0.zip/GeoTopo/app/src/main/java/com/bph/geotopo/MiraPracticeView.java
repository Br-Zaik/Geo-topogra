package com.bph.geotopo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

import java.util.Locale;
import java.util.Random;

/**
 * Simulación visual de una mira topográfica métrica tipo E vista por un nivel.
 * El dibujo es deliberadamente semi realista: conserva graduaciones coherentes,
 * una ventana de observación y tres hilos para practicar la lectura.
 */
public class MiraPracticeView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random();
    private final int panelColor;
    private final int subTextColor;
    private final float density;

    private double upperReading;
    private double middleReading;
    private double lowerReading;
    private double visibleMin;
    private double visibleMax;

    public MiraPracticeView(Context context, int accentColor, int textColor, int subTextColor, int panelColor) {
        super(context);
        this.panelColor = panelColor;
        this.subTextColor = subTextColor;
        this.density = getResources().getDisplayMetrics().density;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        newExercise();
    }

    public void newExercise() {
        // Se observa aproximadamente una ventana de 28 cm.
        int lowerDm = 5 + random.nextInt(40); // 0.50 m a 4.40 m
        visibleMin = lowerDm / 10.0;
        visibleMax = visibleMin + 0.28;

        int minMm = (int) Math.round(visibleMin * 1000.0) + 18;
        int maxMm = (int) Math.round(visibleMax * 1000.0) - 18;
        int middleMm = minMm + (maxMm - minMm) / 2 + random.nextInt(31) - 15;
        int halfSpanMm = 52 + random.nextInt(34); // 52 a 85 mm por lado.

        if (middleMm - halfSpanMm < minMm) middleMm = minMm + halfSpanMm;
        if (middleMm + halfSpanMm > maxMm) middleMm = maxMm - halfSpanMm;

        // Evita ejercicios en los que todos los hilos caigan exactamente sobre líneas gruesas.
        int rem = floorMod(middleMm, 10);
        if (rem == 0 || rem == 9) middleMm += 3;

        middleReading = middleMm / 1000.0;
        upperReading = (middleMm + halfSpanMm) / 1000.0;
        lowerReading = (middleMm - halfSpanMm) / 1000.0;
        invalidate();
    }

    public double getUpperReading() {
        return upperReading;
    }

    public double getMiddleReading() {
        return middleReading;
    }

    public double getLowerReading() {
        return lowerReading;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int desiredHeight = Math.round(width * 1.08f);
        setMeasuredDimension(width, resolveSize(desiredHeight, heightMeasureSpec));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();
        if (width <= 0 || height <= 0) return;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(panelColor);
        canvas.drawRoundRect(new RectF(0, 0, width, height), dp(16), dp(16), paint);

        float footerHeight = dp(35);
        float cx = width / 2f;
        float cy = (height - footerHeight) / 2f;
        float radius = Math.min(width * 0.465f, (height - footerHeight) * 0.465f);

        drawOcular(canvas, cx, cy, radius);

        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(dp(10.5f));
        paint.setColor(subTextColor);
        canvas.drawText("Práctica de mira tipo E · visor de campo simulado · lectura en metros", cx, height - dp(9), paint);
    }

    private void drawOcular(Canvas canvas, float cx, float cy, float radius) {
        paint.setStyle(Paint.Style.FILL);
        paint.setShadowLayer(dp(10), 0, dp(3), Color.argb(140, 0, 0, 0));
        paint.setColor(Color.rgb(12, 14, 18));
        canvas.drawCircle(cx, cy, radius + dp(8), paint);
        paint.clearShadowLayer();

        Path lensPath = new Path();
        lensPath.addCircle(cx, cy, radius, Path.Direction.CW);
        int save = canvas.save();
        canvas.clipPath(lensPath);

        paint.setColor(Color.rgb(236, 239, 240));
        canvas.drawCircle(cx, cy, radius, paint);

        // Iluminación suave del lente.
        paint.setColor(Color.argb(18, 255, 255, 255));
        canvas.drawCircle(cx - radius * 0.34f, cy - radius * 0.34f, radius * 0.66f, paint);
        paint.setColor(Color.argb(13, 0, 0, 0));
        canvas.drawCircle(cx + radius * 0.33f, cy + radius * 0.20f, radius * 0.86f, paint);

        drawStaff(canvas, cx, cy, radius);
        drawReticle(canvas, cx, cy, radius);
        drawVignette(canvas, cx, cy, radius);

        canvas.restoreToCount(save);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(3));
        paint.setColor(Color.rgb(25, 28, 34));
        canvas.drawCircle(cx, cy, radius, paint);
        paint.setStrokeWidth(dp(1));
        paint.setColor(Color.rgb(116, 121, 128));
        canvas.drawCircle(cx, cy, radius - dp(3), paint);
    }

    private void drawStaff(Canvas canvas, float cx, float cy, float radius) {
        float staffWidth = Math.min(dp(126), radius * 0.53f);
        float staffLeft = cx - staffWidth / 2f;
        float staffRight = cx + staffWidth / 2f;
        float staffTop = cy - radius - dp(12);
        float staffBottom = cy + radius + dp(12);

        float rail = Math.max(dp(4), staffWidth * 0.045f);
        float innerLeft = staffLeft + rail;
        float innerRight = staffRight - rail;
        float patternRight = innerLeft + (innerRight - innerLeft) * 0.58f;
        float numberLeft = patternRight;

        // Sombra y cuerpo de aluminio de la mira.
        paint.setStyle(Paint.Style.FILL);
        paint.setShadowLayer(dp(5), dp(2), dp(2), Color.argb(90, 0, 0, 0));
        paint.setColor(Color.rgb(205, 209, 212));
        canvas.drawRect(staffLeft, staffTop, staffRight, staffBottom, paint);
        paint.clearShadowLayer();
        paint.setColor(Color.WHITE);
        canvas.drawRect(innerLeft, staffTop, innerRight, staffBottom, paint);

        // Rieles laterales.
        paint.setColor(Color.rgb(116, 121, 126));
        canvas.drawRect(staffLeft, staffTop, innerLeft, staffBottom, paint);
        canvas.drawRect(innerRight, staffTop, staffRight, staffBottom, paint);
        paint.setColor(Color.rgb(238, 240, 242));
        canvas.drawRect(staffLeft + dp(1), staffTop, staffLeft + rail * 0.42f, staffBottom, paint);
        canvas.drawRect(innerRight + rail * 0.18f, staffTop, staffRight - dp(1), staffBottom, paint);

        int firstCm = (int) Math.floor(visibleMin * 100.0);
        int lastCm = (int) Math.ceil(visibleMax * 100.0);
        for (int cm = firstCm; cm < lastCm; cm++) {
            double low = cm / 100.0;
            double high = (cm + 1) / 100.0;
            float yTop = readingToY(high, staffTop, staffBottom);
            float yBottom = readingToY(low, staffTop, staffBottom);
            drawCentimeterPattern(canvas, cm, innerLeft, patternRight, yTop, yBottom);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(cm % 10 == 0 ? dp(1.0f) : dp(0.45f));
            paint.setColor(cm % 10 == 0 ? Color.rgb(90, 90, 90) : Color.rgb(220, 220, 220));
            canvas.drawLine(innerLeft, yBottom, innerRight, yBottom, paint);
        }

        // Separador de números.
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(0.8f));
        paint.setColor(Color.rgb(80, 80, 80));
        canvas.drawLine(patternRight, staffTop, patternRight, staffBottom, paint);

        int firstDm = (int) Math.floor(visibleMin * 10.0);
        int lastDm = (int) Math.ceil(visibleMax * 10.0);
        for (int dm = firstDm; dm < lastDm; dm++) {
            float yTop = readingToY((dm + 1) / 10.0, staffTop, staffBottom);
            float yBottom = readingToY(dm / 10.0, staffTop, staffBottom);
            drawDecimeterNumber(canvas, dm, numberLeft, innerRight, yTop, yBottom);
        }

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1.1f));
        paint.setColor(Color.rgb(42, 42, 42));
        canvas.drawRect(innerLeft, staffTop, innerRight, staffBottom, paint);
    }

    private void drawCentimeterPattern(Canvas canvas, int cm, float left, float right, float top, float bottom) {
        int cmInDm = floorMod(cm, 10);
        int inHalf = cmInDm % 5;
        boolean upperHalf = cmInDm >= 5;
        boolean fromLeft = ((cm / 10) & 1) == 0 ? !upperHalf : upperHalf;

        float width = right - left;
        float[] proportions = {0.96f, 0.58f, 0.88f, 0.58f, 0.96f};
        float blockWidth = width * proportions[inHalf];
        float verticalPadding = Math.max(dp(0.25f), (bottom - top) * 0.08f);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(220, 25, 32));
        if (fromLeft) {
            canvas.drawRect(left, top + verticalPadding, left + blockWidth, bottom - verticalPadding, paint);
        } else {
            canvas.drawRect(right - blockWidth, top + verticalPadding, right, bottom - verticalPadding, paint);
        }

        // Pequeña muesca blanca para que el bloque se lea como una E y no como barras sueltas.
        if (inHalf == 1 || inHalf == 3) {
            paint.setColor(Color.WHITE);
            float notch = width * 0.16f;
            float midY = (top + bottom) / 2f;
            if (fromLeft) {
                canvas.drawRect(left + blockWidth - notch, midY - dp(0.7f), left + blockWidth, midY + dp(0.7f), paint);
            } else {
                canvas.drawRect(right - blockWidth, midY - dp(0.7f), right - blockWidth + notch, midY + dp(0.7f), paint);
            }
        }
    }

    private void drawDecimeterNumber(Canvas canvas, int dm, float left, float right, float top, float bottom) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(15, 15, 15));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(Math.min(dp(28), Math.abs(bottom - top) * 0.42f));
        float x = left + (right - left) * 0.53f;
        float centerY = (top + bottom) / 2f;
        canvas.drawText(String.format(Locale.US, "%02d", Math.max(0, dm)), x, centeredBaseline(centerY), paint);
    }

    private void drawReticle(Canvas canvas, float cx, float cy, float radius) {
        float top = cy - radius - dp(12);
        float bottom = cy + radius + dp(12);

        drawHorizontalHair(canvas, "LS", upperReading, cx, radius, top, bottom, false);
        drawHorizontalHair(canvas, "LM", middleReading, cx, radius, top, bottom, true);
        drawHorizontalHair(canvas, "LI", lowerReading, cx, radius, top, bottom, false);

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.rgb(15, 15, 15));
        paint.setStrokeWidth(dp(1.1f));
        canvas.drawLine(cx, cy - radius * 0.96f, cx, cy + radius * 0.96f, paint);

        // Pequeño claro central semejante a una retícula óptica.
        paint.setColor(Color.rgb(238, 239, 240));
        paint.setStrokeWidth(dp(2.7f));
        canvas.drawLine(cx, cy - dp(3), cx, cy + dp(3), paint);
        paint.setColor(Color.rgb(15, 15, 15));
        paint.setStrokeWidth(dp(1.0f));
        canvas.drawCircle(cx, cy, dp(1.6f), paint);
    }

    private void drawHorizontalHair(Canvas canvas, String label, double reading, float cx, float radius,
                                    float staffTop, float staffBottom, boolean middle) {
        float y = readingToY(reading, staffTop, staffBottom);
        float fullLeft = cx - radius + dp(5);
        float fullRight = cx + radius - dp(5);
        float shortLeft = cx - radius * 0.53f;
        float shortRight = cx + radius * 0.53f;

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(middle ? dp(1.8f) : dp(1.25f));
        paint.setColor(Color.rgb(12, 12, 12));
        canvas.drawLine(middle ? fullLeft : shortLeft, y, middle ? fullRight : shortRight, y, paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(dp(11.5f));
        paint.setTextAlign(Paint.Align.LEFT);
        paint.setColor(Color.rgb(24, 24, 24));
        float labelX = middle ? fullLeft + dp(4) : shortLeft - dp(26);
        canvas.drawText(label, labelX, y - dp(4), paint);
    }

    private void drawVignette(Canvas canvas, float cx, float cy, float radius) {
        paint.setStyle(Paint.Style.STROKE);
        for (int i = 0; i < 9; i++) {
            int alpha = 8 + i * 5;
            paint.setColor(Color.argb(alpha, 0, 0, 0));
            paint.setStrokeWidth(dp(2.3f));
            canvas.drawCircle(cx, cy, radius - dp(1.5f) - i * dp(1.8f), paint);
        }
    }

    private float readingToY(double reading, float top, float bottom) {
        double range = Math.max(0.01, visibleMax - visibleMin);
        double fraction = (visibleMax - reading) / range;
        return (float) (top + fraction * (bottom - top));
    }

    private float centeredBaseline(float centerY) {
        Paint.FontMetrics metrics = paint.getFontMetrics();
        return centerY - (metrics.ascent + metrics.descent) / 2f;
    }

    private int floorMod(int value, int divisor) {
        int result = value % divisor;
        return result < 0 ? result + divisor : result;
    }

    private int dp(float value) {
        return Math.round(value * density);
    }
}
