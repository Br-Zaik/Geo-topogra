package com.bph.geotopo;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Native, scalable visual components for the Geo Topo interface. */
public final class NativeUi {
    public static final int BG = Color.rgb(2, 17, 32);
    public static final int BG_DEEP = Color.rgb(1, 12, 25);
    public static final int HEADER = Color.rgb(3, 35, 61);
    public static final int CARD = Color.rgb(12, 36, 58);
    public static final int CARD_DARK = Color.rgb(7, 28, 48);
    public static final int CARD_LIGHT = Color.rgb(18, 50, 78);
    public static final int BLUE = Color.rgb(43, 121, 255);
    public static final int BLUE_LIGHT = Color.rgb(92, 159, 255);
    public static final int TEXT = Color.rgb(248, 250, 253);
    public static final int SUB = Color.rgb(169, 193, 219);
    public static final int BORDER = Color.rgb(72, 112, 150);

    private NativeUi() {}

    public static int dp(Context c, int value) {
        return Math.round(value * c.getResources().getDisplayMetrics().density);
    }

    public static int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    public static void styleWindow(Activity activity) {
        Window window = activity.getWindow();
        window.setStatusBarColor(BG_DEEP);
        window.setNavigationBarColor(Color.BLACK);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.getDecorView().setSystemUiVisibility(0);
        }
    }

    public static FrameLayout screen(Context context) {
        FrameLayout root = new FrameLayout(context);
        root.setBackgroundColor(BG);
        TopoBackgroundView background = new TopoBackgroundView(context);
        root.addView(background, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        return root;
    }

    public static ScrollView scroll(Context context, View child) {
        ScrollView scroll = new ScrollView(context);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.addView(child, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        return scroll;
    }

    public static LinearLayout column(Context context) {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    public static LinearLayout row(Context context) {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    public static TextView text(Context context, String value, float sp, boolean bold, int color) {
        TextView text = new TextView(context);
        text.setText(value);
        text.setTextSize(sp);
        text.setTextColor(color);
        text.setGravity(Gravity.CENTER_VERTICAL);
        text.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        text.setIncludeFontPadding(false);
        return text;
    }

    public static GradientDrawable rounded(int color, int radiusDp, int strokeDp, int strokeColor, Context c) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(c, radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(c, strokeDp), strokeColor);
        return drawable;
    }

    public static GradientDrawable gradient(int start, int end, int radiusDp, int strokeColor, Context c) {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{start, end});
        drawable.setCornerRadius(dp(c, radiusDp));
        drawable.setStroke(dp(c, 1), strokeColor);
        return drawable;
    }

    public static View dashboardHeader(Context context, View.OnClickListener settingsClick) {
        LinearLayout bar = row(context);
        bar.setPadding(dp(context, 18), dp(context, 16), dp(context, 18), dp(context, 14));
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.TRANSPARENT);

        LinearLayout labels = column(context);
        TextView title = text(context, "Geo Topo", 34, true, TEXT);
        TextView subtitle = text(context, "Cálculos topográficos", 16, false, SUB);
        subtitle.setPadding(0, dp(context, 5), 0, 0);
        labels.addView(title);
        labels.addView(subtitle);
        bar.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView settings = text(context, "⚙", 27, true, Color.WHITE);
        settings.setGravity(Gravity.CENTER);
        settings.setContentDescription("Ajustes");
        settings.setBackground(gradient(Color.rgb(39, 111, 242), Color.rgb(24, 73, 179), 32,
                withAlpha(BLUE_LIGHT, 190), context));
        settings.setElevation(dp(context, 5));
        settings.setOnClickListener(settingsClick);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(dp(context, 64), dp(context, 64));
        bar.addView(settings, slp);
        return bar;
    }

    public static View pageHeader(Context context, String titleValue, String subtitleValue,
                                  View.OnClickListener backClick, String actionIcon,
                                  View.OnClickListener actionClick) {
        LinearLayout bar = row(context);
        bar.setPadding(dp(context, 8), dp(context, 12), dp(context, 14), dp(context, 12));
        bar.setBackgroundColor(withAlpha(HEADER, 235));

        TextView back = text(context, "‹", 43, false, Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription("Volver");
        back.setOnClickListener(backClick);
        bar.addView(back, new LinearLayout.LayoutParams(dp(context, 56), dp(context, 62)));

        LinearLayout labels = column(context);
        TextView title = text(context, titleValue, 27, true, TEXT);
        TextView subtitle = text(context, subtitleValue, 14, false, SUB);
        subtitle.setPadding(0, dp(context, 4), 0, 0);
        labels.addView(title);
        labels.addView(subtitle);
        bar.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        if (actionIcon != null) {
            TextView action = text(context, actionIcon, 24, true, Color.WHITE);
            action.setGravity(Gravity.CENTER);
            action.setBackground(rounded(withAlpha(BLUE, 40), 28, 1, withAlpha(BLUE_LIGHT, 170), context));
            action.setOnClickListener(actionClick);
            bar.addView(action, new LinearLayout.LayoutParams(dp(context, 56), dp(context, 56)));
        }
        return bar;
    }

    public static View heroCard(Context context, boolean gps, View.OnClickListener click) {
        FrameLayout card = new FrameLayout(context);
        card.setClipToOutline(true);
        card.setBackground(gradient(gps ? Color.rgb(10, 47, 101) : Color.rgb(28, 73, 110),
                gps ? Color.rgb(3, 27, 58) : Color.rgb(8, 34, 57), 20,
                withAlpha(BLUE_LIGHT, 185), context));
        card.setElevation(dp(context, 3));
        card.setOnClickListener(click);

        if (gps) {
            MiniTopoView map = new MiniTopoView(context, true);
            card.addView(map, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            MiniTopoView backdrop = new MiniTopoView(context, false);
            card.addView(backdrop, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
            ImageView station = new ImageView(context);
            station.setImageResource(R.drawable.station_total_card);
            station.setScaleType(ImageView.ScaleType.CENTER_CROP);
            station.setAlpha(0.94f);
            FrameLayout.LayoutParams ilp = new FrameLayout.LayoutParams(dp(context, 98), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END);
            station.setLayoutParams(ilp);
            card.addView(station);
        }

        GradientDrawable shade = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{withAlpha(BG_DEEP, 210), withAlpha(BG_DEEP, gps ? 35 : 0)});
        shade.setCornerRadius(dp(context, 20));
        View shadeView = new View(context);
        shadeView.setBackground(shade);
        card.addView(shadeView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout labels = column(context);
        labels.setPadding(dp(context, 16), dp(context, 18), dp(context, 12), dp(context, 14));
        labels.setGravity(Gravity.BOTTOM);
        TextView title = text(context, gps ? "GPS y mapas" : "Herramientas\nde campo", 21, true, TEXT);
        title.setLineSpacing(0, 1.0f);
        TextView sub = text(context,
                gps ? "Posición, mapas\ny datos GNSS" : "Instrumentos y\nutilidades de campo",
                13.5f, false, Color.rgb(152, 207, 255));
        sub.setLineSpacing(0, 1.18f);
        sub.setPadding(0, dp(context, 10), 0, 0);
        labels.addView(title);
        labels.addView(sub);
        card.addView(labels, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        TextView arrow = text(context, "›", 38, false, Color.WHITE);
        arrow.setGravity(Gravity.CENTER);
        arrow.setBackground(gradient(Color.rgb(38, 111, 236), Color.rgb(16, 61, 145), 28,
                withAlpha(BLUE_LIGHT, 130), context));
        FrameLayout.LayoutParams alp = new FrameLayout.LayoutParams(dp(context, 54), dp(context, 54), Gravity.END | Gravity.BOTTOM);
        alp.setMargins(0, 0, dp(context, 12), dp(context, 12));
        card.addView(arrow, alp);
        return card;
    }

    public static View sectionHeader(Context context, String icon, String titleValue, String rightText,
                                     View.OnClickListener rightClick) {
        LinearLayout row = row(context);
        row.setPadding(dp(context, 2), dp(context, 14), dp(context, 2), dp(context, 9));
        TextView iconView = text(context, icon, 20, true, BLUE_LIGHT);
        iconView.setGravity(Gravity.CENTER);
        row.addView(iconView, new LinearLayout.LayoutParams(dp(context, 36), dp(context, 36)));
        TextView title = text(context, titleValue, 16, true, TEXT);
        title.setLetterSpacing(0.06f);
        row.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(context, 36)));
        View line = new View(context);
        line.setBackgroundColor(withAlpha(BORDER, 80));
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(0, dp(context, 1), 1f);
        llp.setMargins(dp(context, 12), 0, dp(context, 10), 0);
        row.addView(line, llp);
        if (rightText != null) {
            TextView right = text(context, rightText + "  ›", 14, false, BLUE_LIGHT);
            right.setOnClickListener(rightClick);
            row.addView(right);
        }
        return row;
    }

    public static View menuCard(Context context, String iconType, String titleValue,
                                String subtitleValue, View.OnClickListener click, int minHeightDp) {
        LinearLayout card = row(context);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(context, 10), dp(context, 10), dp(context, 8), dp(context, 10));
        card.setMinimumHeight(dp(context, minHeightDp));
        card.setBackground(gradient(CARD_LIGHT, CARD_DARK, 17, withAlpha(BORDER, 170), context));
        card.setElevation(dp(context, 2));
        card.setOnClickListener(click);

        FrameLayout iconBox = iconTile(context, iconType, 54);
        card.addView(iconBox, new LinearLayout.LayoutParams(dp(context, 54), dp(context, 54)));

        LinearLayout labels = column(context);
        labels.setPadding(dp(context, 12), 0, dp(context, 5), 0);
        TextView title = text(context, titleValue, subtitleValue == null ? 16.5f : 16, true, TEXT);
        title.setMaxLines(2);
        labels.addView(title);
        if (subtitleValue != null && !subtitleValue.isEmpty()) {
            TextView sub = text(context, subtitleValue, 12.5f, false, SUB);
            sub.setPadding(0, dp(context, 4), 0, 0);
            sub.setMaxLines(2);
            labels.addView(sub);
        }
        card.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView arrow = text(context, "›", 32, false, Color.rgb(203, 220, 237));
        arrow.setGravity(Gravity.CENTER);
        card.addView(arrow, new LinearLayout.LayoutParams(dp(context, 34), dp(context, 50)));
        return card;
    }

    public static FrameLayout iconTile(Context context, String type, int sizeDp) {
        FrameLayout box = new FrameLayout(context);
        box.setBackground(gradient(Color.rgb(27, 84, 175), Color.rgb(13, 54, 119), 15,
                withAlpha(BLUE_LIGHT, 105), context));
        IconGlyphView glyph = new IconGlyphView(context, type);
        int margin = dp(context, 10);
        FrameLayout.LayoutParams glp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        glp.setMargins(margin, margin, margin, margin);
        box.addView(glyph, glp);
        return box;
    }

    public static View infoCard(Context context, String iconType, String titleValue, String body) {
        LinearLayout card = column(context);
        card.setPadding(dp(context, 14), dp(context, 13), dp(context, 14), dp(context, 13));
        card.setBackground(gradient(CARD_LIGHT, CARD_DARK, 17, withAlpha(BORDER, 165), context));
        LinearLayout titleRow = row(context);
        IconGlyphView icon = new IconGlyphView(context, iconType);
        titleRow.addView(icon, new LinearLayout.LayoutParams(dp(context, 28), dp(context, 28)));
        TextView title = text(context, titleValue, 15, false, TEXT);
        title.setPadding(dp(context, 8), 0, 0, 0);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, dp(context, 30), 1f));
        card.addView(titleRow);
        View line = new View(context);
        line.setBackgroundColor(withAlpha(BORDER, 100));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 1));
        lp.setMargins(0, dp(context, 8), 0, dp(context, 10));
        card.addView(line, lp);
        TextView bodyView = text(context, body, 13.5f, false, SUB);
        bodyView.setLineSpacing(dp(context, 2), 1f);
        card.addView(bodyView);
        return card;
    }

    public static View gpsMapCard(Context context, View.OnClickListener offlineClick, View.OnClickListener openMapClick) {
        FrameLayout card = new FrameLayout(context);
        card.setBackground(gradient(Color.rgb(5, 32, 68), Color.rgb(2, 20, 43), 20,
                withAlpha(BORDER, 180), context));
        card.setClipToOutline(true);
        MiniTopoView map = new MiniTopoView(context, true);
        card.addView(map, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        TextView offline = text(context, "⇩  Mapa offline", 14, false, TEXT);
        offline.setGravity(Gravity.CENTER);
        offline.setBackground(rounded(withAlpha(BG_DEEP, 210), 26, 1, withAlpha(BLUE, 185), context));
        offline.setOnClickListener(offlineClick);
        FrameLayout.LayoutParams olp = new FrameLayout.LayoutParams(dp(context, 190), dp(context, 50), Gravity.START | Gravity.TOP);
        olp.setMargins(dp(context, 16), dp(context, 15), 0, 0);
        card.addView(offline, olp);

        TextView open = text(context, "▱  Abrir mapa", 17, false, Color.WHITE);
        open.setGravity(Gravity.CENTER);
        open.setBackground(gradient(Color.rgb(48, 130, 255), Color.rgb(31, 91, 222), 18,
                withAlpha(Color.WHITE, 60), context));
        open.setElevation(dp(context, 4));
        open.setOnClickListener(openMapClick);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(dp(context, 205), dp(context, 64), Gravity.END | Gravity.BOTTOM);
        blp.setMargins(0, 0, dp(context, 15), dp(context, 15));
        card.addView(open, blp);
        return card;
    }

    public static class TopoBackgroundView extends View {
        private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        public TopoBackgroundView(Context context) {
            super(context);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            linePaint.setStyle(Paint.Style.STROKE);
            linePaint.setStrokeWidth(dp(context, 1));
            linePaint.setColor(withAlpha(BLUE_LIGHT, 22));
            glowPaint.setStyle(Paint.Style.STROKE);
            glowPaint.setStrokeWidth(dp(context, 1));
            glowPaint.setColor(withAlpha(BLUE, 12));
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            canvas.drawColor(BG);
            int w = getWidth();
            int h = getHeight();
            for (int i = -4; i < 18; i++) {
                float baseY = i * h / 12f;
                path.reset();
                path.moveTo(-40, baseY + 30);
                for (int x = 0; x <= w + 60; x += 45) {
                    float y = baseY + (float) Math.sin((x * 0.015) + i * 0.7) * 24f
                            + (float) Math.cos((x * 0.007) - i) * 16f;
                    path.lineTo(x, y);
                }
                canvas.drawPath(path, i % 3 == 0 ? glowPaint : linePaint);
            }
        }
    }

    public static class MiniTopoView extends View {
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint route = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pin = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint white = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path p = new Path();
        private final boolean showPin;

        public MiniTopoView(Context context, boolean showPin) {
            super(context);
            this.showPin = showPin;
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(dp(context, 1));
            line.setColor(withAlpha(BLUE_LIGHT, 45));
            route.setStyle(Paint.Style.STROKE);
            route.setStrokeWidth(dp(context, 2));
            route.setStrokeCap(Paint.Cap.ROUND);
            route.setPathEffect(new android.graphics.DashPathEffect(new float[]{dp(context, 8), dp(context, 7)}, 0));
            route.setColor(Color.rgb(61, 142, 255));
            pin.setColor(Color.rgb(46, 126, 255));
            white.setColor(Color.WHITE);
            white.setStyle(Paint.Style.STROKE);
            white.setStrokeWidth(dp(context, 2));
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            for (int i = -2; i < 14; i++) {
                float baseY = i * h / 9f;
                p.reset();
                p.moveTo(-20, baseY);
                for (int x = 0; x <= w + 30; x += 28) {
                    float y = baseY + (float) Math.sin(x * 0.035 + i) * 12f
                            + (float) Math.cos(x * 0.017 - i) * 8f;
                    p.lineTo(x, y);
                }
                canvas.drawPath(p, line);
            }
            if (showPin) {
                p.reset();
                p.moveTo(w * 0.76f, h * 0.18f);
                p.cubicTo(w * 0.56f, h * 0.28f, w * 0.78f, h * 0.46f, w * 0.55f, h * 0.58f);
                p.cubicTo(w * 0.34f, h * 0.70f, w * 0.54f, h * 0.82f, w * 0.42f, h * 0.96f);
                canvas.drawPath(p, route);
                float cx = w * 0.76f;
                float cy = h * 0.20f;
                canvas.drawCircle(cx, cy + dp(getContext(), 24), dp(getContext(), 28), new Paint(pin));
                Path drop = new Path();
                drop.moveTo(cx, cy + dp(getContext(), 56));
                drop.cubicTo(cx - dp(getContext(), 34), cy + dp(getContext(), 18), cx - dp(getContext(), 28), cy - dp(getContext(), 18), cx, cy - dp(getContext(), 18));
                drop.cubicTo(cx + dp(getContext(), 28), cy - dp(getContext(), 18), cx + dp(getContext(), 34), cy + dp(getContext(), 18), cx, cy + dp(getContext(), 56));
                drop.close();
                canvas.drawPath(drop, pin);
                canvas.drawCircle(cx, cy + dp(getContext(), 5), dp(getContext(), 9), white);
            }
        }
    }

    public static class IconGlyphView extends View {
        private final String type;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        public IconGlyphView(Context context, String type) {
            super(context);
            this.type = type == null ? "dot" : type;
            paint.setColor(Color.rgb(76, 145, 255));
            paint.setStrokeWidth(dp(context, 2));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2f, cy = h / 2f;
            float r = Math.min(w, h) * 0.34f;
            path.reset();
            switch (type) {
                case "target":
                    canvas.drawCircle(cx, cy, r * 0.72f, paint);
                    canvas.drawCircle(cx, cy, r * 0.23f, paint);
                    canvas.drawLine(cx - r, cy, cx - r * 0.52f, cy, paint);
                    canvas.drawLine(cx + r * 0.52f, cy, cx + r, cy, paint);
                    canvas.drawLine(cx, cy - r, cx, cy - r * 0.52f, paint);
                    canvas.drawLine(cx, cy + r * 0.52f, cx, cy + r, paint);
                    break;
                case "grid":
                    for (int i = -1; i <= 1; i++) {
                        for (int j = -1; j <= 1; j++) {
                            canvas.drawRect(cx + i * r * 0.65f - r * 0.17f,
                                    cy + j * r * 0.65f - r * 0.17f,
                                    cx + i * r * 0.65f + r * 0.17f,
                                    cy + j * r * 0.65f + r * 0.17f, paint);
                        }
                    }
                    break;
                case "swap":
                    canvas.drawLine(cx - r, cy - r * 0.4f, cx + r * 0.65f, cy - r * 0.4f, paint);
                    canvas.drawLine(cx + r * 0.65f, cy - r * 0.4f, cx + r * 0.25f, cy - r * 0.8f, paint);
                    canvas.drawLine(cx + r * 0.65f, cy - r * 0.4f, cx + r * 0.25f, cy, paint);
                    canvas.drawLine(cx + r, cy + r * 0.4f, cx - r * 0.65f, cy + r * 0.4f, paint);
                    canvas.drawLine(cx - r * 0.65f, cy + r * 0.4f, cx - r * 0.25f, cy, paint);
                    canvas.drawLine(cx - r * 0.65f, cy + r * 0.4f, cx - r * 0.25f, cy + r * 0.8f, paint);
                    break;
                case "compass":
                    canvas.drawCircle(cx, cy, r * 0.85f, paint);
                    path.moveTo(cx + r * 0.45f, cy - r * 0.6f);
                    path.lineTo(cx + r * 0.10f, cy + r * 0.18f);
                    path.lineTo(cx - r * 0.45f, cy + r * 0.6f);
                    path.lineTo(cx - r * 0.10f, cy - r * 0.18f);
                    path.close();
                    canvas.drawPath(path, paint);
                    break;
                case "angle":
                    canvas.drawLine(cx - r * 0.85f, cy + r * 0.65f, cx + r * 0.75f, cy + r * 0.65f, paint);
                    canvas.drawLine(cx - r * 0.85f, cy + r * 0.65f, cx + r * 0.1f, cy - r * 0.65f, paint);
                    canvas.drawArc(new RectF(cx - r * 0.65f, cy - r * 0.15f, cx + r * 0.25f, cy + r * 0.75f), 205, 72, false, paint);
                    break;
                case "triangle":
                    path.moveTo(cx, cy - r * 0.85f);
                    path.lineTo(cx + r * 0.8f, cy + r * 0.7f);
                    path.lineTo(cx - r * 0.8f, cy + r * 0.7f);
                    path.close();
                    canvas.drawPath(path, paint);
                    break;
                case "slope":
                    canvas.drawLine(cx - r * 0.85f, cy + r * 0.65f, cx + r * 0.55f, cy - r * 0.55f, paint);
                    canvas.drawLine(cx - r * 0.85f, cy + r * 0.65f, cx + r * 0.65f, cy + r * 0.65f, paint);
                    canvas.drawLine(cx + r * 0.55f, cy - r * 0.55f, cx + r * 0.1f, cy - r * 0.5f, paint);
                    canvas.drawLine(cx + r * 0.55f, cy - r * 0.55f, cx + r * 0.52f, cy - r * 0.1f, paint);
                    break;
                case "hair":
                    canvas.drawLine(cx - r * 0.55f, cy - r * 0.7f, cx - r * 0.55f, cy + r * 0.7f, paint);
                    canvas.drawLine(cx + r * 0.55f, cy - r * 0.7f, cx + r * 0.55f, cy + r * 0.7f, paint);
                    canvas.drawCircle(cx - r * 0.55f, cy - r * 0.7f, r * 0.13f, paint);
                    canvas.drawCircle(cx + r * 0.55f, cy - r * 0.7f, r * 0.13f, paint);
                    canvas.drawLine(cx - r * 0.25f, cy, cx + r * 0.25f, cy, paint);
                    break;
                case "polygon":
                    float[] px = {0f, .78f, .52f, -.54f, -.82f};
                    float[] py = {-.86f, -.27f, .75f, .72f, -.22f};
                    for (int i = 0; i < px.length; i++) {
                        int j = (i + 1) % px.length;
                        canvas.drawLine(cx + px[i] * r, cy + py[i] * r, cx + px[j] * r, cy + py[j] * r, paint);
                        canvas.drawCircle(cx + px[i] * r, cy + py[i] * r, r * .12f, paint);
                    }
                    break;
                case "level":
                    canvas.drawRect(cx - r * .75f, cy - r * .45f, cx + r * .75f, cy + r * .05f, paint);
                    canvas.drawCircle(cx, cy - r * .2f, r * .18f, paint);
                    canvas.drawLine(cx - r * .35f, cy + r * .05f, cx - r * .65f, cy + r * .8f, paint);
                    canvas.drawLine(cx + r * .35f, cy + r * .05f, cx + r * .65f, cy + r * .8f, paint);
                    canvas.drawLine(cx, cy + r * .05f, cx, cy + r * .8f, paint);
                    break;
                case "staff":
                    canvas.drawLine(cx, cy - r, cx, cy + r, paint);
                    for (int i = -4; i <= 4; i++) {
                        float y = cy + i * r / 4f;
                        canvas.drawLine(cx, y, cx + (i % 2 == 0 ? r * .45f : r * .28f), y, paint);
                    }
                    break;
                case "pin":
                    canvas.drawCircle(cx, cy - r * .22f, r * .45f, paint);
                    canvas.drawCircle(cx, cy - r * .22f, r * .13f, paint);
                    canvas.drawLine(cx - r * .34f, cy + r * .08f, cx, cy + r * .9f, paint);
                    canvas.drawLine(cx + r * .34f, cy + r * .08f, cx, cy + r * .9f, paint);
                    break;
                case "book":
                    canvas.drawRect(cx - r * .8f, cy - r * .9f, cx + r * .7f, cy + r * .9f, paint);
                    canvas.drawLine(cx - r * .45f, cy - r * .6f, cx + r * .4f, cy - r * .6f, paint);
                    canvas.drawLine(cx - r * .45f, cy - r * .2f, cx + r * .4f, cy - r * .2f, paint);
                    canvas.drawLine(cx - r * .45f, cy + r * .2f, cx + r * .4f, cy + r * .2f, paint);
                    break;
                case "share":
                    canvas.drawCircle(cx - r * .65f, cy, r * .18f, paint);
                    canvas.drawCircle(cx + r * .58f, cy - r * .55f, r * .18f, paint);
                    canvas.drawCircle(cx + r * .58f, cy + r * .55f, r * .18f, paint);
                    canvas.drawLine(cx - r * .47f, cy - r * .05f, cx + r * .4f, cy - r * .48f, paint);
                    canvas.drawLine(cx - r * .47f, cy + r * .05f, cx + r * .4f, cy + r * .48f, paint);
                    break;
                case "satellite":
                    canvas.drawOval(new RectF(cx - r * .35f, cy - r * .2f, cx + r * .25f, cy + r * .25f), paint);
                    canvas.drawLine(cx - r * .05f, cy + r * .2f, cx - r * .35f, cy + r * .75f, paint);
                    canvas.drawLine(cx - r * .65f, cy + r * .75f, cx - r * .05f, cy + r * .75f, paint);
                    canvas.drawArc(new RectF(cx + r * .05f, cy - r * .75f, cx + r * .75f, cy - r * .05f), 205, 75, false, paint);
                    break;
                case "clock":
                    canvas.drawCircle(cx, cy, r * .82f, paint);
                    canvas.drawLine(cx, cy, cx, cy - r * .48f, paint);
                    canvas.drawLine(cx, cy, cx + r * .42f, cy + r * .22f, paint);
                    break;
                default:
                    canvas.drawCircle(cx, cy, r * .55f, paint);
                    break;
            }
        }
    }
}
