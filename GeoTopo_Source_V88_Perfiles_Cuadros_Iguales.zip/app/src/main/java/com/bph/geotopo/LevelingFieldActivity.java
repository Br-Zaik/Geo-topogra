package com.bph.geotopo;

import android.content.ContentResolver;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class LevelingFieldActivity extends BaseToolActivity {
    private static final int REQ_EXPORT = 9520;

    private static final int TYPE_BM_INITIAL = 0;
    private static final int TYPE_INTERMEDIATE = 1;
    private static final int TYPE_CHANGE = 2;
    private static final int TYPE_BM_FINAL = 3;

    private static final int SCREEN_BG = Color.rgb(3, 20, 33);
    private static final int BAR_A = Color.rgb(5, 45, 72);
    private static final int BAR_B = Color.rgb(4, 28, 47);
    private static final int CARD_A = Color.rgb(8, 29, 49);
    private static final int CARD_B = Color.rgb(6, 23, 39);
    private static final int INNER_A = Color.rgb(8, 26, 43);
    private static final int INNER_B = Color.rgb(5, 21, 35);
    private static final int FIELD_BG = Color.rgb(6, 24, 40);
    private static final int FIELD_STROKE = Color.rgb(50, 103, 163);
    private static final int STROKE = Color.rgb(27, 110, 205);
    private static final int PRIMARY_A = Color.rgb(45, 137, 255);
    private static final int PRIMARY_B = Color.rgb(14, 97, 239);
    private static final int TEXT = Color.rgb(244, 248, 252);
    private static final int SUBTEXT = Color.rgb(193, 207, 220);
    private static final int MUTED = Color.rgb(126, 150, 174);
    private static final int BLUE = Color.rgb(50, 145, 255);
    private static final int BLUE_SOFT = Color.rgb(125, 190, 255);
    private static final int GREEN = Color.rgb(75, 226, 119);
    private static final int GREEN_DARK = Color.rgb(25, 86, 54);
    private static final int AMBER = Color.rgb(255, 177, 57);
    private static final int AMBER_DARK = Color.rgb(76, 54, 18);
    private static final int PURPLE = Color.rgb(170, 116, 255);
    private static final int PURPLE_DARK = Color.rgb(57, 35, 84);
    private static final int RED = Color.rgb(255, 107, 107);
    private static final int RED_DARK = Color.rgb(104, 36, 42);

    private EditText startElevation;
    private EditText expectedEnd;
    private EditText toleranceInput;
    private CheckBox distributeCorrection;
    private LinearLayout rowsContainer;
    private final List<LevelRow> rows = new ArrayList<>();
    private String lastCsv;

    private Button typeBmInitial;
    private Button typeIntermediate;
    private Button typeChange;
    private Button typeBmFinal;
    private int newPointType = TYPE_INTERMEDIATE;

    private TextView metricClosure;
    private TextView metricTolerance;
    private TextView metricStatus;
    private TextView metricArithmetic;
    private LinearLayout resultRowsContainer;
    private ProfileView profileView;
    private TextView resultHint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(Color.rgb(1, 13, 24));
            getWindow().setNavigationBarColor(Color.BLACK);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(SCREEN_BG);
        root.addView(buildTopBar(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setBackgroundColor(SCREEN_BG);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundColor(SCREEN_BG);
        content.setPadding(dp(11), dp(12), dp(11), dp(28));

        content.addView(buildConfigurationCard());
        content.addView(buildReadingsCard());
        content.addView(buildResultsCard());

        scroll.addView(content, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        // Initial notebook structure shown by the approved design.
        addRow(TYPE_BM_INITIAL, "BM-1");
        addRow(TYPE_INTERMEDIATE, "P1");
        addRow(TYPE_CHANGE, "PC1");
        addRow(TYPE_BM_FINAL, "BM-2");
        setNewPointType(TYPE_INTERMEDIATE);
        resetResults();
    }

    private View buildTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(7), dp(7), dp(8), dp(8));
        bar.setBackground(gradient(BAR_A, BAR_B, 0, 0, 0));

        TextView back = label("‹", 34f, true, Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(50), dp(54)));

        TextView tripod = label("⌖", 22f, true, BLUE);
        tripod.setGravity(Gravity.CENTER);
        tripod.setBackground(gradient(Color.rgb(9, 38, 64), Color.rgb(7, 27, 45), 14, 1, FIELD_STROKE));
        bar.addView(tripod, new LinearLayout.LayoutParams(dp(42), dp(42)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(9), 0, 0, 0);
        titles.addView(label("Nivelación de campo", 21.3f, true, TEXT));
        TextView subtitle = label("Método de altura de instrumento con control de cierre", 12.5f, false, Color.rgb(214, 226, 237));
        subtitle.setLineSpacing(0, 1.03f);
        titles.addView(subtitle);
        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView export = label("▤", 20f, true, Color.WHITE);
        export.setGravity(Gravity.CENTER);
        export.setOnClickListener(v -> export());
        export.setBackground(gradient(Color.rgb(8, 31, 51), Color.rgb(7, 25, 41), 12, 1, Color.rgb(42, 77, 113)));
        bar.addView(export, new LinearLayout.LayoutParams(dp(40), dp(40)));

        TextView more = label("⋮", 25f, true, SUBTEXT);
        more.setGravity(Gravity.CENTER);
        more.setOnClickListener(v -> showToast("VA = vista atrás · VI = vista intermedia · VD = vista adelante"));
        bar.addView(more, new LinearLayout.LayoutParams(dp(34), dp(40)));
        return bar;
    }

    private View buildHowToCard() {
        LinearLayout card = sectionCard();
        card.addView(sectionHead("ⓘ", "Cómo se usa"));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutParams(blockLp(0, 8, 0, 0));
        row.addView(stepCard("1", "⌖", "Coloca el instrumento\ny nivélalo."), weighted(1f, 0, 0, 4, 0));
        row.addView(stepCard("2", "│", "Mide VA (atrás)\nen el punto actual."), weighted(1f, 4, 0, 4, 0));
        row.addView(stepCard("3", "◎", "Mide VI o VD en el\npunto siguiente."), weighted(1f, 4, 0, 4, 0));
        row.addView(stepCard("4", "✓", "Repite hasta el BM final\ny calcula resultados."), weighted(1f, 4, 0, 0, 0));
        card.addView(row);
        return card;
    }

    private View buildConfigurationCard() {
        LinearLayout card = sectionCard();
        card.addView(sectionHead("⚙", "Configuración"));

        startElevation = numericInput("100.000");
        expectedEnd = numericInput("—");
        toleranceInput = numericInput("0.010");
        toleranceInput.setText("0.010");

        if (ResponsiveUi.isNarrow(this)) {
            LinearLayout valuesA = new LinearLayout(this);
            valuesA.setOrientation(LinearLayout.HORIZONTAL);
            valuesA.setLayoutParams(blockLp(0, 8, 0, 4));
            valuesA.addView(field("Cota inicial", startElevation, "m"), equalField());
            valuesA.addView(field("Cota final conocida", expectedEnd, "m"), equalField());
            card.addView(valuesA);
            LinearLayout valuesB = new LinearLayout(this);
            valuesB.setOrientation(LinearLayout.HORIZONTAL);
            valuesB.setLayoutParams(blockLp(0, 0, 0, 4));
            valuesB.addView(field("Tolerancia de cierre", toleranceInput, "m"), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            card.addView(valuesB);
        } else {
            LinearLayout values = new LinearLayout(this);
            values.setOrientation(LinearLayout.HORIZONTAL);
            values.setLayoutParams(blockLp(0, 8, 0, 4));
            values.addView(field("Cota inicial", startElevation, "m"), equalField());
            values.addView(field("Cota final conocida (opcional)", expectedEnd, "m"), equalField());
            values.addView(field("Tolerancia de cierre", toleranceInput, "m"), equalField());
            card.addView(values);
        }

        TextView typeTitle = label("Nuevo punto", 13f, true, SUBTEXT);
        typeTitle.setLayoutParams(blockLp(2, 8, 2, 5));
        card.addView(typeTitle);

        typeBmInitial = typeSelector("⌖  BM inicial");
        typeIntermediate = typeSelector("•—•  Intermedio");
        typeChange = typeSelector("⇄  Punto de cambio");
        typeBmFinal = typeSelector("⚑  BM final");
        typeBmInitial.setOnClickListener(v -> setNewPointType(TYPE_BM_INITIAL));
        typeIntermediate.setOnClickListener(v -> setNewPointType(TYPE_INTERMEDIATE));
        typeChange.setOnClickListener(v -> setNewPointType(TYPE_CHANGE));
        typeBmFinal.setOnClickListener(v -> setNewPointType(TYPE_BM_FINAL));
        if (ResponsiveUi.isNarrow(this)) {
            LinearLayout selectorA = new LinearLayout(this);
            selectorA.setOrientation(LinearLayout.HORIZONTAL);
            selectorA.setLayoutParams(blockLp(0, 0, 0, 4));
            selectorA.addView(typeBmInitial, equalButton());
            selectorA.addView(typeIntermediate, equalButton());
            card.addView(selectorA);
            LinearLayout selectorB = new LinearLayout(this);
            selectorB.setOrientation(LinearLayout.HORIZONTAL);
            selectorB.setLayoutParams(blockLp(0, 0, 0, 6));
            selectorB.addView(typeChange, equalButton());
            selectorB.addView(typeBmFinal, equalButton());
            card.addView(selectorB);
        } else {
            LinearLayout selector = new LinearLayout(this);
            selector.setOrientation(LinearLayout.HORIZONTAL);
            selector.setLayoutParams(blockLp(0, 0, 0, 6));
            selector.addView(typeBmInitial, equalButton());
            selector.addView(typeIntermediate, equalButton());
            selector.addView(typeChange, equalButton());
            selector.addView(typeBmFinal, equalButton());
            card.addView(selector);
        }

        distributeCorrection = new CheckBox(this);
        distributeCorrection.setText("Distribuir corrección");
        distributeCorrection.setTextColor(TEXT);
        distributeCorrection.setChecked(true);
        distributeCorrection.setButtonTintList(ColorStateList.valueOf(BLUE));
        card.addView(distributeCorrection);

        TextView helper = label("Si conoces la cota final, la app reparte el cierre en las cotas.", 12.0f, false, SUBTEXT);
        helper.setPadding(dp(34), 0, 0, 0);
        helper.setLayoutParams(blockLp(0, 2, 0, 0));
        card.addView(helper);
        return card;
    }

    private LinearLayout.LayoutParams equalField() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    private LinearLayout.LayoutParams equalButton() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(54), 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    private View buildReadingsCard() {
        LinearLayout card = sectionCard();
        card.addView(sectionHead("▦", "Lecturas"));

        rowsContainer = new LinearLayout(this);
        rowsContainer.setOrientation(LinearLayout.VERTICAL);
        if (ResponsiveUi.isNarrow(this)) {
            TextView helper = label("Cada punto muestra solo sus campos útiles. VA = atrás · VI = intermedia · VD = adelante.", 11.8f, false, SUBTEXT);
            helper.setLayoutParams(blockLp(2, 4, 2, 8));
            card.addView(helper);
            card.addView(rowsContainer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        } else {
            HorizontalScrollView hsv = new HorizontalScrollView(this);
            hsv.setHorizontalScrollBarEnabled(true);
            LinearLayout table = new LinearLayout(this);
            table.setOrientation(LinearLayout.VERTICAL);
            table.setPadding(dp(6), dp(6), dp(6), dp(6));
            table.setBackground(gradient(INNER_A, INNER_B, 12, 1, FIELD_STROKE));

            LinearLayout head = new LinearLayout(this);
            head.setOrientation(LinearLayout.HORIZONTAL);
            head.addView(headerCell("#", 42));
            head.addView(headerCell("Punto", 104));
            head.addView(headerCell("Dist. acumulada (m)", 132));
            head.addView(headerCell("VA (m)", 82));
            head.addView(headerCell("VI (m)", 82));
            head.addView(headerCell("VD (m)", 82));
            head.addView(headerCell("Tipo", 128));
            table.addView(head);
            table.addView(rowsContainer);
            hsv.addView(table, new HorizontalScrollView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            card.addView(hsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        Button add = outlineButton("+ Punto", BLUE_SOFT, BLUE);
        Button remove = outlineButton("− Punto", BLUE_SOFT, BLUE);
        Button clear = outlineButton("Limpiar", TEXT, Color.rgb(62, 80, 100));
        Button calc = primaryAction("▦  Calcular nivelación");
        add.setOnClickListener(v -> addRow(newPointType, defaultNameForNewRow(newPointType)));
        remove.setOnClickListener(v -> removeRow());
        clear.setOnClickListener(v -> clear());
        calc.setOnClickListener(v -> calculate());
        if (ResponsiveUi.isNarrow(this)) {
            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            actions.setLayoutParams(blockLp(0, 8, 0, 4));
            actions.addView(add, weighted(1f, 0, 0, 4, 0));
            actions.addView(remove, weighted(1f, 4, 0, 4, 0));
            actions.addView(clear, weighted(1f, 4, 0, 0, 0));
            card.addView(actions);
            LinearLayout calcRow = new LinearLayout(this);
            calcRow.setOrientation(LinearLayout.HORIZONTAL);
            calcRow.setLayoutParams(blockLp(0, 0, 0, 0));
            calcRow.addView(calc, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            card.addView(calcRow);
        } else {
            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            actions.setLayoutParams(blockLp(0, 8, 0, 0));
            actions.addView(add, weighted(0.8f, 0, 0, 4, 0));
            actions.addView(remove, weighted(0.8f, 4, 0, 4, 0));
            actions.addView(clear, weighted(0.95f, 4, 0, 4, 0));
            actions.addView(calc, weighted(1.65f, 4, 0, 0, 0));
            card.addView(actions);
        }
        return card;
    }

    private View buildResultsCard() {
        LinearLayout card = sectionCard();
        card.addView(sectionHead("⌁", "Resultados"));

        if (ResponsiveUi.isNarrow(this)) {
            LinearLayout kpiA = new LinearLayout(this);
            kpiA.setOrientation(LinearLayout.HORIZONTAL);
            kpiA.setLayoutParams(blockLp(0, 8, 0, 4));
            metricClosure = metricBox(kpiA, "Error de cierre", "—", 1f, 0, 0, 4, 0);
            metricTolerance = metricBox(kpiA, "Tolerancia", "±0.010 m", 1f, 4, 0, 0, 0);
            card.addView(kpiA);
            LinearLayout kpiB = new LinearLayout(this);
            kpiB.setOrientation(LinearLayout.HORIZONTAL);
            kpiB.setLayoutParams(blockLp(0, 0, 0, 4));
            metricStatus = metricBox(kpiB, "Estado", "SIN CÁLCULO", 1f, 0, 0, 0, 0);
            card.addView(kpiB);
            LinearLayout kpiC = new LinearLayout(this);
            kpiC.setOrientation(LinearLayout.HORIZONTAL);
            kpiC.setLayoutParams(blockLp(0, 0, 0, 8));
            metricArithmetic = metricBox(kpiC, "ΣVA - ΣVD", "—", 1f, 0, 0, 0, 0);
            card.addView(kpiC);
            resultRowsContainer = new LinearLayout(this);
            resultRowsContainer.setOrientation(LinearLayout.VERTICAL);
            card.addView(resultRowsContainer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        } else {
            LinearLayout kpis = new LinearLayout(this);
            kpis.setOrientation(LinearLayout.HORIZONTAL);
            kpis.setLayoutParams(blockLp(0, 8, 0, 8));
            metricClosure = metricBox(kpis, "Error de cierre", "—", 1f, 0, 0, 4, 0);
            metricTolerance = metricBox(kpis, "Tolerancia", "±0.010 m", 1f, 4, 0, 4, 0);
            metricStatus = metricBox(kpis, "Estado", "SIN CÁLCULO", 1.15f, 4, 0, 4, 0);
            metricArithmetic = metricBox(kpis, "ΣVA - ΣVD", "—", 1f, 4, 0, 0, 0);
            card.addView(kpis);

            HorizontalScrollView resultsHsv = new HorizontalScrollView(this);
            resultsHsv.setHorizontalScrollBarEnabled(true);
            LinearLayout resultTable = new LinearLayout(this);
            resultTable.setOrientation(LinearLayout.VERTICAL);
            resultTable.setBackground(gradient(INNER_A, INNER_B, 11, 1, FIELD_STROKE));
            LinearLayout resultHeader = new LinearLayout(this);
            resultHeader.setOrientation(LinearLayout.HORIZONTAL);
            resultHeader.addView(headerCell("Punto", 108));
            resultHeader.addView(headerCell("H.I. (m)", 112));
            resultHeader.addView(headerCell("Cota (m)", 112));
            resultHeader.addView(headerCell("Corrección (m)", 132));
            resultHeader.addView(headerCell("Cota ajustada (m)", 150));
            resultTable.addView(resultHeader);
            resultRowsContainer = new LinearLayout(this);
            resultRowsContainer.setOrientation(LinearLayout.VERTICAL);
            resultTable.addView(resultRowsContainer);
            resultsHsv.addView(resultTable, new HorizontalScrollView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            card.addView(resultsHsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        LinearLayout profileCard = new LinearLayout(this);
        profileCard.setOrientation(LinearLayout.VERTICAL);
        profileCard.setPadding(dp(10), dp(10), dp(10), dp(10));
        profileCard.setBackground(gradient(INNER_A, INNER_B, 12, 1, FIELD_STROKE));
        profileCard.setLayoutParams(blockLp(0, 10, 0, 0));
        TextView profileTitle = label("Perfil longitudinal (Cota vs Distancia)", 14.4f, true, TEXT);
        profileCard.addView(profileTitle);
        profileView = new ProfileView(this);
        profileCard.addView(profileView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ResponsiveUi.isNarrow(this) ? dp(168) : dp(230)));
        card.addView(profileCard);

        resultHint = infoNote("Completa la libreta y presiona “Calcular nivelación”.");
        card.addView(resultHint);
        return card;
    }

    private void setNewPointType(int type) {
        newPointType = type;
        styleTypeSelector(typeBmInitial, type == TYPE_BM_INITIAL, TYPE_BM_INITIAL);
        styleTypeSelector(typeIntermediate, type == TYPE_INTERMEDIATE, TYPE_INTERMEDIATE);
        styleTypeSelector(typeChange, type == TYPE_CHANGE, TYPE_CHANGE);
        styleTypeSelector(typeBmFinal, type == TYPE_BM_FINAL, TYPE_BM_FINAL);
    }

    private void addRow(int type, String defaultName) {
        final int index = rows.size() + 1;
        EditText point = compactTextInput(defaultName);
        if (defaultName != null && !defaultName.isEmpty()) point.setText(defaultName);
        EditText distance = compactNumberInput(index == 1 ? "0.000" : "—");
        if (index == 1) distance.setText("0.000");
        EditText bs = compactNumberInput("—");
        EditText is = compactNumberInput("—");
        EditText fs = compactNumberInput("—");

        Button typeButton = new Button(this);
        typeButton.setAllCaps(false);
        typeButton.setPadding(dp(5), 0, dp(5), 0);
        typeButton.setMinWidth(0);
        typeButton.setMinimumWidth(0);
        typeButton.setGravity(Gravity.CENTER);
        ResponsiveUi.configureCompactText(typeButton, 11.6f, 9.5f, 2);
        if (Build.VERSION.SDK_INT >= 21) typeButton.setStateListAnimator(null);

        LinearLayout container;
        TextView number;
        if (ResponsiveUi.isNarrow(this)) {
            container = new LinearLayout(this);
            container.setOrientation(LinearLayout.VERTICAL);
            container.setPadding(dp(8), dp(8), dp(8), dp(8));
            container.setBackground(gradient(INNER_A, INNER_B, 12, 1, FIELD_STROKE));
            container.setLayoutParams(blockLp(0, 0, 0, 8));

            LinearLayout top = new LinearLayout(this);
            top.setOrientation(LinearLayout.HORIZONTAL);
            top.setGravity(Gravity.CENTER_VERTICAL);
            top.setLayoutParams(blockLp(0, 0, 0, 6));
            number = tableCell(String.valueOf(index), 40, true, TEXT);
            top.addView(number);
            LinearLayout pointBox = miniLabeled("Punto", point);
            top.addView(pointBox, weighted(1f, 6, 0, 0, 0));
            container.addView(top);

            LinearLayout middle = new LinearLayout(this);
            middle.setOrientation(LinearLayout.HORIZONTAL);
            middle.setLayoutParams(blockLp(0, 0, 0, 6));
            middle.addView(miniLabeled("Dist. acumulada (m)", distance), weighted(1f, 0, 0, 4, 0));
            LinearLayout typeBox = new LinearLayout(this);
            typeBox.setOrientation(LinearLayout.VERTICAL);
            TextView typeLabel = label("Tipo", 10.6f, true, SUBTEXT);
            typeLabel.setPadding(dp(2), 0, 0, dp(3));
            typeBox.addView(typeLabel);
            LinearLayout.LayoutParams typeLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
            typeButton.setLayoutParams(typeLp);
            typeBox.addView(typeButton);
            middle.addView(typeBox, weighted(1f, 4, 0, 0, 0));
            container.addView(middle);

            LinearLayout readings = new LinearLayout(this);
            readings.setOrientation(LinearLayout.HORIZONTAL);
            readings.setLayoutParams(blockLp(0, 0, 0, 0));
            readings.addView(miniLabeled("VA (m)", bs), weighted(1f, 0, 0, 4, 0));
            readings.addView(miniLabeled("VI (m)", is), weighted(1f, 4, 0, 4, 0));
            readings.addView(miniLabeled("VD (m)", fs), weighted(1f, 4, 0, 0, 0));
            container.addView(readings);
        } else {
            container = new LinearLayout(this);
            container.setOrientation(LinearLayout.HORIZONTAL);
            container.setGravity(Gravity.CENTER_VERTICAL);
            container.setLayoutParams(blockLp(0, 0, 0, 4));
            number = tableCell(String.valueOf(index), 42, true, TEXT);
            container.addView(number);
            container.addView(inputCell(point, 104, true));
            container.addView(inputCell(distance, 132, true));
            container.addView(inputCell(bs, 82, false));
            container.addView(inputCell(is, 82, false));
            container.addView(inputCell(fs, 82, false));
            LinearLayout.LayoutParams typeLp = new LinearLayout.LayoutParams(dp(128), dp(44));
            typeLp.setMargins(dp(2), dp(2), dp(2), dp(2));
            typeButton.setLayoutParams(typeLp);
            container.addView(typeButton);
        }

        LevelRow levelRow = new LevelRow(container, number, point, distance, bs, is, fs, typeButton, type);
        typeButton.setOnClickListener(v -> {
            levelRow.type = (levelRow.type + 1) % 4;
            applyRowType(levelRow);
        });
        rows.add(levelRow);
        rowsContainer.addView(container);
        applyRowType(levelRow);
        renumberRows();
    }

    private LinearLayout miniLabeled(String labelText, EditText input) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        TextView label = label(labelText, 10.6f, true, SUBTEXT);
        label.setPadding(dp(2), 0, 0, dp(3));
        box.addView(label);
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        box.addView(input, inputLp);
        return box;
    }

    private void applyRowType(LevelRow row) {
        row.bs.setEnabled(row.type == TYPE_BM_INITIAL || row.type == TYPE_CHANGE);
        row.is.setEnabled(row.type == TYPE_INTERMEDIATE);
        row.fs.setEnabled(row.type == TYPE_CHANGE || row.type == TYPE_BM_FINAL);

        styleDisabledInput(row.bs, row.bs.isEnabled());
        styleDisabledInput(row.is, row.is.isEnabled());
        styleDisabledInput(row.fs, row.fs.isEnabled());

        int color = typeColor(row.type);
        int dark = typeDarkColor(row.type);
        row.typeButton.setText(typeLabel(row.type));
        row.typeButton.setTextColor(color);
        row.typeButton.setBackground(gradient(dark, dark, 10, 1, color));

        // Prevent obsolete values from a previous type from contaminating the calculation.
        if (!row.bs.isEnabled()) row.bs.setText("");
        if (!row.is.isEnabled()) row.is.setText("");
        if (!row.fs.isEnabled()) row.fs.setText("");
    }

    private void styleDisabledInput(EditText input, boolean enabled) {
        input.setTextColor(enabled ? TEXT : MUTED);
        input.setHintTextColor(enabled ? MUTED : Color.rgb(76, 92, 109));
        input.setAlpha(enabled ? 1f : 0.58f);
    }

    private void removeRow() {
        if (rows.size() <= 2) {
            showToast("Conserva al menos dos puntos.");
            return;
        }
        LevelRow row = rows.remove(rows.size() - 1);
        rowsContainer.removeView(row.container);
        renumberRows();
        resetResults();
    }

    private void renumberRows() {
        for (int i = 0; i < rows.size(); i++) {
            rows.get(i).number.setText(String.valueOf(i + 1));
        }
    }

    private void clear() {
        startElevation.setText("");
        expectedEnd.setText("");
        toleranceInput.setText("0.010");
        for (int i = 0; i < rows.size(); i++) {
            LevelRow row = rows.get(i);
            row.point.setText(defaultPointNameForRow(i, row.type));
            row.distance.setText(i == 0 ? "0.000" : "");
            row.bs.setText("");
            row.is.setText("");
            row.fs.setText("");
        }
        lastCsv = null;
        resetResults();
    }

    private void calculate() {
        try {
            if (blank(startElevation)) throw new IllegalArgumentException();
            double start = parse(startElevation);
            double tolerance = blank(toleranceInput) ? 0.010 : Math.abs(parse(toleranceInput));
            if (tolerance <= 0) throw new IllegalArgumentException();

            double currentElevation = start;
            double hi = Double.NaN;
            double sumBS = 0;
            double sumFS = 0;
            double lastDistance = 0;
            List<Computed> computed = new ArrayList<>();

            for (int i = 0; i < rows.size(); i++) {
                LevelRow r = rows.get(i);
                String point = r.point.getText().toString().trim();
                if (point.isEmpty()) point = defaultPointNameForRow(i, r.type);
                double distance = blank(r.distance) ? lastDistance : parse(r.distance);
                if (distance < lastDistance) throw new IllegalArgumentException();
                lastDistance = distance;

                Double bs = null;
                Double is = null;
                Double fs = null;
                double rowHi = hi;
                double elevation;

                if (r.type == TYPE_BM_INITIAL) {
                    if (blank(r.bs)) {
                        // Empty unused default row can be skipped, except the first row.
                        if (i == 0) throw new IllegalArgumentException();
                        continue;
                    }
                    bs = parse(r.bs);
                    elevation = computed.isEmpty() ? start : currentElevation;
                    hi = elevation + bs;
                    rowHi = hi;
                    sumBS += bs;
                } else if (r.type == TYPE_INTERMEDIATE) {
                    if (blank(r.is)) continue;
                    if (Double.isNaN(hi)) throw new IllegalArgumentException();
                    is = parse(r.is);
                    elevation = hi - is;
                    rowHi = hi;
                    currentElevation = elevation;
                } else if (r.type == TYPE_CHANGE) {
                    if (blank(r.fs) && blank(r.bs)) continue;
                    if (blank(r.fs) || blank(r.bs) || Double.isNaN(hi)) throw new IllegalArgumentException();
                    fs = parse(r.fs);
                    bs = parse(r.bs);
                    elevation = hi - fs;
                    sumFS += fs;
                    currentElevation = elevation;
                    hi = elevation + bs;
                    rowHi = hi;
                    sumBS += bs;
                } else {
                    if (blank(r.fs)) continue;
                    if (Double.isNaN(hi)) throw new IllegalArgumentException();
                    fs = parse(r.fs);
                    elevation = hi - fs;
                    rowHi = hi;
                    sumFS += fs;
                    currentElevation = elevation;
                }

                if (computed.isEmpty() && r.type != TYPE_BM_INITIAL) throw new IllegalArgumentException();
                if (r.type == TYPE_BM_INITIAL) currentElevation = elevation;
                computed.add(new Computed(point, r.type, distance, bs, is, fs, rowHi, elevation));
            }

            if (computed.size() < 2) throw new IllegalArgumentException();
            double finalElevation = computed.get(computed.size() - 1).elevation;
            double arithmetic = sumBS - sumFS;
            double observedDifference = finalElevation - start;
            boolean arithmeticOk = Math.abs(arithmetic - observedDifference) <= 0.0015;
            boolean hasKnownEnd = !blank(expectedEnd);
            double closure = hasKnownEnd ? finalElevation - parse(expectedEnd) : 0.0;
            boolean acceptable = !hasKnownEnd || Math.abs(closure) <= tolerance;
            double totalDistance = computed.get(computed.size() - 1).distance;

            StringBuilder csv = new StringBuilder("punto,tipo,distancia,VA,VI,VD,HI,cota_observada,correccion,cota_ajustada\n");
            List<ProfilePoint> profilePoints = new ArrayList<>();
            resultRowsContainer.removeAllViews();

            int count = computed.size();
            for (int i = 0; i < count; i++) {
                Computed c = computed.get(i);
                double ratio;
                if (totalDistance > 0) ratio = c.distance / totalDistance;
                else ratio = count <= 1 ? 0 : (double) i / (count - 1);
                double correction = (hasKnownEnd && distributeCorrection.isChecked()) ? -closure * ratio : 0.0;
                double adjusted = c.elevation + correction;
                c.correction = correction;
                c.adjusted = adjusted;

                resultRowsContainer.addView(resultRow(c));
                profilePoints.add(new ProfilePoint(c.point, c.distance, adjusted, typeColor(c.type)));
                csv.append(csvCell(c.point)).append(',')
                        .append(csvCell(typeLabel(c.type))).append(',')
                        .append(f3(c.distance)).append(',')
                        .append(value(c.bs)).append(',')
                        .append(value(c.is)).append(',')
                        .append(value(c.fs)).append(',')
                        .append(Double.isNaN(c.hi) ? "" : f3(c.hi)).append(',')
                        .append(f3(c.elevation)).append(',')
                        .append(f3(correction)).append(',')
                        .append(f3(adjusted)).append('\n');
            }

            metricClosure.setText(hasKnownEnd ? signed(closure) + " m" : "—");
            metricClosure.setTextColor(hasKnownEnd ? (acceptable ? GREEN : RED) : TEXT);
            metricTolerance.setText("±" + f3(tolerance) + " m");
            metricTolerance.setTextColor(TEXT);
            metricStatus.setText(hasKnownEnd ? (acceptable ? "ACEPTABLE ✓" : "FUERA DE TOLERANCIA") : "SIN CIERRE");
            metricStatus.setTextColor(hasKnownEnd ? (acceptable ? GREEN : RED) : BLUE_SOFT);
            metricArithmetic.setText(signed(arithmetic) + " m");
            metricArithmetic.setTextColor(arithmeticOk ? TEXT : RED);

            if (hasKnownEnd) {
                resultHint.setText((acceptable ? "Cierre dentro de tolerancia. " : "El cierre supera la tolerancia. ")
                        + (distributeCorrection.isChecked() ? "Se muestran cotas ajustadas." : "La distribución de corrección está desactivada."));
                resultHint.setTextColor(acceptable ? BLUE_SOFT : RED);
            } else {
                resultHint.setText("Sin cota final conocida no se evalúa error de cierre. Control aritmético: " + (arithmeticOk ? "CORRECTO" : "REVISAR") + ".");
                resultHint.setTextColor(arithmeticOk ? BLUE_SOFT : RED);
            }

            lastCsv = csv.toString();
            profileView.setPoints(profilePoints);
        } catch (Exception e) {
            lastCsv = null;
            resetResults();
            resultHint.setText("Revisa la libreta: BM inicial usa VA; intermedio usa VI; punto de cambio usa VD y VA; BM final usa VD. Las distancias deben ser acumuladas.");
            resultHint.setTextColor(RED);
        }
    }

    private void resetResults() {
        if (metricClosure == null) return;
        metricClosure.setText("—");
        metricClosure.setTextColor(TEXT);
        metricTolerance.setText("±" + (toleranceInput == null || blank(toleranceInput) ? "0.010" : toleranceInput.getText().toString()) + " m");
        metricTolerance.setTextColor(TEXT);
        metricStatus.setText("SIN CÁLCULO");
        metricStatus.setTextColor(BLUE_SOFT);
        metricArithmetic.setText("—");
        metricArithmetic.setTextColor(TEXT);
        resultRowsContainer.removeAllViews();
        resultRowsContainer.addView(emptyResultRow());
        profileView.setPoints(new ArrayList<>());
        resultHint.setText("Completa la libreta y presiona “Calcular nivelación”.");
        resultHint.setTextColor(SUBTEXT);
    }

    private View resultRow(Computed c) {
        if (ResponsiveUi.isNarrow(this)) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(9), dp(8), dp(9), dp(8));
            card.setBackground(gradient(INNER_A, INNER_B, 11, 1, FIELD_STROKE));
            card.setLayoutParams(blockLp(0, 0, 0, 7));
            TextView name = label(c.point + " · " + typeLabel(c.type), 13.2f, true, TEXT);
            card.addView(name);
            LinearLayout rowA = new LinearLayout(this);
            rowA.setOrientation(LinearLayout.HORIZONTAL);
            rowA.addView(resultMetricSmall("H.I.", Double.isNaN(c.hi) ? "—" : f3(c.hi)), weighted(1f, 0, 4, 4, 0));
            rowA.addView(resultMetricSmall("Cota", f3(c.elevation)), weighted(1f, 4, 4, 0, 0));
            card.addView(rowA);
            LinearLayout rowB = new LinearLayout(this);
            rowB.setOrientation(LinearLayout.HORIZONTAL);
            rowB.addView(resultMetricSmall("Corrección", signed(c.correction)), weighted(1f, 0, 4, 4, 0));
            rowB.addView(resultMetricSmall("Cota ajustada", f3(c.adjusted)), weighted(1f, 4, 4, 0, 0));
            card.addView(rowB);
            return card;
        }
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(dataCell(c.point, 108, true, TEXT));
        row.addView(dataCell(Double.isNaN(c.hi) ? "—" : f3(c.hi), 112, false, TEXT));
        row.addView(dataCell(f3(c.elevation), 112, false, TEXT));
        row.addView(dataCell(signed(c.correction), 132, false, c.correction == 0 ? SUBTEXT : GREEN));
        row.addView(dataCell(f3(c.adjusted), 150, false, TEXT));
        return row;
    }

    private View emptyResultRow() {
        if (ResponsiveUi.isNarrow(this)) {
            TextView empty = infoNote("Aún no hay resultados calculados.");
            empty.setLayoutParams(blockLp(0, 0, 0, 6));
            return empty;
        }
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(dataCell("—", 108, false, MUTED));
        row.addView(dataCell("—", 112, false, MUTED));
        row.addView(dataCell("—", 112, false, MUTED));
        row.addView(dataCell("—", 132, false, MUTED));
        row.addView(dataCell("—", 150, false, MUTED));
        return row;
    }

    private LinearLayout resultMetricSmall(String titleText, String valueText) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(8), dp(7), dp(8), dp(7));
        box.setBackground(gradient(FIELD_BG, FIELD_BG, 9, 1, Color.rgb(40, 74, 115)));
        TextView title = label(titleText, 10.5f, false, SUBTEXT);
        TextView value = label(valueText, 12.4f, true, TEXT);
        box.addView(title);
        box.addView(value);
        return box;
    }

    private String value(Double d) {
        return d == null ? "" : f3(d);
    }

    private String csvCell(String value) {
        return '"' + value.replace("\"", "\"\"") + '"';
    }

    private void export() {
        if (lastCsv == null) calculate();
        if (lastCsv == null) {
            showToast("Primero calcula una nivelación válida.");
            return;
        }
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/csv");
        intent.putExtra(Intent.EXTRA_TITLE,
                "GeoTopo_Nivelacion_" + new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date()) + ".csv");
        startActivityForResult(intent, REQ_EXPORT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_EXPORT && resultCode == RESULT_OK && data != null && data.getData() != null && lastCsv != null) {
            try {
                ContentResolver resolver = getContentResolver();
                Uri uri = data.getData();
                OutputStream out = resolver.openOutputStream(uri);
                if (out == null) throw new IllegalStateException();
                out.write(lastCsv.getBytes(StandardCharsets.UTF_8));
                out.close();
                showToast("Nivelación exportada.");
            } catch (Exception e) {
                showToast("No se pudo exportar.");
            }
        }
    }

    private LinearLayout sectionCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(12), dp(12), dp(12));
        card.setBackground(gradient(CARD_A, CARD_B, 18, 1, STROKE));
        if (Build.VERSION.SDK_INT >= 21) card.setElevation(dp(1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(12));
        card.setLayoutParams(lp);
        return card;
    }

    private LinearLayout sectionHead(String iconText, String titleText) {
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = label(iconText, 17f, true, BLUE);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(gradient(Color.rgb(15, 46, 78), Color.rgb(9, 31, 52), 12, 1, FIELD_STROKE));
        head.addView(icon, new LinearLayout.LayoutParams(dp(36), dp(36)));
        TextView title = label(titleText, 18.3f, true, TEXT);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        titleLp.setMargins(dp(10), 0, 0, 0);
        head.addView(title, titleLp);
        return head;
    }

    private View stepCard(String number, String icon, String text) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(5), dp(7), dp(5), dp(8));
        box.setBackground(gradient(INNER_A, INNER_B, 13, 1, Color.rgb(40, 83, 129)));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView badge = label(number, 12.5f, true, Color.WHITE);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(gradient(PRIMARY_A, PRIMARY_B, 12, 0, 0));
        top.addView(badge, new LinearLayout.LayoutParams(dp(27), dp(27)));
        TextView symbol = label(icon, 21f, true, TEXT);
        symbol.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams symbolLp = new LinearLayout.LayoutParams(dp(38), dp(32));
        symbolLp.setMargins(dp(5), 0, 0, 0);
        top.addView(symbol, symbolLp);
        box.addView(top);

        TextView body = label(text, 11.7f, false, SUBTEXT);
        body.setGravity(Gravity.CENTER);
        body.setLineSpacing(0, 1.1f);
        body.setLayoutParams(blockLp(0, 7, 0, 0));
        box.addView(body);
        return box;
    }

    private LinearLayout field(String title, EditText input, String unit) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        TextView label = label(title, 12.1f, false, SUBTEXT);
        label.setLayoutParams(blockLp(2, 0, 2, 5));
        box.addView(label);

        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.HORIZONTAL);
        shell.setGravity(Gravity.CENTER_VERTICAL);
        shell.setPadding(dp(10), 0, dp(10), 0);
        shell.setBackground(gradient(FIELD_BG, FIELD_BG, 11, 1, FIELD_STROKE));
        input.setBackgroundColor(Color.TRANSPARENT);
        input.setPadding(0, 0, dp(8), 0);
        shell.addView(input, new LinearLayout.LayoutParams(0, dp(52), 1f));
        TextView suffix = label(unit, 12.4f, false, SUBTEXT);
        shell.addView(suffix);
        box.addView(shell);
        return box;
    }

    private EditText numericInput(String hint) {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setSingleLine(true);
        input.setHint(hint);
        input.setHintTextColor(MUTED);
        input.setTextColor(TEXT);
        ResponsiveUi.configureText(input, 14.2f);
        return input;
    }

    private EditText compactNumberInput(String hint) {
        EditText input = numericInput(hint);
        input.setGravity(Gravity.CENTER);
        input.setPadding(dp(4), 0, dp(4), 0);
        ResponsiveUi.configureText(input, 13.2f);
        return input;
    }

    private EditText compactTextInput(String hint) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint(hint);
        input.setHintTextColor(MUTED);
        input.setTextColor(TEXT);
        input.setGravity(Gravity.CENTER);
        input.setPadding(dp(4), 0, dp(4), 0);
        input.setBackgroundColor(Color.TRANSPARENT);
        ResponsiveUi.configureText(input, 13.2f);
        return input;
    }

    private View inputCell(EditText input, int widthDp, boolean blueBorder) {
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.HORIZONTAL);
        shell.setGravity(Gravity.CENTER);
        shell.setPadding(dp(2), dp(2), dp(2), dp(2));
        shell.setBackground(gradient(FIELD_BG, FIELD_BG, 8, 1, blueBorder ? STROKE : Color.rgb(46, 72, 99)));
        input.setBackgroundColor(Color.TRANSPARENT);
        shell.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(widthDp), dp(44));
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        shell.setLayoutParams(lp);
        return shell;
    }

    private Button typeSelector(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(4), 0, dp(4), 0);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setTextColor(TEXT);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        ResponsiveUi.configureCompactText(button, 11.7f, 9.7f, 1);
        if (Build.VERSION.SDK_INT >= 21) button.setStateListAnimator(null);
        return button;
    }

    private void styleTypeSelector(Button button, boolean selected, int type) {
        int color = typeColor(type);
        int dark = typeDarkColor(type);
        button.setTextColor(selected ? Color.WHITE : color);
        button.setBackground(gradient(selected ? color : dark, selected ? withAlphaOpaque(color, 185) : dark, 10, 1, color));
    }

    private int withAlphaOpaque(int color, int level) {
        int scale = Math.max(0, Math.min(255, level));
        return Color.rgb(
                Math.min(255, Color.red(color) * scale / 180),
                Math.min(255, Color.green(color) * scale / 180),
                Math.min(255, Color.blue(color) * scale / 180)
        );
    }

    private Button outlineButton(String text, int textColor, int border) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextColor(textColor);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setPadding(dp(5), 0, dp(5), 0);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setBackground(gradient(FIELD_BG, FIELD_BG, 10, 1, border));
        ResponsiveUi.configureCompactText(button, 13.2f, 10f, 1);
        if (Build.VERSION.SDK_INT >= 21) button.setStateListAnimator(null);
        return button;
    }

    private Button primaryAction(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setPadding(dp(6), 0, dp(6), 0);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setBackground(gradient(PRIMARY_A, PRIMARY_B, 10, 0, 0));
        ResponsiveUi.configureCompactText(button, 13.5f, 10f, 1);
        if (Build.VERSION.SDK_INT >= 21) {
            button.setStateListAnimator(null);
            button.setElevation(dp(2));
        }
        return button;
    }

    private TextView metricBox(LinearLayout parent, String title, String value, float weight, int l, int t, int r, int b) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(8), dp(9), dp(8), dp(9));
        box.setBackground(gradient(INNER_A, INNER_B, 12, 1, FIELD_STROKE));
        TextView titleView = label(title, 11.5f, false, SUBTEXT);
        titleView.setGravity(Gravity.CENTER);
        box.addView(titleView);
        TextView valueView = label(value, 15.8f, true, TEXT);
        valueView.setGravity(Gravity.CENTER);
        valueView.setLayoutParams(blockLp(0, 6, 0, 0));
        box.addView(valueView);
        parent.addView(box, weighted(weight, l, t, r, b));
        return valueView;
    }

    private TextView headerCell(String text, int widthDp) {
        TextView view = label(text, 11.7f, true, SUBTEXT);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(4), dp(8), dp(4), dp(8));
        view.setBackground(gradient(Color.rgb(11, 40, 66), Color.rgb(8, 30, 50), 0, 1, Color.rgb(45, 82, 118)));
        view.setLayoutParams(new LinearLayout.LayoutParams(dp(widthDp), ViewGroup.LayoutParams.WRAP_CONTENT));
        return view;
    }

    private TextView tableCell(String text, int widthDp, boolean bold, int color) {
        TextView view = label(text, 12.2f, bold, color);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(4), 0, dp(4), 0);
        view.setBackground(gradient(FIELD_BG, FIELD_BG, 0, 1, Color.rgb(42, 70, 97)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(widthDp), dp(44));
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        view.setLayoutParams(lp);
        return view;
    }

    private TextView dataCell(String text, int widthDp, boolean bold, int color) {
        TextView view = label(text, 12.1f, bold, color);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(4), dp(8), dp(4), dp(8));
        view.setBackground(gradient(FIELD_BG, FIELD_BG, 0, 1, Color.rgb(42, 70, 97)));
        view.setLayoutParams(new LinearLayout.LayoutParams(dp(widthDp), ViewGroup.LayoutParams.WRAP_CONTENT));
        return view;
    }

    private TextView infoNote(String text) {
        TextView note = label(text, 12.2f, false, SUBTEXT);
        note.setLineSpacing(0, 1.1f);
        note.setPadding(dp(10), dp(9), dp(10), dp(9));
        note.setBackground(gradient(Color.rgb(7, 28, 46), Color.rgb(7, 28, 46), 10, 1, Color.rgb(34, 74, 118)));
        note.setLayoutParams(blockLp(0, 8, 0, 0));
        return note;
    }

    private String defaultNameForNewRow(int type) {
        int n = rows.size() + 1;
        if (type == TYPE_BM_INITIAL) return "BM-" + n;
        if (type == TYPE_CHANGE) return "PC" + n;
        if (type == TYPE_BM_FINAL) return "BM-" + n;
        return "P" + n;
    }

    private String defaultPointNameForRow(int index, int type) {
        if (index == 0 && type == TYPE_BM_INITIAL) return "BM-1";
        if (type == TYPE_CHANGE) return "PC" + Math.max(1, index);
        if (type == TYPE_BM_FINAL) return "BM-" + (index + 1);
        if (type == TYPE_BM_INITIAL) return "BM-" + (index + 1);
        return "P" + Math.max(1, index);
    }

    private String typeLabel(int type) {
        if (type == TYPE_BM_INITIAL) return "⌖ BM inicial";
        if (type == TYPE_INTERMEDIATE) return "•—• Intermedio";
        if (type == TYPE_CHANGE) return "⇄ P. de cambio";
        return "⚑ BM final";
    }

    private int typeColor(int type) {
        if (type == TYPE_BM_INITIAL) return BLUE;
        if (type == TYPE_INTERMEDIATE) return GREEN;
        if (type == TYPE_CHANGE) return AMBER;
        return PURPLE;
    }

    private int typeDarkColor(int type) {
        if (type == TYPE_BM_INITIAL) return Color.rgb(11, 48, 84);
        if (type == TYPE_INTERMEDIATE) return GREEN_DARK;
        if (type == TYPE_CHANGE) return AMBER_DARK;
        return PURPLE_DARK;
    }

    private TextView label(String text, float size, boolean bold, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(color);
        view.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        ResponsiveUi.configureText(view, size);
        return view;
    }

    private GradientDrawable gradient(int start, int end, int radiusDp, int strokeDp, int strokeColor) {
        GradientDrawable drawable = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{start, end});
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), strokeColor);
        return drawable;
    }

    private LinearLayout.LayoutParams weighted(float weight, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        lp.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return lp;
    }

    private LinearLayout.LayoutParams blockLp(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return lp;
    }

    private static class LevelRow {
        final LinearLayout container;
        final TextView number;
        final EditText point;
        final EditText distance;
        final EditText bs;
        final EditText is;
        final EditText fs;
        final Button typeButton;
        int type;

        LevelRow(LinearLayout container, TextView number, EditText point, EditText distance,
                 EditText bs, EditText is, EditText fs, Button typeButton, int type) {
            this.container = container;
            this.number = number;
            this.point = point;
            this.distance = distance;
            this.bs = bs;
            this.is = is;
            this.fs = fs;
            this.typeButton = typeButton;
            this.type = type;
        }
    }

    private static class Computed {
        final String point;
        final int type;
        final double distance;
        final Double bs;
        final Double is;
        final Double fs;
        final double hi;
        final double elevation;
        double correction;
        double adjusted;

        Computed(String point, int type, double distance, Double bs, Double is, Double fs, double hi, double elevation) {
            this.point = point;
            this.type = type;
            this.distance = distance;
            this.bs = bs;
            this.is = is;
            this.fs = fs;
            this.hi = hi;
            this.elevation = elevation;
        }
    }

    private static class ProfilePoint {
        final String label;
        final double distance;
        final double elevation;
        final int color;

        ProfilePoint(String label, double distance, double elevation, int color) {
            this.label = label;
            this.distance = distance;
            this.elevation = elevation;
            this.color = color;
        }
    }

    private class ProfileView extends View {
        private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint axisPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pointPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private List<ProfilePoint> points = new ArrayList<>();

        ProfileView(LevelingFieldActivity activity) {
            super(activity);
            gridPaint.setColor(Color.argb(52, 94, 135, 173));
            gridPaint.setStrokeWidth(dp(1));
            axisPaint.setColor(Color.rgb(111, 143, 173));
            axisPaint.setStrokeWidth(dp(1));
            linePaint.setColor(BLUE);
            linePaint.setStrokeWidth(dp(2.2f));
            linePaint.setStyle(Paint.Style.STROKE);
            fillPaint.setColor(Color.argb(35, 31, 132, 255));
            fillPaint.setStyle(Paint.Style.FILL);
            textPaint.setColor(SUBTEXT);
            textPaint.setTextSize(dp(3.7f));
            pointPaint.setStyle(Paint.Style.FILL);
        }

        void setPoints(List<ProfilePoint> values) {
            points = values == null ? new ArrayList<>() : values;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            canvas.drawColor(Color.rgb(5, 21, 36));
            int w = getWidth();
            int h = getHeight();
            float left = dp(42);
            float right = w - dp(18);
            float top = dp(26);
            float bottom = h - dp(38);

            for (int i = 0; i <= 5; i++) {
                float y = top + (bottom - top) * i / 5f;
                canvas.drawLine(left, y, right, y, gridPaint);
            }
            for (int i = 0; i <= 6; i++) {
                float x = left + (right - left) * i / 6f;
                canvas.drawLine(x, top, x, bottom, gridPaint);
            }
            canvas.drawLine(left, bottom, right, bottom, axisPaint);
            canvas.drawLine(left, top, left, bottom, axisPaint);

            if (points == null || points.size() < 2) {
                textPaint.setColor(MUTED);
                canvas.drawText("El perfil aparecerá después del cálculo.", left + dp(12), top + dp(34), textPaint);
                return;
            }

            double minD = points.get(0).distance;
            double maxD = points.get(0).distance;
            double minH = points.get(0).elevation;
            double maxH = points.get(0).elevation;
            for (ProfilePoint p : points) {
                minD = Math.min(minD, p.distance);
                maxD = Math.max(maxD, p.distance);
                minH = Math.min(minH, p.elevation);
                maxH = Math.max(maxH, p.elevation);
            }
            double spanD = Math.max(1.0, maxD - minD);
            double spanH = Math.max(0.2, maxH - minH);
            double marginH = spanH * 0.18;
            minH -= marginH;
            maxH += marginH;
            spanH = maxH - minH;

            Path linePath = new Path();
            Path fillPath = new Path();
            ArrayList<PointF> mapped = new ArrayList<>();
            for (int i = 0; i < points.size(); i++) {
                ProfilePoint p = points.get(i);
                float x = left + (float) ((p.distance - minD) / spanD) * (right - left);
                float y = bottom - (float) ((p.elevation - minH) / spanH) * (bottom - top);
                mapped.add(new PointF(x, y));
                if (i == 0) {
                    linePath.moveTo(x, y);
                    fillPath.moveTo(x, bottom);
                    fillPath.lineTo(x, y);
                } else {
                    linePath.lineTo(x, y);
                    fillPath.lineTo(x, y);
                }
            }
            PointF last = mapped.get(mapped.size() - 1);
            fillPath.lineTo(last.x, bottom);
            fillPath.close();
            canvas.drawPath(fillPath, fillPaint);
            canvas.drawPath(linePath, linePaint);

            for (int i = 0; i < points.size(); i++) {
                ProfilePoint p = points.get(i);
                PointF m = mapped.get(i);
                pointPaint.setColor(p.color);
                canvas.drawCircle(m.x, m.y, dp(4), pointPaint);
                textPaint.setColor(p.color);
                String value = f3(p.elevation);
                canvas.drawText(p.label, m.x + dp(5), m.y - dp(8), textPaint);
                canvas.drawText(value, m.x + dp(5), m.y + dp(8), textPaint);
            }

            textPaint.setColor(SUBTEXT);
            for (int i = 0; i <= 4; i++) {
                double value = maxH - spanH * i / 4.0;
                float y = top + (bottom - top) * i / 4f;
                canvas.drawText(String.format(Locale.US, "%.2f", value), dp(4), y + dp(4), textPaint);
            }
            for (int i = 0; i <= 5; i++) {
                double value = minD + spanD * i / 5.0;
                float x = left + (right - left) * i / 5f;
                canvas.drawText(String.format(Locale.US, "%.1f", value), x - dp(8), h - dp(13), textPaint);
            }
        }
    }
}
