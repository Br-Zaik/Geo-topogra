package com.bph.geotopo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.GeomagneticField;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;

/** Navegación offline. GNSS y ROTATION_VECTOR reales; no sintetiza una brújula si falta sensor. */
public class GotoPointActivity extends Activity implements LocationListener, SensorEventListener {
    private static final int REQ = 7791;
    private static final long FIX_MAX_AGE = 15_000L;
    private static final int BG = Color.rgb(4, 21, 37);
    private static final int EDGE = Color.rgb(52, 98, 142);
    private static final int MINT = Color.rgb(74, 231, 176);
    private static final int BLUE = Color.rgb(106, 191, 255);
    private static final int AMBER = Color.rgb(255, 203, 105);
    private LocationManager manager;
    private SensorManager sensors;
    private Sensor rotation;
    private TextView targetTitle, status, distance, bearing, heading, accuracy, hint, scaleText, targetCoordinates;
    private Radar radar;
    private double targetLat = Double.NaN, targetLon = Double.NaN;
    private String targetName = "";
    private Location current;
    private double headingTrue = Double.NaN, azimuthTrue = Double.NaN, horizontalMeters = Double.NaN;
    private boolean gpsEnabled, compassReliable = true;
    private boolean headingFromMotion;
    private boolean manualScale;
    private float rangeMeters = 100;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() { update(); ui.postDelayed(this, 1000L); }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        NativeUi.styleWindow(this);
        manager = (LocationManager) getSystemService(LOCATION_SERVICE);
        sensors = (SensorManager) getSystemService(SENSOR_SERVICE);
        rotation = sensors == null ? null : sensors.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        LinearLayout page = NativeUi.column(this);
        page.addView(NativeUi.pageHeader(this, "Ir a punto · Radar", "Navegación GNSS sin Internet",
                v -> finish(), "⌖", v -> selectPoint()));
        LinearLayout body = NativeUi.column(this);
        body.setPadding(dp(13), dp(13), dp(13), dp(27));
        body.setBackgroundColor(BG);
        TextView select = action("⌖    SELECCIONAR PUNTO DE DESTINO     ›", BLUE);
        select.setOnClickListener(v -> selectPoint());
        body.addView(select);
        targetTitle = NativeUi.text(this, "Selecciona un punto", 20, true, Color.WHITE);
        targetTitle.setPadding(dp(5), dp(13), dp(5), dp(3));
        body.addView(targetTitle);
        targetCoordinates = NativeUi.text(this, "El destino puede ser un punto UTM o geográfico guardado.",
                11.5f, false, NativeUi.SUB);
        targetCoordinates.setPadding(dp(5), 0, dp(5), dp(10));
        body.addView(targetCoordinates);

        LinearLayout radarCard = NativeUi.column(this);
        radarCard.setPadding(dp(10), dp(12), dp(10), dp(12));
        radarCard.setBackground(NativeUi.gradient(Color.rgb(15, 48, 77), Color.rgb(5, 27, 46),
                19, EDGE, this));
        status = NativeUi.text(this, "●  ESPERANDO UBICACIÓN Y DESTINO", 11.5f, true, AMBER);
        status.setGravity(Gravity.CENTER);
        radarCard.addView(status);
        radar = new Radar();
        radarCard.addView(radar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(306)));
        LinearLayout scaleRow = NativeUi.row(this);
        scaleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView minus = scaleButton("−", () -> changeScale(true));
        scaleRow.addView(minus, new LinearLayout.LayoutParams(dp(53), dp(43)));
        scaleText = NativeUi.text(this, "RADIO 100 m · AUTOMÁTICO", 12.2f, true, BLUE);
        scaleText.setGravity(Gravity.CENTER);
        scaleRow.addView(scaleText, new LinearLayout.LayoutParams(0, dp(43), 1f));
        TextView plus = scaleButton("+", () -> changeScale(false));
        scaleRow.addView(plus, new LinearLayout.LayoutParams(dp(53), dp(43)));
        radarCard.addView(scaleRow);
        TextView auto = NativeUi.text(this, "AJUSTAR ESCALA AUTOMÁTICA", 11.2f, true, MINT);
        auto.setGravity(Gravity.CENTER);
        auto.setPadding(0, dp(10), 0, dp(4));
        auto.setOnClickListener(v -> { manualScale = false; adaptScale(); update(); });
        radarCard.addView(auto);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.bottomMargin = dp(11);
        body.addView(radarCard, rlp);

        LinearLayout first = NativeUi.row(this);
        distance = valueCard(first, "DISTANCIA DIRECTA", "—", MINT, true);
        bearing = valueCard(first, "AZIMUT VERDADERO", "—", BLUE, false);
        body.addView(first);
        LinearLayout second = NativeUi.row(this);
        heading = valueCard(second, "ORIENTACIÓN", "—", BLUE, true);
        accuracy = valueCard(second, "PRECISIÓN GPS", "—", AMBER, false);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.topMargin = dp(7);
        body.addView(second, slp);
        hint = NativeUi.text(this, "Selecciona un punto. La flecha se activa solo con rumbo real del sensor o del GPS en movimiento.",
                12f, false, NativeUi.SUB);
        hint.setPadding(dp(8), dp(16), dp(8), dp(15));
        body.addView(hint);
        page.addView(NativeUi.scroll(this, body), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(page);
        if (getIntent().hasExtra("target_lat") && getIntent().hasExtra("target_lon")) {
            targetLat = getIntent().getDoubleExtra("target_lat", Double.NaN);
            targetLon = getIntent().getDoubleExtra("target_lon", Double.NaN);
            targetName = getIntent().getStringExtra("target_name");
            if (targetName == null) targetName = "Punto";
        }
        update();
    }

    private int dp(int v) { return NativeUi.dp(this, v); }
    private TextView action(String title, int color) {
        TextView v = NativeUi.text(this, title, 12.8f, true, color);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setPadding(dp(13), 0, dp(13), 0);
        v.setBackground(NativeUi.gradient(Color.rgb(14, 52, 81), Color.rgb(7, 36, 59), 15, EDGE, this));
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));
        return v;
    }
    private TextView scaleButton(String label, Runnable click) {
        TextView v = NativeUi.text(this, label, 26f, true, Color.WHITE);
        v.setGravity(Gravity.CENTER);
        v.setBackground(NativeUi.rounded(Color.rgb(13, 49, 76), 13, 1, EDGE, this));
        v.setOnClickListener(view -> click.run());
        return v;
    }
    private TextView valueCard(LinearLayout row, String caption, String initial, int color, boolean left) {
        LinearLayout card = NativeUi.column(this);
        card.setPadding(dp(11), dp(11), dp(6), dp(12));
        card.setBackground(NativeUi.gradient(Color.rgb(16, 49, 77), Color.rgb(7, 31, 52), 15, EDGE, this));
        card.addView(NativeUi.text(this, caption, 10.6f, true, NativeUi.SUB));
        TextView value = NativeUi.text(this, initial, 20.5f, true, color);
        value.setPadding(0, dp(7), 0, 0);
        card.addView(value);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(86), 1f);
        lp.setMargins(left ? 0 : dp(4), 0, left ? dp(4) : 0, 0);
        row.addView(card, lp);
        return value;
    }

    private void selectPoint() {
        JSONArray points;
        try { points = new JSONArray(getSharedPreferences("geo_topo_gps_points", MODE_PRIVATE)
                .getString("points_json", "[]")); } catch (Exception e) { points = new JSONArray(); }
        java.util.List<JSONObject> valid = new java.util.ArrayList<>();
        for (int i = 0; i < points.length(); i++) {
            JSONObject p = points.optJSONObject(i);
            if (p == null) continue;
            double lat = p.optDouble("latitude", Double.NaN);
            double lon = p.optDouble("longitude", Double.NaN);
            if (validCoordinate(lat, lon)) valid.add(p);
        }
        if (valid.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("No hay puntos con coordenadas")
                    .setMessage("Crea un punto UTM o geográfico desde Puntos. No necesitas Internet ni señal GPS para introducirlo.")
                    .setPositiveButton("Entendido", null).show();
            return;
        }
        String[] labels = new String[valid.size()];
        for (int i = 0; i < valid.size(); i++) {
            JSONObject p = valid.get(i);
            labels[i] = p.optString("name", "Punto") + " · " + p.optString("project", "Proyecto general");
        }
        new AlertDialog.Builder(this).setTitle("Navegar hacia")
                .setItems(labels, (dialog, which) -> {
                    JSONObject p = valid.get(which);
                    targetLat = p.optDouble("latitude", Double.NaN);
                    targetLon = p.optDouble("longitude", Double.NaN);
                    targetName = p.optString("name", "Punto");
                    manualScale = false;
                    update();
                }).setNegativeButton("Cancelar", null).show();
    }
    private boolean validCoordinate(double lat, double lon) {
        return Double.isFinite(lat) && Double.isFinite(lon) && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180;
    }
    @Override protected void onResume() { super.onResume(); start(); ui.removeCallbacks(tick); ui.post(tick); }
    @Override protected void onPause() {
        ui.removeCallbacks(tick);
        stop();
        headingTrue = Double.NaN;
        headingFromMotion = false;
        current = null;
        super.onPause();
    }
    private void start() {
        if (sensors != null && rotation != null) sensors.registerListener(this, rotation, SensorManager.SENSOR_DELAY_UI);
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ);
            return;
        }
        try {
            gpsEnabled = manager != null && manager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            if (gpsEnabled && manager != null) {
                manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this);
                Location last = manager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (fresh(last)) current = new Location(last);
            }
        } catch (Exception ex) {
            hint.setText("No se pudo iniciar el GPS. Revisa los permisos de ubicación precisa.");
        }
        update();
    }
    private void stop() {
        try { if (manager != null) manager.removeUpdates(this); } catch (Exception ignored) { }
        if (sensors != null) sensors.unregisterListener(this);
    }
    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] result) {
        super.onRequestPermissionsResult(code, perms, result);
        if (code != REQ) return;
        if (result.length > 0 && result[0] == PackageManager.PERMISSION_GRANTED) start();
        else Toast.makeText(this, "Se necesita ubicación precisa para navegar.", Toast.LENGTH_LONG).show();
    }
    private boolean fresh(Location loc) {
        return loc != null && loc.getTime() > 0 &&
                Math.abs(System.currentTimeMillis() - loc.getTime()) <= FIX_MAX_AGE &&
                validCoordinate(loc.getLatitude(), loc.getLongitude());
    }
    @Override public void onLocationChanged(Location loc) {
        if (!fresh(loc)) return;
        current = new Location(loc);
        if ((rotation == null || !compassReliable) && (!loc.hasSpeed() || loc.getSpeed() < 1.5f || !loc.hasBearing())) {
            headingTrue = Double.NaN;
            headingFromMotion = false;
        }
        if ((rotation == null || !compassReliable) && loc.hasSpeed() && loc.getSpeed() >= 1.5f && loc.hasBearing()) {
            headingTrue = loc.getBearing();
            headingFromMotion = true;
        }
        update();
    }
    @Override public void onProviderEnabled(String provider) { gpsEnabled = true; update(); }
    @Override public void onProviderDisabled(String provider) {
        gpsEnabled = false;
        current = null;
        azimuthTrue = Double.NaN;
        update();
    }
    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {
        if (rotation != null && sensor.getType() == rotation.getType()) {
            compassReliable = accuracy != SensorManager.SENSOR_STATUS_UNRELIABLE;
            if (!compassReliable && !headingFromMotion) headingTrue = Double.NaN;
            update();
        }
    }
    @Override public void onSensorChanged(SensorEvent event) {
        if (rotation == null || event.sensor.getType() != rotation.getType()) return;
        if (!compassReliable) return;
        float[] matrix = new float[9];
        float[] orientation = new float[3];
        SensorManager.getRotationMatrixFromVector(matrix, event.values);
        SensorManager.getOrientation(matrix, orientation);
        double magnetic = (Math.toDegrees(orientation[0]) + 360) % 360;
        if (fresh(current)) {
            GeomagneticField field = new GeomagneticField((float) current.getLatitude(),
                    (float) current.getLongitude(), current.hasAltitude() ? (float) current.getAltitude() : 0,
                    System.currentTimeMillis());
            double next = RadarNavigationMath.wrap(magnetic + field.getDeclination());
            if (Double.isFinite(headingTrue) && !headingFromMotion) {
                double delta = RadarNavigationMath.relativeAngle(next, headingTrue);
                headingTrue = RadarNavigationMath.wrap(headingTrue + 0.22 * delta);
            } else headingTrue = next;
            headingFromMotion = false;
            update();
        } else {
            headingTrue = Double.NaN; // Sin posición, no afirmar una declinación ni orientación verdadera.
            update();
        }
    }
    private void changeScale(boolean zoomIn) {
        rangeMeters = RadarNavigationMath.manualRange(rangeMeters, zoomIn);
        manualScale = true;
        update();
    }
    private void adaptScale() {
        if (manualScale || !Double.isFinite(horizontalMeters)) return;
        rangeMeters = RadarNavigationMath.autoRange(horizontalMeters);
    }
    private String fmt(double value) { return String.format(Locale.getDefault(), "%.1f", value); }
    private String distanceLabel(double meters) {
        return meters >= 1000 ? fmt(meters / 1000) + " km" : fmt(meters) + " m";
    }
    private void update() {
        if (targetTitle == null) return;
        boolean target = validCoordinate(targetLat, targetLon);
        targetTitle.setText(target ? "Destino: " + targetName : "Selecciona un punto");
        targetCoordinates.setText(target ? String.format(Locale.US, "WGS84  •  %.6f°, %.6f°", targetLat, targetLon)
                : "Elige un punto guardado para ver el radar real.");
        if (!fresh(current)) current = null;
        boolean positioned = gpsEnabled && current != null;
        if (!positioned || !target) {
            horizontalMeters = Double.NaN;
            azimuthTrue = Double.NaN;
            distance.setText("—"); bearing.setText("—");
            accuracy.setText(positioned && current.hasAccuracy() ? "±" + fmt(current.getAccuracy()) + " m" : "—");
            heading.setText(Double.isFinite(headingTrue) && positioned ? fmt(headingTrue) + "°" : "—");
            status.setText(!gpsEnabled ? "●  GPS APAGADO" : !positioned ? "●  ESPERANDO POSICIÓN ACTUAL"
                    : "●  SELECCIONA UN DESTINO");
            status.setTextColor(AMBER);
            hint.setText(!gpsEnabled ? "Activa la ubicación del celular para obtener coordenadas reales."
                    : !positioned ? "Esperando posición GNSS reciente. Ve al aire libre si no encuentra señal."
                    : "Selecciona un punto guardado para calcular distancia y rumbo sin Internet.");
        } else {
            float[] data = new float[3];
            Location.distanceBetween(current.getLatitude(), current.getLongitude(), targetLat, targetLon, data);
            horizontalMeters = data[0];
            azimuthTrue = RadarNavigationMath.wrap(data[1]);
            adaptScale();
            distance.setText(distanceLabel(horizontalMeters));
            bearing.setText(fmt(azimuthTrue) + "°");
            heading.setText(Double.isFinite(headingTrue) ? fmt(headingTrue) + "°" : "Sin brújula");
            accuracy.setText(current.hasAccuracy() ? "±" + fmt(current.getAccuracy()) + " m" : "Sin dato");
            boolean near = RadarNavigationMath.withinAccuracy(horizontalMeters,
                    current.hasAccuracy() ? current.getAccuracy() : Double.NaN);
            status.setText(near ? "●  CERCA DEL DESTINO · VERIFICA EN CAMPO"
                    : Double.isFinite(headingTrue) ? "●  NAVEGACIÓN ACTIVA" : "●  OBJETIVO · NORTE ARRIBA");
            status.setTextColor(near ? AMBER : MINT);
            hint.setText(near ? "Dentro del margen aproximado del GPS. No sustituye un replanteo topográfico preciso."
                    : !Double.isFinite(headingTrue) ? "Sin orientación confiable: radar con norte arriba; no interpreta hacia dónde apunta el celular."
                    : headingFromMotion ? "Orientación por desplazamiento GPS. Camina para mantener la dirección; no es una brújula estática."
                    : !compassReliable ? "Sensor poco confiable. Aléjate de objetos metálicos y vuelve a calibrar la brújula."
                    : "La flecha indica el destino respecto al teléfono. Distancia en línea recta, no por caminos.");
        }
        scaleText.setText("RADIO " + distanceLabel(rangeMeters) + (manualScale ? " · MANUAL" : " · AUTOMÁTICO"));
        if (radar != null) radar.invalidate();
    }

    private class Radar extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Radar() { super(GotoPointActivity.this); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float r = Math.min(getWidth() * .41f, getHeight() * .38f);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(5, 28, 47)); c.drawCircle(cx, cy, r, p);
            for (int i = 4; i >= 1; i--) {
                float ring = r * i / 4f;
                p.setColor(i % 2 == 0 ? Color.rgb(61, 112, 148) : Color.rgb(33, 81, 111));
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1));
                c.drawCircle(cx, cy, ring, p);
            }
            // Cuadrícula circular y marcas de 5°, orientación verdadera cuando hay brújula.
            double frameHeading = Double.isFinite(headingTrue) && current != null ? headingTrue : 0;
            p.setColor(Color.rgb(49, 106, 138)); p.setStrokeWidth(dp(1));
            for (int i = 0; i < 360; i += 30) {
                double a = Math.toRadians(i - frameHeading);
                float dx = (float) Math.sin(a), dy = -(float) Math.cos(a);
                c.drawLine(cx + dx * r * .10f, cy + dy * r * .10f,
                        cx + dx * r, cy + dy * r, p);
            }
            for (int i = 0; i < 360; i += 5) {
                double a = Math.toRadians(i - frameHeading);
                float dx = (float) Math.sin(a), dy = -(float) Math.cos(a);
                p.setColor(i % 30 == 0 ? Color.rgb(147, 208, 235) : Color.rgb(66, 106, 138));
                p.setStrokeWidth(i % 30 == 0 ? dp(2) : dp(1));
                c.drawLine(cx + dx * r * (i % 30 == 0 ? .91f : .96f),
                        cy + dy * r * (i % 30 == 0 ? .91f : .96f), cx + dx * r, cy + dy * r, p);
            }
            p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(dp(15));
            String[] label = {"N", "E", "S", "O"};
            for (int i = 0; i < 4; i++) {
                double a = Math.toRadians(i * 90 - frameHeading);
                p.setColor(i == 0 ? AMBER : Color.WHITE);
                c.drawText(label[i], cx + (float) Math.sin(a) * (r + dp(16)),
                        cy - (float) Math.cos(a) * (r + dp(16)) + dp(5), p);
            }
            if (Double.isFinite(horizontalMeters) && Double.isFinite(azimuthTrue) && current != null) {
                double a = Math.toRadians(RadarNavigationMath.relativeAngle(azimuthTrue, frameHeading));
                float dx = (float) Math.sin(a), dy = -(float) Math.cos(a);
                float ratio = (float) Math.min(1, horizontalMeters / Math.max(1, rangeMeters));
                float dr = r * Math.max(.03f, ratio) * .87f;
                float x = cx + dx * dr, y = cy + dy * dr;
                p.setColor(MINT); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(3));
                c.drawLine(cx, cy, x, y, p);
                p.setColor(Color.argb(58, 74, 231, 176)); p.setStyle(Paint.Style.FILL);
                c.drawCircle(x, y, dp(16), p);
                p.setColor(MINT); c.drawCircle(x, y, dp(7), p);
                p.setColor(Color.WHITE); c.drawCircle(x, y, dp(3), p);
                if (horizontalMeters > rangeMeters) {
                    p.setColor(AMBER); p.setTextSize(dp(11));
                    c.drawText("FUERA DE ESCALA", cx, cy + r * .69f, p);
                }
                if (Double.isFinite(headingTrue)) {
                    p.setColor(BLUE);
                    Path arrow = new Path();
                    arrow.moveTo(cx, cy - dp(23)); arrow.lineTo(cx - dp(8), cy + dp(8));
                    arrow.lineTo(cx, cy + dp(3)); arrow.lineTo(cx + dp(8), cy + dp(8));
                    arrow.close(); c.drawPath(arrow, p);
                }
            } else {
                p.setColor(AMBER); p.setTextSize(dp(12));
                c.drawText("ESPERANDO POSICIÓN / DESTINO", cx, cy + r * .66f, p);
            }
            p.setStyle(Paint.Style.FILL); p.setColor(BLUE); c.drawCircle(cx, cy, dp(4), p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2));
            c.drawCircle(cx, cy, dp(10), p);
            p.setStyle(Paint.Style.FILL); p.setTextSize(dp(10));p.setColor(NativeUi.SUB);
            c.drawText(Double.isFinite(headingTrue) ? "FRENTE DEL TELÉFONO ↑" : "NORTE ARRIBA · SIN BRÚJULA",
                    cx, getHeight() - dp(4), p);
        }
    }
    @Override public void onContentChanged() { super.onContentChanged(); NativeUi.applySystemBarInsets(this); }
}
