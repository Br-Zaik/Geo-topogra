package com.bph.geotopo;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/** Centro real de herramientas GPS: pantallas existentes, sin opciones de demostración. */
public class GpsToolsActivity extends Activity {
    private static final String GPS_PREFS = "geo_topo_gps_points";
    private final int mint = Color.rgb(86, 231, 184);
    private final int gold = Color.rgb(255, 196, 105);
    private final int sky = Color.rgb(117, 194, 255);
    private final int purple = Color.rgb(190, 161, 255);
    private LinearLayout statusArea;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NativeUi.styleWindow(this);
        setContentView(buildScreen());
    }

    @Override protected void onResume() {
        super.onResume();
        if (statusArea != null) {
            statusArea.removeAllViews();
            populateStatus();
        }
    }

    @Override public void onContentChanged() {
        super.onContentChanged();
        NativeUi.applySystemBarInsets(this);
    }

    private int dp(int value) { return NativeUi.dp(this, value); }

    private View buildScreen() {
        FrameLayout root = NativeUi.screen(this);
        LinearLayout page = NativeUi.column(this);
        page.addView(NativeUi.pageHeader(this, "Herramientas GPS", "Trabajo de campo y navegación",
                v -> finish(), "⌖", v -> open(MapActivity.class)));
        LinearLayout content = NativeUi.column(this);
        content.setPadding(dp(14), dp(14), dp(14), dp(32));
        content.addView(buildHero());

        section(content, "01  TRABAJO DE CAMPO", "Captura, guarda y registra");
        feature(content, "track", "Sesiones y recorridos", "Iniciar, pausar y continuar una sesión GPS",
                mint, () -> open(TrackActivity.class));
        feature(content, "pin", "Crear punto manual", "UTM o Lat/Lon, símbolo, foto y vista en mapa",
                gold, () -> open(PointEditorActivity.class));
        row(content,
                mini("bookmark", "Puntos guardados", "Consultar y editar", sky, () -> overviewAction("points")),
                mini("target", "Ir a punto / Radar", "Distancia y azimut", purple, () -> open(GotoPointActivity.class)));

        section(content, "02  MAPAS Y ORIENTACIÓN", "Navegación y emplazamiento");
        feature(content, "map", "Mapa completo y capas", "Vectorial, topográfico, satélite y sin conexión",
                sky, () -> open(MapActivity.class));
        row(content,
                mini("compass", "Brújula", "Orientación", gold, () -> openCalculation("compass")),
                mini("angle", "Azimut y rumbo", "Cálculos de dirección", purple, () -> openCalculation("azimuth")));
        feature(content, "grid", "Mapas descargados", "Abrir y gestionar archivos MBTiles del dispositivo",
                sky, () -> open(OfflineMapActivity.class));

        section(content, "03  GNSS Y PRECISIÓN", "Mediciones y receptor");
        feature(content, "satellite", "Satélites y datos GNSS", "Vista del cielo, constelaciones, precisión y NMEA",
                mint, () -> open(GnssQualityActivity.class));
        feature(content, "target", "Replanteo de puntos", "Objetivo, distancia, dirección y tolerancia",
                gold, () -> open(StakeoutActivity.class));
        feature(content, "satellite", "Receptor GNSS externo", "Conectar un receptor Bluetooth NMEA",
                sky, () -> open(ExternalGnssActivity.class));

        section(content, "04  DATOS Y AJUSTES", "Archivos, coordenadas y referencia");
        row(content,
                mini("grid", "Formato UTM / GPS", "DD, DM y DMS", purple, () -> open(GpsSettingsActivity.class)),
                mini("slope", "Ajuste de altitud", "Offset geoidal manual", gold, () -> open(GpsSettingsActivity.class)));
        feature(content, "file", "Exportar puntos y recorridos", "Genera GPX, KML, KMZ, CSV o TXT",
                mint, () -> overviewAction("export"));
        feature(content, "share", "Compartir ubicación", "Coordenadas registradas; no inventa posición actual",
                sky, this::shareLocation);
        feature(content, "slope", "Perfil de elevación", "Mide una línea en el mapa para generar el perfil",
                purple, this::openElevationMap);

        ScrollView scroll = NativeUi.scroll(this, content);
        scroll.setVerticalScrollBarEnabled(false);
        page.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(page, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        return root;
    }

    private View buildHero() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackground(NativeUi.gradient(Color.rgb(17, 66, 90), Color.rgb(5, 26, 52),
                22, NativeUi.withAlpha(mint, 125), this));
        frame.setClipToOutline(true);
        frame.setElevation(dp(3));
        frame.addView(new NativeUi.TopoCardArtView(this, "gps", true),
                new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
        View overlay = new View(this);
        overlay.setBackground(NativeUi.gradient(NativeUi.withAlpha(Color.rgb(4, 20, 39), 217),
                NativeUi.withAlpha(Color.rgb(4, 20, 39), 185), 22, Color.TRANSPARENT, this));
        frame.addView(overlay, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout body = NativeUi.column(this);
        body.setPadding(dp(17), dp(17), dp(17), dp(15));
        TextView cap = NativeUi.text(this, "CENTRO DE OPERACIONES  /  GEOTOPO", 10, true, mint);
        cap.setLetterSpacing(.08f);
        body.addView(cap);
        TextView title = NativeUi.text(this, "Tu estación de campo", 21, true, Color.WHITE);
        title.setPadding(0, dp(5), 0, dp(4));
        body.addView(title);
        TextView intro = NativeUi.text(this, "Puntos · navegación · sesiones · precisión", 12, false,
                Color.rgb(201, 226, 246));
        body.addView(intro);
        statusArea = NativeUi.column(this);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        sl.topMargin = dp(14);
        body.addView(statusArea, sl);
        frame.addView(body, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(7);
        frame.setMinimumHeight(dp(162));
        frame.setLayoutParams(lp);
        populateStatus();
        return frame;
    }

    private void populateStatus() {
        SharedPreferences sp = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
        String lat = sp.getString("last_latitude", "");
        String lon = sp.getString("last_longitude", "");
        long age = System.currentTimeMillis() - sp.getLong("last_location_time", 0L);
        boolean valid = false;
        double latitude = 0, longitude = 0;
        try {
            if (lat != null && lon != null) {
                latitude = Double.parseDouble(lat);
                longitude = Double.parseDouble(lon);
                valid = !Double.isNaN(latitude) && !Double.isInfinite(latitude)
                        && !Double.isNaN(longitude) && !Double.isInfinite(longitude)
                        && Math.abs(latitude) <= 90 && Math.abs(longitude) <= 180;
            }
        } catch (Exception ignored) { }
        LinearLayout row = NativeUi.row(this);
        int used = sp.getInt("last_satellites_used", 0);
        int visible = sp.getInt("last_satellites_visible", 0);
        String freshness = valid ? age < 0 ? "Lectura guardada"
                : age < 60000L ? "Última lectura · <1 min"
                : age < 3600000L ? "Última lectura · " + (age / 60000L) + " min"
                : "Última lectura anterior" : "Sin coordenadas registradas";
        row.addView(statusPill("target", freshness, valid ? mint : gold),
                new LinearLayout.LayoutParams(0, dp(37), 1f));
        TextView stat = statusPill("satellite", valid ? used + "/" + visible + " sat. ult." : "GNSS —", sky);
        LinearLayout.LayoutParams s = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(37));
        s.leftMargin = dp(6);
        row.addView(stat, s);
        statusArea.addView(row);
        if (valid) {
            String zone = CoordinateUtils.zoneWithBand(latitude, longitude);
            TextView line = NativeUi.text(this, String.format(Locale.US,
                    "WGS84  ·  Zona %s  ·  %.5f°, %.5f°", zone, latitude, longitude),
                    11.5f, false, Color.rgb(215, 232, 246));
            line.setPadding(dp(3), dp(9), 0, 0);
            statusArea.addView(line);
        }
    }

    private TextView statusPill(String icon, String value, int color) {
        TextView pill = NativeUi.text(this, "●  " + value, 11, true, color);
        pill.setGravity(Gravity.CENTER);
        pill.setPadding(dp(8), 0, dp(8), 0);
        pill.setBackground(NativeUi.rounded(Color.argb(215, 5, 24, 45),
                11, 1, NativeUi.withAlpha(color, 75), this));
        return pill;
    }

    private void section(LinearLayout content, String heading, String sub) {
        LinearLayout wrap = NativeUi.column(this);
        TextView title = NativeUi.text(this, heading, 12.5f, true, sky);
        title.setLetterSpacing(.085f);
        TextView desc = NativeUi.text(this, sub, 11.5f, false, NativeUi.SUB);
        desc.setPadding(0, dp(2), 0, 0);
        wrap.addView(title);
        wrap.addView(desc);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(19);
        lp.bottomMargin = dp(9);
        content.addView(wrap, lp);
    }

    private void feature(LinearLayout content, String icon, String name, String desc, int accent, Runnable action) {
        LinearLayout card = NativeUi.row(this);
        card.setPadding(dp(12), dp(12), dp(12), dp(12));
        card.setBackground(NativeUi.gradient(Color.rgb(16, 49, 75), Color.rgb(8, 29, 51),
                17, NativeUi.withAlpha(accent, 90), this));
        card.setElevation(dp(2));
        card.addView(iconTile(icon, accent, 47), new LinearLayout.LayoutParams(dp(47), dp(47)));
        LinearLayout words = NativeUi.column(this);
        words.setPadding(dp(12), 0, 0, 0);
        TextView title = NativeUi.text(this, name, 14.7f, true, NativeUi.TEXT);
        title.setMaxLines(2);
        TextView subtitle = NativeUi.text(this, desc, 11.5f, false, NativeUi.SUB);
        subtitle.setPadding(0, dp(4), 0, 0);
        subtitle.setMaxLines(3);
        words.addView(title);
        words.addView(subtitle);
        card.addView(words, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView arrow = NativeUi.text(this, "›", 27, false, accent);
        arrow.setGravity(Gravity.CENTER);
        card.addView(arrow, new LinearLayout.LayoutParams(dp(24), dp(47)));
        card.setContentDescription(name + ". " + desc);
        card.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(8);
        content.addView(card, lp);
    }

    private FrameLayout iconTile(String icon, int accent, int dimension) {
        return NativeUi.iconTile(this, icon, dimension,
                NativeUi.withAlpha(accent, 52), Color.rgb(10, 31, 51), accent);
    }

    private View mini(String icon, String name, String desc, int accent, Runnable action) {
        LinearLayout card = NativeUi.column(this);
        card.setPadding(dp(12), dp(12), dp(9), dp(11));
        card.setBackground(NativeUi.gradient(Color.rgb(15, 44, 69), Color.rgb(7, 27, 48),
                16, NativeUi.withAlpha(accent, 90), this));
        card.setMinimumHeight(dp(121));
        card.setElevation(dp(2));
        LinearLayout header = NativeUi.row(this);
        header.addView(iconTile(icon, accent, 36), new LinearLayout.LayoutParams(dp(36), dp(36)));
        TextView arrow = NativeUi.text(this, "↗", 17, true, accent);
        arrow.setGravity(Gravity.RIGHT | Gravity.TOP);
        header.addView(arrow, new LinearLayout.LayoutParams(0, dp(32), 1f));
        card.addView(header);
        TextView title = NativeUi.text(this, name, 13.1f, true, NativeUi.TEXT);
        title.setPadding(0, dp(9), 0, 0);
        title.setMaxLines(2);
        card.addView(title);
        TextView subtitle = NativeUi.text(this, desc, 10.8f, false, NativeUi.SUB);
        subtitle.setPadding(0, dp(3), 0, 0);
        subtitle.setMaxLines(2);
        card.addView(subtitle);
        card.setContentDescription(name + ". " + desc);
        card.setOnClickListener(v -> action.run());
        return card;
    }

    private void row(LinearLayout content, View left, View right) {
        LinearLayout cards = NativeUi.row(this);
        cards.setGravity(Gravity.TOP);
        LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        a.rightMargin = dp(4);
        LinearLayout.LayoutParams b = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        b.leftMargin = dp(4);
        cards.addView(left, a);
        cards.addView(right, b);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(8);
        content.addView(cards, lp);
    }

    private void open(Class<?> destination) { startActivity(new Intent(this, destination)); }

    private void openElevationMap() {
        Toast.makeText(this, "Mide una línea de 2 o más puntos en el mapa y abre su perfil de elevación.",
                Toast.LENGTH_LONG).show();
        open(MapActivity.class);
    }

    private void overviewAction(String action) {
        Intent intent = new Intent(this, GpsOverviewActivity.class);
        intent.putExtra("gps_tools_action", action);
        startActivity(intent);
    }

    private void openCalculation(String key) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("single_tool", key);
        startActivity(intent);
    }

    private void shareLocation() {
        SharedPreferences sp = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
        String lat = sp.getString("last_latitude", "");
        String lon = sp.getString("last_longitude", "");
        if (lat == null || lon == null || lat.isEmpty() || lon.isEmpty()) {
            Toast.makeText(this, "Primero registra una lectura GPS para compartirla.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            double latitude = Double.parseDouble(lat), longitude = Double.parseDouble(lon);
            if (Double.isNaN(latitude) || Double.isInfinite(latitude) || Double.isNaN(longitude) || Double.isInfinite(longitude) || Math.abs(latitude) > 90 || Math.abs(longitude) > 180) throw new IllegalArgumentException();
            long time = sp.getLong("last_location_time", 0L);
            String label = time > 0 ? new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
                    .format(new java.util.Date(time)) : "fecha no disponible";
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/plain");
            share.putExtra(Intent.EXTRA_TEXT, String.format(Locale.US,
                    "GeoTopo · Última ubicación registrada (%s)\nLatitud: %.7f\nLongitud: %.7f\nhttps://www.openstreetmap.org/?mlat=%.7f&mlon=%.7f#map=16/%.7f/%.7f",
                    label, latitude, longitude, latitude, longitude, latitude, longitude));
            startActivity(Intent.createChooser(share, "Compartir última ubicación"));
        } catch (Exception e) {
            Toast.makeText(this, "No hay coordenadas válidas para compartir.", Toast.LENGTH_LONG).show();
        }
    }
}
