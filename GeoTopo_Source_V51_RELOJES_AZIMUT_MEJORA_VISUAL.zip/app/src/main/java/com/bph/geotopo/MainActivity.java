package com.bph.geotopo;

import android.app.Activity;
import android.app.AlertDialog;
import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.hardware.GeomagneticField;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.RadialGradient;
import android.graphics.LinearGradient;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.Surface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final String PREFS = "geo_topo_prefs";
    private static final int THEME_LIGHT = 0;
    private static final int THEME_DARK = 1;
    private static final int THEME_BLACK = 2;
    private static final int REQ_LOCATION = 9101;

    private static final int[] ACCENTS = {
            Color.rgb(41, 121, 255),
            Color.rgb(0, 188, 212),
            Color.rgb(0, 150, 136),
            Color.rgb(0, 184, 148),
            Color.rgb(118, 210, 34),
            Color.rgb(255, 214, 10),
            Color.rgb(255, 171, 0),
            Color.rgb(255, 112, 20),
            Color.rgb(244, 67, 54),
            Color.rgb(255, 64, 129),
            Color.rgb(142, 68, 173),
            Color.rgb(92, 92, 210),
            Color.rgb(149, 96, 68),
            Color.rgb(158, 169, 181),
            Color.rgb(20, 20, 22),
            Color.rgb(255, 255, 255)
    };
    private static final int[] COMPASS_ARROW_COLORS = {
            Color.rgb(41, 121, 255),
            Color.rgb(0, 188, 212),
            Color.rgb(0, 150, 136),
            Color.rgb(0, 184, 148),
            Color.rgb(118, 210, 34),
            Color.rgb(255, 214, 10),
            Color.rgb(255, 171, 0),
            Color.rgb(255, 112, 20),
            Color.rgb(231, 76, 60),
            Color.rgb(255, 64, 129),
            Color.rgb(142, 68, 173),
            Color.rgb(92, 92, 210),
            Color.rgb(149, 96, 68),
            Color.rgb(158, 169, 181),
            Color.rgb(20, 20, 22),
            Color.rgb(255, 255, 255)
    };
    private static final int[] COMPASS_RING_COLORS = {
            Color.rgb(41, 121, 255),
            Color.rgb(0, 188, 212),
            Color.rgb(0, 150, 136),
            Color.rgb(0, 184, 148),
            Color.rgb(118, 210, 34),
            Color.rgb(255, 214, 10),
            Color.rgb(255, 171, 0),
            Color.rgb(255, 112, 20),
            Color.rgb(231, 76, 60),
            Color.rgb(255, 64, 129),
            Color.rgb(142, 68, 173),
            Color.rgb(92, 92, 210),
            Color.rgb(149, 96, 68),
            Color.rgb(158, 169, 181),
            Color.rgb(20, 20, 22),
            Color.rgb(255, 255, 255)
    };

    private int themeMode;
    private int accentIndex;
    private int arrowColorIndex;
    private int ringColorIndex;

    private int bgColor;
    private int appBarColor;
    private int cardColor;
    private int textColor;
    private int subTextColor;
    private int borderColor;
    private int inputFillColor;
    private int inputStrokeColor;
    private int resultFillColor;
    private int resultStrokeColor;
    private int cellEditColor;
    private int cellLockedColor;
    private int tableLineColor;
    private int compassArrowColor;
    private int compassRingColor;
    private int sinColor;
    private int cosColor;

    private ZoomLayout zoomLayout;

    private EditText azInput;
    private EditText activeAngleInput;
    private TextView compassCaption;
    private TextView azModeHint;
    private Button modeAzBtn;
    private Button modeRumboBtn;
    private Button modeContraAzBtn;
    private Button modeContraRumboBtn;
    private TextView compassAzLabel;
    private TextView compassRumboLabel;
    private TextView compassContraAzLabel;
    private TextView compassContraRumboLabel;
    private TextView azQuadrantChip;
    private TextView azDecimalLabel;
    private TextView azExplainLabel;
    private int azInputMode = 0;
    private CompassView compassAzView;
    private CompassView compassRumboView;
    private CompassView compassContraAzView;
    private CompassView compassContraRumboView;

    private SensorManager sensorManager;
    private Sensor accelerometerSensor;
    private Sensor magneticSensor;
    private final float[] accelValues = new float[3];
    private final float[] magneticValues = new float[3];
    private boolean hasAccelValues = false;
    private boolean hasMagneticValues = false;
    private CompassView liveMagCompassView;
    private CompassView gpsCompassView;
    private CompassView selectedOrientationCompassView;
    private TextView liveCompassTitle;
    private TextView liveMagStatus;
    private TextView gpsCompassStatus;
    private TextView orientationGpsMetric;
    private TextView orientationSignalMetric;
    private TextView orientationPrecisionMetric;
    private TextView magneticSensorMetric;
    private TextView magneticPrecisionMetric;
    private TextView magneticCalibrationMetric;
    private LinearLayout orientationMagneticPanel;
    private LinearLayout orientationAbPanel;
    private Button orientationMagneticTab;
    private Button orientationAbTab;
    private CompassView magneticCompassDial;
    private CompassView abCompassDial;
    private TextView magneticHeadingValue;
    private TextView magneticHeadingLabel;
    private TextView magneticHintText;
    private TextView magneticSensorInfo;
    private TextView abHeadingValue;
    private TextView abHeadingLabel;
    private TextView abDistanceValue;
    private TextView abAzimuthValue;
    private TextView orientationPointAInfo;
    private TextView orientationPointBInfo;
    private int orientationCompassMode = 0; // 0 auto, 1 magnética, 2 A-B / GPS
    private LocationManager locationManager;
    private Location lastGpsLocation;
    private boolean gpsCompassRunning = false;
    private Location gpsStartLocation;
    private double gpsWalkDistanceMeters = 0.0;
    private long gpsStartMillis = 0L;
    private Double gpsDetectedBearing = null;
    private final Handler gpsUiHandler = new Handler(Looper.getMainLooper());
    private int magneticAccuracy = SensorManager.SENSOR_STATUS_UNRELIABLE;
    private boolean useTrueNorth = true;
    private double smoothedMagneticAzimuth = Double.NaN;
    private double smoothedGpsBearing = Double.NaN;
    private float lastGpsBearingAccuracy = Float.NaN;
    private int invalidGpsBearingUpdates = 0;
    private final List<Location> orientationRecentLocations = new ArrayList<>();
    private final List<Location> orientationAverageSamples = new ArrayList<>();
    private boolean orientationAverageRunning = false;
    private boolean orientationAverageForA = true;
    private long orientationAverageEndsAt = 0L;

    private EditText coordAzInput;
    private EditText distanceInput;
    private TextView coordResult;
    private TextView coordEastMetric;
    private TextView coordNorthMetric;
    private TextView coordQuadrantInfo;
    private PartialCoordinateDiagramView coordDiagram;

    private static final int DIST_MODE_DI_ANGLE = 0;
    private static final int DIST_MODE_DH_DN = 1;
    private static final int DIST_MODE_DH_DI = 2;
    private static final int DIST_MODE_DI_DN = 3;

    private EditText dhInput;
    private EditText diInput;
    private EditText angleInput;
    private EditText desnivelInput;
    private TextView distanceCalcResult;
    private TextView distanceSlopePreview;
    private static final int DIST_ACCENT_DH = Color.rgb(66, 154, 255);
    private static final int DIST_ACCENT_DI = Color.rgb(61, 222, 255);
    private static final int DIST_ACCENT_ANGLE = Color.rgb(255, 192, 62);
    private static final int DIST_ACCENT_DN = Color.rgb(92, 229, 128);
    private static final int DIST_ACCENT_SLOPE = Color.rgb(168, 96, 255);
    private TextView distanceDhCardValue;
    private TextView distanceDiCardValue;
    private TextView distanceDnCardValue;
    private TextView distanceSlopeCardValue;
    private int distanceCalcMode = DIST_MODE_DI_ANGLE;
    private final List<Button> distanceModeButtons = new ArrayList<>();
    private SlopeDiagramView slopeDiagram;

    private EditText polyX0Input;
    private EditText polyY0Input;
    private TextView polyCheckResult;
    private TextView polyProcedureResult;
    private PolyPreviewView polyPreview;
    private EditText hiloSupCalcInput;
    private EditText hiloInfCalcInput;
    private TextView hiloDistValue;
    private TextView hiloDistCalcResult;
    private StadiaDiagramView twoHairDiagram;


    private TextView levelCheckResult;
    private TextView stadiaCheckResult;

    private final List<TableDataRow> tableRows = new ArrayList<>();
    private final List<LevelDataRow> levelRows = new ArrayList<>();
    private final List<StadiaLevelRow> stadiaRows = new ArrayList<>();
    private TableLayout coordTable;
    private TableLayout levelTable;
    private TableLayout stadiaTable;
    private boolean suppressWorkCapture = false;
    private boolean showingSettings = false;
    private String singleToolKey;
    private boolean settingsOnly;
    private ScrollView mainScroll;
    private Location orientationPointA;
    private Location orientationPointB;
    private TextView twoPointStatus;
    private Button viewOrientationMapButton;

    private View selectedColorCell;
    private TableLayout selectedColorTable;
    private int selectedColorRow = -1;
    private int selectedColorCol = -1;
    private EditText selectedDistCell;
    private int manualTextColorIndex = 0;
    private int manualBgColorIndex = 0;
    private final int[] manualTextColors = {
            Color.rgb(245, 245, 247),
            Color.rgb(255, 171, 0),
            Color.rgb(0, 184, 148),
            Color.rgb(64, 158, 255),
            Color.rgb(255, 82, 82),
            Color.rgb(30, 33, 40)
    };
    private final int[] manualBgColors = {
            Color.rgb(25, 31, 42),
            Color.rgb(51, 38, 10),
            Color.rgb(9, 45, 35),
            Color.rgb(12, 44, 82),
            Color.rgb(70, 24, 24),
            Color.rgb(245, 246, 250)
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadPrefs();
        initOrientationServices();
        singleToolKey = getIntent().getStringExtra("single_tool");
        settingsOnly = getIntent().getBooleanExtra("settings_only", false);
        boolean requestedSettings = getIntent().getBooleanExtra("show_settings", false);
        if (singleToolKey != null && !singleToolKey.trim().isEmpty()) {
            buildSingleToolUi(singleToolKey);
        } else if (requestedSettings) {
            showSettingsScreen();
        } else {
            startActivity(new android.content.Intent(this, DashboardActivity.class));
            finish();
        }
    }

    @Override
    protected void onPause() {
        saveCurrentWork();
        unregisterMagneticCompass();
        stopGpsCompass();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean useMagnetic = orientationCompassMode == 1 || (orientationCompassMode == 0 && magneticSensor != null && accelerometerSensor != null);
        if (useMagnetic) registerMagneticCompass();
        else applyOrientationModeToViews();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            boolean granted = false;
            for (int r : grantResults) {
                if (r == PackageManager.PERMISSION_GRANTED) {
                    granted = true;
                    break;
                }
            }
            if (granted) startGpsCompass();
            else if (gpsCompassStatus != null) gpsCompassStatus.setText("Permiso de ubicación denegado.");
        }
    }

    @Override
    public void onBackPressed() {
        if (showingSettings) {
            showingSettings = false;
            if (settingsOnly) finish();
            else if (singleToolKey != null && !singleToolKey.trim().isEmpty()) buildSingleToolUi(singleToolKey);
            else {
                startActivity(new android.content.Intent(this, DashboardActivity.class));
                finish();
            }
        } else {
            super.onBackPressed();
        }
    }

    private void loadPrefs() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        themeMode = sp.getInt("theme", THEME_DARK);
        accentIndex = sp.getInt("accent", 0);
        arrowColorIndex = sp.getInt("arrow_color", 0);
        ringColorIndex = sp.getInt("ring_color", 0);
        orientationCompassMode = sp.getInt("orientation_compass_mode", 0);
        useTrueNorth = sp.getBoolean("true_north", true);
    }

    private void savePrefs() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt("theme", themeMode)
                .putInt("accent", accentIndex)
                .putInt("arrow_color", arrowColorIndex)
                .putInt("ring_color", ringColorIndex)
                .putInt("orientation_compass_mode", orientationCompassMode)
                .putBoolean("true_north", useTrueNorth)
                .apply();
    }

    private void applyPalette() {
        borderColor = ACCENTS[accentIndex % ACCENTS.length];
        compassArrowColor = COMPASS_ARROW_COLORS[arrowColorIndex % COMPASS_ARROW_COLORS.length];
        compassRingColor = COMPASS_RING_COLORS[ringColorIndex % COMPASS_RING_COLORS.length];

        sinColor = Color.rgb(255, 171, 0);
        cosColor = Color.rgb(0, 184, 148);

        if (themeMode == THEME_LIGHT) {
            bgColor = Color.rgb(241, 244, 248);
            appBarColor = Color.rgb(20, 33, 61);
            cardColor = Color.WHITE;
            textColor = Color.rgb(30, 33, 40);
            subTextColor = Color.rgb(96, 104, 118);
            inputFillColor = Color.WHITE;
            inputStrokeColor = Color.rgb(178, 184, 196);
            resultFillColor = Color.rgb(245, 252, 248);
            resultStrokeColor = Color.rgb(29, 185, 84);
            cellEditColor = Color.rgb(252, 253, 255);
            cellLockedColor = Color.rgb(244, 246, 250);
            tableLineColor = Color.rgb(190, 196, 206);
        } else if (themeMode == THEME_BLACK) {
            bgColor = Color.BLACK;
            appBarColor = Color.rgb(3, 20, 34);
            cardColor = Color.rgb(9, 11, 15);
            textColor = Color.rgb(245, 245, 247);
            subTextColor = Color.rgb(179, 184, 192);
            inputFillColor = Color.rgb(14, 16, 22);
            inputStrokeColor = Color.rgb(79, 85, 96);
            resultFillColor = Color.rgb(14, 31, 23);
            resultStrokeColor = Color.rgb(0, 200, 83);
            cellEditColor = Color.rgb(12, 18, 28);
            cellLockedColor = Color.rgb(21, 23, 28);
            tableLineColor = Color.rgb(74, 78, 88);
        } else {
            bgColor = Color.rgb(7, 22, 36);
            appBarColor = Color.rgb(3, 45, 73);
            cardColor = Color.rgb(17, 38, 58);
            textColor = Color.rgb(248, 250, 252);
            subTextColor = Color.rgb(199, 211, 222);
            inputFillColor = Color.rgb(10, 29, 45);
            inputStrokeColor = Color.rgb(92, 112, 132);
            resultFillColor = Color.rgb(9, 50, 42);
            resultStrokeColor = Color.rgb(0, 210, 125);
            cellEditColor = Color.rgb(10, 31, 50);
            cellLockedColor = Color.rgb(21, 40, 57);
            tableLineColor = Color.rgb(86, 105, 123);
        }
    }

    private void buildUi() {
        if (!suppressWorkCapture) saveCurrentWork();
        showingSettings = false;
        applyPalette();
        tableRows.clear();
        levelRows.clear();
        stadiaRows.clear();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);

        root.addView(topBar());

        mainScroll = new ScrollView(this);
        mainScroll.setFillViewport(true);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(10), dp(14), dp(24));
        content.setBackgroundColor(bgColor);

        View gpsSection = collapsibleCard((LinearLayout) gpsLoggerEntryBlock(), "⌖", "GPS y mapas", false);
        View fieldToolsSection = collapsibleCard((LinearLayout) fieldToolsEntryBlock(), "▦", "Herramientas de campo", false);
        View converterSection = collapsibleCard((LinearLayout) converterEntryBlock(), "⇄", "Conversor de unidades", false);
        View compassSection = collapsibleCard((LinearLayout) orientationCompassBlock(), "N", "Orientación y brújula", false);
        View azimuthSection = collapsibleCard((LinearLayout) azimuthBlock(), "∠", "Azimut y rumbo", false);
        View coordSection = collapsibleCard((LinearLayout) coordBlock(), "Δ", "Coordenadas parciales", false);
        View distanceSection = collapsibleCard((LinearLayout) distanceBlock(), "↗", "Distancia y pendiente", false);
        View twoHairSection = collapsibleCard((LinearLayout) twoHairDistanceMiniBlock(), "Ⅱ", "Distancia por dos hilos", false);
        View polygonSection = collapsibleCard((LinearLayout) partialTableBlock(), "◇", "Poligonal cerrada", false);
        View levelSection = collapsibleCard((LinearLayout) levelingBlock(), "≋", "Nivelación", false);
        View stadiaSection = collapsibleCard((LinearLayout) stadiaLevelingBlock(), "Ⅲ", "Nivelación con tres hilos", false);

        content.addView(gpsSection);
        content.addView(fieldToolsSection);
        content.addView(converterSection);
        content.addView(compassSection);
        content.addView(azimuthSection);
        content.addView(coordSection);
        content.addView(distanceSection);
        content.addView(twoHairSection);
        content.addView(polygonSection);
        content.addView(levelSection);
        content.addView(stadiaSection);

        mainScroll.addView(content);
        root.addView(mainScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));
        setContentView(root);
        restoreCurrentWork();

        boolean openSettings = getIntent().getBooleanExtra("show_settings", false);
        String openTool = getIntent().getStringExtra("open_tool");
        getIntent().removeExtra("show_settings");
        getIntent().removeExtra("open_tool");
        if (openSettings) {
            showSettingsScreen();
            return;
        }

        View requested = null;
        if ("compass".equals(openTool)) requested = compassSection;
        else if ("azimuth".equals(openTool)) requested = azimuthSection;
        else if ("coordinates".equals(openTool)) requested = coordSection;
        else if ("distance".equals(openTool)) requested = distanceSection;
        else if ("two_hair".equals(openTool)) requested = twoHairSection;
        else if ("polygon".equals(openTool)) requested = polygonSection;
        else if ("level".equals(openTool)) requested = levelSection;
        else if ("stadia".equals(openTool)) requested = stadiaSection;

        if (requested != null) {
            final View targetView = requested;
            setSectionOpen(targetView, true);
            mainScroll.post(new Runnable() {
                @Override public void run() {
                    mainScroll.smoothScrollTo(0, Math.max(0, targetView.getTop() - dp(8)));
                }
            });
        }
    }

    private void buildSingleToolUi(String key) {
        if (!suppressWorkCapture) saveCurrentWork();
        showingSettings = false;
        applyPalette();
        tableRows.clear();
        levelRows.clear();
        stadiaRows.clear();

        String title;
        String subtitle;
        View body;
        if ("compass".equals(key)) {
            title = "Orientación y brújula";
            subtitle = "Brújula magnética y orientación GPS";
            body = orientationCompassBlock();
        } else if ("azimuth".equals(key)) {
            title = "Azimut y rumbo";
            subtitle = "Conversión, contraazimut y cuadrantes";
            body = azimuthBlock();
        } else if ("coordinates".equals(key)) {
            title = "Coordenadas parciales";
            subtitle = "Incrementos Este/Oeste y Norte/Sur";
            body = coordBlock();
        } else if ("distance".equals(key)) {
            title = "Distancia y pendiente";
            subtitle = "Distancia horizontal, inclinada y desnivel";
            body = distanceBlock();
        } else if ("two_hair".equals(key)) {
            title = "Distancia por dos hilos";
            subtitle = "Cálculo estadimétrico";
            body = twoHairDistanceMiniBlock();
        } else if ("polygon".equals(key)) {
            title = "Poligonal cerrada";
            subtitle = "Cierre y coordenadas parciales";
            body = partialTableBlock();
        } else if ("level".equals(key)) {
            title = "Nivelación";
            subtitle = "Cálculo de cotas y control de cierre";
            body = levelingBlock();
        } else if ("stadia".equals(key)) {
            title = "Nivelación con tres hilos";
            subtitle = "Hilo inferior, medio y superior";
            body = stadiaLevelingBlock();
        } else {
            finish();
            return;
        }

        FrameLayout root;
        if (themeMode == THEME_LIGHT) {
            root = new FrameLayout(this);
            root.setBackgroundColor(bgColor);
        } else {
            root = NativeUi.screen(this);
        }
        LinearLayout page = NativeUi.column(this);
        page.addView(NativeUi.pageHeader(this, title, subtitle, v -> finish(), "⚙", v -> showSettingsScreen()));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12), dp(8), dp(12), dp(18));
        content.setBackgroundColor(Color.TRANSPARENT);
        content.addView(body, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        scroll.addView(content);
        page.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(page, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        restoreCurrentWork();
    }

    private void saveCurrentWork() {
        SharedPreferences.Editor ed = getSharedPreferences(PREFS, MODE_PRIVATE).edit();

        putText(ed, "work_az_input", azInput);
        putText(ed, "work_az_label", compassAzLabel);
        putText(ed, "work_rumbo_label", compassRumboLabel);
        putText(ed, "work_contraaz_label", compassContraAzLabel);
        putText(ed, "work_contrarumbo_label", compassContraRumboLabel);
        putText(ed, "work_compass_caption", compassCaption);

        putText(ed, "work_coord_az", coordAzInput);
        putText(ed, "work_coord_dist", distanceInput);
        putText(ed, "work_coord_result", coordResult);

        putText(ed, "work_dh", dhInput);
        putText(ed, "work_di", diInput);
        putText(ed, "work_angle", angleInput);
        putText(ed, "work_desnivel", desnivelInput);
        putText(ed, "work_distance_result", distanceCalcResult);
        putText(ed, "work_hilo_sup_calc", hiloSupCalcInput);
        putText(ed, "work_hilo_inf_calc", hiloInfCalcInput);
        putText(ed, "work_hilo_dist_value", hiloDistValue);
        putText(ed, "work_hilo_dist_result", hiloDistCalcResult);
        putText(ed, "work_poly_x0", polyX0Input);
        putText(ed, "work_poly_y0", polyY0Input);
        putText(ed, "work_poly_check", polyCheckResult);
        putText(ed, "work_poly_proc", polyProcedureResult);

        putText(ed, "work_level_check", levelCheckResult);
        putText(ed, "work_stadia_check", stadiaCheckResult);

        ed.putInt("work_coord_count", tableRows.size());
        for (int i = 0; i < tableRows.size(); i++) {
            TableDataRow r = tableRows.get(i);
            putText(ed, "work_coord_" + i + "_est", r.est);
            putText(ed, "work_coord_" + i + "_pv", r.pv);
            putText(ed, "work_coord_" + i + "_az", r.az);
            putText(ed, "work_coord_" + i + "_dist", r.dist);
            putText(ed, "work_coord_" + i + "_rumbo", r.rumbo);
            putText(ed, "work_coord_" + i + "_sen", r.sen);
            putText(ed, "work_coord_" + i + "_cos", r.cos);
            putText(ed, "work_coord_" + i + "_este", r.este);
            putText(ed, "work_coord_" + i + "_oeste", r.oeste);
            putText(ed, "work_coord_" + i + "_norte", r.norte);
            putText(ed, "work_coord_" + i + "_sur", r.sur);
            putText(ed, "work_coord_" + i + "_ec", r.eCorr);
            putText(ed, "work_coord_" + i + "_wc", r.wCorr);
            putText(ed, "work_coord_" + i + "_nc", r.nCorr);
            putText(ed, "work_coord_" + i + "_sc", r.sCorr);
            putText(ed, "work_coord_" + i + "_x", r.x);
            putText(ed, "work_coord_" + i + "_y", r.y);
        }

        ed.putInt("work_level_count", levelRows.size());
        for (int i = 0; i < levelRows.size(); i++) {
            LevelDataRow r = levelRows.get(i);
            putText(ed, "work_level_" + i + "_pv", r.pv);
            putText(ed, "work_level_" + i + "_va", r.vAtras);
            putText(ed, "work_level_" + i + "_vi", r.vIntermedia);
            putText(ed, "work_level_" + i + "_vf", r.vAdelante);
            putText(ed, "work_level_" + i + "_ct", r.cotaTerreno);
            putText(ed, "work_level_" + i + "_cn", r.cotaNivel);
        }

        ed.putInt("work_stadia_count", stadiaRows.size());
        for (int i = 0; i < stadiaRows.size(); i++) {
            StadiaLevelRow r = stadiaRows.get(i);
            putText(ed, "work_stadia_" + i + "_pv", r.pv);
            putText(ed, "work_stadia_" + i + "_tipo", r.tipo);
            putText(ed, "work_stadia_" + i + "_hi", r.hInf);
            putText(ed, "work_stadia_" + i + "_hm", r.hMedio);
            putText(ed, "work_stadia_" + i + "_hs", r.hSup);
            putText(ed, "work_stadia_" + i + "_dist", r.distancia);
            putText(ed, "work_stadia_" + i + "_ct", r.cotaTerreno);
            putText(ed, "work_stadia_" + i + "_cn", r.cotaNivel);
        }

        ed.apply();
    }

    private void restoreCurrentWork() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);

        setTextIfExists(sp, "work_az_input", azInput);
        setTextIfExists(sp, "work_az_label", compassAzLabel);
        setTextIfExists(sp, "work_rumbo_label", compassRumboLabel);
        setTextIfExists(sp, "work_contraaz_label", compassContraAzLabel);
        setTextIfExists(sp, "work_contrarumbo_label", compassContraRumboLabel);
        setTextIfExists(sp, "work_compass_caption", compassCaption);

        setTextIfExists(sp, "work_coord_az", coordAzInput);
        setTextIfExists(sp, "work_coord_dist", distanceInput);
        setTextIfExists(sp, "work_coord_result", coordResult);

        setTextIfExists(sp, "work_dh", dhInput);
        setTextIfExists(sp, "work_di", diInput);
        setTextIfExists(sp, "work_angle", angleInput);
        setTextIfExists(sp, "work_desnivel", desnivelInput);
        setTextIfExists(sp, "work_distance_result", distanceCalcResult);
        setTextIfExists(sp, "work_hilo_sup_calc", hiloSupCalcInput);
        setTextIfExists(sp, "work_hilo_inf_calc", hiloInfCalcInput);
        setTextIfExists(sp, "work_hilo_dist_value", hiloDistValue);
        setTextIfExists(sp, "work_hilo_dist_result", hiloDistCalcResult);
        setTextIfExists(sp, "work_poly_x0", polyX0Input);
        setTextIfExists(sp, "work_poly_y0", polyY0Input);
        setTextIfExists(sp, "work_poly_check", polyCheckResult);
        setTextIfExists(sp, "work_poly_proc", polyProcedureResult);

        setTextIfExists(sp, "work_level_check", levelCheckResult);
        setTextIfExists(sp, "work_stadia_check", stadiaCheckResult);

        for (int i = 0; i < tableRows.size(); i++) {
            TableDataRow r = tableRows.get(i);
            setTextIfExists(sp, "work_coord_" + i + "_est", r.est);
            setTextIfExists(sp, "work_coord_" + i + "_pv", r.pv);
            setTextIfExists(sp, "work_coord_" + i + "_az", r.az);
            setTextIfExists(sp, "work_coord_" + i + "_dist", r.dist);
            setTextIfExists(sp, "work_coord_" + i + "_rumbo", r.rumbo);
            setTextIfExists(sp, "work_coord_" + i + "_sen", r.sen);
            setTextIfExists(sp, "work_coord_" + i + "_cos", r.cos);
            setTextIfExists(sp, "work_coord_" + i + "_este", r.este);
            setTextIfExists(sp, "work_coord_" + i + "_oeste", r.oeste);
            setTextIfExists(sp, "work_coord_" + i + "_norte", r.norte);
            setTextIfExists(sp, "work_coord_" + i + "_sur", r.sur);
            setTextIfExists(sp, "work_coord_" + i + "_ec", r.eCorr);
            setTextIfExists(sp, "work_coord_" + i + "_wc", r.wCorr);
            setTextIfExists(sp, "work_coord_" + i + "_nc", r.nCorr);
            setTextIfExists(sp, "work_coord_" + i + "_sc", r.sCorr);
            setTextIfExists(sp, "work_coord_" + i + "_x", r.x);
            setTextIfExists(sp, "work_coord_" + i + "_y", r.y);
        }

        for (int i = 0; i < levelRows.size(); i++) {
            LevelDataRow r = levelRows.get(i);
            setTextIfExists(sp, "work_level_" + i + "_pv", r.pv);
            setTextIfExists(sp, "work_level_" + i + "_va", r.vAtras);
            setTextIfExists(sp, "work_level_" + i + "_vi", r.vIntermedia);
            setTextIfExists(sp, "work_level_" + i + "_vf", r.vAdelante);
            setTextIfExists(sp, "work_level_" + i + "_ct", r.cotaTerreno);
            setTextIfExists(sp, "work_level_" + i + "_cn", r.cotaNivel);
        }

        for (int i = 0; i < stadiaRows.size(); i++) {
            StadiaLevelRow r = stadiaRows.get(i);
            setTextIfExists(sp, "work_stadia_" + i + "_pv", r.pv);
            setTextIfExists(sp, "work_stadia_" + i + "_tipo", r.tipo);
            setTextIfExists(sp, "work_stadia_" + i + "_hi", r.hInf);
            setTextIfExists(sp, "work_stadia_" + i + "_hm", r.hMedio);
            setTextIfExists(sp, "work_stadia_" + i + "_hs", r.hSup);
            setTextIfExists(sp, "work_stadia_" + i + "_dist", r.distancia);
            setTextIfExists(sp, "work_stadia_" + i + "_ct", r.cotaTerreno);
            setTextIfExists(sp, "work_stadia_" + i + "_cn", r.cotaNivel);
        }

        if (azInput != null) {
            try {
                String s = azInput.getText().toString().trim();
                if (!s.isEmpty()) {
                    double az = normalize(parseAngle(s));
                    double contra = contraAzimuth(az);
                    if (compassAzView != null) compassAzView.setAzimuth(az);
                    if (compassRumboView != null) compassRumboView.setAzimuth(az);
                    if (compassContraAzView != null) compassContraAzView.setAzimuth(contra);
                    if (compassContraRumboView != null) compassContraRumboView.setAzimuth(contra);
                }
            } catch (Exception ignored) {
            }
        }
    }

    private void putText(SharedPreferences.Editor ed, String key, TextView view) {
        if (view != null) ed.putString(key, view.getText().toString());
    }

    private void setTextIfExists(SharedPreferences sp, String key, TextView view) {
        if (view != null && sp.contains(key)) view.setText(sp.getString(key, ""));
    }

    private void clearWorkAndRebuild() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        for (String key : sp.getAll().keySet()) {
            if (key.startsWith("work_")) ed.remove(key);
        }
        ed.commit();
        suppressWorkCapture = true;
        if (settingsOnly) showSettingsScreen();
        else if (singleToolKey != null && !singleToolKey.trim().isEmpty()) buildSingleToolUi(singleToolKey);
        else {
            startActivity(new android.content.Intent(this, DashboardActivity.class));
            finish();
        }
        suppressWorkCapture = false;
    }

    private View topBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(10), dp(8), dp(10), dp(8));
        bar.setBackgroundColor(appBarColor);

        LinearLayout titleWrap = new LinearLayout(this);
        titleWrap.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        titleWrap.setLayoutParams(titleParams);

        TextView title = new TextView(this);
        title.setText("Geo Topo");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        titleWrap.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Cálculos topográficos");
        sub.setTextColor(Color.rgb(193, 218, 240));
        sub.setTextSize(11);
        titleWrap.addView(sub);
        bar.addView(titleWrap);

        TextView settings = new TextView(this);
        settings.setText("⚙");
        settings.setContentDescription("Ajustes");
        settings.setGravity(Gravity.CENTER);
        settings.setTextColor(Color.WHITE);
        settings.setTextSize(18);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(withAlpha(borderColor, 210));
        gd.setCornerRadius(dp(19));
        settings.setBackground(gd);
        settings.setOnClickListener(v -> showSettingsScreen());
        bar.addView(settings, new LinearLayout.LayoutParams(dp(38), dp(38)));

        return bar;
    }

    private void showSettingsScreen() {
        saveCurrentWork();
        applyPalette();
        showingSettings = true;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);

        root.addView(settingsBar());

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(18), dp(14), dp(24));
        content.setBackgroundColor(bgColor);

        content.addView(settingHeader("APARIENCIA"));
        content.addView(themeRow("☀", "Tema claro", "Fondo blanco limpio", THEME_LIGHT));
        content.addView(themeRow("☾", "Tema oscuro", "Fondo azul oscuro", THEME_DARK));
        content.addView(themeRow("●", "Tema negro", "Fondo negro AMOLED", THEME_BLACK));

        content.addView(settingHeader("COLORES"));
        content.addView(valueRow("▣", "Color de cuadros", accentName(accentIndex), v ->
                showColorPickerDialog("Color de cuadros", accentNames(), ACCENTS, accentIndex, index -> {
                    accentIndex = index;
                    savePrefs();
                    showSettingsScreen();
                })));
        content.addView(valueRow("➤", "Flecha de brújula", arrowName(arrowColorIndex), v ->
                showColorPickerDialog("Flecha de brújula", arrowNames(), COMPASS_ARROW_COLORS, arrowColorIndex, index -> {
                    arrowColorIndex = index;
                    savePrefs();
                    showSettingsScreen();
                })));
        content.addView(valueRow("◎", "Círculo de brújula", ringName(ringColorIndex), v ->
                showColorPickerDialog("Círculo de brújula", ringNames(), COMPASS_RING_COLORS, ringColorIndex, index -> {
                    ringColorIndex = index;
                    savePrefs();
                    showSettingsScreen();
                })));

        content.addView(settingHeader("TABLAS Y DATOS"));
        content.addView(infoRow("＋", "Agregar filas", "Usa + Fila o + Punto dentro de cada cuadro"));
        content.addView(infoRow("□", "Recordar datos", "Abrir donde te quedaste"));
        content.addView(valueRow("🧹", "Limpiar datos guardados", "Borra todos los cuadros", v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Limpiar datos")
                    .setMessage("¿Quieres borrar los datos guardados de los cuadros?")
                    .setPositiveButton("Borrar", (d, w) -> {
                        clearWorkAndRebuild();
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        }));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private View settingsBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(16), dp(14), dp(16));
        bar.setBackgroundColor(appBarColor);

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextColor(Color.WHITE);
        back.setTextSize(40);
        back.setGravity(Gravity.CENTER);
        back.setTypeface(Typeface.DEFAULT_BOLD);
        back.setOnClickListener(v -> {
            showingSettings = false;
            if (settingsOnly) finish();
            else if (singleToolKey != null && !singleToolKey.trim().isEmpty()) buildSingleToolUi(singleToolKey);
            else {
                startActivity(new android.content.Intent(this, DashboardActivity.class));
                finish();
            }
        });
        bar.addView(back, new LinearLayout.LayoutParams(dp(54), dp(54)));

        TextView title = new TextView(this);
        title.setText("Ajustes");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView ok = new TextView(this);
        ok.setText("✓");
        ok.setTextColor(Color.WHITE);
        ok.setTextSize(34);
        ok.setGravity(Gravity.CENTER);
        ok.setTypeface(Typeface.DEFAULT_BOLD);
        ok.setOnClickListener(v -> {
            savePrefs();
            showingSettings = false;
            buildUi();
        });
        bar.addView(ok, new LinearLayout.LayoutParams(dp(54), dp(54)));
        return bar;
    }

    private TextView settingHeader(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(borderColor);
        v.setTextSize(14);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setPadding(dp(4), dp(18), dp(4), dp(8));
        return v;
    }

    private View themeRow(String icon, String title, String subtitle, int mode) {
        return settingRow(icon, title, subtitle, themeMode == mode ? "◉" : "○", v -> {
            themeMode = mode;
            savePrefs();
            showSettingsScreen();
        });
    }

    private View valueRow(String icon, String title, String subtitle, View.OnClickListener listener) {
        return settingRow(icon, title, subtitle, "›", listener);
    }

    private View infoRow(String icon, String title, String subtitle) {
        return settingRow(icon, title, subtitle, "", null);
    }

    private View settingRow(String icon, String title, String subtitle, String right, View.OnClickListener listener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == THEME_LIGHT ? Color.WHITE : Color.rgb(12, 35, 52));
        bg.setStroke(dp(1), themeMode == THEME_LIGHT ? Color.rgb(225, 230, 238) : Color.rgb(16, 48, 70));
        row.setBackground(bg);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.setMargins(0, 0, 0, dp(6));
        row.setLayoutParams(rlp);
        if (listener != null) row.setOnClickListener(listener);

        TextView ico = new TextView(this);
        ico.setText(icon);
        ico.setTextSize(24);
        ico.setTextColor(borderColor);
        ico.setGravity(Gravity.CENTER);
        row.addView(ico, new LinearLayout.LayoutParams(dp(58), dp(54)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(textColor);
        t.setTextSize(18);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        texts.addView(t);
        TextView s = new TextView(this);
        s.setText(subtitle);
        s.setTextColor(subTextColor);
        s.setTextSize(13);
        texts.addView(s);
        row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView rr = new TextView(this);
        rr.setText(right);
        rr.setTextColor(right.equals("◉") ? borderColor : subTextColor);
        rr.setTextSize(right.equals("›") ? 30 : 20);
        rr.setGravity(Gravity.CENTER);
        row.addView(rr, new LinearLayout.LayoutParams(dp(42), dp(54)));
        return row;
    }

    private String accentName(int idx) {
        String[] names = accentNames();
        return names[idx % names.length];
    }

    private String arrowName(int idx) {
        String[] names = arrowNames();
        return names[idx % names.length];
    }

    private String ringName(int idx) {
        String[] names = ringNames();
        return names[idx % names.length];
    }

    private String[] accentNames() {
        return fullColorNames();
    }

    private String[] arrowNames() {
        return fullColorNames();
    }

    private String[] ringNames() {
        return fullColorNames();
    }

    private String[] fullColorNames() {
        return new String[]{
                "Azul", "Cian", "Turquesa", "Verde", "Verde lima", "Amarillo",
                "Ámbar", "Naranja", "Rojo", "Rosa", "Morado", "Índigo",
                "Marrón", "Gris", "Negro", "Blanco"
        };
    }

    private void showColorPickerDialog(String title, String[] names, int[] colors, int currentIndex, ColorPickListener listener) {
        final int[] selected = {currentIndex};
        final AlertDialog[] dialogRef = new AlertDialog[1];

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(14), dp(14), dp(12));
        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setColor(themeMode == THEME_LIGHT ? Color.WHITE : Color.rgb(12, 25, 39));
        panelBg.setCornerRadius(dp(18));
        panelBg.setStroke(dp(1), themeMode == THEME_LIGHT ? Color.rgb(210, 218, 230) : Color.rgb(58, 76, 100));
        panel.setBackground(panelBg);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);

        TextView icon = new TextView(this);
        icon.setText("◉");
        icon.setGravity(Gravity.CENTER);
        icon.setTextSize(23);
        icon.setTextColor(borderColor);
        head.addView(icon, new LinearLayout.LayoutParams(dp(46), dp(46)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(textColor);
        titleView.setTextSize(22);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        texts.addView(titleView);
        TextView help = new TextView(this);
        help.setText("Elige el color que quieres aplicar.");
        help.setTextColor(subTextColor);
        help.setTextSize(13);
        texts.addView(help);
        head.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView close = new TextView(this);
        close.setText("×");
        close.setGravity(Gravity.CENTER);
        close.setTextColor(subTextColor);
        close.setTextSize(30);
        close.setOnClickListener(v -> {
            if (dialogRef[0] != null) dialogRef[0].dismiss();
        });
        head.addView(close, new LinearLayout.LayoutParams(dp(44), dp(44)));
        panel.addView(head);

        ScrollView scroller = new ScrollView(this);
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        grid.setPadding(0, dp(10), 0, dp(6));

        int columns = 2;
        for (int i = 0; i < names.length && i < colors.length; i += columns) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < columns; c++) {
                int index = i + c;
                if (index >= names.length || index >= colors.length) {
                    SpaceView spacer = new SpaceView(this);
                    row.addView(spacer, weightParams());
                    continue;
                }
                View option = colorOptionView(names[index], colors[index], index == currentIndex);
                final int picked = index;
                option.setOnClickListener(v -> {
                    selected[0] = picked;
                    listener.onPick(picked);
                    if (dialogRef[0] != null) dialogRef[0].dismiss();
                });
                row.addView(option, weightParams());
            }
            grid.addView(row);
        }
        scroller.addView(grid);
        panel.addView(scroller, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(380)));

        TextView note = new TextView(this);
        note.setText("Se aplica al instante y queda guardado al volver.");
        note.setTextColor(subTextColor);
        note.setTextSize(12);
        note.setPadding(dp(4), dp(2), dp(4), dp(8));
        panel.addView(note);

        Button cancel = btn("Cerrar");
        cancel.setOnClickListener(v -> {
            if (dialogRef[0] != null) dialogRef[0].dismiss();
        });
        panel.addView(cancel);

        ScrollView graphScroll = new ScrollView(this);
        graphScroll.addView(panel);
        AlertDialog dialog = new AlertDialog.Builder(this).setView(graphScroll).create();
        dialogRef[0] = dialog;
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            }
        });
        dialog.show();
    }

    private View colorOptionView(String name, int color, boolean selected) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(8), dp(8), dp(8));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == THEME_LIGHT ? Color.rgb(248, 250, 255) : Color.rgb(15, 26, 40));
        bg.setCornerRadius(dp(11));
        bg.setStroke(dp(selected ? 2 : 1), selected ? color : inputStrokeColor);
        row.setBackground(bg);

        TextView chip = new TextView(this);
        chip.setText(selected ? "✓" : "");
        chip.setGravity(Gravity.CENTER);
        chip.setTextColor(bestContrastColor(color));
        chip.setTextSize(15);
        chip.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable chipBg = new GradientDrawable();
        chipBg.setShape(GradientDrawable.OVAL);
        chipBg.setColor(color);
        chipBg.setStroke(dp(1), Color.rgb(188, 194, 205));
        chip.setBackground(chipBg);
        row.addView(chip, new LinearLayout.LayoutParams(dp(34), dp(34)));

        TextView label = new TextView(this);
        label.setText(name);
        label.setTextColor(textColor);
        label.setTextSize(14);
        label.setTypeface(selected ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        label.setPadding(dp(10), 0, 0, 0);
        row.addView(label, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return row;
    }

    public static class SpaceView extends View {
        public SpaceView(Context context) { super(context); }
    }

    private int bestContrastColor(int color) {
        int r = Color.red(color);
        int g = Color.green(color);
        int b = Color.blue(color);
        double luminance = (0.299 * r + 0.587 * g + 0.114 * b);
        return luminance > 170 ? Color.rgb(30, 33, 40) : Color.WHITE;
    }


    private final SensorEventListener magneticCompassListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                lowPassSensor(event.values, accelValues, hasAccelValues);
                hasAccelValues = true;
            } else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
                lowPassSensor(event.values, magneticValues, hasMagneticValues);
                hasMagneticValues = true;
            }
            updateMagneticCompass();
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
            if (sensor.getType() != Sensor.TYPE_MAGNETIC_FIELD) return;
            magneticAccuracy = accuracy;
            if (liveMagStatus != null && accuracy == SensorManager.SENSOR_STATUS_UNRELIABLE) {
                liveMagStatus.setText("Sensor magnético sin calibrar. Aléjate de metal y mueve el celular en forma de 8.");
            }
            updateMagneticUiState();
        }
    };

    private final LocationListener gpsCompassListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            updateGpsCompass(location);
        }

        @Override
        public void onProviderEnabled(String provider) {
            if (gpsCompassStatus != null) gpsCompassStatus.setText("GPS activo. Camina en línea recta hasta obtener una dirección estable.");
        }

        @Override
        public void onProviderDisabled(String provider) {
            if (gpsCompassStatus != null) gpsCompassStatus.setText("Activa ubicación/GPS del celular.");
        }
    };

    private void initOrientationServices() {
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (sensorManager != null) {
            accelerometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            magneticSensor = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        }
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
    }

    private View gpsLoggerEntryBlock() {
        LinearLayout box = card();
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(sectionTitle("GPS y mapas"));
        box.addView(small("Captura puntos, exporta CSV/KML/GPX y trabaja con mapas online u offline."));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button openGps = btn("GPS y mapas");
        openGps.setOnClickListener(v -> startActivity(new android.content.Intent(this, GpsOverviewActivity.class)));
        actions.addView(openGps, weightParams());
        Button openMap = btn("Abrir mapa");
        openMap.setOnClickListener(v -> startActivity(new android.content.Intent(this, MapActivity.class)));
        actions.addView(openMap, weightParams());
        box.addView(actions);
        return box;
    }

    private View fieldToolsEntryBlock() {
        LinearLayout box = card();
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(sectionTitle("Herramientas de campo"));
        box.addView(small("Replanteo, COGO completo, poligonales, nivelación, perfiles, recorridos GPS, mapas offline, control GNSS, receptor Bluetooth, libreta e intercambio de archivos."));

        Button open = btn("Abrir herramientas de campo");
        open.setOnClickListener(v -> startActivity(new android.content.Intent(this, FieldToolsActivity.class)));
        box.addView(open);
        return box;
    }

    private View converterEntryBlock() {
        LinearLayout box = card();
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(sectionTitle("Conversor de unidades"));
        box.addView(small("Convierte longitud, área, volumen, velocidad, ángulos y pendiente. Funciona sin internet y sin anuncios."));

        Button open = btn("Abrir conversor");
        open.setOnClickListener(v -> startActivity(new android.content.Intent(this, ConverterActivity.class)));
        box.addView(open);
        return box;
    }

    private View orientationCompassBlock() {
        LinearLayout box = toolColumn();

        LinearLayout tabsPanel = futuristicInnerPanel();
        tabsPanel.setOrientation(LinearLayout.HORIZONTAL);
        tabsPanel.setPadding(dp(10), dp(10), dp(10), dp(10));
        orientationMagneticTab = orientationTabButton("⌾  Brújula magnética");
        orientationMagneticTab.setOnClickListener(v -> {
            if (magneticSensor == null || accelerometerSensor == null) {
                orientationCompassMode = 2;
                applyOrientationModeToViews();
                showError("Este celular no tiene magnetómetro. Se usará Orientación A–B.");
                return;
            }
            orientationCompassMode = 1;
            savePrefs();
            applyOrientationModeToViews();
        });
        tabsPanel.addView(orientationMagneticTab, weightParams());
        orientationAbTab = orientationTabButton("⇢  Orientación A–B");
        orientationAbTab.setOnClickListener(v -> {
            orientationCompassMode = 2;
            savePrefs();
            applyOrientationModeToViews();
        });
        tabsPanel.addView(orientationAbTab, weightParams());
        box.addView(tabsPanel);

        orientationMagneticPanel = toolColumn();
        LinearLayout magneticStatusPanel = futuristicInnerPanel();
        LinearLayout magneticStatusRow = new LinearLayout(this);
        magneticStatusRow.setOrientation(LinearLayout.HORIZONTAL);
        magneticSensorMetric = metricText("SENSOR", "ACTIVO", Color.rgb(167, 232, 127));
        magneticPrecisionMetric = metricText("PRECISIÓN", "MEDIA", Color.rgb(255, 194, 67));
        magneticCalibrationMetric = metricText("CALIBRACIÓN", "REVISAR", Color.rgb(255, 140, 66));
        magneticStatusRow.addView(magneticSensorMetric, weightParams());
        magneticStatusRow.addView(magneticPrecisionMetric, weightParams());
        magneticStatusRow.addView(magneticCalibrationMetric, weightParams());
        magneticStatusPanel.addView(magneticStatusRow);
        orientationMagneticPanel.addView(magneticStatusPanel);

        LinearLayout magneticCompassCard = futuristicInnerPanel();
        magneticCompassCard.setGravity(Gravity.CENTER_HORIZONTAL);
        magneticCompassDial = new CompassView(this);
        magneticCompassDial.setSpanishWestLabel(true);
        magneticCompassDial.setUnavailableText("");
        magneticCompassDial.setDisplayStyle(CompassView.STYLE_ORIENTATION_HUD);
        magneticCompassDial.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(400)));
        magneticCompassCard.addView(magneticCompassDial);

        magneticHeadingValue = tv("—", 34, true);
        magneticHeadingValue.setGravity(Gravity.CENTER);
        magneticHeadingValue.setPadding(0, dp(6), 0, 0);
        magneticCompassCard.addView(magneticHeadingValue, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        magneticHeadingLabel = smallCenter("Rumbo actual");
        magneticHeadingLabel.setPadding(0, dp(4), 0, 0);
        magneticCompassCard.addView(magneticHeadingLabel);

        magneticHintText = smallCenter("Mueve el teléfono en forma de 8 para mejorar la precisión.");
        magneticHintText.setPadding(dp(12), dp(8), dp(12), dp(8));
        magneticCompassCard.addView(magneticHintText);

        LinearLayout magneticActions = new LinearLayout(this);
        magneticActions.setOrientation(LinearLayout.HORIZONTAL);
        magneticActions.setPadding(0, dp(6), 0, 0);
        Button calibrate = btn("Calibrar");
        calibrate.setOnClickListener(v -> {
            magneticAccuracy = SensorManager.SENSOR_STATUS_UNRELIABLE;
            updateMagneticUiState();
            if (liveMagStatus != null) {
                liveMagStatus.setText("Calibración recomendada: muévete en forma de 8, aléjate de metal y mantén el teléfono horizontal.");
            }
            Toast.makeText(this, "Mueve el teléfono en forma de 8 para calibrar la brújula.", Toast.LENGTH_SHORT).show();
        });
        magneticActions.addView(calibrate, weightParams());
        Button northRef = secondaryButton("Norte verdadero");
        northRef.setOnClickListener(v -> {
            useTrueNorth = !useTrueNorth;
            savePrefs();
            smoothedMagneticAzimuth = Double.NaN;
            updateMagneticUiState();
            updateMagneticCompass();
            Toast.makeText(this, useTrueNorth ? "Usando norte verdadero cuando haya ubicación." : "Usando norte magnético.", Toast.LENGTH_SHORT).show();
        });
        magneticActions.addView(northRef, weightParams());
        magneticCompassCard.addView(magneticActions);
        orientationMagneticPanel.addView(magneticCompassCard);

        LinearLayout magneticInfoCard = futuristicInnerPanel();
        TextView sensorInfoTitle = tv("Estado del sensor", 18, true);
        sensorInfoTitle.setPadding(0, 0, 0, dp(6));
        magneticInfoCard.addView(sensorInfoTitle);
        magneticSensorInfo = small("Comprobando magnetómetro…");
        magneticSensorInfo.setLineSpacing(0, 1.16f);
        magneticInfoCard.addView(magneticSensorInfo);
        liveMagStatus = magneticSensorInfo;
        orientationMagneticPanel.addView(magneticInfoCard);
        box.addView(orientationMagneticPanel);

        orientationAbPanel = toolColumn();
        LinearLayout abStatusPanel = futuristicInnerPanel();
        LinearLayout abStatusRow = new LinearLayout(this);
        abStatusRow.setOrientation(LinearLayout.HORIZONTAL);
        orientationGpsMetric = metricText("GPS", "DETENIDO", Color.rgb(104, 225, 163));
        orientationSignalMetric = metricText("PRECISIÓN", "—", borderColor);
        orientationPrecisionMetric = metricText("OBJETIVO", "PUNTO B", Color.rgb(255, 165, 74));
        abStatusRow.addView(orientationGpsMetric, weightParams());
        abStatusRow.addView(orientationSignalMetric, weightParams());
        abStatusRow.addView(orientationPrecisionMetric, weightParams());
        abStatusPanel.addView(abStatusRow);
        orientationAbPanel.addView(abStatusPanel);

        LinearLayout abCompassCard = futuristicInnerPanel();
        abCompassCard.setGravity(Gravity.CENTER_HORIZONTAL);
        abCompassDial = new CompassView(this);
        abCompassDial.setSpanishWestLabel(true);
        abCompassDial.setUnavailableText("");
        abCompassDial.setDisplayStyle(CompassView.STYLE_ORIENTATION_HUD);
        abCompassDial.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(400)));
        abCompassCard.addView(abCompassDial);

        abHeadingValue = tv("", 1, false);
        abHeadingValue.setVisibility(View.GONE);
        abCompassCard.addView(abHeadingValue, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        abHeadingLabel = smallCenter("Inicia el GPS y selecciona el punto A y B para ver la orientación.");
        abHeadingLabel.setPadding(dp(12), dp(8), dp(12), dp(6));
        abCompassCard.addView(abHeadingLabel);
        orientationAbPanel.addView(abCompassCard);

        LinearLayout abSummary = futuristicInnerPanel();
        LinearLayout abSummaryRow = new LinearLayout(this);
        abSummaryRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout distCard = orientationInfoCard("Distancia restante", "—");
        abDistanceValue = (TextView) distCard.getChildAt(1);
        LinearLayout azCard = orientationInfoCard("Azimut A → B", "—");
        abAzimuthValue = (TextView) azCard.getChildAt(1);
        abSummaryRow.addView(distCard, weightParams());
        abSummaryRow.addView(azCard, weightParams());
        abSummary.addView(abSummaryRow);
        orientationAbPanel.addView(abSummary);

        LinearLayout pointsRow = new LinearLayout(this);
        pointsRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout pointACard = futuristicInnerPanel();
        TextView pointATitle = tv("Punto A", 18, true);
        pointATitle.setPadding(0, 0, 0, dp(6));
        pointACard.addView(pointATitle);
        orientationPointAInfo = small("Pendiente\nAún no registrado");
        orientationPointAInfo.setLineSpacing(0, 1.16f);
        pointACard.addView(orientationPointAInfo);
        pointsRow.addView(pointACard, weightParams());

        LinearLayout pointBCard = futuristicInnerPanel();
        TextView pointBTitle = tv("Punto B", 18, true);
        pointBTitle.setPadding(0, 0, 0, dp(6));
        pointBCard.addView(pointBTitle);
        orientationPointBInfo = small("Pendiente\nAún no registrado");
        orientationPointBInfo.setLineSpacing(0, 1.16f);
        pointBCard.addView(orientationPointBInfo);
        pointsRow.addView(pointBCard, weightParams());
        orientationAbPanel.addView(pointsRow);

        LinearLayout buttonGrid = futuristicInnerPanel();
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        Button savePointA = btn("Guardar punto A");
        savePointA.setOnClickListener(v -> captureOrientationPointA());
        row1.addView(savePointA, weightParams());
        Button registerPointB = secondaryButton("Registrar punto B");
        registerPointB.setOnClickListener(v -> calculateOrientationPointB());
        row1.addView(registerPointB, weightParams());
        buttonGrid.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button calculate = secondaryButton("Calcular A → B");
        calculate.setOnClickListener(v -> {
            if (orientationPointA != null && orientationPointB != null) calculateOrientationFromAtoB();
            else calculateOrientationPointB();
        });
        row2.addView(calculate, weightParams());
        viewOrientationMapButton = secondaryButton("Ver línea A–B en el mapa");
        viewOrientationMapButton.setEnabled(false);
        viewOrientationMapButton.setAlpha(0.45f);
        viewOrientationMapButton.setOnClickListener(v -> openOrientationInMap());
        row2.addView(viewOrientationMapButton, weightParams());
        buttonGrid.addView(row2);
        orientationAbPanel.addView(buttonGrid);

        LinearLayout guide = futuristicInnerPanel();
        TextView guideTitle = tv("Orientación A–B", 18, true);
        guideTitle.setTextColor(themeMode == THEME_LIGHT ? darken(borderColor, 0.80f) : Color.rgb(84, 150, 255));
        guide.addView(guideTitle);
        LinearLayout steps = new LinearLayout(this);
        steps.setOrientation(LinearLayout.HORIZONTAL);
        steps.addView(stepTile("1", "Guardar A", "⌖"), weightParams());
        steps.addView(stepTile("2", "Caminar en\nlínea recta", "→"), weightParams());
        steps.addView(stepTile("3", "Registrar B", "●"), weightParams());
        guide.addView(steps);
        twoPointStatus = resultBox("Guarda el punto A, camina en línea recta y registra el punto B para completar la orientación.");
        guide.addView(twoPointStatus);
        gpsCompassStatus = twoPointStatus;
        orientationAbPanel.addView(guide);
        box.addView(orientationAbPanel);

        applyOrientationModeToViews();
        refreshOrientationPointCards();
        refreshOrientationCompassSummary();
        updateMagneticUiState();
        return box;
    }

    private Button orientationTabButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(15);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(dp(8), dp(12), dp(8), dp(12));
        button.setHeight(dp(54));
        button.setTextColor(withAlpha(textColor, 200));
        button.setBackground(new GradientDrawable());
        return button;
    }

    private void styleOrientationTab(Button button, boolean active) {
        if (button == null) return;
        GradientDrawable bg;
        if (active) {
            bg = new GradientDrawable(
                    GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{borderColor, darken(borderColor, 0.74f)});
            bg.setStroke(dp(1), withAlpha(Color.WHITE, 55));
            button.setTextColor(Color.WHITE);
        } else {
            bg = new GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    themeMode == THEME_LIGHT
                            ? new int[]{Color.rgb(248, 250, 255), Color.rgb(238, 244, 255)}
                            : new int[]{Color.rgb(10, 30, 49), Color.rgb(6, 23, 38)});
            bg.setStroke(dp(1), withAlpha(borderColor, 120));
            button.setTextColor(withAlpha(textColor, 205));
        }
        bg.setCornerRadius(dp(14));
        button.setBackground(bg);
    }

    private LinearLayout orientationInfoCard(String title, String value) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(10), dp(12), dp(10));
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.WHITE, Color.rgb(246, 249, 255)}
                        : new int[]{Color.rgb(9, 29, 47), Color.rgb(5, 22, 38)});
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), withAlpha(borderColor, 140));
        card.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), dp(6), dp(4));
        card.setLayoutParams(lp);

        TextView t = small(title);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(subTextColor);
        card.addView(t);

        TextView v = tv(value, 18, true);
        v.setPadding(0, dp(4), 0, 0);
        card.addView(v);
        return card;
    }

    private void updateMagneticUiState() {
        boolean magneticAvailable = magneticSensor != null && accelerometerSensor != null;
        if (magneticSensorMetric != null) {
            magneticSensorMetric.setText(magneticAvailable ? "SENSOR\nACTIVO" : "SENSOR\nNO DISP.");
            magneticSensorMetric.setTextColor(magneticAvailable ? Color.rgb(167, 232, 127) : Color.rgb(255, 140, 66));
        }
        String quality = magneticAccuracyLabel(magneticAccuracy).toUpperCase(Locale.US);
        if (magneticPrecisionMetric != null) {
            magneticPrecisionMetric.setText("PRECISIÓN\n" + quality);
        }
        String calibration = magneticAccuracy == SensorManager.SENSOR_STATUS_UNRELIABLE ? "REVISAR" : (useTrueNorth ? "N. VERD." : "OK");
        if (magneticCalibrationMetric != null) {
            magneticCalibrationMetric.setText("CALIBRACIÓN\n" + calibration);
        }
        if (magneticHeadingValue != null) {
            if (!magneticAvailable || Double.isNaN(smoothedMagneticAzimuth)) magneticHeadingValue.setText("—");
            else magneticHeadingValue.setText(orientationHeading(smoothedMagneticAzimuth));
        }
        if (magneticHeadingLabel != null) {
            magneticHeadingLabel.setText(useTrueNorth ? "Rumbo actual · norte verdadero" : "Rumbo actual · norte magnético");
        }
        if (magneticHintText != null) {
            magneticHintText.setText(magneticAccuracy == SensorManager.SENSOR_STATUS_UNRELIABLE
                    ? "Mueve el teléfono en forma de 8 para mejorar la precisión."
                    : "Mantén el teléfono horizontal y lejos de objetos metálicos." );
        }
        if (magneticSensorInfo != null) {
            magneticSensorInfo.setText(magneticAvailable
                    ? (magneticSensor.getName() + "\nLa lectura puede verse afectada por objetos metálicos cercanos.")
                    : "Este celular no tiene magnetómetro. Usa la pestaña Orientación A–B para trabajar con GPS.");
        }
    }

    private void refreshOrientationCompassSummary() {
        boolean hasAB = orientationPointA != null && orientationPointB != null;
        if (abHeadingValue != null) {
            if (hasAB) {
                abHeadingValue.setText(orientationHeading(bearingBetween(orientationPointA, orientationPointB)));
            } else if (gpsDetectedBearing != null) {
                abHeadingValue.setText(orientationHeading(gpsDetectedBearing));
            } else {
                abHeadingValue.setText("—");
            }
        }
        if (abHeadingLabel != null) {
            if (hasAB) abHeadingLabel.setText("Dirección al objetivo");
            else if (gpsCompassRunning) abHeadingLabel.setText("Dirección por movimiento GPS");
            else abHeadingLabel.setText("Inicia el GPS y selecciona el punto A y B para ver la orientación.");
        }
        if (abDistanceValue != null) {
            abDistanceValue.setText(hasAB ? String.format(Locale.US, "%.1f m", orientationPointA.distanceTo(orientationPointB)) : "—");
        }
        if (abAzimuthValue != null) {
            abAzimuthValue.setText(hasAB ? formatDms(bearingBetween(orientationPointA, orientationPointB)) : "—");
        }
        if (orientationPrecisionMetric != null) {
            orientationPrecisionMetric.setText(hasAB ? "OBJETIVO\nPUNTO B" : "OBJETIVO\nPENDIENTE");
        }
    }

    private void refreshOrientationPointCards() {
        if (orientationPointAInfo != null) {
            if (orientationPointA == null) {
                orientationPointAInfo.setText("Pendiente\nAún no registrado");
            } else {
                orientationPointAInfo.setText(String.format(Locale.US,
                        "Guardado\n%.6f, %.6f\nPrecisión ±%.1f m",
                        orientationPointA.getLatitude(), orientationPointA.getLongitude(), orientationPointA.getAccuracy()));
            }
        }
        if (orientationPointBInfo != null) {
            if (orientationPointB == null) {
                orientationPointBInfo.setText("Pendiente\nAún no registrado");
            } else {
                orientationPointBInfo.setText(String.format(Locale.US,
                        "Guardado\n%.6f, %.6f\nPrecisión ±%.1f m",
                        orientationPointB.getLatitude(), orientationPointB.getLongitude(), orientationPointB.getAccuracy()));
            }
        }
        if (viewOrientationMapButton != null) {
            boolean enabled = orientationPointA != null && orientationPointB != null;
            viewOrientationMapButton.setEnabled(enabled);
            viewOrientationMapButton.setAlpha(enabled ? 1f : 0.45f);
        }
        refreshOrientationCompassSummary();
    }

    private String orientationHeading(double azimuth) {
        int rounded = (int) Math.round(normalizeBearing(azimuth));
        if (rounded == 360) rounded = 0;
        return rounded + "° " + orientationOctant(rounded);
    }

    private String orientationOctant(double azimuth) {
        double a = normalizeBearing(azimuth);
        String[] dirs = {"N", "NE", "E", "SE", "S", "SO", "O", "NO"};
        int index = (int) Math.round(a / 45.0) % 8;
        return dirs[index];
    }

    private void showOrientationModeDialog() {
        final String[] names = {"Automática", "Magnética", "GPS / movimiento"};
        final String[] desc = {
                "Usa magnética si hay sensor; si no, usa GPS.",
                "Funciona sin GPS, solo si el celular tiene magnetómetro.",
                "Para celulares sin magnetómetro. Pide ubicación y debes caminar recto."
        };
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == THEME_LIGHT ? Color.WHITE : Color.rgb(12, 25, 39));
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), borderColor);
        panel.setBackground(bg);

        TextView title = tv("Elegir brújula", 21, true);
        title.setPadding(dp(4), 0, dp(4), dp(8));
        panel.addView(title);

        CheckBox trueNorth = new CheckBox(this);
        trueNorth.setText("Corregir a norte verdadero cuando haya ubicación");
        trueNorth.setTextColor(textColor);
        trueNorth.setChecked(useTrueNorth);
        trueNorth.setPadding(dp(4), dp(2), dp(4), dp(8));
        trueNorth.setOnCheckedChangeListener((button, checked) -> {
            useTrueNorth = checked;
            savePrefs();
            smoothedMagneticAzimuth = Double.NaN;
            updateMagneticCompass();
        });
        panel.addView(trueNorth);

        TextView sensorState = small(magneticSensor == null
                ? "Este equipo no tiene magnetómetro: usa GPS / movimiento o A–B."
                : "Magnetómetro detectado: " + magneticSensor.getName());
        sensorState.setPadding(dp(4), 0, dp(4), dp(8));
        panel.addView(sensorState);

        final AlertDialog[] dialogRef = new AlertDialog[1];
        for (int i = 0; i < names.length; i++) {
            final int mode = i;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(10), dp(10), dp(10), dp(10));
            GradientDrawable rowBg = new GradientDrawable();
            rowBg.setColor(themeMode == THEME_LIGHT ? Color.rgb(248, 250, 255) : Color.rgb(15, 26, 40));
            rowBg.setCornerRadius(dp(12));
            rowBg.setStroke(dp(1), orientationCompassMode == mode ? borderColor : inputStrokeColor);
            row.setBackground(rowBg);
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.setMargins(0, dp(5), 0, dp(5));
            row.setLayoutParams(rlp);

            TextView check = tv(orientationCompassMode == mode ? "✓" : "○", 22, true);
            check.setTextColor(orientationCompassMode == mode ? borderColor : subTextColor);
            check.setGravity(Gravity.CENTER);
            row.addView(check, new LinearLayout.LayoutParams(dp(44), dp(48)));

            LinearLayout texts = new LinearLayout(this);
            texts.setOrientation(LinearLayout.VERTICAL);
            TextView n = tv(names[i], 16, true);
            texts.addView(n);
            TextView d = tv(desc[i], 12, false);
            d.setTextColor(subTextColor);
            texts.addView(d);
            row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.setOnClickListener(v -> {
                if (mode == 1 && (magneticSensor == null || accelerometerSensor == null)) {
                    showError("Este celular no tiene magnetómetro. Usa Orientación A–B.");
                    orientationCompassMode = 2;
                } else {
                    orientationCompassMode = mode;
                }
                savePrefs();
                applyOrientationModeToViews();
                if (dialogRef[0] != null) dialogRef[0].dismiss();
            });
            panel.addView(row);
        }
        Button close = btn("Cerrar");
        close.setOnClickListener(v -> { if (dialogRef[0] != null) dialogRef[0].dismiss(); });
        panel.addView(close);
        AlertDialog dialog = new AlertDialog.Builder(this).setView(panel).create();
        dialogRef[0] = dialog;
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        });
        dialog.show();
    }

    private void applyOrientationModeToViews() {
        boolean magneticAvailable = magneticSensor != null && accelerometerSensor != null;
        int effective = orientationCompassMode;
        if (!magneticAvailable && effective == 1) effective = 2;
        if (effective == 0) effective = magneticAvailable ? 1 : 2;

        if (orientationMagneticTab != null) {
            orientationMagneticTab.setEnabled(magneticAvailable);
            orientationMagneticTab.setAlpha(magneticAvailable ? 1f : 0.48f);
        }
        styleOrientationTab(orientationMagneticTab, magneticAvailable && effective == 1);
        styleOrientationTab(orientationAbTab, effective == 2);
        if (orientationMagneticPanel != null) orientationMagneticPanel.setVisibility(magneticAvailable && effective == 1 ? View.VISIBLE : View.GONE);
        if (orientationAbPanel != null) orientationAbPanel.setVisibility(effective == 2 ? View.VISIBLE : View.GONE);

        if (magneticCompassDial != null) {
            magneticCompassDial.setUnavailableText("");
        }
        if (abCompassDial != null) {
            abCompassDial.setUnavailableText("");
        }

        if (effective == 1 && magneticAvailable) {
            liveMagCompassView = magneticCompassDial;
            gpsCompassView = null;
            selectedOrientationCompassView = magneticCompassDial;
            if (magneticCompassDial != null) {
                magneticCompassDial.setDisplayStyle(CompassView.STYLE_ORIENTATION_HUD);
                magneticCompassDial.setSpanishWestLabel(true);
                magneticCompassDial.setDirectionAvailable(!Double.isNaN(smoothedMagneticAzimuth));
                if (!Double.isNaN(smoothedMagneticAzimuth)) magneticCompassDial.setAzimuth(smoothedMagneticAzimuth);
            }
            registerMagneticCompass();
            updateMagneticUiState();
        } else {
            unregisterMagneticCompass();
            liveMagCompassView = null;
            gpsCompassView = abCompassDial;
            selectedOrientationCompassView = abCompassDial;
            if (abCompassDial != null) {
                abCompassDial.setDisplayStyle(CompassView.STYLE_ORIENTATION_HUD);
                abCompassDial.setSpanishWestLabel(true);
                boolean hasAB = orientationPointA != null && orientationPointB != null;
                if (hasAB) {
                    abCompassDial.setDirectionAvailable(true);
                    abCompassDial.setAzimuth(bearingBetween(orientationPointA, orientationPointB));
                } else if (gpsDetectedBearing != null) {
                    abCompassDial.setDirectionAvailable(true);
                    abCompassDial.setAzimuth(gpsDetectedBearing);
                } else {
                    abCompassDial.setDirectionAvailable(false);
                }
            }
            refreshOrientationPointCards();
            updateMagneticUiState();
        }
        refreshOrientationCompassSummary();
    }

    private void registerMagneticCompass() {
        if (sensorManager == null || accelerometerSensor == null || magneticSensor == null) {
            if (liveMagStatus != null) liveMagStatus.setText("No disponible: este celular no tiene magnetómetro. Usa GPS o A–B.");
            return;
        }
        sensorManager.unregisterListener(magneticCompassListener);
        sensorManager.registerListener(magneticCompassListener, accelerometerSensor, SensorManager.SENSOR_DELAY_GAME);
        sensorManager.registerListener(magneticCompassListener, magneticSensor, SensorManager.SENSOR_DELAY_GAME);
        updateLastKnownLocationForDeclination();
        if (liveMagStatus != null) liveMagStatus.setText("Leyendo sensor magnético… Mantén el celular horizontal.");
        updateMagneticUiState();
    }

    private void unregisterMagneticCompass() {
        if (sensorManager != null) sensorManager.unregisterListener(magneticCompassListener);
    }

    private void lowPassSensor(float[] input, float[] output, boolean initialized) {
        if (!initialized) {
            System.arraycopy(input, 0, output, 0, Math.min(3, input.length));
            return;
        }
        final float alpha = 0.18f;
        for (int i = 0; i < 3; i++) output[i] += alpha * (input[i] - output[i]);
    }

    private void updateLastKnownLocationForDeclination() {
        if (locationManager == null || !hasLocationPermission()) return;
        try {
            Location gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location net = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            Location best = gps;
            if (best == null || (net != null && net.getTime() > best.getTime())) best = net;
            if (best != null && (lastGpsLocation == null || best.getTime() > lastGpsLocation.getTime())) lastGpsLocation = new Location(best);
        } catch (SecurityException ignored) {}
    }

    private void updateMagneticCompass() {
        if (!hasAccelValues || !hasMagneticValues || liveMagCompassView == null) return;
        float[] rotation = new float[9];
        float[] inclination = new float[9];
        if (!SensorManager.getRotationMatrix(rotation, inclination, accelValues, magneticValues)) return;

        float[] remapped = new float[9];
        int displayRotation = getWindowManager().getDefaultDisplay().getRotation();
        int axisX = SensorManager.AXIS_X;
        int axisY = SensorManager.AXIS_Y;
        if (displayRotation == Surface.ROTATION_90) {
            axisX = SensorManager.AXIS_Y;
            axisY = SensorManager.AXIS_MINUS_X;
        } else if (displayRotation == Surface.ROTATION_180) {
            axisX = SensorManager.AXIS_MINUS_X;
            axisY = SensorManager.AXIS_MINUS_Y;
        } else if (displayRotation == Surface.ROTATION_270) {
            axisX = SensorManager.AXIS_MINUS_Y;
            axisY = SensorManager.AXIS_X;
        }
        if (!SensorManager.remapCoordinateSystem(rotation, axisX, axisY, remapped)) return;

        float[] orientation = new float[3];
        SensorManager.getOrientation(remapped, orientation);
        double magneticAzimuth = normalizeBearing(Math.toDegrees(orientation[0]));
        double azimuth = magneticAzimuth;
        String reference = "magnético";
        if (useTrueNorth && lastGpsLocation != null) {
            float altitude = lastGpsLocation.hasAltitude() ? (float) lastGpsLocation.getAltitude() : 0f;
            GeomagneticField field = new GeomagneticField(
                    (float) lastGpsLocation.getLatitude(),
                    (float) lastGpsLocation.getLongitude(), altitude, System.currentTimeMillis());
            azimuth = normalizeBearing(magneticAzimuth + field.getDeclination());
            reference = "verdadero";
        }
        smoothedMagneticAzimuth = smoothBearing(smoothedMagneticAzimuth, azimuth, 0.20);
        liveMagCompassView.setDirectionAvailable(true);
        liveMagCompassView.setAzimuth(smoothedMagneticAzimuth);

        String quality = magneticAccuracyLabel(magneticAccuracy);
        if (liveMagStatus != null) {
            String calibration = magneticAccuracy == SensorManager.SENSOR_STATUS_UNRELIABLE
                    ? "\nCalibra en forma de 8 y aléjate de metal."
                    : "";
            liveMagStatus.setText("Norte " + reference + ": " + formatDms(smoothedMagneticAzimuth)
                    + " · calidad " + quality + calibration);
        }
    }

    private String magneticAccuracyLabel(int accuracy) {
        if (accuracy == SensorManager.SENSOR_STATUS_ACCURACY_HIGH) return "alta";
        if (accuracy == SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM) return "media";
        if (accuracy == SensorManager.SENSOR_STATUS_ACCURACY_LOW) return "baja";
        return "no confiable";
    }

    private double smoothBearing(double previous, double next, double alpha) {
        next = normalizeBearing(next);
        if (Double.isNaN(previous)) return next;
        double diff = ((next - previous + 540.0) % 360.0) - 180.0;
        return normalizeBearing(previous + alpha * diff);
    }

    private double normalizeBearing(double value) {
        value %= 360.0;
        if (value < 0) value += 360.0;
        return value;
    }

    private boolean hasLocationPermission() {
        if (Build.VERSION.SDK_INT < 23) return true;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestLocationPermission() {
        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
        }
    }

    private void startGpsCompass() {
        if (locationManager == null) {
            if (gpsCompassStatus != null) gpsCompassStatus.setText("Ubicación no disponible en este equipo.");
            return;
        }
        if (!hasLocationPermission()) {
            if (gpsCompassStatus != null) gpsCompassStatus.setText("Acepta el permiso de ubicación para usar GPS.");
            requestLocationPermission();
            return;
        }
        try {
            gpsCompassRunning = true;
            if (orientationGpsMetric != null) orientationGpsMetric.setText("GPS\nACTIVO");
            if (orientationSignalMetric != null) orientationSignalMetric.setText("PRECISIÓN\nBUSCANDO");
            lastGpsLocation = null;
            gpsStartLocation = null;
            gpsWalkDistanceMeters = 0.0;
            gpsDetectedBearing = null;
            smoothedGpsBearing = Double.NaN;
            lastGpsBearingAccuracy = Float.NaN;
            invalidGpsBearingUpdates = 0;
            orientationRecentLocations.clear();
            gpsStartMillis = System.currentTimeMillis();
            updateGpsProgressStatus();
            gpsUiHandler.removeCallbacksAndMessages(null);
            gpsUiHandler.postDelayed(new Runnable() {
                @Override public void run() {
                    if (!gpsCompassRunning) return;
                    updateGpsProgressStatus();
                    gpsUiHandler.postDelayed(this, 1000);
                }
            }, 1000);
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 800, 1.0f, gpsCompassListener);
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1200, 2.0f, gpsCompassListener);
            }
        } catch (SecurityException e) {
            if (gpsCompassStatus != null) gpsCompassStatus.setText("Permiso de ubicación requerido.");
        } catch (Exception e) {
            if (gpsCompassStatus != null) gpsCompassStatus.setText("No se pudo iniciar GPS. Activa ubicación.");
        }
    }

    private void stopGpsCompass() {
        if (locationManager != null) {
            try { locationManager.removeUpdates(gpsCompassListener); } catch (Exception ignored) {}
        }
        gpsCompassRunning = false;
        if (orientationGpsMetric != null) orientationGpsMetric.setText("GPS\nDETENIDO");
        if (orientationSignalMetric != null) orientationSignalMetric.setText("PRECISIÓN\n—");
        if (gpsCompassStatus != null) gpsCompassStatus.setText("GPS detenido. La orientación por movimiento no está disponible.");
        gpsDetectedBearing = null;
        smoothedGpsBearing = Double.NaN;
        invalidGpsBearingUpdates = 0;
        boolean hasAB = orientationPointA != null && orientationPointB != null;
        if (gpsCompassView != null && !hasAB) gpsCompassView.setDirectionAvailable(false);
        orientationAverageRunning = false;
        orientationAverageSamples.clear();
        gpsStartLocation = null;
        gpsWalkDistanceMeters = 0.0;
        gpsStartMillis = 0L;
        gpsUiHandler.removeCallbacksAndMessages(null);
        refreshOrientationCompassSummary();
    }

    private void updateGpsProgressStatus() {
        if (gpsCompassStatus == null) return;
        long secs = gpsStartMillis > 0 ? Math.max(0L, (System.currentTimeMillis() - gpsStartMillis) / 1000L) : 0L;
        String distText = String.format(Locale.US, "%.1f", gpsWalkDistanceMeters);
        String accuracyText = lastGpsLocation != null && lastGpsLocation.hasAccuracy()
                ? String.format(Locale.US, "±%.1f m", lastGpsLocation.getAccuracy()) : "sin precisión";
        if (orientationAverageRunning) {
            long remaining = Math.max(0L, (orientationAverageEndsAt - System.currentTimeMillis() + 999L) / 1000L);
            gpsCompassStatus.setText("Promediando punto " + (orientationAverageForA ? "A" : "B") + "… " + remaining + " s"
                    + "\nLecturas válidas: " + orientationAverageSamples.size() + " · precisión actual " + accuracyText);
        } else if (gpsDetectedBearing != null) {
            String bearingAcc = Float.isNaN(lastGpsBearingAccuracy) ? "" : String.format(Locale.US, " · rumbo ±%.0f°", lastGpsBearingAccuracy);
            gpsCompassStatus.setText("Dirección de movimiento: " + formatDms(gpsDetectedBearing)
                    + bearingAcc + "\nGPS " + accuracyText + " · recorrido " + distText + " m · " + secs + " s");
        } else if (gpsCompassRunning) {
            gpsCompassStatus.setText("GPS activo, pero sin rumbo confiable. Camina en línea recta a paso normal."
                    + "\nGPS " + accuracyText + " · recorrido " + distText + " m · " + secs + " s");
        }
    }

    private void updateGpsCompass(Location location) {
        if (location == null) return;
        if (orientationGpsMetric != null) orientationGpsMetric.setText("GPS\nACTIVO");
        if (orientationSignalMetric != null) orientationSignalMetric.setText("PRECISIÓN\n" + (location.hasAccuracy() ? String.format(Locale.US, "±%.1f m", location.getAccuracy()) : "—"));
        long age = Math.abs(System.currentTimeMillis() - location.getTime());
        if (age > 15000L) return;
        boolean hasAB = orientationPointA != null && orientationPointB != null;
        if (location.hasAccuracy() && location.getAccuracy() > 60f) {
            lastGpsLocation = new Location(location);
            invalidGpsBearingUpdates++;
            if (invalidGpsBearingUpdates >= 2) {
                gpsDetectedBearing = null;
                lastGpsBearingAccuracy = Float.NaN;
                if (gpsCompassView != null && !hasAB) gpsCompassView.setDirectionAvailable(false);
            }
            updateGpsProgressStatus();
            refreshOrientationCompassSummary();
            return;
        }

        if (orientationAverageRunning && (!location.hasAccuracy() || location.getAccuracy() <= 25f)) {
            orientationAverageSamples.add(new Location(location));
            if (orientationAverageSamples.size() > 80) orientationAverageSamples.remove(0);
        }
        orientationRecentLocations.add(new Location(location));
        while (orientationRecentLocations.size() > 30) orientationRecentLocations.remove(0);

        if (lastGpsLocation != null) {
            float step = lastGpsLocation.distanceTo(location);
            float noise = ((lastGpsLocation.hasAccuracy() ? lastGpsLocation.getAccuracy() : 8f)
                    + (location.hasAccuracy() ? location.getAccuracy() : 8f)) * 0.25f;
            if (step > Math.max(1.5f, noise) && step < 100f) gpsWalkDistanceMeters += step;
        }

        double bearing = Double.NaN;
        float bearingAccuracy = Float.NaN;
        boolean goodPosition = !location.hasAccuracy() || location.getAccuracy() <= 25f;
        if (goodPosition && location.hasBearing() && location.hasSpeed() && location.getSpeed() >= 1.0f) {
            bearing = location.getBearing();
            if (Build.VERSION.SDK_INT >= 26 && location.hasBearingAccuracy()) bearingAccuracy = location.getBearingAccuracyDegrees();
            if (!Float.isNaN(bearingAccuracy) && bearingAccuracy > 55f) bearing = Double.NaN;
        }
        if (Double.isNaN(bearing) && goodPosition) {
            Location baseline = findGpsBearingBaseline(location);
            if (baseline != null) bearing = bearingBetween(baseline, location);
        }

        if (!Double.isNaN(bearing)) {
            invalidGpsBearingUpdates = 0;
            smoothedGpsBearing = smoothBearing(smoothedGpsBearing, bearing, 0.28);
            gpsDetectedBearing = smoothedGpsBearing;
            lastGpsBearingAccuracy = bearingAccuracy;
            if (gpsCompassView != null && !hasAB) {
                gpsCompassView.setDirectionAvailable(true);
                gpsCompassView.setAzimuth(smoothedGpsBearing);
            }
        } else {
            invalidGpsBearingUpdates++;
            if ((!location.hasSpeed() || location.getSpeed() < 0.8f) || invalidGpsBearingUpdates >= 3) {
                gpsDetectedBearing = null;
                lastGpsBearingAccuracy = Float.NaN;
                if (gpsCompassView != null && !hasAB) gpsCompassView.setDirectionAvailable(false);
            }
        }
        lastGpsLocation = new Location(location);
        updateGpsProgressStatus();
        refreshOrientationCompassSummary();
    }

    private Location findGpsBearingBaseline(Location current) {
        for (Location candidate : orientationRecentLocations) {
            if (candidate == current) continue;
            if (candidate.hasAccuracy() && candidate.getAccuracy() > 25f) continue;
            float required = Math.max(8f,
                    ((candidate.hasAccuracy() ? candidate.getAccuracy() : 6f)
                            + (current.hasAccuracy() ? current.getAccuracy() : 6f)) * 1.2f);
            if (candidate.distanceTo(current) >= required) return candidate;
        }
        return null;
    }

    private void captureOrientationPointA() {
        startOrientationPointAverage(true);
    }

    private void calculateOrientationPointB() {
        if (orientationPointA == null) {
            if (twoPointStatus != null) twoPointStatus.setText("Primero registra el punto A.");
            return;
        }
        startOrientationPointAverage(false);
    }

    private void startOrientationPointAverage(boolean forPointA) {
        orientationCompassMode = 2;
        savePrefs();
        applyOrientationModeToViews();
        if (!gpsCompassRunning) startGpsCompass();
        if (!hasLocationPermission()) return;
        if (orientationAverageRunning) {
            if (twoPointStatus != null) twoPointStatus.setText("Ya se está promediando un punto. Espera a que termine.");
            return;
        }
        orientationAverageRunning = true;
        orientationAverageForA = forPointA;
        orientationAverageSamples.clear();
        orientationAverageEndsAt = System.currentTimeMillis() + 10000L;
        if (twoPointStatus != null) twoPointStatus.setText("Promediando punto " + (forPointA ? "A" : "B")
                + " durante 10 segundos. Mantén el teléfono quieto y con cielo despejado.");
        gpsUiHandler.post(new Runnable() {
            @Override public void run() {
                if (!orientationAverageRunning) return;
                updateGpsProgressStatus();
                if (System.currentTimeMillis() >= orientationAverageEndsAt) finishOrientationPointAverage();
                else gpsUiHandler.postDelayed(this, 500L);
            }
        });
    }

    private void finishOrientationPointAverage() {
        orientationAverageRunning = false;
        Location averaged = averageLocations(orientationAverageSamples);
        orientationAverageSamples.clear();
        if (averaged == null) {
            if (twoPointStatus != null) twoPointStatus.setText("No hubo suficientes lecturas GPS válidas. Ve a un lugar despejado e inténtalo otra vez.");
            refreshOrientationPointCards();
            return;
        }
        if (orientationAverageForA) {
            orientationPointA = averaged;
            orientationPointB = null;
            if (viewOrientationMapButton != null) {
                viewOrientationMapButton.setEnabled(false);
                viewOrientationMapButton.setAlpha(0.45f);
            }
            float recommended = recommendedOrientationDistance(orientationPointA.getAccuracy(), orientationPointA.getAccuracy());
            if (twoPointStatus != null) twoPointStatus.setText(String.format(Locale.US,
                    "Punto A registrado: %.7f, %.7f\nPrecisión declarada: ±%.1f m. Camina en línea recta; distancia orientativa mínima: %.0f m.",
                    orientationPointA.getLatitude(), orientationPointA.getLongitude(), orientationPointA.getAccuracy(), recommended));
        } else {
            orientationPointB = averaged;
            calculateOrientationFromAtoB();
        }
    }

    private Location averageLocations(List<Location> samples) {
        if (samples == null || samples.size() < 3) return null;
        double sumW = 0.0, lat = 0.0, lon = 0.0, altitude = 0.0;
        int altitudeCount = 0;
        float accuracySum = 0f;
        for (Location l : samples) {
            float acc = l.hasAccuracy() ? Math.max(3f, l.getAccuracy()) : 12f;
            double w = 1.0 / (acc * acc);
            sumW += w;
            lat += l.getLatitude() * w;
            lon += l.getLongitude() * w;
            accuracySum += acc;
            if (l.hasAltitude()) { altitude += l.getAltitude(); altitudeCount++; }
        }
        if (sumW <= 0) return null;
        Location result = new Location(LocationManager.GPS_PROVIDER);
        result.setLatitude(lat / sumW);
        result.setLongitude(lon / sumW);
        if (altitudeCount > 0) result.setAltitude(altitude / altitudeCount);
        result.setAccuracy(accuracySum / samples.size());
        result.setTime(System.currentTimeMillis());
        return result;
    }

    private void calculateOrientationFromAtoB() {
        if (orientationPointA == null || orientationPointB == null) return;
        float distance = orientationPointA.distanceTo(orientationPointB);
        double bearing = bearingBetween(orientationPointA, orientationPointB);
        double combined = Math.hypot(orientationPointA.getAccuracy(), orientationPointB.getAccuracy());
        double uncertainty = Math.toDegrees(Math.atan2(combined, Math.max(0.1, distance)));
        float recommended = recommendedOrientationDistance(orientationPointA.getAccuracy(), orientationPointB.getAccuracy());
        if (abCompassDial != null) {
            abCompassDial.setDirectionAvailable(true);
            abCompassDial.setAzimuth(bearing);
        }
        gpsDetectedBearing = bearing;
        String quality = uncertainty <= 5.0 ? "buena" : uncertainty <= 10.0 ? "media" : "baja";
        String advice = distance < recommended
                ? String.format(Locale.US, "\nContinúa hasta aproximadamente %.0f m para reducir el error angular.", recommended)
                : "\nSeparación suficiente para orientación aproximada de campo.";
        if (twoPointStatus != null) {
            twoPointStatus.setText("Azimut A → B: " + formatDms(bearing)
                    + "\nRumbo: " + rumbo(bearing)
                    + String.format(Locale.US, "\nDistancia: %.2f m · incertidumbre estimada ±%.1f° · calidad %s", distance, uncertainty, quality)
                    + advice);
        }
        if (viewOrientationMapButton != null) {
            viewOrientationMapButton.setEnabled(true);
            viewOrientationMapButton.setAlpha(1f);
        }
        refreshOrientationPointCards();
    }

    private float recommendedOrientationDistance(float accuracyA, float accuracyB) {
        double combined = Math.hypot(Math.max(3f, accuracyA), Math.max(3f, accuracyB));
        return (float) Math.max(30.0, Math.min(250.0, combined / Math.tan(Math.toRadians(5.0))));
    }

    private void openOrientationInMap() {
        if (orientationPointA == null || orientationPointB == null) {
            Toast.makeText(this, "Primero registra A y B.", Toast.LENGTH_SHORT).show();
            return;
        }
        android.content.Intent intent = new android.content.Intent(this, MapActivity.class);
        intent.putExtra("ab_a_lat", orientationPointA.getLatitude());
        intent.putExtra("ab_a_lon", orientationPointA.getLongitude());
        intent.putExtra("ab_a_acc", orientationPointA.getAccuracy());
        intent.putExtra("ab_b_lat", orientationPointB.getLatitude());
        intent.putExtra("ab_b_lon", orientationPointB.getLongitude());
        intent.putExtra("ab_b_acc", orientationPointB.getAccuracy());
        intent.putExtra("ab_bearing", bearingBetween(orientationPointA, orientationPointB));
        intent.putExtra("ab_distance", orientationPointA.distanceTo(orientationPointB));
        startActivity(intent);
    }

    private double bearingBetween(Location from, Location to) {
        double lat1 = Math.toRadians(from.getLatitude());
        double lat2 = Math.toRadians(to.getLatitude());
        double dLon = Math.toRadians(to.getLongitude() - from.getLongitude());
        double y = Math.sin(dLon) * Math.cos(lat2);
        double x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
        return normalizeBearing(Math.toDegrees(Math.atan2(y, x)));
    }

    private View azimuthBlock() {
        LinearLayout box = toolColumn();

        LinearLayout modePanel = futuristicInnerPanel();
        modePanel.setPadding(dp(6), dp(6), dp(6), dp(6));
        LinearLayout modes = new LinearLayout(this);
        modes.setOrientation(LinearLayout.HORIZONTAL);
        modeAzBtn = smallModeBtn("Azimut", 0);
        modeRumboBtn = smallModeBtn("Rumbo", 1);
        modeContraAzBtn = smallModeBtn("Contraaz.", 2);
        modeContraRumboBtn = smallModeBtn("Contrarr.", 3);
        modes.addView(modeAzBtn, weightParams());
        modes.addView(modeRumboBtn, weightParams());
        modes.addView(modeContraAzBtn, weightParams());
        modes.addView(modeContraRumboBtn, weightParams());
        modePanel.addView(modes);
        box.addView(modePanel);

        LinearLayout entry = futuristicInnerPanel();
        entry.setPadding(dp(14), dp(14), dp(14), dp(14));
        TextView entryTitle = tv("Dato de entrada", 18, true);
        entryTitle.setTextColor(borderColor);
        entry.addView(entryTitle);

        azInput = edit("");
        azInput.setTextSize(22);
        azInput.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        azInput.setMinHeight(dp(60));
        azInput.setPadding(dp(16), dp(10), dp(16), dp(10));
        trackAngleEdit(azInput);
        entry.addView(azInput);
        entry.addView(angleShortcutBar());

        Button calc = btn("◉  CALCULAR");
        calc.setTextSize(18);
        calc.setOnClickListener(v -> calculateAzimuth());
        LinearLayout.LayoutParams calcLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        calcLp.setMargins(0, dp(6), 0, 0);
        entry.addView(calc, calcLp);
        box.addView(entry);
        setAzInputMode(0);

        box.addView(azimuthResultPanel());
        return box;
    }

    private Button smallModeBtn(String text, int mode) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(15);
        b.setTextColor(textColor);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(6), dp(10), dp(6), dp(10));
        b.setHeight(dp(50));
        b.setOnClickListener(v -> setAzInputMode(mode));
        return b;
    }

    private void setAzInputMode(int mode) {
        azInputMode = mode;
        if (azModeHint != null) {
            String[] names = {"Azimut", "Rumbo", "Contraazimut", "Contrarrumbo"};
            azModeHint.setText("Formato activo: " + names[mode]);
        }
        if (azInput != null) {
            azInput.setHint("");
        }
        styleModeButton(modeAzBtn, mode == 0);
        styleModeButton(modeRumboBtn, mode == 1);
        styleModeButton(modeContraAzBtn, mode == 2);
        styleModeButton(modeContraRumboBtn, mode == 3);
    }

    private void styleModeButton(Button b, boolean active) {
        if (b == null) return;
        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                active
                        ? new int[]{borderColor, darken(borderColor, 0.78f)}
                        : (themeMode == THEME_LIGHT
                            ? new int[]{Color.rgb(248, 251, 255), Color.rgb(240, 246, 255)}
                            : new int[]{Color.rgb(10, 27, 43), Color.rgb(7, 21, 35)}));
        gd.setCornerRadius(dp(16));
        gd.setStroke(dp(active ? 2 : 1), active ? withAlpha(Color.WHITE, 85) : withAlpha(borderColor, 105));
        b.setBackground(gd);
        b.setTextColor(active ? Color.WHITE : textColor);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) b.setElevation(active ? dp(2) : 0f);
    }

    private View azimuthResultPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout.LayoutParams panelLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        panelLp.setMargins(0, dp(8), 0, dp(4));
        panel.setLayoutParams(panelLp);
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.rgb(249, 251, 255), Color.rgb(240, 246, 255)}
                        : new int[]{Color.rgb(5, 18, 31), Color.rgb(3, 12, 24)});
        bg.setStroke(dp(1), withAlpha(borderColor, 145));
        bg.setCornerRadius(dp(18));
        panel.setBackground(bg);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = tv("Resultados", 18, true);
        title.setTextColor(borderColor);
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        azQuadrantChip = miniChip("Cuadrante: —", borderColor);
        head.addView(azQuadrantChip);
        panel.addView(head);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(compassItem("Azimut", 0), weightParams());
        row1.addView(compassItem("Rumbo", 1), weightParams());
        panel.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(compassItem("Contraazimut", 2), weightParams());
        row2.addView(compassItem("Contrarrumbo", 3), weightParams());
        panel.addView(row2);

        azDecimalLabel = compactInfoText("Formato decimal\n—");
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        infoLp.setMargins(dp(2), dp(4), dp(2), 0);
        azDecimalLabel.setLayoutParams(infoLp);
        panel.addView(azDecimalLabel);
        return panel;
    }

    private TextView miniChip(String text, int color) {
        TextView v = tv(text, 12, true);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(12), dp(6), dp(12), dp(6));
        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.rgb(240, 247, 255), Color.rgb(232, 242, 255)}
                        : new int[]{Color.rgb(8, 28, 48), Color.rgb(6, 20, 37)});
        gd.setStroke(dp(1), withAlpha(color, 200));
        gd.setCornerRadius(dp(18));
        v.setBackground(gd);
        v.setTextColor(themeMode == THEME_LIGHT ? darken(color, 0.78f) : Color.rgb(106, 176, 255));
        return v;
    }

    private TextView bigDirectionText(String text) {
        TextView v = compassResultChip("", "");
        v.setText(text);
        v.setTextSize(22);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(6), dp(12), dp(6), dp(12));
        return v;
    }

    private TextView compactInfoText(String text) {
        TextView v = compassResultChip("", "");
        v.setText(text);
        v.setTextSize(12);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(6), dp(8), dp(6), dp(8));
        return v;
    }

    private View quadrantReferencePanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(2), dp(6), dp(2), 0);
        panel.addView(small("Referencia rápida de cuadrantes"));

        LinearLayout r1 = new LinearLayout(this);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        r1.addView(quadrantCard("NE", "0° a 90°", "Rumbo: N θ E", Color.rgb(0, 184, 148)), weightParams());
        r1.addView(quadrantCard("SE", "90° a 180°", "Rumbo: S θ E", Color.rgb(0, 188, 212)), weightParams());
        panel.addView(r1);

        LinearLayout r2 = new LinearLayout(this);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        r2.addView(quadrantCard("SW", "180° a 270°", "Rumbo: S θ W", Color.rgb(255, 171, 0)), weightParams());
        r2.addView(quadrantCard("NW", "270° a 360°", "Rumbo: N θ W", Color.rgb(142, 68, 173)), weightParams());
        panel.addView(r2);
        return panel;
    }

    private View quadrantCard(String quadrant, String range, String formula, int color) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(8), dp(8), dp(8), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == THEME_LIGHT ? Color.WHITE : Color.rgb(14, 26, 39));
        bg.setStroke(dp(1), color);
        bg.setCornerRadius(dp(12));
        card.setBackground(bg);
        TextView title = tv(quadrant + "  " + range, 13, true);
        title.setTextColor(color);
        TextView body = tv(formula, 12, false);
        body.setGravity(Gravity.CENTER);
        card.addView(title);
        card.addView(body);
        return card;
    }

    private View compassItem(String title, int type) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(8), dp(8), dp(8), dp(8));

        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.rgb(252, 253, 255), Color.rgb(241, 247, 255)}
                        : new int[]{Color.rgb(4, 16, 30), Color.rgb(3, 12, 24)});
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), withAlpha(borderColor, 145));
        wrap.setBackground(bg);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView headTitle = tv(title.toUpperCase(Locale.US), title.length() > 10 ? 10 : 12, true);
        headTitle.setTextColor(borderColor);
        headTitle.setSingleLine(true);
        headTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
        headTitle.setMaxLines(1);
        head.addView(headTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        head.addView(smallCornerIndicator("—"));
        wrap.addView(head);

        CompassView cv = new CompassView(this);
        cv.setLightDial(false);
        cv.setDisplayStyle(CompassView.STYLE_AZIMUTH_PANEL);
        cv.setSpanishWestLabel(false);
        cv.setAzimuthPanelMode((type == 1 || type == 3) ? CompassView.PANEL_RUMBO : CompassView.PANEL_AZIMUTH);
        cv.setDirectionAvailable(false);
        LinearLayout.LayoutParams dialLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(214));
        dialLp.setMargins(0, dp(6), 0, dp(4));
        cv.setLayoutParams(dialLp);
        if (type == 0) compassAzView = cv;
        else if (type == 1) compassRumboView = cv;
        else if (type == 2) compassContraAzView = cv;
        else compassContraRumboView = cv;
        wrap.addView(cv);

        TextView t = compassValueChip("—");
        if (type == 0) compassAzLabel = t;
        else if (type == 1) compassRumboLabel = t;
        else if (type == 2) compassContraAzLabel = t;
        else compassContraRumboLabel = t;
        wrap.addView(t);
        return wrap;
    }

    private TextView smallCornerIndicator(String text) {
        TextView v = tv(text, 12, true);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(8), dp(3), dp(8), dp(3));
        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.rgb(240, 247, 255), Color.rgb(232, 242, 255)}
                        : new int[]{Color.rgb(8, 23, 39), Color.rgb(5, 18, 32)});
        gd.setCornerRadius(dp(12));
        gd.setStroke(dp(1), withAlpha(borderColor, 110));
        v.setBackground(gd);
        v.setTextColor(subTextColor);
        return v;
    }

    private TextView compassValueChip(String value) {
        TextView v = tv(value, 16, true);
        v.setGravity(Gravity.CENTER);
        v.setLineSpacing(0, 1.06f);
        v.setPadding(dp(8), dp(9), dp(8), dp(10));
        v.setTextColor(themeMode == THEME_LIGHT ? darken(borderColor, 0.84f) : Color.rgb(112, 186, 255));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(dp(2), dp(6), dp(2), 0);
        v.setLayoutParams(lp);

        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.rgb(246, 249, 255), Color.rgb(239, 245, 255)}
                        : new int[]{Color.rgb(6, 18, 31), Color.rgb(4, 14, 25)});
        gd.setCornerRadius(dp(14));
        gd.setStroke(dp(1), withAlpha(borderColor, 120));
        v.setBackground(gd);
        return v;
    }

    private TextView compassResultChip(String title, String value) {
        String body = title == null || title.isEmpty() ? value : title.toUpperCase(Locale.US) + "\n" + value;
        TextView v = tv(body, 15, true);
        v.setGravity(Gravity.CENTER);
        v.setLineSpacing(0, 1.08f);
        v.setPadding(dp(7), dp(8), dp(7), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(dp(2), dp(6), dp(2), 0);
        v.setLayoutParams(lp);

        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.rgb(246, 249, 255), Color.rgb(239, 245, 255)}
                        : new int[]{Color.rgb(6, 18, 31), Color.rgb(4, 14, 25)});
        gd.setCornerRadius(dp(14));
        gd.setStroke(dp(1), withAlpha(borderColor, 120));
        v.setBackground(gd);
        return v;
    }

    private View coordBlock() {
        LinearLayout box = toolColumn();

        LinearLayout inputPanel = futuristicInnerPanel();
        inputPanel.setPadding(dp(14), dp(14), dp(14), dp(14));
        TextView azLabel = tv("Azimut", 15, true);
        azLabel.setTextColor(borderColor);
        azLabel.setPadding(dp(2), dp(2), dp(2), dp(6));
        inputPanel.addView(azLabel);
        coordAzInput = edit("");
        coordAzInput.setHint("");
        coordAzInput.setTextSize(22);
        coordAzInput.setMinHeight(dp(58));
        coordAzInput.setPadding(dp(14), dp(10), dp(14), dp(10));
        trackAngleEdit(coordAzInput);
        stylePartialInput(coordAzInput);
        inputPanel.addView(coordAzInput);
        inputPanel.addView(coordAngleShortcutBar());

        TextView distLabel = tv("Distancia horizontal", 15, true);
        distLabel.setTextColor(borderColor);
        distLabel.setPadding(dp(2), dp(10), dp(2), dp(6));
        inputPanel.addView(distLabel);
        distanceInput = edit("");
        distanceInput.setHint("");
        distanceInput.setTextSize(21);
        distanceInput.setMinHeight(dp(56));
        distanceInput.setPadding(dp(14), dp(10), dp(14), dp(10));
        distanceInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        stylePartialInput(distanceInput);
        inputPanel.addView(distanceInput);

        Button calc = partialPrimaryButton("▣  Calcular E/O/N/S");
        calc.setOnClickListener(v -> calculateCoordinateSingle());
        LinearLayout.LayoutParams calcLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        calcLp.setMargins(0, dp(12), 0, 0);
        inputPanel.addView(calc, calcLp);
        box.addView(inputPanel);

        LinearLayout resultPanel = futuristicInnerPanel();
        resultPanel.setPadding(dp(14), dp(14), dp(14), dp(12));
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView resultTitle = tv("✦  Resultados", 19, true);
        resultTitle.setTextColor(borderColor);
        titleRow.addView(resultTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        coordQuadrantInfo = partialHeaderChip("Cuadrante: —", borderColor);
        titleRow.addView(coordQuadrantInfo);
        resultPanel.addView(titleRow);

        LinearLayout metricsRow = new LinearLayout(this);
        metricsRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams metricsLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        metricsLp.setMargins(0, dp(10), 0, dp(8));
        metricsRow.setLayoutParams(metricsLp);
        metricsRow.addView(partialEastMetricCard(), new LinearLayout.LayoutParams(0, dp(108), 1f));
        metricsRow.addView(partialNorthMetricCard(), new LinearLayout.LayoutParams(0, dp(108), 1f));
        resultPanel.addView(metricsRow);

        coordDiagram = new PartialCoordinateDiagramView(this);
        LinearLayout.LayoutParams chartLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(334));
        chartLp.setMargins(0, dp(4), 0, dp(8));
        resultPanel.addView(coordDiagram, chartLp);

        coordResult = resultBox("Resultado pendiente");
        coordResult.setVisibility(View.GONE);
        resultPanel.addView(coordResult);
        box.addView(resultPanel);
        return box;
    }

    private void stylePartialInput(EditText editText) {
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.rgb(253, 254, 255), Color.rgb(244, 248, 255)}
                        : new int[]{Color.rgb(6, 23, 39), Color.rgb(4, 18, 32)});
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), withAlpha(borderColor, 150));
        editText.setBackground(bg);
        editText.setTextColor(textColor);
        editText.setHintTextColor(subTextColor);
    }

    private LinearLayout coordAngleShortcutBar() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.HORIZONTAL);
        wrap.setPadding(0, dp(10), 0, 0);
        String[] keys = {"°", "'", "\"", "00'", "00\"", "⌫"};
        for (String k : keys) {
            Button b = new Button(this);
            b.setText(k);
            b.setAllCaps(false);
            b.setTextSize(13);
            b.setTypeface(Typeface.DEFAULT_BOLD);
            b.setTextColor(themeMode == THEME_LIGHT ? darken(borderColor, 0.82f) : Color.WHITE);
            b.setMinWidth(0);
            b.setMinimumWidth(0);
            b.setPadding(dp(2), dp(6), dp(2), dp(6));
            b.setHeight(dp(48));
            GradientDrawable gd = new GradientDrawable(
                    GradientDrawable.Orientation.LEFT_RIGHT,
                    themeMode == THEME_LIGHT
                            ? new int[]{Color.rgb(247, 250, 255), Color.rgb(239, 245, 255)}
                            : new int[]{Color.rgb(16, 41, 66), Color.rgb(11, 31, 52)});
            gd.setCornerRadius(dp(14));
            gd.setStroke(dp(1), withAlpha(borderColor, 165));
            b.setBackground(gd);
            b.setOnClickListener(v -> {
                if ("⌫".equals(k)) deleteFromAngleInput();
                else insertIntoAngleInput(k);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(dp(3), 0, dp(3), 0);
            wrap.addView(b, lp);
        }
        return wrap;
    }

    private Button partialPrimaryButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(18);
        b.setTextColor(Color.WHITE);
        b.setPadding(dp(10), dp(13), dp(10), dp(13));
        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.rgb(61, 134, 255), Color.rgb(40, 102, 218)});
        gd.setCornerRadius(dp(16));
        gd.setStroke(dp(1), withAlpha(Color.WHITE, 80));
        b.setBackground(gd);
        b.setMinHeight(dp(58));
        return b;
    }

    private TextView partialHeaderChip(String text, int color) {
        TextView chip = tv(text, 12, true);
        chip.setGravity(Gravity.CENTER);
        chip.setTextColor(themeMode == THEME_LIGHT ? darken(color, 0.84f) : Color.rgb(230, 237, 248));
        chip.setPadding(dp(11), dp(6), dp(11), dp(6));
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.rgb(244, 249, 255), Color.rgb(236, 244, 255)}
                        : new int[]{Color.rgb(8, 29, 47), Color.rgb(6, 22, 39)});
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), withAlpha(color, 180));
        chip.setBackground(bg);
        return chip;
    }

    private View partialEastMetricCard() {
        LinearLayout card = partialMetricCardShell(Color.rgb(49, 183, 255));
        TextView label = tv("Δ Este (E/O)", 14, true);
        label.setTextColor(Color.rgb(76, 182, 255));
        card.addView(label);
        coordEastMetric = tv("— m", 23, true);
        coordEastMetric.setTextColor(textColor);
        coordEastMetric.setPadding(0, dp(10), 0, 0);
        card.addView(coordEastMetric);
        TextView arrow = tv("→ componente horizontal", 12, false);
        arrow.setTextColor(Color.rgb(76, 182, 255));
        arrow.setPadding(0, dp(8), 0, 0);
        card.addView(arrow);
        return card;
    }

    private View partialNorthMetricCard() {
        LinearLayout card = partialMetricCardShell(Color.rgb(80, 222, 123));
        TextView label = tv("Δ Norte (N/S)", 14, true);
        label.setTextColor(Color.rgb(97, 228, 136));
        card.addView(label);
        coordNorthMetric = tv("— m", 23, true);
        coordNorthMetric.setTextColor(textColor);
        coordNorthMetric.setPadding(0, dp(10), 0, 0);
        card.addView(coordNorthMetric);
        TextView arrow = tv("↑ componente vertical", 12, false);
        arrow.setTextColor(Color.rgb(97, 228, 136));
        arrow.setPadding(0, dp(8), 0, 0);
        card.addView(arrow);
        return card;
    }

    private LinearLayout partialMetricCardShell(int strokeColor) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(10));
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.rgb(254, 255, 255), Color.rgb(243, 248, 255)}
                        : new int[]{Color.rgb(7, 22, 36), Color.rgb(5, 18, 31)});
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), withAlpha(strokeColor, 195));
        card.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(4), dp(4), dp(4), dp(6));
        card.setLayoutParams(lp);
        return card;
    }

    private View partialSignGuide() {
        LinearLayout guide = new LinearLayout(this);
        guide.setOrientation(LinearLayout.VERTICAL);
        guide.setPadding(dp(4), dp(8), dp(4), dp(0));
        TextView title = tv("Guía de signos", 15, true);
        title.setTextColor(themeMode == THEME_LIGHT ? darken(borderColor, 0.82f) : Color.WHITE);
        guide.addView(title);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(8), 0, 0);
        row.addView(partialSignChip("Este (+)", "→", Color.rgb(51, 176, 255)), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(partialSignChip("Oeste (−)", "←", Color.rgb(62, 196, 224)), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(partialSignChip("Norte (+)", "↑", Color.rgb(80, 222, 123)), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(partialSignChip("Sur (−)", "↓", Color.rgb(255, 176, 55)), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        guide.addView(row);
        return guide;
    }

    private View partialSignChip(String label, String arrow, int color) {
        LinearLayout chip = new LinearLayout(this);
        chip.setOrientation(LinearLayout.VERTICAL);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(dp(6), dp(9), dp(6), dp(9));
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.rgb(251, 253, 255), Color.rgb(242, 247, 255)}
                        : new int[]{Color.rgb(8, 27, 46), Color.rgb(6, 21, 36)});
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), withAlpha(color, 170));
        chip.setBackground(bg);
        TextView t = tv(label, 11, true);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        chip.addView(t);
        TextView a = tv(arrow, 24, true);
        a.setTextColor(color);
        a.setGravity(Gravity.CENTER);
        chip.addView(a);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(4), 0, dp(4), 0);
        chip.setLayoutParams(lp);
        return chip;
    }

    private View distanceBlock() {
        LinearLayout box = toolColumn();

        LinearLayout modePanel = futuristicInnerPanel();
        modePanel.addView(sectionTitle("3. Distancia y pendiente"));
        modePanel.addView(small("Selecciona exactamente 2 valores conocidos. La app calcula el resto y muestra un gráfico más claro y grande."));

        distanceModeButtons.clear();
        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        modeRow.addView(distanceModeButton("Di + ángulo", DIST_MODE_DI_ANGLE), weightParams());
        modeRow.addView(distanceModeButton("Dh + Δh", DIST_MODE_DH_DN), weightParams());
        modeRow.addView(distanceModeButton("Dh + Di", DIST_MODE_DH_DI), weightParams());
        modeRow.addView(distanceModeButton("Di + Δh", DIST_MODE_DI_DN), weightParams());
        modePanel.addView(modeRow);
        TextView chooseHelp = small("Métodos disponibles: la pantalla habilita solo los 2 datos que debes escribir y bloquea el resto.");
        chooseHelp.setPadding(dp(4), dp(6), dp(4), 0);
        modePanel.addView(chooseHelp);
        box.addView(modePanel);

        LinearLayout inputPanel = futuristicInnerPanel();
        TextView inputTitle = tv("Ingresa los valores", 18, true);
        inputTitle.setTextColor(textColor);
        inputPanel.addView(inputTitle);

        dhInput = edit("0.000");
        diInput = edit("0.000");
        angleInput = edit("0°00'00\"");
        trackAngleEdit(angleInput);
        desnivelInput = edit("0.000");
        dhInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        diInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        desnivelInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);

        inputPanel.addView(distanceInputItem("↔", "Distancia horizontal (Dh)", "Longitud horizontal", dhInput, "m"));
        inputPanel.addView(distanceInputItem("╱", "Distancia inclinada (Di)", "Longitud sobre la pendiente", diInput, "m"));
        inputPanel.addView(distanceInputItem("∠", "Ángulo vertical", "Ángulo respecto a la horizontal", angleInput, "°"));
        inputPanel.addView(distanceInputItem("↕", "Δh / diferencia de cota", "Cambio de elevación (+ sube / − baja)", desnivelInput, "m"));
        distanceSlopePreview = readonlyValueBox("—");
        inputPanel.addView(distanceInputItem("%", "Pendiente", "Se calcula automáticamente", distanceSlopePreview, "%"));

        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        actionRow.setGravity(Gravity.CENTER_VERTICAL);

        Button calc = btn("ϟ  Calcular");
        calc.setOnClickListener(v -> calculateDistanceData());
        LinearLayout.LayoutParams calcLp = new LinearLayout.LayoutParams(0, dp(56), 0.68f);
        calcLp.setMargins(0, dp(8), dp(5), 0);
        actionRow.addView(calc, calcLp);

        Button clear = distanceClearButton();
        clear.setOnClickListener(v -> clearDistanceData());
        LinearLayout.LayoutParams clearLp = new LinearLayout.LayoutParams(0, dp(56), 0.32f);
        clearLp.setMargins(dp(5), dp(8), 0, 0);
        actionRow.addView(clear, clearLp);

        inputPanel.addView(actionRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(inputPanel);

        LinearLayout results = futuristicInnerPanel();
        TextView rt = tv("Resultados", 18, true);
        rt.setTextColor(Color.rgb(73, 220, 150));
        results.addView(rt);

        LinearLayout cardsRow = new LinearLayout(this);
        cardsRow.setOrientation(LinearLayout.HORIZONTAL);
        cardsRow.addView(distanceMetricCard("Dh", "Horizontal", "m", Color.rgb(66, 154, 255)), weightParams());
        cardsRow.addView(distanceMetricCard("Di", "Inclinada", "m", Color.rgb(61, 222, 255)), weightParams());
        cardsRow.addView(distanceMetricCard("Δh", "Dif. de cota", "m", Color.rgb(92, 229, 128)), weightParams());
        cardsRow.addView(distanceMetricCard("Pend.", "Inclinación", "%", Color.rgb(168, 96, 255)), weightParams());
        results.addView(cardsRow);

        slopeDiagram = new SlopeDiagramView(this);
        LinearLayout.LayoutParams diagramLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(380));
        diagramLp.setMargins(0, dp(10), 0, 0);
        results.addView(slopeDiagram, diagramLp);
        box.addView(results);

        applyDistanceModeUi();
        resetDistanceResultUi();
        return box;
    }

    private Button distanceClearButton() {
        Button button = new Button(this);
        button.setText("⌫  Limpiar");
        button.setAllCaps(false);
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setTextColor(themeMode == THEME_LIGHT ? darken(borderColor, 0.82f) : Color.rgb(205, 224, 244));
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(dp(6), dp(8), dp(6), dp(8));
        button.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.rgb(247, 250, 255), Color.rgb(238, 245, 255)}
                        : new int[]{Color.rgb(10, 29, 47), Color.rgb(6, 21, 36)});
        bg.setCornerRadius(dp(13));
        bg.setStroke(dp(1), withAlpha(borderColor, 175));
        button.setBackground(bg);
        return button;
    }

    private void clearDistanceData() {
        if (dhInput != null) dhInput.setText("");
        if (diInput != null) diInput.setText("");
        if (angleInput != null) angleInput.setText("");
        if (desnivelInput != null) desnivelInput.setText("");
        resetDistanceResultUi();
        applyDistanceModeUi();
    }

    private Button distanceModeButton(String text, int mode) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(12);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(dp(5), dp(10), dp(5), dp(10));
        button.setMaxLines(2);
        button.setGravity(Gravity.CENTER);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setOnClickListener(v -> {
            distanceCalcMode = mode;
            applyDistanceModeUi();
        });
        distanceModeButtons.add(button);
        return button;
    }

    private void styleDistanceModeButton(Button button, boolean selected, int mode) {
        int[] colors = distanceModeColors(mode);
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                selected
                        ? colors
                        : (themeMode == THEME_LIGHT
                            ? new int[]{Color.rgb(249, 251, 255), Color.rgb(239, 245, 255)}
                            : new int[]{Color.rgb(7, 24, 41), Color.rgb(5, 19, 34)}));
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), selected ? withAlpha(Color.WHITE, 74) : withAlpha(borderColor, 165));
        button.setBackground(bg);
        button.setTextColor(selected ? Color.WHITE : (themeMode == THEME_LIGHT ? darken(borderColor, 0.82f) : Color.rgb(227, 237, 248)));
        button.setAlpha(selected ? 1f : 0.95f);
    }

    private int[] distanceModeColors(int mode) {
        if (mode == DIST_MODE_DH_DN) return new int[]{Color.rgb(65, 145, 255), Color.rgb(72, 206, 145)};
        if (mode == DIST_MODE_DH_DI) return new int[]{Color.rgb(65, 145, 255), Color.rgb(61, 222, 255)};
        if (mode == DIST_MODE_DI_DN) return new int[]{Color.rgb(61, 222, 255), Color.rgb(92, 229, 128)};
        return new int[]{Color.rgb(74, 212, 255), Color.rgb(255, 193, 61)};
    }

    private GradientDrawable distanceFieldBg(int accentColor, boolean editable) {
        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.WHITE, Color.rgb(247, 250, 255)}
                        : new int[]{editable ? Color.rgb(7, 30, 48) : Color.rgb(8, 31, 50), editable ? Color.rgb(5, 22, 38) : Color.rgb(6, 25, 42)});
        gd.setCornerRadius(dp(11));
        gd.setStroke(dp(editable ? 2 : 1), withAlpha(accentColor, editable ? 245 : 165));
        return gd;
    }

    private LinearLayout distanceInputItem(String icon, String titleText, String subtitle, View field, String unit) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(0, dp(4), 0, dp(4));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView iconView = tv(icon, 18, true);
        iconView.setTextColor(borderColor);
        iconView.setGravity(Gravity.CENTER);
        header.addView(iconView, new LinearLayout.LayoutParams(dp(28), dp(28)));

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        TextView title = tv(titleText, 15, true);
        title.setTextColor(textColor);
        labels.addView(title);
        TextView help = small(subtitle);
        help.setTextSize(11);
        labels.addView(help);
        header.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView unitView = tv(unit, 12, true);
        unitView.setTextColor(subTextColor);
        unitView.setGravity(Gravity.END);
        header.addView(unitView);
        wrap.addView(header);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), 0, dp(2));
        field.setLayoutParams(lp);
        wrap.addView(field);
        return wrap;
    }

    private TextView readonlyValueBox(String value) {
        TextView v = tv(value, 16, false);
        v.setTextColor(textColor);
        v.setPadding(dp(13), dp(13), dp(13), dp(13));
        v.setMinHeight(dp(54));
        v.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        v.setBackground(inputBg(false));
        return v;
    }

    private LinearLayout distanceMetricCard(String key, String titleText, String unit, int accentColor) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(10), dp(10), dp(10), dp(10));
        card.setMinimumHeight(dp(124));
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.WHITE, Color.rgb(243, 248, 255)}
                        : new int[]{Color.rgb(9, 27, 46), Color.rgb(6, 20, 35)});
        bg.setCornerRadius(dp(15));
        bg.setStroke(dp(1), withAlpha(accentColor, 180));
        card.setBackground(bg);

        TextView code = tv(key, key.length() > 5 ? 13 : 15, true);
        code.setTextColor(accentColor);
        card.addView(code);

        TextView title = small(titleText);
        title.setTextSize(10);
        title.setTextColor(subTextColor);
        title.setPadding(0, dp(2), 0, 0);
        title.setMaxLines(1);
        card.addView(title);

        TextView value = tv("—", 15, true);
        value.setTextColor(themeMode == THEME_LIGHT ? Color.rgb(32, 48, 69) : Color.rgb(244, 248, 252));
        value.setPadding(0, dp(10), 0, 0);
        value.setSingleLine(true);
        card.addView(value);

        TextView unitView = small(unit);
        unitView.setTextSize(11);
        unitView.setPadding(0, dp(5), 0, 0);
        unitView.setMaxLines(1);
        card.addView(unitView);

        if ("Dh".equals(key)) distanceDhCardValue = value;
        else if ("Di".equals(key)) distanceDiCardValue = value;
        else if ("Δh".equals(key)) distanceDnCardValue = value;
        else distanceSlopeCardValue = value;
        return card;
    }

    private void applyDistanceModeUi() {
        for (int i = 0; i < distanceModeButtons.size(); i++) {
            Button button = distanceModeButtons.get(i);
            int mode = DIST_MODE_DI_ANGLE;
            if (i == 1) mode = DIST_MODE_DH_DN;
            else if (i == 2) mode = DIST_MODE_DH_DI;
            else if (i == 3) mode = DIST_MODE_DI_DN;
            styleDistanceModeButton(button, distanceCalcMode == mode, mode);
        }

        setDistanceFieldEditable(dhInput, distanceCalcMode == DIST_MODE_DH_DN || distanceCalcMode == DIST_MODE_DH_DI, DIST_ACCENT_DH);
        setDistanceFieldEditable(diInput, distanceCalcMode == DIST_MODE_DI_ANGLE || distanceCalcMode == DIST_MODE_DI_DN, DIST_ACCENT_DI);
        setDistanceFieldEditable(angleInput, distanceCalcMode == DIST_MODE_DI_ANGLE, DIST_ACCENT_ANGLE);
        setDistanceFieldEditable(desnivelInput, distanceCalcMode == DIST_MODE_DH_DN || distanceCalcMode == DIST_MODE_DI_DN, DIST_ACCENT_DN);
        styleDistancePreview();
    }

    private void setDistanceFieldEditable(EditText input, boolean editable, int accentColor) {
        if (input == null) return;
        input.setFocusable(editable);
        input.setFocusableInTouchMode(editable);
        input.setCursorVisible(editable);
        input.setLongClickable(editable);
        input.setTextIsSelectable(editable);
        input.setAlpha(editable ? 1f : 0.72f);
        input.setBackground(distanceFieldBg(accentColor, editable));
        input.setTextColor(textColor);
        if (!editable) input.clearFocus();
        if (editable && input == angleInput) activeAngleInput = angleInput;
    }

    private void styleDistancePreview() {
        if (distanceSlopePreview == null) return;
        distanceSlopePreview.setAlpha(0.86f);
        distanceSlopePreview.setBackground(distanceFieldBg(DIST_ACCENT_SLOPE, false));
        distanceSlopePreview.setTextColor(textColor);
    }

    private void resetDistanceResultUi() {
        if (distanceSlopePreview != null) distanceSlopePreview.setText("—");
        if (distanceDhCardValue != null) distanceDhCardValue.setText("—");
        if (distanceDiCardValue != null) distanceDiCardValue.setText("—");
        if (distanceDnCardValue != null) distanceDnCardValue.setText("—");
        if (distanceSlopeCardValue != null) distanceSlopeCardValue.setText("—");
        if (slopeDiagram != null) slopeDiagram.clearData();
    }

    private void updateDistanceResultUi(double horizontal, double inclinada, double desnivel, double angulo, double pendiente) {
        if (dhInput != null) dhInput.setText(f3(horizontal));
        if (diInput != null) diInput.setText(f3(inclinada));
        if (angleInput != null) angleInput.setText(formatDms(angulo));
        if (desnivelInput != null) desnivelInput.setText(f3(desnivel));
        if (distanceSlopePreview != null) distanceSlopePreview.setText(signedPercent(pendiente));
        if (distanceDhCardValue != null) distanceDhCardValue.setText(f3(horizontal));
        if (distanceDiCardValue != null) distanceDiCardValue.setText(f3(inclinada));
        if (distanceDnCardValue != null) distanceDnCardValue.setText(signedNumber(desnivel));
        if (distanceSlopeCardValue != null) distanceSlopeCardValue.setText(signedNumber(pendiente));
        if (slopeDiagram != null) slopeDiagram.update(horizontal, inclinada, desnivel, angulo);
    }

    private String signedNumber(double value) {
        return (value > 0 ? "+" : "") + f3(value);
    }

    private String signedPercent(double value) {
        return (value > 0 ? "+" : "") + f3(value) + " %";
    }

    private View twoHairDistanceMiniBlock() {
        LinearLayout box = toolColumn();

        LinearLayout formulaCard = futuristicInnerPanel();
        formulaCard.setPadding(dp(12), dp(10), dp(12), dp(10));
        TextView formulaTitle = tv("D = |HS − HI| × 100", 19, true);
        formulaTitle.setTextColor(textColor);
        formulaTitle.setGravity(Gravity.CENTER);
        formulaCard.addView(formulaTitle, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(formulaCard);

        LinearLayout readingsCard = futuristicInnerPanel();
        readingsCard.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout readingsHeader = new LinearLayout(this);
        readingsHeader.setOrientation(LinearLayout.HORIZONTAL);
        readingsHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView readingsTitle = tv("LECTURAS", 17, true);
        readingsTitle.setTextColor(borderColor);
        readingsHeader.addView(readingsTitle);
        readingsCard.addView(readingsHeader);

        LinearLayout readingsRow = new LinearLayout(this);
        readingsRow.setOrientation(LinearLayout.HORIZONTAL);

        hiloSupCalcInput = edit("");
        hiloInfCalcInput = edit("");
        hiloDistValue = smallResultCell("0.000");
        hiloSupCalcInput.setTextSize(16);
        hiloInfCalcInput.setTextSize(16);
        hiloDistValue.setTextSize(16);
        hiloDistValue.setTextColor(borderColor);
        hiloDistValue.setTypeface(Typeface.DEFAULT_BOLD);
        hiloSupCalcInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        hiloSupCalcInput.setMinHeight(dp(48));
        hiloInfCalcInput.setMinHeight(dp(48));
        hiloSupCalcInput.setPadding(dp(11), dp(8), dp(11), dp(8));
        hiloInfCalcInput.setPadding(dp(11), dp(8), dp(11), dp(8));
        hiloInfCalcInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);

        LinearLayout supCard = futuristicInnerPanel();
        supCard.setPadding(dp(8), dp(8), dp(8), dp(8));
        GradientDrawable supBg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.rgb(252, 253, 255), Color.rgb(241, 247, 255)}
                        : new int[]{Color.rgb(8, 27, 44), Color.rgb(5, 20, 34)});
        supBg.setCornerRadius(dp(16));
        supBg.setStroke(dp(1), withAlpha(borderColor, 135));
        supCard.setBackground(supBg);
        TextView supTitle = tv("Hilo superior (HS)", 12, true);
        supTitle.setTextColor(textColor);
        supCard.addView(supTitle);
        supCard.addView(hiloSupCalcInput);
        TextView supUnit = smallCenter("m");
        supUnit.setTextColor(subTextColor);
        supCard.addView(supUnit);

        LinearLayout infCard = futuristicInnerPanel();
        infCard.setPadding(dp(8), dp(8), dp(8), dp(8));
        GradientDrawable infBg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.rgb(252, 253, 255), Color.rgb(241, 247, 255)}
                        : new int[]{Color.rgb(8, 27, 44), Color.rgb(5, 20, 34)});
        infBg.setCornerRadius(dp(16));
        infBg.setStroke(dp(1), withAlpha(Color.rgb(55, 213, 143), 155));
        infCard.setBackground(infBg);
        TextView infTitle = tv("Hilo inferior (HI)", 12, true);
        infTitle.setTextColor(textColor);
        infCard.addView(infTitle);
        infCard.addView(hiloInfCalcInput);
        TextView infUnit = smallCenter("m");
        infUnit.setTextColor(subTextColor);
        infCard.addView(infUnit);

        LinearLayout distCard = futuristicInnerPanel();
        distCard.setPadding(dp(8), dp(8), dp(8), dp(8));
        GradientDrawable distBg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.rgb(246, 250, 255), Color.rgb(239, 246, 255)}
                        : new int[]{Color.rgb(8, 27, 44), Color.rgb(5, 20, 34)});
        distBg.setCornerRadius(dp(16));
        distBg.setStroke(dp(1), withAlpha(borderColor, 200));
        distCard.setBackground(distBg);
        TextView distTitle = tv("Distancia (D)", 12, true);
        distTitle.setTextColor(borderColor);
        distCard.addView(distTitle);
        distCard.addView(hiloDistValue);
        TextView distUnit = smallCenter("m");
        distUnit.setTextColor(subTextColor);
        distCard.addView(distUnit);

        readingsRow.addView(supCard, weightParams());
        readingsRow.addView(infCard, weightParams());
        readingsRow.addView(distCard, weightParams());
        readingsCard.addView(readingsRow);
        box.addView(readingsCard);

        LinearLayout visualCard = futuristicInnerPanel();
        visualCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout visualHeader = new LinearLayout(this);
        visualHeader.setOrientation(LinearLayout.HORIZONTAL);
        visualHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView how = tv("¿Cómo se obtienen las lecturas?", 18, true);
        how.setTextColor(textColor);
        visualHeader.addView(how);
        visualCard.addView(visualHeader);
        twoHairDiagram = new StadiaDiagramView(this);
        LinearLayout.LayoutParams diagLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(200));
        diagLp.topMargin = dp(10);
        visualCard.addView(twoHairDiagram, diagLp);
        box.addView(visualCard);

        Button calc = btn("▣  Calcular distancia");
        calc.setOnClickListener(v -> calculateTwoHairDistance());
        LinearLayout.LayoutParams calcLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        calcLp.setMargins(dp(3), dp(4), dp(3), dp(8));
        box.addView(calc, calcLp);

        LinearLayout result = successPanel();
        result.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout resultTop = new LinearLayout(this);
        resultTop.setOrientation(LinearLayout.HORIZONTAL);
        resultTop.setGravity(Gravity.CENTER_VERTICAL);
        TextView rtitle = tv("✓  Distancia calculada", 17, true);
        rtitle.setTextColor(Color.rgb(55, 226, 151));
        resultTop.addView(rtitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button copy = secondaryButton("□  Copiar");
        copy.setTextColor(Color.rgb(55, 226, 151));
        copy.setOnClickListener(v -> copyTwoHairDistance());
        LinearLayout.LayoutParams copyLp = new LinearLayout.LayoutParams(dp(112), dp(44));
        copyLp.rightMargin = dp(6);
        resultTop.addView(copy, copyLp);
        result.addView(resultTop);

        hiloDistCalcResult = resultBox("0.000 m");
        hiloDistCalcResult.setTextSize(28);
        hiloDistCalcResult.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams resultValueLp = (LinearLayout.LayoutParams) hiloDistCalcResult.getLayoutParams();
        resultValueLp.topMargin = dp(8);
        resultValueLp.bottomMargin = dp(2);
        hiloDistCalcResult.setLayoutParams(resultValueLp);
        result.addView(hiloDistCalcResult);

        box.addView(result);
        return box;
    }

    private View partialTableBlock() {
        LinearLayout box = toolColumn();

        LinearLayout header = futuristicInnerPanel();
        header.addView(sectionTitle("5. Poligonal cerrada"));
        header.addView(small("Calcula cierre, correcciones y coordenadas de los vértices."));
        LinearLayout xyRow = new LinearLayout(this);
        xyRow.setOrientation(LinearLayout.HORIZONTAL);
        polyX0Input = edit("X inicial");
        polyY0Input = edit("Y inicial");
        polyX0Input.setText("0.000");
        polyY0Input.setText("0.000");
        polyX0Input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        polyY0Input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        xyRow.addView(labeledInput("X inicial", polyX0Input), weightParams());
        xyRow.addView(labeledInput("Y inicial", polyY0Input), weightParams());
        header.addView(xyRow);
        box.addView(header);

        LinearLayout tablePanel = futuristicInnerPanel();
        LinearLayout tableTop = new LinearLayout(this);
        tableTop.setOrientation(LinearLayout.HORIZONTAL);
        tableTop.setGravity(Gravity.CENTER_VERTICAL);
        TextView tableTitle = tv("Tabla de poligonal", 16, true);
        tableTop.addView(tableTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button tableOptionsButton = secondaryButton("▤  Opciones  ▾");
        tableTop.addView(tableOptionsButton, new LinearLayout.LayoutParams(dp(145), dp(48)));
        tablePanel.addView(tableTop);

        LinearLayout tableOptions = new LinearLayout(this);
        tableOptions.setOrientation(LinearLayout.VERTICAL);
        tableOptions.setVisibility(View.GONE);
        tableOptions.addView(small("Apariencia de tabla y accesos rápidos para AZIMUT."));
        tableOptions.addView(tableColorBar());
        tableOptions.addView(angleShortcutBar());
        tableOptionsButton.setOnClickListener(v -> tableOptions.setVisibility(tableOptions.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
        tablePanel.addView(tableOptions);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(true);
        coordTable = new TableLayout(this);
        coordTable.setStretchAllColumns(false);
        coordTable.addView(headerRow("EST.", "P.V.", "AZIMUT", "DIST.", "RB", "E", "W", "N", "S", "E CORR.", "W CORR.", "N CORR.", "S CORR.", "X", "Y"));
        int coordCount = Math.max(6, getSharedPreferences(PREFS, MODE_PRIVATE).getInt("work_coord_count", 6));
        for (int i = 0; i < coordCount; i++) addCoordRow();
        hsv.addView(coordTable);
        hsv.setFillViewport(true);
        hsv.post(() -> hsv.scrollTo(0, 0));
        LinearLayout.LayoutParams tableLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tableLp.setMargins(0, dp(8), 0, dp(8));
        tablePanel.addView(hsv, tableLp);

        LinearLayout rowButtons = new LinearLayout(this);
        rowButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button add = secondaryButton("＋ Fila");
        add.setOnClickListener(v -> addCoordRow());
        rowButtons.addView(add, weightParams());
        Button calc = btn("▣ Calcular poligonal");
        calc.setOnClickListener(v -> calculateTable());
        rowButtons.addView(calc, new LinearLayout.LayoutParams(0, dp(58), 1.4f));
        Button clear = dangerButton("⌫ Limpiar");
        clear.setOnClickListener(v -> clearWorkAndRebuild());
        rowButtons.addView(clear, weightParams());
        tablePanel.addView(rowButtons);
        box.addView(tablePanel);

        LinearLayout summaryRow = new LinearLayout(this);
        summaryRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout verification = futuristicInnerPanel();
        TextView vt = tv("✓  Verificación", 17, true);
        vt.setTextColor(Color.rgb(63, 222, 154));
        verification.addView(vt);
        polyCheckResult = resultBox("Verificación pendiente");
        polyCheckResult.setTextSize(12);
        verification.addView(polyCheckResult);
        summaryRow.addView(verification, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.53f));

        LinearLayout previewPanel = futuristicInnerPanel();
        TextView pt = tv("Vista rápida", 16, true);
        pt.setTextColor(borderColor);
        previewPanel.addView(pt);
        polyPreview = new PolyPreviewView(this);
        previewPanel.addView(polyPreview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(235)));
        summaryRow.addView(previewPanel, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.47f));
        box.addView(summaryRow);

        polyProcedureResult = resultBox("Procedimiento pendiente. Aquí verás las fórmulas usadas, dónde va seno y dónde va coseno.");
        polyProcedureResult.setVisibility(View.GONE);
        box.addView(polyProcedureResult);
        LinearLayout moreBtns = new LinearLayout(this);
        moreBtns.setOrientation(LinearLayout.HORIZONTAL);
        Button procBtn = secondaryButton("▤  Ver procedimiento");
        procBtn.setOnClickListener(v -> showProcedureDialog("Procedimiento de poligonal", polyProcedureResult.getText()));
        moreBtns.addView(procBtn, weightParams());
        Button graphBtn = secondaryButton("⌁  Ver gráfico");
        graphBtn.setOnClickListener(v -> showPolyGraphDialog());
        moreBtns.addView(graphBtn, weightParams());
        box.addView(moreBtns);
        return box;
    }

    private View levelingBlock() {
        LinearLayout box = toolColumn();

        LinearLayout panel = futuristicInnerPanel();
        panel.addView(sectionTitle("6. Nivelación: cota terreno y cota nivel"));
        panel.addView(small("Registra vistas atrás, intermedias y adelante. La tabla conserva el cálculo actual."));
        LinearLayout summary = new LinearLayout(this);
        summary.setOrientation(LinearLayout.HORIZONTAL);
        summary.addView(statusChip("PUNTOS", "ver tabla"), weightParams());
        summary.addView(statusChip("COTA INICIAL", "fila 1"), weightParams());
        summary.addView(statusChip("CIERRE", "pendiente"), weightParams());
        panel.addView(summary);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(true);
        levelTable = new TableLayout(this);
        levelTable.setStretchAllColumns(false);
        levelTable.addView(headerRowCompact("P.V.", "V. ATRÁS (+)", "V. INTERMEDIA (-)", "V. ADELANTE (-)", "COTA TERRENO", "COTA NIVEL"));
        int levelCount = Math.max(12, getSharedPreferences(PREFS, MODE_PRIVATE).getInt("work_level_count", 12));
        for (int i = 0; i < levelCount; i++) addLevelRow(i == 0 ? "BM1" : "", i == 0 ? "1000.000" : "");
        hsv.addView(levelTable);
        hsv.setFillViewport(true);
        hsv.post(() -> hsv.scrollTo(0, 0));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.setMargins(0, dp(8), 0, dp(8));
        panel.addView(hsv, tlp);

        LinearLayout rowButtons = new LinearLayout(this);
        rowButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button add = secondaryButton("＋ Punto");
        add.setOnClickListener(v -> addLevelRow("", ""));
        rowButtons.addView(add, weightParams());
        Button calc = btn("▣ Calcular cotas");
        calc.setOnClickListener(v -> calculateLeveling());
        rowButtons.addView(calc, weightParams());
        Button clear = dangerButton("⌫ Limpiar");
        clear.setOnClickListener(v -> clearWorkAndRebuild());
        rowButtons.addView(clear, weightParams());
        panel.addView(rowButtons);
        box.addView(panel);

        LinearLayout verification = successPanel();
        TextView vt = tv("✓  Verificación de nivelación", 17, true);
        vt.setTextColor(Color.rgb(63, 222, 154));
        verification.addView(vt);
        levelCheckResult = resultBox("Verificación pendiente");
        verification.addView(levelCheckResult);
        LinearLayout progress = new LinearLayout(this);
        progress.setOrientation(LinearLayout.HORIZONTAL);
        progress.addView(stepTile("1", "Datos", "●"), weightParams());
        progress.addView(stepTile("2", "Cálculo", "○"), weightParams());
        progress.addView(stepTile("3", "Verificación", "○"), weightParams());
        progress.addView(stepTile("4", "Resumen", "○"), weightParams());
        verification.addView(progress);
        box.addView(verification);
        return box;
    }

    private View stadiaLevelingBlock() {
        LinearLayout box = toolColumn();

        LinearLayout panel = futuristicInnerPanel();
        panel.addView(sectionTitle("7. Nivelación con tres hilos"));
        panel.addView(small("Calcula distancia y cotas mediante hilo inferior, medio y superior."));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(true);
        stadiaTable = new TableLayout(this);
        stadiaTable.setStretchAllColumns(false);
        stadiaTable.addView(headerRow("P.V.", "TIPO", "H. INF.", "H. MEDIO", "H. SUP.", "DIST. (m)", "COTA NIVEL"));
        int stadiaCount = Math.max(10, getSharedPreferences(PREFS, MODE_PRIVATE).getInt("work_stadia_count", 10));
        for (int i = 0; i < stadiaCount; i++) addStadiaRow(i == 0 ? "BM1" : "", i == 0 ? "A" : "");
        hsv.addView(stadiaTable);
        hsv.setFillViewport(true);
        hsv.post(() -> hsv.scrollTo(0, 0));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.setMargins(0, dp(10), 0, dp(6));
        panel.addView(hsv, tlp);

        TextView typeHelp = small("Tipo: A = atrás, I = intermedia, D = adelante.");
        typeHelp.setPadding(dp(2), dp(2), 0, dp(5));
        panel.addView(typeHelp);
        LinearLayout rowButtons = new LinearLayout(this);
        rowButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button add = secondaryButton("＋ Fila");
        add.setOnClickListener(v -> addStadiaRow("", ""));
        rowButtons.addView(add, weightParams());
        Button calc = btn("▣ Calcular hilos");
        calc.setOnClickListener(v -> calculateStadiaLeveling());
        rowButtons.addView(calc, weightParams());
        Button clear = dangerButton("⌫ Limpiar");
        clear.setOnClickListener(v -> clearWorkAndRebuild());
        rowButtons.addView(clear, weightParams());
        panel.addView(rowButtons);
        box.addView(panel);

        LinearLayout verification = successPanel();
        TextView vt = tv("VERIFICACIÓN PENDIENTE", 17, true);
        vt.setTextColor(Color.rgb(63, 222, 154));
        verification.addView(vt);
        stadiaCheckResult = resultBox("Σ Dist. atrás: —     Σ Dist. adelante: —\nError de cierre: —     Error tolerado: —\nEstado: pendiente de cálculo");
        verification.addView(stadiaCheckResult);
        box.addView(verification);
        return box;
    }


    private void addCoordRow() {
        TableDataRow row = new TableDataRow();
        TableRow tr = new TableRow(this);
        row.est = cellEdit("", false);
        row.pv = cellEdit("", false);
        row.az = cellEdit("", false);
        trackAngleEdit(row.az);
        row.dist = cellEdit("", true);
        row.rumbo = cellText("—");
        row.sen = cellText("—");
        row.cos = cellText("—");
        row.este = cellText("—");
        row.oeste = cellText("—");
        row.norte = cellText("—");
        row.sur = cellText("—");
        row.eCorr = cellText("—");
        row.wCorr = cellText("—");
        row.nCorr = cellText("—");
        row.sCorr = cellText("—");
        row.x = cellText("—");
        row.y = cellText("—");
        applyDefaultPolyColors(row);
        tr.addView(row.est); tr.addView(row.pv); tr.addView(row.az); tr.addView(row.dist);
        tr.addView(row.rumbo); tr.addView(row.este); tr.addView(row.oeste); tr.addView(row.norte); tr.addView(row.sur);
        tr.addView(row.eCorr); tr.addView(row.wCorr); tr.addView(row.nCorr); tr.addView(row.sCorr); tr.addView(row.x); tr.addView(row.y);
        int visualRow = coordTable.getChildCount();
        for (int c = 0; c < tr.getChildCount(); c++) {
            registerColorCell(tr.getChildAt(c), coordTable, visualRow, c);
        }
        coordTable.addView(tr);
        tableRows.add(row);
    }

    private void addLevelRow(String label, String cotaDefault) {
        LevelDataRow row = new LevelDataRow();
        TableRow tr = new TableRow(this);
        row.pv = cellEditCompact(label, false);
        row.vAtras = cellEditCompact("", true);
        row.vIntermedia = cellEditCompact("", true);
        row.vAdelante = cellEditCompact("", true);
        row.cotaTerreno = cellEditCompact(cotaDefault, true);
        row.cotaNivel = cellTextCompact("—");
        tr.addView(row.pv); tr.addView(row.vAtras); tr.addView(row.vIntermedia); tr.addView(row.vAdelante); tr.addView(row.cotaTerreno); tr.addView(row.cotaNivel);
        levelTable.addView(tr);
        levelRows.add(row);
    }

    private void addStadiaRow(String label, String tipoDefault) {
        StadiaLevelRow row = new StadiaLevelRow();
        TableRow tr = new TableRow(this);
        row.pv = cellEdit(label, false);
        row.tipo = cellEdit(tipoDefault, false);
        row.hInf = cellEdit("", true);
        row.hMedio = cellEdit("", true);
        row.hSup = cellEdit("", true);
        row.distancia = cellText("—");
        row.cotaTerreno = cellEdit("", true);
        row.cotaNivel = cellText("—");
        tr.addView(row.pv); tr.addView(row.tipo); tr.addView(row.hInf); tr.addView(row.hMedio); tr.addView(row.hSup); tr.addView(row.distancia); tr.addView(row.cotaTerreno); tr.addView(row.cotaNivel);
        stadiaTable.addView(tr);
        stadiaRows.add(row);
    }

    private void calculateStadiaLeveling() {
        double currentHI = Double.NaN;
        double sumBack = 0;
        double sumForesight = 0;
        Double firstCota = null;
        Double lastCota = null;
        int calculated = 0;

        for (StadiaLevelRow row : stadiaRows) {
            String pv = row.pv.getText().toString().trim();
            String tipoText = row.tipo.getText().toString().trim();
            Double hInf = optNumber(row.hInf.getText().toString());
            Double hMedio = optNumber(row.hMedio.getText().toString());
            Double hSup = optNumber(row.hSup.getText().toString());
            Double cota = optNumber(row.cotaTerreno.getText().toString());

            boolean empty = pv.isEmpty() && tipoText.isEmpty() && hInf == null && hMedio == null && hSup == null && cota == null;
            if (empty) {
                row.distancia.setText("—");
                row.cotaNivel.setText("—");
                continue;
            }

            try {
                if (hInf != null && hSup != null) {
                    double dist = (hSup - hInf) * 100.0;
                    if (dist < 0) throw new IllegalArgumentException("bad stadia order");
                    row.distancia.setText(f3(dist));
                } else {
                    row.distancia.setText("");
                }

                if (hMedio == null) throw new IllegalArgumentException("missing middle hair");

                int tipo = parseViewType(tipoText, cota != null, currentHI);
                if (tipo == 1) {
                    if (cota == null && lastCota != null) cota = lastCota;
                    if (cota == null) throw new IllegalArgumentException("missing cota");
                    row.cotaTerreno.setText(f3(cota));
                    currentHI = cota + hMedio;
                    sumBack += hMedio;
                    row.cotaNivel.setText(f3(currentHI));
                    if (firstCota == null) firstCota = cota;
                    lastCota = cota;
                } else {
                    if (Double.isNaN(currentHI)) throw new IllegalArgumentException("no HI");
                    cota = currentHI - hMedio;
                    row.cotaTerreno.setText(f3(cota));
                    row.cotaNivel.setText("");
                    if (tipo == 3) sumForesight += hMedio;
                    if (firstCota == null) firstCota = cota;
                    lastCota = cota;
                }

                calculated++;
            } catch (Exception e) {
                row.distancia.setText(row.distancia.getText().toString().equals("—") ? "ERROR" : row.distancia.getText().toString());
                row.cotaNivel.setText("ERROR");
            }
        }

        String check = "Filas procesadas: " + calculated + "\n"
                + "Fórmula distancia: (H. superior - H. inferior) × 100\n"
                + "Σ Vista atrás: " + f3(sumBack) + "\n"
                + "Σ Vista adelante: " + f3(sumForesight);

        if (firstCota != null && lastCota != null) {
            double diffReadings = sumBack - sumForesight;
            double diffCotas = lastCota - firstCota;
            double error = diffReadings - diffCotas;
            check += "\nΣA - ΣD: " + f3(diffReadings)
                    + "\nCota final - Cota inicial: " + f3(diffCotas)
                    + "\nError de comprobación: " + f3(error);
        }

        stadiaCheckResult.setText(check);
        Toast.makeText(this, "Nivelación con hilos calculada", Toast.LENGTH_SHORT).show();
    }

    private int parseViewType(String tipoText, boolean hasKnownCota, double currentHI) {
        String t = tipoText.trim().toUpperCase(Locale.US);
        t = t.replace("Á", "A");
        if (t.isEmpty()) {
            if (Double.isNaN(currentHI) || hasKnownCota) return 1;
            return 2;
        }
        if (t.equals("A") || t.equals("VA") || t.contains("ATRAS")) return 1;
        if (t.equals("I") || t.equals("VI") || t.contains("INTER")) return 2;
        if (t.equals("D") || t.equals("F") || t.equals("FS") || t.equals("VAD") || t.contains("ADEL")) return 3;
        throw new IllegalArgumentException("bad view type");
    }


    private void calculateDistanceData() {
        try {
            Double dh = optNumber(dhInput.getText().toString());
            Double di = optNumber(diInput.getText().toString());
            Double angle = optAngle(angleInput.getText().toString());
            Double dn = optNumber(desnivelInput.getText().toString());

            double horizontal;
            double inclinada;
            double desnivel;
            double angulo;

            switch (distanceCalcMode) {
                case DIST_MODE_DH_DN:
                    if (dh == null || dn == null) {
                        showError("Faltan datos. En este modo debes escribir Dh y Δh.");
                        return;
                    }
                    horizontal = dh;
                    desnivel = dn;
                    inclinada = Math.sqrt(horizontal * horizontal + desnivel * desnivel);
                    angulo = Math.toDegrees(Math.atan2(desnivel, horizontal));
                    break;
                case DIST_MODE_DH_DI:
                    if (dh == null || di == null) {
                        showError("Faltan datos. En este modo debes escribir Dh y Di.");
                        return;
                    }
                    horizontal = dh;
                    inclinada = di;
                    double insideDhDi = inclinada * inclinada - horizontal * horizontal;
                    if (insideDhDi < 0) throw new IllegalArgumentException("invalid");
                    desnivel = Math.sqrt(insideDhDi);
                    angulo = Math.toDegrees(Math.atan2(desnivel, horizontal));
                    break;
                case DIST_MODE_DI_DN:
                    if (di == null || dn == null) {
                        showError("Faltan datos. En este modo debes escribir Di y Δh.");
                        return;
                    }
                    inclinada = di;
                    desnivel = dn;
                    double insideDiDn = inclinada * inclinada - desnivel * desnivel;
                    if (insideDiDn < 0) throw new IllegalArgumentException("invalid");
                    horizontal = Math.sqrt(insideDiDn);
                    angulo = Math.toDegrees(Math.asin(desnivel / inclinada));
                    break;
                default:
                    if (di == null || angle == null) {
                        showError("Faltan datos. En este modo debes escribir Di y ángulo.");
                        return;
                    }
                    inclinada = di;
                    angulo = angle;
                    horizontal = inclinada * Math.cos(Math.toRadians(angulo));
                    desnivel = inclinada * Math.sin(Math.toRadians(angulo));
                    break;
            }

            if (Math.abs(horizontal) < 0.0000001) throw new IllegalArgumentException("zero horizontal");
            double pendiente = (desnivel / horizontal) * 100.0;
            updateDistanceResultUi(horizontal, inclinada, desnivel, angulo, pendiente);
        } catch (Exception e) {
            showError("Revisa los datos. Debes usar un par válido: Di + ángulo, Dh + Δh, Dh + Di o Di + Δh.");
        }
    }

    private void calculateTwoHairDistance() {
        try {
            double sup = parseNumber(hiloSupCalcInput.getText().toString());
            double inf = parseNumber(hiloInfCalcInput.getText().toString());
            double dist = Math.abs(sup - inf) * 100.0;
            if (hiloDistValue != null) hiloDistValue.setText(f3(dist));
            if (twoHairDiagram != null) twoHairDiagram.update(sup, inf);
            hiloDistCalcResult.setText(f3(dist) + " m");
        } catch (Exception e) {
            if (hiloDistValue != null) hiloDistValue.setText("—");
            if (twoHairDiagram != null) twoHairDiagram.clearData();
            hiloDistCalcResult.setText("—");
            showError("Revisa los 2 hilos. Escribe números válidos.");
        }
    }

    private Double getTwoHairDistanceValue() {
        try {
            double sup = parseNumber(hiloSupCalcInput.getText().toString());
            double inf = parseNumber(hiloInfCalcInput.getText().toString());
            return Math.abs(sup - inf) * 100.0;
        } catch (Exception e) {
            return null;
        }
    }

    private void copyTwoHairDistance() {
        Double dist = getTwoHairDistanceValue();
        if (dist == null) {
            showError("Primero calcula una distancia válida con los 2 hilos.");
            return;
        }
        if (hiloDistValue != null) hiloDistValue.setText(f3(dist));
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("distancia", f3(dist)));
            Toast.makeText(this, "Distancia copiada: " + f3(dist), Toast.LENGTH_SHORT).show();
        }
    }

    private void pasteTwoHairDistanceIntoSelectedCell() {
        Double dist = getTwoHairDistanceValue();
        if (dist == null) {
            showError("Primero calcula una distancia válida con los 2 hilos.");
            return;
        }
        if (selectedDistCell == null) {
            showError("Primero toca una celda de DIST. en la poligonal.");
            return;
        }
        if (hiloDistValue != null) hiloDistValue.setText(f3(dist));
        selectedDistCell.setText(f3(dist));
        selectedDistCell.requestFocus();
        selectedDistCell.setSelection(selectedDistCell.getText().length());
        Toast.makeText(this, "Distancia pegada en DIST.", Toast.LENGTH_SHORT).show();
    }

    private void calculateLeveling() {
        double currentHI = Double.NaN;
        double sumBack = 0;
        double sumForesight = 0;
        Double firstCota = null;
        Double lastCota = null;
        int calculated = 0;

        for (LevelDataRow row : levelRows) {
            String pv = row.pv.getText().toString().trim();
            Double va = optNumber(row.vAtras.getText().toString());
            Double vi = optNumber(row.vIntermedia.getText().toString());
            Double vad = optNumber(row.vAdelante.getText().toString());
            Double cota = optNumber(row.cotaTerreno.getText().toString());

            boolean empty = pv.isEmpty() && va == null && vi == null && vad == null && cota == null;
            if (empty) {
                row.cotaNivel.setText("—");
                continue;
            }

            try {
                if (cota == null && !Double.isNaN(currentHI)) {
                    if (vi != null) cota = currentHI - vi;
                    else if (vad != null) cota = currentHI - vad;
                }

                if (cota != null) {
                    row.cotaTerreno.setText(f3(cota));
                    if (firstCota == null) firstCota = cota;
                    lastCota = cota;
                }

                if (vad != null) sumForesight += vad;
                if (va != null) {
                    if (cota == null) throw new IllegalArgumentException("missing cota");
                    sumBack += va;
                    currentHI = cota + va;
                    row.cotaNivel.setText(f3(currentHI));
                } else {
                    row.cotaNivel.setText(vi != null || vad != null ? "" : "—");
                }
                calculated++;
            } catch (Exception e) {
                row.cotaNivel.setText("ERROR");
            }
        }

        String check = "Filas procesadas: " + calculated + "\n"
                + "Σ Vista atrás: " + f3(sumBack) + "\n"
                + "Σ Vista adelante: " + f3(sumForesight);
        if (firstCota != null && lastCota != null) {
            double diffReadings = sumBack - sumForesight;
            double diffCotas = lastCota - firstCota;
            double error = diffReadings - diffCotas;
            check += "\nΣVA - ΣVAdelante: " + f3(diffReadings)
                    + "\nCota final - Cota inicial: " + f3(diffCotas)
                    + "\nError de comprobación: " + f3(error);
        }
        levelCheckResult.setText(check);
        Toast.makeText(this, "Nivelación calculada", Toast.LENGTH_SHORT).show();
    }

    private void calculateAzimuth() {
        try {
            String raw = azInput.getText().toString().trim();
            double az;
            if (azInputMode == 0) {
                az = normalize(parseAngle(raw));
            } else if (azInputMode == 1) {
                az = normalize(parseRumbo(raw));
            } else if (azInputMode == 2) {
                double contraAz = normalize(parseAngle(raw));
                az = contraAzimuth(contraAz);
            } else {
                double contraAz = normalize(parseRumbo(raw));
                az = contraAzimuth(contraAz);
            }
            double contra = contraAzimuth(az);
            if (compassAzView != null) compassAzView.setAzimuth(az);
            if (compassRumboView != null) compassRumboView.setAzimuth(az);
            if (compassContraAzView != null) compassContraAzView.setAzimuth(contra);
            if (compassContraRumboView != null) compassContraRumboView.setAzimuth(contra);
            if (compassAzLabel != null) compassAzLabel.setText(formatDms(az));
            if (compassRumboLabel != null) compassRumboLabel.setText(rumbo(az));
            if (compassContraAzLabel != null) compassContraAzLabel.setText(formatDms(contra));
            if (compassContraRumboLabel != null) compassContraRumboLabel.setText(rumbo(contra));
            if (azQuadrantChip != null) azQuadrantChip.setText("Cuadrante: " + quadrantLabel(az));
            if (azDecimalLabel != null) azDecimalLabel.setText("Formato decimal\n" + rumboDecimal(az));
            if (azExplainLabel != null) azExplainLabel.setText(azimuthStudyText(az));
            if (compassCaption != null) compassCaption.setText(azimuthStudyText(az));
        } catch (Exception e) {
            if (azInputMode == 0 || azInputMode == 2) {
                showError("Revisa el dato angular. Ejemplo correcto: 150°00'00\"");
            } else {
                showError("Revisa el rumbo. Ejemplo correcto: N 30°00'00\" W");
            }
        }
    }

    private void calculateCoordinateSingle() {
        try {
            double az = normalize(parseAngle(coordAzInput.getText().toString()));
            double distance = parseNumber(distanceInput.getText().toString());
            CoordinateResult r = coordinateResult(az, distance);
            coordResult.setText(coordinateOutput(az, distance, r));
            if (coordEastMetric != null) coordEastMetric.setText((r.dx >= 0 ? "+" : "−") + f3(Math.abs(r.dx)) + " m");
            if (coordNorthMetric != null) coordNorthMetric.setText((r.dy >= 0 ? "+" : "−") + f3(Math.abs(r.dy)) + " m");
            if (coordQuadrantInfo != null) coordQuadrantInfo.setText("Cuadrante: " + quadrantLabel(az));
            if (coordDiagram != null) coordDiagram.update(az, r.dx, r.dy);
        } catch (Exception e) {
            showError("Revisa azimut y distancia. Ejemplo: azimut 326°30'00\" y distancia 75.00");
        }
    }

    private void calculateTable() {
        ArrayList<TableDataRow> validRows = new ArrayList<>();
        ArrayList<Double> distances = new ArrayList<>();
        ArrayList<Double> azimuths = new ArrayList<>();
        ArrayList<Double> dxs = new ArrayList<>();
        ArrayList<Double> dys = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();
        ArrayList<String> estLabels = new ArrayList<>();
        ArrayList<String> pvLabels = new ArrayList<>();
        double sumDx = 0;
        double sumDy = 0;
        double perimeter = 0;
        int ok = 0;
        int referenceRows = 0;
        String lastEst = "";

        for (TableDataRow row : tableRows) {
            String azText = row.az.getText().toString().trim();
            String distText = row.dist.getText().toString().trim();
            String estText = row.est.getText().toString().trim();
            String pvText = row.pv.getText().toString().trim();
            if (!estText.isEmpty()) lastEst = estText;
            String effectiveEst = estText.isEmpty() ? lastEst : estText;

            if (azText.isEmpty() && distText.isEmpty() && estText.isEmpty() && pvText.isEmpty()) {
                blankPolyRow(row);
                continue;
            }

            try {
                double az = normalize(parseAngle(azText));
                row.rumbo.setText(rumbo(az));

                if (distText.isEmpty()) {
                    blankPolyNumbers(row);
                    referenceRows++;
                    continue;
                }

                double distance = parseNumber(distText);
                CoordinateResult r = coordinateResult(az, distance);

                row.sen.setText(f6(r.sen));
                row.cos.setText(f6(r.cos));
                setDirection(row.este, row.oeste, r.dx);
                setDirection(row.norte, row.sur, r.dy);

                blankPolyCorrections(row);

                validRows.add(row);
                distances.add(distance);
                azimuths.add(az);
                dxs.add(r.dx);
                dys.add(r.dy);
                labels.add((effectiveEst.isEmpty() ? "?" : effectiveEst) + " - " + (pvText.isEmpty() ? "?" : pvText));
                estLabels.add(effectiveEst);
                pvLabels.add(pvText);

                sumDx += r.dx;
                sumDy += r.dy;
                perimeter += Math.abs(distance);
                ok++;
            } catch (Exception e) {
                row.rumbo.setText("ERROR");
                blankPolyNumbers(row);
            }
        }

        if (validRows.isEmpty() || perimeter == 0) {
            if (polyCheckResult != null) polyCheckResult.setText("Agrega azimut y distancia para calcular la poligonal.");
            if (polyProcedureResult != null) {
                polyProcedureResult.setText("Procedimiento pendiente. Primero llena una fila con azimut y distancia.");
            }
            Toast.makeText(this, "No hay filas válidas", Toast.LENGTH_SHORT).show();
            return;
        }

        SpannableStringBuilder procedure = buildPolyProcedureHeader();
        for (int i = 0; i < validRows.size(); i++) {
            appendPartialProcedureRow(procedure, labels.get(i), azimuths.get(i), distances.get(i), dxs.get(i), dys.get(i), i + 1);
        }

        boolean closedChain = isClosedPolygonChain(estLabels, pvLabels);
        if (validRows.size() < 3 || !closedChain) {
            for (TableDataRow row : validRows) {
                blankPolyCorrections(row);
            }
            String check = "Parciales calculadas: " + ok
                    + "\nFilas solo referencia: " + referenceRows
                    + "\nPerímetro ingresado: " + f3(perimeter)
                    + "\nFaltan lados o la secuencia no cierra."
                    + "\nPara compensar debe ser: A-B, B-C, C-D... y terminar regresando al inicio.";
            if (polyCheckResult != null) polyCheckResult.setText(check);
            appendPlain(procedure, "\nPara corregidas, X/Y y gráfico completo, llena una poligonal cerrada: el último P.V. debe volver al primer EST.\n");
            if (polyProcedureResult != null) polyProcedureResult.setText(procedure);
            if (polyPreview != null) polyPreview.updateFromDeltas(dxs, dys);
            Toast.makeText(this, "Parciales calculadas. La poligonal todavía no cierra.", Toast.LENGTH_SHORT).show();
            return;
        }

        Double x0 = optNumber(polyX0Input.getText().toString());
        Double y0 = optNumber(polyY0Input.getText().toString());
        double x = x0 != null ? x0 : 0;
        double y = y0 != null ? y0 : 0;
        double startX = x;
        double startY = y;
        ArrayList<Double> correctedXs = new ArrayList<>();
        ArrayList<Double> correctedYs = new ArrayList<>();
        correctedXs.add(startX);
        correctedYs.add(startY);

        for (int i = 0; i < validRows.size(); i++) {
            TableDataRow row = validRows.get(i);
            double distance = distances.get(i);
            double dx = dxs.get(i);
            double dy = dys.get(i);
            double corrX = -sumDx * (Math.abs(distance) / perimeter);
            double corrY = -sumDy * (Math.abs(distance) / perimeter);
            double cdx = dx + corrX;
            double cdy = dy + corrY;

            setDirection(row.eCorr, row.wCorr, cdx);
            setDirection(row.nCorr, row.sCorr, cdy);
            x += cdx;
            y += cdy;
            row.x.setText(f3(x));
            row.y.setText(f3(y));
            correctedXs.add(x);
            correctedYs.add(y);

            appendCorrectionProcedureRow(procedure, labels.get(i), corrX, corrY, cdx, cdy, x, y);
        }

        double closeError = Math.sqrt(sumDx * sumDx + sumDy * sumDy);
        double precision = closeError == 0 ? 0 : perimeter / closeError;
        double signedArea = signedPolygonArea(correctedXs, correctedYs);
        double area = Math.abs(signedArea);
        String orientation = signedArea < 0 ? "horario" : signedArea > 0 ? "antihorario" : "sin orientación";
        String check = "Filas calculadas: " + ok
                + "\nFilas solo referencia: " + referenceRows
                + "\nPerímetro: " + f3(perimeter)
                + "\nError X: " + f3(sumDx)
                + "\nError Y: " + f3(sumDy)
                + "\nError de cierre: " + f3(closeError)
                + "\nPrecisión aprox.: 1/" + (precision == 0 ? "∞" : String.format(Locale.US, "%.0f", precision))
                + "\nÁrea: " + f3(area) + " m²  (" + String.format(Locale.US, "%.4f", area / 10000.0) + " ha)"
                + "\nSentido: " + orientation
                + "\nInicio: X " + f3(startX) + "  Y " + f3(startY)
                + "\nFinal corregido: X " + f3(x) + "  Y " + f3(y);
        if (polyCheckResult != null) polyCheckResult.setText(check);
        if (polyPreview != null) polyPreview.updateFromCoordinates(correctedXs, correctedYs);
        appendProcedureSummary(procedure, sumDx, sumDy, perimeter, closeError);
        if (polyProcedureResult != null) polyProcedureResult.setText(procedure);
        Toast.makeText(this, "Poligonal calculada: " + ok + " lados", Toast.LENGTH_SHORT).show();
    }

    private double signedPolygonArea(List<Double> xs, List<Double> ys) {
        if (xs == null || ys == null || xs.size() < 4 || xs.size() != ys.size()) return 0;
        double sum = 0;
        for (int i = 0; i < xs.size() - 1; i++) {
            sum += xs.get(i) * ys.get(i + 1) - xs.get(i + 1) * ys.get(i);
        }
        if (Math.abs(xs.get(xs.size() - 1) - xs.get(0)) > 0.000001
                || Math.abs(ys.get(ys.size() - 1) - ys.get(0)) > 0.000001) {
            int last = xs.size() - 1;
            sum += xs.get(last) * ys.get(0) - xs.get(0) * ys.get(last);
        }
        return sum / 2.0;
    }

    private void setDirection(TextView positive, TextView negative, double value) {
        double v = cleanZero(value);
        if (v > 0) {
            positive.setText(f3(v));
            negative.setText("—");
        } else if (v < 0) {
            positive.setText("—");
            negative.setText(f3(-v));
        } else {
            positive.setText("0.000");
            negative.setText("—");
        }
    }

    private void blankPolyRow(TableDataRow row) {
        row.rumbo.setText("—");
        blankPolyNumbers(row);
    }

    private void blankPolyNumbers(TableDataRow row) {
        row.sen.setText("—"); row.cos.setText("—");
        row.este.setText("—"); row.oeste.setText("—"); row.norte.setText("—"); row.sur.setText("—");
        blankPolyCorrections(row);
    }

    private void blankPolyCorrections(TableDataRow row) {
        row.eCorr.setText("—"); row.wCorr.setText("—"); row.nCorr.setText("—"); row.sCorr.setText("—");
        row.x.setText("—"); row.y.setText("—");
    }

    private boolean isClosedPolygonChain(List<String> ests, List<String> pvs) {
        if (ests == null || pvs == null || ests.size() < 3 || ests.size() != pvs.size()) return false;
        String first = normalizeLabel(ests.get(0));
        String last = normalizeLabel(pvs.get(pvs.size() - 1));
        if (first.isEmpty() || last.isEmpty() || !first.equals(last)) return false;
        for (int i = 1; i < ests.size(); i++) {
            String prevPv = normalizeLabel(pvs.get(i - 1));
            String currentEst = normalizeLabel(ests.get(i));
            if (prevPv.isEmpty() || currentEst.isEmpty() || !prevPv.equals(currentEst)) return false;
        }
        return true;
    }

    private String normalizeLabel(String value) {
        return value == null ? "" : value.trim().toUpperCase(Locale.US);
    }

    private CoordinateResult coordinateResult(double az, double distance) {
        double rad = Math.toRadians(az);
        double sen = Math.sin(rad);
        double cos = Math.cos(rad);
        double dx = distance * sen;
        double dy = distance * cos;
        CoordinateResult r = new CoordinateResult();
        r.sen = sen;
        r.cos = cos;
        r.dx = dx;
        r.dy = dy;
        r.este = dx > 0 ? dx : 0;
        r.oeste = dx < 0 ? -dx : 0;
        r.norte = dy > 0 ? dy : 0;
        r.sur = dy < 0 ? -dy : 0;
        return r;
    }

    private String coordinateOutput(double az, double distance, CoordinateResult r) {
        return "Azimut: " + formatDms(az) + "\n"
                + "Rumbo: " + rumbo(az) + "\n"
                + "Distancia: " + f3(distance) + "\n"
                + "Seno: " + f6(r.sen) + "\n"
                + "Coseno: " + f6(r.cos) + "\n"
                + "ΔX = D × sen(Az): " + f3(r.dx) + "\n"
                + "ΔY = D × cos(Az): " + f3(r.dy) + "\n"
                + "Este: " + f3(r.este) + "   Oeste: " + f3(r.oeste) + "\n"
                + "Norte: " + f3(r.norte) + "   Sur: " + f3(r.sur);
    }

    private double parseAngle(String value) {
        String s = value.trim().replace(',', '.');
        if (s.isEmpty()) throw new IllegalArgumentException("empty");

        Matcher m = Pattern.compile("-?\\d+(?:\\.\\d+)?").matcher(s);
        ArrayList<Double> nums = new ArrayList<>();
        while (m.find()) nums.add(Double.parseDouble(m.group()));
        if (nums.isEmpty()) throw new IllegalArgumentException("no number");

        double deg = nums.get(0);
        double sign = deg < 0 ? -1 : 1;
        deg = Math.abs(deg);
        double min = nums.size() > 1 ? Math.abs(nums.get(1)) : 0;
        double sec = nums.size() > 2 ? Math.abs(nums.get(2)) : 0;

        if (nums.size() == 1 && !s.contains("°") && !s.contains("º") && !s.contains("'") && !s.contains("\"") && !s.contains(" ")) {
            String clean = s.startsWith("-") ? s.substring(1) : s;
            if (clean.matches("\\d+\\.\\d{2}")) {
                String[] parts = clean.split("\\.");
                double d = Double.parseDouble(parts[0]);
                double mm = Double.parseDouble(parts[1]);
                if (mm < 60) return sign * (d + mm / 60.0);
            }
            if (clean.matches("\\d+\\.\\d{4}")) {
                String[] parts = clean.split("\\.");
                double d = Double.parseDouble(parts[0]);
                double mm = Double.parseDouble(parts[1].substring(0, 2));
                double ss = Double.parseDouble(parts[1].substring(2, 4));
                if (mm < 60 && ss < 60) return sign * (d + mm / 60.0 + ss / 3600.0);
            }
            return nums.get(0);
        }
        return sign * (deg + min / 60.0 + sec / 3600.0);
    }

    private Double optNumber(String value) {
        String s = value.trim();
        if (s.isEmpty() || s.equals("—")) return null;
        return parseNumber(s);
    }

    private Double optAngle(String value) {
        String s = value.trim();
        if (s.isEmpty() || s.equals("—")) return null;
        return parseAngle(s);
    }

    private double parseRumbo(String value) {
        String s = value.trim().toUpperCase(Locale.US).replace("º", "°").replace("O", "W");
        if (s.isEmpty()) throw new IllegalArgumentException("empty");
        s = s.replaceAll("\\s+", " ").trim();
        char first = 0;
        char last = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == 'N' || c == 'S') { first = c; break; }
        }
        for (int i = s.length() - 1; i >= 0; i--) {
            char c = s.charAt(i);
            if (c == 'E' || c == 'W') { last = c; break; }
        }
        if (first == 0 || last == 0) throw new IllegalArgumentException("bad rumbo");
        int i1 = s.indexOf(first);
        int i2 = s.lastIndexOf(last);
        if (i2 <= i1) throw new IllegalArgumentException("bad rumbo");
        String middle = s.substring(i1 + 1, i2).trim();
        double ang = parseAngle(middle);
        if (ang < 0 || ang > 90) throw new IllegalArgumentException("angle out of range");
        if (first == 'N' && last == 'E') return ang;
        if (first == 'S' && last == 'E') return 180.0 - ang;
        if (first == 'S' && last == 'W') return 180.0 + ang;
        return 360.0 - ang;
    }

    private double parseNumber(String value) {
        String s = value.trim().replace(',', '.');
        if (s.isEmpty()) throw new IllegalArgumentException("empty");
        return Double.parseDouble(s);
    }

    private double normalize(double angle) {
        double a = angle % 360.0;
        if (a < 0) a += 360.0;
        if (Math.abs(a - 360.0) < 0.0000001) a = 0;
        return a;
    }

    private double contraAzimuth(double az) {
        return normalize(az + 180.0);
    }

    private String rumbo(double az) {
        double a = normalize(az);
        if (near(a, 0) || near(a, 360)) return "N";
        if (near(a, 90)) return "E";
        if (near(a, 180)) return "S";
        if (near(a, 270)) return "W";
        if (a > 0 && a < 90) return "N " + formatDms(a) + " E";
        if (a > 90 && a < 180) return "S " + formatDms(180 - a) + " E";
        if (a > 180 && a < 270) return "S " + formatDms(a - 180) + " W";
        return "N " + formatDms(360 - a) + " W";
    }

    private double rumboAngle(double az) {
        double a = normalize(az);
        if (a <= 90) return a;
        if (a <= 180) return 180.0 - a;
        if (a <= 270) return a - 180.0;
        return 360.0 - a;
    }

    private String quadrantLabel(double az) {
        double a = normalize(az);
        if (near(a, 0) || near(a, 90) || near(a, 180) || near(a, 270) || near(a, 360)) {
            return "Eje cardinal";
        }
        if (a > 0 && a < 90) return "NE";
        if (a > 90 && a < 180) return "SE";
        if (a > 180 && a < 270) return "SW";
        return "NW";
    }

    private String rumboDecimal(double az) {
        double a = normalize(az);
        if (near(a, 0) || near(a, 360)) return "N / 0.0000°";
        if (near(a, 90)) return "E / 90.0000°";
        if (near(a, 180)) return "S / 180.0000°";
        if (near(a, 270)) return "W / 270.0000°";
        double rb = rumboAngle(a);
        if (a > 0 && a < 90) return String.format(Locale.US, "N %.4f° E", rb);
        if (a > 90 && a < 180) return String.format(Locale.US, "S %.4f° E", rb);
        if (a > 180 && a < 270) return String.format(Locale.US, "S %.4f° W", rb);
        return String.format(Locale.US, "N %.4f° W", rb);
    }

    private String azimuthStudyText(double az) {
        double a = normalize(az);
        String azTxt = formatDms(a);
        if (near(a, 0) || near(a, 360)) return "Explicación: azimut 0° está sobre el Norte. Rumbo = N.";
        if (near(a, 90)) return "Explicación: azimut 90° está sobre el Este. Rumbo = E.";
        if (near(a, 180)) return "Explicación: azimut 180° está sobre el Sur. Rumbo = S.";
        if (near(a, 270)) return "Explicación: azimut 270° está sobre el Oeste. Rumbo = W.";
        double rb = rumboAngle(a);
        if (a > 0 && a < 90) {
            return "Explicación: " + azTxt + " está en NE (0° a 90°). El rumbo conserva el ángulo: N " + formatDms(rb) + " E.";
        }
        if (a > 90 && a < 180) {
            return "Explicación: " + azTxt + " está en SE. Se calcula 180° - azimut = " + formatDms(rb) + ". Rumbo: S " + formatDms(rb) + " E.";
        }
        if (a > 180 && a < 270) {
            return "Explicación: " + azTxt + " está en SW. Se calcula azimut - 180° = " + formatDms(rb) + ". Rumbo: S " + formatDms(rb) + " W.";
        }
        return "Explicación: " + azTxt + " está en NW. Se calcula 360° - azimut = " + formatDms(rb) + ". Rumbo: N " + formatDms(rb) + " W.";
    }

    private boolean near(double a, double b) {
        return Math.abs(a - b) < 0.0000001;
    }

    private String formatDms(double angle) {
        double a = Math.abs(angle);
        int deg = (int) Math.floor(a);
        double minFloat = (a - deg) * 60.0;
        int min = (int) Math.floor(minFloat);
        double secFloat = (minFloat - min) * 60.0;
        int sec = (int) Math.round(secFloat);
        if (sec == 60) { sec = 0; min++; }
        if (min == 60) { min = 0; deg++; }
        return String.format(Locale.US, "%02d°%02d'%02d\"", deg, min, sec);
    }

    private String f3(double v) {
        return String.format(Locale.US, "%.3f", cleanZero(v));
    }

    private String f6(double v) {
        return String.format(Locale.US, "%.6f", cleanZero(v));
    }

    private double cleanZero(double v) {
        return Math.abs(v) < 0.0000000001 ? 0 : v;
    }

    private void showError(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    private View collapsibleCard(LinearLayout box, String iconText, String titleText, boolean open) {
        if (box.getChildCount() > 0) box.removeViewAt(0); // El título interno se reemplaza por una cabecera plegable.

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        while (box.getChildCount() > 0) {
            View child = box.getChildAt(0);
            box.removeViewAt(0);
            body.addView(child);
        }
        body.setVisibility(open ? View.VISIBLE : View.GONE);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(2), dp(2), dp(2), dp(8));

        TextView icon = tv(iconText, 19, true);
        icon.setTextColor(borderColor);
        icon.setGravity(Gravity.CENTER);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setColor(withAlpha(borderColor, themeMode == THEME_LIGHT ? 28 : 42));
        iconBg.setCornerRadius(dp(12));
        icon.setBackground(iconBg);
        header.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(42)));

        TextView title = tv(titleText, 18, true);
        title.setPadding(dp(10), 0, 0, 0);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView arrow = tv(open ? "⌄" : "›", 28, true);
        arrow.setTextColor(subTextColor);
        arrow.setGravity(Gravity.CENTER);
        header.addView(arrow, new LinearLayout.LayoutParams(dp(42), dp(42)));

        SectionState state = new SectionState(body, arrow);
        box.setTag(state);
        header.setOnClickListener(v -> setSectionOpen(box, body.getVisibility() != View.VISIBLE));
        box.addView(header);
        box.addView(body);
        return box;
    }

    private View quickNavigation(ScrollView scroll, String[] labels, View[] sections) {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(10));
        hsv.setLayoutParams(lp);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(2), 0, dp(2));
        int count = Math.min(labels.length, sections.length);
        for (int i = 0; i < count; i++) {
            final View section = sections[i];
            Button chip = secondaryButton(labels[i]);
            chip.setTextSize(12);
            LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42));
            chipLp.setMargins(dp(3), 0, dp(3), 0);
            chip.setLayoutParams(chipLp);
            chip.setOnClickListener(v -> {
                setSectionOpen(section, true);
                scroll.post(() -> scroll.smoothScrollTo(0, Math.max(0, section.getTop() - dp(6))));
            });
            row.addView(chip);
        }
        hsv.addView(row);
        hsv.post(() -> hsv.scrollTo(0, 0));
        return hsv;
    }

    private void setSectionOpen(View section, boolean open) {
        Object tag = section.getTag();
        if (!(tag instanceof SectionState)) return;
        SectionState state = (SectionState) tag;
        boolean wasOpen = state.body.getVisibility() == View.VISIBLE;
        state.body.setVisibility(open ? View.VISIBLE : View.GONE);
        state.arrow.setText(open ? "⌄" : "›");
    }

    private LinearLayout toolColumn() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(Color.TRANSPARENT);
        return box;
    }

    private LinearLayout successPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(13), dp(13), dp(13), dp(13));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(8), 0, dp(8));
        panel.setLayoutParams(lp);
        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.rgb(244, 253, 249), Color.rgb(235, 249, 243)}
                        : new int[]{Color.rgb(5, 48, 41), Color.rgb(4, 31, 33)});
        gd.setCornerRadius(dp(17));
        gd.setStroke(dp(1), themeMode == THEME_LIGHT ? Color.rgb(45, 180, 125) : Color.rgb(35, 218, 148));
        panel.setBackground(gd);
        return panel;
    }

    private View stepTile(String number, String label, String glyph) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER);
        tile.setPadding(dp(4), dp(7), dp(4), dp(7));
        TextView badge = tv(number, 11, true);
        badge.setGravity(Gravity.CENTER);
        badge.setTextColor(Color.rgb(57, 231, 151));
        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setColor(themeMode == THEME_LIGHT ? Color.rgb(232, 250, 242) : Color.rgb(5, 55, 43));
        badgeBg.setCornerRadius(dp(16));
        badgeBg.setStroke(dp(1), Color.rgb(57, 231, 151));
        badge.setBackground(badgeBg);
        tile.addView(badge, new LinearLayout.LayoutParams(dp(32), dp(32)));
        TextView icon = tv(glyph, 20, true);
        icon.setGravity(Gravity.CENTER);
        icon.setTextColor(themeMode == THEME_LIGHT ? darken(borderColor, .8f) : borderColor);
        tile.addView(icon);
        TextView txt = tv(label, 10, true);
        txt.setGravity(Gravity.CENTER);
        txt.setTextColor(textColor);
        tile.addView(txt);
        return tile;
    }

    private TextView metricText(String title, String value, int color) {
        TextView v = tv(title + "\n" + value, 14, true);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setLineSpacing(0, 1.12f);
        v.setPadding(dp(12), dp(10), dp(8), dp(10));
        v.setTextColor(color);
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.WHITE, Color.rgb(246, 250, 253)}
                        : new int[]{Color.rgb(8, 31, 50), Color.rgb(5, 22, 38)});
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), withAlpha(color, 155));
        v.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), dp(6), dp(4));
        v.setLayoutParams(lp);
        return v;
    }

    private LinearLayout futuristicInnerPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(8), 0, dp(8));
        panel.setLayoutParams(lp);
        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.rgb(252, 253, 255), Color.rgb(241, 247, 255)}
                        : new int[]{Color.rgb(10, 31, 49), Color.rgb(6, 22, 38)});
        gd.setCornerRadius(dp(16));
        gd.setStroke(dp(1), withAlpha(borderColor, themeMode == THEME_LIGHT ? 110 : 150));
        panel.setBackground(gd);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) panel.setElevation(dp(2));
        return panel;
    }

    private View statusChip(String title, String value) {
        LinearLayout chip = new LinearLayout(this);
        chip.setOrientation(LinearLayout.VERTICAL);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(dp(7), dp(8), dp(7), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == THEME_LIGHT ? Color.rgb(246, 250, 255) : Color.rgb(8, 29, 47));
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), withAlpha(borderColor, 120));
        chip.setBackground(bg);
        TextView t = tv(title, 10, true);
        t.setTextColor(subTextColor);
        t.setGravity(Gravity.CENTER);
        TextView v = tv(value, 12, true);
        v.setTextColor(textColor);
        v.setGravity(Gravity.CENTER);
        v.setPadding(0, dp(3), 0, 0);
        chip.addView(t);
        chip.addView(v);
        return chip;
    }

    private Button toolActionButton(String text, boolean danger) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(Color.WHITE);
        b.setPadding(dp(8), dp(10), dp(8), dp(10));
        GradientDrawable gd;
        if (danger) {
            gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{Color.rgb(105, 28, 46), Color.rgb(63, 24, 41)});
            gd.setStroke(dp(1), Color.rgb(244, 81, 101));
        } else {
            gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{borderColor, darken(borderColor, 0.72f)});
            gd.setStroke(dp(1), withAlpha(Color.WHITE, 60));
        }
        gd.setCornerRadius(dp(14));
        b.setBackground(gd);
        b.setMinHeight(dp(54));
        return b;
    }

    private Button dangerButton(String text) {
        Button b = secondaryButton(text);
        b.setTextColor(themeMode == THEME_LIGHT ? Color.rgb(190, 35, 55) : Color.rgb(255, 96, 111));
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(themeMode == THEME_LIGHT ? Color.rgb(255, 248, 249) : Color.rgb(36, 18, 29));
        gd.setCornerRadius(dp(12));
        gd.setStroke(dp(1), Color.rgb(235, 73, 93));
        b.setBackground(gd);
        return b;
    }

    private int darken(int color, float factor) {
        return Color.rgb(
                Math.max(0, Math.min(255, Math.round(Color.red(color) * factor))),
                Math.max(0, Math.min(255, Math.round(Color.green(color) * factor))),
                Math.max(0, Math.min(255, Math.round(Color.blue(color) * factor))));
    }

    private View signGuide() {
        LinearLayout guide = new LinearLayout(this);
        guide.setOrientation(LinearLayout.VERTICAL);
        guide.setPadding(dp(8), dp(8), dp(8), dp(4));
        TextView title = small("GUÍA DE SIGNOS");
        title.setTypeface(Typeface.DEFAULT_BOLD);
        guide.addView(title);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(signItem("ESTE (+)", "→", Color.rgb(51, 176, 255)), weightParams());
        row.addView(signItem("OESTE (−)", "←", Color.rgb(62, 196, 224)), weightParams());
        row.addView(signItem("NORTE (+)", "↑", Color.rgb(80, 222, 123)), weightParams());
        row.addView(signItem("SUR (−)", "↓", Color.rgb(255, 176, 55)), weightParams());
        guide.addView(row);
        return guide;
    }

    private View signItem(String label, String arrow, int color) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        TextView t = tv(label, 9, true);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        TextView a = tv(arrow, 24, false);
        a.setTextColor(color);
        a.setGravity(Gravity.CENTER);
        item.addView(t);
        item.addView(a);
        return item;
    }

    private Button secondaryButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextColor(textColor);
        button.setTextSize(13);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
        button.setPadding(dp(6), dp(7), dp(6), dp(7));
        button.setGravity(Gravity.CENTER);
        button.setMaxLines(2);
        button.setHeight(dp(50));
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.rgb(255, 255, 255), Color.rgb(246, 249, 253)}
                        : new int[]{Color.rgb(14, 39, 60), Color.rgb(7, 27, 45)});
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), withAlpha(borderColor, 175));
        button.setBackground(bg);
        return button;
    }

    private int withAlpha(int color, int alpha) {
        return Color.argb(Math.max(0, Math.min(255, alpha)), Color.red(color), Color.green(color), Color.blue(color));
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, 0, 0, dp(14));
        box.setLayoutParams(lp);

        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.WHITE, Color.rgb(245, 249, 254)}
                        : new int[]{Color.rgb(15, 42, 65), Color.rgb(6, 25, 43)});
        gd.setCornerRadius(dp(19));
        gd.setStroke(dp(1), withAlpha(borderColor, themeMode == THEME_LIGHT ? 100 : 145));
        box.setBackground(gd);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) box.setElevation(dp(3));
        return box;
    }

    private TextView sectionTitle(String text) {
        TextView v = tv(text, 20, true);
        v.setTextColor(themeMode == THEME_LIGHT ? darken(borderColor, 0.78f) : Color.rgb(65, 143, 255));
        v.setPadding(0, 0, 0, dp(8));
        v.setLineSpacing(0, 1.04f);
        return v;
    }

    private TextView small(String text) {
        TextView v = tv(text, 13, false);
        v.setTextColor(subTextColor);
        v.setLineSpacing(0, 1.15f);
        return v;
    }

    private TextView smallCenter(String text) {
        TextView v = small(text);
        v.setGravity(Gravity.CENTER);
        v.setPadding(0, dp(2), 0, 0);
        return v;
    }

    private TextView tv(String text, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(textColor);
        v.setTextSize(sp);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private LinearLayout labeledInput(String label, EditText input) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        TextView title = small(label);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(dp(4), 0, 0, 0);
        wrap.addView(title);
        wrap.addView(input);
        return wrap;
    }

    private LinearLayout labeledText(String label, TextView value) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        TextView title = small(label);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(dp(4), 0, 0, 0);
        wrap.addView(title);
        wrap.addView(value);
        return wrap;
    }

    private TextView smallResultCell(String text) {
        TextView v = tv(text, 16, false);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(8), 0, dp(8));
        v.setLayoutParams(lp);
        v.setBackground(inputBg(false));
        return v;
    }

    private void trackAngleEdit(EditText input) {
        if (input == null) return;
        input.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus && v instanceof EditText) activeAngleInput = (EditText) v;
        });
        input.setOnClickListener(v -> {
            if (v instanceof EditText) activeAngleInput = (EditText) v;
        });
    }

    private LinearLayout azimuthShortcutBar() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(0, dp(4), 0, dp(6));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(azimuthShortcutButton("0°", v -> applyAzimuthPreset(0)), weightParams());
        row1.addView(azimuthShortcutButton("90°", v -> applyAzimuthPreset(90)), weightParams());
        row1.addView(azimuthShortcutButton("180°", v -> applyAzimuthPreset(180)), weightParams());
        row1.addView(azimuthShortcutButton("270°", v -> applyAzimuthPreset(270)), weightParams());
        wrap.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(azimuthShortcutButton("+90°", v -> offsetCurrentAzimuth(90)), weightParams());
        row2.addView(azimuthShortcutButton("-90°", v -> offsetCurrentAzimuth(-90)), weightParams());
        row2.addView(azimuthShortcutButton("↔", v -> offsetCurrentAzimuth(180)), weightParams());
        row2.addView(azimuthShortcutButton("⌫", v -> deleteFromAngleInput()), weightParams());
        wrap.addView(row2);
        return wrap;
    }

    private Button azimuthShortcutButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(themeMode == THEME_LIGHT ? darken(borderColor, 0.82f) : Color.rgb(112, 186, 255));
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(13);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(2), dp(7), dp(2), dp(7));
        b.setHeight(dp(46));
        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                themeMode == THEME_LIGHT
                        ? new int[]{Color.rgb(246, 250, 255), Color.rgb(238, 245, 255)}
                        : new int[]{Color.rgb(8, 25, 42), Color.rgb(5, 18, 31)});
        gd.setCornerRadius(dp(12));
        gd.setStroke(dp(1), withAlpha(borderColor, 160));
        b.setBackground(gd);
        b.setOnClickListener(listener);
        return b;
    }

    private void applyAzimuthPreset(double value) {
        if (azInput == null) return;
        String rendered;
        if (azInputMode == 0 || azInputMode == 2) rendered = formatDms(normalize(value));
        else rendered = rumbo(normalize(value));
        azInput.setText(rendered);
        azInput.setSelection(azInput.getText().length());
        activeAngleInput = azInput;
    }

    private void offsetCurrentAzimuth(double delta) {
        if (azInput == null) return;
        double base;
        String raw = azInput.getText().toString().trim();
        if (raw.isEmpty()) {
            base = 0;
        } else {
            try {
                if (azInputMode == 0) base = normalize(parseAngle(raw));
                else if (azInputMode == 1) base = normalize(parseRumbo(raw));
                else if (azInputMode == 2) base = normalize(parseAngle(raw));
                else base = normalize(parseRumbo(raw));
            } catch (Exception e) {
                base = 0;
            }
        }
        applyAzimuthPreset(normalize(base + delta));
    }

    private LinearLayout angleShortcutBar() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.HORIZONTAL);
        wrap.setPadding(0, dp(2), 0, dp(6));
        String[] keys = {"°", "'", "\"", "00'", "00\"", "⌫"};
        for (String k : keys) {
            Button b = new Button(this);
            b.setText(k);
            b.setAllCaps(false);
            b.setTextColor(Color.WHITE);
            b.setTypeface(Typeface.DEFAULT_BOLD);
            b.setTextSize(13);
            b.setMinWidth(0);
            b.setMinimumWidth(0);
            b.setPadding(dp(2), dp(6), dp(2), dp(6));
            b.setHeight(dp(46));
            GradientDrawable gd = new GradientDrawable(
                    GradientDrawable.Orientation.LEFT_RIGHT,
                    themeMode == THEME_LIGHT
                            ? new int[]{Color.rgb(246, 250, 255), Color.rgb(238, 245, 255)}
                            : new int[]{Color.rgb(8, 25, 42), Color.rgb(5, 18, 31)});
            gd.setCornerRadius(dp(12));
            gd.setStroke(dp(1), withAlpha(borderColor, 160));
            b.setBackground(gd);
            if (themeMode == THEME_LIGHT) b.setTextColor(darken(borderColor, 0.80f));
            b.setOnClickListener(v -> {
                if ("⌫".equals(k)) deleteFromAngleInput();
                else insertIntoAngleInput(k);
            });
            wrap.addView(b, weightParams());
        }
        return wrap;
    }

    private void insertIntoAngleInput(String text) {
        EditText target = activeAngleInput;
        if (target == null) target = azInput;
        if (target == null) return;
        target.requestFocus();
        int start = Math.max(0, target.getSelectionStart());
        int end = Math.max(0, target.getSelectionEnd());
        if (end < start) { int tmp = start; start = end; end = tmp; }
        target.getText().replace(start, end, text);
        target.setSelection(start + text.length());
    }

    private void deleteFromAngleInput() {
        EditText target = activeAngleInput;
        if (target == null) target = azInput;
        if (target == null) return;
        target.requestFocus();
        int start = Math.max(0, target.getSelectionStart());
        int end = Math.max(0, target.getSelectionEnd());
        if (end > start) {
            target.getText().delete(start, end);
            target.setSelection(start);
        } else if (start > 0) {
            target.getText().delete(start - 1, start);
            target.setSelection(start - 1);
        }
    }

    private EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextColor(textColor);
        e.setHintTextColor(withAlpha(subTextColor, 190));
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        e.setPadding(dp(13), dp(10), dp(13), dp(10));
        e.setMinHeight(dp(54));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(7), 0, dp(7));
        e.setLayoutParams(lp);
        e.setBackground(inputBg(false));
        return e;
    }

    private Button btn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setPadding(dp(6), dp(8), dp(6), dp(8));
        b.setGravity(Gravity.CENTER);
        b.setMaxLines(2);
        b.setHeight(dp(52));
        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{borderColor, darken(borderColor, 0.70f)});
        gd.setCornerRadius(dp(13));
        gd.setStroke(dp(1), withAlpha(Color.WHITE, 55));
        b.setBackground(gd);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) b.setElevation(dp(2));
        return b;
    }

    private TextView resultBox(String text) {
        TextView v = tv(text, 15, false);
        v.setPadding(dp(12), dp(11), dp(12), dp(11));
        v.setBackground(inputBg(true));
        v.setLineSpacing(0, 1.13f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(9), 0, 0);
        v.setLayoutParams(lp);
        return v;
    }

    private GradientDrawable inputBg(boolean result) {
        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                result
                        ? (themeMode == THEME_LIGHT
                            ? new int[]{Color.rgb(242, 252, 247), Color.rgb(234, 248, 242)}
                            : new int[]{Color.rgb(8, 54, 43), Color.rgb(5, 39, 34)})
                        : (themeMode == THEME_LIGHT
                            ? new int[]{Color.WHITE, Color.rgb(248, 250, 253)}
                            : new int[]{Color.rgb(8, 31, 50), Color.rgb(6, 25, 42)}));
        gd.setCornerRadius(dp(11));
        gd.setStroke(dp(1), result ? resultStrokeColor : withAlpha(inputStrokeColor, 200));
        return gd;
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), dp(4), dp(3), dp(4));
        return lp;
    }

    private SpannableStringBuilder buildPolyProcedureHeader() {
        SpannableStringBuilder sb = new SpannableStringBuilder();
        appendColored(sb, "PROCEDIMIENTO SIMPLE DE POLIGONAL\n", borderColor);
        appendPlain(sb, "Datos que tú llenas: estación, P.V., azimut y distancia.\n");
        appendPlain(sb, "La app hace 4 pasos:\n");
        appendPlain(sb, "1) Convierte el azimut a rumbo.\n");
        appendPlain(sb, "2) Del rumbo toma solo el ángulo interior. Ejemplo: N 33°30' W → se usa 33°30'.\n");
        appendPlain(sb, "3) La letra final E/W usa ");
        appendColored(sb, "seno", Color.rgb(255, 171, 0));
        appendPlain(sb, ":  E/W = Distancia × seno(ángulo del rumbo).\n");
        appendPlain(sb, "4) La letra inicial N/S usa ");
        appendColored(sb, "coseno", Color.rgb(0, 184, 148));
        appendPlain(sb, ":  N/S = Distancia × coseno(ángulo del rumbo).\n");
        appendPlain(sb, "5) Después reparte el error con Bowditch y saca X/Y acumuladas.\n\n");
        return sb;
    }

    private void appendProcedureRow(SpannableStringBuilder sb, String label, double az, double distance, double dx, double dy,
                                    double corrX, double corrY, double cdx, double cdy, double x, double y, int index) {
        appendColored(sb, "Lado " + index + ": " + label + "\n", Color.rgb(41, 121, 255));
        appendPlain(sb, "Azimut: ");
        appendColored(sb, formatDms(az), Color.rgb(41, 121, 255));
        appendPlain(sb, "   Rumbo: ");
        appendColored(sb, rumbo(az), Color.rgb(194, 170, 120));
        appendPlain(sb, "\nDistancia: ");
        appendColored(sb, f3(distance), Color.rgb(41, 121, 255));
        appendPlain(sb, "\nΔE/ΔW = ");
        appendColored(sb, f3(distance), Color.rgb(41, 121, 255));
        appendPlain(sb, " × ");
        appendColored(sb, "sen(" + formatDms(az) + ")", Color.rgb(255, 171, 0));
        appendPlain(sb, " = ");
        appendColored(sb, f3(Math.abs(dx)), dx >= 0 ? Color.rgb(0, 184, 148) : Color.rgb(231, 76, 60));
        appendPlain(sb, dx >= 0 ? "  → E\n" : "  → W\n");
        appendPlain(sb, "ΔN/ΔS = ");
        appendColored(sb, f3(distance), Color.rgb(41, 121, 255));
        appendPlain(sb, " × ");
        appendColored(sb, "cos(" + formatDms(az) + ")", Color.rgb(0, 184, 148));
        appendPlain(sb, " = ");
        appendColored(sb, f3(Math.abs(dy)), dy >= 0 ? Color.rgb(0, 184, 148) : Color.rgb(231, 76, 60));
        appendPlain(sb, dy >= 0 ? "  → N\n" : "  → S\n");
        appendPlain(sb, "Corrección X: ");
        appendColored(sb, f3(corrX), Color.rgb(142, 68, 173));
        appendPlain(sb, "   Corrección Y: ");
        appendColored(sb, f3(corrY), Color.rgb(142, 68, 173));
        appendPlain(sb, "\nE/W corregida: ");
        appendColored(sb, f3(Math.abs(cdx)), cdx >= 0 ? Color.rgb(0, 184, 148) : Color.rgb(231, 76, 60));
        appendPlain(sb, cdx >= 0 ? "  → E" : "  → W");
        appendPlain(sb, "   N/S corregida: ");
        appendColored(sb, f3(Math.abs(cdy)), cdy >= 0 ? Color.rgb(0, 184, 148) : Color.rgb(231, 76, 60));
        appendPlain(sb, cdy >= 0 ? "  → N\n" : "  → S\n");
        appendPlain(sb, "X = ");
        appendColored(sb, f3(x), Color.rgb(41, 121, 255));
        appendPlain(sb, "   Y = ");
        appendColored(sb, f3(y), Color.rgb(41, 121, 255));
        appendPlain(sb, "\n\n");
    }

    private void appendPartialProcedureRow(SpannableStringBuilder sb, String label, double az, double distance, double dx, double dy, int index) {
        String rb = rumbo(az);
        double rbAngle = rumboAngle(az);
        String ew = dx >= 0 ? "E" : "W";
        String ns = dy >= 0 ? "N" : "S";
        appendColored(sb, "Fila " + index + ": " + label + "\n", Color.rgb(41, 121, 255));
        appendPlain(sb, "Dato escrito: azimut + distancia.\n");
        appendPlain(sb, "Azimut: ");
        appendColored(sb, formatDms(az), Color.rgb(41, 121, 255));
        appendPlain(sb, "  →  Rumbo: ");
        appendColored(sb, rb, Color.rgb(194, 170, 120));
        appendPlain(sb, "\nDistancia: ");
        appendColored(sb, f3(distance), Color.rgb(41, 121, 255));
        appendPlain(sb, "\nÁngulo útil del rumbo: ");
        appendColored(sb, formatDms(rbAngle), Color.rgb(41, 121, 255));
        appendPlain(sb, "  (sale del rumbo, no del azimut completo)");
        appendPlain(sb, "\nComo el rumbo termina en ");
        appendColored(sb, ew, Color.rgb(255, 171, 0));
        appendPlain(sb, ", se usa SENO:\n");
        appendColored(sb, ew + " = " + f3(distance) + " × sen(" + formatDms(rbAngle) + ") = " + f3(Math.abs(dx)), Color.rgb(255, 171, 0));
        appendPlain(sb, "\nComo el rumbo empieza en ");
        appendColored(sb, ns, Color.rgb(0, 184, 148));
        appendPlain(sb, ", se usa COSENO:\n");
        appendColored(sb, ns + " = " + f3(distance) + " × cos(" + formatDms(rbAngle) + ") = " + f3(Math.abs(dy)), Color.rgb(0, 184, 148));
        appendPlain(sb, "\nEntonces en la tabla va: ");
        appendColored(sb, ew + " = " + f3(Math.abs(dx)), Color.rgb(255, 171, 0));
        appendPlain(sb, " y ");
        appendColored(sb, ns + " = " + f3(Math.abs(dy)), Color.rgb(0, 184, 148));
        appendPlain(sb, "\n\n");
    }

    private void appendCorrectionProcedureRow(SpannableStringBuilder sb, String label,
                                             double corrX, double corrY, double cdx, double cdy, double x, double y) {
        appendColored(sb, "Corrección " + label + "\n", Color.rgb(142, 68, 173));
        appendPlain(sb, "Cx: ");
        appendColored(sb, f3(corrX), Color.rgb(142, 68, 173));
        appendPlain(sb, "   Cy: ");
        appendColored(sb, f3(corrY), Color.rgb(142, 68, 173));
        appendPlain(sb, "\nE/W corregida: ");
        appendColored(sb, f3(Math.abs(cdx)), Color.rgb(255, 171, 0));
        appendPlain(sb, cdx >= 0 ? " → E" : " → W");
        appendPlain(sb, "   N/S corregida: ");
        appendColored(sb, f3(Math.abs(cdy)), Color.rgb(0, 184, 148));
        appendPlain(sb, cdy >= 0 ? " → N" : " → S");
        appendPlain(sb, "\nX: ");
        appendColored(sb, f3(x), Color.rgb(41, 121, 255));
        appendPlain(sb, "   Y: ");
        appendColored(sb, f3(y), Color.rgb(41, 121, 255));
        appendPlain(sb, "\n\n");
    }

    private void appendProcedureSummary(SpannableStringBuilder sb, double sumDx, double sumDy, double perimeter, double closeError) {
        appendColored(sb, "RESUMEN FINAL\n", borderColor);
        appendPlain(sb, "Σ parciales X: ");
        appendColored(sb, f3(sumDx), Color.rgb(142, 68, 173));
        appendPlain(sb, "\nΣ parciales Y: ");
        appendColored(sb, f3(sumDy), Color.rgb(142, 68, 173));
        appendPlain(sb, "\nPerímetro: ");
        appendColored(sb, f3(perimeter), Color.rgb(41, 121, 255));
        appendPlain(sb, "\nError de cierre: ");
        appendColored(sb, f3(closeError), Color.rgb(231, 76, 60));
    }

    private void appendPlain(SpannableStringBuilder sb, String text) {
        sb.append(text);
    }

    private void appendColored(SpannableStringBuilder sb, String text, int color) {
        int start = sb.length();
        sb.append(text);
        sb.setSpan(new ForegroundColorSpan(color), start, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private void showProcedureDialog(String title, CharSequence content) {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.WHITE);
        TextView tv = new TextView(this);
        tv.setText(content);
        tv.setTextColor(Color.rgb(30, 33, 40));
        tv.setTextSize(13);
        tv.setLineSpacing(0, 1.08f);
        tv.setPadding(dp(12), dp(12), dp(12), dp(12));
        scroll.addView(tv);
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(scroll)
                .setPositiveButton("Cerrar", null)
                .show();
    }

    private void showPolyGraphDialog() {
        ArrayList<GraphPoint> points = buildPolyGraphPoints();
        if (points.size() < 2) {
            showError("Primero calcula la poligonal cerrada para generar el gráfico.");
            return;
        }

        final AlertDialog[] dialogRef = new AlertDialog[1];
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(14), dp(14), dp(12));
        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setColor(themeMode == THEME_LIGHT ? Color.WHITE : Color.rgb(10, 24, 39));
        panelBg.setCornerRadius(dp(18));
        panelBg.setStroke(dp(1), themeMode == THEME_LIGHT ? Color.rgb(210, 218, 230) : Color.rgb(58, 76, 100));
        panel.setBackground(panelBg);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);

        TextView icon = new TextView(this);
        icon.setText("⌁");
        icon.setGravity(Gravity.CENTER);
        icon.setTextSize(24);
        icon.setTextColor(Color.WHITE);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setColor(borderColor);
        iconBg.setCornerRadius(dp(10));
        icon.setBackground(iconBg);
        head.addView(icon, new LinearLayout.LayoutParams(dp(46), dp(46)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(10), 0, 0, 0);
        TextView title = new TextView(this);
        title.setText("Gráfico de poligonal");
        title.setTextColor(textColor);
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        texts.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Croquis con cuadrícula, puntos y brújula norte.");
        subtitle.setTextColor(subTextColor);
        subtitle.setTextSize(13);
        texts.addView(subtitle);
        head.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView close = new TextView(this);
        close.setText("×");
        close.setGravity(Gravity.CENTER);
        close.setTextColor(subTextColor);
        close.setTextSize(30);
        close.setOnClickListener(v -> { if (dialogRef[0] != null) dialogRef[0].dismiss(); });
        head.addView(close, new LinearLayout.LayoutParams(dp(44), dp(44)));
        panel.addView(head);

        TextView hint = small("Sale de las coordenadas X/Y calculadas. La brújula es referencia de orientación.");
        hint.setPadding(0, dp(10), 0, dp(4));
        panel.addView(hint);

        LinearLayout legend = new LinearLayout(this);
        legend.setOrientation(LinearLayout.HORIZONTAL);
        legend.setGravity(Gravity.CENTER_VERTICAL);
        legend.addView(legendItem("━", "Poligonal", Color.rgb(41, 121, 255)));
        legend.addView(legendItem("●", "Vértice", textColor));
        legend.addView(legendItem("✥", "Brújula", textColor));
        panel.addView(legend);

        PolyGraphView graph = new PolyGraphView(this, points);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(560));
        gp.setMargins(0, dp(8), 0, dp(8));
        panel.addView(graph, gp);

        TextView info = resultBox("ⓘ El croquis no está a escala exacta. Sirve para revisar la forma y verificar las coordenadas en la tabla.");
        info.setTextSize(12);
        panel.addView(info);

        Button closeBtn = btn("Cerrar ✓");
        closeBtn.setOnClickListener(v -> { if (dialogRef[0] != null) dialogRef[0].dismiss(); });
        panel.addView(closeBtn);

        ScrollView graphScroll = new ScrollView(this);
        graphScroll.addView(panel);
        AlertDialog dialog = new AlertDialog.Builder(this).setView(graphScroll).create();
        dialogRef[0] = dialog;
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            }
        });
        dialog.show();
    }

    private View legendItem(String symbol, String text, int color) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.HORIZONTAL);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(0, 0, dp(14), 0);
        TextView s = new TextView(this);
        s.setText(symbol);
        s.setTextColor(color);
        s.setTextSize(18);
        s.setTypeface(Typeface.DEFAULT_BOLD);
        item.addView(s);
        TextView t = new TextView(this);
        t.setText("  " + text);
        t.setTextColor(subTextColor);
        t.setTextSize(12);
        item.addView(t);
        return item;
    }

    private ArrayList<GraphPoint> buildPolyGraphPoints() {
        ArrayList<GraphPoint> points = new ArrayList<>();
        double startX = optNumber(polyX0Input.getText().toString()) != null ? optNumber(polyX0Input.getText().toString()) : 0;
        double startY = optNumber(polyY0Input.getText().toString()) != null ? optNumber(polyY0Input.getText().toString()) : 0;
        String startLabel = "Inicio";
        for (TableDataRow r : tableRows) {
            String est = r.est.getText().toString().trim();
            String pv = r.pv.getText().toString().trim();
            String dist = r.dist.getText().toString().trim();
            if (!est.isEmpty() && !pv.isEmpty() && !dist.isEmpty()) {
                startLabel = est.toUpperCase(Locale.US);
                break;
            }
        }
        points.add(new GraphPoint(startLabel, startX, startY));
        for (int i = 0; i < tableRows.size(); i++) {
            TableDataRow row = tableRows.get(i);
            Double x = optNumber(row.x.getText().toString());
            Double y = optNumber(row.y.getText().toString());
            if (x == null || y == null) continue;
            String label = row.pv.getText().toString().trim();
            if (label.isEmpty()) label = String.valueOf(i + 1);
            label = label.toUpperCase(Locale.US);
            points.add(new GraphPoint(label, x, y));
        }
        return points;
    }

    private LinearLayout tableColorBar() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.HORIZONTAL);
        Button text = btn("Texto");
        text.setTextSize(12);
        text.setOnClickListener(v -> applyManualTextColor());
        wrap.addView(text, weightParams());
        Button bg = btn("Fondo");
        bg.setTextSize(12);
        bg.setOnClickListener(v -> applyManualBgColor(false, false));
        wrap.addView(bg, weightParams());
        Button row = btn("Fila");
        row.setTextSize(12);
        row.setOnClickListener(v -> applyManualBgColor(true, false));
        wrap.addView(row, weightParams());
        Button col = btn("Col.");
        col.setTextSize(12);
        col.setOnClickListener(v -> applyManualBgColor(false, true));
        wrap.addView(col, weightParams());
        Button reset = btn("Normal");
        reset.setTextSize(12);
        reset.setOnClickListener(v -> resetCoordTableColors());
        wrap.addView(reset, weightParams());
        return wrap;
    }

    private void registerColorCell(View cell, TableLayout table, int row, int col) {
        cell.setOnClickListener(v -> {
            selectColorCell(v, table, row, col);
            if (v instanceof EditText && col == 2) activeAngleInput = (EditText) v;
            if (v instanceof EditText && col == 3) selectedDistCell = (EditText) v;
        });
        cell.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                selectColorCell(v, table, row, col);
                if (v instanceof EditText && col == 2) activeAngleInput = (EditText) v;
                if (v instanceof EditText && col == 3) selectedDistCell = (EditText) v;
            }
        });
    }

    private void selectColorCell(View cell, TableLayout table, int row, int col) {
        selectedColorCell = cell;
        selectedColorTable = table;
        selectedColorRow = row;
        selectedColorCol = col;
    }

    private void applyManualTextColor() {
        if (selectedColorCell == null) {
            Toast.makeText(this, "Primero toca una celda de la tabla", Toast.LENGTH_SHORT).show();
            return;
        }
        manualTextColorIndex = (manualTextColorIndex + 1) % manualTextColors.length;
        if (selectedColorCell instanceof TextView) {
            ((TextView) selectedColorCell).setTextColor(manualTextColors[manualTextColorIndex]);
        }
    }

    private void applyManualBgColor(boolean wholeRow, boolean wholeColumn) {
        if (selectedColorCell == null || selectedColorTable == null) {
            Toast.makeText(this, "Primero toca una celda de la tabla", Toast.LENGTH_SHORT).show();
            return;
        }
        manualBgColorIndex = (manualBgColorIndex + 1) % manualBgColors.length;
        int color = manualBgColors[manualBgColorIndex];
        if (wholeRow) {
            TableRow row = (TableRow) selectedColorTable.getChildAt(selectedColorRow);
            for (int c = 0; c < row.getChildCount(); c++) setCellManualBg(row.getChildAt(c), color);
        } else if (wholeColumn) {
            for (int r = 1; r < selectedColorTable.getChildCount(); r++) {
                View rv = selectedColorTable.getChildAt(r);
                if (rv instanceof TableRow) {
                    TableRow tr = (TableRow) rv;
                    if (selectedColorCol >= 0 && selectedColorCol < tr.getChildCount()) setCellManualBg(tr.getChildAt(selectedColorCol), color);
                }
            }
        } else {
            setCellManualBg(selectedColorCell, color);
        }
    }

    private void setCellManualBg(View cell, int color) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setStroke(1, tableLineColor);
        cell.setBackground(gd);
    }

    private void resetCoordTableColors() {
        if (coordTable == null) return;
        for (int r = 1; r < coordTable.getChildCount(); r++) {
            View rv = coordTable.getChildAt(r);
            if (!(rv instanceof TableRow)) continue;
            TableRow tr = (TableRow) rv;
            for (int c = 0; c < tr.getChildCount(); c++) {
                View cell = tr.getChildAt(c);
                boolean locked = !(cell instanceof EditText);
                cell.setBackground(cellBg(locked));
                if (cell instanceof TextView) ((TextView) cell).setTextColor(textColor);
            }
        }
        for (TableDataRow row : tableRows) applyDefaultPolyColors(row);
    }

    private void applyDefaultPolyColors(TableDataRow row) {
        row.este.setTextColor(sinColor);
        row.oeste.setTextColor(sinColor);
        row.eCorr.setTextColor(sinColor);
        row.wCorr.setTextColor(sinColor);
        row.norte.setTextColor(cosColor);
        row.sur.setTextColor(cosColor);
        row.nCorr.setTextColor(cosColor);
        row.sCorr.setTextColor(cosColor);
    }

    private TableRow headerRowCompact(String... headers) {
        TableRow tr = new TableRow(this);
        for (String h : headers) {
            TextView v = cellTextCompact(h);
            v.setTypeface(Typeface.DEFAULT_BOLD);
            v.setBackgroundColor(borderColor);
            v.setTextColor(Color.WHITE);
            tr.addView(v);
        }
        return tr;
    }

    private EditText cellEditCompact(String text, boolean number) {
        EditText e = new EditText(this);
        e.setText(text);
        e.setTextColor(textColor);
        e.setHintTextColor(subTextColor);
        e.setTextSize(12);
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER);
        e.setPadding(dp(4), dp(2), dp(4), dp(2));
        e.setMinWidth(dp(54));
        e.setBackground(cellBg(false));
        e.setInputType(number ? (InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED) : InputType.TYPE_CLASS_TEXT);
        return e;
    }

    private TextView cellTextCompact(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(textColor);
        v.setTextSize(12);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(4), dp(6), dp(4), dp(6));
        v.setMinWidth(dp(54));
        v.setBackground(cellBg(true));
        return v;
    }

    private TableRow headerSpanRow(String[] headers, int[] spans) {
        TableRow tr = new TableRow(this);
        for (int i = 0; i < headers.length; i++) {
            TextView v = cellText(headers[i]);
            v.setTypeface(Typeface.DEFAULT_BOLD);
            v.setBackgroundColor(borderColor);
            v.setTextColor(Color.WHITE);
            v.setMinWidth(dp(96 * spans[i]));
            tr.addView(v);
        }
        return tr;
    }

    private TableRow headerRow(String... headers) {
        TableRow tr = new TableRow(this);
        for (String h : headers) {
            TextView v = cellText(h);
            v.setTypeface(Typeface.DEFAULT_BOLD);
            v.setBackgroundColor(borderColor);
            v.setTextColor(Color.WHITE);
            tr.addView(v);
        }
        return tr;
    }

    private EditText cellEdit(String text, boolean number) {
        EditText e = new EditText(this);
        e.setText(text);
        e.setTextColor(textColor);
        e.setHintTextColor(subTextColor);
        e.setTextSize(13);
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER);
        e.setPadding(dp(6), dp(3), dp(6), dp(3));
        e.setMinWidth(dp(96));
        e.setBackground(cellBg(false));
        e.setInputType(number ? (InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED) : InputType.TYPE_CLASS_TEXT);
        return e;
    }

    private TextView cellText(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(textColor);
        v.setTextSize(13);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(6), dp(7), dp(6), dp(7));
        v.setMinWidth(dp(96));
        v.setBackground(cellBg(true));
        return v;
    }

    private GradientDrawable cellBg(boolean locked) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(locked ? cellLockedColor : cellEditColor);
        gd.setStroke(1, tableLineColor);
        return gd;
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }

    private static class CoordinateResult {
        double sen;
        double cos;
        double dx;
        double dy;
        double este;
        double oeste;
        double norte;
        double sur;
    }

    private interface ColorPickListener {
        void onPick(int index);
    }

    private static final class SectionState {
        final LinearLayout body;
        final TextView arrow;

        SectionState(LinearLayout body, TextView arrow) {
            this.body = body;
            this.arrow = arrow;
        }
    }

    private static class TableDataRow {
        EditText est;
        EditText pv;
        EditText az;
        EditText dist;
        TextView rumbo;
        TextView sen;
        TextView cos;
        TextView este;
        TextView oeste;
        TextView norte;
        TextView sur;
        TextView eCorr;
        TextView wCorr;
        TextView nCorr;
        TextView sCorr;
        TextView x;
        TextView y;
    }

    private static class LevelDataRow {
        EditText pv;
        EditText vAtras;
        EditText vIntermedia;
        EditText vAdelante;
        EditText cotaTerreno;
        TextView cotaNivel;
    }

    private static class StadiaLevelRow {
        EditText pv;
        EditText tipo;
        EditText hInf;
        EditText hMedio;
        EditText hSup;
        TextView distancia;
        EditText cotaTerreno;
        TextView cotaNivel;
    }

    private static class GraphPoint {
        String label;
        double x;
        double y;

        GraphPoint(String label, double x, double y) {
            this.label = label;
            this.x = x;
            this.y = y;
        }
    }

    public static class ZoomLayout extends FrameLayout {
        private final ScaleGestureDetector detector;
        private float scale = 1.0f;

        public ZoomLayout(Context context) {
            super(context);
            detector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScale(ScaleGestureDetector d) {
                    scale *= d.getScaleFactor();
                    scale = Math.max(0.80f, Math.min(scale, 3.00f));
                    setScaleX(scale);
                    setScaleY(scale);
                    setPivotX(0);
                    setPivotY(0);
                    return true;
                }
            });
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            detector.onTouchEvent(event);
            return true;
        }

        @Override
        public boolean dispatchTouchEvent(MotionEvent ev) {
            detector.onTouchEvent(ev);
            return super.dispatchTouchEvent(ev);
        }

        public void resetZoom() {
            scale = 1.0f;
            setScaleX(scale);
            setScaleY(scale);
        }
    }


    public class PolyGraphView extends View {
        private final List<GraphPoint> points;
        private final Paint plotBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint minorGridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint majorGridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint framePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint lineGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pointPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pointStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint compassPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint compassWhitePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint compassStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        public PolyGraphView(Context context, List<GraphPoint> points) {
            super(context);
            this.points = points;

            plotBgPaint.setColor(Color.rgb(250, 252, 255));
            plotBgPaint.setStyle(Paint.Style.FILL);

            minorGridPaint.setColor(Color.rgb(232, 238, 246));
            minorGridPaint.setStrokeWidth(dp(1));

            majorGridPaint.setColor(Color.rgb(190, 207, 230));
            majorGridPaint.setStrokeWidth(dp(1));

            framePaint.setColor(Color.rgb(98, 120, 146));
            framePaint.setStyle(Paint.Style.STROKE);
            framePaint.setStrokeWidth(dp(1));

            lineGlowPaint.setColor(Color.rgb(122, 176, 255));
            lineGlowPaint.setStrokeWidth(dp(9));
            lineGlowPaint.setStyle(Paint.Style.STROKE);
            lineGlowPaint.setStrokeCap(Paint.Cap.ROUND);
            lineGlowPaint.setStrokeJoin(Paint.Join.ROUND);
            lineGlowPaint.setAlpha(75);

            linePaint.setColor(Color.rgb(41, 121, 255));
            linePaint.setStrokeWidth(dp(5));
            linePaint.setStyle(Paint.Style.STROKE);
            linePaint.setStrokeCap(Paint.Cap.ROUND);
            linePaint.setStrokeJoin(Paint.Join.ROUND);

            pointPaint.setColor(Color.rgb(18, 20, 24));
            pointPaint.setStyle(Paint.Style.FILL);

            pointStrokePaint.setColor(Color.WHITE);
            pointStrokePaint.setStyle(Paint.Style.STROKE);
            pointStrokePaint.setStrokeWidth(dp(2));

            labelPaint.setColor(Color.rgb(18, 20, 24));
            labelPaint.setTextSize(dp(16));
            labelPaint.setTypeface(Typeface.DEFAULT_BOLD);

            compassPaint.setColor(Color.rgb(18, 20, 24));
            compassPaint.setStyle(Paint.Style.FILL);
            compassWhitePaint.setColor(Color.WHITE);
            compassWhitePaint.setStyle(Paint.Style.FILL);
            compassStrokePaint.setColor(Color.rgb(18, 20, 24));
            compassStrokePaint.setStyle(Paint.Style.STROKE);
            compassStrokePaint.setStrokeWidth(dp(1));
            compassStrokePaint.setTextSize(dp(12));
            compassStrokePaint.setTypeface(Typeface.DEFAULT_BOLD);
            compassStrokePaint.setTextAlign(Paint.Align.CENTER);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();

            float left = dp(8);
            float top = dp(8);
            float right = w - dp(8);
            float bottom = h - dp(8);
            canvas.drawRoundRect(left, top, right, bottom, dp(12), dp(12), plotBgPaint);

            float plotLeft = left + dp(18);
            float plotTop = top + dp(18);
            float plotRight = right - dp(18);
            float plotBottom = bottom - dp(18);

            for (int i = 0; i <= 24; i++) {
                float x = plotLeft + (plotRight - plotLeft) * i / 24f;
                float y = plotTop + (plotBottom - plotTop) * i / 24f;
                canvas.drawLine(x, plotTop, x, plotBottom, (i % 4 == 0) ? majorGridPaint : minorGridPaint);
                canvas.drawLine(plotLeft, y, plotRight, y, (i % 4 == 0) ? majorGridPaint : minorGridPaint);
            }

            double minX = Double.POSITIVE_INFINITY, maxX = Double.NEGATIVE_INFINITY;
            double minY = Double.POSITIVE_INFINITY, maxY = Double.NEGATIVE_INFINITY;
            for (GraphPoint p : points) {
                minX = Math.min(minX, p.x);
                maxX = Math.max(maxX, p.x);
                minY = Math.min(minY, p.y);
                maxY = Math.max(maxY, p.y);
            }
            if (!Double.isFinite(minX) || !Double.isFinite(minY)) return;
            double spanX = Math.max(1.0, maxX - minX);
            double spanY = Math.max(1.0, maxY - minY);
            minX -= spanX * 0.16;
            maxX += spanX * 0.16;
            minY -= spanY * 0.16;
            maxY += spanY * 0.16;
            spanX = Math.max(1.0, maxX - minX);
            spanY = Math.max(1.0, maxY - minY);
            double scaleX = (plotRight - plotLeft) / spanX;
            double scaleY = (plotBottom - plotTop) / spanY;

            Path poly = new Path();
            for (int i = 0; i < points.size(); i++) {
                GraphPoint p = points.get(i);
                float px = (float) (plotLeft + (p.x - minX) * scaleX);
                float py = (float) (plotBottom - (p.y - minY) * scaleY);
                if (i == 0) poly.moveTo(px, py); else poly.lineTo(px, py);
            }
            canvas.drawPath(poly, lineGlowPaint);
            canvas.drawPath(poly, linePaint);

            for (GraphPoint p : points) {
                float px = (float) (plotLeft + (p.x - minX) * scaleX);
                float py = (float) (plotBottom - (p.y - minY) * scaleY);
                canvas.drawCircle(px, py, dp(7), pointPaint);
                canvas.drawCircle(px, py, dp(7), pointStrokePaint);
                canvas.drawText(p.label, px + dp(10), py - dp(10), labelPaint);
            }

            drawCompassRose(canvas, right - dp(72), top + dp(76), dp(50));
            canvas.drawRoundRect(left, top, right, bottom, dp(12), dp(12), framePaint);
        }

        private void drawCompassRose(Canvas canvas, float cx, float cy, float r) {
            canvas.drawCircle(cx, cy, r, compassStrokePaint);
            canvas.drawCircle(cx, cy, r * 0.70f, compassStrokePaint);
            for (int i = 0; i < 16; i++) {
                double a = Math.toRadians(i * 22.5 - 90);
                float len = (i % 2 == 0) ? r * 0.92f : r * 0.62f;
                float x = (float) (cx + Math.cos(a) * len);
                float y = (float) (cy + Math.sin(a) * len);
                canvas.drawLine(cx, cy, x, y, compassStrokePaint);
            }
            for (int i = 0; i < 8; i++) {
                double a = Math.toRadians(i * 45 - 90);
                double leftA = a - Math.toRadians(10);
                double rightA = a + Math.toRadians(10);
                float tipR = (i % 2 == 0) ? r * 0.86f : r * 0.58f;
                float baseR = r * 0.13f;
                Path path = new Path();
                path.moveTo((float) (cx + Math.cos(a) * tipR), (float) (cy + Math.sin(a) * tipR));
                path.lineTo((float) (cx + Math.cos(leftA) * baseR), (float) (cy + Math.sin(leftA) * baseR));
                path.lineTo((float) (cx + Math.cos(rightA) * baseR), (float) (cy + Math.sin(rightA) * baseR));
                path.close();
                canvas.drawPath(path, (i % 2 == 0) ? compassPaint : compassWhitePaint);
                canvas.drawPath(path, compassStrokePaint);
            }
            compassStrokePaint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("N", cx, cy - r - dp(4), compassStrokePaint);
            canvas.drawText("S", cx, cy + r + dp(12), compassStrokePaint);
            canvas.drawText("E", cx + r + dp(11), cy + dp(4), compassStrokePaint);
            canvas.drawText("W", cx - r - dp(11), cy + dp(4), compassStrokePaint);
        }
    }

    public class PolyPreviewView extends View {
        private final ArrayList<Double> xs = new ArrayList<>();
        private final ArrayList<Double> ys = new ArrayList<>();

        public PolyPreviewView(Context context) { super(context); }

        public void updateFromDeltas(List<Double> dxs, List<Double> dys) {
            xs.clear(); ys.clear();
            double x = 0, y = 0;
            xs.add(x); ys.add(y);
            int n = Math.min(dxs == null ? 0 : dxs.size(), dys == null ? 0 : dys.size());
            for (int i = 0; i < n; i++) {
                x += dxs.get(i);
                y += dys.get(i);
                xs.add(x); ys.add(y);
            }
            invalidate();
        }

        public void updateFromCoordinates(List<Double> xValues, List<Double> yValues) {
            xs.clear(); ys.clear();
            if (xValues != null) xs.addAll(xValues);
            if (yValues != null) ys.addAll(yValues);
            invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth(), h = getHeight();
            Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
            grid.setColor(themeMode == THEME_LIGHT ? Color.argb(45, 60, 100, 140) : Color.argb(45, 130, 170, 210));
            grid.setStrokeWidth(dp(1));
            for (int i=1;i<6;i++) {
                float x=w*i/6f, y=h*i/6f;
                canvas.drawLine(x, dp(12), x, h-dp(18), grid);
                canvas.drawLine(dp(12), y, w-dp(12), y, grid);
            }
            if (xs.size() < 2 || xs.size() != ys.size()) {
                Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
                t.setColor(subTextColor); t.setTextAlign(Paint.Align.CENTER); t.setTextSize(dp(11));
                canvas.drawText("Calcula la poligonal para ver el croquis", w/2f, h/2f, t);
                return;
            }
            double minX=xs.get(0), maxX=minX, minY=ys.get(0), maxY=minY;
            for (int i=1;i<xs.size();i++) { minX=Math.min(minX,xs.get(i)); maxX=Math.max(maxX,xs.get(i)); minY=Math.min(minY,ys.get(i)); maxY=Math.max(maxY,ys.get(i)); }
            double spanX=Math.max(1e-6,maxX-minX), spanY=Math.max(1e-6,maxY-minY);
            float pad=dp(26), availW=w-2*pad, availH=h-2*pad;
            float scale=(float)Math.min(availW/spanX, availH/spanY);
            float usedW=(float)(spanX*scale), usedH=(float)(spanY*scale);
            float ox=(w-usedW)/2f, oy=(h-usedH)/2f;
            Paint line=new Paint(Paint.ANTI_ALIAS_FLAG); line.setColor(borderColor); line.setStrokeWidth(dp(2)); line.setStyle(Paint.Style.STROKE);
            Path path=new Path();
            for (int i=0;i<xs.size();i++) {
                float px=ox+(float)((xs.get(i)-minX)*scale);
                float py=h-(oy+(float)((ys.get(i)-minY)*scale));
                if(i==0) path.moveTo(px,py); else path.lineTo(px,py);
            }
            canvas.drawPath(path,line);
            Paint pt=new Paint(Paint.ANTI_ALIAS_FLAG); pt.setColor(Color.rgb(70,145,255)); pt.setStyle(Paint.Style.FILL);
            Paint label=new Paint(Paint.ANTI_ALIAS_FLAG); label.setColor(textColor); label.setTextAlign(Paint.Align.CENTER); label.setTextSize(dp(9)); label.setTypeface(Typeface.DEFAULT_BOLD);
            for(int i=0;i<xs.size();i++) {
                float px=ox+(float)((xs.get(i)-minX)*scale);
                float py=h-(oy+(float)((ys.get(i)-minY)*scale));
                canvas.drawCircle(px,py,dp(5),pt);
                canvas.drawText(i==0?"A":String.valueOf(i+1),px,py-dp(8),label);
            }
            Paint north=new Paint(Paint.ANTI_ALIAS_FLAG); north.setColor(textColor); north.setStrokeWidth(dp(2));
            canvas.drawLine(w-dp(24),dp(38),w-dp(24),dp(14),north);
            canvas.drawLine(w-dp(24),dp(14),w-dp(29),dp(22),north);
            canvas.drawLine(w-dp(24),dp(14),w-dp(19),dp(22),north);
            label.setTextSize(dp(10)); canvas.drawText("N",w-dp(24),dp(10),label);
        }
    }

    public class PartialCoordinateDiagramView extends View {
        private double azimuth = 30.0;
        private double dx = 0.0;
        private double dy = 0.0;
        private boolean hasData = false;

        private final Paint panelFill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint panelStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint titlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint subtitlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint innerRingPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint axisPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tickPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint degreePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint cardinalPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint vectorPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint projectionEastPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint projectionNorthPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint centerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pointGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pointPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint footerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint footerTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint chipFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint chipStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint chipTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        public PartialCoordinateDiagramView(Context context) {
            super(context);
            panelFill.setStyle(Paint.Style.FILL);
            panelFill.setColor(themeMode == THEME_LIGHT ? Color.rgb(248, 251, 255) : Color.rgb(4, 18, 32));
            panelStroke.setStyle(Paint.Style.STROKE);
            panelStroke.setStrokeWidth(dp(1));
            panelStroke.setColor(withAlpha(borderColor, 125));

            titlePaint.setColor(themeMode == THEME_LIGHT ? Color.rgb(28, 42, 58) : Color.WHITE);
            titlePaint.setTextSize(dp(15));
            titlePaint.setTypeface(Typeface.DEFAULT_BOLD);

            subtitlePaint.setColor(themeMode == THEME_LIGHT ? Color.rgb(106, 122, 142) : Color.rgb(166, 184, 206));
            subtitlePaint.setTextSize(dp(10));
            subtitlePaint.setTypeface(Typeface.DEFAULT_BOLD);
            subtitlePaint.setTextAlign(Paint.Align.CENTER);

            ringPaint.setStyle(Paint.Style.STROKE);
            ringPaint.setStrokeWidth(dp(2));
            ringPaint.setColor(themeMode == THEME_LIGHT ? Color.rgb(58, 134, 255) : Color.rgb(45, 161, 255));

            innerRingPaint.setStyle(Paint.Style.STROKE);
            innerRingPaint.setStrokeWidth(dp(1));
            innerRingPaint.setColor(themeMode == THEME_LIGHT ? Color.argb(70, 50, 90, 140) : Color.argb(80, 70, 120, 180));

            gridPaint.setStyle(Paint.Style.STROKE);
            gridPaint.setStrokeWidth(dp(1));
            gridPaint.setColor(themeMode == THEME_LIGHT ? Color.argb(40, 60, 95, 138) : Color.argb(35, 70, 126, 180));

            axisPaint.setStyle(Paint.Style.STROKE);
            axisPaint.setStrokeWidth(dp(1));
            axisPaint.setColor(themeMode == THEME_LIGHT ? Color.argb(160, 85, 103, 124) : Color.argb(145, 212, 226, 242));

            tickPaint.setStyle(Paint.Style.STROKE);
            tickPaint.setStrokeCap(Paint.Cap.ROUND);
            tickPaint.setColor(themeMode == THEME_LIGHT ? Color.argb(120, 55, 88, 120) : Color.argb(130, 192, 214, 236));

            degreePaint.setColor(themeMode == THEME_LIGHT ? Color.rgb(86, 108, 130) : Color.rgb(160, 181, 208));
            degreePaint.setTextSize(dp(10));
            degreePaint.setTypeface(Typeface.DEFAULT_BOLD);
            degreePaint.setTextAlign(Paint.Align.CENTER);

            cardinalPaint.setColor(themeMode == THEME_LIGHT ? Color.rgb(37, 50, 68) : Color.rgb(226, 237, 248));
            cardinalPaint.setTextSize(dp(18));
            cardinalPaint.setTypeface(Typeface.DEFAULT_BOLD);
            cardinalPaint.setTextAlign(Paint.Align.CENTER);

            vectorPaint.setStyle(Paint.Style.STROKE);
            vectorPaint.setStrokeCap(Paint.Cap.ROUND);
            vectorPaint.setStrokeJoin(Paint.Join.ROUND);
            vectorPaint.setStrokeWidth(dp(2));
            vectorPaint.setColor(Color.rgb(79, 198, 255));
            vectorPaint.setShadowLayer(dp(6), 0, 0, withAlpha(Color.rgb(79, 198, 255), 180));

            projectionEastPaint.setStyle(Paint.Style.STROKE);
            projectionEastPaint.setStrokeWidth(dp(2));
            projectionEastPaint.setColor(Color.rgb(74, 208, 255));
            projectionEastPaint.setPathEffect(new DashPathEffect(new float[]{dp(4), dp(4)}, 0));

            projectionNorthPaint.setStyle(Paint.Style.STROKE);
            projectionNorthPaint.setStrokeWidth(dp(2));
            projectionNorthPaint.setColor(Color.rgb(92, 229, 128));
            projectionNorthPaint.setPathEffect(new DashPathEffect(new float[]{dp(4), dp(4)}, 0));

            centerPaint.setStyle(Paint.Style.FILL);
            centerPaint.setColor(Color.rgb(60, 148, 255));
            pointGlowPaint.setStyle(Paint.Style.FILL);
            pointGlowPaint.setColor(withAlpha(Color.rgb(96, 210, 255), 140));
            pointPaint.setStyle(Paint.Style.FILL);
            pointPaint.setColor(Color.rgb(245, 250, 255));

            footerPaint.setStyle(Paint.Style.FILL);
            footerPaint.setColor(themeMode == THEME_LIGHT ? Color.argb(220, 245, 248, 255) : Color.argb(205, 7, 22, 39));
            footerTextPaint.setColor(themeMode == THEME_LIGHT ? Color.rgb(50, 65, 82) : Color.rgb(214, 226, 240));
            footerTextPaint.setTextSize(dp(11));
            footerTextPaint.setTextAlign(Paint.Align.CENTER);

            chipFillPaint.setStyle(Paint.Style.FILL);
            chipFillPaint.setColor(themeMode == THEME_LIGHT ? Color.argb(245, 255, 255, 255) : Color.argb(228, 8, 22, 39));
            chipStrokePaint.setStyle(Paint.Style.STROKE);
            chipStrokePaint.setStrokeWidth(dp(1));
            chipTextPaint.setColor(themeMode == THEME_LIGHT ? Color.rgb(35, 50, 67) : Color.rgb(236, 243, 248));
            chipTextPaint.setTypeface(Typeface.DEFAULT_BOLD);
            chipTextPaint.setTextSize(dp(11));
            chipTextPaint.setTextAlign(Paint.Align.CENTER);

            setLayerType(LAYER_TYPE_SOFTWARE, null);
        }

        public void update(double azimuth, double dx, double dy) {
            this.azimuth = azimuth;
            this.dx = dx;
            this.dy = dy;
            this.hasData = true;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float panelRadius = dp(18);
            RectF panel = new RectF(dp(1), dp(1), w - dp(1), h - dp(1));
            canvas.drawRoundRect(panel, panelRadius, panelRadius, panelFill);
            canvas.drawRoundRect(panel, panelRadius, panelRadius, panelStroke);

            canvas.drawText("Vector y componentes", dp(16), dp(24), titlePaint);

            float cx = w / 2f;
            float cy = h * 0.54f;
            float r = Math.min(w * 0.33f, h * 0.36f);

            for (int i = 1; i <= 4; i++) {
                canvas.drawCircle(cx, cy, r * i / 4f, i == 4 ? ringPaint : innerRingPaint);
            }

            for (int deg = 0; deg < 360; deg += 15) {
                double ang = Math.toRadians(deg - 90);
                boolean major = deg % 45 == 0;
                float outer = r;
                float inner = major ? r - dp(14) : r - dp(8);
                tickPaint.setStrokeWidth(major ? dp(2) : dp(1));
                canvas.drawLine(
                        (float) (cx + Math.cos(ang) * inner),
                        (float) (cy + Math.sin(ang) * inner),
                        (float) (cx + Math.cos(ang) * outer),
                        (float) (cy + Math.sin(ang) * outer),
                        tickPaint
                );
            }

            for (int deg = 0; deg < 360; deg += 30) {
                double ang = Math.toRadians(deg - 90);
                float endX = (float) (cx + Math.cos(ang) * r);
                float endY = (float) (cy + Math.sin(ang) * r);
                canvas.drawLine(cx, cy, endX, endY, gridPaint);
            }

            canvas.drawLine(cx - r, cy, cx + r, cy, axisPaint);
            canvas.drawLine(cx, cy - r, cx, cy + r, axisPaint);

            canvas.drawText("N", cx, cy - r - dp(10), cardinalPaint);
            canvas.drawText("S", cx, cy + r + dp(24), cardinalPaint);
            canvas.drawText("E", cx + r + dp(18), cy + dp(6), cardinalPaint);
            canvas.drawText("O", cx - r - dp(18), cy + dp(6), cardinalPaint);

            double distance = Math.hypot(dx, dy);
            double displayMax = Math.max(20.0, Math.ceil(Math.max(distance, 1.0) / 5.0) * 5.0);
            float usableR = r * 0.84f;
            float endX;
            float endY;
            if (hasData && distance > 0.0001) {
                float vectorLen = (float) ((distance / displayMax) * usableR);
                endX = cx + (float) ((dx / distance) * vectorLen);
                endY = cy - (float) ((dy / distance) * vectorLen);
            } else {
                endX = cx;
                endY = cy;
            }

            if (hasData && distance > 0.0001) {
                float projX = cx + (float) ((dx / displayMax) * usableR);
                float projY = cy - (float) ((dy / displayMax) * usableR);

                canvas.drawLine(cx, cy, projX, cy, projectionEastPaint);
                canvas.drawLine(projX, cy, projX, projY, projectionNorthPaint);
                canvas.drawLine(cx, cy, projX, projY, vectorPaint);
                drawArrowHead(canvas, projX, projY, (float) Math.atan2(projY - cy, projX - cx));

                canvas.drawCircle(cx, cy, dp(7), centerPaint);
                canvas.drawCircle(cx, cy, dp(3), pointPaint);
                canvas.drawCircle(projX, projY, dp(10), pointGlowPaint);
                canvas.drawCircle(projX, projY, dp(5), pointPaint);

                drawLabeledChip(canvas,
                        projX + dp(52),
                        projY - dp(10),
                        "Δ Norte (N/S)",
                        signedMeters(dy),
                        Color.rgb(92, 229, 128));
                drawLabeledChip(canvas,
                        projX + dp(28),
                        cy + dp(26),
                        "Δ Este (E/O)",
                        signedMeters(dx),
                        Color.rgb(74, 208, 255));
            } else {
                canvas.drawCircle(cx, cy, dp(7), centerPaint);
                canvas.drawCircle(cx, cy, dp(3), pointPaint);
            }

        }

        private void drawArrowHead(Canvas canvas, float x, float y, float angle) {
            float size = dp(12);
            canvas.drawLine(x, y,
                    x - (float) Math.cos(angle - 0.55f) * size,
                    y - (float) Math.sin(angle - 0.55f) * size,
                    vectorPaint);
            canvas.drawLine(x, y,
                    x - (float) Math.cos(angle + 0.55f) * size,
                    y - (float) Math.sin(angle + 0.55f) * size,
                    vectorPaint);
        }

        private void drawLabeledChip(Canvas canvas, float anchorX, float anchorY, String title, String value, int color) {
            float textW = Math.max(chipTextPaint.measureText(title), chipTextPaint.measureText(value));
            float halfW = textW / 2f + dp(10);
            float halfH = dp(20);
            RectF rect = new RectF(anchorX - halfW, anchorY - halfH, anchorX + halfW, anchorY + halfH);
            chipFillPaint.setColor(themeMode == THEME_LIGHT ? Color.argb(245, 255, 255, 255) : Color.argb(232, 8, 22, 39));
            chipStrokePaint.setColor(withAlpha(color, 205));
            canvas.drawRoundRect(rect, dp(12), dp(12), chipFillPaint);
            canvas.drawRoundRect(rect, dp(12), dp(12), chipStrokePaint);

            chipTextPaint.setColor(color);
            canvas.drawText(title, anchorX, anchorY - dp(2), chipTextPaint);
            chipTextPaint.setColor(themeMode == THEME_LIGHT ? Color.rgb(35, 50, 67) : Color.rgb(238, 244, 248));
            canvas.drawText(value, anchorX, anchorY + dp(12), chipTextPaint);
        }

        private String signedMeters(double value) {
            return (value >= 0 ? "+" : "−") + f3(Math.abs(value)) + " m";
        }

        private String trimMeasure(double value) {
            double rounded = Math.rint(value * 10.0) / 10.0;
            if (Math.abs(rounded - Math.rint(rounded)) < 0.0001) {
                return ((int) Math.rint(rounded)) + " m";
            }
            return String.format(Locale.US, "%.1f m", rounded);
        }
    }

    public class SlopeDiagramView extends View {
        private double horizontal = 0.0;
        private double inclined = 0.0;
        private double vertical = 0.0;
        private double angle = 0.0;
        private boolean hasData = false;
        private final Paint panelFill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint panelStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint basePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint slopePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint risePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pointPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pointGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint captionPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint legendPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint anglePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint chipFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint chipStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint chipTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        public SlopeDiagramView(Context context) {
            super(context);
            panelFill.setStyle(Paint.Style.FILL);
            panelFill.setColor(themeMode == THEME_LIGHT ? Color.rgb(248, 251, 255) : Color.rgb(4, 18, 32));
            panelStroke.setStyle(Paint.Style.STROKE);
            panelStroke.setStrokeWidth(dp(1));
            panelStroke.setColor(withAlpha(borderColor, 140));

            gridPaint.setStyle(Paint.Style.STROKE);
            gridPaint.setStrokeWidth(dp(1));
            gridPaint.setColor(themeMode == THEME_LIGHT ? Color.argb(32, 64, 92, 138) : Color.argb(30, 92, 126, 160));

            basePaint.setStyle(Paint.Style.STROKE);
            basePaint.setStrokeWidth(dp(3));
            basePaint.setColor(Color.rgb(66, 154, 255));
            slopePaint.setStyle(Paint.Style.STROKE);
            slopePaint.setStrokeWidth(dp(3));
            slopePaint.setColor(Color.rgb(61, 222, 255));
            risePaint.setStyle(Paint.Style.STROKE);
            risePaint.setStrokeWidth(dp(3));
            risePaint.setColor(Color.rgb(92, 229, 128));

            pointPaint.setStyle(Paint.Style.FILL);
            pointPaint.setColor(Color.rgb(236, 245, 255));
            pointGlowPaint.setStyle(Paint.Style.FILL);
            pointGlowPaint.setColor(withAlpha(Color.rgb(76, 180, 255), 135));

            textPaint.setColor(themeMode == THEME_LIGHT ? Color.rgb(34, 46, 63) : Color.rgb(230, 239, 248));
            textPaint.setTextSize(dp(12));
            textPaint.setTypeface(Typeface.DEFAULT_BOLD);
            captionPaint.setColor(themeMode == THEME_LIGHT ? Color.rgb(95, 108, 127) : Color.rgb(166, 184, 206));
            captionPaint.setTextSize(dp(10));
            captionPaint.setTypeface(Typeface.DEFAULT_BOLD);
            legendPaint.setColor(themeMode == THEME_LIGHT ? Color.rgb(66, 80, 98) : Color.rgb(210, 223, 236));
            legendPaint.setTextSize(dp(10));
            anglePaint.setStyle(Paint.Style.STROKE);
            anglePaint.setStrokeWidth(dp(3));
            anglePaint.setColor(Color.rgb(255, 193, 7));
            chipFillPaint.setStyle(Paint.Style.FILL);
            chipFillPaint.setColor(themeMode == THEME_LIGHT ? Color.argb(232, 255, 255, 255) : Color.argb(220, 8, 22, 39));
            chipStrokePaint.setStyle(Paint.Style.STROKE);
            chipStrokePaint.setStrokeWidth(dp(1));
            chipTextPaint.setTextSize(dp(11));
            chipTextPaint.setTypeface(Typeface.DEFAULT_BOLD);
            chipTextPaint.setTextAlign(Paint.Align.CENTER);
            setLayerType(LAYER_TYPE_SOFTWARE, null);
        }

        public void update(double horizontal, double inclined, double vertical, double angle) {
            this.horizontal = horizontal;
            this.inclined = inclined;
            this.vertical = vertical;
            this.angle = angle;
            this.hasData = true;
            invalidate();
        }

        public void clearData() {
            hasData = false;
            this.horizontal = 0.0;
            this.inclined = 0.0;
            this.vertical = 0.0;
            this.angle = 0.0;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            RectF panel = new RectF(dp(1), dp(1), w - dp(1), h - dp(1));
            canvas.drawRoundRect(panel, dp(18), dp(18), panelFill);
            canvas.drawRoundRect(panel, dp(18), dp(18), panelStroke);

            textPaint.setTextAlign(Paint.Align.LEFT);
            canvas.drawText("Gráfico y componentes", dp(16), dp(22), textPaint);
            canvas.drawText("Esquema visual del cálculo activo", dp(16), dp(38), captionPaint);

            float graphLeft = dp(16);
            float graphTop = dp(52);
            float graphRight = w - dp(16);
            float graphBottom = h - dp(48);
            RectF graph = new RectF(graphLeft, graphTop, graphRight, graphBottom);

            for (int i = 0; i <= 10; i++) {
                float x = graph.left + (graph.width() * i / 10f);
                canvas.drawLine(x, graph.top, x, graph.bottom, gridPaint);
            }
            for (int i = 0; i <= 6; i++) {
                float y = graph.top + (graph.height() * i / 6f);
                canvas.drawLine(graph.left, y, graph.right, y, gridPaint);
            }

            if (!hasData) {
                return;
            }

            float startX = graph.left + dp(26);
            float baseY = graph.bottom - dp(44);
            float maxRight = graph.right - dp(90);
            float minTop = graph.top + dp(26);
            double absH = Math.max(Math.abs(horizontal), 0.0001);
            double absV = Math.max(Math.abs(vertical), 0.0001);
            float availableW = Math.max(dp(90), maxRight - startX);
            float availableH = Math.max(dp(90), baseY - minTop);
            float scale = (float) Math.min(availableW / absH, availableH / absV);
            if (!Float.isFinite(scale) || scale <= 0f) scale = 1f;
            float spanX = Math.max(dp(58), (float) absH * scale);
            float spanY = Math.max(dp(58), (float) absV * scale);
            if (spanX > availableW) spanX = availableW;
            if (spanY > availableH) spanY = availableH;

            float endX = startX + spanX;
            float endY = baseY - spanY;

            canvas.drawLine(startX, baseY, endX, baseY, basePaint);
            canvas.drawLine(endX, baseY, endX, endY, risePaint);
            canvas.drawLine(startX, baseY, endX, endY, slopePaint);

            canvas.drawCircle(startX, baseY, dp(6), pointGlowPaint);
            canvas.drawCircle(startX, baseY, dp(4), pointPaint);
            canvas.drawCircle(endX, baseY, dp(6), pointGlowPaint);
            canvas.drawCircle(endX, baseY, dp(4), pointPaint);
            canvas.drawCircle(endX, endY, dp(7), pointGlowPaint);
            canvas.drawCircle(endX, endY, dp(5), pointPaint);

            float arcRadius = Math.min(dp(34), Math.max(dp(24), Math.min(spanX, spanY) * 0.28f));
            RectF arc = new RectF(startX - arcRadius, baseY - arcRadius, startX + arcRadius, baseY + arcRadius);
            canvas.drawArc(arc, 0, (float) -angle, false, anglePaint);
            drawChip(canvas, startX + arcRadius + dp(34), baseY - arcRadius * 0.58f,
                    "θ " + formatDms(angle), Color.rgb(255, 193, 7));
            drawChip(canvas, startX + spanX * 0.50f, baseY + dp(28), "Dh  " + f3(horizontal) + " m", Color.rgb(66, 154, 255));
            drawChip(canvas, Math.min(graph.right - dp(64), endX + dp(54)), baseY - spanY * 0.50f, "Δh  " + signedNumber(vertical) + " m", Color.rgb(92, 229, 128));

            float midX = (startX + endX) / 2f;
            float midY = (baseY + endY) / 2f;
            canvas.save();
            double deg = Math.toDegrees(Math.atan2(endY - baseY, endX - startX));
            canvas.rotate((float) deg, midX, midY);
            chipTextPaint.setColor(Color.rgb(61, 222, 255));
            canvas.drawText("Di  " + f3(inclined) + " m", midX, midY - dp(12), chipTextPaint);
            canvas.restore();

            float legendY = h - dp(20);
            drawLegendItem(canvas, graph.left + dp(6), legendY, Color.rgb(66, 154, 255), "Dh horizontal");
            drawLegendItem(canvas, graph.left + dp(146), legendY, Color.rgb(61, 222, 255), "Di inclinada");
            drawLegendItem(canvas, graph.left + dp(296), legendY, Color.rgb(92, 229, 128), "Δh cota");
        }

        private void drawLegendItem(Canvas canvas, float x, float y, int color, String label) {
            Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(dp(3));
            line.setColor(color);
            canvas.drawLine(x, y, x + dp(24), y, line);
            canvas.drawText(label, x + dp(32), y + dp(4), legendPaint);
        }

        private void drawChip(Canvas canvas, float centerX, float centerY, String text, int accent) {
            chipTextPaint.setTextSize(dp(11));
            float width = chipTextPaint.measureText(text) + dp(24);
            RectF rect = new RectF(centerX - width / 2f, centerY - dp(16), centerX + width / 2f, centerY + dp(10));
            chipStrokePaint.setColor(withAlpha(accent, 180));
            canvas.drawRoundRect(rect, dp(12), dp(12), chipFillPaint);
            canvas.drawRoundRect(rect, dp(12), dp(12), chipStrokePaint);
            chipTextPaint.setColor(accent);
            canvas.drawText(text, centerX, centerY + dp(2), chipTextPaint);
        }
    }

    public class StadiaDiagramView extends View {
        private double superior = 1.50;
        private double inferior = 1.30;
        private boolean hasData = false;
        private final Paint lineSup = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint lineInf = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint object = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint soft = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint accentBlue = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint accentGreen = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint legend = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint dashed = new Paint(Paint.ANTI_ALIAS_FLAG);

        public StadiaDiagramView(Context context) {
            super(context);
            lineSup.setStyle(Paint.Style.STROKE);
            lineSup.setStrokeWidth(dp(2));
            lineSup.setColor(Color.rgb(55, 134, 255));

            lineInf.setStyle(Paint.Style.STROKE);
            lineInf.setStrokeWidth(dp(2));
            lineInf.setColor(Color.rgb(55, 213, 143));

            object.setStyle(Paint.Style.STROKE);
            object.setStrokeWidth(dp(2));
            object.setColor(themeMode == THEME_LIGHT ? Color.rgb(78, 99, 121) : Color.rgb(199, 219, 241));

            soft.setStyle(Paint.Style.STROKE);
            soft.setStrokeWidth(dp(1));
            soft.setColor(themeMode == THEME_LIGHT ? Color.argb(80, 90, 120, 152) : Color.argb(75, 96, 129, 169));

            fill.setStyle(Paint.Style.FILL);
            fill.setColor(themeMode == THEME_LIGHT ? Color.rgb(238, 246, 255) : Color.rgb(6, 20, 34));

            accentBlue.setStyle(Paint.Style.FILL);
            accentBlue.setColor(Color.rgb(67, 152, 255));

            accentGreen.setStyle(Paint.Style.FILL);
            accentGreen.setColor(Color.rgb(55, 213, 143));

            text.setColor(themeMode == THEME_LIGHT ? Color.rgb(45, 58, 72) : Color.rgb(205, 224, 242));
            text.setTextSize(dp(11));
            text.setTypeface(Typeface.DEFAULT_BOLD);

            legend.setColor(themeMode == THEME_LIGHT ? Color.rgb(52, 72, 95) : Color.rgb(184, 207, 230));
            legend.setTextSize(dp(11));
            legend.setTypeface(Typeface.DEFAULT_BOLD);

            dashed.setStyle(Paint.Style.STROKE);
            dashed.setStrokeWidth(dp(1));
            dashed.setColor(themeMode == THEME_LIGHT ? Color.argb(110, 88, 112, 138) : Color.argb(110, 122, 150, 184));
            dashed.setPathEffect(new DashPathEffect(new float[]{dp(6), dp(4)}, 0));
        }

        public void update(double superior, double inferior) {
            this.superior = superior;
            this.inferior = inferior;
            this.hasData = true;
            invalidate();
        }

        public void clearData() {
            hasData = false;
            invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float left = dp(12);
            float right = w - dp(12);
            float top = dp(12);
            float bottom = h - dp(12);
            float ground = h * 0.90f;
            float staffX = w * 0.22f;
            float instX = w * 0.76f;
            float instY = h * 0.50f;
            float staffTop = h * 0.18f;
            float staffBottom = h * 0.80f;

            GradientDrawable bg = new GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    themeMode == THEME_LIGHT
                            ? new int[]{Color.rgb(250, 252, 255), Color.rgb(240, 247, 255)}
                            : new int[]{Color.rgb(5, 18, 32), Color.rgb(4, 16, 28)});
            bg.setCornerRadius(dp(16));
            bg.setStroke(dp(1), withAlpha(borderColor, 120));
            bg.setBounds((int) left, (int) top, (int) right, (int) bottom);
            bg.draw(canvas);

            canvas.drawLine(left + dp(8), ground, right - dp(8), ground, soft);

            canvas.drawRect(staffX - dp(8), staffTop, staffX + dp(8), staffBottom, fill);
            canvas.drawRect(staffX - dp(8), staffTop, staffX + dp(8), staffBottom, object);
            int segments = 12;
            float segH = (staffBottom - staffTop) / segments;
            Paint staffMark = new Paint(Paint.ANTI_ALIAS_FLAG);
            staffMark.setStyle(Paint.Style.FILL);
            for (int i = 0; i < segments; i++) {
                float y1 = staffTop + i * segH;
                float y2 = y1 + segH;
                if (i % 2 == 0) {
                    staffMark.setColor(themeMode == THEME_LIGHT ? Color.rgb(226, 233, 240) : Color.rgb(231, 238, 245));
                    canvas.drawRect(staffX - dp(8), y1, staffX, y2, staffMark);
                }
                if (i % 3 == 0) {
                    staffMark.setColor(Color.rgb(220, 72, 72));
                    canvas.drawRect(staffX, y1, staffX + dp(8), y1 + segH / 2f, staffMark);
                }
                canvas.drawLine(staffX - dp(8), y2, staffX + dp(8), y2, object);
            }

            double max = hasData ? Math.max(superior, inferior) : 1.55;
            double min = hasData ? Math.min(superior, inferior) : 1.20;
            if (Math.abs(max - min) < 0.20) {
                max += 0.10;
                min -= 0.10;
            }
            min = Math.max(0, min - 0.18);
            max = max + 0.18;
            float usable = staffBottom - staffTop;
            float ySup = (float) (staffBottom - ((superior - min) / (max - min)) * usable);
            float yInf = (float) (staffBottom - ((inferior - min) / (max - min)) * usable);
            if (!hasData) {
                ySup = h * 0.34f;
                yInf = h * 0.60f;
            }
            if (ySup > yInf) {
                float tmp = ySup;
                ySup = yInf;
                yInf = tmp;
            }

            canvas.drawLine(staffX, ySup, instX, instY, lineSup);
            canvas.drawLine(staffX, yInf, instX, instY, lineInf);

            canvas.drawCircle(staffX, ySup, dp(5), accentBlue);
            canvas.drawCircle(staffX, yInf, dp(5), accentGreen);
            canvas.drawCircle(instX, instY, dp(6), themeMode == THEME_LIGHT ? accentBlue : fill);
            canvas.drawCircle(instX, instY, dp(6), object);

            // instrument
            Paint yellow = new Paint(Paint.ANTI_ALIAS_FLAG);
            yellow.setStyle(Paint.Style.FILL);
            yellow.setColor(Color.rgb(242, 185, 50));
            Paint dark = new Paint(Paint.ANTI_ALIAS_FLAG);
            dark.setStyle(Paint.Style.FILL);
            dark.setColor(themeMode == THEME_LIGHT ? Color.rgb(78, 98, 121) : Color.rgb(56, 72, 92));
            RectF head = new RectF(instX - dp(14), instY - dp(12), instX + dp(14), instY + dp(10));
            canvas.drawRoundRect(head, dp(5), dp(5), yellow);
            canvas.drawCircle(instX, instY - dp(1), dp(5), dark);
            canvas.drawCircle(instX, instY - dp(1), dp(2), accentBlue);
            RectF monitor = new RectF(instX - dp(12), instY + dp(10), instX + dp(12), instY + dp(18));
            canvas.drawRoundRect(monitor, dp(3), dp(3), dark);
            canvas.drawRect(instX - dp(2), instY + dp(20), instX + dp(2), instY + dp(30), dark);
            canvas.drawLine(instX - dp(2), instY + dp(30), instX - dp(14), ground, object);
            canvas.drawLine(instX, instY + dp(30), instX, ground, object);
            canvas.drawLine(instX + dp(2), instY + dp(30), instX + dp(14), ground, object);

            // labels and legend
            text.setTextAlign(Paint.Align.LEFT);
            text.setColor(Color.rgb(67, 152, 255));
            canvas.drawText("HS", left + dp(18), ySup + dp(4), text);
            text.setColor(Color.rgb(55, 213, 143));
            canvas.drawText("HI", left + dp(18), yInf + dp(4), text);

            Path dashSup = new Path();
            dashSup.moveTo(left + dp(58), ySup);
            dashSup.lineTo(staffX - dp(8), ySup);
            canvas.drawPath(dashSup, dashed);
            Path dashInf = new Path();
            dashInf.moveTo(left + dp(58), yInf);
            dashInf.lineTo(staffX - dp(8), yInf);
            canvas.drawPath(dashInf, dashed);

        }
    }

    public class CompassView extends View {
        public static final int STYLE_CLASSIC = 0;
        public static final int STYLE_TARGET = 1;
        public static final int STYLE_NEON = 2;
        public static final int STYLE_ORIENTATION_HUD = 3;
        public static final int STYLE_AZIMUTH_PANEL = 4;
        public static final int PANEL_AZIMUTH = 0;
        public static final int PANEL_RUMBO = 1;

        private double azimuth;
        private boolean directionAvailable = true;
        private boolean lightDial = false;
        private int displayStyle = STYLE_CLASSIC;
        private boolean spanishWestLabel = false;
        private String unavailableText = "";
        private int azimuthPanelMode = PANEL_AZIMUTH;

        public CompassView(Context context) {
            super(context);
            setLayerType(LAYER_TYPE_SOFTWARE, null);
        }

        public void setLightDial(boolean lightDial) {
            this.lightDial = lightDial;
            invalidate();
        }

        public void setDisplayStyle(int displayStyle) {
            this.displayStyle = displayStyle;
            invalidate();
        }

        public void setSpanishWestLabel(boolean spanishWestLabel) {
            this.spanishWestLabel = spanishWestLabel;
            invalidate();
        }

        public void setAzimuthPanelMode(int azimuthPanelMode) {
            this.azimuthPanelMode = azimuthPanelMode;
            invalidate();
        }

        public void setUnavailableText(String unavailableText) {
            this.unavailableText = unavailableText == null ? "" : unavailableText;
            invalidate();
        }

        public void setAzimuth(double azimuth) {
            this.azimuth = azimuth;
            this.directionAvailable = true;
            invalidate();
        }

        public void setDirectionAvailable(boolean available) {
            this.directionAvailable = available;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2f;
            float cy = h / 2f;
            float r = Math.min(w, h) * 0.42f;

            if (displayStyle == STYLE_ORIENTATION_HUD) {
                drawOrientationHudCompass(canvas, cx, cy, r, false);
                return;
            }
            if (displayStyle == STYLE_AZIMUTH_PANEL) {
                drawAzimuthPanelCompass(canvas, cx, cy, r);
                return;
            }

            boolean targetMode = displayStyle == STYLE_TARGET;
            boolean neonMode = displayStyle == STYLE_NEON || targetMode;
            if (neonMode) {
                drawFuturisticCompass(canvas, cx, cy, r, targetMode);
                return;
            }
            drawFuturisticCompass(canvas, cx, cy, r, false);
        }

        private void drawOrientationHudCompass(Canvas canvas, float cx, float cy, float r, boolean unusedTargetMode) {
            boolean targetMode = selectedOrientationCompassView == this && orientationCompassMode == 2;

            int faceOuter = themeMode == THEME_LIGHT ? Color.rgb(241, 247, 255) : Color.rgb(3, 10, 20);
            int faceInner = themeMode == THEME_LIGHT ? Color.rgb(250, 252, 255) : Color.rgb(6, 14, 26);
            int innerDisc = themeMode == THEME_LIGHT ? Color.rgb(247, 250, 255) : Color.rgb(7, 16, 28);
            int cyan = themeMode == THEME_LIGHT ? Color.rgb(43, 143, 255) : Color.rgb(66, 184, 255);
            int cyanSoft = themeMode == THEME_LIGHT ? Color.argb(120, 64, 156, 255) : Color.argb(115, 69, 175, 255);
            int white = themeMode == THEME_LIGHT ? Color.rgb(26, 39, 58) : Color.rgb(242, 248, 255);
            int minor = themeMode == THEME_LIGHT ? Color.argb(125, 88, 104, 128) : Color.argb(125, 175, 196, 224);
            int ringDark = themeMode == THEME_LIGHT ? Color.argb(65, 50, 74, 102) : Color.argb(75, 38, 66, 102);

            Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
            halo.setStyle(Paint.Style.FILL);
            halo.setColor(themeMode == THEME_LIGHT ? Color.argb(28, 51, 128, 255) : Color.argb(42, 34, 88, 170));
            canvas.drawCircle(cx, cy, r * 1.05f, halo);

            Paint outerFace = new Paint(Paint.ANTI_ALIAS_FLAG);
            outerFace.setStyle(Paint.Style.FILL);
            outerFace.setColor(faceOuter);
            canvas.drawCircle(cx, cy, r * 0.99f, outerFace);

            Paint outerRing = new Paint(Paint.ANTI_ALIAS_FLAG);
            outerRing.setStyle(Paint.Style.STROKE);
            outerRing.setStrokeWidth(dp(3));
            outerRing.setColor(cyan);
            outerRing.setShadowLayer(dp(9), 0, 0, withAlpha(cyan, 165));
            canvas.drawCircle(cx, cy, r * 0.98f, outerRing);

            Paint darkRing = new Paint(Paint.ANTI_ALIAS_FLAG);
            darkRing.setStyle(Paint.Style.STROKE);
            darkRing.setStrokeWidth(dp(7));
            darkRing.setColor(ringDark);
            canvas.drawCircle(cx, cy, r * 0.90f, darkRing);

            Paint innerFacePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            innerFacePaint.setStyle(Paint.Style.FILL);
            innerFacePaint.setColor(faceInner);
            canvas.drawCircle(cx, cy, r * 0.88f, innerFacePaint);

            Paint innerDiscPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            innerDiscPaint.setStyle(Paint.Style.FILL);
            innerDiscPaint.setColor(innerDisc);
            canvas.drawCircle(cx, cy, r * 0.84f, innerDiscPaint);

            Paint innerDiscStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
            innerDiscStroke.setStyle(Paint.Style.STROKE);
            innerDiscStroke.setStrokeWidth(dp(2));
            innerDiscStroke.setColor(withAlpha(cyan, 115));
            canvas.drawCircle(cx, cy, r * 0.72f, innerDiscStroke);

            Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
            grid.setStyle(Paint.Style.STROKE);
            grid.setStrokeWidth(dp(1));
            grid.setColor(themeMode == THEME_LIGHT ? Color.argb(42, 88, 120, 156) : Color.argb(46, 74, 112, 158));
            for (float factor : new float[]{0.22f, 0.36f, 0.50f, 0.64f}) {
                canvas.drawCircle(cx, cy, r * factor, grid);
            }
            canvas.drawLine(cx - r * 0.80f, cy, cx + r * 0.80f, cy, grid);
            canvas.drawLine(cx, cy - r * 0.80f, cx, cy + r * 0.80f, grid);

            Paint majorTick = new Paint(Paint.ANTI_ALIAS_FLAG);
            majorTick.setStyle(Paint.Style.STROKE);
            majorTick.setStrokeCap(Paint.Cap.ROUND);
            majorTick.setColor(themeMode == THEME_LIGHT ? Color.rgb(56, 76, 103) : Color.rgb(240, 246, 252));
            Paint minorTick = new Paint(Paint.ANTI_ALIAS_FLAG);
            minorTick.setStyle(Paint.Style.STROKE);
            minorTick.setStrokeCap(Paint.Cap.ROUND);
            minorTick.setColor(minor);

            for (int i = 0; i < 60; i++) {
                double a = Math.toRadians(i * 6 - 90);
                boolean cardinal = i % 15 == 0;
                boolean major = i % 5 == 0;
                Paint tickPaint = cardinal || major ? majorTick : minorTick;
                tickPaint.setStrokeWidth(cardinal ? 2.4f * getResources().getDisplayMetrics().density : (major ? 1.6f * getResources().getDisplayMetrics().density : 1f * getResources().getDisplayMetrics().density));
                float outer = r * 0.84f;
                float inner = cardinal ? r * 0.69f : (major ? r * 0.75f : r * 0.79f);
                canvas.drawLine(
                        (float) (cx + Math.cos(a) * inner),
                        (float) (cy + Math.sin(a) * inner),
                        (float) (cx + Math.cos(a) * outer),
                        (float) (cy + Math.sin(a) * outer),
                        tickPaint
                );
            }

            RectF hudRect = new RectF(cx - r * 1.07f, cy - r * 1.07f, cx + r * 1.07f, cy + r * 1.07f);
            drawHudArcSegment(canvas, hudRect, 208f, 38f, cyan, dp(4));
            drawHudArcSegment(canvas, hudRect, 300f, 46f, cyan, dp(4));
            drawHudArcSegment(canvas, hudRect, 22f, 32f, cyan, dp(3));
            drawHudArcSegment(canvas, hudRect, 148f, 26f, cyan, dp(3));
            drawOuterHudTicks(canvas, cx, cy, r * 1.14f, cyan);

            Paint cardinalPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            cardinalPaint.setTypeface(Typeface.DEFAULT_BOLD);
            cardinalPaint.setTextAlign(Paint.Align.CENTER);
            cardinalPaint.setTextSize(dp(28));
            cardinalPaint.setShadowLayer(dp(6), 0, 0, themeMode == THEME_LIGHT ? Color.argb(0, 0, 0, 0) : withAlpha(Color.WHITE, 48));
            cardinalPaint.setColor(targetMode ? white : Color.rgb(255, 246, 246));
            canvas.drawText("N", cx, cy - r * 0.48f, cardinalPaint);
            cardinalPaint.setColor(white);
            canvas.drawText("S", cx, cy + r * 0.58f, cardinalPaint);
            canvas.drawText("E", cx + r * 0.57f, cy + dp(8), cardinalPaint);
            canvas.drawText(spanishWestLabel ? "O" : "W", cx - r * 0.57f, cy + dp(8), cardinalPaint);

            if (targetMode && directionAvailable) {
                drawTargetRingMarker(canvas, cx, cy, r, Math.toRadians(azimuth - 90.0), cyan);
            }

            double needleAngle = targetMode ? -Math.PI / 2.0 : (directionAvailable ? Math.toRadians(azimuth - 90.0) : -Math.PI / 2.0);
            drawNorthNeedleSingle(canvas, cx, cy, r, needleAngle);
            drawHudCenterHub(canvas, cx, cy, cyan);
        }

        private void drawHudArcSegment(Canvas canvas, RectF rect, float startDeg, float sweepDeg, int color, float stroke) {
            Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
            arc.setStyle(Paint.Style.STROKE);
            arc.setStrokeCap(Paint.Cap.ROUND);
            arc.setStrokeWidth(stroke);
            arc.setColor(color);
            arc.setShadowLayer(stroke * 1.8f, 0, 0, withAlpha(color, 160));
            canvas.drawArc(rect, startDeg, sweepDeg, false, arc);
        }

        private void drawOuterHudTicks(Canvas canvas, float cx, float cy, float radius, int color) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(withAlpha(color, 175));
            p.setStrokeWidth(dp(3));
            for (int i = 0; i < 12; i++) {
                if (i == 2 || i == 5 || i == 8 || i == 11) continue;
                double a = Math.toRadians(i * 30 - 90);
                float inner = radius - dp(4);
                float outer = radius + dp(2);
                canvas.drawLine(
                        (float) (cx + Math.cos(a) * inner),
                        (float) (cy + Math.sin(a) * inner),
                        (float) (cx + Math.cos(a) * outer),
                        (float) (cy + Math.sin(a) * outer),
                        p
                );
            }
        }

        private void drawNorthNeedleSingle(Canvas canvas, float cx, float cy, float r, double rad) {
            Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
            glow.setStyle(Paint.Style.FILL);
            glow.setColor(Color.argb(80, 255, 74, 74));
            Path glowPath = createSingleNeedlePath(cx, cy, r * 0.55f, r * 0.16f, rad);
            canvas.drawPath(glowPath, glow);

            Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(Color.rgb(242, 55, 55));
            Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
            edge.setStyle(Paint.Style.STROKE);
            edge.setStrokeWidth(dp(1));
            edge.setColor(Color.rgb(137, 17, 17));
            Path needle = createSingleNeedlePath(cx, cy, r * 0.48f, r * 0.13f, rad);
            canvas.drawPath(needle, fill);
            canvas.drawPath(needle, edge);

            Paint shine = new Paint(Paint.ANTI_ALIAS_FLAG);
            shine.setStyle(Paint.Style.STROKE);
            shine.setStrokeWidth(1.2f * getResources().getDisplayMetrics().density);
            shine.setColor(Color.argb(135, 255, 236, 236));
            canvas.drawLine(cx, cy,
                    (float) (cx + Math.cos(rad) * r * 0.36f),
                    (float) (cy + Math.sin(rad) * r * 0.36f),
                    shine);
        }

        private Path createSingleNeedlePath(float cx, float cy, float tipLen, float baseLen, double rad) {
            double left = rad + Math.toRadians(10.5);
            double right = rad - Math.toRadians(10.5);
            Path path = new Path();
            path.moveTo((float) (cx + Math.cos(rad) * tipLen), (float) (cy + Math.sin(rad) * tipLen));
            path.lineTo((float) (cx + Math.cos(left) * baseLen), (float) (cy + Math.sin(left) * baseLen));
            path.lineTo(cx, cy);
            path.lineTo((float) (cx + Math.cos(right) * baseLen), (float) (cy + Math.sin(right) * baseLen));
            path.close();
            return path;
        }

        private void drawTargetRingMarker(Canvas canvas, float cx, float cy, float r, double rad, int color) {
            Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeCap(Paint.Cap.ROUND);
            line.setStrokeWidth(dp(2));
            line.setColor(withAlpha(color, 210));
            line.setPathEffect(new DashPathEffect(new float[]{dp(5), dp(4)}, 0));
            canvas.drawLine(
                    (float) (cx + Math.cos(rad) * r * 0.18f),
                    (float) (cy + Math.sin(rad) * r * 0.18f),
                    (float) (cx + Math.cos(rad) * r * 0.68f),
                    (float) (cy + Math.sin(rad) * r * 0.68f),
                    line
            );

            Paint markerGlow = new Paint(Paint.ANTI_ALIAS_FLAG);
            markerGlow.setStyle(Paint.Style.FILL);
            markerGlow.setColor(withAlpha(color, 95));
            Path glow = createTargetMarkerPath(cx, cy, r * 0.93f, r * 1.06f, rad);
            canvas.drawPath(glow, markerGlow);

            Paint marker = new Paint(Paint.ANTI_ALIAS_FLAG);
            marker.setStyle(Paint.Style.FILL);
            marker.setColor(color);
            marker.setShadowLayer(dp(7), 0, 0, withAlpha(color, 180));
            Path markerPath = createTargetMarkerPath(cx, cy, r * 0.90f, r * 1.00f, rad);
            canvas.drawPath(markerPath, marker);
        }

        private Path createTargetMarkerPath(float cx, float cy, float innerRadius, float outerRadius, double rad) {
            double left = rad + Math.toRadians(4.5);
            double right = rad - Math.toRadians(4.5);
            Path path = new Path();
            path.moveTo((float) (cx + Math.cos(rad) * outerRadius), (float) (cy + Math.sin(rad) * outerRadius));
            path.lineTo((float) (cx + Math.cos(left) * innerRadius), (float) (cy + Math.sin(left) * innerRadius));
            path.lineTo((float) (cx + Math.cos(right) * innerRadius), (float) (cy + Math.sin(right) * innerRadius));
            path.close();
            return path;
        }

        private void drawHudCenterHub(Canvas canvas, float cx, float cy, int ringBlue) {
            Paint outerGlow = new Paint(Paint.ANTI_ALIAS_FLAG);
            outerGlow.setStyle(Paint.Style.FILL);
            outerGlow.setColor(themeMode == THEME_LIGHT ? Color.argb(34, 55, 136, 255) : Color.argb(62, 63, 149, 255));
            canvas.drawCircle(cx, cy, dp(17), outerGlow);

            Paint outer = new Paint(Paint.ANTI_ALIAS_FLAG);
            outer.setStyle(Paint.Style.FILL);
            outer.setColor(themeMode == THEME_LIGHT ? Color.rgb(19, 30, 44) : Color.rgb(14, 22, 32));
            canvas.drawCircle(cx, cy, dp(12), outer);

            Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(dp(2));
            ring.setColor(ringBlue);
            canvas.drawCircle(cx, cy, dp(12), ring);

            Paint core = new Paint(Paint.ANTI_ALIAS_FLAG);
            core.setStyle(Paint.Style.FILL);
            core.setColor(themeMode == THEME_LIGHT ? Color.rgb(232, 238, 246) : Color.rgb(243, 247, 252));
            canvas.drawCircle(cx, cy, dp(8), core);
            core.setColor(themeMode == THEME_LIGHT ? Color.rgb(50, 110, 240) : Color.rgb(74, 170, 255));
            canvas.drawCircle(cx, cy, dp(3), core);
        }

        private void drawAzimuthPanelCompass(Canvas canvas, float cx, float cy, float r) {
            r *= 1.18f;
            int ringBlue = themeMode == THEME_LIGHT ? Color.rgb(56, 140, 255) : Color.rgb(78, 190, 255);
            int ringBlue2 = themeMode == THEME_LIGHT ? Color.rgb(116, 186, 255) : Color.rgb(130, 212, 255);
            int tickMajor = themeMode == THEME_LIGHT ? Color.rgb(84, 94, 112) : Color.rgb(234, 241, 248);
            int tickMinor = themeMode == THEME_LIGHT ? Color.argb(170, 118, 128, 146) : Color.argb(165, 166, 180, 199);
            int cardinalColor = themeMode == THEME_LIGHT ? Color.rgb(28, 40, 58) : Color.rgb(247, 249, 252);
            int subLabelColor = themeMode == THEME_LIGHT ? Color.rgb(86, 96, 115) : Color.rgb(224, 232, 241);

            Paint outerShadow = new Paint(Paint.ANTI_ALIAS_FLAG);
            outerShadow.setStyle(Paint.Style.FILL);
            outerShadow.setColor(themeMode == THEME_LIGHT ? Color.argb(30, 36, 84, 170) : Color.argb(78, 10, 18, 30));
            outerShadow.setShadowLayer(dp(14), 0, dp(8), themeMode == THEME_LIGHT ? Color.argb(45, 60, 120, 255) : Color.argb(150, 18, 46, 90));
            canvas.drawCircle(cx, cy + dp(4), r * 0.93f, outerShadow);

            Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
            halo.setStyle(Paint.Style.FILL);
            halo.setColor(themeMode == THEME_LIGHT ? Color.argb(18, 80, 154, 255) : Color.argb(42, 56, 146, 255));
            canvas.drawCircle(cx, cy, r * 0.96f, halo);

            Paint face = new Paint(Paint.ANTI_ALIAS_FLAG);
            face.setStyle(Paint.Style.FILL);
            RadialGradient faceGradient = new RadialGradient(
                    cx, cy, r * 0.92f,
                    themeMode == THEME_LIGHT
                            ? new int[]{Color.rgb(20, 36, 58), Color.rgb(10, 22, 38), Color.rgb(3, 10, 20)}
                            : new int[]{Color.rgb(14, 32, 52), Color.rgb(8, 20, 35), Color.rgb(4, 10, 20)},
                    new float[]{0f, 0.62f, 1f},
                    Shader.TileMode.CLAMP);
            face.setShader(faceGradient);
            canvas.drawCircle(cx, cy, r * 0.89f, face);

            Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
            ring.setStyle(Paint.Style.STROKE);
            ring.setColor(ringBlue);
            ring.setStrokeWidth(dp(2));
            ring.setShadowLayer(dp(10), 0, 0, withAlpha(ringBlue, 180));
            canvas.drawCircle(cx, cy, r * 0.89f, ring);
            ring.setColor(withAlpha(ringBlue2, 170));
            ring.setStrokeWidth(dp(1));
            canvas.drawCircle(cx, cy, r * 0.85f, ring);

            Paint innerGlow = new Paint(Paint.ANTI_ALIAS_FLAG);
            innerGlow.setStyle(Paint.Style.STROKE);
            innerGlow.setColor(themeMode == THEME_LIGHT ? Color.argb(36, 120, 162, 220) : Color.argb(48, 92, 142, 194));
            innerGlow.setStrokeWidth(dp(1));
            for (float factor : new float[]{0.25f, 0.42f, 0.59f}) {
                canvas.drawCircle(cx, cy, r * factor, innerGlow);
            }
            Paint cross = new Paint(Paint.ANTI_ALIAS_FLAG);
            cross.setStyle(Paint.Style.STROKE);
            cross.setStrokeWidth(dp(1));
            cross.setColor(themeMode == THEME_LIGHT ? Color.argb(50, 106, 126, 150) : Color.argb(55, 108, 128, 152));
            canvas.drawLine(cx - r * 0.63f, cy, cx + r * 0.63f, cy, cross);
            canvas.drawLine(cx, cy - r * 0.63f, cx, cy + r * 0.63f, cross);

            drawAzimuthPanelTicks(canvas, cx, cy, r, tickMajor, tickMinor);
            if (azimuthPanelMode == PANEL_RUMBO) {
                drawRumboPanelLabels(canvas, cx, cy, r, cardinalColor, subLabelColor);
            } else {
                drawAzimuthPanelLabels(canvas, cx, cy, r, cardinalColor, subLabelColor);
            }

            drawPanelNorthNeedle(canvas, cx, cy, r, cardinalColor);
            if (directionAvailable) {
                drawPanelDirectionNeedle(canvas, cx, cy, r, Math.toRadians(azimuth - 90.0), ringBlue2);
            }
            drawPanelCenterHub(canvas, cx, cy, ringBlue);
        }

        private void drawAzimuthPanelTicks(Canvas canvas, float cx, float cy, float r, int majorColor, int minorColor) {
            Paint tick = new Paint(Paint.ANTI_ALIAS_FLAG);
            tick.setStyle(Paint.Style.STROKE);
            tick.setStrokeCap(Paint.Cap.ROUND);
            float density = getResources().getDisplayMetrics().density;
            for (int i = 0; i < 72; i++) {
                double a = Math.toRadians(i * 5 - 90);
                boolean cardinal = i % 18 == 0;
                boolean major = i % 9 == 0;
                boolean medium = i % 3 == 0;
                tick.setColor(cardinal || major ? majorColor : minorColor);
                tick.setStrokeWidth(cardinal ? 2.3f * density : (major ? 1.6f * density : (medium ? 1.1f * density : 0.8f * density)));
                float outerR = r * 0.82f;
                float innerR = cardinal ? r * 0.66f : (major ? r * 0.70f : (medium ? r * 0.74f : r * 0.77f));
                canvas.drawLine(
                        (float) (cx + Math.cos(a) * innerR),
                        (float) (cy + Math.sin(a) * innerR),
                        (float) (cx + Math.cos(a) * outerR),
                        (float) (cy + Math.sin(a) * outerR),
                        tick
                );
            }
        }

        private void drawAzimuthPanelLabels(Canvas canvas, float cx, float cy, float r, int cardinalColor, int degreeColor) {
            Paint cardinal = new Paint(Paint.ANTI_ALIAS_FLAG);
            cardinal.setColor(cardinalColor);
            cardinal.setTypeface(Typeface.DEFAULT_BOLD);
            cardinal.setTextAlign(Paint.Align.CENTER);
            cardinal.setTextSize(dp(13));
            canvas.drawText("N", cx, cy - r * 0.50f, cardinal);
            canvas.drawText("S", cx, cy + r * 0.60f, cardinal);
            canvas.drawText("E", cx + r * 0.57f, cy + dp(5), cardinal);
            canvas.drawText(spanishWestLabel ? "O" : "W", cx - r * 0.57f, cy + dp(5), cardinal);

            Paint degree = new Paint(Paint.ANTI_ALIAS_FLAG);
            degree.setColor(degreeColor);
            degree.setTextAlign(Paint.Align.CENTER);
            degree.setTypeface(Typeface.DEFAULT_BOLD);
            degree.setTextSize(dp(7));
            // 90° and 270° are represented by E/W, so omit them to avoid collisions.
            int[] vals = new int[]{0, 45, 135, 180, 225, 315};
            for (int degVal : vals) {
                double a = Math.toRadians(degVal - 90);
                float tr = (degVal == 0 || degVal == 180) ? r * 0.74f : r * 0.77f;
                float tyAdjust = degree.getTextSize() * 0.33f;
                canvas.drawText(String.valueOf(degVal),
                        (float) (cx + Math.cos(a) * tr),
                        (float) (cy + Math.sin(a) * tr + tyAdjust), degree);
            }
        }

        private void drawRumboPanelLabels(Canvas canvas, float cx, float cy, float r, int textColor, int subColor) {
            Paint cardinal = new Paint(Paint.ANTI_ALIAS_FLAG);
            cardinal.setColor(textColor);
            cardinal.setTypeface(Typeface.DEFAULT_BOLD);
            cardinal.setTextAlign(Paint.Align.CENTER);
            cardinal.setTextSize(dp(13));
            canvas.drawText("N", cx, cy - r * 0.50f, cardinal);
            canvas.drawText("S", cx, cy + r * 0.60f, cardinal);
            canvas.drawText("E", cx + r * 0.57f, cy + dp(5), cardinal);
            canvas.drawText(spanishWestLabel ? "O" : "W", cx - r * 0.57f, cy + dp(5), cardinal);

            Paint inter = new Paint(Paint.ANTI_ALIAS_FLAG);
            inter.setColor(subColor);
            inter.setTextAlign(Paint.Align.CENTER);
            inter.setTypeface(Typeface.DEFAULT_BOLD);
            inter.setTextSize(dp(7));
            drawTextAtAngle(canvas, "NE", cx, cy, r * 0.55f, -45, inter);
            drawTextAtAngle(canvas, "SE", cx, cy, r * 0.55f, 45, inter);
            drawTextAtAngle(canvas, "SW", cx, cy, r * 0.55f, 135, inter);
            drawTextAtAngle(canvas, "NW", cx, cy, r * 0.55f, -135, inter);
        }

        private void drawTextAtAngle(Canvas canvas, String text, float cx, float cy, float radius, float deg, Paint paint) {
            double a = Math.toRadians(deg - 90);
            float tyAdjust = paint.getTextSize() * 0.34f;
            canvas.drawText(text,
                    (float) (cx + Math.cos(a) * radius),
                    (float) (cy + Math.sin(a) * radius + tyAdjust),
                    paint);
        }

        private void drawPanelNorthNeedle(Canvas canvas, float cx, float cy, float r, int lightColor) {
            double rad = -Math.PI / 2.0;

            Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
            glow.setStyle(Paint.Style.FILL);
            glow.setColor(Color.argb(88, 255, 64, 64));
            glow.setShadowLayer(dp(10), 0, 0, Color.argb(175, 255, 58, 58));
            Path glowPath = createPanelNeedlePath(cx, cy, r * 0.53f, r * 0.20f, rad);
            canvas.drawPath(glowPath, glow);

            Paint red = new Paint(Paint.ANTI_ALIAS_FLAG);
            red.setStyle(Paint.Style.FILL);
            LinearGradient redGradient = new LinearGradient(
                    cx, cy + r * 0.05f,
                    cx, cy - r * 0.54f,
                    Color.rgb(120, 8, 16), Color.rgb(255, 86, 86), Shader.TileMode.CLAMP);
            red.setShader(redGradient);
            Path north = createPanelNeedlePath(cx, cy, r * 0.50f, r * 0.18f, rad);
            canvas.drawPath(north, red);

            Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
            edge.setStyle(Paint.Style.STROKE);
            edge.setStrokeWidth(dp(1));
            edge.setColor(Color.rgb(112, 10, 16));
            canvas.drawPath(north, edge);

            Paint highlight = new Paint(Paint.ANTI_ALIAS_FLAG);
            highlight.setStyle(Paint.Style.STROKE);
            highlight.setStrokeCap(Paint.Cap.ROUND);
            highlight.setStrokeWidth(dp(1));
            highlight.setColor(Color.argb(180, 255, 230, 230));
            canvas.drawLine(cx, cy - r * 0.02f, cx, cy - r * 0.41f, highlight);

            Paint tail = new Paint(Paint.ANTI_ALIAS_FLAG);
            tail.setStyle(Paint.Style.FILL);
            LinearGradient tailGrad = new LinearGradient(
                    cx, cy,
                    cx, cy + r * 0.18f,
                    Color.rgb(210, 215, 224), Color.rgb(92, 98, 108), Shader.TileMode.CLAMP);
            tail.setShader(tailGrad);
            Path southTail = createPanelNeedlePath(cx, cy, r * 0.17f, r * 0.08f, Math.PI / 2.0);
            canvas.drawPath(southTail, tail);

            Paint tailEdge = new Paint(Paint.ANTI_ALIAS_FLAG);
            tailEdge.setStyle(Paint.Style.STROKE);
            tailEdge.setStrokeWidth(dp(0.8f));
            tailEdge.setColor(Color.argb(145, 245, 248, 252));
            canvas.drawPath(southTail, tailEdge);
        }

        private void drawPanelDirectionNeedle(Canvas canvas, float cx, float cy, float r, double rad, int cyan) {
            Paint trail = new Paint(Paint.ANTI_ALIAS_FLAG);
            trail.setStyle(Paint.Style.STROKE);
            trail.setStrokeCap(Paint.Cap.ROUND);
            trail.setStrokeWidth(dp(5));
            trail.setColor(Color.argb(60, 126, 244, 255));
            trail.setShadowLayer(dp(10), 0, 0, Color.argb(155, 70, 210, 255));
            canvas.drawLine(cx, cy,
                    (float) (cx + Math.cos(rad) * r * 0.46f),
                    (float) (cy + Math.sin(rad) * r * 0.46f), trail);

            Paint beam = new Paint(Paint.ANTI_ALIAS_FLAG);
            beam.setStyle(Paint.Style.STROKE);
            beam.setStrokeCap(Paint.Cap.ROUND);
            beam.setStrokeWidth(2.7f * getResources().getDisplayMetrics().density);
            beam.setColor(Color.rgb(137, 246, 255));
            canvas.drawLine(cx, cy,
                    (float) (cx + Math.cos(rad) * r * 0.45f),
                    (float) (cy + Math.sin(rad) * r * 0.45f), beam);

            Paint pointer = new Paint(Paint.ANTI_ALIAS_FLAG);
            pointer.setStyle(Paint.Style.FILL);
            LinearGradient grad = new LinearGradient(
                    (float) (cx - Math.cos(rad) * r * 0.06f), (float) (cy - Math.sin(rad) * r * 0.06f),
                    (float) (cx + Math.cos(rad) * r * 0.52f), (float) (cy + Math.sin(rad) * r * 0.52f),
                    Color.rgb(109, 232, 247), Color.rgb(206, 255, 255), Shader.TileMode.CLAMP);
            pointer.setShader(grad);
            pointer.setShadowLayer(dp(8), 0, 0, withAlpha(cyan, 150));
            Path path = createPanelNeedlePath(cx, cy, r * 0.53f, r * 0.085f, rad);
            canvas.drawPath(path, pointer);
        }

        private Path createPanelNeedlePath(float cx, float cy, float tipLen, float baseLen, double rad) {
            double left = rad + Math.toRadians(13.5);
            double right = rad - Math.toRadians(13.5);
            Path path = new Path();
            path.moveTo((float) (cx + Math.cos(rad) * tipLen), (float) (cy + Math.sin(rad) * tipLen));
            path.lineTo((float) (cx + Math.cos(left) * baseLen), (float) (cy + Math.sin(left) * baseLen));
            path.lineTo((float) (cx + Math.cos(right) * baseLen), (float) (cy + Math.sin(right) * baseLen));
            path.close();
            return path;
        }

        private void drawPanelCenterHub(Canvas canvas, float cx, float cy, int ringBlue) {
            Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
            glow.setStyle(Paint.Style.FILL);
            glow.setColor(Color.argb(48, 88, 162, 255));
            canvas.drawCircle(cx, cy, dp(12), glow);

            Paint outer = new Paint(Paint.ANTI_ALIAS_FLAG);
            outer.setStyle(Paint.Style.FILL);
            RadialGradient metal = new RadialGradient(
                    cx - dp(1), cy - dp(1), dp(11),
                    new int[]{Color.rgb(255, 255, 255), Color.rgb(210, 216, 224), Color.rgb(126, 134, 145), Color.rgb(58, 65, 74)},
                    new float[]{0f, 0.20f, 0.58f, 1f},
                    Shader.TileMode.CLAMP);
            outer.setShader(metal);
            canvas.drawCircle(cx, cy, dp(9), outer);

            Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(dp(1.1f));
            ring.setColor(Color.argb(200, 255, 255, 255));
            canvas.drawCircle(cx, cy, dp(9), ring);

            Paint innerRing = new Paint(Paint.ANTI_ALIAS_FLAG);
            innerRing.setStyle(Paint.Style.STROKE);
            innerRing.setStrokeWidth(dp(1));
            innerRing.setColor(Color.argb(140, 82, 90, 100));
            canvas.drawCircle(cx, cy, dp(4.6f), innerRing);

            Paint core = new Paint(Paint.ANTI_ALIAS_FLAG);
            core.setStyle(Paint.Style.FILL);
            RadialGradient coreGrad = new RadialGradient(
                    cx - dp(0.6f), cy - dp(0.6f), dp(4.2f),
                    new int[]{Color.rgb(74, 80, 90), Color.rgb(28, 33, 40), Color.rgb(8, 10, 14)},
                    new float[]{0f, 0.55f, 1f},
                    Shader.TileMode.CLAMP);
            core.setShader(coreGrad);
            canvas.drawCircle(cx, cy, dp(3.6f), core);

            Paint spec = new Paint(Paint.ANTI_ALIAS_FLAG);
            spec.setStyle(Paint.Style.FILL);
            spec.setColor(Color.argb(180, 255, 255, 255));
            canvas.drawCircle(cx - dp(1.1f), cy - dp(1.1f), dp(0.9f), spec);
        }

        private void drawFuturisticCompass(Canvas canvas, float cx, float cy, float r, boolean targetMode) {
            int faceColor = lightDial ? Color.rgb(249, 251, 255)
                    : (themeMode == THEME_LIGHT ? Color.rgb(243, 248, 255) : Color.rgb(7, 16, 28));
            int innerColor = lightDial ? Color.rgb(241, 246, 255)
                    : (themeMode == THEME_LIGHT ? Color.rgb(235, 243, 255) : Color.rgb(11, 24, 40));
            int glowColor = themeMode == THEME_LIGHT ? Color.argb(28, 41, 116, 255) : Color.argb(40, 46, 127, 255);
            int majorColor = lightDial ? Color.rgb(31, 44, 60) : (themeMode == THEME_LIGHT ? Color.rgb(36, 48, 66) : Color.rgb(232, 238, 246));
            int minorColor = lightDial ? Color.rgb(120, 136, 155) : (themeMode == THEME_LIGHT ? Color.rgb(121, 140, 166) : Color.rgb(120, 138, 161));
            int ringBlue = themeMode == THEME_LIGHT ? Color.rgb(58, 129, 255) : Color.rgb(55, 146, 255);
            int ringBlueSoft = themeMode == THEME_LIGHT ? Color.rgb(129, 164, 228) : Color.rgb(72, 92, 120);

            Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
            halo.setStyle(Paint.Style.FILL);
            halo.setColor(glowColor);
            canvas.drawCircle(cx, cy, r * 0.98f, halo);

            Paint face = new Paint(Paint.ANTI_ALIAS_FLAG);
            face.setStyle(Paint.Style.FILL);
            face.setColor(faceColor);
            canvas.drawCircle(cx, cy, r * 0.96f, face);

            Paint inner = new Paint(Paint.ANTI_ALIAS_FLAG);
            inner.setStyle(Paint.Style.FILL);
            inner.setColor(innerColor);
            canvas.drawCircle(cx, cy, r * 0.84f, inner);

            Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(dp(4));
            ring.setColor(ringBlue);
            canvas.drawCircle(cx, cy, r, ring);
            ring.setStrokeWidth(dp(2));
            ring.setColor(themeMode == THEME_LIGHT ? Color.argb(185, 255, 255, 255) : Color.argb(195, 238, 244, 252));
            canvas.drawCircle(cx, cy, r * 0.93f, ring);
            ring.setStrokeWidth(dp(1));
            ring.setColor(ringBlueSoft);
            canvas.drawCircle(cx, cy, r * 0.72f, ring);

            Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
            grid.setStyle(Paint.Style.STROKE);
            grid.setStrokeWidth(dp(1));
            grid.setColor(themeMode == THEME_LIGHT ? Color.argb(55, 100, 120, 156) : Color.argb(58, 88, 115, 148));
            for (float factor : new float[]{0.22f, 0.36f, 0.50f, 0.64f}) {
                canvas.drawCircle(cx, cy, r * factor, grid);
            }
            canvas.drawLine(cx - r * 0.62f, cy, cx + r * 0.62f, cy, grid);
            canvas.drawLine(cx, cy - r * 0.62f, cx, cy + r * 0.62f, grid);

            Paint tick = new Paint(Paint.ANTI_ALIAS_FLAG);
            tick.setStyle(Paint.Style.STROKE);
            tick.setStrokeCap(Paint.Cap.ROUND);
            for (int i = 0; i < 72; i++) {
                double a = Math.toRadians(i * 5 - 90);
                boolean cardinal = i % 18 == 0;
                boolean major = i % 6 == 0;
                tick.setColor(cardinal || major ? majorColor : minorColor);
                float density = getResources().getDisplayMetrics().density;
                tick.setStrokeWidth(cardinal ? 2.4f * density : (major ? 1.5f * density : 0.9f * density));
                float outerR = r * 0.88f;
                float innerR = cardinal ? r * 0.68f : (major ? r * 0.75f : r * 0.80f);
                canvas.drawLine(
                        (float) (cx + Math.cos(a) * innerR),
                        (float) (cy + Math.sin(a) * innerR),
                        (float) (cx + Math.cos(a) * outerR),
                        (float) (cy + Math.sin(a) * outerR),
                        tick
                );
            }

            Paint cardinalPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            cardinalPaint.setColor(majorColor);
            cardinalPaint.setTypeface(Typeface.DEFAULT_BOLD);
            cardinalPaint.setTextAlign(Paint.Align.CENTER);
            cardinalPaint.setTextSize(dp(20));
            canvas.drawText("N", cx, cy - r * 0.52f, cardinalPaint);
            canvas.drawText("S", cx, cy + r * 0.60f, cardinalPaint);
            canvas.drawText("E", cx + r * 0.56f, cy + dp(6), cardinalPaint);
            canvas.drawText(spanishWestLabel ? "O" : "W", cx - r * 0.56f, cy + dp(6), cardinalPaint);

            Paint degreePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            degreePaint.setColor(minorColor);
            degreePaint.setTextAlign(Paint.Align.CENTER);
            degreePaint.setTypeface(Typeface.DEFAULT_BOLD);
            degreePaint.setTextSize(dp(9));
            for (int deg = 0; deg < 360; deg += 30) {
                double a = Math.toRadians(deg - 90);
                float tr = r * 0.74f;
                float tx = (float) (cx + Math.cos(a) * tr);
                float ty = (float) (cy + Math.sin(a) * tr + degreePaint.getTextSize() * 0.35f);
                canvas.drawText(String.valueOf(deg), tx, ty, degreePaint);
            }

            drawNorthNeedle(canvas, cx, cy, r, targetMode ? -Math.PI / 2.0 : (directionAvailable ? Math.toRadians(azimuth - 90.0) : -Math.PI / 2.0));

            if (targetMode && directionAvailable) {
                drawTargetArrow(canvas, cx, cy, r, Math.toRadians(azimuth - 90.0));
            }

            drawCenterHub(canvas, cx, cy, ringBlue);

            if (targetMode && directionAvailable == false && unavailableText != null && !unavailableText.trim().isEmpty()) {
                drawUnavailableText(canvas, cx, cy + r * 0.33f,
                        themeMode == THEME_LIGHT ? Color.rgb(86, 102, 122) : Color.rgb(176, 186, 198), dp(11));
            }
        }

        private void drawNorthNeedle(Canvas canvas, float cx, float cy, float r, double rad) {
            Paint north = new Paint(Paint.ANTI_ALIAS_FLAG);
            north.setStyle(Paint.Style.FILL);
            north.setColor(Color.rgb(232, 50, 61));
            Paint northEdge = new Paint(Paint.ANTI_ALIAS_FLAG);
            northEdge.setStyle(Paint.Style.STROKE);
            northEdge.setStrokeWidth(dp(1));
            northEdge.setColor(Color.rgb(132, 15, 23));

            Paint south = new Paint(Paint.ANTI_ALIAS_FLAG);
            south.setStyle(Paint.Style.FILL);
            south.setColor(themeMode == THEME_LIGHT ? Color.rgb(110, 176, 255) : Color.rgb(63, 146, 255));
            Paint southEdge = new Paint(Paint.ANTI_ALIAS_FLAG);
            southEdge.setStyle(Paint.Style.STROKE);
            southEdge.setStrokeWidth(dp(1));
            southEdge.setColor(themeMode == THEME_LIGHT ? Color.rgb(44, 104, 188) : Color.rgb(18, 79, 156));

            drawSlimNeedleShape(canvas, cx, cy, r * 0.78f, r * 0.14f, rad, north, northEdge);
            drawSlimNeedleShape(canvas, cx, cy, r * 0.55f, r * 0.12f, rad + Math.PI, south, southEdge);

            Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
            glow.setStyle(Paint.Style.STROKE);
            glow.setStrokeWidth(dp(2));
            glow.setColor(Color.argb(95, 255, 255, 255));
            canvas.drawLine(cx, cy,
                    (float) (cx + Math.cos(rad) * r * 0.55f),
                    (float) (cy + Math.sin(rad) * r * 0.55f),
                    glow);
        }

        private void drawSlimNeedleShape(Canvas canvas, float cx, float cy, float tipLen, float baseLen, double rad, Paint fill, Paint edge) {
            double left = rad + Math.toRadians(8.5);
            double right = rad - Math.toRadians(8.5);
            Path path = new Path();
            path.moveTo((float) (cx + Math.cos(rad) * tipLen), (float) (cy + Math.sin(rad) * tipLen));
            path.lineTo((float) (cx + Math.cos(left) * baseLen), (float) (cy + Math.sin(left) * baseLen));
            path.lineTo((float) (cx + Math.cos(right) * baseLen), (float) (cy + Math.sin(right) * baseLen));
            path.close();
            canvas.drawPath(path, fill);
            canvas.drawPath(path, edge);
        }

        private void drawTargetArrow(Canvas canvas, float cx, float cy, float r, double rad) {
            Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
            glow.setStyle(Paint.Style.FILL);
            glow.setColor(themeMode == THEME_LIGHT ? Color.argb(45, 44, 172, 255) : Color.argb(60, 47, 190, 255));
            Path glowPath = createArrowPath(cx, cy, r * 0.68f, r * 0.30f, rad);
            canvas.drawPath(glowPath, glow);

            Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(themeMode == THEME_LIGHT ? Color.rgb(59, 160, 255) : Color.rgb(74, 188, 255));
            Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
            edge.setStyle(Paint.Style.STROKE);
            edge.setStrokeWidth(dp(1));
            edge.setColor(themeMode == THEME_LIGHT ? Color.rgb(20, 88, 174) : Color.rgb(28, 104, 198));
            Path arrow = createArrowPath(cx, cy, r * 0.63f, r * 0.25f, rad);
            canvas.drawPath(arrow, fill);
            canvas.drawPath(arrow, edge);
        }

        private void drawAzimuthResultArrow(Canvas canvas, float cx, float cy, float r, double rad) {
            Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
            glow.setStyle(Paint.Style.FILL);
            glow.setColor(themeMode == THEME_LIGHT ? Color.argb(48, 255, 84, 84) : Color.argb(72, 255, 74, 74));
            Path glowPath = createArrowPath(cx, cy, r * 0.70f, r * 0.31f, rad);
            canvas.drawPath(glowPath, glow);

            Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(Color.rgb(244, 70, 70));
            Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
            edge.setStyle(Paint.Style.STROKE);
            edge.setStrokeWidth(dp(1));
            edge.setColor(Color.rgb(158, 28, 28));
            Path arrow = createArrowPath(cx, cy, r * 0.65f, r * 0.26f, rad);
            canvas.drawPath(arrow, fill);
            canvas.drawPath(arrow, edge);
        }

        private Path createArrowPath(float cx, float cy, float tipLen, float bodyLen, double rad) {
            double leftShoulder = rad + Math.toRadians(138);
            double rightShoulder = rad - Math.toRadians(138);
            double tailLeft = rad + Math.toRadians(90);
            double tailRight = rad - Math.toRadians(90);
            Path path = new Path();
            path.moveTo((float) (cx + Math.cos(rad) * tipLen), (float) (cy + Math.sin(rad) * tipLen));
            path.lineTo((float) (cx + Math.cos(leftShoulder) * bodyLen), (float) (cy + Math.sin(leftShoulder) * bodyLen));
            path.lineTo((float) (cx + Math.cos(rad + Math.PI) * bodyLen * 0.16f + Math.cos(tailLeft) * bodyLen * 0.08f),
                    (float) (cy + Math.sin(rad + Math.PI) * bodyLen * 0.16f + Math.sin(tailLeft) * bodyLen * 0.08f));
            path.lineTo((float) (cx + Math.cos(rad + Math.PI) * bodyLen * 0.26f),
                    (float) (cy + Math.sin(rad + Math.PI) * bodyLen * 0.26f));
            path.lineTo((float) (cx + Math.cos(rad + Math.PI) * bodyLen * 0.16f + Math.cos(tailRight) * bodyLen * 0.08f),
                    (float) (cy + Math.sin(rad + Math.PI) * bodyLen * 0.16f + Math.sin(tailRight) * bodyLen * 0.08f));
            path.lineTo((float) (cx + Math.cos(rightShoulder) * bodyLen), (float) (cy + Math.sin(rightShoulder) * bodyLen));
            path.close();
            return path;
        }

        private void drawCenterHub(Canvas canvas, float cx, float cy, int ringBlue) {
            Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
            glow.setStyle(Paint.Style.FILL);
            glow.setColor(themeMode == THEME_LIGHT ? Color.argb(38, 55, 136, 255) : Color.argb(55, 54, 142, 255));
            canvas.drawCircle(cx, cy, dp(15), glow);

            Paint hub = new Paint(Paint.ANTI_ALIAS_FLAG);
            hub.setStyle(Paint.Style.FILL);
            hub.setColor(themeMode == THEME_LIGHT ? Color.WHITE : Color.rgb(233, 239, 246));
            canvas.drawCircle(cx, cy, dp(11), hub);
            hub.setStyle(Paint.Style.STROKE);
            hub.setStrokeWidth(dp(2));
            hub.setColor(ringBlue);
            canvas.drawCircle(cx, cy, dp(11), hub);
            hub.setStyle(Paint.Style.FILL);
            hub.setColor(ringBlue);
            canvas.drawCircle(cx, cy, dp(4), hub);
        }

        private void drawUnavailableText(Canvas canvas, float cx, float cy, int color, float sizePx) {
            if (unavailableText == null || unavailableText.trim().isEmpty()) return;
            Paint unavailable = new Paint(Paint.ANTI_ALIAS_FLAG);
            unavailable.setColor(color);
            unavailable.setTextAlign(Paint.Align.CENTER);
            unavailable.setTypeface(Typeface.DEFAULT_BOLD);
            unavailable.setTextSize(sizePx);
            String[] lines = unavailableText.split("\n");
            float lineHeight = unavailable.getTextSize() * 1.12f;
            float startY = cy - ((lines.length - 1) * lineHeight / 2f);
            for (int i = 0; i < lines.length; i++) {
                canvas.drawText(lines[i], cx, startY + i * lineHeight, unavailable);
            }
        }
    }
}
