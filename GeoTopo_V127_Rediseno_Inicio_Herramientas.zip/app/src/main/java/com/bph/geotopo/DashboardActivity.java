package com.bph.geotopo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;

/** V127: Inicio "Cálculos topográficos" según el nuevo diseño. */
public class DashboardActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NativeUi.styleWindow(this);
        setContentView(buildScreen());
    }

    private View buildScreen() {
        FrameLayout root = NativeUi.screen(this);
        LinearLayout content = NativeUi.column(this);
        content.setPadding(NativeUi.dp(this, 16), 0, NativeUi.dp(this, 16), NativeUi.dp(this, 20));

        content.addView(DesignUi.homeHeader(this, v -> openSettings()));

        content.addView(DesignUi.twoColumns(this,
                DesignUi.heroCard(this, "gps", "GPS y mapas", "Posición, mapas y datos GNSS",
                        v -> open(GpsOverviewActivity.class)),
                DesignUi.heroCard(this, "field", "Herramientas de campo", "Instrumentos y utilidades de campo",
                        v -> open(FieldToolsActivity.class))));

        content.addView(DesignUi.sectionHeader(this, null, "ACCESO RÁPIDO"));
        content.addView(DesignUi.twoColumns(this,
                DesignUi.quickCard(this, "converter", "Conversor de unidades", "Longitud, área, ángulos y más",
                        v -> open(ConverterActivity.class)),
                DesignUi.quickCard(this, "compass", "Orientación y brújula", "Rumbos, norte y dirección",
                        v -> openTool("compass"))));
        content.addView(DesignUi.twoColumns(this,
                DesignUi.quickCard(this, "azimuth", "Azimut y rumbo", "Cálculos y conversiones",
                        v -> openTool("azimuth")),
                DesignUi.quickCard(this, "coordinates", "Coordenadas parciales", "Cálculos, offsets e intersecciones",
                        v -> openTool("coordinates"))));

        LinearLayout page = NativeUi.column(this);
        ScrollView scroll = NativeUi.scroll(this, content);
        scroll.setVerticalScrollBarEnabled(false);
        page.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        page.addView(DesignUi.bottomNav(this, 0,
                null,
                this::openPoints,
                () -> open(NotebookActivity.class),
                this::openSettings));
        root.addView(page, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return root;
    }

    private void open(Class<?> target) {
        startActivity(new Intent(this, target));
    }

    private void openTool(String key) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("single_tool", key);
        startActivity(intent);
    }

    private void openPoints() {
        Intent intent = new Intent(this, GpsOverviewActivity.class);
        intent.putExtra("gps_tools_action", "points");
        startActivity(intent);
    }

    private void openSettings() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("show_settings", true);
        intent.putExtra("settings_only", true);
        startActivity(intent);
    }

    @Override public void onContentChanged() {
        super.onContentChanged();
        NativeUi.applySystemBarInsets(this);
    }
}
