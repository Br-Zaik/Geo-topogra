package com.bph.geotopo;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import java.util.Locale;

/** V127: Herramientas de campo según el nuevo diseño (cálculos + captura + mapas). */
public class FieldToolsActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NativeUi.styleWindow(this);
        setContentView(buildScreen());
    }

    private View buildScreen() {
        FrameLayout root = NativeUi.screen(this);
        LinearLayout page = NativeUi.column(this);
        page.addView(DesignUi.toolsHeader(this, v -> finish(), lastAltitude()));

        LinearLayout c = NativeUi.column(this);
        c.setPadding(NativeUi.dp(this, 16), 0, NativeUi.dp(this, 16), NativeUi.dp(this, 20));

        // Diseño 1: Cálculos topográficos + Herramientas complementarias
        c.addView(DesignUi.sectionHeader(this, "target", "CÁLCULOS TOPOGRÁFICOS"));
        c.addView(DesignUi.full(this, DesignUi.wideCard(this, "polygon", true, "Poligonal cerrada",
                "Área, perímetro, cierres y compensación", v -> openTool("polygon"))));
        c.addView(DesignUi.twoColumns(this,
                DesignUi.stackCard(this, "level", "Nivelación", "Vista atrás, intermedia, adelante y ajuste",
                        v -> openTool("level")),
                DesignUi.stackCard(this, "distance", "Distancia y pendiente", "Distancia inclinada, horizontal y desnivel",
                        v -> openTool("distance"))));
        c.addView(DesignUi.full(this, DesignUi.wideCard(this, "two_hair", false, "Distancia por dos hilos",
                "Lecturas taquimétricas y cálculo de distancias", v -> openTool("two_hair"))));

        c.addView(DesignUi.sectionHeader(this, "compass", "HERRAMIENTAS COMPLEMENTARIAS"));
        c.addView(DesignUi.twoColumns(this,
                DesignUi.stackCard(this, "track", "Registro de recorridos GPS", "Trayectos, distancia, tiempo y puntos",
                        v -> open(TrackActivity.class)),
                DesignUi.stackCard(this, "tripod", "Coordenadas parciales", "Cálculos, offsets e intersecciones",
                        v -> openTool("coordinates"))));

        // Diseño 2: Captura y ubicación · Cálculos de campo · Mapas y archivos
        c.addView(DesignUi.sectionHeader(this, "target", "CAPTURA Y UBICACIÓN"));
        c.addView(DesignUi.twoColumns(this,
                DesignUi.gridCard(this, "stakeout", "Replanteo de punto", "Coordenadas, dirección, distancia y tolerancia",
                        v -> open(StakeoutActivity.class)),
                DesignUi.gridCard(this, "track_grid", "Registro de recorridos GPS", "Trayectos, distancia, tiempo y puntos",
                        v -> open(TrackActivity.class))));
        c.addView(DesignUi.twoColumns(this,
                DesignUi.gridCard(this, "quality", "Calidad GNSS", "Satélites, precisión, constelaciones y NMEA",
                        v -> open(GnssQualityActivity.class)),
                DesignUi.gridCard(this, "external", "GNSS externo Bluetooth", "Receptores NMEA emparejados",
                        v -> open(ExternalGnssActivity.class))));

        c.addView(DesignUi.sectionHeader(this, "calculator", "CÁLCULOS DE CAMPO"));
        c.addView(DesignUi.twoColumns(this,
                DesignUi.gridCard(this, "area", "Área y perímetro", "Cálculo por vértices, lados y rumbos",
                        v -> open(AreaActivity.class)),
                DesignUi.gridCard(this, "traverse", "Poligonales", "Abierta, cerrada, cierres y Bowditch",
                        v -> open(TraverseActivity.class))));
        c.addView(DesignUi.twoColumns(this,
                DesignUi.gridCard(this, "leveling", "Nivelación de campo", "Vista atrás, intermedia, adelante y ajuste",
                        v -> open(LevelingFieldActivity.class)),
                DesignUi.gridCard(this, "profile", "Perfiles y secciones", "Progresivas, cotas y pendientes",
                        v -> open(ProfileActivity.class))));

        c.addView(DesignUi.sectionHeader(this, "map", "MAPAS Y ARCHIVOS"));
        c.addView(DesignUi.twoColumns(this,
                DesignUi.gridCard(this, "offline", "Mapas sin internet", "Paquetes MBTiles propios o autorizados",
                        v -> open(OfflineMapActivity.class)),
                DesignUi.gridCard(this, "notebook", "Libreta de campo", "Puntos, códigos, cotas y observaciones",
                        v -> open(NotebookActivity.class))));

        ScrollView scroll = NativeUi.scroll(this, c);
        scroll.setVerticalScrollBarEnabled(false);
        page.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        page.addView(DesignUi.bottomNav(this, 0,
                this::goHome,
                this::openPoints,
                () -> open(NotebookActivity.class),
                this::openSettings));
        root.addView(page, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return root;
    }

    /** Altitud real de la última lectura GPS; si no existe, la cabecera no muestra nada. */
    private String lastAltitude() {
        try {
            SharedPreferences sp = getSharedPreferences("geo_topo_gps_points", MODE_PRIVATE);
            float alt = sp.getFloat("last_altitude_m", Float.NaN);
            if (Float.isNaN(alt) || Float.isInfinite(alt)) return null;
            return String.format(Locale.US, "%.0f m", alt);
        } catch (Exception e) {
            return null;
        }
    }

    private void open(Class<?> target) {
        startActivity(new Intent(this, target));
    }

    private void openTool(String key) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("single_tool", key);
        startActivity(intent);
    }

    private void goHome() {
        Intent intent = new Intent(this, DashboardActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }

    private void openPoints() {
        Intent intent = new Intent(this, GpsOverviewActivity.class);
        intent.putExtra("gps_tools_action", "points");
        startActivity(intent);
    }

    private void openSettings() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("show_settings", true);
        intent.putExtra("settings_only", true);
        startActivity(intent);
    }

    @Override public void onContentChanged() {
        super.onContentChanged();
        NativeUi.applySystemBarInsets(this);
    }
}
