# GeoTopo

Versión actual: **1.24.0**

## Herramientas principales

- GPS/GNSS y captura de puntos por proyectos.
- Mapas, búsqueda, medición, importación y exportación.
- Conversor de unidades.
- Orientación, brújula, azimut, rumbo y coordenadas parciales.
- Distancia, pendiente, poligonal y nivelación.
- Práctica de lectura de mira métrica tipo E con LS, LM y LI.

## Herramientas de campo

### Captura y ubicación

- Replanteo de punto con objetivo geográfico o UTM WGS84.
- Registro de recorrido GPS con notificación visible y exportación CSV/GPX.
- Calidad GNSS y datos NMEA.
- Receptor GNSS Bluetooth clásico SPP.

### Cálculos topográficos

- COGO directo, inverso, intersecciones, proyección, offset y división de línea.
- Área y perímetro.
- Poligonal abierta o cerrada con Bowditch.
- Nivelación de campo.
- Perfiles longitudinales y secciones transversales.

### Mapas, proyectos y archivos

- Mapas sin internet mediante MBTiles ráster importado por el usuario.
- Libreta de campo por proyecto y sistema de coordenadas/CRS.
- Importación y exportación CSV, GeoJSON, KML y JSON.

## Comportamiento de la interfaz

- Todas las secciones comienzan cerradas.
- Se retiró la fila de accesos rápidos duplicados de la parte superior.
- Las herramientas existentes conservan sus cálculos y su funcionamiento.

## Privacidad y precisión

GeoTopo no solicita ubicación permanente en segundo plano. El registro de recorrido solo se inicia por acción del usuario y mantiene una notificación visible. La precisión depende del dispositivo, la geometría satelital, el entorno y las condiciones de observación. Para trabajos centimétricos se necesita un receptor GNSS RTK o instrumental topográfico adecuado.

Los mapas offline deben provenir de paquetes propios o autorizados. Esta versión no realiza descarga masiva desde servidores públicos de teselas.


Actualización v1.27.5: se reemplazaron las imágenes field_*.png de Herramientas de campo para quitar el sombreado azul lateral incrustado y dejar la vista más limpia.
