package com.bph.geotopo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.GeomagneticField;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * V130: Ir a punto rediseñado desde cero. Radar animado, distancia grande con color de
 * proximidad, instrucción de giro, barra lejos/cerca y aviso de llegada.
 * GNSS y ROTATION_VECTOR reales; no sintetiza una brújula si falta sensor.
 */
public class GotoPointActivity extends Activity implements LocationListener, SensorEventListener {
    private static final int REQ = 7791;
    private static final long FIX_MAX_AGE = 15_000L;
    private static final int EDGE = Color.argb(120, 88, 148, 214);
    private static final int MINT = ProRadar.MINT;
    private static final int BLUE = Color.rgb(106, 191, 255);
    private static final int AMBER = ProRadar.AMBER;
    private LocationManager manager;
    private SensorManager sensors;
    private Sensor rotation;
    private TextView targetTitle, targetUtm, targetGeo, status, distance, instruction, bearing, heading,
            accuracy, speed, hint, scaleText;
    private ProRadar.NavRadarView radar;
    private ProRadar.ProximityBar proximity;
    private double targetLat = Double.NaN, targetLon = Double.NaN;
    private String targetName = "";
    private Location current;
    private double headingTrue = Double.NaN, azimuthTrue = Double.NaN, horizontalMeters = Double.NaN;
    private boolean gpsEnabled, compassReliable = true;
    private boolean headingFromMotion;
    private boolean manualScale;
    private boolean arrived;
    private float rangeMeters = 100;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() { update(); ui.postDelayed(this, 1000L); }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        NativeUi.styleWindow(this);
        manager = (LocationManager) getSystemService(LOCATION_SERVICE);
        sensors = (SensorManager) getSystemService(SENSOR_SERVICE);
        rotation = sensors == null ? null : sensors.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);

        FrameLayout root = NativeUi.screen(this);
        LinearLayout page = NativeUi.column(this);
        page.addView(NativeUi.pageHeader(this, "Ir a punto", "Radar de navegación GNSS · sin Internet",
                v -> finish(), "☰", v -> selectPoint()));
        LinearLayout body = NativeUi.column(this);
        body.setPadding(dp(14), dp(12), dp(14), dp(26));

        body.addView(buildTargetCard());

        // Tarjeta del radar
        LinearLayout radarCard = card();
        status = NativeUi.text(this, "●  ESPERANDO UBICACIÓN Y DESTINO", 11.5f, true, AMBER);
        status.setGravity(Gravity.CENTER);
        status.setLetterSpacing(.05f);
        status.setPadding(dp(10), dp(6), dp(10), dp(6));
        status.setBackground(NativeUi.rounded(Color.argb(160, 4, 20, 36), 14, 1, EDGE, this));
        LinearLayout.LayoutParams stLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        stLp.gravity = Gravity.CENTER_HORIZONTAL;
        radarCard.addView(status, stLp);
        radar = new ProRadar.NavRadarView(this);
        radarCard.addView(radar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(330)));
        distance = NativeUi.text(this, "—", 44f, true, Color.WHITE);
        distance.setGravity(Gravity.CENTER);
        distance.setIncludeFontPadding(false);
        radarCard.addView(distance);
        instruction = NativeUi.text(this, "Selecciona un destino", 15f, true, NativeUi.SUB);
        instruction.setGravity(Gravity.CENTER);
        instruction.setPadding(0, dp(4), 0, dp(10));
        radarCard.addView(instruction);
        proximity = new ProRadar.ProximityBar(this);
        LinearLayout.LayoutParams pxLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36));
        pxLp.setMargins(dp(8), 0, dp(8), dp(12));
        radarCard.addView(proximity, pxLp);

        LinearLayout scaleRow = NativeUi.row(this);
        scaleRow.addView(pill("−", () -> changeScale(true)), new LinearLayout.LayoutParams(dp(50), dp(42)));
        scaleText = NativeUi.text(this, "RADIO 100 m · AUTO", 12f, true, BLUE);
        scaleText.setGravity(Gravity.CENTER);
        scaleText.setOnClickListener(v -> { manualScale = false; adaptScale(); update(); });
        scaleRow.addView(scaleText, new LinearLayout.LayoutParams(0, dp(42), 1f));
        scaleRow.addView(pill("+", () -> changeScale(false)), new LinearLayout.LayoutParams(dp(50), dp(42)));
        radarCard.addView(scaleRow);
        TextView autoHint = NativeUi.text(this, "Toca el radio para volver a escala automática", 10.5f, false, NativeUi.SUB);
        autoHint.setGravity(Gravity.CENTER);
        autoHint.setPadding(0, dp(6), 0, 0);
        radarCard.addView(autoHint);
        body.addView(radarCard, spaced());

        // Datos
        LinearLayout r1 = NativeUi.row(this);
        bearing = stat(r1, "AZIMUT AL PUNTO", BLUE, true);
        heading = stat(r1, "ORIENTACIÓN", BLUE, false);
        body.addView(r1);
        LinearLayout r2 = NativeUi.row(this);
        accuracy = stat(r2, "PRECISIÓN GPS", AMBER, true);
        speed = stat(r2, "VELOCIDAD · LLEGADA", MINT, false);
        LinearLayout.LayoutParams r2lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        r2lp.topMargin = dp(8);
        body.addView(r2, r2lp);

        hint = NativeUi.text(this, "", 12f, false, NativeUi.SUB);
        hint.setPadding(dp(6), dp(14), dp(6), dp(6));
        body.addView(hint);

        page.addView(NativeUi.scroll(this, body), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(page, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        if (getIntent().hasExtra("target_lat") && getIntent().hasExtra("target_lon")) {
            targetLat = getIntent().getDoubleExtra("target_lat", Double.NaN);
            targetLon = getIntent().getDoubleExtra("target_lon", Double.NaN);
            targetName = getIntent().getStringExtra("target_name");
            if (targetName == null) targetName = "Punto";
        }
        update();
    }

    private int dp(int v) { return NativeUi.dp(this, v); }

    private LinearLayout card() {
        LinearLayout c = NativeUi.column(this);
        c.setPadding(dp(12), dp(12), dp(12), dp(14));
        c.setBackground(NativeUi.gradient(DesignUi.CARD_TOP, DesignUi.CARD_BOTTOM, 18, EDGE, this));
        return c;
    }

    private LinearLayout.LayoutParams spaced() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(12);
        return lp;
    }

    private View buildTargetCard() {
        LinearLayout c = NativeUi.row(this);
        c.setPadding(dp(12), dp(12), dp(10), dp(12));
        c.setBackground(NativeUi.gradient(DesignUi.CARD_TOP, DesignUi.CARD_BOTTOM, 18, EDGE, this));
        DesignUi.Glyph pin = new DesignUi.Glyph(this, "pin", MINT);
        FrameLayout badge = new FrameLayout(this);
        badge.setBackground(NativeUi.rounded(Color.argb(40, 74, 231, 176), 22, 1, Color.argb(140, 74, 231, 176), this));
        badge.addView(pin, new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
        c.addView(badge, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout labels = NativeUi.column(this);
        labels.setPadding(dp(11), 0, dp(6), 0);
        TextView cap = NativeUi.text(this, "DESTINO", 10.5f, true, NativeUi.SUB);
        cap.setLetterSpacing(.08f);
        labels.addView(cap);
        targetTitle = NativeUi.text(this, "Sin destino", 18f, true, Color.WHITE);
        targetTitle.setSingleLine(true);
        targetTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
        labels.addView(targetTitle);
        targetUtm = NativeUi.text(this, "Toca Elegir para seleccionar un punto", 11.5f, false, NativeUi.SUB);
        labels.addView(targetUtm);
        targetGeo = NativeUi.text(this, "", 11f, false, NativeUi.SUB);
        labels.addView(targetGeo);
        c.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView choose = NativeUi.text(this, "Elegir", 13f, true, Color.WHITE);
        choose.setGravity(Gravity.CENTER);
        choose.setPadding(dp(14), 0, dp(14), 0);
        choose.setBackground(NativeUi.gradient(Color.rgb(34, 110, 220), Color.rgb(20, 70, 170), 18,
                Color.argb(170, 140, 200, 255), this));
        choose.setOnClickListener(v -> selectPoint());
        c.addView(choose, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)));
        c.setOnClickListener(v -> selectPoint());
        c.setLayoutParams(spaced());
        return c;
    }

    private TextView pill(String label, Runnable click) {
        TextView v = NativeUi.text(this, label, 24f, true, Color.WHITE);
        v.setGravity(Gravity.CENTER);
        v.setIncludeFontPadding(false);
        v.setBackground(NativeUi.rounded(Color.rgb(13, 49, 80), 14, 1, EDGE, this));
        v.setOnClickListener(view -> click.run());
        return v;
    }

    private TextView stat(LinearLayout row, String caption, int color, boolean left) {
        LinearLayout c = NativeUi.column(this);
        c.setPadding(dp(12), dp(11), dp(8), dp(12));
        c.setBackground(NativeUi.gradient(DesignUi.CARD_TOP, DesignUi.CARD_BOTTOM, 16, EDGE, this));
        TextView cap = NativeUi.text(this, caption, 10.2f, true, NativeUi.SUB);
        cap.setLetterSpacing(.05f);
        cap.setSingleLine(true);
        c.addView(cap);
        TextView value = NativeUi.text(this, "—", 19f, true, color);
        value.setPadding(0, dp(6), 0, 0);
        value.setSingleLine(true);
        ResponsiveUi.configureCompactText(value, 19f, 12, 1);
        c.addView(value);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(left ? 0 : dp(4), 0, left ? dp(4) : 0, 0);
        row.addView(c, lp);
        return value;
    }

    /** Lista estilo "Choose waypoint": puntos ordenados por distancia + crear uno nuevo. */
    private void selectPoint() {
        JSONArray points;
        try { points = new JSONArray(getSharedPreferences("geo_topo_gps_points", MODE_PRIVATE)
                .getString("points_json", "[]")); } catch (Exception e) { points = new JSONArray(); }
        final List<JSONObject> valid = new ArrayList<>();
        for (int i = 0; i < points.length(); i++) {
            JSONObject p = points.optJSONObject(i);
            if (p == null) continue;
            if (validCoordinate(p.optDouble("latitude", Double.NaN), p.optDouble("longitude", Double.NaN))) valid.add(p);
        }
        final Location here = fresh(current) ? current : null;
        if (here != null) {
            Collections.sort(valid, (a, b) -> Float.compare(distanceTo(here, a), distanceTo(here, b)));
        }
        final String[] labels = new String[valid.size() + 1];
        labels[0] = "＋  Crear punto nuevo (coordenadas)";
        for (int i = 0; i < valid.size(); i++) {
            JSONObject p = valid.get(i);
            String extra = here != null ? "  ·  " + distanceLabel(distanceTo(here, p)) : "";
            labels[i + 1] = p.optString("symbol", "●") + "  " + p.optString("name", "Punto") + extra
                    + "\n      " + p.optString("project", "Proyecto general");
        }
        new AlertDialog.Builder(this).setTitle(valid.isEmpty() ? "No hay puntos guardados" : "Elegir destino")
                .setItems(labels, (dialog, which) -> {
                    if (which == 0) {
                        startActivity(new Intent(this, PointEditorActivity.class));
                        return;
                    }
                    JSONObject p = valid.get(which - 1);
                    targetLat = p.optDouble("latitude", Double.NaN);
                    targetLon = p.optDouble("longitude", Double.NaN);
                    targetName = p.optString("name", "Punto");
                    manualScale = false;
                    arrived = false;
                    update();
                }).setNegativeButton("Cancelar", null).show();
    }

    private float distanceTo(Location here, JSONObject p) {
        float[] r = new float[1];
        Location.distanceBetween(here.getLatitude(), here.getLongitude(),
                p.optDouble("latitude"), p.optDouble("longitude"), r);
        return r[0];
    }

    private boolean validCoordinate(double lat, double lon) {
        return Double.isFinite(lat) && Double.isFinite(lon) && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180;
    }

    private static String cardinal(double deg) {
        String[] n = {"N", "NE", "E", "SE", "S", "SO", "O", "NO"};
        return n[(int) Math.round(RadarNavigationMath.wrap(deg) / 45.0) % 8];
    }

    @Override protected void onResume() { super.onResume(); start(); ui.removeCallbacks(tick); ui.post(tick); }
    @Override protected void onPause() {
        ui.removeCallbacks(tick);
        stop();
        headingTrue = Double.NaN;
        headingFromMotion = false;
        current = null;
        super.onPause();
    }
    private void start() {
        if (sensors != null && rotation != null) sensors.registerListener(this, rotation, SensorManager.SENSOR_DELAY_UI);
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ);
            return;
        }
        try {
            gpsEnabled = manager != null && manager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            if (gpsEnabled && manager != null) {
                manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this);
                Location last = manager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (fresh(last)) current = new Location(last);
            }
        } catch (Exception ex) {
            hint.setText("No se pudo iniciar el GPS. Revisa los permisos de ubicación precisa.");
        }
        update();
    }
    private void stop() {
        try { if (manager != null) manager.removeUpdates(this); } catch (Exception ignored) { }
        if (sensors != null) sensors.unregisterListener(this);
    }
    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] result) {
        super.onRequestPermissionsResult(code, perms, result);
        if (code != REQ) return;
        if (result.length > 0 && result[0] == PackageManager.PERMISSION_GRANTED) start();
        else Toast.makeText(this, "Se necesita ubicación precisa para navegar.", Toast.LENGTH_LONG).show();
    }
    private boolean fresh(Location loc) {
        return loc != null && loc.getTime() > 0 &&
                Math.abs(System.currentTimeMillis() - loc.getTime()) <= FIX_MAX_AGE &&
                validCoordinate(loc.getLatitude(), loc.getLongitude());
    }
    @Override public void onLocationChanged(Location loc) {
        if (!fresh(loc)) return;
        current = new Location(loc);
        if ((rotation == null || !compassReliable) && (!loc.hasSpeed() || loc.getSpeed() < 1.5f || !loc.hasBearing())) {
            headingTrue = Double.NaN;
            headingFromMotion = false;
        }
        if ((rotation == null || !compassReliable) && loc.hasSpeed() && loc.getSpeed() >= 1.5f && loc.hasBearing()) {
            headingTrue = loc.getBearing();
            headingFromMotion = true;
        }
        update();
    }
    @Override public void onProviderEnabled(String provider) { gpsEnabled = true; update(); }
    @Override public void onProviderDisabled(String provider) {
        gpsEnabled = false;
        current = null;
        azimuthTrue = Double.NaN;
        update();
    }
    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {
        if (rotation != null && sensor.getType() == rotation.getType()) {
            compassReliable = accuracy != SensorManager.SENSOR_STATUS_UNRELIABLE;
            if (!compassReliable && !headingFromMotion) headingTrue = Double.NaN;
            update();
        }
    }
    @Override public void onSensorChanged(SensorEvent event) {
        if (rotation == null || event.sensor.getType() != rotation.getType()) return;
        if (!compassReliable) return;
        float[] matrix = new float[9];
        float[] orientation = new float[3];
        SensorManager.getRotationMatrixFromVector(matrix, event.values);
        SensorManager.getOrientation(matrix, orientation);
        double magnetic = (Math.toDegrees(orientation[0]) + 360) % 360;
        if (fresh(current)) {
            GeomagneticField field = new GeomagneticField((float) current.getLatitude(),
                    (float) current.getLongitude(), current.hasAltitude() ? (float) current.getAltitude() : 0,
                    System.currentTimeMillis());
            double next = RadarNavigationMath.wrap(magnetic + field.getDeclination());
            if (Double.isFinite(headingTrue) && !headingFromMotion) {
                double delta = RadarNavigationMath.relativeAngle(next, headingTrue);
                headingTrue = RadarNavigationMath.wrap(headingTrue + 0.22 * delta);
            } else headingTrue = next;
            headingFromMotion = false;
            update();
        } else {
            headingTrue = Double.NaN; // Sin posición, no afirmar una declinación ni orientación verdadera.
            update();
        }
    }
    private void changeScale(boolean zoomIn) {
        rangeMeters = RadarNavigationMath.manualRange(rangeMeters, zoomIn);
        manualScale = true;
        update();
    }
    private void adaptScale() {
        if (manualScale || !Double.isFinite(horizontalMeters)) return;
        rangeMeters = RadarNavigationMath.autoRange(horizontalMeters);
    }
    private String fmt(double value) { return String.format(Locale.getDefault(), "%.1f", value); }
    private String distanceLabel(double meters) {
        return meters >= 1000 ? fmt(meters / 1000) + " km" : fmt(meters) + " m";
    }
    private void update() {
        if (targetTitle == null) return;
        boolean target = validCoordinate(targetLat, targetLon);
        targetTitle.setText(target ? targetName : "Sin destino");
        if (target) {
            CoordinateUtils.Utm u = CoordinateUtils.toUtm(targetLat, targetLon);
            targetUtm.setText(u.valid ? String.format(Locale.US, "UTM %s  E %.3f  N %.3f",
                    CoordinateUtils.zoneWithBand(targetLat, targetLon), u.easting, u.northing) : "");
            targetGeo.setText(String.format(Locale.US, "WGS84  %.6f°, %.6f°", targetLat, targetLon));
        } else {
            targetUtm.setText("Toca Elegir para seleccionar un punto");
            targetGeo.setText("");
        }
        if (!fresh(current)) current = null;
        boolean positioned = gpsEnabled && current != null;
        double acc = positioned && current.hasAccuracy() ? current.getAccuracy() : Double.NaN;
        heading.setText(Double.isFinite(headingTrue) && positioned
                ? fmt0(headingTrue) + "° " + cardinal(headingTrue) : positioned ? "Sin brújula" : "—");
        accuracy.setText(Double.isFinite(acc) ? "±" + fmt(acc) + " m" : "—");
        if (!positioned || !target) {
            horizontalMeters = Double.NaN;
            azimuthTrue = Double.NaN;
            arrived = false;
            distance.setText("—");
            distance.setTextColor(Color.WHITE);
            bearing.setText("—");
            speed.setText("—");
            instruction.setText(!target ? "Selecciona un destino" : "Esperando señal GPS");
            instruction.setTextColor(NativeUi.SUB);
            status.setText(!gpsEnabled ? "●  GPS APAGADO" : !positioned ? "●  ESPERANDO POSICIÓN ACTUAL"
                    : "●  SELECCIONA UN DESTINO");
            status.setTextColor(AMBER);
            hint.setText(!gpsEnabled ? "Activa la ubicación del celular para obtener coordenadas reales."
                    : !positioned ? "Esperando posición GNSS reciente. Ve al aire libre si no encuentra señal."
                    : "Elige un punto guardado o crea uno nuevo con sus coordenadas.");
        } else {
            float[] data = new float[3];
            Location.distanceBetween(current.getLatitude(), current.getLongitude(), targetLat, targetLon, data);
            horizontalMeters = data[0];
            azimuthTrue = RadarNavigationMath.wrap(data[1]);
            adaptScale();
            int prox = ProRadar.NavRadarView.proximityColor(horizontalMeters);
            distance.setText(distanceLabel(horizontalMeters));
            distance.setTextColor(prox);
            bearing.setText(fmt0(azimuthTrue) + "° " + cardinal(azimuthTrue));
            boolean nowArrived = RadarNavigationMath.withinAccuracy(horizontalMeters, acc) || horizontalMeters <= 3;
            if (nowArrived && !arrived) {
                radar.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                Toast.makeText(this, "Llegaste a " + targetName, Toast.LENGTH_SHORT).show();
            }
            if (!nowArrived && horizontalMeters > Math.max(8, Double.isFinite(acc) ? acc * 2 : 8)) arrived = false;
            else if (nowArrived) arrived = true;

            if (current.hasSpeed() && current.getSpeed() >= .5f) {
                double eta = horizontalMeters / current.getSpeed();
                speed.setText(String.format(Locale.US, "%.1f km/h · %s", current.getSpeed() * 3.6, eta(eta)));
            } else speed.setText("Detenido");

            if (arrived) {
                instruction.setText("Estás en el punto (margen del GPS)");
                instruction.setTextColor(MINT);
            } else if (Double.isFinite(headingTrue)) {
                double rel = RadarNavigationMath.relativeAngle(azimuthTrue, headingTrue);
                if (Math.abs(rel) <= 12) instruction.setText("↑  Sigue recto");
                else if (Math.abs(rel) >= 160) instruction.setText("↓  Date la vuelta");
                else instruction.setText((rel > 0 ? "↱  Gira " : "↰  Gira ") + fmt0(Math.abs(rel)) + "° a la "
                        + (rel > 0 ? "derecha" : "izquierda"));
                instruction.setTextColor(Color.WHITE);
            } else {
                instruction.setText("Rumbo " + fmt0(azimuthTrue) + "° " + cardinal(azimuthTrue) + " · norte arriba");
                instruction.setTextColor(NativeUi.SUB);
            }
            status.setText(arrived ? "●  DESTINO ALCANZADO" : Double.isFinite(headingTrue)
                    ? "●  NAVEGACIÓN ACTIVA" : "●  SIN BRÚJULA · NORTE ARRIBA");
            status.setTextColor(arrived ? MINT : Double.isFinite(headingTrue) ? MINT : AMBER);
            hint.setText(arrived ? "Dentro del margen del GPS. No sustituye un replanteo topográfico preciso."
                    : !Double.isFinite(headingTrue) ? "Sin orientación confiable: el radar queda con el norte arriba."
                    : headingFromMotion ? "Orientación por desplazamiento GPS. Sigue caminando para mantenerla."
                    : !compassReliable ? "Brújula poco confiable. Aléjate de metales y mueve el celular en forma de 8."
                    : "La flecha apunta al destino respecto al frente del celular. Distancia en línea recta.");
        }
        scaleText.setText("RADIO " + distanceLabel(rangeMeters) + (manualScale ? " · MANUAL" : " · AUTO"));
        if (radar != null) {
            if (positioned) {
                JSONArray all;
                try { all = new JSONArray(getSharedPreferences("geo_topo_gps_points", MODE_PRIVATE).getString("points_json", "[]")); }
                catch (Exception e) { all = new JSONArray(); }
                List<double[]> vals = new ArrayList<>();
                List<String> names = new ArrayList<>();
                for (int i = 0; i < all.length() && vals.size() < 60; i++) {
                    JSONObject o = all.optJSONObject(i);
                    if (o == null) continue;
                    double la = o.optDouble("latitude", Double.NaN), lo = o.optDouble("longitude", Double.NaN);
                    if (!validCoordinate(la, lo) || (Math.abs(la - targetLat) < 1e-9 && Math.abs(lo - targetLon) < 1e-9)) continue;
                    float[] r = new float[2];
                    Location.distanceBetween(current.getLatitude(), current.getLongitude(), la, lo, r);
                    vals.add(new double[]{r[0], RadarNavigationMath.wrap(r[1])});
                    names.add(o.optString("name", "Punto"));
                }
                double[] dd = new double[vals.size()], bb = new double[vals.size()];
                for (int i = 0; i < vals.size(); i++) { dd[i] = vals.get(i)[0]; bb[i] = vals.get(i)[1]; }
                radar.setOthers(dd, bb, names.toArray(new String[0]));
            } else radar.setOthers(null, null, null);
        }
        if (radar != null) radar.setState(horizontalMeters, azimuthTrue, positioned ? headingTrue : Double.NaN,
                acc, rangeMeters, arrived);
        if (proximity != null) proximity.setDistance(horizontalMeters);
    }

    private String fmt0(double v) { return String.format(Locale.US, "%.0f", v); }

    private static String eta(double seconds) {
        if (!Double.isFinite(seconds)) return "—";
        long s = Math.round(seconds);
        if (s < 60) return s + " s";
        if (s < 3600) return (s / 60) + " min";
        return (s / 3600) + " h " + ((s % 3600) / 60) + " min";
    }

    @Override public void onContentChanged() { super.onContentChanged(); NativeUi.applySystemBarInsets(this); }
}
