package com.bph.geotopo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * V130: radares profesionales animados (~30 fps, se detienen si la vista no está visible).
 * Solo dibujan datos reales entregados por el receptor / GPS; la animación es decorativa.
 */
public final class ProRadar {
    private ProRadar() {}

    static final int AMBER = Color.rgb(255, 196, 92);
    static final int MINT = Color.rgb(74, 231, 176);
    static final int RED = Color.rgb(255, 96, 96);
    static final int SKY = Color.rgb(96, 176, 255);
    static final int TEXT = Color.rgb(236, 244, 252);
    static final int DIM = Color.rgb(150, 178, 206);

    /** Base común: bucle de animación que se pausa sola. */
    abstract static class Animated extends View {
        protected final float d;
        protected long startMs = SystemClock.uptimeMillis();
        private boolean attached;
        private final Runnable frame = new Runnable() {
            @Override public void run() {
                if (!attached || getWindowVisibility() != VISIBLE || !isShown()) return;
                invalidate();
                postDelayed(this, 33);
            }
        };
        Animated(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
            setLayerType(LAYER_TYPE_HARDWARE, null);
        }
        protected float t() { return (SystemClock.uptimeMillis() - startMs) / 1000f; }
        protected void kick() { removeCallbacks(frame); post(frame); }
        @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); attached = true; kick(); }
        @Override protected void onDetachedFromWindow() { attached = false; removeCallbacks(frame); super.onDetachedFromWindow(); }
        @Override protected void onWindowVisibilityChanged(int v) { super.onWindowVisibilityChanged(v); if (v == VISIBLE) kick(); }
        @Override protected void onVisibilityChanged(View changed, int v) { super.onVisibilityChanged(changed, v); if (v == VISIBLE) kick(); }
    }

    static int alpha(int color, int a) {
        return Color.argb(Math.max(0, Math.min(255, a)), Color.red(color), Color.green(color), Color.blue(color));
    }

    static int constellationColor(String prefix) {
        if ("G".equals(prefix)) return Color.rgb(72, 169, 255);
        if ("R".equals(prefix)) return Color.rgb(255, 160, 80);
        if ("E".equals(prefix)) return Color.rgb(176, 140, 255);
        if ("C".equals(prefix)) return Color.rgb(98, 222, 232);
        if ("J".equals(prefix)) return Color.rgb(247, 136, 180);
        if ("I".equals(prefix)) return Color.rgb(241, 205, 108);
        if ("S".equals(prefix)) return Color.rgb(200, 200, 200);
        return Color.rgb(157, 186, 206);
    }

    // =====================================================================
    // Cielo GNSS
    // =====================================================================
    public static class SkyRadarView extends Animated {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Matrix m = new Matrix();
        private final List<GnssSkyBridge.Satellite> sats = new ArrayList<>();
        private SweepGradient sweepShader;
        private float lastR = -1;

        public SkyRadarView(Context c) {
            super(c);
            txt.setTypeface(Typeface.create("sans", Typeface.BOLD));
            txt.setTextAlign(Paint.Align.CENTER);
        }

        public void setSatellites(List<GnssSkyBridge.Satellite> list) {
            sats.clear();
            if (list != null) sats.addAll(list);
            kick();
        }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            float cx = w / 2f, cy = h / 2f;
            float r = Math.min(w, h) / 2f - 26 * d;
            if (r <= 0) return;
            float time = t();

            // Disco con degradado de cielo
            p.setStyle(Paint.Style.FILL);
            p.setShader(new RadialGradient(cx, cy, r, new int[]{Color.rgb(16, 58, 98), Color.rgb(8, 34, 62),
                    Color.rgb(3, 18, 34)}, new float[]{0f, .7f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, r, p);
            p.setShader(null);

            // Anillos de elevación 0°, 30°, 60° y cenit
            p.setStyle(Paint.Style.STROKE);
            for (int i = 1; i <= 3; i++) {
                float rr = r * i / 3f;
                p.setStrokeWidth(i == 3 ? 2 * d : d);
                p.setColor(i == 3 ? Color.rgb(70, 130, 190) : alpha(SKY, 70));
                c.drawCircle(cx, cy, rr, p);
            }
            p.setPathEffect(new DashPathEffect(new float[]{4 * d, 5 * d}, 0));
            p.setStrokeWidth(d);
            p.setColor(alpha(SKY, 60));
            for (int a = 0; a < 180; a += 30) {
                double rad = Math.toRadians(a);
                float dx = (float) Math.sin(rad) * r, dy = (float) Math.cos(rad) * r;
                c.drawLine(cx - dx, cy + dy, cx + dx, cy - dy, p);
            }
            p.setPathEffect(null);
            txt.setTextSize(9 * d);
            txt.setColor(DIM);
            c.drawText("60°", cx + 4 * d, cy - r / 3f + 11 * d, txt);
            c.drawText("30°", cx + 4 * d, cy - 2 * r / 3f + 11 * d, txt);

            // Bisel con marcas cada 5° y rótulos cada 30°
            for (int a = 0; a < 360; a += 5) {
                double rad = Math.toRadians(a);
                boolean major = a % 30 == 0;
                float r1 = r + (major ? 2 : 3) * d, r2 = r + (major ? 9 : 6) * d;
                p.setStrokeWidth(major ? 1.8f * d : d);
                p.setColor(major ? TEXT : alpha(DIM, 150));
                c.drawLine(cx + (float) Math.sin(rad) * r1, cy - (float) Math.cos(rad) * r1,
                        cx + (float) Math.sin(rad) * r2, cy - (float) Math.cos(rad) * r2, p);
            }
            String[] card = {"N", "30", "60", "E", "120", "150", "S", "210", "240", "O", "300", "330"};
            for (int i = 0; i < 12; i++) {
                double rad = Math.toRadians(i * 30);
                boolean main = i % 3 == 0;
                txt.setTextSize((main ? 13 : 9) * d);
                txt.setColor(i == 0 ? AMBER : main ? TEXT : DIM);
                float rr = r + 18 * d;
                c.drawText(card[i], cx + (float) Math.sin(rad) * rr,
                        cy - (float) Math.cos(rad) * rr + txt.getTextSize() * .36f, txt);
            }

            // Barrido giratorio con estela
            float sweepDeg = (time * 60f) % 360f;
            if (sweepShader == null || lastR != r) {
                sweepShader = new SweepGradient(cx, cy, new int[]{alpha(MINT, 0), alpha(MINT, 0), alpha(MINT, 90)},
                        new float[]{0f, .80f, 1f});
                lastR = r;
            }
            m.reset();
            m.setRotate(sweepDeg - 90, cx, cy);
            sweepShader.setLocalMatrix(m);
            p.setStyle(Paint.Style.FILL);
            p.setShader(sweepShader);
            c.drawCircle(cx, cy, r, p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.6f * d);
            p.setColor(alpha(MINT, 200));
            double srad = Math.toRadians(sweepDeg);
            c.drawLine(cx, cy, cx + (float) Math.sin(srad) * r, cy - (float) Math.cos(srad) * r, p);

            // Satélites reales
            int shown = 0;
            for (GnssSkyBridge.Satellite s : sats) {
                if (!Float.isFinite(s.elevation) || s.elevation < 0 || s.elevation > 90 || !Float.isFinite(s.azimuth)) continue;
                shown++;
                double a = Math.toRadians(s.azimuth);
                float rr = r * (1 - s.elevation / 90f);
                float x = cx + (float) Math.sin(a) * rr, y = cy - (float) Math.cos(a) * rr;
                float cn = Float.isFinite(s.cn0) ? Math.max(0, Math.min(50, s.cn0)) : 0;
                float size = (5.5f + cn / 50f * 5f) * d;
                int col = constellationColor(s.prefix);
                // Eco: brilla cuando el barrido pasa por encima
                float diff = (float) ((sweepDeg - s.azimuth + 360) % 360);
                float echo = diff < 40 ? 1f - diff / 40f : 0f;
                if (s.used) {
                    float pulse = (float) (0.5 + 0.5 * Math.sin(time * 3 + s.svid));
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(alpha(MINT, (int) (40 + 50 * pulse + 80 * echo)));
                    c.drawCircle(x, y, size * (1.9f + .4f * pulse), p);
                    p.setColor(col);
                    c.drawCircle(x, y, size, p);
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2 * d);
                    p.setColor(MINT);
                    c.drawCircle(x, y, size + 2.5f * d, p);
                } else {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(alpha(col, (int) (60 + 120 * echo)));
                    c.drawCircle(x, y, size, p);
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(1.5f * d);
                    p.setColor(col);
                    c.drawCircle(x, y, size, p);
                }
                txt.setTextSize(8.5f * d);
                txt.setColor(TEXT);
                c.drawText((s.prefix == null ? "?" : s.prefix) + s.svid, x, y - size - 4 * d, txt);
            }

            // Cenit
            p.setStyle(Paint.Style.FILL);
            p.setColor(alpha(TEXT, 180));
            c.drawCircle(cx, cy, 2.2f * d, p);

            if (shown == 0) {
                txt.setTextSize(12 * d);
                txt.setColor(DIM);
                c.drawText("Sin satélites con posición en el cielo", cx, cy + r * .55f, txt);
            }
        }
    }

    // =====================================================================
    // Navegación "Ir a punto"
    // =====================================================================
    public static class NavRadarView extends Animated {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final Matrix m = new Matrix();
        private SweepGradient sweepShader;
        private float shaderCx = -1, shaderCy = -1;

        // Estado (siempre real; NaN = sin dato)
        private double distanceM = Double.NaN, bearingTrue = Double.NaN, heading = Double.NaN;
        private double accuracyM = Double.NaN;
        private float range = 100f;
        private boolean arrived;
        // Otros puntos guardados (distancia m, azimut verdadero, nombre)
        private double[] otherDist = new double[0], otherBearing = new double[0];
        private String[] otherNames = new String[0];
        // Interpolación suave del objetivo
        private float shownAngle = Float.NaN, shownRatio = Float.NaN;

        public NavRadarView(Context c) {
            super(c);
            txt.setTypeface(Typeface.create("sans", Typeface.BOLD));
            txt.setTextAlign(Paint.Align.CENTER);
        }

        public void setState(double distance, double bearing, double headingTrue, double accuracy,
                             float rangeMeters, boolean isArrived) {
            distanceM = distance;
            bearingTrue = bearing;
            heading = headingTrue;
            accuracyM = accuracy;
            range = Math.max(1f, rangeMeters);
            arrived = isArrived;
            kick();
        }

        public void setOthers(double[] dist, double[] bearing, String[] names) {
            otherDist = dist == null ? new double[0] : dist;
            otherBearing = bearing == null ? new double[0] : bearing;
            otherNames = names == null ? new String[0] : names;
        }

        /** Color de proximidad: rojo lejos → ámbar → verde cerca. */
        static int proximityColor(double meters) {
            if (!Double.isFinite(meters)) return DIM;
            if (meters <= 5) return MINT;
            if (meters <= 30) return Color.rgb(150, 230, 120);
            if (meters <= 150) return AMBER;
            return RED;
        }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            float cx = w / 2f, cy = h / 2f;
            float r = Math.min(w, h) / 2f - 24 * d;
            if (r <= 0) return;
            float time = t();
            boolean hasHeading = Double.isFinite(heading);
            double frame = hasHeading ? heading : 0;
            boolean hasTarget = Double.isFinite(distanceM) && Double.isFinite(bearingTrue);
            int prox = proximityColor(distanceM);

            // Fondo
            p.setStyle(Paint.Style.FILL);
            p.setShader(new RadialGradient(cx, cy, r, new int[]{Color.rgb(10, 52, 72), Color.rgb(5, 30, 50),
                    Color.rgb(2, 16, 30)}, new float[]{0f, .72f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, r, p);
            p.setShader(null);

            // Anillos de distancia con rótulo
            p.setStyle(Paint.Style.STROKE);
            txt.setTextSize(9 * d);
            txt.setColor(DIM);
            for (int i = 1; i <= 4; i++) {
                float rr = r * i / 4f * .92f;
                p.setStrokeWidth(d);
                p.setColor(alpha(SKY, i == 4 ? 110 : 60));
                c.drawCircle(cx, cy, rr, p);
                c.drawText(shortDistance(range * i / 4f), cx + rr * .70f, cy - rr * .70f, txt);
            }

            // Pulsos que salen del centro (sonar)
            for (int k = 0; k < 3; k++) {
                float ph = ((time * .55f) + k / 3f) % 1f;
                p.setStrokeWidth(2 * d);
                p.setColor(alpha(prox == DIM ? SKY : prox, (int) (120 * (1 - ph))));
                c.drawCircle(cx, cy, r * .92f * ph, p);
            }

            // Bisel giratorio con la orientación del teléfono
            for (int a = 0; a < 360; a += 5) {
                double rad = Math.toRadians(a - frame);
                boolean major = a % 30 == 0;
                float r1 = r + 2 * d, r2 = r + (major ? 9 : 5) * d;
                p.setStrokeWidth(major ? 1.8f * d : d);
                p.setColor(major ? TEXT : alpha(DIM, 140));
                c.drawLine(cx + (float) Math.sin(rad) * r1, cy - (float) Math.cos(rad) * r1,
                        cx + (float) Math.sin(rad) * r2, cy - (float) Math.cos(rad) * r2, p);
            }
            String[] card = {"N", "E", "S", "O"};
            for (int i = 0; i < 4; i++) {
                double rad = Math.toRadians(i * 90 - frame);
                txt.setTextSize(13 * d);
                txt.setColor(i == 0 ? AMBER : TEXT);
                float rr = r + 17 * d;
                c.drawText(card[i], cx + (float) Math.sin(rad) * rr, cy - (float) Math.cos(rad) * rr + 4.5f * d, txt);
            }

            // Barrido
            float sweepDeg = (time * 90f) % 360f;
            if (sweepShader == null || shaderCx != cx || shaderCy != cy) {
                sweepShader = new SweepGradient(cx, cy, new int[]{alpha(SKY, 0), alpha(SKY, 0), alpha(SKY, 80)},
                        new float[]{0f, .82f, 1f});
                shaderCx = cx; shaderCy = cy;
            }
            m.reset();
            m.setRotate(sweepDeg - 90, cx, cy);
            sweepShader.setLocalMatrix(m);
            p.setStyle(Paint.Style.FILL);
            p.setShader(sweepShader);
            c.drawCircle(cx, cy, r * .92f, p);
            p.setShader(null);

            // Halo de precisión GPS alrededor del usuario
            if (Double.isFinite(accuracyM) && accuracyM > 0) {
                float ar = (float) Math.min(r * .92f, r * .92f * accuracyM / range);
                p.setStyle(Paint.Style.FILL);
                p.setColor(alpha(SKY, 40));
                c.drawCircle(cx, cy, Math.max(ar, 6 * d), p);
            }

            // Otros puntos guardados dentro del radio
            int n = Math.min(otherDist.length, Math.min(otherBearing.length, otherNames.length));
            if (Double.isFinite(frame)) for (int i = 0; i < n; i++) {
                if (!Double.isFinite(otherDist[i]) || !Double.isFinite(otherBearing[i]) || otherDist[i] > range) continue;
                double oa = Math.toRadians(RadarNavigationMath.relativeAngle(otherBearing[i], frame));
                float od = r * .92f * (float) Math.max(.04, otherDist[i] / range);
                float ox = cx + (float) Math.sin(oa) * od, oy = cy - (float) Math.cos(oa) * od;
                p.setStyle(Paint.Style.FILL);
                p.setColor(alpha(Color.WHITE, 60));
                c.drawCircle(ox, oy, 7 * d, p);
                p.setColor(Color.rgb(235, 52, 52));
                c.drawCircle(ox, oy, 4 * d, p);
                txt.setTextSize(9 * d);
                txt.setColor(alpha(TEXT, 210));
                c.drawText(otherNames[i], ox, oy - 8 * d, txt);
            }

            if (hasTarget) {
                float targetAngle = (float) RadarNavigationMath.relativeAngle(bearingTrue, frame);
                float ratio = (float) Math.min(1.0, distanceM / range);
                if (Float.isNaN(shownAngle)) { shownAngle = targetAngle; shownRatio = ratio; }
                float da = (float) RadarNavigationMath.relativeAngle(targetAngle, shownAngle);
                shownAngle = (float) RadarNavigationMath.wrap(shownAngle + da * .18f);
                shownRatio += (ratio - shownRatio) * .18f;
                double a = Math.toRadians(shownAngle);
                float dist = r * .92f * Math.max(.04f, shownRatio);
                float x = cx + (float) Math.sin(a) * dist, y = cy - (float) Math.cos(a) * dist;

                // Línea al objetivo
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2.5f * d);
                p.setPathEffect(new DashPathEffect(new float[]{7 * d, 6 * d}, -time * 30 * d));
                p.setColor(alpha(prox, 210));
                c.drawLine(cx, cy, x, y, p);
                p.setPathEffect(null);

                // Eco del barrido sobre el objetivo
                float diff = (float) ((sweepDeg - (shownAngle + frame) + 720) % 360);
                float echo = diff < 50 ? 1f - diff / 50f : 0f;
                float pulse = (float) (0.5 + 0.5 * Math.sin(time * 4));
                p.setStyle(Paint.Style.FILL);
                p.setColor(alpha(prox, (int) (50 + 60 * pulse + 110 * echo)));
                c.drawCircle(x, y, (14 + 6 * pulse) * d, p);
                p.setColor(prox);
                c.drawCircle(x, y, 7.5f * d, p);
                p.setColor(Color.WHITE);
                c.drawCircle(x, y, 3 * d, p);
                if (distanceM > range) {
                    txt.setTextSize(10 * d);
                    txt.setColor(AMBER);
                    c.drawText("FUERA DE ESCALA", cx, cy + r * .55f, txt);
                }

                // Flecha grande de dirección (hacia el destino)
                c.save();
                c.rotate(shownAngle, cx, cy);
                float L = r * .42f;
                path.reset();
                path.moveTo(cx, cy - L);
                path.lineTo(cx - 17 * d, cy - L + 30 * d);
                path.lineTo(cx - 6 * d, cy - L + 24 * d);
                path.lineTo(cx - 6 * d, cy - 14 * d);
                path.lineTo(cx + 6 * d, cy - 14 * d);
                path.lineTo(cx + 6 * d, cy - L + 24 * d);
                path.lineTo(cx + 17 * d, cy - L + 30 * d);
                path.close();
                p.setStyle(Paint.Style.FILL);
                p.setColor(alpha(prox, hasHeading ? 235 : 120));
                c.drawPath(path, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(1.2f * d);
                p.setColor(alpha(Color.WHITE, 170));
                c.drawPath(path, p);
                c.restore();
            } else {
                shownAngle = Float.NaN;
                txt.setTextSize(11.5f * d);
                txt.setColor(AMBER);
                c.drawText("ESPERANDO POSICIÓN / DESTINO", cx, cy + r * .55f, txt);
            }

            // Usuario en el centro
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(20, 60, 110));
            c.drawCircle(cx, cy, 11 * d, p);
            p.setColor(SKY);
            c.drawCircle(cx, cy, 6 * d, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2 * d);
            p.setColor(Color.WHITE);
            c.drawCircle(cx, cy, 11 * d, p);

            // Llegada: anillo verde pulsante
            if (arrived) {
                float ph = (time * 1.2f) % 1f;
                p.setStrokeWidth(4 * d);
                p.setColor(alpha(MINT, (int) (230 * (1 - ph))));
                c.drawCircle(cx, cy, r * (.2f + .72f * ph), p);
                RectF pill = new RectF(cx - 70 * d, cy + r * .30f, cx + 70 * d, cy + r * .30f + 26 * d);
                p.setStyle(Paint.Style.FILL);
                p.setColor(alpha(Color.rgb(8, 60, 44), 230));
                c.drawRoundRect(pill, 13 * d, 13 * d, p);
                txt.setTextSize(12 * d);
                txt.setColor(MINT);
                c.drawText("¡LLEGASTE AL PUNTO!", cx, pill.centerY() + 4.5f * d, txt);
            }
        }

        static String shortDistance(double m) {
            if (m >= 1000) return String.format(Locale.US, "%.1f km", m / 1000);
            return String.format(Locale.US, "%.0f m", m);
        }
    }

    // =====================================================================
    // Barra de proximidad (lejos → cerca)
    // =====================================================================
    public static class ProximityBar extends Animated {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        private double meters = Double.NaN;
        private float shown = 0f;

        public ProximityBar(Context c) {
            super(c);
            txt.setTypeface(Typeface.create("sans", Typeface.BOLD));
        }

        public void setDistance(double m) { meters = m; kick(); }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            float barH = 10 * d, top = h - barH - 2 * d;
            RectF full = new RectF(0, top, w, top + barH);
            p.setStyle(Paint.Style.FILL);
            p.setShader(new android.graphics.LinearGradient(0, 0, w, 0,
                    new int[]{RED, AMBER, Color.rgb(150, 230, 120), MINT}, null, Shader.TileMode.CLAMP));
            p.setAlpha(90);
            c.drawRoundRect(full, barH / 2, barH / 2, p);
            p.setAlpha(255);
            float target = 0f;
            if (Double.isFinite(meters)) {
                // Escala logarítmica: 1 km o más = 0, 1 m = 1
                double v = 1 - Math.log10(Math.max(1, Math.min(1000, meters))) / 3.0;
                target = (float) Math.max(0, Math.min(1, v));
            }
            shown += (target - shown) * .15f;
            c.drawRoundRect(new RectF(0, top, Math.max(barH, w * shown), top + barH), barH / 2, barH / 2, p);
            p.setShader(null);
            float x = Math.max(barH / 2, w * shown);
            p.setColor(Color.WHITE);
            c.drawCircle(x, top + barH / 2, barH * .85f, p);
            p.setColor(NavRadarView.proximityColor(meters));
            c.drawCircle(x, top + barH / 2, barH * .55f, p);
            txt.setTextSize(10 * d);
            txt.setColor(DIM);
            txt.setTextAlign(Paint.Align.LEFT);
            c.drawText("LEJOS", 0, top - 5 * d, txt);
            txt.setTextAlign(Paint.Align.RIGHT);
            c.drawText("CERCA", w, top - 5 * d, txt);
            txt.setTextAlign(Paint.Align.CENTER);
            txt.setColor(NavRadarView.proximityColor(meters));
            String state = !Double.isFinite(meters) ? "SIN DATO" : meters <= 5 ? "¡AQUÍ!"
                    : meters <= 30 ? "MUY CERCA" : meters <= 150 ? "CERCA" : meters <= 1000 ? "LEJOS" : "MUY LEJOS";
            c.drawText(state, w / 2, top - 5 * d, txt);
        }
    }
}
