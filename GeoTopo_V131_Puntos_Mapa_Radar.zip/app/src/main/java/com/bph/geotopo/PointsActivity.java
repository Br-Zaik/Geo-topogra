package com.bph.geotopo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * V131: Puntos guardados (estilo lista de waypoints de Handy GPS).
 * Tocar un punto abre el radar "Ir a punto". Mantener pulsado activa la selección múltiple para eliminar.
 */
public class PointsActivity extends Activity implements LocationListener {
    private static final String PREFS = "geo_topo_gps_points";
    private static final int EDGE = Color.argb(120, 88, 148, 214);
    private static final int MINT = Color.rgb(74, 231, 176);
    private static final int AMBER = Color.rgb(255, 196, 92);
    private static final int RED = Color.rgb(255, 104, 104);

    private LocationManager manager;
    private Location here;
    private LinearLayout list, selectionBar;
    private TextView headerCount, selectionText;
    private EditText search;
    private final Set<Integer> selected = new HashSet<>();
    private boolean selecting;

    private static final class Row {
        int index;
        String name, project, symbol, utm;
        double lat, lon, alt;
        long time;
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        NativeUi.styleWindow(this);
        manager = (LocationManager) getSystemService(LOCATION_SERVICE);

        FrameLayout root = NativeUi.screen(this);
        LinearLayout page = NativeUi.column(this);
        page.addView(NativeUi.pageHeader(this, "Puntos guardados", "Toca un punto para ir con el radar",
                v -> finish(), "＋", v -> startActivity(new Intent(this, PointEditorActivity.class))));

        LinearLayout top = NativeUi.column(this);
        top.setPadding(dp(14), dp(10), dp(14), dp(4));
        LinearLayout actions = NativeUi.row(this);
        TextView add = button("＋  Nuevo punto", Color.rgb(20, 130, 96), Color.rgb(8, 72, 64), MINT);
        add.setOnClickListener(v -> startActivity(new Intent(this, PointEditorActivity.class)));
        TextView map = button("⌖  Ver todos en mapa", Color.rgb(24, 90, 150), Color.rgb(10, 50, 96), DesignUi.ACCENT_LIGHT);
        map.setOnClickListener(v -> {
            Intent i = new Intent(this, MapActivity.class);
            i.putExtra("show_saved_points", true);
            i.putExtra("show_all_saved_points", true);
            startActivity(i);
        });
        LinearLayout.LayoutParams a1 = new LinearLayout.LayoutParams(0, dp(46), 1f);
        a1.rightMargin = dp(5);
        LinearLayout.LayoutParams a2 = new LinearLayout.LayoutParams(0, dp(46), 1f);
        a2.leftMargin = dp(5);
        actions.addView(add, a1);
        actions.addView(map, a2);
        top.addView(actions);

        search = new EditText(this);
        search.setHint("Buscar por nombre o proyecto");
        search.setTextColor(Color.WHITE);
        search.setHintTextColor(Color.rgb(120, 150, 176));
        search.setTextSize(15);
        search.setSingleLine(true);
        search.setPadding(dp(12), dp(8), dp(12), dp(8));
        search.setBackground(NativeUi.rounded(Color.rgb(8, 26, 46), 12, 1, EDGE, this));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { render(); }
            @Override public void afterTextChanged(Editable s) { }
        });
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        slp.topMargin = dp(10);
        top.addView(search, slp);

        headerCount = NativeUi.text(this, "", 11.5f, true, NativeUi.SUB);
        headerCount.setPadding(dp(2), dp(10), 0, dp(2));
        top.addView(headerCount);

        selectionBar = NativeUi.row(this);
        selectionBar.setPadding(dp(12), 0, dp(8), 0);
        selectionBar.setBackground(NativeUi.gradient(Color.rgb(70, 24, 30), Color.rgb(40, 12, 18), 14,
                NativeUi.withAlpha(RED, 160), this));
        selectionText = NativeUi.text(this, "", 13.5f, true, Color.WHITE);
        selectionBar.addView(selectionText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView all = smallPill("Todos", DesignUi.ACCENT_LIGHT);
        all.setOnClickListener(v -> selectAllVisible());
        TextView del = smallPill("Eliminar", RED);
        del.setOnClickListener(v -> confirmDelete(new ArrayList<>(selected)));
        TextView cancel = smallPill("✕", NativeUi.SUB);
        cancel.setOnClickListener(v -> { selecting = false; selected.clear(); render(); });
        selectionBar.addView(all, pillLp());
        selectionBar.addView(del, pillLp());
        selectionBar.addView(cancel, pillLp());
        selectionBar.setVisibility(View.GONE);
        LinearLayout.LayoutParams sb = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        sb.topMargin = dp(6);
        top.addView(selectionBar, sb);
        page.addView(top);

        list = NativeUi.column(this);
        list.setPadding(dp(14), dp(6), dp(14), dp(24));
        ScrollView scroll = NativeUi.scroll(this, list);
        page.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(page, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
    }

    @Override protected void onResume() {
        super.onResume();
        render();
        if (manager != null && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            try {
                if (manager.isProviderEnabled(LocationManager.GPS_PROVIDER))
                    manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 1f, this, Looper.getMainLooper());
                Location last = manager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (last != null && Math.abs(System.currentTimeMillis() - last.getTime()) < 120000) { here = last; render(); }
            } catch (Exception ignored) { }
        }
    }

    @Override protected void onPause() {
        try { if (manager != null) manager.removeUpdates(this); } catch (Exception ignored) { }
        super.onPause();
    }

    @Override public void onLocationChanged(Location location) {
        if (location == null) return;
        here = new Location(location);
        if (!selecting) render();
    }
    @Override public void onProviderEnabled(String provider) { }
    @Override public void onProviderDisabled(String provider) { here = null; render(); }
    @Override public void onStatusChanged(String provider, int status, Bundle extras) { }

    // ------------------------------------------------------------------ Datos
    private JSONArray array() {
        try { return new JSONArray(getSharedPreferences(PREFS, MODE_PRIVATE).getString("points_json", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private List<Row> rows() {
        List<Row> out = new ArrayList<>();
        JSONArray a = array();
        for (int i = a.length() - 1; i >= 0; i--) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            Row r = new Row();
            r.index = i;
            r.name = o.optString("name", "Punto");
            r.project = o.optString("project", "Proyecto general");
            r.symbol = o.optString("symbol", "●");
            r.lat = o.optDouble("latitude", Double.NaN);
            r.lon = o.optDouble("longitude", Double.NaN);
            r.alt = o.optDouble("altitude", Double.NaN);
            r.time = o.optLong("timestamp", 0L);
            CoordinateUtils.Utm u = Double.isFinite(r.lat) && Double.isFinite(r.lon) ? CoordinateUtils.toUtm(r.lat, r.lon) : null;
            r.utm = u != null && u.valid ? String.format(Locale.US, "UTM %s  E %.3f  N %.3f",
                    CoordinateUtils.zoneWithBand(r.lat, r.lon), u.easting, u.northing)
                    : String.format(Locale.US, "%.6f°, %.6f°", r.lat, r.lon);
            out.add(r);
        }
        return out;
    }

    private List<Row> visibleRows() {
        String q = search == null ? "" : search.getText().toString().trim().toLowerCase(Locale.getDefault());
        List<Row> all = rows();
        if (q.isEmpty()) return all;
        List<Row> out = new ArrayList<>();
        for (Row r : all) {
            if (r.name.toLowerCase(Locale.getDefault()).contains(q) || r.project.toLowerCase(Locale.getDefault()).contains(q))
                out.add(r);
        }
        return out;
    }

    // ------------------------------------------------------------------ Render
    private void render() {
        if (list == null) return;
        list.removeAllViews();
        List<Row> rows = visibleRows();
        int total = array().length();
        headerCount.setText(total == 0 ? "SIN PUNTOS" : rows.size() == total ? total + " PUNTOS"
                : rows.size() + " DE " + total + " PUNTOS");
        selectionBar.setVisibility(selecting ? View.VISIBLE : View.GONE);
        selectionText.setText(selected.size() + " seleccionado" + (selected.size() == 1 ? "" : "s"));
        if (rows.isEmpty()) {
            TextView empty = NativeUi.text(this, total == 0
                    ? "Todavía no hay puntos.\nToca «Nuevo punto» para escribir coordenadas o usar tu posición GPS."
                    : "Ningún punto coincide con la búsqueda.", 13.5f, false, NativeUi.SUB);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(16), dp(40), dp(16), dp(40));
            list.addView(empty);
            return;
        }
        for (Row r : rows) list.addView(card(r));
    }

    private View card(Row r) {
        boolean isSel = selected.contains(r.index);
        LinearLayout c = NativeUi.column(this);
        c.setPadding(dp(12), dp(11), dp(10), dp(10));
        c.setBackground(NativeUi.gradient(DesignUi.CARD_TOP, DesignUi.CARD_BOTTOM, 16,
                isSel ? NativeUi.withAlpha(RED, 220) : EDGE, this));

        LinearLayout head = NativeUi.row(this);
        TextView badge = NativeUi.text(this, isSel ? "✓" : r.symbol, 17f, true, isSel ? Color.WHITE : AMBER);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(NativeUi.rounded(isSel ? NativeUi.withAlpha(RED, 200) : NativeUi.withAlpha(AMBER, 36),
                19, 1, NativeUi.withAlpha(isSel ? RED : AMBER, 150), this));
        head.addView(badge, new LinearLayout.LayoutParams(dp(38), dp(38)));
        LinearLayout words = NativeUi.column(this);
        words.setPadding(dp(10), 0, dp(6), 0);
        TextView name = NativeUi.text(this, r.name, 16f, true, Color.WHITE);
        name.setSingleLine(true);
        words.addView(name);
        TextView sub = NativeUi.text(this, r.project + "  ·  " + when(r.time), 11f, false, NativeUi.SUB);
        sub.setSingleLine(true);
        words.addView(sub);
        head.addView(words, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (here != null && Double.isFinite(r.lat)) {
            float[] res = new float[2];
            Location.distanceBetween(here.getLatitude(), here.getLongitude(), r.lat, r.lon, res);
            int col = ProRadar.NavRadarView.proximityColor(res[0]);
            LinearLayout dist = NativeUi.column(this);
            dist.setGravity(Gravity.END);
            TextView dv = NativeUi.text(this, distance(res[0]), 15f, true, col);
            dist.addView(dv);
            TextView bv = NativeUi.text(this, String.format(Locale.US, "%.0f° %s", wrap(res[1]), cardinal(res[1])), 10.5f, false, NativeUi.SUB);
            dist.addView(bv);
            head.addView(dist);
        }
        c.addView(head);

        TextView coords = NativeUi.text(this, r.utm + (Double.isFinite(r.alt) ? String.format(Locale.US, "  ·  %.1f m", r.alt) : ""),
                11.5f, false, Color.rgb(196, 214, 234));
        coords.setPadding(dp(48), dp(4), 0, dp(8));
        c.addView(coords);

        if (!selecting) {
            LinearLayout buttons = NativeUi.row(this);
            buttons.setPadding(dp(48), 0, 0, 0);
            TextView go = smallPill("➤ Ir", MINT);
            go.setOnClickListener(v -> navigate(r));
            TextView onMap = smallPill("Mapa", DesignUi.ACCENT_LIGHT);
            onMap.setOnClickListener(v -> openOnMap(r));
            TextView edit = smallPill("Editar", NativeUi.SUB);
            edit.setOnClickListener(v -> {
                Intent i = new Intent(this, PointEditorActivity.class);
                i.putExtra("edit_index", r.index);
                startActivity(i);
            });
            TextView del = smallPill("Eliminar", RED);
            del.setOnClickListener(v -> {
                List<Integer> one = new ArrayList<>();
                one.add(r.index);
                confirmDelete(one);
            });
            buttons.addView(go, pillLp());
            buttons.addView(onMap, pillLp());
            buttons.addView(edit, pillLp());
            buttons.addView(del, pillLp());
            c.addView(buttons);
        }

        c.setOnClickListener(v -> {
            if (selecting) toggle(r.index); else navigate(r);
        });
        c.setOnLongClickListener(v -> {
            selecting = true;
            toggle(r.index);
            return true;
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(9);
        c.setLayoutParams(lp);
        return c;
    }

    private void toggle(int index) {
        if (!selected.remove(index)) selected.add(index);
        if (selected.isEmpty()) selecting = false;
        render();
    }

    private void selectAllVisible() {
        for (Row r : visibleRows()) selected.add(r.index);
        render();
    }

    private void confirmDelete(List<Integer> indexes) {
        if (indexes.isEmpty()) return;
        new AlertDialog.Builder(this)
                .setTitle(indexes.size() == 1 ? "¿Eliminar este punto?" : "¿Eliminar " + indexes.size() + " puntos?")
                .setMessage("Esta acción no se puede deshacer.")
                .setPositiveButton("Eliminar", (d, w) -> {
                    Set<Integer> drop = new HashSet<>(indexes);
                    JSONArray a = array();
                    JSONArray out = new JSONArray();
                    for (int i = 0; i < a.length(); i++) if (!drop.contains(i)) out.put(a.opt(i));
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("points_json", out.toString()).apply();
                    selected.clear();
                    selecting = false;
                    render();
                    Toast.makeText(this, indexes.size() == 1 ? "Punto eliminado" : indexes.size() + " puntos eliminados",
                            Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void navigate(Row r) {
        Intent i = new Intent(this, GotoPointActivity.class);
        i.putExtra("target_lat", r.lat);
        i.putExtra("target_lon", r.lon);
        i.putExtra("target_name", r.name);
        startActivity(i);
    }

    private void openOnMap(Row r) {
        Intent intent = new Intent(this, MapActivity.class);
        intent.putExtra("show_saved_points", true);
        intent.putExtra("saved_points_project", r.project);
        intent.putExtra("selected_saved_point_name", r.name);
        intent.putExtra("selected_saved_point_lat", r.lat);
        intent.putExtra("selected_saved_point_lon", r.lon);
        startActivity(intent);
    }

    // ------------------------------------------------------------------ Helpers
    private int dp(int v) { return NativeUi.dp(this, v); }

    private LinearLayout.LayoutParams pillLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(34), 1f);
        lp.rightMargin = dp(5);
        return lp;
    }

    private TextView smallPill(String label, int color) {
        TextView v = NativeUi.text(this, label, 12f, true, color);
        v.setGravity(Gravity.CENTER);
        v.setSingleLine(true);
        v.setBackground(NativeUi.rounded(NativeUi.withAlpha(color, 26), 12, 1, NativeUi.withAlpha(color, 130), this));
        return v;
    }

    private TextView button(String label, int start, int end, int stroke) {
        TextView v = NativeUi.text(this, label, 13.5f, true, Color.WHITE);
        v.setGravity(Gravity.CENTER);
        v.setSingleLine(true);
        v.setBackground(NativeUi.gradient(start, end, 14, NativeUi.withAlpha(stroke, 170), this));
        return v;
    }

    private static double wrap(double d) { return RadarNavigationMath.wrap(d); }

    private static String cardinal(double deg) {
        String[] n = {"N", "NE", "E", "SE", "S", "SO", "O", "NO"};
        return n[(int) Math.round(RadarNavigationMath.wrap(deg) / 45.0) % 8];
    }

    private static String distance(double m) {
        return m >= 1000 ? String.format(Locale.US, "%.2f km", m / 1000) : String.format(Locale.US, "%.1f m", m);
    }

    private static String when(long t) {
        if (t <= 0) return "sin fecha";
        return new java.text.SimpleDateFormat("dd/MM/yy HH:mm", Locale.getDefault()).format(new java.util.Date(t));
    }

    @Override public void onContentChanged() { super.onContentChanged(); NativeUi.applySystemBarInsets(this); }
}
