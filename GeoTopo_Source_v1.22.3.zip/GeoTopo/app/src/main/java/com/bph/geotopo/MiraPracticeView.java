package com.bph.geotopo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

import java.util.Locale;
import java.util.Random;

/**
 * Vista para practicar lectura de mira tipo E.
 * Se dibuja por código para mantener la app liviana,
 * pero con una presentación más grande, limpia y cercana
 * a la apariencia real de una mira de campo.
 */
public class MiraPracticeView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random();
    private final int textColor;
    private final int subTextColor;
    private final int panelColor;
    private final float density;

    private double upperReading;
    private double middleReading;
    private double lowerReading;
    private double visibleMin;
    private double visibleMax;

    public MiraPracticeView(Context context, int accentColor, int textColor, int subTextColor, int panelColor) {
        super(context);
        this.textColor = textColor;
        this.subTextColor = subTextColor;
        this.panelColor = panelColor;
        this.density = getResources().getDisplayMetrics().density;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        newExercise();
    }

    public void newExercise() {
        int halfSpanMm = 55 + random.nextInt(56); // 55 a 110 mm por lado.
        int middleMm = 500 + random.nextInt(4001); // 0.500 m a 4.500 m.

        if (middleMm - halfSpanMm < 120) middleMm = 120 + halfSpanMm;
        if (middleMm + halfSpanMm > 4880) middleMm = 4880 - halfSpanMm;

        if (middleMm % 10 == 0) middleMm += 3 + random.nextInt(4);

        middleReading = middleMm / 1000.0;
        upperReading = (middleMm + halfSpanMm) / 1000.0;
        lowerReading = (middleMm - halfSpanMm) / 1000.0;

        double margin = 0.08;
        visibleMin = Math.floor((lowerReading - margin) * 10.0) / 10.0;
        visibleMax = Math.ceil((upperReading + margin) * 10.0) / 10.0;

        if (visibleMin < 0.0) visibleMin = 0.0;
        if (visibleMax > 5.0) visibleMax = 5.0;
        if (visibleMax - visibleMin < 0.30) visibleMax = Math.min(5.0, visibleMin + 0.30);

        invalidate();
    }

    public double getUpperReading() {
        return upperReading;
    }

    public double getMiddleReading() {
        return middleReading;
    }

    public double getLowerReading() {
        return lowerReading;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int desiredHeight = dp(620);
        int height = resolveSize(desiredHeight, heightMeasureSpec);
        setMeasuredDimension(width, height);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        float footerHeight = dp(52);
        float cx = w / 2f;
        float cy = (h - footerHeight) / 2f;
        float radius = Math.min(w * 0.45f, (h - footerHeight) * 0.44f);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(panelColor);
        canvas.drawRoundRect(new RectF(0, 0, w, h), dp(18), dp(18), paint);

        // Aro exterior del ocular.
        paint.setColor(Color.rgb(14, 18, 23));
        paint.setShadowLayer(dp(10), 0f, dp(4), Color.argb(110, 0, 0, 0));
        canvas.drawCircle(cx, cy, radius + dp(10), paint);
        paint.clearShadowLayer();

        paint.setColor(Color.rgb(245, 245, 245));
        canvas.drawCircle(cx, cy, radius, paint);

        Path clip = new Path();
        clip.addCircle(cx, cy, radius - dp(1), Path.Direction.CW);
        int save = canvas.save();
        canvas.clipPath(clip);

        drawLensBackground(canvas, cx, cy, radius);
        drawStaff(canvas, cx, cy, radius);
        drawThreads(canvas, cx, cy, radius);

        canvas.restoreToCount(save);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(4));
        paint.setColor(Color.rgb(17, 21, 27));
        canvas.drawCircle(cx, cy, radius, paint);
        paint.setStrokeWidth(dp(1.2f));
        paint.setColor(Color.rgb(86, 86, 86));
        canvas.drawCircle(cx, cy, radius - dp(4), paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        paint.setTextSize(dp(12));
        paint.setColor(subTextColor);
        canvas.drawText("Mira tipo E · numeración negra · patrón rojo", cx, h - dp(28), paint);
        canvas.drawText("Cada franja roja o blanca representa 1 cm", cx, h - dp(10), paint);
    }

    private void drawLensBackground(Canvas canvas, float cx, float cy, float radius) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(248, 248, 248));
        canvas.drawRect(cx - radius, cy - radius, cx + radius, cy + radius, paint);

        // Suaves sombras para sensación de lente.
        paint.setColor(Color.argb(14, 0, 0, 0));
        canvas.drawCircle(cx + radius * 0.26f, cy - radius * 0.10f, radius * 0.96f, paint);
        paint.setColor(Color.argb(10, 255, 255, 255));
        canvas.drawCircle(cx - radius * 0.32f, cy - radius * 0.24f, radius * 0.62f, paint);
    }

    private void drawStaff(Canvas canvas, float cx, float cy, float radius) {
        float staffWidth = Math.min(dp(160), radius * 0.62f);
        float staffLeft = cx - staffWidth / 2f;
        float staffRight = cx + staffWidth / 2f;
        float staffTop = cy - radius - dp(24);
        float staffBottom = cy + radius + dp(24);

        float patternLeft = staffLeft;
        float dividerX = staffLeft + staffWidth * 0.42f;
        float numberRight = staffRight;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
        canvas.drawRect(staffLeft, staffTop, staffRight, staffBottom, paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.rgb(115, 115, 115));
        paint.setStrokeWidth(dp(1));
        canvas.drawRect(staffLeft, staffTop, staffRight, staffBottom, paint);

        // Líneas verticales guía.
        paint.setColor(Color.rgb(25, 25, 25));
        paint.setStrokeWidth(dp(1.4f));
        canvas.drawLine(dividerX, staffTop, dividerX, staffBottom, paint);
        paint.setColor(Color.rgb(130, 130, 130));
        paint.setStrokeWidth(dp(0.9f));
        canvas.drawLine(staffLeft + staffWidth * 0.06f, staffTop, staffLeft + staffWidth * 0.06f, staffBottom, paint);
        canvas.drawLine(numberRight - staffWidth * 0.06f, staffTop, numberRight - staffWidth * 0.06f, staffBottom, paint);

        int startCm = (int) Math.floor(visibleMin * 100.0) - 1;
        int endCm = (int) Math.ceil(visibleMax * 100.0) + 1;

        for (int cm = startCm; cm <= endCm; cm++) {
            double value = cm / 100.0;
            float y = readingToY(value, staffTop, staffBottom);
            if (y < staffTop - dp(2) || y > staffBottom + dp(2)) continue;
            boolean decimeter = floorMod(cm, 10) == 0;
            boolean fiveCm = floorMod(cm, 5) == 0;
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(decimeter ? Color.rgb(92, 92, 92)
                    : (fiveCm ? Color.rgb(145, 145, 145) : Color.rgb(205, 205, 205)));
            paint.setStrokeWidth(decimeter ? dp(1.1f) : (fiveCm ? dp(0.8f) : dp(0.55f)));
            canvas.drawLine(staffLeft, y, staffRight, y, paint);
        }

        int startDm = (int) Math.floor(visibleMin * 10.0) - 1;
        int endDm = (int) Math.ceil(visibleMax * 10.0) + 1;
        for (int dm = startDm; dm <= endDm; dm++) {
            double dmValue = dm / 10.0;
            double nextDmValue = dmValue + 0.10;
            float y1 = readingToY(nextDmValue, staffTop, staffBottom);
            float y2 = readingToY(dmValue, staffTop, staffBottom);
            float top = Math.min(y1, y2);
            float bottom = Math.max(y1, y2);
            if (bottom < staffTop || top > staffBottom) continue;

            drawEPattern(canvas, patternLeft, dividerX, top, bottom);
            drawNumber(canvas, dm, dividerX, numberRight, top, bottom);
        }
    }

    private void drawEPattern(Canvas canvas, float left, float right, float top, float bottom) {
        float width = right - left;
        float cmH = (bottom - top) / 10f;
        float margin = width * 0.06f;
        float spineLeft = left + margin;
        float spineRight = spineLeft + width * 0.12f;
        float fullRight = right - margin;
        float longLen = width * 0.74f;
        float midLen = width * 0.52f;
        float shortLen = width * 0.28f;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(229, 28, 35));

        canvas.drawRect(spineLeft, top + cmH * 1.0f, spineRight, top + cmH * 9.0f, paint);

        drawRectBar(canvas, spineLeft, top + cmH * 0.10f, shortLen, cmH * 0.80f);
        drawRectBar(canvas, spineLeft, top + cmH * 1.10f, longLen, cmH * 1.90f);
        drawRectBar(canvas, spineLeft, top + cmH * 3.20f, shortLen, cmH * 0.80f);
        drawRectBar(canvas, spineLeft, top + cmH * 4.10f, midLen, cmH * 1.80f);
        drawRectBar(canvas, spineLeft, top + cmH * 6.10f, shortLen, cmH * 0.80f);
        drawRectBar(canvas, spineLeft, top + cmH * 7.10f, longLen, cmH * 1.80f);
        drawRectBar(canvas, spineLeft, top + cmH * 9.10f, shortLen, cmH * 0.80f);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(0.8f));
        paint.setColor(Color.rgb(160, 160, 160));
        canvas.drawLine(fullRight, top, fullRight, bottom, paint);
    }

    private void drawRectBar(Canvas canvas, float left, float top, float width, float height) {
        canvas.drawRect(left, top, left + width, top + height, paint);
    }

    private void drawNumber(Canvas canvas, int dm, float left, float right, float top, float bottom) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(15, 15, 15));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(Math.min(dp(34), Math.max(dp(22), (bottom - top) * 0.42f)));
        float x = left + (right - left) * 0.53f;
        float y = (top + bottom) / 2f;
        canvas.drawText(String.format(Locale.US, "%02d", Math.max(0, dm)), x, centeredTextBaseline(y), paint);
    }

    private void drawThreads(Canvas canvas, float cx, float cy, float radius) {
        float staffWidth = Math.min(dp(160), radius * 0.62f);
        float staffTop = cy - radius - dp(24);
        float staffBottom = cy + radius + dp(24);

        drawThread(canvas, "LS", upperReading, cx, radius, staffTop, staffBottom, false);
        drawThread(canvas, "LM", middleReading, cx, radius, staffTop, staffBottom, true);
        drawThread(canvas, "LI", lowerReading, cx, radius, staffTop, staffBottom, false);

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.rgb(16, 16, 16));
        paint.setStrokeWidth(dp(1.2f));
        float centralTop = cy - radius * 0.92f;
        float centralBottom = cy + radius * 0.92f;
        canvas.drawLine(cx, centralTop, cx, centralBottom, paint);
    }

    private void drawThread(Canvas canvas, String label, double reading, float cx, float radius,
                            float staffTop, float staffBottom, boolean middle) {
        float y = readingToY(reading, staffTop, staffBottom);
        float left = cx - radius + dp(8);
        float right = cx + radius - dp(8);

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.rgb(20, 20, 20));
        paint.setStrokeWidth(middle ? dp(2.5f) : dp(1.7f));
        canvas.drawLine(left, y, right, y, paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(38, 38, 38));
        paint.setTextAlign(Paint.Align.LEFT);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(dp(16));
        canvas.drawText(label, left + dp(4), y - dp(6), paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.rgb(18, 18, 18));
        paint.setStrokeWidth(dp(1.2f));
        canvas.drawLine(cx, y - dp(10), cx, y + dp(10), paint);
    }

    private float centeredTextBaseline(float centerY) {
        Paint.FontMetrics fm = paint.getFontMetrics();
        return centerY - (fm.ascent + fm.descent) / 2f;
    }

    private float readingToY(double reading, float top, float bottom) {
        double range = Math.max(0.01, visibleMax - visibleMin);
        double t = (visibleMax - reading) / range;
        return (float) (top + t * (bottom - top));
    }

    private int floorMod(int value, int divisor) {
        int result = value % divisor;
        return result < 0 ? result + divisor : result;
    }

    private int dp(float value) {
        return Math.round(value * density);
    }
}
