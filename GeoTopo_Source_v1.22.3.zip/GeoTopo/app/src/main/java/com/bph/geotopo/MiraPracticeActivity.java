package com.bph.geotopo;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

public class MiraPracticeActivity extends Activity {
    private static final String PREFS = "geo_topo_prefs";
    private static final int THEME_LIGHT = 0;
    private static final int THEME_DARK = 1;
    private static final int THEME_BLACK = 2;

    private static final int[] ACCENTS = {
            Color.rgb(41, 121, 255),
            Color.rgb(0, 188, 212),
            Color.rgb(0, 150, 136),
            Color.rgb(0, 184, 148),
            Color.rgb(118, 210, 34),
            Color.rgb(255, 214, 10),
            Color.rgb(255, 171, 0),
            Color.rgb(255, 112, 20),
            Color.rgb(244, 67, 54),
            Color.rgb(255, 64, 129),
            Color.rgb(142, 68, 173),
            Color.rgb(92, 92, 210),
            Color.rgb(149, 96, 68),
            Color.rgb(158, 169, 181),
            Color.rgb(20, 20, 22),
            Color.rgb(255, 255, 255)
    };

    private int themeMode;
    private int accentIndex;

    private int bgColor;
    private int appBarColor;
    private int cardColor;
    private int textColor;
    private int subTextColor;
    private int borderColor;
    private int inputFillColor;
    private int inputStrokeColor;
    private int resultFillColor;
    private int resultStrokeColor;

    private MiraPracticeView miraPracticeView;
    private EditText miraLsInput;
    private EditText miraLmInput;
    private EditText miraLiInput;
    private TextView miraPracticeResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadPrefs();
        applyPalette();
        buildUi();
        newMiraExercise();
    }

    private void loadPrefs() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        themeMode = sp.getInt("theme", THEME_DARK);
        accentIndex = sp.getInt("accent", 0);
    }

    private void applyPalette() {
        borderColor = ACCENTS[accentIndex % ACCENTS.length];
        if (themeMode == THEME_LIGHT) {
            bgColor = Color.rgb(241, 244, 248);
            appBarColor = Color.rgb(20, 33, 61);
            cardColor = Color.WHITE;
            textColor = Color.rgb(30, 33, 40);
            subTextColor = Color.rgb(96, 104, 118);
            inputFillColor = Color.WHITE;
            inputStrokeColor = Color.rgb(178, 184, 196);
            resultFillColor = Color.rgb(245, 252, 248);
            resultStrokeColor = Color.rgb(29, 185, 84);
        } else if (themeMode == THEME_BLACK) {
            bgColor = Color.BLACK;
            appBarColor = Color.rgb(3, 20, 34);
            cardColor = Color.rgb(9, 11, 15);
            textColor = Color.rgb(245, 245, 247);
            subTextColor = Color.rgb(179, 184, 192);
            inputFillColor = Color.rgb(14, 16, 22);
            inputStrokeColor = Color.rgb(79, 85, 96);
            resultFillColor = Color.rgb(14, 31, 23);
            resultStrokeColor = Color.rgb(0, 200, 83);
        } else {
            bgColor = Color.rgb(7, 22, 36);
            appBarColor = Color.rgb(3, 45, 73);
            cardColor = Color.rgb(17, 38, 58);
            textColor = Color.rgb(248, 250, 252);
            subTextColor = Color.rgb(199, 211, 222);
            inputFillColor = Color.rgb(10, 29, 45);
            inputStrokeColor = Color.rgb(92, 112, 132);
            resultFillColor = Color.rgb(9, 50, 42);
            resultStrokeColor = Color.rgb(0, 210, 125);
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);
        root.addView(topBar());

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(12), dp(14), dp(24));
        content.setBackgroundColor(bgColor);

        LinearLayout card = card();
        card.addView(sectionTitle("Práctica de lectura de mira"));
        card.addView(small("Observa una mira tipo E grande y más realista. Lee las tres líneas: LS, LM y LI. El último milímetro se estima visualmente."));

        miraPracticeView = new MiraPracticeView(this, borderColor, textColor, subTextColor, inputFillColor);
        LinearLayout.LayoutParams viewLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(620)
        );
        viewLp.setMargins(0, dp(10), 0, dp(10));
        miraPracticeView.setLayoutParams(viewLp);
        card.addView(miraPracticeView);

        card.addView(small("Escribe en metros con tres decimales. Ejemplo: 1.455. Se acepta una tolerancia visual de ±2 mm."));

        LinearLayout inputs = new LinearLayout(this);
        inputs.setOrientation(LinearLayout.HORIZONTAL);

        miraLsInput = edit("1.505");
        miraLmInput = edit("1.455");
        miraLiInput = edit("1.405");
        inputs.addView(labeledInput("LS superior", miraLsInput), weightParams());
        inputs.addView(labeledInput("LM medio", miraLmInput), weightParams());
        inputs.addView(labeledInput("LI inferior", miraLiInput), weightParams());
        card.addView(inputs);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button newExercise = btn("Nueva mira");
        newExercise.setOnClickListener(v -> newMiraExercise());
        buttons.addView(newExercise, weightParams());
        Button check = btn("Comprobar lectura");
        check.setOnClickListener(v -> checkMiraReading());
        buttons.addView(check, weightParams());
        card.addView(buttons);

        miraPracticeResult = resultBox("Ejercicio listo. Genera o revisa la mira y luego escribe LS, LM y LI.");
        card.addView(miraPracticeResult);

        content.addView(card);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));

        setContentView(root);
    }

    private View topBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(appBarColor);
        bar.setPadding(dp(10), dp(14), dp(12), dp(14));

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextColor(Color.WHITE);
        back.setTextSize(28);
        back.setTypeface(Typeface.DEFAULT_BOLD);
        back.setGravity(Gravity.CENTER);
        back.setPadding(dp(8), dp(2), dp(8), dp(4));
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(42), dp(42)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = new TextView(this);
        title.setText("Distancia por hilos");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        titles.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Mira tipo E · práctica topográfica");
        subtitle.setTextColor(Color.argb(220, 255, 255, 255));
        subtitle.setTextSize(12);
        titles.addView(subtitle);
        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        return bar;
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(16));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(cardColor);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), Color.argb(90, Color.red(borderColor), Color.green(borderColor), Color.blue(borderColor)));
        box.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, 0, 0, dp(12));
        box.setLayoutParams(lp);
        return box;
    }

    private TextView sectionTitle(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(textColor);
        tv.setTextSize(17);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }

    private TextView small(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(subTextColor);
        tv.setTextSize(13);
        tv.setPadding(0, dp(4), 0, dp(4));
        return tv;
    }

    private EditText edit(String hint) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setHintTextColor(Color.argb(170, Color.red(subTextColor), Color.green(subTextColor), Color.blue(subTextColor)));
        et.setTextColor(textColor);
        et.setTextSize(18);
        et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        et.setSelectAllOnFocus(true);
        et.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(inputFillColor);
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), inputStrokeColor);
        et.setBackground(bg);
        return et;
    }

    private LinearLayout labeledInput(String label, EditText input) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(4), dp(6), dp(4), dp(6));

        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(textColor);
        tv.setTextSize(14);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(0, 0, 0, dp(4));
        box.addView(tv);
        box.addView(input, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        return box;
    }

    private Button btn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(borderColor);
        bg.setCornerRadius(dp(12));
        b.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(50)
        );
        lp.setMargins(dp(4), dp(8), dp(4), dp(4));
        b.setLayoutParams(lp);
        return b;
    }

    private TextView resultBox(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(textColor);
        tv.setTextSize(14);
        tv.setPadding(dp(12), dp(12), dp(12), dp(12));
        tv.setBackground(resultBackground(true, resultFillColor, resultStrokeColor));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(8), 0, 0);
        tv.setLayoutParams(lp);
        return tv;
    }

    private GradientDrawable resultBackground(boolean neutral, int fill, int stroke) {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(12));
        if (neutral) {
            bg.setColor(fill);
            bg.setStroke(dp(1), stroke);
        }
        return bg;
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    private void newMiraExercise() {
        if (miraPracticeView != null) miraPracticeView.newExercise();
        if (miraLsInput != null) miraLsInput.setText("");
        if (miraLmInput != null) miraLmInput.setText("");
        if (miraLiInput != null) miraLiInput.setText("");
        if (miraPracticeResult != null) {
            miraPracticeResult.setText("Nueva mira generada. Lee las tres líneas horizontales y escribe LS, LM y LI.");
            setMiraPracticeResultStyle(-1);
        }
    }

    private void checkMiraReading() {
        if (miraPracticeView == null || miraPracticeResult == null) return;
        try {
            double enteredLs = parseNumber(miraLsInput.getText().toString());
            double enteredLm = parseNumber(miraLmInput.getText().toString());
            double enteredLi = parseNumber(miraLiInput.getText().toString());

            if (!(enteredLs > enteredLm && enteredLm > enteredLi)) {
                setMiraPracticeResult(false,
                        "Lectura incorrecta: debe cumplirse LS > LM > LI. Revisa el orden de los tres hilos.");
                return;
            }

            double targetLs = miraPracticeView.getUpperReading();
            double targetLm = miraPracticeView.getMiddleReading();
            double targetLi = miraPracticeView.getLowerReading();
            double tolerance = 0.002;

            double errLs = enteredLs - targetLs;
            double errLm = enteredLm - targetLm;
            double errLi = enteredLi - targetLi;
            boolean lsOk = Math.abs(errLs) <= tolerance;
            boolean lmOk = Math.abs(errLm) <= tolerance;
            boolean liOk = Math.abs(errLi) <= tolerance;
            boolean allOk = lsOk && lmOk && liOk;

            double targetDistance = Math.abs(targetLs - targetLi) * 100.0;
            double enteredDistance = Math.abs(enteredLs - enteredLi) * 100.0;
            double enteredMiddleCheck = (enteredLs + enteredLi) / 2.0;
            double middleDifferenceMm = Math.abs(enteredLm - enteredMiddleCheck) * 1000.0;

            if (allOk) {
                setMiraPracticeResult(true,
                        "Lectura correcta dentro de ±2 mm.\n"
                                + "LS: " + f3(enteredLs) + " m · LM: " + f3(enteredLm) + " m · LI: " + f3(enteredLi) + " m\n"
                                + "Distancia estadimétrica: " + f3(enteredDistance) + " m\n"
                                + "Comprobación: LM ≈ (LS + LI) / 2, diferencia " + f3(middleDifferenceMm) + " mm.");
            } else {
                setMiraPracticeResult(false,
                        "Aún no coincide.\n"
                                + "Error: LS " + signedMillimeters(errLs) + " · LM " + signedMillimeters(errLm) + " · LI " + signedMillimeters(errLi) + "\n"
                                + "Respuesta: LS " + f3(targetLs) + " m · LM " + f3(targetLm) + " m · LI " + f3(targetLi) + " m\n"
                                + "Distancia correcta: " + f3(targetDistance) + " m");
            }
        } catch (Exception e) {
            setMiraPracticeResult(false,
                    "Completa LS, LM y LI con números válidos en metros. Ejemplo: 1.455");
        }
    }

    private void setMiraPracticeResult(boolean success, String message) {
        miraPracticeResult.setText(message);
        setMiraPracticeResultStyle(success ? 1 : 0);
    }

    private void setMiraPracticeResultStyle(int mode) {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(12));
        if (mode > 0) {
            bg.setColor(themeMode == THEME_LIGHT ? Color.rgb(236, 249, 241) : Color.rgb(9, 50, 42));
            bg.setStroke(dp(1), Color.rgb(0, 184, 105));
            miraPracticeResult.setTextColor(textColor);
        } else if (mode == 0) {
            bg.setColor(themeMode == THEME_LIGHT ? Color.rgb(255, 244, 235) : Color.rgb(65, 37, 18));
            bg.setStroke(dp(1), Color.rgb(255, 152, 0));
            miraPracticeResult.setTextColor(textColor);
        } else {
            bg.setColor(resultFillColor);
            bg.setStroke(dp(1), resultStrokeColor);
            miraPracticeResult.setTextColor(textColor);
        }
        miraPracticeResult.setBackground(bg);
    }

    private double parseNumber(String raw) {
        return Double.parseDouble(raw.trim().replace(',', '.'));
    }

    private String f3(double value) {
        return String.format(Locale.US, "%.3f", value);
    }

    private String signedMillimeters(double errorMeters) {
        return String.format(Locale.US, "%+.1f mm", errorMeters * 1000.0);
    }

    private int dp(float value) {
        return Math.round(getResources().getDisplayMetrics().density * value);
    }
}
