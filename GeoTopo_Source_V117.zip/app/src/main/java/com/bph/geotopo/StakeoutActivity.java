package com.bph.geotopo;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;

import org.maplibre.android.MapLibre;
import org.maplibre.android.annotations.IconFactory;
import org.maplibre.android.annotations.Marker;
import org.maplibre.android.annotations.MarkerOptions;
import org.maplibre.android.annotations.Polyline;
import org.maplibre.android.annotations.PolylineOptions;
import org.maplibre.android.camera.CameraPosition;
import org.maplibre.android.camera.CameraUpdateFactory;
import org.maplibre.android.geometry.LatLng;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapView;
import org.maplibre.android.maps.Style;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Replanteo de punto con Radar orientado por sensores y mapa de seguimiento.
 * Mantiene el cálculo geográfico/UTM original y presenta los resultados en tiempo real.
 */
public class StakeoutActivity extends BaseToolActivity {
    private static final int REQ_LOCATION = 9401;

    private static final int NAV_BLUE = Color.rgb(45, 129, 255);
    private static final int TARGET_GREEN = Color.rgb(112, 220, 68);
    private static final int TARGET_RED = Color.rgb(244, 78, 67);
    private static final int VALUE_GREEN = Color.rgb(93, 207, 57);
    private static final int WARN_AMBER = Color.rgb(255, 171, 0);
    private static final int PURPLE = Color.rgb(132, 83, 255);
    private static final String STAKEOUT_MAP_STYLE = "https://tiles.openfreemap.org/styles/bright";

    private LocationManager locationManager;
    private SensorManager sensorManager;
    private Sensor rotationVectorSensor;
    private Sensor accelerometerSensor;
    private Sensor magnetometerSensor;
    private boolean headingAvailable;
    private float magneticHeadingDegrees;
    private float trueHeadingDegrees;
    private EditText firstInput;
    private EditText secondInput;
    private EditText zoneInput;
    private EditText toleranceInput;
    private CheckBox utmCheck;
    private CheckBox southCheck;
    private LinearLayout utmOptions;
    private TextView modeHelp;
    private TextView statusText;
    private TextView distanceValue;
    private TextView azimuthValue;
    private TextView northValue;
    private TextView eastValue;
    private TextView precisionValue;
    private TextView precisionDetail;
    private Button startButton;
    private StakeoutNavigationView navigationView;
    private FrameLayout navigationContainer;
    private Button topViewButton;
    private Button mapViewButton;
    private MapView stakeoutMapView;
    private MapLibreMap stakeoutMap;
    private Marker stakeoutCurrentMarker;
    private Marker stakeoutTargetMarker;
    private Polyline stakeoutRouteLine;
    private Bundle mapSavedState;
    private boolean mapMode;
    private boolean stakeoutMapReady;
    private boolean mapAutoFollow = true;
    private double lastMapCurrentLat = Double.NaN;
    private double lastMapCurrentLon = Double.NaN;
    private double lastMapTargetLat = Double.NaN;
    private double lastMapTargetLon = Double.NaN;
    private double lastMapDistance = Double.NaN;

    private boolean running;
    private Location lastLocation;
    private Location smoothedLocation;
    private boolean arrivalVibrated;
    private boolean pendingUseCurrent;

    private final SensorEventListener headingListener = new SensorEventListener() {
        private final float[] rotation = new float[9];
        private final float[] inclination = new float[9];
        private final float[] orientation = new float[3];
        private final float[] gravityValues = new float[3];
        private final float[] geomagneticValues = new float[3];
        private boolean hasGravity;
        private boolean hasGeomagnetic;

        @Override public void onSensorChanged(SensorEvent event) {
            if (event == null || event.sensor == null || event.values == null) return;
            try {
                boolean ready = false;
                int type = event.sensor.getType();
                if (type == Sensor.TYPE_ROTATION_VECTOR) {
                    SensorManager.getRotationMatrixFromVector(rotation, event.values);
                    SensorManager.getOrientation(rotation, orientation);
                    ready = true;
                } else if (type == Sensor.TYPE_ACCELEROMETER) {
                    lowPass(event.values, gravityValues);
                    hasGravity = true;
                    ready = hasGeomagnetic
                            && SensorManager.getRotationMatrix(rotation, inclination, gravityValues, geomagneticValues);
                    if (ready) SensorManager.getOrientation(rotation, orientation);
                } else if (type == Sensor.TYPE_MAGNETIC_FIELD) {
                    lowPass(event.values, geomagneticValues);
                    hasGeomagnetic = true;
                    ready = hasGravity
                            && SensorManager.getRotationMatrix(rotation, inclination, gravityValues, geomagneticValues);
                    if (ready) SensorManager.getOrientation(rotation, orientation);
                }
                if (!ready) return;

                float raw = (float) normalizeBearing(Math.toDegrees(orientation[0]));
                if (!headingAvailable) {
                    magneticHeadingDegrees = raw;
                } else {
                    float delta = (float) (((raw - magneticHeadingDegrees + 540.0) % 360.0) - 180.0);
                    magneticHeadingDegrees = (float) normalizeBearing(magneticHeadingDegrees + delta * 0.22f);
                }
                headingAvailable = true;
                trueHeadingDegrees = magneticHeadingDegrees;
                Location reference = lastLocation != null ? lastLocation : smoothedLocation;
                if (reference != null) {
                    float altitude = reference.hasAltitude() ? (float) reference.getAltitude() : 0f;
                    GeomagneticField field = new GeomagneticField(
                            (float) reference.getLatitude(), (float) reference.getLongitude(), altitude, System.currentTimeMillis());
                    trueHeadingDegrees = (float) normalizeBearing(magneticHeadingDegrees + field.getDeclination());
                }
                if (navigationView != null) navigationView.setHeading(trueHeadingDegrees, true);
            } catch (Exception ignored) {}
        }

        private void lowPass(float[] input, float[] output) {
            final float alpha = 0.22f;
            for (int i = 0; i < Math.min(input.length, output.length); i++) {
                output[i] = output[i] + alpha * (input[i] - output[i]);
            }
        }

        @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}
    };

    private final LocationListener listener = new LocationListener() {
        @Override public void onLocationChanged(Location location) {
            if (location == null) return;
            if (lastLocation != null && lastLocation.getTime() > 0 && location.getTime() > 0
                    && location.getTime() < lastLocation.getTime()) return;
            Location filtered = smoothLocation(location);
            if (filtered == null) return;
            lastLocation = filtered;
            if (pendingUseCurrent) {
                pendingUseCurrent = false;
                fillTargetFromLocation(filtered);
                if (!running && locationManager != null) {
                    try { locationManager.removeUpdates(listener); } catch (SecurityException ignored) {}
                }
            }
            updateResult(filtered);
        }

        @Override public void onProviderDisabled(String provider) {
            setStatus("Activa la ubicación/GPS del celular para usar el replanteo.", WARN_AMBER);
        }

        @Override public void onProviderEnabled(String provider) {
            setStatus("GPS activo. Esperando una posición válida...", NAV_BLUE);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MapLibre.getInstance(this);
        MapEngineConfig.configure(this);
        mapSavedState = savedInstanceState;
        applyPalette();
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (sensorManager != null) {
            rotationVectorSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            // Respaldo para equipos sin vector de rotación: acelerómetro + magnetómetro.
            accelerometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            magnetometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);
        root.addView(stakeoutTopBar());

        LinearLayout content = vertical();
        content.addView(buildTargetCard());
        content.addView(buildNavigationCard());
        content.addView(buildMetricsSection());
        content.addView(buildStatusBanner());

        root.addView(scrollWith(content), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        updateMode();
        resetLiveDisplay();
        applyLaunchTarget();
    }

    private void applyLaunchTarget() {
        Intent intent = getIntent();
        if (intent == null || !intent.hasExtra("target_lat") || !intent.hasExtra("target_lon")) return;
        double lat = intent.getDoubleExtra("target_lat", Double.NaN);
        double lon = intent.getDoubleExtra("target_lon", Double.NaN);
        if (!Double.isFinite(lat) || !Double.isFinite(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) return;
        if (utmCheck != null) utmCheck.setChecked(false);
        updateMode();
        if (firstInput != null) firstInput.setText(String.format(Locale.US, "%.8f", lat));
        if (secondInput != null) secondInput.setText(String.format(Locale.US, "%.8f", lon));
        String name = intent.getStringExtra("target_name");
        String prefix = name == null || name.trim().isEmpty() ? "Objetivo cargado desde el mapa."
                : "Objetivo cargado: " + name.trim() + ".";
        setStatus(prefix + " Pulsa Iniciar replanteo.", NAV_BLUE);
        syncTargetPreviewFromInputs(true);
    }

    private LinearLayout stakeoutTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(8), dp(8), dp(8));
        bar.setBackgroundColor(barColor);

        Button back = topIconButton("‹", 30);
        back.setContentDescription("Volver");
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(50)));

        LinearLayout titles = vertical();
        TextView title = text("Replanteo de punto", 20, true);
        title.setTextColor(Color.WHITE);
        titles.addView(title);
        TextView subtitle = text("Objetivo geográfico o UTM WGS84", 12, false);
        subtitle.setTextColor(Color.rgb(215, 228, 240));
        titles.addView(subtitle);
        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button help = topIconButton("?", 18);
        help.setContentDescription("Ayuda de replanteo");
        help.setOnClickListener(v -> showHelp());
        bar.addView(help, new LinearLayout.LayoutParams(dp(44), dp(44)));

        Button more = topIconButton("⋮", 24);
        more.setContentDescription("Más opciones");
        more.setOnClickListener(this::showMoreMenu);
        bar.addView(more, new LinearLayout.LayoutParams(dp(44), dp(44)));
        return bar;
    }

    private Button topIconButton(String label, int sizeSp) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(sizeSp);
        button.setTextColor(Color.WHITE);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        button.setPadding(0, 0, 0, 0);
        button.setMinWidth(0);
        button.setMinHeight(0);
        button.setBackgroundColor(Color.TRANSPARENT);
        return button;
    }

    private LinearLayout buildTargetCard() {
        LinearLayout box = card();
        box.setPadding(dp(12), dp(12), dp(12), dp(12));

        TextView warningView = warning("⚠  El GNSS interno del teléfono es orientativo.\nPara replanteo centimétrico se requiere receptor RTK o estación total y control de campo.");
        warningView.setTextColor(themeMode == 0 ? Color.rgb(85, 68, 20) : Color.rgb(244, 234, 204));
        box.addView(warningView);

        Button notebookPoint = secondaryButton("Elegir punto de Libreta de campo");
        notebookPoint.setOnClickListener(v -> chooseNotebookPoint());
        box.addView(notebookPoint);

        utmCheck = new CheckBox(this);
        utmCheck.setText("Ingresar objetivo en UTM WGS84");
        utmCheck.setTextColor(textColor);
        ResponsiveUi.configureCompactText(utmCheck, 14, 11, 2);
        utmCheck.setPadding(dp(2), dp(1), dp(2), dp(1));
        utmCheck.setOnCheckedChangeListener((buttonView, isChecked) -> updateMode());
        box.addView(utmCheck);

        modeHelp = small("");
        modeHelp.setTextSize(12);
        box.addView(modeHelp);

        LinearLayout r1 = horizontal();
        firstInput = numberInput("");
        secondInput = numberInput("");
        r1.addView(labeled("Latitud / Norte UTM", firstInput), weight());
        r1.addView(labeled("Longitud / Este UTM", secondInput), weight());
        box.addView(r1);

        utmOptions = horizontal();
        zoneInput = integerInput("19");
        zoneInput.setText("19");
        southCheck = new CheckBox(this);
        southCheck.setText("Hemisferio Sur (S)");
        southCheck.setTextColor(textColor);
        ResponsiveUi.configureCompactText(southCheck, 12, 10, 2);
        southCheck.setChecked(true);
        utmOptions.addView(labeled("Zona UTM (1–60)", zoneInput), weight());
        utmOptions.addView(southCheck, weight());
        box.addView(utmOptions);

        toleranceInput = numberInput("2.0");
        toleranceInput.setText("2.0");
        toleranceInput.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence t, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence t, int a, int b, int c) { }
            @Override public void afterTextChanged(android.text.Editable e) {
                // El radar refleja la tolerancia aunque el replanteo aún no haya iniciado.
                if (navigationView != null) navigationView.setToleranceHint(parse(toleranceInput));
            }
        });
        box.addView(labeled("Tolerancia de llegada (m)", toleranceInput));

        LinearLayout actions = horizontal();
        startButton = primaryButton("▶  Iniciar replanteo");
        startButton.setOnClickListener(v -> toggle());
        actions.addView(startButton, weight());
        Button current = secondaryButton("⌖  Usar posición actual");
        current.setOnClickListener(v -> useCurrent());
        actions.addView(current, weight());
        box.addView(actions);
        return box;
    }

    private LinearLayout buildNavigationCard() {
        LinearLayout box = card();
        box.setPadding(dp(6), dp(6), dp(6), dp(6));

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setGravity(Gravity.CENTER);
        tabs.setPadding(dp(4), dp(3), dp(4), dp(7));

        topViewButton = navigationTabButton("Radar");
        topViewButton.setOnClickListener(v -> showNavigationMode(false));
        tabs.addView(topViewButton, new LinearLayout.LayoutParams(0, dp(42), 1f));

        mapViewButton = navigationTabButton("Mapa");
        mapViewButton.setOnClickListener(v -> showNavigationMode(true));
        LinearLayout.LayoutParams mapTabLp = new LinearLayout.LayoutParams(0, dp(42), 1f);
        mapTabLp.setMargins(dp(6), 0, 0, 0);
        tabs.addView(mapViewButton, mapTabLp);
        box.addView(tabs);

        navigationContainer = new FrameLayout(this);
        int height = ResponsiveUi.isNarrow(this) ? dp(330) : dp(360);
        box.addView(navigationContainer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, height));

        navigationView = new StakeoutNavigationView();
        navigationContainer.addView(navigationView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        stakeoutMapView = new MapView(this);
        stakeoutMapView.onCreate(mapSavedState);
        stakeoutMapView.setVisibility(View.GONE);
        stakeoutMapView.setOnTouchListener((view, event) -> {
            int action = event.getActionMasked();
            if (action == android.view.MotionEvent.ACTION_DOWN
                    || action == android.view.MotionEvent.ACTION_MOVE
                    || action == android.view.MotionEvent.ACTION_POINTER_DOWN) {
                mapAutoFollow = false;
                if (view.getParent() != null) view.getParent().requestDisallowInterceptTouchEvent(true);
            } else if (action == android.view.MotionEvent.ACTION_UP
                    || action == android.view.MotionEvent.ACTION_CANCEL) {
                if (view.getParent() != null) view.getParent().requestDisallowInterceptTouchEvent(false);
            }
            return false;
        });
        navigationContainer.addView(stakeoutMapView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        Button centerMap = topIconButton("⌖", 23);
        centerMap.setContentDescription("Centrar posición y objetivo");
        centerMap.setTextColor(Color.WHITE);
        GradientDrawable centerBg = new GradientDrawable();
        centerBg.setColor(Color.argb(232, 9, 31, 48));
        centerBg.setCornerRadius(dp(20));
        centerBg.setStroke(dp(1), withAlpha(borderColor, 160));
        centerMap.setBackground(centerBg);
        centerMap.setOnClickListener(v -> { mapAutoFollow = true; centerStakeoutMap(true); });
        FrameLayout.LayoutParams centerLp = new FrameLayout.LayoutParams(dp(42), dp(42), Gravity.END | Gravity.BOTTOM);
        centerLp.setMargins(0, 0, dp(10), dp(10));
        navigationContainer.addView(centerMap, centerLp);
        centerMap.setTag("stakeout_map_center");
        centerMap.setVisibility(View.GONE);

        stakeoutMapView.getMapAsync(mapLibreMap -> {
            stakeoutMap = mapLibreMap;
            stakeoutMap.getUiSettings().setLogoEnabled(false);
            stakeoutMap.getUiSettings().setAttributionEnabled(true);
            stakeoutMap.getUiSettings().setAttributionGravity(Gravity.BOTTOM | Gravity.START);
            stakeoutMap.getUiSettings().setCompassEnabled(false);
            stakeoutMap.setMinZoomPreference(2.0);
            stakeoutMap.setMaxZoomPreference(20.0);
            stakeoutMap.setStyle(new Style.Builder().fromUri(STAKEOUT_MAP_STYLE), style -> {
                stakeoutMapReady = true;
                redrawStakeoutMap();
                if (mapMode) centerStakeoutMap(false);
            });
        });

        showNavigationMode(false);
        return box;
    }

    private Button navigationTabButton(String label) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(label);
        button.setTextColor(textColor);
        ResponsiveUi.configureCompactText(button, 12.5f, 10f, 1);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(8), 0, dp(8), 0);
        return button;
    }

    private void showNavigationMode(boolean showMap) {
        mapMode = showMap;
        if (navigationView != null) navigationView.setVisibility(showMap ? View.GONE : View.VISIBLE);
        if (stakeoutMapView != null) stakeoutMapView.setVisibility(showMap ? View.VISIBLE : View.GONE);
        if (navigationContainer != null) {
            for (int i = 0; i < navigationContainer.getChildCount(); i++) {
                View child = navigationContainer.getChildAt(i);
                if ("stakeout_map_center".equals(child.getTag())) child.setVisibility(showMap ? View.VISIBLE : View.GONE);
            }
        }
        styleNavigationTab(topViewButton, !showMap);
        styleNavigationTab(mapViewButton, showMap);
        if (showMap) {
            mapAutoFollow = true;
            syncTargetPreviewFromInputs(false);
            centerStakeoutMap(false);
        }
    }

    private void styleNavigationTab(Button button, boolean active) {
        if (button == null) return;
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(active ? NAV_BLUE : (themeMode == 0 ? Color.rgb(238, 244, 249) : Color.rgb(11, 35, 54)));
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), active ? withAlpha(Color.WHITE, 85) : withAlpha(borderColor, 115));
        button.setBackground(bg);
        button.setTextColor(active ? Color.WHITE : textColor);
    }

    private LinearLayout buildMetricsSection() {
        LinearLayout section = vertical();

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setWeightSum(4f);
        row.setPadding(0, 0, 0, dp(6));

        MetricTile distance = metricTile("⚑", "Distancia restante", NAV_BLUE);
        distanceValue = distance.value;
        row.addView(distance.root, metricWeight());

        MetricTile azimuth = metricTile("◉", "Azimut", VALUE_GREEN);
        azimuthValue = azimuth.value;
        row.addView(azimuth.root, metricWeight());

        MetricTile north = metricTile("↑", "Δ Norte", VALUE_GREEN);
        northValue = north.value;
        row.addView(north.root, metricWeight());

        MetricTile east = metricTile("→", "Δ Este", VALUE_GREEN);
        eastValue = east.value;
        row.addView(east.root, metricWeight());
        section.addView(row);

        LinearLayout precisionCard = card();
        precisionCard.setOrientation(LinearLayout.HORIZONTAL);
        precisionCard.setGravity(Gravity.CENTER_VERTICAL);
        precisionCard.setPadding(dp(12), dp(10), dp(12), dp(10));

        TextView icon = text("◈", 24, true);
        icon.setTextColor(PURPLE);
        icon.setGravity(Gravity.CENTER);
        precisionCard.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(48)));

        LinearLayout labels = vertical();
        TextView pLabel = text("Precisión actual", 12, false);
        pLabel.setTextColor(subTextColor);
        labels.addView(pLabel);
        precisionValue = text("—", 18, true);
        labels.addView(precisionValue);
        precisionDetail = text("Esperando posición", 11, false);
        precisionDetail.setTextColor(subTextColor);
        precisionDetail.setMaxLines(2);
        labels.addView(precisionDetail);
        precisionCard.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView bars = text("▂▄▆█", 22, true);
        bars.setTextColor(VALUE_GREEN);
        bars.setGravity(Gravity.CENTER);
        precisionCard.addView(bars, new LinearLayout.LayoutParams(dp(72), dp(54)));
        section.addView(precisionCard);
        return section;
    }

    private LinearLayout buildStatusBanner() {
        LinearLayout banner = new LinearLayout(this);
        banner.setOrientation(LinearLayout.HORIZONTAL);
        banner.setGravity(Gravity.CENTER_VERTICAL);
        banner.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(6));
        banner.setLayoutParams(lp);

        TextView info = text("i", 16, true);
        info.setGravity(Gravity.CENTER);
        info.setTextColor(Color.WHITE);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setShape(GradientDrawable.OVAL);
        iconBg.setColor(NAV_BLUE);
        info.setBackground(iconBg);
        banner.addView(info, new LinearLayout.LayoutParams(dp(34), dp(34)));

        statusText = text("Replanteo detenido. Completa el objetivo y pulsa Iniciar replanteo.", 13, false);
        statusText.setPadding(dp(10), 0, 0, 0);
        statusText.setLineSpacing(0, 1.08f);
        banner.addView(statusText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        styleStatusBanner(banner, NAV_BLUE);
        statusText.setTag(banner);
        return banner;
    }

    private LinearLayout.LayoutParams metricWeight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(102), 1f);
        int gap = ResponsiveUi.isNarrow(this) ? dp(2) : dp(4);
        lp.setMargins(gap, 0, gap, 0);
        return lp;
    }

    private MetricTile metricTile(String iconText, String labelText, int valueColor) {
        LinearLayout root = vertical();
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(5), dp(8), dp(5), dp(7));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(cardColor);
        bg.setCornerRadius(dp(13));
        bg.setStroke(dp(1), withAlpha(borderColor, 145));
        root.setBackground(bg);

        TextView icon = text(iconText, 18, true);
        icon.setTextColor(valueColor);
        icon.setGravity(Gravity.CENTER);
        root.addView(icon, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));

        TextView label = text(labelText, 10, false);
        label.setTextColor(subTextColor);
        label.setGravity(Gravity.CENTER);
        ResponsiveUi.configureCompactText(label, 10, 8, 2);
        root.addView(label, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(30)));

        TextView value = text("—", 15, true);
        value.setTextColor(valueColor);
        value.setGravity(Gravity.CENTER);
        ResponsiveUi.configureCompactText(value, 15, 10, 2);
        root.addView(value, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(32)));
        return new MetricTile(root, value);
    }

    private void updateMode() {
        boolean utm = utmCheck != null && utmCheck.isChecked();
        if (utmOptions != null) utmOptions.setVisibility(utm ? View.VISIBLE : View.GONE);
        if (modeHelp != null) modeHelp.setText(utm
                ? "Modo UTM: Norte (Y), Este (X), zona y hemisferio del proyecto."
                : "Modo geográfico: latitud y longitud en grados decimales.");
        if (firstInput != null && secondInput != null) {
            firstInput.setHint(utm ? "Norte UTM" : "Latitud");
            secondInput.setHint(utm ? "Este UTM" : "Longitud");
        }
    }

    private void toggle() {
        if (running) {
            stopUpdates();
            setStatus("Replanteo detenido. La última guía queda visible.", NAV_BLUE);
            return;
        }
        try {
            Target target = readTarget();
            if (parse(toleranceInput) <= 0) throw new IllegalArgumentException();
            previewTargetOnMap(target, false);
        } catch (Exception e) {
            showToast("Revisa la coordenada objetivo, zona/hemisferio y tolerancia.");
            setStatus("Faltan datos válidos del punto objetivo.", WARN_AMBER);
            return;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        startUpdates();
    }

    private Target readTarget() {
        if (!utmCheck.isChecked()) {
            double lat = parse(firstInput), lon = parse(secondInput);
            if (lat < -90 || lat > 90 || lon < -180 || lon > 180) throw new IllegalArgumentException();
            return new Target(lat, lon, null);
        }
        double northing = parse(firstInput), easting = parse(secondInput);
        int zone = (int) Math.round(parse(zoneInput));
        if (Math.abs(parse(zoneInput) - zone) > 1e-9 || zone < 1 || zone > 60) throw new IllegalArgumentException();
        CoordinateUtils.LatLon ll = CoordinateUtils.fromUtm(easting, northing, zone, southCheck.isChecked());
        if (!ll.valid) throw new IllegalArgumentException();
        return new Target(ll.latitude, ll.longitude,
                new CoordinateUtils.Utm(true, zone, southCheck.isChecked(), easting, northing));
    }

    private void startUpdates() {
        if (locationManager == null) {
            setStatus("El servicio de ubicación no está disponible.", WARN_AMBER);
            return;
        }
        try {
            boolean requested = false;
            boolean gpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            if (gpsEnabled) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener);
                requested = true;
            } else if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1500L, 0f, listener);
                requested = true;
            }
            if (!requested) {
                setStatus("Activa la ubicación del celular.", WARN_AMBER);
                return;
            }
            running = true;
            arrivalVibrated = false;
            smoothedLocation = null;
            startButton.setText("■  Detener replanteo");
            setStatus(gpsEnabled
                    ? "Buscando señal GNSS... Mantén vista despejada al cielo."
                    : "Usando ubicación de red aproximada; activa GPS para mejorar.", NAV_BLUE);
        } catch (SecurityException e) {
            setStatus("No se concedió el permiso de ubicación.", WARN_AMBER);
        }
    }

    private void stopUpdates() {
        if (locationManager != null) {
            try { locationManager.removeUpdates(listener); } catch (SecurityException ignored) {}
        }
        running = false;
        pendingUseCurrent = false;
        if (startButton != null) startButton.setText("▶  Iniciar replanteo");
    }

    private Location smoothLocation(Location incoming) {
        if (incoming == null) return null;
        if (smoothedLocation == null) {
            smoothedLocation = new Location(incoming);
            return new Location(smoothedLocation);
        }

        float accuracy = incoming.hasAccuracy() ? Math.max(1f, incoming.getAccuracy()) : 10f;
        double alpha;
        if (accuracy <= 3f) alpha = 0.68;
        else if (accuracy <= 6f) alpha = 0.52;
        else if (accuracy <= 12f) alpha = 0.36;
        else if (accuracy <= 25f) alpha = 0.24;
        else alpha = 0.16;

        float jump = smoothedLocation.distanceTo(incoming);
        long dt = incoming.getTime() > 0 && smoothedLocation.getTime() > 0
                ? incoming.getTime() - smoothedLocation.getTime() : 1000L;
        if (dt > 0 && dt < 3000L && jump > Math.max(30f, accuracy * 4f)) {
            alpha = Math.min(alpha, 0.08);
        }

        Location filtered = new Location(incoming);
        filtered.setLatitude(smoothedLocation.getLatitude()
                + (incoming.getLatitude() - smoothedLocation.getLatitude()) * alpha);
        filtered.setLongitude(smoothedLocation.getLongitude()
                + (incoming.getLongitude() - smoothedLocation.getLongitude()) * alpha);
        if (incoming.hasAltitude() && smoothedLocation.hasAltitude()) {
            filtered.setAltitude(smoothedLocation.getAltitude()
                    + (incoming.getAltitude() - smoothedLocation.getAltitude()) * alpha);
        }
        smoothedLocation = new Location(filtered);
        return filtered;
    }

    private void updateResult(Location current) {
        if (!running || current == null) return;
        try {
            Target targetData = readTarget();
            double tolerance = parse(toleranceInput);
            Location target = new Location("target");
            target.setLatitude(targetData.latitude);
            target.setLongitude(targetData.longitude);
            float distance = current.distanceTo(target);
            float bearing = (float) normalizeBearing(current.bearingTo(target));

            double dNorth;
            double dEast;
            String coordinateInfo;
            if (targetData.utm != null) {
                CoordinateUtils.Utm currentUtm = CoordinateUtils.toUtm(
                        current.getLatitude(), current.getLongitude(), targetData.utm.zone);
                if (!currentUtm.valid) throw new IllegalArgumentException();
                dNorth = targetData.utm.northing - currentUtm.northing;
                dEast = targetData.utm.easting - currentUtm.easting;
                coordinateInfo = "UTM " + currentUtm.zone + currentUtm.hemisphere()
                        + " · N " + f3(currentUtm.northing) + " · E " + f3(currentUtm.easting);
            } else {
                double latRad = Math.toRadians((current.getLatitude() + targetData.latitude) / 2.0);
                dNorth = (targetData.latitude - current.getLatitude()) * 111320.0;
                dEast = (targetData.longitude - current.getLongitude()) * 111320.0 * Math.cos(latRad);
                coordinateInfo = "Actual " + f7(current.getLatitude()) + ", " + f7(current.getLongitude());
            }

            float accuracyMeters = current.hasAccuracy() ? Math.max(0f, current.getAccuracy()) : 0f;
            boolean arrived = distance <= tolerance;
            boolean withinAccuracy = !arrived && accuracyMeters > 0f
                    && distance <= Math.max(tolerance, accuracyMeters);
            boolean bearingReliable = distance > Math.max(3.0, accuracyMeters > 0f ? accuracyMeters * 1.15 : 3.0);

            if (arrived && !arrivalVibrated) {
                arrivalVibrated = true;
                vibrateArrival();
            }
            if (distance > Math.max(tolerance * 1.5, accuracyMeters * 1.5)) arrivalVibrated = false;

            String age = current.getTime() > 0
                    ? f1(Math.max(0, System.currentTimeMillis() - current.getTime()) / 1000.0) + " s"
                    : "—";
            String accuracy = current.hasAccuracy() ? "±" + f1(current.getAccuracy()) + " m" : "—";

            distanceValue.setText((withinAccuracy ? "≈" : "") + f2(distance) + " m");
            azimuthValue.setText(bearingReliable ? f1(bearing) + "°" : "—");
            northValue.setText(signed(dNorth) + " m");
            eastValue.setText(signed(dEast) + " m");
            precisionValue.setText(accuracy);
            String provider = current.getProvider() == null ? "ubicación" : current.getProvider().toUpperCase(Locale.US);
            String bearingNote = bearingReliable ? "" : " · azimut inestable por cercanía";
            precisionDetail.setText(provider + " · " + coordinateInfo + " · edad " + age + bearingNote);

            navigationView.setAccuracy(accuracyMeters);
            navigationView.setNavigation(dNorth, dEast, distance, tolerance, bearing, arrived, withinAccuracy);
            navigationView.setHeading(trueHeadingDegrees, headingAvailable);
            updateStakeoutMap(current, target, distance);

            if (arrived) {
                setStatus("✓ Objetivo dentro de la tolerancia de " + f2(tolerance) + " m.", TARGET_GREEN);
            } else if (withinAccuracy) {
                setStatus("≈ Dentro de la precisión GPS (" + accuracy + "). El celular no puede confirmar una posición más exacta.", TARGET_GREEN);
            } else {
                setStatus("A " + f2(distance) + " m del objetivo · " + direction(dNorth, dEast), NAV_BLUE);
            }
        } catch (Exception e) {
            setStatus("Revisa la coordenada objetivo, la zona UTM y la tolerancia.", WARN_AMBER);
        }
    }

    private void syncTargetPreviewFromInputs(boolean animate) {
        try {
            previewTargetOnMap(readTarget(), animate);
        } catch (Exception ignored) {}
    }

    private void previewTargetOnMap(Target target, boolean animate) {
        if (target == null || !Double.isFinite(target.latitude) || !Double.isFinite(target.longitude)) return;
        lastMapTargetLat = target.latitude;
        lastMapTargetLon = target.longitude;
        Location reference = lastLocation != null ? lastLocation : smoothedLocation;
        if (reference != null) {
            lastMapCurrentLat = reference.getLatitude();
            lastMapCurrentLon = reference.getLongitude();
            Location goal = new Location("target_preview");
            goal.setLatitude(target.latitude);
            goal.setLongitude(target.longitude);
            lastMapDistance = reference.distanceTo(goal);
        } else {
            lastMapCurrentLat = Double.NaN;
            lastMapCurrentLon = Double.NaN;
            lastMapDistance = Double.NaN;
        }
        redrawStakeoutMap();
        if (mapMode) centerStakeoutMap(animate);
    }

    private void updateStakeoutMap(Location current, Location target, double distance) {
        if (current == null || target == null) return;
        boolean firstMapPosition = !Double.isFinite(lastMapCurrentLat) || !Double.isFinite(lastMapTargetLat);
        lastMapCurrentLat = current.getLatitude();
        lastMapCurrentLon = current.getLongitude();
        lastMapTargetLat = target.getLatitude();
        lastMapTargetLon = target.getLongitude();
        lastMapDistance = distance;
        redrawStakeoutMap();
        if (mapMode && (firstMapPosition || mapAutoFollow)) centerStakeoutMap(false);
    }

    private void redrawStakeoutMap() {
        if (!stakeoutMapReady || stakeoutMap == null
                || !Double.isFinite(lastMapTargetLat) || !Double.isFinite(lastMapTargetLon)) return;
        try {
            if (stakeoutCurrentMarker != null) stakeoutMap.removeMarker(stakeoutCurrentMarker);
            if (stakeoutTargetMarker != null) stakeoutMap.removeMarker(stakeoutTargetMarker);
            if (stakeoutRouteLine != null) stakeoutMap.removePolyline(stakeoutRouteLine);
        } catch (Exception ignored) {}
        stakeoutCurrentMarker = null;
        stakeoutTargetMarker = null;
        stakeoutRouteLine = null;

        LatLng target = new LatLng(lastMapTargetLat, lastMapTargetLon);
        stakeoutTargetMarker = stakeoutMap.addMarker(new MarkerOptions()
                .position(target)
                .title("Objetivo")
                .icon(IconFactory.getInstance(this).fromBitmap(createStakeoutMapDot(TARGET_RED, true))));

        if (Double.isFinite(lastMapCurrentLat) && Double.isFinite(lastMapCurrentLon)) {
            LatLng current = new LatLng(lastMapCurrentLat, lastMapCurrentLon);
            stakeoutCurrentMarker = stakeoutMap.addMarker(new MarkerOptions()
                    .position(current)
                    .title("Mi posición")
                    .icon(IconFactory.getInstance(this).fromBitmap(createStakeoutMapDot(NAV_BLUE, false))));
            stakeoutRouteLine = stakeoutMap.addPolyline(new PolylineOptions()
                    .add(current, target)
                    .color(NAV_BLUE)
                    .width(5f));
        }
    }

    private Bitmap createStakeoutMapDot(int color, boolean target) {
        int size = dp(target ? 30 : 26);
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        float c = size / 2f;
        paint.setColor(withAlpha(color, 70));
        canvas.drawCircle(c, c, size * 0.43f, paint);
        paint.setColor(Color.WHITE);
        canvas.drawCircle(c, c, size * 0.29f, paint);
        paint.setColor(color);
        canvas.drawCircle(c, c, size * 0.22f, paint);
        if (target) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(1.5f));
            canvas.drawCircle(c, c, size * 0.38f, paint);
        }
        return bitmap;
    }

    private void centerStakeoutMap(boolean animate) {
        if (stakeoutMap == null || !Double.isFinite(lastMapTargetLat) || !Double.isFinite(lastMapTargetLon)) return;

        boolean hasCurrent = Double.isFinite(lastMapCurrentLat) && Double.isFinite(lastMapCurrentLon);
        double lat = hasCurrent ? (lastMapCurrentLat + lastMapTargetLat) / 2.0 : lastMapTargetLat;
        double lon = hasCurrent ? (lastMapCurrentLon + lastMapTargetLon) / 2.0 : lastMapTargetLon;
        double distance = hasCurrent && Double.isFinite(lastMapDistance) ? lastMapDistance : 0.0;
        double zoom;
        if (!hasCurrent) zoom = 17.0;
        else if (distance > 10000) zoom = 9.5;
        else if (distance > 3000) zoom = 11.0;
        else if (distance > 1000) zoom = 12.5;
        else if (distance > 300) zoom = 14.0;
        else if (distance > 100) zoom = 15.0;
        else if (distance > 30) zoom = 16.3;
        else if (distance > 10) zoom = 17.2;
        else zoom = 18.2;
        CameraPosition camera = new CameraPosition.Builder()
                .target(new LatLng(lat, lon))
                .zoom(zoom)
                .bearing(0)
                .tilt(0)
                .build();
        if (animate) stakeoutMap.animateCamera(CameraUpdateFactory.newCameraPosition(camera), 350);
        else stakeoutMap.moveCamera(CameraUpdateFactory.newCameraPosition(camera));
    }

    private String direction(double north, double east) {
        String ns = Math.abs(north) < 0.3 ? "" : (north > 0 ? "Norte" : "Sur");
        String ew = Math.abs(east) < 0.3 ? "" : (east > 0 ? "Este" : "Oeste");
        if (!ns.isEmpty() && !ew.isEmpty()) return "avanza hacia " + ns + " y " + ew + ".";
        if (!ns.isEmpty()) return "avanza hacia el " + ns + ".";
        if (!ew.isEmpty()) return "avanza hacia el " + ew + ".";
        return "muy cerca del objetivo.";
    }

    private void vibrateArrival() {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vibrator == null || !vibrator.hasVibrator()) return;
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(VibrationEffect.createWaveform(new long[]{0, 180, 100, 180}, -1));
        } else {
            vibrator.vibrate(new long[]{0, 180, 100, 180}, -1);
        }
    }

    private void chooseNotebookPoint() {
        List<NotebookStore.Entry> entries = NotebookStore.load(this);
        List<NotebookStore.Entry> usable = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        for (NotebookStore.Entry entry : entries) {
            if (!isUsableNotebookEntry(entry)) continue;
            usable.add(entry);
            String code = entry.code == null || entry.code.trim().isEmpty() ? "Sin código" : entry.code.trim();
            String project = entry.project == null || entry.project.trim().isEmpty() ? "General" : entry.project.trim();
            String crs = entry.crs == null || entry.crs.trim().isEmpty() ? "Sistema no indicado" : entry.crs.trim();
            labels.add(code + " · " + project + "\n" + crs);
        }
        if (usable.isEmpty()) {
            showToast("No hay puntos compatibles en la Libreta de campo.");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Elegir punto de Libreta")
                .setItems(labels.toArray(new String[0]), (dialog, which) -> fillTargetFromNotebook(usable.get(which)))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private boolean isUsableNotebookEntry(NotebookStore.Entry entry) {
        if (entry == null || entry.north == null || entry.east == null) return false;
        try {
            double north = Double.parseDouble(entry.north.trim().replace(',', '.'));
            double east = Double.parseDouble(entry.east.trim().replace(',', '.'));
            String crs = entry.crs == null ? "" : entry.crs.toLowerCase(Locale.US);
            if (crs.contains("geogr") || crs.contains("lat") || crs.contains("lon")) {
                return north >= -90 && north <= 90 && east >= -180 && east <= 180;
            }
            if (crs.contains("utm")) return extractUtmZone(entry.crs) >= 1;
            return north >= -90 && north <= 90 && east >= -180 && east <= 180;
        } catch (Exception e) {
            return false;
        }
    }

    private void fillTargetFromNotebook(NotebookStore.Entry entry) {
        try {
            double north = Double.parseDouble(entry.north.trim().replace(',', '.'));
            double east = Double.parseDouble(entry.east.trim().replace(',', '.'));
            String crs = entry.crs == null ? "" : entry.crs;
            String lower = crs.toLowerCase(Locale.US);
            if (lower.contains("utm")) {
                int zone = extractUtmZone(crs);
                if (zone < 1 || zone > 60) {
                    showToast("Ese punto UTM no tiene una zona válida en la Libreta.");
                    return;
                }
                utmCheck.setChecked(true);
                zoneInput.setText(String.valueOf(zone));
                southCheck.setChecked(extractSouthHemisphere(crs));
                firstInput.setText(f3(north));
                secondInput.setText(f3(east));
            } else {
                if (north < -90 || north > 90 || east < -180 || east > 180) {
                    showToast("Ese punto no tiene un sistema de coordenadas compatible.");
                    return;
                }
                utmCheck.setChecked(false);
                firstInput.setText(f7(north));
                secondInput.setText(f7(east));
            }
            String code = entry.code == null || entry.code.trim().isEmpty() ? "punto" : entry.code.trim();
            setStatus("Objetivo cargado desde Libreta: " + code + ".", NAV_BLUE);
            syncTargetPreviewFromInputs(true);
            showToast("Punto " + code + " cargado.");
        } catch (Exception e) {
            showToast("No se pudo cargar ese punto de la Libreta.");
        }
    }

    private int extractUtmZone(String crs) {
        if (crs == null) return -1;
        String value = crs.toUpperCase(Locale.US);
        int utm = value.indexOf("UTM");
        if (utm < 0) return -1;
        for (int i = utm + 3; i < value.length(); i++) {
            if (!Character.isDigit(value.charAt(i))) continue;
            int j = i;
            while (j < value.length() && Character.isDigit(value.charAt(j))) j++;
            try {
                int zone = Integer.parseInt(value.substring(i, j));
                return zone >= 1 && zone <= 60 ? zone : -1;
            } catch (Exception ignored) {
                return -1;
            }
        }
        return -1;
    }

    private boolean extractSouthHemisphere(String crs) {
        if (crs == null) return true;
        String value = crs.toUpperCase(Locale.US).replace(" ", "");
        int zone = extractUtmZone(crs);
        if (zone < 1) return true;
        return value.contains("UTM" + zone + "S") || value.contains("ZONA" + zone + "S") || value.endsWith(zone + "S");
    }

    private void useCurrent() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            pendingUseCurrent = true;
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        Location current = lastLocation != null ? lastLocation : bestLastKnownLocation();
        if (current == null) {
            pendingUseCurrent = true;
            showToast("Esperando una posición actual del GPS...");
            startUpdatesForCurrentPosition();
            return;
        }
        lastLocation = current;
        fillTargetFromLocation(current);
    }

    private Location bestLastKnownLocation() {
        if (locationManager == null) return null;
        Location best = null;
        try {
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                best = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            }
            Location network = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (network != null && (best == null || network.getTime() > best.getTime())) best = network;
        } catch (SecurityException ignored) {}
        return best;
    }

    private void startUpdatesForCurrentPosition() {
        if (locationManager == null) return;
        try {
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener);
            } else if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1500L, 0f, listener);
            } else {
                pendingUseCurrent = false;
                showToast("Activa la ubicación del celular.");
            }
        } catch (SecurityException ignored) {
            pendingUseCurrent = false;
        }
    }

    private void fillTargetFromLocation(Location location) {
        if (location == null) return;
        if (utmCheck.isChecked()) {
            int zone;
            try {
                zone = (int) Math.round(parse(zoneInput));
                if (zone < 1 || zone > 60) throw new IllegalArgumentException();
            } catch (Exception e) {
                CoordinateUtils.Utm auto = CoordinateUtils.toUtm(location.getLatitude(), location.getLongitude());
                if (!auto.valid) {
                    showToast("No se pudo convertir la posición a UTM.");
                    return;
                }
                zone = auto.zone;
                zoneInput.setText(String.valueOf(zone));
            }
            CoordinateUtils.Utm u = CoordinateUtils.toUtm(location.getLatitude(), location.getLongitude(), zone);
            if (!u.valid) {
                showToast("No se pudo convertir la posición a UTM.");
                return;
            }
            firstInput.setText(f3(u.northing));
            secondInput.setText(f3(u.easting));
            southCheck.setChecked(u.south);
        } else {
            firstInput.setText(f7(location.getLatitude()));
            secondInput.setText(f7(location.getLongitude()));
        }
        syncTargetPreviewFromInputs(true);
        showToast("Objetivo cargado con la posición actual.");
    }

    private void setStatus(String message, int color) {
        if (statusText == null) return;
        statusText.setText(message);
        Object tag = statusText.getTag();
        if (tag instanceof LinearLayout) styleStatusBanner((LinearLayout) tag, color);
    }

    private void styleStatusBanner(LinearLayout banner, int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == 0 ? Color.WHITE : Color.rgb(8, 31, 49));
        bg.setCornerRadius(dp(13));
        bg.setStroke(dp(1), withAlpha(color, 220));
        banner.setBackground(bg);
    }

    private void resetLiveDisplay() {
        if (distanceValue != null) distanceValue.setText("—");
        if (azimuthValue != null) azimuthValue.setText("—");
        if (northValue != null) northValue.setText("—");
        if (eastValue != null) eastValue.setText("—");
        if (precisionValue != null) precisionValue.setText("—");
        if (precisionDetail != null) precisionDetail.setText("Esperando posición");
        if (navigationView != null) {
            navigationView.setAccuracy(0f);
            navigationView.clearNavigation("Sin objetivo · pulsa Iniciar replanteo para guiarte");
            navigationView.setToleranceHint(parse(toleranceInput));
        }
        lastMapCurrentLat = Double.NaN;
        lastMapCurrentLon = Double.NaN;
        lastMapTargetLat = Double.NaN;
        lastMapTargetLon = Double.NaN;
        lastMapDistance = Double.NaN;
        setStatus("Replanteo detenido. Completa el objetivo y pulsa Iniciar replanteo.", NAV_BLUE);
    }

    private void showHelp() {
        new AlertDialog.Builder(this)
                .setTitle("Replanteo de punto")
                .setMessage("1. Ingresa el objetivo en coordenadas geográficas o UTM WGS84.\n\n"
                        + "2. Define la tolerancia de llegada.\n\n"
                        + "3. Pulsa Iniciar replanteo. Puedes alternar entre Radar y Mapa. El Radar usa la orientación del teléfono y el Mapa muestra tu posición y el objetivo.\n\n"
                        + "4. Distancia, azimut, Δ Norte, Δ Este y precisión se actualizan con cada lectura GNSS. Si la distancia es menor que la precisión del teléfono, se indica como aproximada.\n\n"
                        + "El GNSS interno es orientativo; para precisión centimétrica usa RTK o estación total.")
                .setPositiveButton("Entendido", null)
                .show();
    }

    private void showMoreMenu(View anchor) {
        PopupMenu menu = new PopupMenu(this, anchor);
        menu.getMenu().add("Modo geográfico");
        menu.getMenu().add("Modo UTM WGS84");
        menu.getMenu().add("Usar posición actual");
        if (running) menu.getMenu().add("Detener replanteo");
        menu.setOnMenuItemClickListener(item -> {
            String title = String.valueOf(item.getTitle());
            if ("Modo geográfico".equals(title)) {
                utmCheck.setChecked(false);
                return true;
            }
            if ("Modo UTM WGS84".equals(title)) {
                utmCheck.setChecked(true);
                return true;
            }
            if ("Usar posición actual".equals(title)) {
                useCurrent();
                return true;
            }
            if ("Detener replanteo".equals(title)) {
                stopUpdates();
                setStatus("Replanteo detenido. La última guía queda visible.", NAV_BLUE);
                return true;
            }
            return false;
        });
        menu.show();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_LOCATION) return;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (pendingUseCurrent) startUpdatesForCurrentPosition();
            else startUpdates();
        } else {
            pendingUseCurrent = false;
            setStatus("Sin permiso de ubicación no se puede usar el replanteo.", WARN_AMBER);
        }
    }

    @Override protected void onStart() {
        super.onStart();
        if (stakeoutMapView != null) stakeoutMapView.onStart();
    }

    @Override protected void onResume() {
        super.onResume();
        if (stakeoutMapView != null) stakeoutMapView.onResume();
        if (sensorManager != null) {
            if (rotationVectorSensor != null) {
                sensorManager.registerListener(headingListener, rotationVectorSensor, SensorManager.SENSOR_DELAY_UI);
            } else if (accelerometerSensor != null && magnetometerSensor != null) {
                sensorManager.registerListener(headingListener, accelerometerSensor, SensorManager.SENSOR_DELAY_UI);
                sensorManager.registerListener(headingListener, magnetometerSensor, SensorManager.SENSOR_DELAY_UI);
            } else {
                headingAvailable = false;
                if (navigationView != null) navigationView.setHeading(0.0, false);
            }
        }
    }

    @Override protected void onPause() {
        if (sensorManager != null) sensorManager.unregisterListener(headingListener);
        stopUpdates();
        if (stakeoutMapView != null) stakeoutMapView.onPause();
        super.onPause();
    }

    @Override protected void onStop() {
        if (stakeoutMapView != null) stakeoutMapView.onStop();
        super.onStop();
    }

    @Override public void onLowMemory() {
        super.onLowMemory();
        if (stakeoutMapView != null) stakeoutMapView.onLowMemory();
    }

    @Override protected void onDestroy() {
        if (stakeoutMapView != null) stakeoutMapView.onDestroy();
        super.onDestroy();
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (stakeoutMapView != null) stakeoutMapView.onSaveInstanceState(outState);
    }

    /**
     * Radar de replanteo. Dibuja siempre la rosa (anillos, cardinales y rumbo del teléfono),
     * y cuando hay navegación activa añade el objetivo, la ruta y el círculo de tolerancia.
     */
    private final class StakeoutNavigationView extends View {
        private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint routePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint targetPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint currentPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint subLabelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint chipPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint crossPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint outerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint controlBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint controlStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint controlIconPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tolerancePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        private boolean hasNavigation;
        private double north;
        private double east;
        private double distance;
        private double tolerance = 2.0;
        private double bearing;
        private boolean arrived;
        private boolean withinAccuracy;
        private boolean headingAvailableInView;
        private double headingDegrees;
        private String emptyMessage = "Inicia el replanteo para ver la guía";

        // Barrido, suavizado y eco del radar.
        private final Paint sweepPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint sweepLinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint accuracyFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint accuracyStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private static final float SWEEP_DEGREES_PER_SECOND = 105f;
        private float sweepAngle;
        private float previousSweepAngle;
        private long lastFrameNanos;
        private boolean animating;
        private boolean smoothingReady;
        private double shownDistance;
        private double shownBearing;
        private float accuracyMeters;
        private long lastEchoAt;
        private float pulsePhase;

        private final RectF zoomInControl = new RectF();
        private final RectF zoomOutControl = new RectF();
        private final RectF resetControl = new RectF();
        private float zoomFactor = 1.0f;
        private double lockedRange = 0.0;

        StakeoutNavigationView() {
            super(StakeoutActivity.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            setClickable(true);
            setPadding(dp(4), dp(4), dp(4), dp(4));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(themeMode == 0 ? Color.rgb(245, 249, 253) : Color.rgb(7, 27, 43));
            bg.setCornerRadius(dp(14));
            bg.setStroke(dp(1), withAlpha(borderColor, 110));
            setBackground(bg);

            ringPaint.setStyle(Paint.Style.STROKE);
            ringPaint.setStrokeWidth(dp(1));
            ringPaint.setColor(themeMode == 0 ? Color.argb(58, 32, 101, 170) : Color.argb(78, 62, 137, 198));
            ringPaint.setPathEffect(new DashPathEffect(new float[]{dp(5), dp(5)}, 0));

            crossPaint.setStyle(Paint.Style.STROKE);
            crossPaint.setStrokeWidth(dp(1));
            crossPaint.setColor(themeMode == 0 ? Color.argb(46, 40, 80, 120) : Color.argb(64, 72, 126, 168));

            outerPaint.setStyle(Paint.Style.STROKE);
            outerPaint.setStrokeWidth(dp(1.5f));
            outerPaint.setColor(withAlpha(borderColor, 190));

            fillPaint.setStyle(Paint.Style.FILL);
            fillPaint.setColor(themeMode == 0 ? Color.argb(16, 45, 129, 255) : Color.argb(26, 45, 129, 255));

            routePaint.setStyle(Paint.Style.STROKE);
            routePaint.setStrokeWidth(dp(2.4f));
            routePaint.setStrokeCap(Paint.Cap.ROUND);
            routePaint.setColor(NAV_BLUE);
            routePaint.setPathEffect(new DashPathEffect(new float[]{dp(7), dp(5)}, 0));

            targetPaint.setStyle(Paint.Style.STROKE);
            targetPaint.setStrokeWidth(dp(3));
            targetPaint.setColor(TARGET_RED);

            currentPaint.setStyle(Paint.Style.FILL);
            currentPaint.setColor(NAV_BLUE);

            tolerancePaint.setStyle(Paint.Style.STROKE);
            tolerancePaint.setStrokeWidth(dp(1.6f));
            tolerancePaint.setPathEffect(new DashPathEffect(new float[]{dp(5), dp(4)}, 0));

            labelPaint.setColor(textColor);
            labelPaint.setTextSize(dp(12));
            labelPaint.setTypeface(Typeface.DEFAULT_BOLD);

            subLabelPaint.setColor(subTextColor);
            subLabelPaint.setTextSize(dp(10));

            chipPaint.setColor(themeMode == 0 ? Color.argb(235, 255, 255, 255) : Color.argb(228, 12, 35, 53));
            chipPaint.setStyle(Paint.Style.FILL);

            controlBgPaint.setColor(themeMode == 0 ? Color.argb(238, 255, 255, 255) : Color.argb(235, 9, 31, 48));
            controlStrokePaint.setStyle(Paint.Style.STROKE);
            controlStrokePaint.setStrokeWidth(dp(1));
            controlStrokePaint.setColor(withAlpha(borderColor, 175));
            controlIconPaint.setColor(textColor);
            controlIconPaint.setStyle(Paint.Style.STROKE);
            controlIconPaint.setStrokeWidth(dp(2.2f));
            controlIconPaint.setStrokeCap(Paint.Cap.ROUND);

            sweepPaint.setStyle(Paint.Style.FILL);
            sweepLinePaint.setStyle(Paint.Style.STROKE);
            sweepLinePaint.setStrokeWidth(dp(1.6f));
            sweepLinePaint.setStrokeCap(Paint.Cap.ROUND);
            accuracyFillPaint.setStyle(Paint.Style.FILL);
            accuracyFillPaint.setColor(Color.argb(38, 45, 129, 255));
            accuracyStrokePaint.setStyle(Paint.Style.STROKE);
            accuracyStrokePaint.setStrokeWidth(dp(1.2f));
            accuracyStrokePaint.setColor(Color.argb(120, 45, 129, 255));
        }

        // ----- Animación continua (barrido + suavizado) -----

        private final Runnable frameTick = new Runnable() {
            @Override public void run() {
                if (!animating) return;
                long now = System.nanoTime();
                float dt = lastFrameNanos == 0L ? 0.016f
                        : Math.min(0.05f, (now - lastFrameNanos) / 1_000_000_000f);
                lastFrameNanos = now;
                previousSweepAngle = sweepAngle;
                sweepAngle = (sweepAngle + dt * SWEEP_DEGREES_PER_SECOND) % 360f;
                pulsePhase = (pulsePhase + dt) % 2f;
                stepSmoothing(dt);
                invalidate();
                // ~33 fps: fluido pero sin castigar la batería ni el CPU.
                postDelayed(this, 30L);
            }
        };

        private void startRadarAnimation() {
            if (animating) return;
            animating = true;
            lastFrameNanos = 0L;
            post(frameTick);
        }

        private void stopRadarAnimation() {
            animating = false;
            removeCallbacks(frameTick);
        }

        private boolean shouldAnimate() {
            return isShown() && getWindowVisibility() == View.VISIBLE;
        }

        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            if (shouldAnimate()) startRadarAnimation();
        }

        @Override protected void onDetachedFromWindow() {
            stopRadarAnimation();
            super.onDetachedFromWindow();
        }

        @Override protected void onVisibilityChanged(View changedView, int visibility) {
            super.onVisibilityChanged(changedView, visibility);
            if (visibility == View.VISIBLE && shouldAnimate()) startRadarAnimation();
            else if (visibility != View.VISIBLE) stopRadarAnimation();
        }

        @Override protected void onWindowVisibilityChanged(int visibility) {
            super.onWindowVisibilityChanged(visibility);
            if (visibility == View.VISIBLE && shouldAnimate()) startRadarAnimation();
            else if (visibility != View.VISIBLE) stopRadarAnimation();
        }

        /** El objetivo se mueve suave entre lecturas GNSS en vez de saltar. */
        private void stepSmoothing(float dt) {
            if (!hasNavigation) {
                smoothingReady = false;
                return;
            }
            if (!smoothingReady) {
                shownDistance = distance;
                shownBearing = bearing;
                smoothingReady = true;
                return;
            }
            double k = 1.0 - Math.exp(-dt * 5.5);
            shownDistance += (distance - shownDistance) * k;
            double diff = ((bearing - shownBearing + 540.0) % 360.0) - 180.0;
            shownBearing = normalizeBearing(shownBearing + diff * k);
        }

        /** Precisión GNSS actual: se dibuja como halo alrededor de tu posición. */
        void setAccuracy(float meters) {
            this.accuracyMeters = Math.max(0f, meters);
        }

        void setNavigation(double north, double east, double distance, double tolerance,
                           double bearing, boolean arrived, boolean withinAccuracy) {
            this.hasNavigation = true;
            this.north = north;
            this.east = east;
            this.distance = Math.max(0.0, distance);
            this.tolerance = Math.max(0.0, tolerance);
            this.bearing = bearing;
            this.arrived = arrived;
            this.withinAccuracy = withinAccuracy;
            invalidate();
        }

        void setHeading(double headingDegrees, boolean available) {
            this.headingDegrees = normalizeBearing(headingDegrees);
            this.headingAvailableInView = available;
            invalidate();
        }

        void setToleranceHint(double toleranceMeters) {
            if (hasNavigation) return;
            this.tolerance = Math.max(0.0, toleranceMeters);
            invalidate();
        }

        void clearNavigation(String message) {
            hasNavigation = false;
            smoothingReady = false;
            lastEchoAt = 0L;
            lockedRange = 0.0;
            emptyMessage = message == null ? "" : message;
            invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) return;

            float topReserved = dp(54);
            float bottomReserved = dp(58);
            float cx = w * 0.5f;
            float cy = topReserved + (h - topReserved - bottomReserved) * 0.5f;
            float maxR = Math.min(w * 0.5f - dp(46), (h - topReserved - bottomReserved) * 0.5f - dp(16));
            if (maxR < dp(40)) maxR = dp(40);

            double maxRange = radarMaxRange(hasNavigation ? distance : 0.0, tolerance);

            drawRadarBackground(canvas, cx, cy, maxR);
            drawSweep(canvas, cx, cy, maxR);
            drawRangeRings(canvas, cx, cy, maxR, maxRange);
            drawCardinalLabels(canvas, cx, cy, maxR);
            drawPhoneHeadingMarker(canvas, cx, cy, maxR);
            drawTopLabels(canvas, w, maxRange);
            drawControls(canvas, w, h);

            if (!hasNavigation) {
                drawAccuracyHalo(canvas, cx, cy, maxR, maxRange);
                drawCurrent(canvas, cx, cy);
                subLabelPaint.setTextAlign(Paint.Align.CENTER);
                subLabelPaint.setColor(subTextColor);
                subLabelPaint.setTextSize(dp(11.5f));
                canvas.drawText(emptyMessage, w / 2f, cy + maxR + dp(34), subLabelPaint);
                subLabelPaint.setTextSize(dp(10));
                return;
            }

            double drawBearing = smoothingReady ? shownBearing : bearing;
            double drawDistance = smoothingReady ? shownDistance : distance;
            double relativeBearing = headingAvailableInView
                    ? normalizeSignedBearing(drawBearing - headingDegrees)
                    : normalizeSignedBearing(drawBearing);
            double radians = Math.toRadians(relativeBearing - 90.0);
            boolean outOfRange = drawDistance > maxRange;
            float radius = outOfRange
                    ? maxR
                    : (float) Math.min(maxR, Math.max(dp(10), drawDistance / Math.max(0.01, maxRange) * maxR));
            float targetX = cx + (float) Math.cos(radians) * radius;
            float targetY = cy + (float) Math.sin(radians) * radius;

            checkSweepEcho(relativeBearing);

            canvas.drawLine(cx, cy, targetX, targetY, routePaint);
            drawRouteArrow(canvas, cx, cy, targetX, targetY);
            if (!outOfRange) drawToleranceCircle(canvas, targetX, targetY, maxR, maxRange);
            drawAccuracyHalo(canvas, cx, cy, maxR, maxRange);
            drawCurrent(canvas, cx, cy);
            drawEcho(canvas, targetX, targetY);
            drawTarget(canvas, targetX, targetY, outOfRange, radians);

            drawTargetLabel(canvas, w, targetX, targetY, outOfRange);
            drawDistanceBadge(canvas, w, h);
        }

        private double normalizeSignedBearing(double value) {
            return ((value + 540.0) % 360.0) - 180.0;
        }

        /**
         * Escala del radar. Se engancha a valores redondos y sólo cambia cuando la distancia
         * se sale del rango o baja mucho, para que los anillos no salten en cada lectura GNSS.
         */
        private double radarMaxRange(double distanceMeters, double toleranceMeters) {
            double needed = Math.max(distanceMeters * 1.18, Math.max(5.0, Math.max(1.0, toleranceMeters) * 4.0));
            double[] ranges = {5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000, 100000};
            double base = ranges[ranges.length - 1];
            for (double candidate : ranges) {
                if (candidate >= needed) { base = candidate; break; }
            }
            if (lockedRange > 0.0 && base <= lockedRange && needed > lockedRange * 0.35) base = lockedRange;
            lockedRange = base;
            return Math.max(1.0, base / Math.max(0.25f, zoomFactor));
        }

        /** Barrido giratorio con estela, como un radar de verdad. */
        private void drawSweep(Canvas canvas, float cx, float cy, float maxR) {
            RectF box = new RectF(cx - maxR, cy - maxR, cx + maxR, cy + maxR);
            int segments = 24;
            float span = 3.4f;
            int baseAlpha = themeMode == 0 ? 26 : 46;
            for (int i = 0; i < segments; i++) {
                float alpha = baseAlpha * (1f - (float) i / segments);
                if (alpha < 1.5f) continue;
                sweepPaint.setColor(Color.argb((int) alpha, 74, 168, 255));
                canvas.drawArc(box, sweepAngle - 90f - (i + 1) * span, span + 0.7f, true, sweepPaint);
            }
            double rad = Math.toRadians(sweepAngle - 90f);
            sweepLinePaint.setColor(Color.argb(themeMode == 0 ? 120 : 165, 96, 190, 255));
            canvas.drawLine(cx, cy, cx + (float) Math.cos(rad) * maxR, cy + (float) Math.sin(rad) * maxR, sweepLinePaint);
        }

        /** Marca el instante en que el barrido pasa por encima del objetivo. */
        private void checkSweepEcho(double relativeBearing) {
            float targetAngle = (float) ((relativeBearing + 360.0) % 360.0);
            float from = (previousSweepAngle + 360f) % 360f;
            float to = (sweepAngle + 360f) % 360f;
            boolean crossed = from <= to
                    ? (targetAngle >= from && targetAngle <= to)
                    : (targetAngle >= from || targetAngle <= to);
            if (crossed) lastEchoAt = System.currentTimeMillis();
        }

        /** Eco: el objetivo destella y se expande cuando el barrido lo toca. */
        private void drawEcho(Canvas canvas, float targetX, float targetY) {
            long elapsed = System.currentTimeMillis() - lastEchoAt;
            if (lastEchoAt == 0L || elapsed > 900L) return;
            float t = elapsed / 900f;
            Paint echo = new Paint(Paint.ANTI_ALIAS_FLAG);
            echo.setStyle(Paint.Style.STROKE);
            echo.setStrokeWidth(dp(2f));
            echo.setColor(Color.argb((int) (150 * (1f - t)), 255, 96, 96));
            canvas.drawCircle(targetX, targetY, dp(10) + dp(20) * t, echo);
            echo.setStyle(Paint.Style.FILL);
            echo.setColor(Color.argb((int) (60 * (1f - t)), 255, 96, 96));
            canvas.drawCircle(targetX, targetY, dp(9), echo);
        }

        /** Halo de precisión GNSS a escala real del radar. */
        private void drawAccuracyHalo(Canvas canvas, float cx, float cy, float maxR, double maxRange) {
            if (accuracyMeters <= 0f) return;
            float radius = (float) (accuracyMeters / Math.max(0.01, maxRange) * maxR);
            radius = clamp(radius, dp(6), maxR);
            canvas.drawCircle(cx, cy, radius, accuracyFillPaint);
            canvas.drawCircle(cx, cy, radius, accuracyStrokePaint);
        }

        private void drawRadarBackground(Canvas canvas, float cx, float cy, float maxR) {
            canvas.drawCircle(cx, cy, maxR, fillPaint);
            canvas.drawLine(cx - maxR, cy, cx + maxR, cy, crossPaint);
            canvas.drawLine(cx, cy - maxR, cx, cy + maxR, crossPaint);
            canvas.drawCircle(cx, cy, maxR, outerPaint);
        }

        private void drawRangeRings(Canvas canvas, float cx, float cy, float maxR, double maxRange) {
            subLabelPaint.setTextAlign(Paint.Align.CENTER);
            subLabelPaint.setColor(withAlpha(subTextColor, 215));
            for (int i = 1; i <= 4; i++) {
                float r = maxR * i / 4f;
                if (i < 4) canvas.drawCircle(cx, cy, r, ringPaint);
                canvas.drawText(formatRange(maxRange * i / 4.0), cx, cy + r - dp(4), subLabelPaint);
            }
        }

        private void drawCardinalLabels(Canvas canvas, float cx, float cy, float maxR) {
            String[] names = {"N", "E", "S", "O"};
            double[] absolute = {0, 90, 180, 270};
            labelPaint.setTextAlign(Paint.Align.CENTER);
            for (int i = 0; i < names.length; i++) {
                double rel = headingAvailableInView
                        ? normalizeSignedBearing(absolute[i] - headingDegrees)
                        : normalizeSignedBearing(absolute[i]);
                double a = Math.toRadians(rel - 90.0);
                float r = maxR + dp(16);
                float x = cx + (float) Math.cos(a) * r;
                float y = cy + (float) Math.sin(a) * r + dp(4);
                labelPaint.setColor("N".equals(names[i]) ? NAV_BLUE : subTextColor);
                canvas.drawText(names[i], x, y, labelPaint);
            }
            labelPaint.setColor(textColor);
        }

        private void drawPhoneHeadingMarker(Canvas canvas, float cx, float cy, float maxR) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(headingAvailableInView ? NAV_BLUE : withAlpha(NAV_BLUE, 110));
            p.setStyle(Paint.Style.FILL);
            float y = cy - maxR - dp(4);
            Path triangle = new Path();
            triangle.moveTo(cx, y - dp(9));
            triangle.lineTo(cx - dp(6.5f), y + dp(3));
            triangle.lineTo(cx + dp(6.5f), y + dp(3));
            triangle.close();
            canvas.drawPath(triangle, p);
        }

        private void drawToleranceCircle(Canvas canvas, float targetX, float targetY, float maxR, double maxRange) {
            float radius = (float) (Math.max(0.0, tolerance) / Math.max(0.01, maxRange) * maxR);
            radius = clamp(radius, dp(9), maxR * 0.55f);
            tolerancePaint.setColor((arrived || withinAccuracy)
                    ? Color.argb(235, 112, 220, 68) : Color.argb(170, 112, 220, 68));
            canvas.drawCircle(targetX, targetY, radius, tolerancePaint);
        }

        private void drawTopLabels(Canvas canvas, int w, double maxRange) {
            RectF chip = new RectF(dp(12), dp(12), w - dp(12), dp(46));
            canvas.drawRoundRect(chip, dp(9), dp(9), chipPaint);

            labelPaint.setTextAlign(Paint.Align.LEFT);
            labelPaint.setColor(textColor);
            String label = headingAvailableInView
                    ? "Radar · rumbo " + f1(headingDegrees) + "°"
                    : "Radar · norte arriba";
            canvas.drawText(label, chip.left + dp(12), chip.centerY() + dp(4), labelPaint);

            subLabelPaint.setTextAlign(Paint.Align.RIGHT);
            subLabelPaint.setColor(subTextColor);
            canvas.drawText("Alcance " + formatRange(maxRange), chip.right - dp(12), chip.centerY() + dp(4), subLabelPaint);
        }

        private void drawControls(Canvas canvas, int w, int h) {
            float size = dp(38);
            float gap = dp(7);
            float right = w - dp(12);
            float bottom = h - dp(66);

            zoomOutControl.set(right - size, bottom - size, right, bottom);
            zoomInControl.set(right - size, bottom - size * 2f - gap, right, bottom - size - gap);
            resetControl.set(right - size, bottom - size * 3f - gap * 2f, right, bottom - size * 2f - gap * 2f);

            for (RectF rect : new RectF[]{resetControl, zoomInControl, zoomOutControl}) {
                canvas.drawRoundRect(rect, dp(9), dp(9), controlBgPaint);
                canvas.drawRoundRect(rect, dp(9), dp(9), controlStrokePaint);
            }

            float rx = resetControl.centerX();
            float ry = resetControl.centerY();
            controlIconPaint.setStrokeWidth(dp(1.8f));
            canvas.drawCircle(rx, ry, dp(6.5f), controlIconPaint);
            canvas.drawCircle(rx, ry, dp(1.8f), controlIconPaint);
            canvas.drawLine(rx - dp(11), ry, rx - dp(8), ry, controlIconPaint);
            canvas.drawLine(rx + dp(8), ry, rx + dp(11), ry, controlIconPaint);
            canvas.drawLine(rx, ry - dp(11), rx, ry - dp(8), controlIconPaint);
            canvas.drawLine(rx, ry + dp(8), rx, ry + dp(11), controlIconPaint);

            controlIconPaint.setStrokeWidth(dp(2.4f));
            float ix = zoomInControl.centerX();
            float iy = zoomInControl.centerY();
            canvas.drawLine(ix - dp(7.5f), iy, ix + dp(7.5f), iy, controlIconPaint);
            canvas.drawLine(ix, iy - dp(7.5f), ix, iy + dp(7.5f), controlIconPaint);

            float ox = zoomOutControl.centerX();
            float oy = zoomOutControl.centerY();
            canvas.drawLine(ox - dp(7.5f), oy, ox + dp(7.5f), oy, controlIconPaint);
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent event) {
            if (event.getActionMasked() != android.view.MotionEvent.ACTION_UP) {
                return event.getActionMasked() == android.view.MotionEvent.ACTION_DOWN || super.onTouchEvent(event);
            }
            float x = event.getX();
            float y = event.getY();
            if (resetControl.contains(x, y)) {
                zoomFactor = 1.0f;
                lockedRange = 0.0;
                invalidate();
                performClick();
                return true;
            }
            if (zoomInControl.contains(x, y)) {
                zoomFactor = Math.min(8f, zoomFactor * 2f);
                invalidate();
                performClick();
                return true;
            }
            if (zoomOutControl.contains(x, y)) {
                zoomFactor = Math.max(0.25f, zoomFactor / 2f);
                invalidate();
                performClick();
                return true;
            }
            return super.onTouchEvent(event);
        }

        @Override public boolean performClick() {
            super.performClick();
            return true;
        }

        private void drawRouteArrow(Canvas canvas, float x1, float y1, float x2, float y2) {
            float dist = (float) Math.hypot(x2 - x1, y2 - y1);
            if (dist < dp(24)) return;
            float t = 0.62f;
            float x = x1 + (x2 - x1) * t;
            float y = y1 + (y2 - y1) * t;
            double angle = Math.atan2(y2 - y1, x2 - x1);
            float size = dp(11);
            Path path = new Path();
            path.moveTo(x + (float) Math.cos(angle) * size, y + (float) Math.sin(angle) * size);
            path.lineTo(x + (float) Math.cos(angle + 2.5) * size, y + (float) Math.sin(angle + 2.5) * size);
            path.lineTo(x + (float) Math.cos(angle - 2.5) * size, y + (float) Math.sin(angle - 2.5) * size);
            path.close();
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(NAV_BLUE);
            p.setStyle(Paint.Style.FILL);
            canvas.drawPath(path, p);
        }

        private void drawCurrent(Canvas canvas, float x, float y) {
            // Latido suave: deja claro que el radar está vivo aunque no haya objetivo.
            float beat = (float) (0.5 + 0.5 * Math.sin(pulsePhase * Math.PI));
            Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
            halo.setColor(Color.argb((int) (30 + 34 * beat), 45, 129, 255));
            halo.setStyle(Paint.Style.FILL);
            canvas.drawCircle(x, y, dp(14) + dp(7) * beat, halo);
            canvas.drawCircle(x, y, dp(8), currentPaint);
            Paint inner = new Paint(Paint.ANTI_ALIAS_FLAG);
            inner.setStyle(Paint.Style.FILL);
            inner.setColor(Color.WHITE);
            canvas.drawCircle(x, y, dp(3.4f), inner);
        }

        private void drawTarget(Canvas canvas, float x, float y, boolean outOfRange, double radians) {
            int color = (arrived || withinAccuracy) ? TARGET_GREEN : TARGET_RED;
            targetPaint.setColor(color);
            if (outOfRange) {
                // Fuera de alcance: se marca con una punta de flecha sobre el borde del radar.
                Path path = new Path();
                float size = dp(12);
                path.moveTo(x + (float) Math.cos(radians) * size, y + (float) Math.sin(radians) * size);
                path.lineTo(x + (float) Math.cos(radians + 2.5) * size, y + (float) Math.sin(radians + 2.5) * size);
                path.lineTo(x + (float) Math.cos(radians - 2.5) * size, y + (float) Math.sin(radians - 2.5) * size);
                path.close();
                Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
                p.setColor(color);
                p.setStyle(Paint.Style.FILL);
                canvas.drawPath(path, p);
                return;
            }
            canvas.drawCircle(x, y, dp(13), targetPaint);
            canvas.drawCircle(x, y, dp(4), targetPaint);
            canvas.drawLine(x - dp(19), y, x - dp(9), y, targetPaint);
            canvas.drawLine(x + dp(9), y, x + dp(19), y, targetPaint);
            canvas.drawLine(x, y - dp(19), x, y - dp(9), targetPaint);
            canvas.drawLine(x, y + dp(9), x, y + dp(19), targetPaint);
        }

        private void drawTargetLabel(Canvas canvas, int w, float targetX, float targetY, boolean outOfRange) {
            String label = outOfRange ? "Objetivo fuera de alcance"
                    : (arrived ? "Objetivo ✓" : (withinAccuracy ? "Objetivo ≈" : "Objetivo"));
            labelPaint.setTypeface(Typeface.DEFAULT_BOLD);
            float textWidth = labelPaint.measureText(label);
            boolean toLeft = targetX + dp(20) + textWidth > w - dp(14);
            labelPaint.setTextAlign(toLeft ? Paint.Align.RIGHT : Paint.Align.LEFT);
            labelPaint.setColor((arrived || withinAccuracy) ? TARGET_GREEN : TARGET_RED);
            float x = toLeft ? Math.max(dp(14) + textWidth, targetX - dp(20)) : Math.min(w - dp(14) - textWidth, targetX + dp(20));
            float y = Math.max(dp(66), targetY - dp(16));
            canvas.drawText(label, x, y, labelPaint);
            labelPaint.setColor(textColor);
        }

        private void drawDistanceBadge(Canvas canvas, int w, int h) {
            String value = (withinAccuracy ? "≈" : "") + f2(distance) + " m";
            String toleranceText = "Tolerancia " + f2(tolerance) + " m";
            RectF badge = new RectF(dp(12), h - dp(52), w - dp(12), h - dp(12));
            canvas.drawRoundRect(badge, dp(10), dp(10), chipPaint);

            labelPaint.setTextAlign(Paint.Align.LEFT);
            labelPaint.setColor(textColor);
            canvas.drawText("A " + value + " · " + direction(north, east), badge.left + dp(12), badge.centerY() + dp(4), labelPaint);
            subLabelPaint.setTextAlign(Paint.Align.RIGHT);
            subLabelPaint.setColor((arrived || withinAccuracy) ? TARGET_GREEN : VALUE_GREEN);
            canvas.drawText(toleranceText, badge.right - dp(12), badge.centerY() + dp(4), subLabelPaint);
        }

        private String formatRange(double meters) {
            if (meters >= 1000.0) return String.format(Locale.US, "%.1f km", meters / 1000.0);
            if (meters >= 10.0) return String.format(Locale.US, "%.0f m", meters);
            return String.format(Locale.US, "%.1f m", meters);
        }

        private float clamp(float value, float min, float max) {
            return Math.max(min, Math.min(max, value));
        }
    }

    private static final class MetricTile {
        final LinearLayout root;
        final TextView value;
        MetricTile(LinearLayout root, TextView value) {
            this.root = root;
            this.value = value;
        }
    }

    private static final class Target {
        final double latitude;
        final double longitude;
        final CoordinateUtils.Utm utm;
        Target(double latitude, double longitude, CoordinateUtils.Utm utm) {
            this.latitude = latitude;
            this.longitude = longitude;
            this.utm = utm;
        }
    }
}
