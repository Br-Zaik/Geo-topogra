package com.bph.geotopo;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Selector visual de tipos de mapa. Se mantiene independiente del motor para
 * poder reutilizarlo en el mini mapa y en el mapa completo.
 */
public final class MapLayerPicker {
    public interface Listener {
        void onLayerSelected(String mode);
        void onManageOffline();
    }

    private MapLayerPicker() { }

    public static void show(Activity activity, String currentMode, Listener listener) {
        if (activity == null || activity.isFinishing()) return;
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout sheet = new LinearLayout(activity);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(dp(activity, 16), dp(activity, 9), dp(activity, 16), dp(activity, 16));
        sheet.setBackground(round(Color.rgb(23, 27, 33), 24, 1, Color.rgb(68, 75, 84)));

        View handle = new View(activity);
        handle.setBackground(round(Color.rgb(120, 126, 134), 3, 0, Color.TRANSPARENT));
        LinearLayout.LayoutParams handleLp = new LinearLayout.LayoutParams(dp(activity, 42), dp(activity, 4));
        handleLp.gravity = Gravity.CENTER_HORIZONTAL;
        handleLp.setMargins(0, 0, 0, dp(activity, 12));
        sheet.addView(handle, handleLp);

        sheet.addView(text(activity, "Tipo de mapa", 20, true, Color.WHITE));
        TextView baseTitle = text(activity, "MAPA BASE", 11.5f, true, Color.rgb(177, 188, 201));
        LinearLayout.LayoutParams baseLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        baseLp.setMargins(0, dp(activity, 12), 0, dp(activity, 7));
        sheet.addView(baseTitle, baseLp);

        LinearLayout row1 = row(activity);
        row1.addView(option(activity, "Mapa", "standard", currentMode, dialog, listener), choiceLp(activity, false, true));
        row1.addView(option(activity, "Satélite", "satellite", currentMode, dialog, listener), choiceLp(activity, true, true));
        row1.addView(option(activity, "Nombres", "labels", currentMode, dialog, listener), choiceLp(activity, true, false));
        sheet.addView(row1);

        TextView workTitle = text(activity, "SIN CONEXIÓN", 11.5f, true, Color.rgb(177, 188, 201));
        LinearLayout.LayoutParams workLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        workLp.setMargins(0, dp(activity, 15), 0, dp(activity, 7));
        sheet.addView(workTitle, workLp);

        LinearLayout row2 = row(activity);
        row2.addView(option(activity, "Offline", "offline", currentMode, dialog, listener), halfChoiceLp(activity, false));
        View spacer1 = new View(activity);
        row2.addView(spacer1, halfChoiceLp(activity, true));
        sheet.addView(row2);

        TextView manage = text(activity, "▣  Mapas sin conexión", 14, true, Color.rgb(94, 171, 255));
        manage.setGravity(Gravity.CENTER_VERTICAL);
        manage.setPadding(dp(activity, 12), dp(activity, 12), dp(activity, 12), dp(activity, 12));
        manage.setBackground(round(Color.rgb(31, 36, 43), 14, 1, Color.rgb(73, 82, 94)));
        LinearLayout.LayoutParams manageLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        manageLp.setMargins(0, dp(activity, 14), 0, 0);
        sheet.addView(manage, manageLp);
        manage.setOnClickListener(v -> {
            dialog.dismiss();
            if (listener != null) listener.onManageOffline();
        });

        dialog.setContentView(sheet);
        dialog.setCanceledOnTouchOutside(true);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setGravity(Gravity.BOTTOM);
            WindowManager.LayoutParams p = window.getAttributes();
            p.width = WindowManager.LayoutParams.MATCH_PARENT;
            p.height = WindowManager.LayoutParams.WRAP_CONTENT;
            p.dimAmount = 0.34f;
            window.setAttributes(p);
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
        dialog.show();
        if (window != null) window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private static LinearLayout row(Activity a) {
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setBaselineAligned(false);
        return row;
    }


    private static LinearLayout.LayoutParams halfChoiceLp(Activity a, boolean leftMargin) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(a, 108), 1f);
        lp.setMargins(leftMargin ? dp(a, 6) : 0, 0, 0, 0);
        return lp;
    }

    private static LinearLayout.LayoutParams choiceLp(Activity a, boolean left, boolean right) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(a, 102), 1f);
        lp.setMargins(left ? dp(a, 5) : 0, 0, right ? dp(a, 5) : 0, 0);
        return lp;
    }

    private static View option(Activity a, String label, String mode, String currentMode,
                               Dialog dialog, Listener listener) {
        boolean selected = mode.equals(currentMode)
                || ("standard".equals(mode) && (currentMode == null || currentMode.trim().isEmpty() || "topo".equals(currentMode)));
        LinearLayout card = new LinearLayout(a);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(a, 5), dp(a, 5), dp(a, 5), dp(a, 6));
        card.setBackground(round(selected ? Color.rgb(37, 50, 66) : Color.rgb(31, 36, 43),
                14, selected ? 2 : 1, selected ? Color.rgb(66, 133, 244) : Color.rgb(70, 78, 89)));

        LayerPreview preview = new LayerPreview(a, mode);
        card.addView(preview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(a, 64)));

        TextView name = text(a, (selected ? "✓  " : "") + label, 11.2f, true,
                selected ? Color.rgb(116, 178, 255) : Color.WHITE);
        name.setGravity(Gravity.CENTER);
        name.setSingleLine(true);
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        nameLp.setMargins(0, dp(a, 5), 0, 0);
        card.addView(name, nameLp);

        card.setOnClickListener(v -> {
            dialog.dismiss();
            if (listener != null) listener.onLayerSelected(mode);
        });
        return card;
    }

    private static TextView text(Activity a, String value, float sp, boolean bold, int color) {
        TextView view = new TextView(a);
        view.setText(value);
        view.setTextColor(color);
        view.setTextSize(sp);
        view.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        if (bold) view.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return view;
    }

    private static GradientDrawable round(int fill, int radiusDp, int strokeDp, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(radiusDp * android.content.res.Resources.getSystem().getDisplayMetrics().density);
        if (strokeDp > 0) {
            int px = Math.max(1, Math.round(strokeDp * android.content.res.Resources.getSystem().getDisplayMetrics().density));
            d.setStroke(px, stroke);
        }
        return d;
    }

    private static int dp(Activity a, float value) {
        return Math.round(value * a.getResources().getDisplayMetrics().density);
    }

    private static final class LayerPreview extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final String mode;

        LayerPreview(Activity a, String mode) {
            super(a);
            this.mode = mode;
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float r = Math.min(w, h) * 0.12f;
            canvas.save();
            Path clip = new Path();
            clip.addRoundRect(0, 0, w, h, r, r, Path.Direction.CW);
            canvas.clipPath(clip);

            if ("satellite".equals(mode)) drawSatellite(canvas, w, h);
            else if ("labels".equals(mode)) drawLabels(canvas, w, h);
            else if ("topo".equals(mode)) drawTopo(canvas, w, h);
            else if ("offline".equals(mode)) drawOffline(canvas, w, h);
            else drawStandard(canvas, w, h);
            canvas.restore();
        }

        private void drawStandard(Canvas c, float w, float h) {
            c.drawColor(Color.rgb(230, 233, 236));
            paint.setColor(Color.rgb(211, 222, 205));
            c.drawRect(w * .04f, h * .08f, w * .43f, h * .43f, paint);
            paint.setColor(Color.rgb(211, 228, 239));
            c.drawRect(w * .72f, 0, w, h, paint);
            drawRoads(c, w, h, Color.WHITE, Color.rgb(255, 193, 73));
        }

        private void drawSatellite(Canvas c, float w, float h) {
            // Vista aérea pura: sin carreteras, nombres ni símbolos híbridos.
            c.drawColor(Color.rgb(67, 83, 57));
            paint.setColor(Color.rgb(105, 88, 55));
            c.drawRect(0, h * .50f, w * .40f, h, paint);
            paint.setColor(Color.rgb(47, 76, 49));
            c.drawCircle(w * .76f, h * .20f, h * .34f, paint);
            paint.setColor(Color.rgb(128, 113, 78));
            c.drawRect(w * .42f, h * .24f, w * .68f, h * .58f, paint);
            paint.setColor(Color.rgb(83, 103, 68));
            c.drawRect(w * .69f, h * .47f, w, h, paint);
            paint.setColor(Color.rgb(92, 77, 50));
            c.drawRect(w * .08f, h * .10f, w * .36f, h * .43f, paint);
            paint.setColor(Color.argb(65, 255, 255, 255));
            c.drawCircle(w * .53f, h * .73f, h * .08f, paint);
        }

        private void drawLabels(Canvas c, float w, float h) {
            drawSatellite(c, w, h);
            // Miniatura coherente con el modo real: solo nombres sobre imagen.
            paint.setColor(Color.WHITE);
            paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            paint.setTextSize(h * .13f);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setShadowLayer(1.35f, 0f, 0.5f, Color.rgb(24, 29, 35));
            c.drawText("Yauri", w * .54f, h * .34f, paint);
            paint.setTypeface(android.graphics.Typeface.DEFAULT);
            paint.setTextSize(h * .095f);
            c.drawText("Av. Principal", w * .56f, h * .68f, paint);
            paint.clearShadowLayer();
        }

        private void drawTopo(Canvas c, float w, float h) {
            c.drawColor(Color.rgb(218, 226, 203));
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(Math.max(1f, h * .018f));
            line.setColor(Color.rgb(121, 146, 100));
            for (int i = 0; i < 5; i++) {
                Path p = new Path();
                float y = h * (.18f + i * .14f);
                p.moveTo(-w * .08f, y);
                p.cubicTo(w * .22f, y - h * .20f, w * .48f, y + h * .20f, w * 1.08f, y - h * .03f);
                c.drawPath(p, line);
            }
            drawRoads(c, w, h, Color.rgb(244, 244, 226), Color.rgb(231, 164, 64));
        }

        private void drawOffline(Canvas c, float w, float h) {
            c.drawColor(Color.rgb(18, 40, 57));
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(1f);
            line.setColor(Color.rgb(51, 81, 100));
            for (int i = 1; i < 6; i++) {
                c.drawLine(w * i / 6f, 0, w * i / 6f, h, line);
                c.drawLine(0, h * i / 6f, w, h * i / 6f, line);
            }
            paint.setColor(Color.rgb(68, 153, 255));
            c.drawCircle(w * .53f, h * .48f, h * .12f, paint);
            paint.setColor(Color.WHITE);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(h * .22f);
            c.drawText("MB", w * .53f, h * .56f, paint);
        }

        private void drawRoads(Canvas c, float w, float h, int minorColor, int majorColor) {
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeCap(Paint.Cap.ROUND);
            line.setStrokeWidth(Math.max(2f, h * .055f));
            line.setColor(minorColor);
            Path p = new Path();
            p.moveTo(-w * .05f, h * .76f);
            p.lineTo(w * .30f, h * .52f);
            p.lineTo(w * .58f, h * .60f);
            p.lineTo(w * 1.05f, h * .28f);
            c.drawPath(p, line);
            c.drawLine(w * .16f, -h * .05f, w * .40f, h * 1.05f, line);
            c.drawLine(w * .70f, -h * .05f, w * .65f, h * 1.05f, line);
            line.setStrokeWidth(Math.max(3f, h * .075f));
            line.setColor(majorColor);
            c.drawLine(-w * .05f, h * .18f, w * 1.05f, h * .88f, line);
        }
    }
}
