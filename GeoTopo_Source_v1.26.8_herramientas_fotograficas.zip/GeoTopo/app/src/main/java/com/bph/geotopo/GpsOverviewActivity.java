package com.bph.geotopo;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Native GPS and maps overview. No full-screen reference bitmap is used. */
public class GpsOverviewActivity extends Activity {
    private static final String GPS_PREFS = "geo_topo_gps_points";
    private static final String KEY_POINTS = "points_json";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NativeUi.styleWindow(this);
        setContentView(buildScreen());
    }

    @Override protected void onRestart() {
        super.onRestart();
        setContentView(buildScreen());
    }

    private View buildScreen() {
        FrameLayout root = NativeUi.screen(this);
        LinearLayout page = NativeUi.column(this);
        page.addView(NativeUi.pageHeader(this, "GPS y mapas",
                "Ubicación, mapas offline y datos GNSS", v -> finish(), "▱",
                v -> open(MapActivity.class)));

        LinearLayout content = NativeUi.column(this);
        content.setPadding(NativeUi.dp(this, 14), NativeUi.dp(this, 14),
                NativeUi.dp(this, 14), NativeUi.dp(this, 26));

        View mapCard = NativeUi.gpsMapCard(this,
                v -> open(OfflineMapActivity.class), v -> open(MapActivity.class));
        LinearLayout.LayoutParams mapLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 330));
        mapLp.setMargins(0, 0, 0, NativeUi.dp(this, 13));
        content.addView(mapCard, mapLp);

        LastPosition position = readLastPosition();
        String coordinateBody;
        String precisionBody;
        if (position.valid) {
            CoordinateUtils.Utm utm = CoordinateUtils.toUtm(position.latitude, position.longitude);
            if (utm.valid) {
                coordinateBody = "UTM " + utm.zone + utm.hemisphere()
                        + "\nEste: " + format3(utm.easting) + " m"
                        + "\nNorte: " + format3(utm.northing) + " m"
                        + "\nLat/Lon: " + format6(position.latitude) + ", " + format6(position.longitude);
            } else {
                coordinateBody = "Latitud: " + format6(position.latitude)
                        + "\nLongitud: " + format6(position.longitude);
            }
            precisionBody = "±" + format1(Math.max(0.0, position.accuracy)) + " m"
                    + "\nÚltima actualización: " + formatTime(position.timestamp);
        } else {
            coordinateBody = "Sin lectura guardada\nAbre GPS y puntos para obtener tu posición.";
            precisionBody = "Sin datos\nLa precisión aparecerá después de una lectura GPS.";
        }

        LinearLayout infoRow = NativeUi.row(this);
        infoRow.setBaselineAligned(false);
        View coords = NativeUi.infoCard(this, "target", "Coordenadas actuales", coordinateBody);
        coords.setOnClickListener(v -> open(GpsActivity.class));
        View accuracy = NativeUi.infoCard(this, "target", "Precisión", precisionBody);
        accuracy.setOnClickListener(v -> open(GpsActivity.class));
        LinearLayout.LayoutParams left = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        left.setMargins(0, 0, NativeUi.dp(this, 6), 0);
        LinearLayout.LayoutParams right = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        right.setMargins(NativeUi.dp(this, 6), 0, 0, 0);
        infoRow.addView(coords, left);
        infoRow.addView(accuracy, right);
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 170));
        infoLp.setMargins(0, 0, 0, NativeUi.dp(this, 12));
        content.addView(infoRow, infoLp);

        LinearLayout actions = NativeUi.row(this);
        actions.setBaselineAligned(false);
        actions.addView(actionCard("pin", "Guardar\npunto", v -> open(GpsActivity.class)), actionLp(false, false));
        actions.addView(actionCard("share", "Compartir\ncoordenadas", v -> shareLastCoordinates()), actionLp(true, true));
        actions.addView(actionCard("satellite", "Ver satélites\nGNSS", v -> open(GnssQualityActivity.class)), actionLp(false, false));
        content.addView(actions, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 104)));

        content.addView(NativeUi.sectionHeader(this, "◷", "PUNTOS RECIENTES", "Ver todos",
                v -> open(GpsActivity.class)));
        content.addView(recentPointsCard());

        page.addView(NativeUi.scroll(this, content), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(page, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return root;
    }

    private LinearLayout.LayoutParams actionLp(boolean middleLeft, boolean middleRight) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lp.setMargins(middleLeft ? NativeUi.dp(this, 5) : 0, 0,
                middleRight ? NativeUi.dp(this, 5) : 0, 0);
        return lp;
    }

    private View actionCard(String icon, String label, View.OnClickListener click) {
        LinearLayout box = NativeUi.row(this);
        box.setPadding(NativeUi.dp(this, 8), NativeUi.dp(this, 9), NativeUi.dp(this, 5), NativeUi.dp(this, 9));
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setBackground(NativeUi.gradient(NativeUi.CARD_LIGHT, NativeUi.CARD_DARK, 16,
                NativeUi.withAlpha(NativeUi.BORDER, 165), this));
        box.setOnClickListener(click);
        FrameLayout iconBox = NativeUi.iconTile(this, icon, 46);
        box.addView(iconBox, new LinearLayout.LayoutParams(NativeUi.dp(this, 46), NativeUi.dp(this, 46)));
        TextView title = NativeUi.text(this, label, 13.5f, false, NativeUi.TEXT);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(NativeUi.dp(this, 8), 0, 0, 0);
        box.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return box;
    }

    private View recentPointsCard() {
        LinearLayout card = NativeUi.column(this);
        card.setBackground(NativeUi.gradient(NativeUi.CARD_LIGHT, NativeUi.CARD_DARK, 18,
                NativeUi.withAlpha(NativeUi.BORDER, 165), this));
        List<PointRow> points = readRecentPoints();
        if (points.isEmpty()) {
            TextView empty = NativeUi.text(this,
                    "Todavía no hay puntos guardados. Abre GPS y puntos para registrar el primero.",
                    14, false, NativeUi.SUB);
            empty.setPadding(NativeUi.dp(this, 16), NativeUi.dp(this, 18),
                    NativeUi.dp(this, 16), NativeUi.dp(this, 18));
            card.addView(empty);
            return card;
        }
        for (int i = 0; i < points.size(); i++) {
            PointRow p = points.get(i);
            card.addView(recentRow(p));
            if (i < points.size() - 1) {
                View divider = new View(this);
                divider.setBackgroundColor(NativeUi.withAlpha(NativeUi.BORDER, 80));
                card.addView(divider, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 1)));
            }
        }
        return card;
    }

    private View recentRow(PointRow point) {
        LinearLayout row = NativeUi.row(this);
        row.setPadding(NativeUi.dp(this, 12), NativeUi.dp(this, 13),
                NativeUi.dp(this, 10), NativeUi.dp(this, 13));
        row.setOnClickListener(v -> open(GpsActivity.class));
        NativeUi.IconGlyphView icon = new NativeUi.IconGlyphView(this, "pin");
        row.addView(icon, new LinearLayout.LayoutParams(NativeUi.dp(this, 38), NativeUi.dp(this, 38)));
        LinearLayout labels = NativeUi.column(this);
        labels.setPadding(NativeUi.dp(this, 9), 0, NativeUi.dp(this, 5), 0);
        labels.addView(NativeUi.text(this, point.name, 15, false, NativeUi.TEXT));
        TextView sub = NativeUi.text(this, point.summary, 11.5f, false, NativeUi.SUB);
        sub.setSingleLine(true);
        labels.addView(sub);
        row.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView time = NativeUi.text(this, point.time + "  ›", 12, false, NativeUi.SUB);
        row.addView(time);
        return row;
    }

    private LastPosition readLastPosition() {
        SharedPreferences prefs = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
        try {
            String lat = prefs.getString("last_latitude", "");
            String lon = prefs.getString("last_longitude", "");
            if (lat == null || lon == null || lat.trim().isEmpty() || lon.trim().isEmpty()) return new LastPosition();
            LastPosition p = new LastPosition();
            p.latitude = Double.parseDouble(lat);
            p.longitude = Double.parseDouble(lon);
            p.accuracy = prefs.getFloat("last_accuracy", 0f);
            p.timestamp = prefs.getLong("last_location_time", 0L);
            p.valid = true;
            return p;
        } catch (Exception ignored) {
            return new LastPosition();
        }
    }

    private List<PointRow> readRecentPoints() {
        List<PointRow> rows = new ArrayList<>();
        String json = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]");
        try {
            JSONArray array = new JSONArray(json == null ? "[]" : json);
            for (int i = array.length() - 1; i >= 0 && rows.size() < 3; i--) {
                JSONObject object = array.optJSONObject(i);
                if (object == null) continue;
                PointRow row = new PointRow();
                row.name = object.optString("name", "Punto");
                double lat = object.optDouble("latitude", Double.NaN);
                double lon = object.optDouble("longitude", Double.NaN);
                double alt = object.optDouble("altitude", Double.NaN);
                CoordinateUtils.Utm utm = CoordinateUtils.toUtm(lat, lon);
                if (utm.valid) {
                    row.summary = "UTM " + utm.zone + utm.hemisphere() + " · "
                            + format3(utm.easting) + " E · " + format3(utm.northing) + " N"
                            + (Double.isNaN(alt) ? "" : " · " + format1(alt) + " m");
                } else {
                    row.summary = format6(lat) + ", " + format6(lon);
                }
                row.time = relativeTime(object.optLong("timestamp", System.currentTimeMillis()));
                rows.add(row);
            }
        } catch (Exception ignored) {
        }
        return rows;
    }

    private void open(Class<?> target) { startActivity(new Intent(this, target)); }

    private void shareLastCoordinates() {
        LastPosition p = readLastPosition();
        if (!p.valid) {
            Toast.makeText(this, "Primero obtén una lectura en GPS y puntos.", Toast.LENGTH_LONG).show();
            open(GpsActivity.class);
            return;
        }
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT, "Coordenadas Geo Topo\nLatitud: "
                + format6(p.latitude) + "\nLongitud: " + format6(p.longitude));
        startActivity(Intent.createChooser(share, "Compartir coordenadas"));
    }

    private String format3(double value) { return String.format(Locale.US, "%,.3f", value).replace(',', ' '); }
    private String format6(double value) { return String.format(Locale.US, "%.6f", value); }
    private String format1(double value) { return String.format(Locale.US, "%.1f", value); }
    private String formatTime(long timestamp) {
        if (timestamp <= 0) return "sin hora";
        return new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date(timestamp));
    }
    private String relativeTime(long timestamp) {
        long diff = Math.max(0, System.currentTimeMillis() - timestamp);
        String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(timestamp));
        if (diff < 24L * 60L * 60L * 1000L) return "Hoy, " + time;
        if (diff < 48L * 60L * 60L * 1000L) return "Ayer, " + time;
        return new SimpleDateFormat("dd/MM, HH:mm", Locale.getDefault()).format(new Date(timestamp));
    }

    private static final class LastPosition {
        boolean valid;
        double latitude;
        double longitude;
        double accuracy;
        long timestamp;
    }

    private static final class PointRow {
        String name;
        String summary;
        String time;
    }
}
