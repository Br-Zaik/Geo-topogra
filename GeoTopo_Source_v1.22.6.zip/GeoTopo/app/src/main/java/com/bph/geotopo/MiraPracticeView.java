package com.bph.geotopo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

import java.util.Locale;
import java.util.Random;

/**
 * Práctica digital de lectura de mira tipo E.
 * Se dibuja por código para conservar nitidez, bajo peso y ejercicios aleatorios,
 * pero buscando una apariencia más cercana a una mira de campo real.
 */
public class MiraPracticeView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random();
    private final int subTextColor;
    private final int panelColor;
    private final float density;

    private double upperReading;
    private double middleReading;
    private double lowerReading;
    private double visibleMin;
    private double visibleMax;

    public MiraPracticeView(Context context, int accentColor, int textColor, int subTextColor, int panelColor) {
        super(context);
        this.subTextColor = subTextColor;
        this.panelColor = panelColor;
        this.density = getResources().getDisplayMetrics().density;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        newExercise();
    }

    public void newExercise() {
        // Ventana visible aproximada de 30 cm, similar a una observación por nivel.
        int firstDm = 3 + random.nextInt(45); // 0.30 m a 4.70 m
        visibleMin = firstDm / 10.0;
        visibleMax = visibleMin + 0.30;

        // Hilo medio cerca del centro, evitando que caiga justo sobre el entero del centímetro.
        int middleMm = (int) Math.round((visibleMin + 0.15) * 1000.0);
        middleMm += random.nextInt(31) - 15;
        int remainder = floorMod(middleMm, 10);
        if (remainder == 0 || remainder == 1 || remainder == 9) {
            middleMm += 4;
        }

        // LS y LI simétricos respecto a LM.
        int halfSpanMm = 62 + random.nextInt(34); // 62 mm a 95 mm por lado.
        int minMm = (int) Math.round(visibleMin * 1000.0) + 12;
        int maxMm = (int) Math.round(visibleMax * 1000.0) - 12;
        if (middleMm - halfSpanMm < minMm) middleMm = minMm + halfSpanMm;
        if (middleMm + halfSpanMm > maxMm) middleMm = maxMm - halfSpanMm;

        middleReading = middleMm / 1000.0;
        upperReading = (middleMm + halfSpanMm) / 1000.0;
        lowerReading = (middleMm - halfSpanMm) / 1000.0;
        invalidate();
    }

    public double getUpperReading() {
        return upperReading;
    }

    public double getMiddleReading() {
        return middleReading;
    }

    public double getLowerReading() {
        return lowerReading;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int desiredHeight = Math.round(width * 1.03f);
        int height = resolveSize(desiredHeight, heightMeasureSpec);
        setMeasuredDimension(width, height);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(panelColor);
        canvas.drawRoundRect(new RectF(0, 0, w, h), dp(16), dp(16), paint);

        float footer = dp(34);
        float cx = w / 2f;
        float cy = (h - footer) / 2f - dp(3);
        float radius = Math.min(w * 0.47f, (h - footer) * 0.47f);

        // Anillo del ocular.
        paint.setColor(Color.rgb(13, 16, 21));
        paint.setShadowLayer(dp(10), 0, dp(2), Color.argb(120, 0, 0, 0));
        canvas.drawCircle(cx, cy, radius + dp(8), paint);
        paint.clearShadowLayer();

        Path lens = new Path();
        lens.addCircle(cx, cy, radius, Path.Direction.CW);
        int save = canvas.save();
        canvas.clipPath(lens);

        paint.setColor(Color.rgb(243, 243, 243));
        canvas.drawRect(cx - radius, cy - radius, cx + radius, cy + radius, paint);

        // Sombra del lente bastante suave.
        paint.setColor(Color.argb(10, 0, 0, 0));
        canvas.drawCircle(cx - radius * 0.28f, cy + radius * 0.06f, radius * 0.95f, paint);
        paint.setColor(Color.argb(16, 255, 255, 255));
        canvas.drawCircle(cx - radius * 0.42f, cy - radius * 0.28f, radius * 0.62f, paint);

        drawStaff(canvas, cx, cy, radius);
        drawThreads(canvas, cx, cy, radius);

        canvas.restoreToCount(save);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(3));
        paint.setColor(Color.rgb(18, 20, 26));
        canvas.drawCircle(cx, cy, radius, paint);
        paint.setStrokeWidth(dp(1));
        paint.setColor(Color.rgb(118, 118, 118));
        canvas.drawCircle(cx, cy, radius - dp(3), paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(dp(10.5f));
        paint.setColor(subTextColor);
        canvas.drawText("Mira tipo E digital · patrón realista · 1 franja = 1 cm", cx, h - dp(8), paint);
    }

    private void drawStaff(Canvas canvas, float cx, float cy, float radius) {
        float staffWidth = Math.min(dp(124), radius * 0.48f);
        float staffLeft = cx - staffWidth / 2f;
        float staffRight = cx + staffWidth / 2f;
        float staffTop = cy - radius - dp(8);
        float staffBottom = cy + radius + dp(8);

        float patternRight = staffLeft + staffWidth * 0.43f;
        float centerLineX = staffLeft + staffWidth * 0.50f;
        float numberRight = staffRight;

        // Fondo blanco de la mira.
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
        canvas.drawRect(staffLeft, staffTop, staffRight, staffBottom, paint);

        // Delimitadores verticales.
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1.0f));
        paint.setColor(Color.rgb(34, 34, 34));
        canvas.drawLine(staffLeft, staffTop, staffLeft, staffBottom, paint);
        canvas.drawLine(patternRight, staffTop, patternRight, staffBottom, paint);
        canvas.drawLine(centerLineX, staffTop, centerLineX, staffBottom, paint);
        canvas.drawLine(numberRight, staffTop, numberRight, staffBottom, paint);

        // Retícula suave centimétrica y líneas de decímetro marcadas.
        int firstCm = (int) Math.floor(visibleMin * 100.0);
        int lastCm = (int) Math.ceil(visibleMax * 100.0);
        for (int cm = firstCm; cm <= lastCm; cm++) {
            double reading = cm / 100.0;
            float y = readingToY(reading, staffTop, staffBottom);
            if (cm % 10 == 0) {
                paint.setColor(Color.rgb(132, 132, 132));
                paint.setStrokeWidth(dp(0.9f));
            } else {
                paint.setColor(Color.rgb(208, 208, 208));
                paint.setStrokeWidth(dp(0.55f));
            }
            canvas.drawLine(staffLeft, y, staffRight, y, paint);
        }

        int firstDm = (int) Math.floor(visibleMin * 10.0);
        int lastDm = (int) Math.ceil(visibleMax * 10.0);
        for (int dm = firstDm; dm < lastDm; dm++) {
            float yTop = readingToY((dm + 1) / 10.0, staffTop, staffBottom);
            float yBottom = readingToY(dm / 10.0, staffTop, staffBottom);
            float top = Math.min(yTop, yBottom);
            float bottom = Math.max(yTop, yBottom);
            if (bottom < staffTop || top > staffBottom) continue;

            drawPatternBlock(canvas, dm, staffLeft, patternRight, top, bottom);
            drawDecimeterNumber(canvas, dm, centerLineX, numberRight, top, bottom);
        }
    }

    private void drawPatternBlock(Canvas canvas, int dm, float left, float right, float top, float bottom) {
        float cmHeight = (bottom - top) / 10f;
        float innerTop = top + cmHeight * 0.10f;
        float innerBottom = bottom - cmHeight * 0.10f;
        float usableHeight = innerBottom - innerTop;
        float segmentTop = innerTop;
        float segmentBottom = innerTop + usableHeight * 0.5f;
        float otherTop = segmentBottom;
        float otherBottom = innerBottom;

        boolean eUpper = floorMod(dm, 2) != 0;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(235, 32, 39));

        if (eUpper) {
            drawBigE(canvas, left, right, segmentTop, segmentBottom);
            drawSmallBars(canvas, left, right, otherTop, otherBottom);
        } else {
            drawSmallBars(canvas, left, right, segmentTop, segmentBottom);
            drawBigE(canvas, left, right, otherTop, otherBottom);
        }
    }

    private void drawBigE(Canvas canvas, float left, float right, float top, float bottom) {
        float width = right - left;
        float height = bottom - top;
        float marginX = width * 0.08f;
        float xLeft = left + marginX;
        float xRight = right - marginX;
        float spineWidth = width * 0.16f;
        float armThickness = height / 5f * 0.86f;
        float armShorten = width * 0.14f;

        // Espina vertical a la izquierda; la E abre hacia la derecha.
        canvas.drawRect(xLeft, top, xLeft + spineWidth, bottom, paint);

        // Brazos superior, medio e inferior.
        float topY = top + height * 0.02f;
        float middleY = top + height * 0.5f - armThickness / 2f;
        float bottomY = bottom - armThickness - height * 0.02f;
        canvas.drawRect(xLeft, topY, xRight, topY + armThickness, paint);
        canvas.drawRect(xLeft, middleY, xRight - armShorten, middleY + armThickness, paint);
        canvas.drawRect(xLeft, bottomY, xRight, bottomY + armThickness, paint);
    }

    private void drawSmallBars(Canvas canvas, float left, float right, float top, float bottom) {
        float width = right - left;
        float height = bottom - top;
        float marginX = width * 0.10f;
        float xLeft = left + marginX;
        float xRight = right - marginX;
        float barWidth = (xRight - xLeft) * 0.62f;
        float barHeight = height * 0.16f;

        float y1 = top + height * 0.18f;
        float y2 = top + height * 0.62f;
        canvas.drawRect(xLeft, y1, xLeft + barWidth, y1 + barHeight, paint);
        canvas.drawRect(xLeft, y2, xLeft + barWidth, y2 + barHeight, paint);
    }

    private void drawDecimeterNumber(Canvas canvas, int dm, float left, float right, float top, float bottom) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(10, 10, 10));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(Math.min(dp(31), (bottom - top) * 0.50f));
        float x = left + (right - left) * 0.60f;
        float y = (top + bottom) / 2f;
        canvas.drawText(String.format(Locale.US, "%02d", Math.max(0, dm)), x, centeredBaseline(y), paint);
    }

    private void drawThreads(Canvas canvas, float cx, float cy, float radius) {
        float staffTop = cy - radius - dp(8);
        float staffBottom = cy + radius + dp(8);

        drawThread(canvas, "LS", upperReading, cx, radius, staffTop, staffBottom, false);
        drawThread(canvas, "LM", middleReading, cx, radius, staffTop, staffBottom, true);
        drawThread(canvas, "LI", lowerReading, cx, radius, staffTop, staffBottom, false);

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.BLACK);
        paint.setStrokeWidth(dp(1.0f));
        canvas.drawLine(cx, cy - radius * 0.97f, cx, cy + radius * 0.97f, paint);
    }

    private void drawThread(Canvas canvas, String label, double reading, float cx, float radius,
                            float staffTop, float staffBottom, boolean middle) {
        float y = readingToY(reading, staffTop, staffBottom);
        float fullLeft = cx - radius + dp(4);
        float fullRight = cx + radius - dp(4);
        float shortLeft = cx - radius * 0.38f;
        float shortRight = cx + radius * 0.38f;

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.BLACK);
        paint.setStrokeWidth(middle ? dp(2.0f) : dp(1.4f));
        if (middle) {
            canvas.drawLine(fullLeft, y, fullRight, y, paint);
        } else {
            canvas.drawLine(shortLeft, y, shortRight, y, paint);
        }

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(30, 30, 30));
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(dp(12.5f));
        paint.setTextAlign(Paint.Align.LEFT);
        float labelX = middle ? fullLeft + dp(4) : shortLeft - dp(28);
        canvas.drawText(label, labelX, y - dp(5), paint);
    }

    private float centeredBaseline(float centerY) {
        Paint.FontMetrics metrics = paint.getFontMetrics();
        return centerY - (metrics.ascent + metrics.descent) / 2f;
    }

    private float readingToY(double reading, float top, float bottom) {
        double range = Math.max(0.01, visibleMax - visibleMin);
        double fraction = (visibleMax - reading) / range;
        return (float) (top + fraction * (bottom - top));
    }

    private int floorMod(int value, int divisor) {
        int result = value % divisor;
        return result < 0 ? result + divisor : result;
    }

    private int dp(float value) {
        return Math.round(value * density);
    }
}
