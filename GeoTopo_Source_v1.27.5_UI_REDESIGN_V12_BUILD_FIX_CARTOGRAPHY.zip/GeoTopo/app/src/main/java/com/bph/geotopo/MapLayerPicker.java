package com.bph.geotopo;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Selector visual de tipos de mapa. Se mantiene independiente del motor para
 * poder reutilizarlo en el mini mapa y en el mapa completo.
 */
public final class MapLayerPicker {
    public interface Listener {
        void onLayerSelected(String mode);
        void onManageOffline();
    }

    private MapLayerPicker() { }

    public static void show(Activity activity, String currentMode, Listener listener) {
        if (activity == null || activity.isFinishing()) return;
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout sheet = new LinearLayout(activity);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(dp(activity, 16), dp(activity, 9), dp(activity, 16), dp(activity, 16));
        sheet.setBackground(round(Color.rgb(23, 27, 33), 24, 1, Color.rgb(68, 75, 84)));

        View handle = new View(activity);
        handle.setBackground(round(Color.rgb(120, 126, 134), 3, 0, Color.TRANSPARENT));
        LinearLayout.LayoutParams handleLp = new LinearLayout.LayoutParams(dp(activity, 42), dp(activity, 4));
        handleLp.gravity = Gravity.CENTER_HORIZONTAL;
        handleLp.setMargins(0, 0, 0, dp(activity, 12));
        sheet.addView(handle, handleLp);

        sheet.addView(text(activity, "Mapas y capas", 20, true, Color.WHITE));
        TextView baseTitle = text(activity, "MAPA BASE", 11.5f, true, Color.rgb(177, 188, 201));
        LinearLayout.LayoutParams baseLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        baseLp.setMargins(0, dp(activity, 12), 0, dp(activity, 7));
        sheet.addView(baseTitle, baseLp);

        LinearLayout row1 = row(activity);
        row1.addView(option(activity, "Mapa", "standard", currentMode, dialog, listener), choiceLp(activity, false, true));
        row1.addView(option(activity, "Satélite", "satellite", currentMode, dialog, listener), choiceLp(activity, true, true));
        row1.addView(option(activity, "Oscuro", "dark", currentMode, dialog, listener), choiceLp(activity, true, false));
        sheet.addView(row1);

        TextView workTitle = text(activity, "CARTOGRAFÍA DE CAMPO", 11.5f, true, Color.rgb(177, 188, 201));
        LinearLayout.LayoutParams workLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        workLp.setMargins(0, dp(activity, 15), 0, dp(activity, 7));
        sheet.addView(workTitle, workLp);

        LinearLayout row2 = row(activity);
        row2.addView(option(activity, "Topográfico", "topo", currentMode, dialog, listener), choiceLp(activity, false, true));
        row2.addView(option(activity, "Offline", "offline", currentMode, dialog, listener), choiceLp(activity, true, true));
        View spacer = new View(activity);
        row2.addView(spacer, choiceLp(activity, true, false));
        sheet.addView(row2);

        TextView manage = text(activity, "▣  Mapas sin conexión", 14, true, Color.rgb(94, 171, 255));
        manage.setGravity(Gravity.CENTER_VERTICAL);
        manage.setPadding(dp(activity, 12), dp(activity, 12), dp(activity, 12), dp(activity, 12));
        manage.setBackground(round(Color.rgb(31, 36, 43), 14, 1, Color.rgb(73, 82, 94)));
        LinearLayout.LayoutParams manageLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        manageLp.setMargins(0, dp(activity, 14), 0, 0);
        sheet.addView(manage, manageLp);
        manage.setOnClickListener(v -> {
            dialog.dismiss();
            if (listener != null) listener.onManageOffline();
        });

        dialog.setContentView(sheet);
        dialog.setCanceledOnTouchOutside(true);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setGravity(Gravity.BOTTOM);
            WindowManager.LayoutParams p = window.getAttributes();
            p.width = WindowManager.LayoutParams.MATCH_PARENT;
            p.height = WindowManager.LayoutParams.WRAP_CONTENT;
            p.dimAmount = 0.34f;
            window.setAttributes(p);
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
        dialog.show();
        if (window != null) window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private static LinearLayout row(Activity a) {
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setBaselineAligned(false);
        return row;
    }

    private static LinearLayout.LayoutParams choiceLp(Activity a, boolean left, boolean right) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(a, 108), 1f);
        lp.setMargins(left ? dp(a, 5) : 0, 0, right ? dp(a, 5) : 0, 0);
        return lp;
    }

    private static View option(Activity a, String label, String mode, String currentMode,
                               Dialog dialog, Listener listener) {
        boolean selected = mode.equals(currentMode)
                || ("standard".equals(mode) && (currentMode == null || currentMode.trim().isEmpty()));
        LinearLayout card = new LinearLayout(a);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(a, 5), dp(a, 5), dp(a, 5), dp(a, 6));
        card.setBackground(round(selected ? Color.rgb(37, 50, 66) : Color.rgb(31, 36, 43),
                14, selected ? 2 : 1, selected ? Color.rgb(66, 133, 244) : Color.rgb(70, 78, 89)));

        LayerPreview preview = new LayerPreview(a, mode);
        card.addView(preview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(a, 68)));

        TextView name = text(a, (selected ? "✓  " : "") + label, 11.2f, true,
                selected ? Color.rgb(116, 178, 255) : Color.WHITE);
        name.setGravity(Gravity.CENTER);
        name.setSingleLine(true);
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        nameLp.setMargins(0, dp(a, 5), 0, 0);
        card.addView(name, nameLp);

        card.setOnClickListener(v -> {
            dialog.dismiss();
            if (listener != null) listener.onLayerSelected(mode);
        });
        return card;
    }

    private static TextView text(Activity a, String value, float sp, boolean bold, int color) {
        TextView view = new TextView(a);
        view.setText(value);
        view.setTextColor(color);
        view.setTextSize(sp);
        view.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        if (bold) view.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return view;
    }

    private static GradientDrawable round(int fill, int radiusDp, int strokeDp, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(radiusDp * android.content.res.Resources.getSystem().getDisplayMetrics().density);
        if (strokeDp > 0) {
            int px = Math.max(1, Math.round(strokeDp * android.content.res.Resources.getSystem().getDisplayMetrics().density));
            d.setStroke(px, stroke);
        }
        return d;
    }

    private static int dp(Activity a, float value) {
        return Math.round(value * a.getResources().getDisplayMetrics().density);
    }

    private static final class LayerPreview extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final String mode;

        LayerPreview(Activity a, String mode) {
            super(a);
            this.mode = mode;
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float r = Math.min(w, h) * 0.12f;
            canvas.save();
            Path clip = new Path();
            clip.addRoundRect(0, 0, w, h, r, r, Path.Direction.CW);
            canvas.clipPath(clip);

            if ("dark".equals(mode)) drawDark(canvas, w, h);
            else if ("satellite".equals(mode)) drawSatellite(canvas, w, h);
            else if ("topo".equals(mode)) drawTopo(canvas, w, h);
            else if ("offline".equals(mode)) drawOffline(canvas, w, h);
            else drawStandard(canvas, w, h);
            canvas.restore();
        }

        private void drawStandard(Canvas c, float w, float h) {
            c.drawColor(Color.rgb(230, 233, 236));
            paint.setColor(Color.rgb(211, 222, 205));
            c.drawRect(w * .04f, h * .08f, w * .43f, h * .43f, paint);
            paint.setColor(Color.rgb(211, 228, 239));
            c.drawRect(w * .72f, 0, w, h, paint);
            drawRoads(c, w, h, Color.WHITE, Color.rgb(255, 193, 73));
        }

        private void drawDark(Canvas c, float w, float h) {
            c.drawColor(Color.rgb(36, 48, 69));
            paint.setColor(Color.rgb(30, 59, 77));
            c.drawRect(w * .65f, 0, w, h, paint);
            drawRoads(c, w, h, Color.rgb(83, 105, 129), Color.rgb(86, 142, 191));
        }

        private void drawSatellite(Canvas c, float w, float h) {
            c.drawColor(Color.rgb(72, 97, 63));
            paint.setColor(Color.rgb(115, 101, 67));
            c.drawRect(0, h * .52f, w * .42f, h, paint);
            paint.setColor(Color.rgb(49, 84, 53));
            c.drawCircle(w * .74f, h * .23f, h * .32f, paint);
            paint.setColor(Color.rgb(132, 123, 91));
            c.drawRect(w * .43f, h * .25f, w * .69f, h * .59f, paint);
            drawRoads(c, w, h, Color.rgb(228, 220, 199), Color.rgb(250, 195, 69));
        }

        private void drawTopo(Canvas c, float w, float h) {
            c.drawColor(Color.rgb(218, 226, 203));
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(Math.max(1f, h * .018f));
            line.setColor(Color.rgb(121, 146, 100));
            for (int i = 0; i < 5; i++) {
                Path p = new Path();
                float y = h * (.18f + i * .14f);
                p.moveTo(-w * .08f, y);
                p.cubicTo(w * .22f, y - h * .20f, w * .48f, y + h * .20f, w * 1.08f, y - h * .03f);
                c.drawPath(p, line);
            }
            drawRoads(c, w, h, Color.rgb(244, 244, 226), Color.rgb(231, 164, 64));
        }

        private void drawOffline(Canvas c, float w, float h) {
            c.drawColor(Color.rgb(18, 40, 57));
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(1f);
            line.setColor(Color.rgb(51, 81, 100));
            for (int i = 1; i < 6; i++) {
                c.drawLine(w * i / 6f, 0, w * i / 6f, h, line);
                c.drawLine(0, h * i / 6f, w, h * i / 6f, line);
            }
            paint.setColor(Color.rgb(68, 153, 255));
            c.drawCircle(w * .53f, h * .48f, h * .12f, paint);
            paint.setColor(Color.WHITE);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(h * .22f);
            c.drawText("MB", w * .53f, h * .56f, paint);
        }

        private void drawRoads(Canvas c, float w, float h, int minorColor, int majorColor) {
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeCap(Paint.Cap.ROUND);
            line.setStrokeWidth(Math.max(2f, h * .055f));
            line.setColor(minorColor);
            Path p = new Path();
            p.moveTo(-w * .05f, h * .76f);
            p.lineTo(w * .30f, h * .52f);
            p.lineTo(w * .58f, h * .60f);
            p.lineTo(w * 1.05f, h * .28f);
            c.drawPath(p, line);
            c.drawLine(w * .16f, -h * .05f, w * .40f, h * 1.05f, line);
            c.drawLine(w * .70f, -h * .05f, w * .65f, h * 1.05f, line);
            line.setStrokeWidth(Math.max(3f, h * .075f));
            line.setColor(majorColor);
            c.drawLine(-w * .05f, h * .18f, w * 1.05f, h * .88f, line);
        }
    }
}
