package com.bph.geotopo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.location.GnssStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.maplibre.android.MapLibre;
import org.maplibre.android.annotations.IconFactory;
import org.maplibre.android.annotations.Marker;
import org.maplibre.android.annotations.MarkerOptions;
import org.maplibre.android.annotations.Polygon;
import org.maplibre.android.annotations.PolygonOptions;
import org.maplibre.android.camera.CameraPosition;
import org.maplibre.android.camera.CameraUpdateFactory;
import org.maplibre.android.geometry.LatLng;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapView;
import org.maplibre.android.maps.Style;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Centro único de GPS y mapas. Las acciones principales trabajan dentro de
 * esta pantalla para evitar saltos repetidos a la antigua pantalla GPS.
 */
public class GpsOverviewActivity extends Activity implements LocationListener {
    private static final String PREFS = "geo_topo_prefs";
    private static final String GPS_PREFS = "geo_topo_gps_points";
    private static final String KEY_POINTS = "points_json";
    private static final String KEY_MAP_MODE = "map_mode";
    private static final String KEY_OFFLINE_PATH = "offline_mbtiles_path";
    private static final int REQ_LOCATION = 9410;
    private static final int REQ_PHOTO = 9411;
    private static final int REQ_EXPORT = 9412;
    private static final int REQ_IMPORT = 9413;
    private static final float MAX_AVERAGE_SAMPLE_ACCURACY_M = 300f;
    private static final long MAX_AVERAGE_SAMPLE_AGE_MS = 5000L;
    private static final float MAX_STATIONARY_SPEED_MPS = 3.5f;
    private static final long RECENT_MAP_LOCATION_MS = 10L * 60L * 1000L;
    private static final long FRESH_SAVE_LOCATION_MS = 45L * 1000L;
    private static final String OFM_LIBERTY = "https://tiles.openfreemap.org/styles/liberty";
    private static final String OFM_DARK_READABLE = "https://tiles.openfreemap.org/styles/fiord";
    private static final double OVERVIEW_CONTEXT_ZOOM = 15.0;

    private MapView overviewMapView;
    private MapLibreMap overviewMap;
    private Marker overviewMarker;
    private Polygon overviewAccuracyPolygon;
    private Bundle mapSavedState;
    private final MbtilesServer offlineServer = new MbtilesServer();
    private String currentMapMode = "standard";
    private boolean overviewStyleInitialized;
    private boolean overviewFallbackInProgress;

    private LocationManager locationManager;
    private Location currentLocation;
    private boolean gpsRunning;
    private boolean averaging;
    private boolean startAverageAfterPermission;
    private long pendingAverageDurationMs = 20000L;
    private long averageDurationMs = 20000L;
    private long averageStartedAt;
    private Runnable averageProgressRunnable;
    private final Runnable averageFinishRunnable = this::finishAveraging;
    private boolean overviewAutoCenterPending;
    private int satellitesVisible;
    private int satellitesUsed;
    private GnssStatus.Callback gnssCallback;
    private boolean gnssRegistered;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<Location> averageSamples = new ArrayList<>();
    private int averagingRejectedSamples;
    private int totalAverageReadings;
    private int maxSatellitesUsedDuringAverage;
    private Location lastAcceptedAverageSample;
    private float bestAverageAccuracy = Float.NaN;
    private float finalAverageStability = Float.NaN;
    private float finalAverageAccuracy = Float.NaN;
    private int finalValidSampleCount;
    private int finalRejectedSampleCount;
    private long finalAverageDurationSeconds;
    private String pendingPhotoUri = "";
    private TextView photoStatusView;
    private String pendingExportType;

    private LastPosition overviewPosition;
    private TextView mapHintView;
    private TextView qualityValue;
    private TextView precisionValue;
    private TextView satellitesValue;
    private TextView timeValue;
    private TextView readingStateValue;
    private TextView latValue;
    private TextView lonValue;
    private TextView eastValue;
    private TextView northValue;
    private TextView altitudeValue;
    private TextView readingPrecisionValue;
    private TextView zoneValue;
    private TextView gpsActionLabel;
    private TextView averageActionLabel;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MapLibre.getInstance(this);
        mapSavedState = savedInstanceState;
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        currentMapMode = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_MAP_MODE, "standard");
        long savedAverage = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getLong("average_duration_ms", 20000L);
        averageDurationMs = savedAverage == 10000L || savedAverage == 20000L || savedAverage == 30000L || savedAverage == 60000L ? savedAverage : 20000L;
        NativeUi.styleWindow(this);
        setContentView(buildScreen());
    }

    @Override protected void onStart() {
        super.onStart();
        if (overviewMapView != null) overviewMapView.onStart();
    }

    @Override protected void onResume() {
        super.onResume();
        if (overviewMapView != null) overviewMapView.onResume();
        LastPosition latest = readLastPosition();
        if (latest.valid) {
            overviewPosition = latest;
            updateOverviewData(latest);
            if (overviewMap != null && isRecent(latest)) centerOverviewMap(false);
        }
    }

    @Override protected void onPause() {
        stopLocationUpdates(false);
        if (overviewMapView != null) overviewMapView.onPause();
        super.onPause();
    }

    @Override protected void onStop() {
        if (overviewMapView != null) overviewMapView.onStop();
        super.onStop();
    }

    @Override public void onLowMemory() {
        super.onLowMemory();
        if (overviewMapView != null) overviewMapView.onLowMemory();
    }

    @Override protected void onDestroy() {
        stopLocationUpdates(false);
        offlineServer.stop();
        handler.removeCallbacksAndMessages(null);
        if (overviewMapView != null) overviewMapView.onDestroy();
        super.onDestroy();
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (overviewMapView != null) overviewMapView.onSaveInstanceState(outState);
    }

    private View buildScreen() {
        FrameLayout root = NativeUi.screen(this);
        LinearLayout page = NativeUi.column(this);
        page.addView(NativeUi.pageHeader(this, "GPS y mapas",
                "Ubicación, puntos y mapas", v -> finish(), "⌖",
                v -> openFullMap()));

        LinearLayout content = NativeUi.column(this);
        content.setPadding(NativeUi.dp(this, 12), NativeUi.dp(this, 9),
                NativeUi.dp(this, 12), NativeUi.dp(this, 24));

        overviewPosition = readLastPosition();

        View mapCard = buildFunctionalMapCard();
        LinearLayout.LayoutParams mapLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 228));
        mapLp.setMargins(0, 0, 0, NativeUi.dp(this, 9));
        content.addView(mapCard, mapLp);

        content.addView(buildStatusPanel(overviewPosition));
        content.addView(buildPrimaryActions());
        content.addView(buildReadingPanel(overviewPosition));
        content.addView(buildSecondaryActions());

        content.addView(NativeUi.sectionHeader(this, "◷", "PUNTOS RECIENTES", "Ver todos",
                v -> showPointsPanel()));
        content.addView(recentPointsCard());

        page.addView(NativeUi.scroll(this, content), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(page, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return root;
    }

    private View buildFunctionalMapCard() {
        FrameLayout card = new FrameLayout(this);
        card.setBackground(NativeUi.gradient(Color.rgb(5, 34, 69), Color.rgb(2, 18, 37), 18,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 160), this));
        card.setClipToOutline(true);
        card.setElevation(NativeUi.dp(this, 2));

        overviewMapView = new MapView(this);
        overviewMapView.onCreate(mapSavedState);
        overviewMapView.addOnDidFailLoadingMapListener(this::handleOverviewMapLoadFailure);
        card.addView(overviewMapView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        overviewMapView.getMapAsync(mapLibreMap -> {
            overviewMap = mapLibreMap;
            overviewMap.getUiSettings().setLogoEnabled(false);
            overviewMap.getUiSettings().setAttributionEnabled(true);
            overviewMap.getUiSettings().setCompassEnabled(false);
            overviewMap.getUiSettings().setAllGesturesEnabled(true);
            overviewMap.setMinZoomPreference(1.0);
            overviewMap.setMaxZoomPreference(20.0);
            applyOverviewMapMode(currentMapMode);
        });

        ImageButton layers = miniMapIcon(R.drawable.ic_map_layers, "Capas", v -> showOverviewLayers());
        FrameLayout.LayoutParams layersLp = new FrameLayout.LayoutParams(
                NativeUi.dp(this, 40), NativeUi.dp(this, 40), Gravity.END | Gravity.TOP);
        layersLp.setMargins(0, NativeUi.dp(this, 9), NativeUi.dp(this, 9), 0);
        card.addView(layers, layersLp);

        ImageButton locate = miniMapIcon(R.drawable.ic_map_location, "Centrar ubicación", v -> centerOrStartGps());
        FrameLayout.LayoutParams locateLp = new FrameLayout.LayoutParams(
                NativeUi.dp(this, 40), NativeUi.dp(this, 40), Gravity.END | Gravity.BOTTOM);
        locateLp.setMargins(0, 0, NativeUi.dp(this, 9), NativeUi.dp(this, 9));
        card.addView(locate, locateLp);

        TextView expand = NativeUi.text(this, "⛶", 19f, true, Color.WHITE);
        expand.setGravity(Gravity.CENTER);
        expand.setContentDescription("Abrir mapa completo");
        expand.setBackground(NativeUi.rounded(NativeUi.withAlpha(Color.rgb(36, 41, 48), 242), 20, 1,
                NativeUi.withAlpha(Color.WHITE, 90), this));
        expand.setElevation(NativeUi.dp(this, 4));
        expand.setOnClickListener(v -> openFullMap());
        FrameLayout.LayoutParams expandLp = new FrameLayout.LayoutParams(
                NativeUi.dp(this, 40), NativeUi.dp(this, 40), Gravity.START | Gravity.BOTTOM);
        expandLp.setMargins(NativeUi.dp(this, 9), 0, 0, NativeUi.dp(this, 9));
        card.addView(expand, expandLp);

        mapHintView = NativeUi.text(this, "", 10.5f, true, Color.WHITE);
        mapHintView.setGravity(Gravity.CENTER);
        mapHintView.setPadding(NativeUi.dp(this, 8), NativeUi.dp(this, 4), NativeUi.dp(this, 8), NativeUi.dp(this, 4));
        mapHintView.setBackground(NativeUi.rounded(NativeUi.withAlpha(Color.rgb(26, 31, 38), 235), 12, 0,
                Color.TRANSPARENT, this));
        FrameLayout.LayoutParams hintLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, NativeUi.dp(this, 28), Gravity.START | Gravity.TOP);
        hintLp.setMargins(NativeUi.dp(this, 9), NativeUi.dp(this, 9), NativeUi.dp(this, 58), 0);
        card.addView(mapHintView, hintLp);
        return card;
    }

    private ImageButton miniMapIcon(int drawable, String description, View.OnClickListener click) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(drawable);
        b.setColorFilter(Color.WHITE);
        b.setScaleType(android.widget.ImageView.ScaleType.CENTER);
        b.setPadding(NativeUi.dp(this, 9), NativeUi.dp(this, 9), NativeUi.dp(this, 9), NativeUi.dp(this, 9));
        b.setContentDescription(description);
        b.setBackground(NativeUi.rounded(NativeUi.withAlpha(Color.rgb(36, 41, 48), 242), 20, 1,
                NativeUi.withAlpha(Color.WHITE, 90), this));
        b.setElevation(NativeUi.dp(this, 4));
        b.setOnClickListener(click);
        return b;
    }

    private void applyOverviewMapMode(String mode) {
        if (overviewMap == null) return;
        if (mode == null || mode.trim().isEmpty()) mode = "standard";
        currentMapMode = mode;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_MAP_MODE, currentMapMode).apply();
        final CameraPosition preservedCamera = overviewStyleInitialized ? overviewMap.getCameraPosition() : null;
        if (!"offline".equals(mode)) offlineServer.stop();
        overviewMap.setMaxZoomPreference("satellite".equals(mode) ? 19.0 : ("topo".equals(mode) ? 17.0 : 20.0));

        if ("dark".equals(mode)) {
            overviewMap.setStyle(new Style.Builder().fromUri(OFM_DARK_READABLE), style -> onOverviewStyleReady(preservedCamera));
            return;
        }
        if ("topo".equals(mode)) {
            overviewMap.setStyle(new Style.Builder().fromJson(topographicStyleJson()), style -> onOverviewStyleReady(preservedCamera));
            return;
        }
        if ("satellite".equals(mode)) {
            overviewMap.setStyle(new Style.Builder().fromJson(satelliteStyleJson()), style -> onOverviewStyleReady(preservedCamera));
            return;
        }
        if ("offline".equals(mode)) {
            if (applyOverviewOfflineStyle(preservedCamera)) return;
            currentMapMode = "standard";
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_MAP_MODE, currentMapMode).apply();
            Toast.makeText(this, "No hay un paquete MBTiles cargado. Se mostrará Mapa.", Toast.LENGTH_LONG).show();
        }
        overviewMap.setStyle(new Style.Builder().fromUri(OFM_LIBERTY), style -> onOverviewStyleReady(preservedCamera));
    }

    private void onOverviewStyleReady(CameraPosition preservedCamera) {
        overviewFallbackInProgress = false;
        overviewMarker = null;
        overviewAccuracyPolygon = null;
        if (overviewMap != null) overviewMap.getUiSettings().setAllGesturesEnabled(true);
        if (preservedCamera != null) {
            overviewStyleInitialized = true;
            overviewMap.moveCamera(CameraUpdateFactory.newCameraPosition(preservedCamera));
            if (overviewPosition != null && isRecent(overviewPosition)) {
                drawOverviewMarker(overviewPosition.latitude, overviewPosition.longitude, (float) overviewPosition.accuracy);
            }
            return;
        }
        overviewStyleInitialized = true;
        centerOverviewMap(false);
    }

    private boolean applyOverviewOfflineStyle(CameraPosition preservedCamera) {
        String path = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_OFFLINE_PATH, "");
        if (path == null || path.trim().isEmpty()) return false;
        File file = new File(path);
        if (!file.isFile()) return false;
        try {
            offlineServer.start(file);
            String url = "http://127.0.0.1:" + offlineServer.getPort() + "/tiles/{z}/{x}/{y}." + offlineServer.getFormat();
            String attribution = escapeJson(offlineServer.getAttribution());
            String style = "{\"version\":8,\"sources\":{\"offline\":{\"type\":\"raster\",\"tiles\":[\"" + url
                    + "\"],\"tileSize\":256,\"minzoom\":" + offlineServer.getMinZoom() + ",\"maxzoom\":" + offlineServer.getMaxZoom()
                    + ",\"attribution\":\"" + attribution + "\"}},\"layers\":[{\"id\":\"background\",\"type\":\"background\",\"paint\":{\"background-color\":\"#e8edf1\"}},{\"id\":\"offline\",\"type\":\"raster\",\"source\":\"offline\",\"paint\":{\"raster-fade-duration\":0}}]}";
            overviewMap.setStyle(new Style.Builder().fromJson(style), loaded -> onOverviewStyleReady(preservedCamera));
            return true;
        } catch (Exception e) {
            offlineServer.stop();
            return false;
        }
    }

    private String satelliteStyleJson() {
        return "{\"version\":8,\"sources\":{" 
                + "\"imagery\":{\"type\":\"raster\",\"tiles\":[\"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}\"],\"tileSize\":256,\"maxzoom\":19,\"attribution\":\"Powered by Esri · Esri, Maxar, Earthstar Geographics and the GIS User Community\"},"
                + "\"roads\":{\"type\":\"raster\",\"tiles\":[\"https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Transportation/MapServer/tile/{z}/{y}/{x}\"],\"tileSize\":256,\"maxzoom\":19},"
                + "\"labels\":{\"type\":\"raster\",\"tiles\":[\"https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}\"],\"tileSize\":256,\"maxzoom\":19}"
                + "},\"layers\":["
                + "{\"id\":\"imagery\",\"type\":\"raster\",\"source\":\"imagery\",\"paint\":{\"raster-fade-duration\":0,\"raster-contrast\":0.08,\"raster-saturation\":0.05}},"
                + "{\"id\":\"roads\",\"type\":\"raster\",\"source\":\"roads\",\"paint\":{\"raster-fade-duration\":0}},"
                + "{\"id\":\"labels\",\"type\":\"raster\",\"source\":\"labels\",\"paint\":{\"raster-fade-duration\":0}}]}";
    }

    private String topographicStyleJson() {
        return "{\"version\":8,\"sources\":{"
                + "\"topo\":{\"type\":\"raster\",\"tiles\":[\"https://tile.opentopomap.org/{z}/{x}/{y}.png\"],\"tileSize\":256,\"maxzoom\":17,\"attribution\":\"© OpenStreetMap contributors · SRTM | Map style © OpenTopoMap (CC-BY-SA)\"}"
                + "},\"layers\":["
                + "{\"id\":\"background\",\"type\":\"background\",\"paint\":{\"background-color\":\"#e8ede3\"}},"
                + "{\"id\":\"topo\",\"type\":\"raster\",\"source\":\"topo\",\"paint\":{\"raster-fade-duration\":0}}]}";
    }

    private void handleOverviewMapLoadFailure(String errorMessage) {
        runOnUiThread(() -> {
            if (overviewMap == null) return;
            if (overviewFallbackInProgress) {
                setMapHint("Mapa no disponible");
                return;
            }
            if (!"standard".equals(currentMapMode)) {
                overviewFallbackInProgress = true;
                currentMapMode = "standard";
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_MAP_MODE, currentMapMode).apply();
                Toast.makeText(this, "La capa no respondió. Volviendo a Mapa.", Toast.LENGTH_SHORT).show();
                applyOverviewMapMode("standard");
            } else {
                overviewFallbackInProgress = true;
                setMapHint("Mapa no disponible · revisa conexión");
            }
        });
    }

    private String escapeJson(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", " ");
    }

    private String mapModeLabel(String mode) {
        if ("dark".equals(mode)) return "Oscuro";
        if ("satellite".equals(mode)) return "Satélite";
        if ("topo".equals(mode)) return "Topográfico";
        if ("offline".equals(mode)) return "Offline";
        return "Mapa";
    }

    private void showOverviewLayers() {
        MapLayerPicker.show(this, currentMapMode, new MapLayerPicker.Listener() {
            @Override public void onLayerSelected(String mode) {
                applyOverviewMapMode(mode);
            }

            @Override public void onManageOffline() {
                startActivity(new Intent(GpsOverviewActivity.this, OfflineMapActivity.class));
            }
        });
    }

    private void centerOverviewMap(boolean animate) {
        if (overviewMap == null) return;
        Location live = currentLocation;
        if (live != null && System.currentTimeMillis() - live.getTime() <= RECENT_MAP_LOCATION_MS) {
            moveOverviewCamera(live.getLatitude(), live.getLongitude(), OVERVIEW_CONTEXT_ZOOM, animate);
            drawOverviewMarker(live.getLatitude(), live.getLongitude(), live.hasAccuracy() ? live.getAccuracy() : 0f);
            setMapHint("±" + format1(live.hasAccuracy() ? live.getAccuracy() : 0f) + " m");
            return;
        }
        if (overviewPosition != null && isRecent(overviewPosition)) {
            moveOverviewCamera(overviewPosition.latitude, overviewPosition.longitude, OVERVIEW_CONTEXT_ZOOM, animate);
            drawOverviewMarker(overviewPosition.latitude, overviewPosition.longitude, (float) overviewPosition.accuracy);
            setMapHint("Última lectura");
            return;
        }
        if (overviewMarker != null) {
            try { overviewMap.removeMarker(overviewMarker); } catch (Exception ignored) { }
            overviewMarker = null;
        }
        if (overviewAccuracyPolygon != null) {
            try { overviewMap.removePolygon(overviewAccuracyPolygon); } catch (Exception ignored) { }
            overviewAccuracyPolygon = null;
        }
        moveOverviewCamera(0.0, 0.0, 1.35, animate);
        setMapHint("Ubicación aún no disponible");
    }

    private void moveOverviewCamera(double lat, double lon, double zoom, boolean animate) {
        CameraPosition camera = new CameraPosition.Builder().target(new LatLng(lat, lon)).zoom(zoom).bearing(0).tilt(0).build();
        if (animate) overviewMap.animateCamera(CameraUpdateFactory.newCameraPosition(camera), 420);
        else overviewMap.moveCamera(CameraUpdateFactory.newCameraPosition(camera));
    }

    private void drawOverviewMarker(double lat, double lon, float accuracyMeters) {
        if (overviewMap == null) return;
        if (overviewMarker != null) {
            try { overviewMap.removeMarker(overviewMarker); } catch (Exception ignored) { }
        }
        if (overviewAccuracyPolygon != null) {
            try { overviewMap.removePolygon(overviewAccuracyPolygon); } catch (Exception ignored) { }
            overviewAccuracyPolygon = null;
        }
        LatLng center = new LatLng(lat, lon);
        if (accuracyMeters > 0f && accuracyMeters < 5000f) {
            overviewAccuracyPolygon = overviewMap.addPolygon(new PolygonOptions()
                    .addAll(buildOverviewAccuracyCircle(center, accuracyMeters))
                    .fillColor(Color.argb(28, 66, 133, 244))
                    .strokeColor(Color.argb(85, 66, 133, 244)));
        }
        overviewMarker = overviewMap.addMarker(new MarkerOptions()
                .position(center)
                .title("Posición actual")
                .icon(IconFactory.getInstance(this).fromBitmap(createOverviewLocationDotBitmap())));
    }

    private Bitmap createOverviewLocationDotBitmap() {
        int size = NativeUi.dp(this, 22);
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        float center = size / 2f;
        paint.setColor(Color.WHITE);
        canvas.drawCircle(center, center, NativeUi.dp(this, 6), paint);
        paint.setColor(Color.rgb(66, 133, 244));
        canvas.drawCircle(center, center, NativeUi.dp(this, 4), paint);
        return bitmap;
    }

    private List<LatLng> buildOverviewAccuracyCircle(LatLng center, float radiusMeters) {
        List<LatLng> ring = new ArrayList<>();
        double latRad = Math.toRadians(center.getLatitude());
        double metersPerDegLat = 111320.0;
        double metersPerDegLon = Math.max(1.0, 111320.0 * Math.cos(latRad));
        for (int i = 0; i <= 40; i++) {
            double a = Math.toRadians(i * 360.0 / 40.0);
            ring.add(new LatLng(center.getLatitude() + Math.sin(a) * radiusMeters / metersPerDegLat,
                    center.getLongitude() + Math.cos(a) * radiusMeters / metersPerDegLon));
        }
        return ring;
    }

    private void setMapHint(String text) {
        if (mapHintView != null) mapHintView.setText(text == null ? "" : text);
    }

    private void resetOverviewBearing() {
        if (overviewMap == null) return;
        CameraPosition current = overviewMap.getCameraPosition();
        CameraPosition next = new CameraPosition.Builder(current).bearing(0).tilt(0).build();
        overviewMap.animateCamera(CameraUpdateFactory.newCameraPosition(next), 260);
    }

    private void centerOrStartGps() {
        if (currentLocation != null && System.currentTimeMillis() - currentLocation.getTime() <= RECENT_MAP_LOCATION_MS) {
            overviewAutoCenterPending = true;
            centerOverviewMap(true);
            overviewAutoCenterPending = false;
        } else {
            overviewAutoCenterPending = true;
            startGps();
        }
    }

    private View mapControl(String glyph, String description, View.OnClickListener click) {
        TextView b = NativeUi.text(this, glyph, 16.5f, true, Color.WHITE);
        b.setGravity(Gravity.CENTER);
        b.setContentDescription(description);
        b.setBackground(NativeUi.rounded(NativeUi.withAlpha(NativeUi.BG_DEEP, 235), 18, 1,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 130), this));
        b.setOnClickListener(click);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                NativeUi.dp(this, 38), NativeUi.dp(this, 38));
        lp.setMargins(0, NativeUi.dp(this, 2), 0, NativeUi.dp(this, 2));
        b.setLayoutParams(lp);
        return b;
    }

    private View buildStatusPanel(LastPosition p) {
        LinearLayout panel = NativeUi.row(this);
        panel.setPadding(NativeUi.dp(this, 5), NativeUi.dp(this, 5),
                NativeUi.dp(this, 5), NativeUi.dp(this, 5));
        panel.setBackground(NativeUi.gradient(NativeUi.CARD_LIGHT, NativeUi.CARD_DARK, 15,
                NativeUi.withAlpha(NativeUi.BORDER, 130), this));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 72));
        plp.setMargins(0, 0, 0, NativeUi.dp(this, 9));
        panel.setLayoutParams(plp);

        qualityValue = metric(panel, "Calidad", qualityLabel(p), qualityColor(p));
        precisionValue = metric(panel, "Precisión", p.valid ? "±" + format1(p.accuracy) + " m" : "—", NativeUi.BLUE_LIGHT);
        satellitesValue = metric(panel, "Satélites", p.valid ? p.satellitesUsed + " / " + p.satellitesVisible : "0 / 0", Color.rgb(170, 122, 255));
        timeValue = metric(panel, "Hora", p.valid ? formatTime(p.timestamp) : "—", Color.rgb(255, 198, 82));
        return panel;
    }

    private TextView metric(LinearLayout parent, String title, String value, int color) {
        LinearLayout box = NativeUi.column(this);
        box.setGravity(Gravity.CENTER);
        box.setPadding(NativeUi.dp(this, 5), NativeUi.dp(this, 6), NativeUi.dp(this, 5), NativeUi.dp(this, 6));
        box.setBackground(NativeUi.rounded(NativeUi.withAlpha(NativeUi.BG_DEEP, 120), 12, 1,
                NativeUi.withAlpha(NativeUi.BORDER, 85), this));
        TextView t = NativeUi.text(this, title, 10.2f, false, NativeUi.SUB);
        t.setGravity(Gravity.CENTER);
        TextView v = NativeUi.text(this, value, 12.2f, true, color);
        v.setGravity(Gravity.CENTER);
        v.setMaxLines(2);
        box.addView(t);
        box.addView(v);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lp.setMargins(NativeUi.dp(this, 2), NativeUi.dp(this, 2), NativeUi.dp(this, 2), NativeUi.dp(this, 2));
        parent.addView(box, lp);
        return v;
    }

    private View buildPrimaryActions() {
        LinearLayout row = NativeUi.row(this);
        View gpsCard = actionCard("play", "Iniciar\nGPS", v -> startOrStopGps());
        gpsActionLabel = (TextView) gpsCard.getTag();
        row.addView(gpsCard, actionLp(false, true));
        View avgCard = actionCard("clock", "Promediar", v -> onAverageAction());
        averageActionLabel = (TextView) avgCard.getTag();
        row.addView(avgCard, actionLp(true, true));
        row.addView(actionCard("pin", "Guardar\npunto", v -> showSavePointDialog()), actionLp(true, false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 88));
        lp.setMargins(0, 0, 0, NativeUi.dp(this, 9));
        row.setLayoutParams(lp);
        return row;
    }

    private View buildReadingPanel(LastPosition p) {
        LinearLayout panel = NativeUi.column(this);
        panel.setPadding(NativeUi.dp(this, 14), NativeUi.dp(this, 13), NativeUi.dp(this, 14), NativeUi.dp(this, 13));
        panel.setBackground(NativeUi.gradient(NativeUi.CARD_LIGHT, NativeUi.CARD_DARK, 18,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 135), this));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        plp.setMargins(0, 0, 0, NativeUi.dp(this, 12));
        panel.setLayoutParams(plp);

        LinearLayout head = NativeUi.row(this);
        TextView title = NativeUi.text(this, "⌁  LECTURA ACTUAL", 15.5f, true, NativeUi.TEXT);
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        readingStateValue = NativeUi.text(this, p.valid ? "●  " + relativeTime(p.timestamp) : "Sin lectura", 11.5f, true,
                p.valid ? Color.rgb(53, 220, 145) : NativeUi.SUB);
        head.addView(readingStateValue);
        panel.addView(head);

        CoordinateUtils.Utm utm = p.valid ? CoordinateUtils.toUtm(p.latitude, p.longitude) : null;
        LinearLayout row1 = NativeUi.row(this);
        latValue = readingCell(row1, "Latitud", p.valid ? format6(p.latitude) + "°" : "Sin lectura", true);
        lonValue = readingCell(row1, "Longitud", p.valid ? format6(p.longitude) + "°" : "Sin lectura", false);
        panel.addView(row1);

        LinearLayout row2 = NativeUi.row(this);
        eastValue = readingCell(row2, "Este UTM", utm != null && utm.valid ? format3(utm.easting) + " m" : "Sin lectura", true);
        northValue = readingCell(row2, "Norte UTM", utm != null && utm.valid ? format3(utm.northing) + " m" : "Sin lectura", false);
        panel.addView(row2);

        LinearLayout row3 = NativeUi.row(this);
        altitudeValue = readingCell(row3, "Altitud GNSS", !Float.isNaN(p.altitudeM) ? format1(p.altitudeM) + " m" : "No disponible", true);
        readingPrecisionValue = readingCell(row3, "Precisión", p.valid ? "±" + format1(p.accuracy) + " m" : "Sin lectura", false);
        panel.addView(row3);

        LinearLayout row4 = NativeUi.row(this);
        zoneValue = readingCell(row4, "Zona UTM", utm != null && utm.valid ? utm.zone + utm.hemisphere() : "Sin lectura", true);
        readingCell(row4, "Datum", "WGS84 / UTM", false);
        panel.addView(row4);
        return panel;
    }

    private TextView readingCell(LinearLayout row, String title, String value, boolean left) {
        LinearLayout box = NativeUi.column(this);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(NativeUi.dp(this, 9), NativeUi.dp(this, 6), NativeUi.dp(this, 7), NativeUi.dp(this, 6));
        box.setBackground(NativeUi.rounded(NativeUi.withAlpha(NativeUi.BG_DEEP, 125), 10, 1,
                NativeUi.withAlpha(NativeUi.BORDER, 85), this));
        TextView t = NativeUi.text(this, title, 9.5f, false, NativeUi.SUB);
        TextView v = NativeUi.text(this, value, 12.1f, true, NativeUi.TEXT);
        v.setPadding(0, NativeUi.dp(this, 2), 0, 0);
        v.setSingleLine(true);
        box.addView(t);
        box.addView(v);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, NativeUi.dp(this, 58), 1f);
        lp.setMargins(left ? 0 : NativeUi.dp(this, 4), NativeUi.dp(this, 4), left ? NativeUi.dp(this, 4) : 0, 0);
        row.addView(box, lp);
        return v;
    }

    private View buildSecondaryActions() {
        LinearLayout row = NativeUi.row(this);
        row.setBaselineAligned(false);
        row.addView(actionCard("bookmark", "Puntos", v -> showPointsPanel()), actionLp(false, true));
        row.addView(actionCard("satellite", "Datos GNSS", v -> showGnssPanel()), actionLp(true, true));
        row.addView(actionCard("file", "Exportar", v -> showExportPanel()), actionLp(true, false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 76));
        lp.setMargins(0, 0, 0, NativeUi.dp(this, 7));
        row.setLayoutParams(lp);
        return row;
    }

    private LinearLayout.LayoutParams actionLp(boolean leftMargin, boolean rightMargin) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lp.setMargins(leftMargin ? NativeUi.dp(this, 4) : 0, 0,
                rightMargin ? NativeUi.dp(this, 4) : 0, 0);
        return lp;
    }

    private View actionCard(String icon, String label, View.OnClickListener click) {
        LinearLayout box = NativeUi.column(this);
        box.setPadding(NativeUi.dp(this, 6), NativeUi.dp(this, 7), NativeUi.dp(this, 6), NativeUi.dp(this, 6));
        box.setGravity(Gravity.CENTER);
        box.setBackground(NativeUi.gradient(NativeUi.CARD_LIGHT, NativeUi.CARD_DARK, 13,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 110), this));
        box.setOnClickListener(click);
        FrameLayout iconBox = NativeUi.iconTile(this, icon, 31);
        box.addView(iconBox, new LinearLayout.LayoutParams(NativeUi.dp(this, 31), NativeUi.dp(this, 31)));
        TextView title = NativeUi.text(this, label, 10.6f, true, NativeUi.TEXT);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, NativeUi.dp(this, 4), 0, 0);
        title.setMaxLines(2);
        box.addView(title);
        box.setTag(title);
        return box;
    }

    private View recentPointsCard() {
        LinearLayout card = NativeUi.column(this);
        card.setBackground(NativeUi.gradient(NativeUi.CARD_LIGHT, NativeUi.CARD_DARK, 18,
                NativeUi.withAlpha(NativeUi.BORDER, 165), this));
        List<PointRow> points = readRecentPoints(3);
        if (points.isEmpty()) {
            TextView empty = NativeUi.text(this,
                    "Todavía no hay puntos guardados. Usa Guardar punto para registrar el primero.",
                    13.2f, false, NativeUi.SUB);
            empty.setPadding(NativeUi.dp(this, 16), NativeUi.dp(this, 18),
                    NativeUi.dp(this, 16), NativeUi.dp(this, 18));
            card.addView(empty);
            return card;
        }
        for (int i = 0; i < points.size(); i++) {
            PointRow point = points.get(i);
            card.addView(recentRow(point));
            if (i < points.size() - 1) {
                View divider = new View(this);
                divider.setBackgroundColor(NativeUi.withAlpha(NativeUi.BORDER, 80));
                card.addView(divider, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 1)));
            }
        }
        return card;
    }

    private View recentRow(PointRow point) {
        LinearLayout row = NativeUi.row(this);
        row.setPadding(NativeUi.dp(this, 12), NativeUi.dp(this, 13),
                NativeUi.dp(this, 10), NativeUi.dp(this, 13));
        row.setOnClickListener(v -> openPointOnMap(point));
        NativeUi.IconGlyphView icon = new NativeUi.IconGlyphView(this, "pin");
        row.addView(icon, new LinearLayout.LayoutParams(NativeUi.dp(this, 38), NativeUi.dp(this, 38)));
        LinearLayout labels = NativeUi.column(this);
        labels.setPadding(NativeUi.dp(this, 9), 0, NativeUi.dp(this, 5), 0);
        labels.addView(NativeUi.text(this, point.name, 14.5f, true, NativeUi.TEXT));
        TextView sub = NativeUi.text(this, point.summary, 11.2f, false, NativeUi.SUB);
        sub.setSingleLine(true);
        labels.addView(sub);
        row.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView time = NativeUi.text(this, point.time + "  ›", 11.5f, false, NativeUi.SUB);
        row.addView(time);
        return row;
    }

    private void startOrStopGps() {
        if (gpsRunning) {
            stopLocationUpdates(true);
        } else {
            startGps();
        }
    }

    private void startGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
            return;
        }
        if (locationManager == null) {
            Toast.makeText(this, "Servicio de ubicación no disponible.", Toast.LENGTH_LONG).show();
            return;
        }
        boolean gpsEnabled = false;
        try { gpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER); } catch (Exception ignored) { }
        if (!gpsEnabled) {
            new AlertDialog.Builder(this)
                    .setTitle("Activar ubicación")
                    .setMessage("Activa la ubicación del teléfono para obtener una lectura GPS/GNSS.")
                    .setPositiveButton("Abrir ajustes", (d, w) -> startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)))
                    .setNegativeButton("Cancelar", null)
                    .show();
            return;
        }
        try {
            locationManager.removeUpdates(this);
            currentLocation = null;
            gpsRunning = true;
            overviewAutoCenterPending = true;
            updateActionLabels();
            setMapHint("Buscando señal GPS…");
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this);
            try {
                if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                    locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1400L, 0f, this);
            } catch (Exception ignored) { }
            registerGnssStatus();
        } catch (SecurityException e) {
            gpsRunning = false;
            updateActionLabels();
            Toast.makeText(this, "Permite ubicación precisa para usar el GPS.", Toast.LENGTH_LONG).show();
        }
    }

    private void stopLocationUpdates(boolean showMessage) {
        if (locationManager != null) {
            try { locationManager.removeUpdates(this); } catch (Exception ignored) { }
        }
        unregisterGnssStatus();
        gpsRunning = false;
        if (averaging) {
            averaging = false;
            averageSamples.clear();
            handler.removeCallbacks(averageFinishRunnable);
            if (averageProgressRunnable != null) handler.removeCallbacks(averageProgressRunnable);
        }
        updateActionLabels();
        if (showMessage) Toast.makeText(this, "GPS detenido.", Toast.LENGTH_SHORT).show();
    }

    private void onAverageAction() {
        if (averaging) {
            cancelAveraging(true);
            return;
        }
        showAverageDurationChooser();
    }

    private void showAverageDurationChooser() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout sheet = NativeUi.column(this);
        sheet.setPadding(NativeUi.dp(this, 16), NativeUi.dp(this, 10),
                NativeUi.dp(this, 16), NativeUi.dp(this, 16));
        sheet.setBackground(NativeUi.gradient(Color.rgb(10, 29, 48), Color.rgb(4, 20, 36), 22,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 120), this));

        View handle = new View(this);
        handle.setBackground(NativeUi.rounded(Color.rgb(111, 132, 151), 3, 0, Color.TRANSPARENT, this));
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(NativeUi.dp(this, 42), NativeUi.dp(this, 4));
        hlp.gravity = Gravity.CENTER_HORIZONTAL;
        hlp.setMargins(0, 0, 0, NativeUi.dp(this, 12));
        sheet.addView(handle, hlp);

        sheet.addView(NativeUi.text(this, "Promediar ubicación", 19f, true, NativeUi.TEXT));
        TextView sub = NativeUi.text(this,
                "Elige el tiempo de observación. GeoTopo filtra lecturas inestables y prioriza GNSS cuando está disponible.",
                11.5f, false, NativeUi.SUB);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.setMargins(0, NativeUi.dp(this, 3), 0, NativeUi.dp(this, 12));
        sheet.addView(sub, slp);

        LinearLayout row1 = NativeUi.row(this);
        row1.addView(averageDurationCard("10 s", "Rápido", "Comprobación breve", 10000L, dialog), durationOptionLp(false));
        row1.addView(averageDurationCard("20 s", "Normal", "Uso general", 20000L, dialog), durationOptionLp(true));
        sheet.addView(row1);

        LinearLayout row2 = NativeUi.row(this);
        row2.addView(averageDurationCard("30 s", "Recomendado", "Mejor estabilidad", 30000L, dialog), durationOptionLp(false));
        row2.addView(averageDurationCard("60 s", "Máxima estabilidad", "Trabajo de campo", 60000L, dialog), durationOptionLp(true));
        LinearLayout.LayoutParams r2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        r2.setMargins(0, NativeUi.dp(this, 8), 0, 0);
        sheet.addView(row2, r2);

        TextView cancel = NativeUi.text(this, "Cancelar", 12.5f, true, NativeUi.SUB);
        cancel.setGravity(Gravity.CENTER);
        cancel.setPadding(0, NativeUi.dp(this, 13), 0, NativeUi.dp(this, 3));
        cancel.setOnClickListener(v -> dialog.dismiss());
        sheet.addView(cancel);

        dialog.setContentView(sheet);
        dialog.setCanceledOnTouchOutside(true);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setGravity(Gravity.BOTTOM);
            WindowManager.LayoutParams params = window.getAttributes();
            params.width = WindowManager.LayoutParams.MATCH_PARENT;
            params.height = WindowManager.LayoutParams.WRAP_CONTENT;
            params.dimAmount = 0.38f;
            window.setAttributes(params);
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
        dialog.show();
        if (window != null) window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams durationOptionLp(boolean leftMargin) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, NativeUi.dp(this, 98), 1f);
        lp.setMargins(leftMargin ? NativeUi.dp(this, 5) : 0, 0, leftMargin ? 0 : NativeUi.dp(this, 5), 0);
        return lp;
    }

    private View averageDurationCard(String duration, String title, String subtitle, long durationMs, Dialog dialog) {
        LinearLayout card = NativeUi.column(this);
        card.setGravity(Gravity.CENTER);
        card.setPadding(NativeUi.dp(this, 8), NativeUi.dp(this, 8), NativeUi.dp(this, 8), NativeUi.dp(this, 8));
        card.setBackground(NativeUi.gradient(NativeUi.CARD_LIGHT, NativeUi.CARD_DARK, 15,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 130), this));
        TextView big = NativeUi.text(this, duration, 21f, true, NativeUi.BLUE_LIGHT);
        big.setGravity(Gravity.CENTER);
        card.addView(big);
        TextView t = NativeUi.text(this, title, 12.3f, true, NativeUi.TEXT);
        t.setGravity(Gravity.CENTER);
        card.addView(t);
        TextView st = NativeUi.text(this, subtitle, 9.6f, false, NativeUi.SUB);
        st.setGravity(Gravity.CENTER);
        st.setMaxLines(2);
        card.addView(st);
        card.setOnClickListener(v -> {
            dialog.dismiss();
            beginAveraging(durationMs);
        });
        return card;
    }

    private void beginAveraging(long durationMs) {
        if (averaging) {
            cancelAveraging(true);
            return;
        }
        pendingAverageDurationMs = durationMs;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            startAverageAfterPermission = true;
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
            return;
        }
        if (!gpsRunning) {
            startGps();
            if (!gpsRunning) return;
        }
        averageDurationMs = durationMs == 10000L || durationMs == 20000L || durationMs == 30000L || durationMs == 60000L
                ? durationMs : 20000L;
        getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit().putLong("average_duration_ms", averageDurationMs).apply();
        averageStartedAt = System.currentTimeMillis();
        averaging = true;
        averageSamples.clear();
        averagingRejectedSamples = 0;
        totalAverageReadings = 0;
        maxSatellitesUsedDuringAverage = satellitesUsed;
        lastAcceptedAverageSample = null;
        bestAverageAccuracy = Float.NaN;
        finalAverageStability = Float.NaN;
        finalAverageAccuracy = Float.NaN;
        finalValidSampleCount = 0;
        finalRejectedSampleCount = 0;
        finalAverageDurationSeconds = 0L;
        updateActionLabels();
        handler.removeCallbacks(averageFinishRunnable);
        if (averageProgressRunnable != null) handler.removeCallbacks(averageProgressRunnable);
        averageProgressRunnable = new Runnable() {
            @Override public void run() {
                if (!averaging) return;
                long elapsed = Math.max(0L, System.currentTimeMillis() - averageStartedAt);
                int totalSec = Math.max(1, (int) (averageDurationMs / 1000L));
                int elapsedSec = Math.min(totalSec, (int) (elapsed / 1000L));
                if (averageActionLabel != null) averageActionLabel.setText("Promedio\n" + elapsedSec + "/" + totalSec + " s");
                String best = Float.isNaN(bestAverageAccuracy) ? "sin mejor lectura" : "mejor ±" + format1(bestAverageAccuracy) + " m";
                setMapHint("Promediando " + elapsedSec + "/" + totalSec + " s · "
                        + averageSamples.size() + " válidas · " + averagingRejectedSamples + " descartadas · "
                        + maxSatellitesUsedDuringAverage + " sat. máx. · " + best);
                handler.postDelayed(this, 1000L);
            }
        };
        handler.post(averageProgressRunnable);
        handler.postDelayed(averageFinishRunnable, averageDurationMs);
    }

    private void cancelAveraging(boolean showMessage) {
        averaging = false;
        averageSamples.clear();
        averagingRejectedSamples = 0;
        totalAverageReadings = 0;
        lastAcceptedAverageSample = null;
        handler.removeCallbacks(averageFinishRunnable);
        if (averageProgressRunnable != null) handler.removeCallbacks(averageProgressRunnable);
        updateActionLabels();
        if (showMessage) {
            setMapHint("Promedio cancelado");
            Toast.makeText(this, "Promedio cancelado.", Toast.LENGTH_SHORT).show();
        }
    }

    private void finishAveraging() {
        if (!averaging) return;
        averaging = false;
        handler.removeCallbacks(averageFinishRunnable);
        if (averageProgressRunnable != null) handler.removeCallbacks(averageProgressRunnable);
        updateActionLabels();

        if (averageSamples.isEmpty() && currentLocation != null && isReasonableAverageSample(currentLocation)) {
            averageSamples.add(new Location(currentLocation));
            totalAverageReadings = Math.max(1, totalAverageReadings);
        }
        if (averageSamples.isEmpty()) {
            setMapHint("Sin promedio válido · revisa GPS, precisión y cielo despejado");
            Toast.makeText(this, "No hubo lecturas válidas durante el promedio.", Toast.LENGTH_LONG).show();
            return;
        }

        List<Location> preferred = preferGnssSamples(averageSamples);
        boolean approximate = !hasGnssSamples(preferred);
        List<Location> filtered = selectStableCluster(preferred);
        if (filtered.isEmpty()) filtered = new ArrayList<>(preferred);
        int rejectedByFilter = Math.max(0, averageSamples.size() - filtered.size());
        Location avg = averageLocationsWeighted(filtered);
        float best = bestReportedAccuracy(filtered);
        float stability = calculateStability68(filtered, avg);
        float finalAcc = estimateFinalAverageAccuracy(best, stability, approximate);
        if (!Float.isNaN(finalAcc)) avg.setAccuracy(finalAcc);

        bestAverageAccuracy = best;
        finalAverageStability = stability;
        finalAverageAccuracy = finalAcc;
        finalValidSampleCount = filtered.size();
        finalRejectedSampleCount = averagingRejectedSamples + rejectedByFilter;
        finalAverageDurationSeconds = Math.max(1L, averageDurationMs / 1000L);
        currentLocation = new Location(avg);
        saveLastLocation(avg);
        saveAverageMetrics();
        overviewPosition = fromLocation(avg);
        updateOverviewData(overviewPosition);
        if (overviewMap != null) {
            drawOverviewMarker(avg.getLatitude(), avg.getLongitude(), avg.hasAccuracy() ? avg.getAccuracy() : 0f);
            centerOverviewMap(true);
        }
        stopLocationUpdates(false);
        String source = approximate ? "asistido" : "GNSS";
        setMapHint("Promedio " + source + " listo · " + finalValidSampleCount + " usadas · "
                + finalRejectedSampleCount + " descartadas · final " + formatAverageAccuracy(finalAcc));
        Toast.makeText(this, "Promedio de " + finalAverageDurationSeconds + " s completado. Resultado listo para guardar.", Toast.LENGTH_LONG).show();
        averageSamples.clear();
    }

    private void updateActionLabels() {
        if (gpsActionLabel != null) gpsActionLabel.setText(gpsRunning ? "Detener\nGPS" : "Iniciar\nGPS");
        if (averageActionLabel != null) averageActionLabel.setText(averaging ? "Cancelar\npromedio" : "Promediar");
    }

    @Override public void onLocationChanged(Location location) {
        if (location == null) return;
        long timestamp = location.getTime() > 0 ? location.getTime() : System.currentTimeMillis();
        if (System.currentTimeMillis() - timestamp > 20000L) return;
        boolean firstLiveFix = currentLocation == null;
        if (currentLocation == null || isBetterLocation(location, currentLocation)) currentLocation = new Location(location);

        if (averaging) {
            maxSatellitesUsedDuringAverage = Math.max(maxSatellitesUsedDuringAverage, satellitesUsed);
            totalAverageReadings++;
            if (isSampleAllowedForAverage(location) && passesAverageJumpFilter(location)) {
                addAverageSample(location);
            } else {
                averagingRejectedSamples++;
            }
        }

        saveLastLocation(currentLocation);
        overviewPosition = fromLocation(currentLocation);
        updateOverviewData(overviewPosition);
        if (overviewMap != null) {
            drawOverviewMarker(currentLocation.getLatitude(), currentLocation.getLongitude(), currentLocation.hasAccuracy() ? currentLocation.getAccuracy() : 0f);
            if (overviewAutoCenterPending || firstLiveFix || overviewMap.getCameraPosition().zoom < 4.0) {
                centerOverviewMap(false);
                overviewAutoCenterPending = false;
            }
        }
    }

    private boolean isGpsSample(Location location) {
        return location != null && (LocationManager.GPS_PROVIDER.equals(location.getProvider())
                || "promedio_gnss".equals(location.getProvider()));
    }

    private boolean hasGnssSamples(List<Location> samples) {
        if (samples == null) return false;
        for (Location sample : samples) if (isGpsSample(sample)) return true;
        return false;
    }

    private boolean isSampleAllowedForAverage(Location location) {
        if (location == null) return false;
        long timestamp = location.getTime() > 0 ? location.getTime() : System.currentTimeMillis();
        if (System.currentTimeMillis() - timestamp > MAX_AVERAGE_SAMPLE_AGE_MS) return false;
        if (location.hasSpeed() && location.getSpeed() > MAX_STATIONARY_SPEED_MPS) return false;
        if (location.hasAccuracy() && location.getAccuracy() > MAX_AVERAGE_SAMPLE_ACCURACY_M) return false;
        if (!isGpsSample(location) && hasGnssSamples(averageSamples)) return false;
        return true;
    }

    private boolean isReasonableAverageSample(Location location) {
        if (location == null) return false;
        long timestamp = location.getTime() > 0 ? location.getTime() : System.currentTimeMillis();
        return System.currentTimeMillis() - timestamp <= 20000L
                && (!location.hasAccuracy() || location.getAccuracy() <= MAX_AVERAGE_SAMPLE_ACCURACY_M)
                && (!location.hasSpeed() || location.getSpeed() <= MAX_STATIONARY_SPEED_MPS);
    }

    private void addAverageSample(Location location) {
        Location sample = new Location(location);
        averageSamples.add(sample);
        lastAcceptedAverageSample = sample;
        maxSatellitesUsedDuringAverage = Math.max(maxSatellitesUsedDuringAverage, satellitesUsed);
        if (sample.hasAccuracy() && (Float.isNaN(bestAverageAccuracy) || sample.getAccuracy() < bestAverageAccuracy))
            bestAverageAccuracy = sample.getAccuracy();
    }

    private boolean passesAverageJumpFilter(Location location) {
        if (lastAcceptedAverageSample == null) return true;
        boolean currentGnss = isGpsSample(location);
        boolean previousGnss = isGpsSample(lastAcceptedAverageSample);
        if (currentGnss && !previousGnss) return true;
        if (!currentGnss && previousGnss) return false;
        float ca = location.hasAccuracy() ? location.getAccuracy() : 30f;
        float pa = lastAcceptedAverageSample.hasAccuracy() ? lastAcceptedAverageSample.getAccuracy() : 30f;
        if (currentGnss && ca + 5f < pa * 0.65f) return true;
        float base = currentGnss ? 10f : 35f;
        float cap = currentGnss ? 45f : 120f;
        float threshold = Math.max(base, Math.min(cap, (ca + pa) * 1.8f));
        return location.distanceTo(lastAcceptedAverageSample) <= threshold;
    }

    private List<Location> preferGnssSamples(List<Location> samples) {
        List<Location> gnss = new ArrayList<>();
        List<Location> fallback = new ArrayList<>();
        for (Location sample : samples) {
            if (sample == null) continue;
            if (isGpsSample(sample)) gnss.add(new Location(sample)); else fallback.add(new Location(sample));
        }
        return gnss.isEmpty() ? fallback : gnss;
    }

    private boolean isStoredAverageSample(Location location) {
        if (location == null) return false;
        if (location.hasAccuracy() && location.getAccuracy() > MAX_AVERAGE_SAMPLE_ACCURACY_M) return false;
        return !location.hasSpeed() || location.getSpeed() <= MAX_STATIONARY_SPEED_MPS;
    }

    private List<Location> selectStableCluster(List<Location> samples) {
        List<Location> clean = new ArrayList<>();
        if (samples == null) return clean;
        for (Location sample : samples) if (isStoredAverageSample(sample)) clean.add(new Location(sample));
        if (clean.size() <= 4) return clean;
        Location medoid = clean.get(0);
        double bestScore = Double.MAX_VALUE;
        for (Location candidate : clean) {
            List<Float> distances = new ArrayList<>();
            for (Location other : clean) distances.add(candidate.distanceTo(other));
            java.util.Collections.sort(distances);
            double score = distances.get(distances.size() / 2);
            if (score < bestScore) { bestScore = score; medoid = candidate; }
        }
        final Location center = medoid;
        java.util.Collections.sort(clean, (a, b) -> Float.compare(a.distanceTo(center), b.distanceTo(center)));
        int keep = Math.min(clean.size(), Math.max(4, (int) Math.ceil(clean.size() * 0.75)));
        return new ArrayList<>(clean.subList(0, keep));
    }

    private Location averageLocationsWeighted(List<Location> samples) {
        double totalWeight = 0, lat = 0, lon = 0, alt = 0, altWeight = 0, speed = 0, speedWeight = 0;
        double bearingSin = 0, bearingCos = 0, bearingWeight = 0;
        for (Location sample : samples) {
            double reported = sample.hasAccuracy() ? Math.max(3.0, Math.min(100.0, sample.getAccuracy())) : 20.0;
            double weight = 1.0 / reported;
            totalWeight += weight;
            lat += sample.getLatitude() * weight;
            lon += sample.getLongitude() * weight;
            if (sample.hasAltitude()) { alt += sample.getAltitude() * weight; altWeight += weight; }
            if (sample.hasSpeed()) { speed += sample.getSpeed() * weight; speedWeight += weight; }
            if (sample.hasBearing() && sample.hasSpeed() && sample.getSpeed() >= 0.8f) {
                double rad = Math.toRadians(sample.getBearing());
                bearingSin += Math.sin(rad) * weight; bearingCos += Math.cos(rad) * weight; bearingWeight += weight;
            }
        }
        if (totalWeight <= 0) totalWeight = Math.max(1, samples.size());
        Location result = new Location(hasGnssSamples(samples) ? "promedio_gnss" : "promedio_aproximado");
        result.setLatitude(lat / totalWeight);
        result.setLongitude(lon / totalWeight);
        if (altWeight > 0) result.setAltitude(alt / altWeight);
        if (speedWeight > 0) result.setSpeed((float) (speed / speedWeight));
        if (bearingWeight > 0) {
            double bearing = Math.toDegrees(Math.atan2(bearingSin, bearingCos));
            if (bearing < 0) bearing += 360.0;
            result.setBearing((float) bearing);
        }
        result.setTime(System.currentTimeMillis());
        return result;
    }

    private float bestReportedAccuracy(List<Location> samples) {
        float best = Float.NaN;
        for (Location sample : samples) if (sample != null && sample.hasAccuracy() && (Float.isNaN(best) || sample.getAccuracy() < best)) best = sample.getAccuracy();
        return best;
    }

    private float calculateStability68(List<Location> samples, Location center) {
        if (samples == null || samples.size() < 2 || center == null) return Float.NaN;
        List<Float> distances = new ArrayList<>();
        for (Location sample : samples) if (sample != null) distances.add(sample.distanceTo(center));
        if (distances.isEmpty()) return Float.NaN;
        java.util.Collections.sort(distances);
        int index = Math.max(0, Math.min(distances.size() - 1, (int) Math.ceil(distances.size() * 0.68) - 1));
        return distances.get(index);
    }

    private float estimateFinalAverageAccuracy(float best, float stability, boolean approximate) {
        float result = Float.isNaN(best) ? stability : (Float.isNaN(stability) ? best : Math.max(best, stability));
        if (Float.isNaN(result)) return Float.NaN;
        if (approximate) result = Math.max(result, 10f);
        return Math.max(1f, result);
    }

    private String formatAverageAccuracy(float value) {
        return Float.isNaN(value) ? "no disponible" : "±" + format1(value) + " m";
    }

    private void saveAverageMetrics() {
        getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit()
                .putFloat("last_average_best_accuracy", bestAverageAccuracy)
                .putFloat("last_average_stability", finalAverageStability)
                .putFloat("last_average_final_accuracy", finalAverageAccuracy)
                .putInt("last_average_valid", finalValidSampleCount)
                .putInt("last_average_rejected", finalRejectedSampleCount)
                .putInt("last_average_max_satellites", maxSatellitesUsedDuringAverage)
                .putLong("last_average_duration_s", finalAverageDurationSeconds)
                .putLong("last_average_time", System.currentTimeMillis())
                .apply();
    }

    private boolean isBetterLocation(Location candidate, Location current) {
        if (current == null) return true;
        long dt = candidate.getTime() - current.getTime();
        if (dt > 15000L) return true;
        float ca = candidate.hasAccuracy() ? candidate.getAccuracy() : 9999f;
        float oa = current.hasAccuracy() ? current.getAccuracy() : 9999f;
        return ca <= oa + 4f || dt > 3000L;
    }

    private void registerGnssStatus() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N || locationManager == null || gnssRegistered) return;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        if (gnssCallback == null) {
            gnssCallback = new GnssStatus.Callback() {
                @Override public void onSatelliteStatusChanged(GnssStatus status) {
                    satellitesVisible = status.getSatelliteCount();
                    int used = 0;
                    for (int i = 0; i < status.getSatelliteCount(); i++) if (status.usedInFix(i)) used++;
                    satellitesUsed = used;
                    getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit()
                            .putInt("last_satellites_visible", satellitesVisible)
                            .putInt("last_satellites_used", satellitesUsed)
                            .apply();
                    if (satellitesValue != null) satellitesValue.setText(satellitesUsed + " / " + satellitesVisible);
                }
            };
        }
        try {
            locationManager.registerGnssStatusCallback(gnssCallback, handler);
            gnssRegistered = true;
        } catch (Exception ignored) { }
    }

    private void unregisterGnssStatus() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N || locationManager == null || !gnssRegistered || gnssCallback == null) return;
        try { locationManager.unregisterGnssStatusCallback(gnssCallback); } catch (Exception ignored) { }
        gnssRegistered = false;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_LOCATION) return;
        boolean precise = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if (!precise) {
            startAverageAfterPermission = false;
            Toast.makeText(this, "Para GPS/GNSS selecciona ubicación precisa.", Toast.LENGTH_LONG).show();
            return;
        }
        startGps();
        if (startAverageAfterPermission) {
            startAverageAfterPermission = false;
            handler.postDelayed(() -> beginAveraging(pendingAverageDurationMs), 450L);
        }
    }

    private void updateOverviewData(LastPosition p) {
        if (p == null) p = new LastPosition();
        if (qualityValue != null) {
            qualityValue.setText(qualityLabel(p));
            qualityValue.setTextColor(qualityColor(p));
        }
        if (precisionValue != null) precisionValue.setText(p.valid ? "±" + format1(p.accuracy) + " m" : "—");
        if (satellitesValue != null) satellitesValue.setText(p.valid ? p.satellitesUsed + " / " + p.satellitesVisible : "0 / 0");
        if (timeValue != null) timeValue.setText(p.valid ? formatTime(p.timestamp) : "—");
        if (readingStateValue != null) readingStateValue.setText(p.valid ? "●  " + relativeTime(p.timestamp) : "Sin lectura");
        if (latValue != null) latValue.setText(p.valid ? format6(p.latitude) + "°" : "Sin lectura");
        if (lonValue != null) lonValue.setText(p.valid ? format6(p.longitude) + "°" : "Sin lectura");
        CoordinateUtils.Utm utm = p.valid ? CoordinateUtils.toUtm(p.latitude, p.longitude) : null;
        if (eastValue != null) eastValue.setText(utm != null && utm.valid ? format3(utm.easting) + " m" : "Sin lectura");
        if (northValue != null) northValue.setText(utm != null && utm.valid ? format3(utm.northing) + " m" : "Sin lectura");
        if (altitudeValue != null) altitudeValue.setText(!Float.isNaN(p.altitudeM) ? format1(p.altitudeM) + " m" : "No disponible");
        if (readingPrecisionValue != null) readingPrecisionValue.setText(p.valid ? "±" + format1(p.accuracy) + " m" : "Sin lectura");
        if (zoneValue != null) zoneValue.setText(utm != null && utm.valid ? utm.zone + utm.hemisphere() : "Sin lectura");
    }

    private void saveLastLocation(Location location) {
        if (location == null) return;
        SharedPreferences.Editor e = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit()
                .putString("last_latitude", Double.toString(location.getLatitude()))
                .putString("last_longitude", Double.toString(location.getLongitude()))
                .putFloat("last_accuracy", location.hasAccuracy() ? location.getAccuracy() : 0f)
                .putFloat("last_speed_mps", location.hasSpeed() ? location.getSpeed() : -1f)
                .putFloat("last_altitude_m", location.hasAltitude() ? (float) location.getAltitude() : Float.NaN)
                .putString("last_provider", location.getProvider() == null ? "" : location.getProvider())
                .putLong("last_location_time", location.getTime() > 0 ? location.getTime() : System.currentTimeMillis())
                .putInt("last_satellites_visible", satellitesVisible)
                .putInt("last_satellites_used", satellitesUsed);
        e.apply();
    }

    private void showSavePointDialog() {
        Location loc = freshLocationForSave();
        if (loc == null) {
            Toast.makeText(this, "Primero inicia el GPS y espera una lectura reciente.", Toast.LENGTH_LONG).show();
            return;
        }
        if (loc.hasAccuracy() && loc.getAccuracy() > 50f) {
            final Location lowAccuracy = new Location(loc);
            new AlertDialog.Builder(this)
                    .setTitle("Precisión baja")
                    .setMessage("La lectura actual es ±" + format1(loc.getAccuracy()) + " m. Para trabajo topográfico conviene esperar una lectura mejor. ¿Guardar de todos modos como punto referencial?")
                    .setPositiveButton("Guardar referencial", (d, w) -> showSavePointForm(lowAccuracy))
                    .setNegativeButton("Esperar mejor GPS", null)
                    .show();
            return;
        }
        showSavePointForm(loc);
    }

    private void showSavePointForm(Location loc) {
        pendingPhotoUri = "";
        LinearLayout form = NativeUi.column(this);
        form.setPadding(NativeUi.dp(this, 18), NativeUi.dp(this, 8), NativeUi.dp(this, 18), 0);
        EditText project = new EditText(this);
        project.setHint("Proyecto");
        project.setSingleLine(true);
        project.setText(getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString("current_project", "Proyecto general"));
        EditText name = new EditText(this);
        name.setHint("Nombre del punto");
        name.setSingleLine(true);
        name.setText(nextPointName());
        EditText description = new EditText(this);
        description.setHint("Descripción opcional");
        form.addView(project);
        form.addView(name);
        form.addView(description);

        Button photo = new Button(this);
        photo.setText("Agregar foto");
        photo.setOnClickListener(v -> choosePointPhoto());
        form.addView(photo);
        photoStatusView = NativeUi.text(this, "Sin foto adjunta", 11.5f, false, NativeUi.SUB);
        form.addView(photoStatusView);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Guardar punto")
                .setMessage("Se guardarán coordenadas, UTM, precisión, proveedor, hora y la foto si la adjuntas.")
                .setView(form)
                .setPositiveButton("Guardar", null)
                .setNegativeButton("Cancelar", null)
                .create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(b -> {
            String p = project.getText().toString().trim();
            if (p.isEmpty()) p = "Proyecto general";
            String n = name.getText().toString().trim();
            if (n.isEmpty()) n = nextPointName();
            getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit().putString("current_project", p).apply();
            persistPoint(p, n, description.getText().toString().trim(), loc);
            pendingPhotoUri = "";
            photoStatusView = null;
            dialog.dismiss();
        }));
        dialog.show();
    }

    private void choosePointPhoto() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, REQ_PHOTO);
    }

    private Location freshLocationForSave() {
        if (currentLocation != null && System.currentTimeMillis() - currentLocation.getTime() <= FRESH_SAVE_LOCATION_MS)
            return new Location(currentLocation);
        LastPosition p = readLastPosition();
        if (!p.valid || System.currentTimeMillis() - p.timestamp > FRESH_SAVE_LOCATION_MS) return null;
        Location loc = new Location(p.provider == null || p.provider.isEmpty() ? "guardada" : p.provider);
        loc.setLatitude(p.latitude);
        loc.setLongitude(p.longitude);
        loc.setAccuracy((float) p.accuracy);
        if (!Float.isNaN(p.altitudeM)) loc.setAltitude(p.altitudeM);
        loc.setTime(p.timestamp);
        return loc;
    }

    private void persistPoint(String project, String name, String description, Location location) {
        try {
            String existing = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]");
            JSONArray array = new JSONArray(existing == null ? "[]" : existing);
            JSONObject o = new JSONObject();
            o.put("project", project);
            o.put("name", name);
            o.put("description", description == null ? "" : description);
            o.put("latitude", location.getLatitude());
            o.put("longitude", location.getLongitude());
            if (location.hasAltitude()) o.put("altitude", location.getAltitude()); else o.put("altitude", JSONObject.NULL);
            if (location.hasAccuracy()) o.put("accuracy", location.getAccuracy()); else o.put("accuracy", JSONObject.NULL);
            if (location.hasSpeed()) o.put("speedKmh", location.getSpeed() * 3.6); else o.put("speedKmh", JSONObject.NULL);
            if (location.hasBearing()) o.put("bearing", location.getBearing()); else o.put("bearing", JSONObject.NULL);
            o.put("timestamp", location.getTime() > 0 ? location.getTime() : System.currentTimeMillis());
            o.put("provider", location.getProvider() == null ? "" : location.getProvider());
            o.put("photoUri", pendingPhotoUri == null ? "" : pendingPhotoUri);
            array.put(o);
            getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit().putString(KEY_POINTS, array.toString()).apply();
            Toast.makeText(this, "Punto " + name + " guardado.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo guardar el punto.", Toast.LENGTH_LONG).show();
        }
    }

    private String nextPointName() {
        String json = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]");
        try {
            JSONArray a = new JSONArray(json == null ? "[]" : json);
            int n = 1;
            while (true) {
                String candidate = "P" + n;
                boolean exists = false;
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.optJSONObject(i);
                    if (o != null && candidate.equalsIgnoreCase(o.optString("name", ""))) { exists = true; break; }
                }
                if (!exists) return candidate;
                n++;
            }
        } catch (Exception ignored) { return "P1"; }
    }

    private void showPointsPanel() {
        List<PointRow> points = readRecentPoints(200);
        if (points.isEmpty()) {
            Toast.makeText(this, "Todavía no hay puntos guardados.", Toast.LENGTH_LONG).show();
            return;
        }
        LinearLayout list = NativeUi.column(this);
        list.setPadding(NativeUi.dp(this, 10), NativeUi.dp(this, 8), NativeUi.dp(this, 10), NativeUi.dp(this, 8));
        Button allMap = new Button(this);
        allMap.setText("Ver todos en el mapa");
        list.addView(allMap);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Puntos guardados · " + points.size())
                .setNegativeButton("Cerrar", null)
                .create();
        allMap.setOnClickListener(v -> { dialog.dismiss(); openAllPointsOnMap(); });
        for (PointRow point : points) {
            TextView row = NativeUi.text(this, point.name + " · " + point.project + "\n" + point.summary + "\n" + point.time, 12.3f, false, NativeUi.TEXT);
            row.setPadding(NativeUi.dp(this, 12), NativeUi.dp(this, 10), NativeUi.dp(this, 12), NativeUi.dp(this, 10));
            row.setBackground(NativeUi.rounded(NativeUi.withAlpha(NativeUi.BG_DEEP, 100), 12, 1, NativeUi.withAlpha(NativeUi.BORDER, 80), this));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, NativeUi.dp(this, 7), 0, 0);
            list.addView(row, lp);
            row.setOnClickListener(v -> { dialog.dismiss(); openPointOnMap(point); });
            row.setOnLongClickListener(v -> { showPointActions(point, dialog); return true; });
        }
        ScrollView scroll = new ScrollView(this);
        scroll.addView(list);
        dialog.setView(scroll);
        dialog.show();
    }

    private void showPointActions(PointRow point, AlertDialog parent) {
        String[] items = {"Ver en mapa", "Compartir punto", "Eliminar punto"};
        new AlertDialog.Builder(this)
                .setTitle(point.name)
                .setItems(items, (d, which) -> {
                    if (which == 0) { parent.dismiss(); openPointOnMap(point); }
                    else if (which == 1) sharePoint(point);
                    else deletePoint(point, parent);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void sharePoint(PointRow point) {
        String text = point.name + " · " + point.project + "\n" + point.summary + "\n"
                + format6(point.latitude) + ", " + format6(point.longitude);
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(send, "Compartir punto"));
    }

    private void deletePoint(PointRow point, AlertDialog parent) {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar " + point.name + "")
                .setMessage("Esta acción no se puede deshacer.")
                .setPositiveButton("Eliminar", (d, w) -> {
                    JSONArray a = readPointArray();
                    JSONArray out = new JSONArray();
                    for (int i = 0; i < a.length(); i++) if (i != point.sourceIndex) out.put(a.opt(i));
                    getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit().putString(KEY_POINTS, out.toString()).apply();
                    parent.dismiss();
                    Toast.makeText(this, "Punto eliminado.", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void openAllPointsOnMap() {
        Intent intent = new Intent(this, MapActivity.class);
        intent.putExtra("show_saved_points", true);
        intent.putExtra("show_all_saved_points", true);
        startActivity(intent);
    }

    private void showGnssPanel() {
        LastPosition p = readLastPosition();
        CoordinateUtils.Utm utm = p.valid ? CoordinateUtils.toUtm(p.latitude, p.longitude) : null;
        SharedPreferences sp = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
        float best = sp.getFloat("last_average_best_accuracy", Float.NaN);
        float stability = sp.getFloat("last_average_stability", Float.NaN);
        float finalAcc = sp.getFloat("last_average_final_accuracy", Float.NaN);
        int valid = sp.getInt("last_average_valid", 0);
        int rejected = sp.getInt("last_average_rejected", 0);
        int maxSat = sp.getInt("last_average_max_satellites", 0);
        long duration = sp.getLong("last_average_duration_s", 0L);
        StringBuilder sb = new StringBuilder();
        sb.append("Estado: " ).append(gpsRunning ? "GPS activo" : "GPS detenido").append("\n");
        sb.append("Calidad: " ).append(qualityLabel(p)).append("\n");
        sb.append("Precisión actual: " ).append(p.valid ? "±" + format1(p.accuracy) + " m" : "Sin lectura").append("\n");
        sb.append("Satélites usados / visibles: " ).append(p.satellitesUsed).append(" / " ).append(p.satellitesVisible).append("\n");
        sb.append("Proveedor: " ).append(providerLabel(p.provider)).append("\n");
        sb.append("Velocidad: " ).append(p.speedMps >= 0 ? format1(p.speedMps * 3.6) + " km/h" : "Sin dato").append("\n");
        sb.append("Altitud: " ).append(!Float.isNaN(p.altitudeM) ? format1(p.altitudeM) + " m" : "Sin dato").append("\n");
        if (utm != null && utm.valid) sb.append("UTM: " ).append(utm.zone).append(utm.hemisphere()).append(" · " ).append(format3(utm.easting)).append(" E · " ).append(format3(utm.northing)).append(" N\n");
        sb.append("Última lectura: " ).append(p.valid ? relativeTime(p.timestamp) : "Sin lectura");
        if (duration > 0) {
            sb.append("\n\nÚltimo promedio: " ).append(duration).append(" s");
            sb.append("\nMejor precisión: " ).append(formatAverageAccuracy(best));
            sb.append("\nEstabilidad 68%: " ).append(formatAverageAccuracy(stability));
            sb.append("\nPrecisión final: " ).append(formatAverageAccuracy(finalAcc));
            sb.append("\nLecturas: " ).append(valid).append(" usadas · " ).append(rejected).append(" descartadas · " ).append(maxSat).append(" sat. máx.");
        }
        new AlertDialog.Builder(this).setTitle("Datos GNSS").setMessage(sb.toString()).setPositiveButton("Cerrar", null).show();
    }

    private void showExportPanel() {
        String[] items = {"Compartir coordenada actual", "Exportar CSV", "Exportar KML", "Exportar KMZ", "Exportar GPX", "Exportar GeoJSON", "Importar KML/KMZ", "Compartir resumen del proyecto"};
        new AlertDialog.Builder(this)
                .setTitle("Archivos y exportación")
                .setItems(items, (d, which) -> {
                    if (which == 0) shareLastCoordinates();
                    else if (which >= 1 && which <= 5) beginExport(new String[]{"csv","kml","kmz","gpx","geojson"}[which - 1]);
                    else if (which == 6) beginImport();
                    else shareProjectSummary();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void beginExport(String type) {
        if (readPointArray().length() == 0) {
            Toast.makeText(this, "No hay puntos guardados para exportar.", Toast.LENGTH_LONG).show();
            return;
        }
        pendingExportType = type;
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date());
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        if ("kml".equals(type)) { intent.setType("application/vnd.google-earth.kml+xml"); intent.putExtra(Intent.EXTRA_TITLE, "GeoTopo_puntos_" + stamp + ".kml"); }
        else if ("kmz".equals(type)) { intent.setType("application/vnd.google-earth.kmz"); intent.putExtra(Intent.EXTRA_TITLE, "GeoTopo_puntos_" + stamp + ".kmz"); }
        else if ("gpx".equals(type)) { intent.setType("application/gpx+xml"); intent.putExtra(Intent.EXTRA_TITLE, "GeoTopo_puntos_" + stamp + ".gpx"); }
        else if ("geojson".equals(type)) { intent.setType("application/geo+json"); intent.putExtra(Intent.EXTRA_TITLE, "GeoTopo_puntos_" + stamp + ".geojson"); }
        else { intent.setType("text/csv"); intent.putExtra(Intent.EXTRA_TITLE, "GeoTopo_puntos_" + stamp + ".csv"); }
        startActivityForResult(intent, REQ_EXPORT);
    }

    private void beginImport() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/vnd.google-earth.kml+xml", "application/vnd.google-earth.kmz", "application/zip", "text/xml", "application/xml"});
        startActivityForResult(intent, REQ_IMPORT);
    }

    private void shareProjectSummary() {
        JSONArray a = readPointArray();
        if (a.length() == 0) { Toast.makeText(this, "No hay puntos guardados para compartir.", Toast.LENGTH_LONG).show(); return; }
        StringBuilder sb = new StringBuilder("GeoTopo · Proyecto de campo\nPuntos: " + a.length() + "\n\n");
        for (int i = 0; i < a.length(); i++) {
            JSONObject p = a.optJSONObject(i); if (p == null) continue;
            sb.append('[').append(p.optString("project", "Proyecto general")).append("] " ).append(p.optString("name", "Punto")).append("\n")
                    .append(format6(p.optDouble("latitude", 0))).append(", " ).append(format6(p.optDouble("longitude", 0)));
            if (!p.isNull("accuracy")) sb.append(" · ±" ).append(format1(p.optDouble("accuracy"))).append(" m");
            String desc = p.optString("description", ""); if (!desc.isEmpty()) sb.append("\n" ).append(desc);
            sb.append("\n\n");
        }
        Intent send = new Intent(Intent.ACTION_SEND); send.setType("text/plain"); send.putExtra(Intent.EXTRA_TEXT, sb.toString());
        startActivity(Intent.createChooser(send, "Compartir proyecto"));
    }

    private String buildGpsCsv() {
        JSONArray a = readPointArray();
        if (a.length() == 0) return "";
        StringBuilder sb = new StringBuilder("project,name,description,latitude,longitude,altitude,accuracy,timestamp,provider\n");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            sb.append(csv(o.optString("project", ""))).append(',')
                    .append(csv(o.optString("name", ""))).append(',')
                    .append(csv(o.optString("description", ""))).append(',')
                    .append(o.optDouble("latitude", 0)).append(',')
                    .append(o.optDouble("longitude", 0)).append(',')
                    .append(o.isNull("altitude") ? "" : o.optDouble("altitude")).append(',')
                    .append(o.isNull("accuracy") ? "" : o.optDouble("accuracy")).append(',')
                    .append(o.optLong("timestamp", 0)).append(',')
                    .append(csv(o.optString("provider", ""))).append('\n');
        }
        return sb.toString();
    }

    private String csv(String value) {
        String v = value == null ? "" : value.replace("\"", "\"\"");
        return "\"" + v + "\"";
    }

    private String buildGpsKml() {
        JSONArray a = readPointArray();
        if (a.length() == 0) return "";
        StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><kml xmlns=\"http://www.opengis.net/kml/2.2\"><Document>");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            sb.append("<Placemark><name>").append(xml(o.optString("name", "Punto"))).append("</name><description>")
                    .append(xml(o.optString("description", ""))).append("</description><Point><coordinates>")
                    .append(o.optDouble("longitude", 0)).append(',').append(o.optDouble("latitude", 0)).append(',')
                    .append(o.isNull("altitude") ? 0 : o.optDouble("altitude", 0)).append("</coordinates></Point></Placemark>");
        }
        return sb.append("</Document></kml>").toString();
    }

    private String xml(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    private String buildGpsGpx() {
        JSONArray a = readPointArray();
        if (a.length() == 0) return "";
        SimpleDateFormat iso = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        iso.setTimeZone(TimeZone.getTimeZone("UTC"));
        StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<gpx version=\"1.1\" creator=\"GeoTopo\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n");
        for (int i = 0; i < a.length(); i++) {
            JSONObject p = a.optJSONObject(i); if (p == null) continue;
            sb.append("<wpt lat=\"" ).append(format6(p.optDouble("latitude",0))).append("\" lon=\"" ).append(format6(p.optDouble("longitude",0))).append("\">\n");
            if (!p.isNull("altitude")) sb.append("<ele>" ).append(p.optDouble("altitude",0)).append("</ele>\n");
            sb.append("<time>" ).append(iso.format(new Date(p.optLong("timestamp", System.currentTimeMillis())))).append("</time>\n")
                    .append("<name>" ).append(xml(p.optString("name","Punto"))).append("</name>\n")
                    .append("<desc>" ).append(xml(p.optString("project","Proyecto general") + " · " + p.optString("description",""))).append("</desc>\n</wpt>\n");
        }
        return sb.append("</gpx>\n").toString();
    }

    private String buildGpsGeoJson() {
        JSONArray points = readPointArray();
        if (points.length() == 0) return "";
        try {
            JSONObject root = new JSONObject();
            root.put("type", "FeatureCollection");
            JSONArray features = new JSONArray();
            for (int i = 0; i < points.length(); i++) {
                JSONObject p = points.optJSONObject(i);
                if (p == null) continue;
                JSONObject f = new JSONObject();
                f.put("type", "Feature");
                JSONObject geometry = new JSONObject();
                geometry.put("type", "Point");
                JSONArray coordinates = new JSONArray();
                coordinates.put(p.optDouble("longitude", 0));
                coordinates.put(p.optDouble("latitude", 0));
                if (!p.isNull("altitude")) coordinates.put(p.optDouble("altitude", 0));
                geometry.put("coordinates", coordinates);
                f.put("geometry", geometry);
                JSONObject properties = new JSONObject();
                properties.put("project", p.optString("project", ""));
                properties.put("name", p.optString("name", ""));
                properties.put("description", p.optString("description", ""));
                if (!p.isNull("accuracy")) properties.put("accuracy", p.optDouble("accuracy"));
                properties.put("timestamp", p.optLong("timestamp", 0));
                f.put("properties", properties);
                features.put(f);
            }
            root.put("features", features);
            return root.toString(2);
        } catch (Exception e) {
            return "";
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_PHOTO) {
            try {
                int flags = data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;
                getContentResolver().takePersistableUriPermission(uri, flags);
            } catch (Exception ignored) { }
            pendingPhotoUri = uri.toString();
            if (photoStatusView != null) photoStatusView.setText("Foto adjunta correctamente");
            return;
        }
        if (requestCode == REQ_IMPORT) { importKmlOrKmz(uri); return; }
        if (requestCode != REQ_EXPORT) return;
        try (OutputStream output = getContentResolver().openOutputStream(uri, "w")) {
            if (output == null) throw new IOException("No se pudo abrir el destino");
            if ("kmz".equals(pendingExportType)) {
                try (ZipOutputStream zip = new ZipOutputStream(output)) {
                    zip.putNextEntry(new ZipEntry("doc.kml"));
                    zip.write(buildGpsKml().getBytes(StandardCharsets.UTF_8));
                    zip.closeEntry();
                }
            } else {
                String text = "kml".equals(pendingExportType) ? buildGpsKml()
                        : ("gpx".equals(pendingExportType) ? buildGpsGpx()
                        : ("geojson".equals(pendingExportType) ? buildGpsGeoJson() : buildGpsCsv()));
                try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(output, StandardCharsets.UTF_8))) {
                    writer.write(text);
                }
            }
            Toast.makeText(this, "Archivo exportado correctamente.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo exportar: " + safeMessage(e), Toast.LENGTH_LONG).show();
        }
    }

    private void importKmlOrKmz(Uri uri) {
        try (InputStream raw = getContentResolver().openInputStream(uri)) {
            if (raw == null) throw new IOException("No se pudo abrir el archivo");
            BufferedInputStream input = new BufferedInputStream(raw);
            input.mark(4);
            int b1 = input.read(), b2 = input.read();
            input.reset();
            String kml = (b1 == 'P' && b2 == 'K') ? readKmlFromKmz(input)
                    : new String(readAllBytes(input, 20 * 1024 * 1024), StandardCharsets.UTF_8);
            List<JSONObject> imported = parseKmlPoints(kml);
            if (imported.isEmpty()) { Toast.makeText(this, "El archivo no contiene puntos KML compatibles.", Toast.LENGTH_LONG).show(); return; }
            JSONArray array = readPointArray();
            for (JSONObject o : imported) array.put(o);
            getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit().putString(KEY_POINTS, array.toString()).apply();
            Toast.makeText(this, "Importados " + imported.size() + " puntos.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo importar: " + safeMessage(e), Toast.LENGTH_LONG).show();
        }
    }

    private String readKmlFromKmz(InputStream input) throws IOException {
        try (ZipInputStream zip = new ZipInputStream(input)) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                if (!entry.isDirectory() && entry.getName().toLowerCase(Locale.US).endsWith(".kml"))
                    return new String(readAllBytes(zip, 20 * 1024 * 1024), StandardCharsets.UTF_8);
            }
        }
        throw new IOException("El KMZ no contiene KML");
    }

    private byte[] readAllBytes(InputStream input, int maxBytes) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int total = 0, read;
        while ((read = input.read(buffer)) != -1) {
            total += read;
            if (total > maxBytes) throw new IOException("El archivo es demasiado grande");
            output.write(buffer, 0, read);
        }
        return output.toByteArray();
    }

    private List<JSONObject> parseKmlPoints(String kml) {
        List<JSONObject> out = new ArrayList<>();
        if (kml == null) return out;
        Matcher placemarks = Pattern.compile("(?is)<Placemark\\b[^>]*>(.*?)</Placemark>").matcher(kml);
        int count = 1;
        while (placemarks.find()) {
            String block = placemarks.group(1);
            String coords = firstTagValue(block, "coordinates");
            if (coords.isEmpty()) continue;
            String[] parts = coords.trim().split("\\s+")[0].split(",");
            if (parts.length < 2) continue;
            try {
                double lon = Double.parseDouble(parts[0].trim()), lat = Double.parseDouble(parts[1].trim());
                if (lat < -90 || lat > 90 || lon < -180 || lon > 180) continue;
                JSONObject o = new JSONObject();
                o.put("project", "Importado KML/KMZ");
                String name = decodeXml(firstTagValue(block, "name"));
                o.put("name", name.isEmpty() ? "KML" + count : name);
                o.put("description", stripHtml(decodeXml(firstTagValue(block, "description"))));
                o.put("latitude", lat); o.put("longitude", lon);
                if (parts.length >= 3) { try { o.put("altitude", Double.parseDouble(parts[2].trim())); } catch (Exception e) { o.put("altitude", JSONObject.NULL); } }
                else o.put("altitude", JSONObject.NULL);
                o.put("accuracy", JSONObject.NULL); o.put("speedKmh", JSONObject.NULL); o.put("bearing", JSONObject.NULL);
                o.put("timestamp", System.currentTimeMillis()); o.put("provider", "KML/KMZ importado"); o.put("photoUri", "");
                out.add(o); count++;
            } catch (Exception ignored) { }
        }
        return out;
    }

    private String firstTagValue(String block, String tag) {
        Matcher m = Pattern.compile("(?is)<" + Pattern.quote(tag) + "\\b[^>]*>(.*?)</" + Pattern.quote(tag) + ">").matcher(block);
        return m.find() ? m.group(1).trim() : "";
    }

    private String decodeXml(String value) {
        return value == null ? "" : value.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
                .replace("&apos;", "'").replace("&amp;", "&");
    }

    private String stripHtml(String value) {
        return value == null ? "" : value.replaceAll("(?is)<[^>]+>", " ").replaceAll("\\s+", " ").trim();
    }

    private String safeMessage(Exception e) {
        String m = e == null ? "" : e.getMessage();
        return m == null || m.trim().isEmpty() ? "error desconocido" : m;
    }

    private JSONArray readPointArray() {
        String json = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]");
        try { return new JSONArray(json == null ? "[]" : json); }
        catch (Exception ignored) { return new JSONArray(); }
    }

    private void openPointOnMap(PointRow point) {
        Intent intent = new Intent(this, MapActivity.class);
        intent.putExtra("show_saved_points", true);
        intent.putExtra("saved_points_project", point.project == null ? "" : point.project);
        intent.putExtra("selected_saved_point_name", point.name == null ? "" : point.name);
        intent.putExtra("selected_saved_point_lat", point.latitude);
        intent.putExtra("selected_saved_point_lon", point.longitude);
        startActivity(intent);
    }

    private void openFullMap() {
        Intent intent = new Intent(this, MapActivity.class);
        if (overviewMap != null && overviewStyleInitialized) {
            CameraPosition camera = overviewMap.getCameraPosition();
            if (camera != null && camera.target != null) {
                intent.putExtra("camera_lat", camera.target.getLatitude());
                intent.putExtra("camera_lon", camera.target.getLongitude());
                intent.putExtra("camera_zoom", camera.zoom);
                intent.putExtra("camera_bearing", camera.bearing);
            }
        }
        Location loc = currentLocation;
        if (loc != null && System.currentTimeMillis() - loc.getTime() <= RECENT_MAP_LOCATION_MS) {
            intent.putExtra("latitude", loc.getLatitude());
            intent.putExtra("longitude", loc.getLongitude());
            intent.putExtra("location_accuracy", loc.hasAccuracy() ? loc.getAccuracy() : 0f);
            intent.putExtra("location_bearing", loc.hasBearing() ? loc.getBearing() : 0f);
        } else if (overviewPosition != null && isRecent(overviewPosition)) {
            intent.putExtra("latitude", overviewPosition.latitude);
            intent.putExtra("longitude", overviewPosition.longitude);
            intent.putExtra("location_accuracy", (float) overviewPosition.accuracy);
        }
        startActivity(intent);
    }

    private void shareLastCoordinates() {
        LastPosition p = readLastPosition();
        if (!p.valid) {
            Toast.makeText(this, "Primero obtén una lectura GPS.", Toast.LENGTH_LONG).show();
            return;
        }
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT, "Coordenadas GeoTopo\nLatitud: "
                + format6(p.latitude) + "\nLongitud: " + format6(p.longitude));
        startActivity(Intent.createChooser(share, "Compartir coordenadas"));
    }

    private LastPosition readLastPosition() {
        SharedPreferences prefs = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
        try {
            String lat = prefs.getString("last_latitude", "");
            String lon = prefs.getString("last_longitude", "");
            LastPosition p = new LastPosition();
            p.satellitesVisible = prefs.getInt("last_satellites_visible", 0);
            p.satellitesUsed = prefs.getInt("last_satellites_used", 0);
            p.speedMps = prefs.getFloat("last_speed_mps", -1f);
            p.altitudeM = prefs.getFloat("last_altitude_m", Float.NaN);
            p.provider = prefs.getString("last_provider", "");
            if (lat == null || lon == null || lat.trim().isEmpty() || lon.trim().isEmpty()) return p;
            p.latitude = Double.parseDouble(lat);
            p.longitude = Double.parseDouble(lon);
            p.accuracy = prefs.getFloat("last_accuracy", 0f);
            p.timestamp = prefs.getLong("last_location_time", 0L);
            p.valid = true;
            return p;
        } catch (Exception ignored) {
            return new LastPosition();
        }
    }

    private LastPosition fromLocation(Location location) {
        LastPosition p = new LastPosition();
        if (location == null) return p;
        p.valid = true;
        p.latitude = location.getLatitude();
        p.longitude = location.getLongitude();
        p.accuracy = location.hasAccuracy() ? location.getAccuracy() : 0f;
        p.timestamp = location.getTime() > 0 ? location.getTime() : System.currentTimeMillis();
        p.satellitesVisible = satellitesVisible;
        p.satellitesUsed = satellitesUsed;
        p.speedMps = location.hasSpeed() ? location.getSpeed() : -1f;
        p.altitudeM = location.hasAltitude() ? (float) location.getAltitude() : Float.NaN;
        p.provider = location.getProvider() == null ? "" : location.getProvider();
        return p;
    }

    private boolean isRecent(LastPosition p) {
        return p != null && p.valid && p.timestamp > 0 && System.currentTimeMillis() - p.timestamp <= RECENT_MAP_LOCATION_MS;
    }

    private List<PointRow> readRecentPoints(int limit) {
        List<PointRow> rows = new ArrayList<>();
        JSONArray array = readPointArray();
        for (int i = array.length() - 1; i >= 0 && rows.size() < limit; i--) {
            JSONObject object = array.optJSONObject(i);
            if (object == null) continue;
            PointRow row = new PointRow();
            row.sourceIndex = i;
            row.project = object.optString("project", "Proyecto general");
            row.name = object.optString("name", "Punto");
            row.description = object.optString("description", "");
            row.latitude = object.optDouble("latitude", Double.NaN);
            row.longitude = object.optDouble("longitude", Double.NaN);
            double alt = object.optDouble("altitude", Double.NaN);
            CoordinateUtils.Utm utm = CoordinateUtils.toUtm(row.latitude, row.longitude);
            if (utm.valid) {
                row.summary = "UTM " + utm.zone + utm.hemisphere() + " · "
                        + format3(utm.easting) + " E · " + format3(utm.northing) + " N"
                        + (Double.isNaN(alt) ? "" : " · " + format1(alt) + " m");
            } else {
                row.summary = format6(row.latitude) + ", " + format6(row.longitude);
            }
            row.time = relativeTime(object.optLong("timestamp", System.currentTimeMillis()));
            rows.add(row);
        }
        return rows;
    }

    private String qualityLabel(LastPosition p) {
        if (!p.valid) return "Sin lectura";
        if (p.accuracy <= 2.0) return "Excelente";
        if (p.accuracy <= 5.0) return "Buena";
        if (p.accuracy <= 10.0) return "Aceptable";
        if (p.accuracy <= 25.0) return "Media";
        return "Débil";
    }

    private int qualityColor(LastPosition p) {
        if (!p.valid) return NativeUi.SUB;
        if (p.accuracy <= 5.0) return Color.rgb(51, 220, 145);
        if (p.accuracy <= 15.0) return Color.rgb(255, 193, 74);
        return Color.rgb(255, 103, 116);
    }

    private String providerLabel(String provider) {
        if (provider == null || provider.trim().isEmpty()) return "Sin lectura";
        if ("gps".equalsIgnoreCase(provider)) return "GPS / GNSS";
        if ("network".equalsIgnoreCase(provider)) return "Red";
        if (provider.startsWith("promedio")) return "Promedio GNSS";
        return provider;
    }

    private String format3(double value) { return String.format(Locale.US, "%,.3f", value).replace(',', ' '); }
    private String format6(double value) { return String.format(Locale.US, "%.6f", value); }
    private String format1(double value) { return String.format(Locale.US, "%.1f", value); }
    private String formatTime(long timestamp) {
        if (timestamp <= 0) return "sin hora";
        return new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date(timestamp));
    }
    private String relativeTime(long timestamp) {
        if (timestamp <= 0) return "Sin lectura";
        long diff = Math.max(0, System.currentTimeMillis() - timestamp);
        String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(timestamp));
        if (diff < 60000L) return "Ahora";
        if (diff < 60L * 60000L) return "Hace " + Math.max(1, diff / 60000L) + " min";
        if (diff < 24L * 60L * 60L * 1000L) return "Hoy, " + time;
        if (diff < 48L * 60L * 60L * 1000L) return "Ayer, " + time;
        return new SimpleDateFormat("dd/MM, HH:mm", Locale.getDefault()).format(new Date(timestamp));
    }

    private static final class LastPosition {
        boolean valid;
        double latitude;
        double longitude;
        double accuracy;
        long timestamp;
        int satellitesVisible;
        int satellitesUsed;
        float speedMps = -1f;
        float altitudeM = Float.NaN;
        String provider = "";
    }

    private static final class PointRow {
        int sourceIndex;
        String project;
        String name;
        String description;
        String summary;
        String time;
        double latitude;
        double longitude;
    }
}
