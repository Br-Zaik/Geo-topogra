package com.bph.geotopo;

import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ProfileActivity extends BaseToolActivity {
    private static final int REQ_EXPORT_PROFILE = 9530;
    private static final int REQ_EXPORT_SECTION = 9531;

    private static final int PROFILE_MODE_SLOPE = 0;
    private static final int PROFILE_MODE_START_END = 1;
    private static final int PROFILE_MODE_DISABLED = 2;

    private int profileMode = PROFILE_MODE_SLOPE;

    private final List<ProfileRow> profileRows = new ArrayList<>();
    private LinearLayout profileContainer;
    private EditText profileSlopeInput;
    private EditText profileStartDesignInput;
    private EditText profileEndDesignInput;
    private Button profileModeSlopeButton;
    private Button profileModeStartEndButton;
    private Button profileModeManualButton;
    private LinearLayout profileSlopePanel;
    private LinearLayout profileStartEndPanel;
    private Button profileExportButton;
    private View profileChartBox;
    private MetricCard profileMetricSlope;
    private MetricCard profileMetricCut;
    private MetricCard profileMetricFill;
    private LongitudinalChartView profileChartView;
    private TextView profileResult;
    private String profileCsv;
    private final List<ProfileSample> lastProfileSamples = new ArrayList<>();

    private final List<SectionRow> sectionRows = new ArrayList<>();
    private LinearLayout sectionContainer;
    private EditText sectionProgressiveInput;
    private MetricCard sectionMetricCut;
    private MetricCard sectionMetricFill;
    private MetricCard sectionMetricCross;
    private MetricCard sectionMetricWidth;
    private TextView sectionStatusOffsets;
    private TextView sectionStatusData;
    private SectionChartView sectionChartView;
    private View sectionChartBox;
    private Button sectionExportButton;
    private TextView sectionResult;
    private String sectionCsv;
    private final List<SectionSample> lastSectionSamples = new ArrayList<>();
    private double currentSectionCutArea;
    private double currentSectionFillArea;
    private Double currentSectionCrossOffset;
    private double currentSectionWidth;

    private View volumeCardView;
    private EditText volumePrevCutInput;
    private EditText volumePrevFillInput;
    private EditText volumeDistanceInput;
    private MetricCard volumeMetricCut;
    private MetricCard volumeMetricFill;
    private MetricCard volumeMetricBalance;
    private TextView volumeResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();

        LinearLayout root = page("Perfiles y secciones", "Progresivas, cotas, pendientes y corte/relleno aproximado");
        LinearLayout content = vertical();
        content.addView(collapsibleCard(profileBlock(), "⌁", "Perfil longitudinal", true));
        content.addView(collapsibleCard(sectionBlock(), "⊥", "Sección transversal", true));
        volumeCardView = collapsibleCard(volumeBlock(), "⬒", "Volúmenes y resumen", false);
        volumeCardView.setVisibility(View.GONE);
        content.addView(volumeCardView);
        root.addView(scrollWith(content), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private LinearLayout profileBlock() {
        LinearLayout box = vertical();
        box.addView(small("Perfil simple: progresivas, cotas del terreno y rasante manual o automática."));

        box.addView(sectionTitle("Modo de rasante"));
        LinearLayout modeRow = horizontal();
        profileModeManualButton = flatToggleButton("Manual");
        profileModeSlopeButton = flatToggleButton("Pendiente");
        profileModeStartEndButton = flatToggleButton("Cota inicial-final");
        profileModeManualButton.setOnClickListener(v -> { profileMode = PROFILE_MODE_DISABLED; updateProfileModeUi(); });
        profileModeSlopeButton.setOnClickListener(v -> { profileMode = PROFILE_MODE_SLOPE; updateProfileModeUi(); });
        profileModeStartEndButton.setOnClickListener(v -> { profileMode = PROFILE_MODE_START_END; updateProfileModeUi(); });
        modeRow.addView(profileModeManualButton, weight());
        modeRow.addView(profileModeSlopeButton, weight());
        modeRow.addView(profileModeStartEndButton, weight());
        box.addView(modeRow);

        profileSlopePanel = vertical();
        profileSlopeInput = numberInput("2.50");
        profileSlopePanel.addView(labeled("Pendiente (%) · usa negativo si baja", profileSlopeInput));
        box.addView(profileSlopePanel);

        profileStartEndPanel = vertical();
        LinearLayout designEnds = horizontal();
        profileStartDesignInput = numberInput("100.000");
        profileEndDesignInput = numberInput("102.500");
        designEnds.addView(labeled("Cota inicial", profileStartDesignInput), weight());
        designEnds.addView(labeled("Cota final", profileEndDesignInput), weight());
        profileStartEndPanel.addView(designEnds);
        box.addView(profileStartEndPanel);
        updateProfileModeUi();

        box.addView(sectionTitle("Puntos del perfil"));
        profileContainer = vertical();
        box.addView(profileContainer);
        for (int i = 0; i < 5; i++) addProfileRow();

        LinearLayout actions = horizontal();
        Button add = secondaryButton("+ Punto");
        add.setOnClickListener(v -> addProfileRow());
        Button clear = dangerButton("🗑 Limpiar");
        clear.setOnClickListener(v -> clearProfile());
        actions.addView(add, weight());
        actions.addView(clear, weight());
        box.addView(actions);

        LinearLayout calcRow = horizontal();
        Button calc = primaryButton("Calcular perfil");
        calc.setOnClickListener(v -> calculateProfile());
        profileExportButton = secondaryButton("Exportar perfil CSV");
        profileExportButton.setOnClickListener(v -> exportProfile());
        profileExportButton.setVisibility(View.GONE);
        calcRow.addView(calc, weight());
        calcRow.addView(profileExportButton, weight());
        box.addView(calcRow);

        box.addView(sectionTitle("Vista previa del perfil"));
        profileChartView = new LongitudinalChartView();
        profileChartBox = chartBox(profileChartView);
        profileChartBox.setVisibility(View.GONE);
        box.addView(profileChartBox);

        LinearLayout metrics = horizontal();
        profileMetricSlope = metricCard("Pendiente promedio", "—", "Aún sin cálculo", Color.rgb(46, 204, 113));
        profileMetricCut = metricCard("Corte total", "—", "Aprox. en perfil", Color.rgb(255, 167, 38));
        profileMetricFill = metricCard("Relleno total", "—", "Aprox. en perfil", accent);
        metrics.addView(profileMetricSlope.box, weight());
        metrics.addView(profileMetricCut.box, weight());
        metrics.addView(profileMetricFill.box, weight());
        box.addView(metrics);

        profileResult = resultBox("Perfil pendiente.");
        box.addView(profileResult);
        return box;
    }

    private LinearLayout sectionBlock() {
        LinearLayout box = vertical();
        box.addView(small("Sección simple: progresiva, offsets, terreno y proyecto. Los offsets se ordenan solos al calcular."));

        sectionProgressiveInput = numberInput("0+100.000");
        box.addView(labeled("Progresiva de la sección (m)", sectionProgressiveInput));

        box.addView(sectionTitle("Offsets de izquierda a derecha"));
        sectionContainer = vertical();
        box.addView(sectionContainer);
        for (int i = 0; i < 5; i++) addSectionRow();

        LinearLayout actions = horizontal();
        Button add = secondaryButton("+ Punto");
        add.setOnClickListener(v -> addSectionRow());
        Button clear = dangerButton("🗑 Limpiar");
        clear.setOnClickListener(v -> clearSection());
        actions.addView(add, weight());
        actions.addView(clear, weight());
        box.addView(actions);

        LinearLayout calcRow = horizontal();
        Button calc = primaryButton("Calcular sección");
        calc.setOnClickListener(v -> calculateSection());
        sectionExportButton = secondaryButton("Exportar sección CSV");
        sectionExportButton.setOnClickListener(v -> exportSection());
        sectionExportButton.setVisibility(View.GONE);
        calcRow.addView(calc, weight());
        calcRow.addView(sectionExportButton, weight());
        box.addView(calcRow);

        LinearLayout sectionMetrics = horizontal();
        sectionMetricCut = metricCard("Área corte", "—", "m²", Color.rgb(239, 83, 80));
        sectionMetricFill = metricCard("Área relleno", "—", "m²", Color.rgb(76, 175, 80));
        sectionMetricCross = metricCard("Punto de cruce", "—", "Offset", Color.rgb(255, 214, 10));
        sectionMetricWidth = metricCard("Ancho total", "—", "m", accent);
        sectionMetrics.addView(sectionMetricCut.box, weight());
        sectionMetrics.addView(sectionMetricFill.box, weight());
        sectionMetrics.addView(sectionMetricCross.box, weight());
        sectionMetrics.addView(sectionMetricWidth.box, weight());
        box.addView(sectionMetrics);

        LinearLayout chipRow = horizontal();
        sectionStatusOffsets = statusChip("Offsets pendientes", false);
        sectionStatusData = statusChip("Datos pendientes", false);
        chipRow.addView(sectionStatusOffsets, weight());
        chipRow.addView(sectionStatusData, weight());
        box.addView(chipRow);

        box.addView(sectionTitle("Vista de sección"));
        sectionChartView = new SectionChartView();
        sectionChartBox = chartBox(sectionChartView);
        sectionChartBox.setVisibility(View.GONE);
        box.addView(sectionChartBox);

        sectionResult = resultBox("Sección pendiente.");
        box.addView(sectionResult);
        return box;
    }

    private LinearLayout volumeBlock() {
        LinearLayout box = vertical();
        box.addView(small("Volumen opcional entre la sección actual y otra sección por áreas medias."));

        LinearLayout row1 = horizontal();
        volumePrevCutInput = numberInput("0.000");
        volumePrevFillInput = numberInput("0.000");
        row1.addView(labeled("Área corte de la otra sección (m²)", volumePrevCutInput), weight());
        row1.addView(labeled("Área relleno de la otra sección (m²)", volumePrevFillInput), weight());
        box.addView(row1);

        volumeDistanceInput = numberInput("20.000");
        box.addView(labeled("Distancia entre secciones (m)", volumeDistanceInput));

        Button calcVolume = primaryButton("Calcular volúmenes");
        calcVolume.setOnClickListener(v -> calculateVolumes());
        box.addView(calcVolume);

        LinearLayout metrics = horizontal();
        volumeMetricCut = metricCard("Vol. corte", "—", "m³", Color.rgb(255, 167, 38));
        volumeMetricFill = metricCard("Vol. relleno", "—", "m³", Color.rgb(76, 175, 80));
        volumeMetricBalance = metricCard("Balance", "—", "Relleno - corte", accent);
        metrics.addView(volumeMetricCut.box, weight());
        metrics.addView(volumeMetricFill.box, weight());
        metrics.addView(volumeMetricBalance.box, weight());
        box.addView(metrics);

        volumeResult = resultBox("Esperando cálculo de volúmenes.");
        box.addView(volumeResult);
        return box;
    }

    private void updateProfileModeUi() {
        styleModeButton(profileModeManualButton, profileMode == PROFILE_MODE_DISABLED);
        styleModeButton(profileModeSlopeButton, profileMode == PROFILE_MODE_SLOPE);
        styleModeButton(profileModeStartEndButton, profileMode == PROFILE_MODE_START_END);
        profileSlopePanel.setVisibility(profileMode == PROFILE_MODE_SLOPE ? View.VISIBLE : View.GONE);
        profileStartEndPanel.setVisibility(profileMode == PROFILE_MODE_START_END ? View.VISIBLE : View.GONE);
    }

    private void addProfileRow() {
        int i = profileRows.size() + 1;
        LinearLayout row = horizontal();
        TextView idx = text(String.valueOf(i), 13, true);
        idx.setGravity(Gravity.CENTER);
        row.addView(idx, new LinearLayout.LayoutParams(dp(30), dp(52)));
        EditText chainage = numberInput(i == 1 ? "0.000" : "");
        EditText ground = numberInput("100.000");
        EditText design = numberInput(profileMode == PROFILE_MODE_DISABLED ? "Opcional" : "Rasante");
        row.addView(labeled("Progresiva (m)", chainage), weight());
        row.addView(labeled("Terreno (m)", ground), weight());
        row.addView(labeled("Rasante (m)", design), weight());
        ProfileRow profileRow = new ProfileRow(row, idx, chainage, ground, design);
        Button delete = miniDangerButton("✕");
        delete.setOnClickListener(v -> removeProfileRow(profileRow));
        row.addView(delete, new LinearLayout.LayoutParams(dp(40), dp(50)));
        profileRows.add(profileRow);
        profileContainer.addView(row);
    }

    private void removeProfileRow(ProfileRow row) {
        if (profileRows.size() <= 2) {
            showToast("Conserva al menos dos puntos.");
            return;
        }
        profileRows.remove(row);
        profileContainer.removeView(row.container);
        refreshProfileIndexes();
    }

    private void refreshProfileIndexes() {
        for (int i = 0; i < profileRows.size(); i++) {
            profileRows.get(i).index.setText(String.valueOf(i + 1));
        }
    }

    private void clearProfile() {
        for (ProfileRow r : profileRows) {
            r.chainage.setText("");
            r.ground.setText("");
            r.design.setText("");
        }
        lastProfileSamples.clear();
        profileChartView.setSamples(lastProfileSamples);
        if (profileChartBox != null) profileChartBox.setVisibility(View.GONE);
        profileMetricSlope.set("—", "Aún sin cálculo");
        profileMetricCut.set("—", "Aprox. en perfil");
        profileMetricFill.set("—", "Aprox. en perfil");
        profileResult.setText("Perfil pendiente.");
        profileCsv = null;
        if (profileExportButton != null) profileExportButton.setVisibility(View.GONE);
    }

    private void validateProfileOnly() {
        try {
            buildProfilePoints(true);
            showToast("Perfil válido: progresivas crecientes y datos completos.");
        } catch (Exception e) {
            showToast("Revisa el perfil antes de calcular.");
        }
    }

    private void generateDesignIntoInputs() {
        try {
            List<ProfileSample> samples = buildProfilePoints(true);
            if (samples.size() < 2) return;
            for (int i = 0; i < samples.size() && i < profileRows.size(); i++) {
                ProfileSample s = samples.get(i);
                profileRows.get(i).design.setText(s.design == null ? "" : f3(s.design));
            }
            showToast("Rasante generada en la tabla.");
        } catch (Exception e) {
            showToast("No se pudo generar la rasante. Revisa los datos.");
        }
    }

    private List<ProfileSample> buildProfilePoints(boolean includeAutoDesign) {
        List<ProfileSample> points = new ArrayList<>();
        for (ProfileRow r : profileRows) {
            if (blank(r.chainage) && blank(r.ground) && blank(r.design)) continue;
            if (blank(r.chainage) || blank(r.ground)) throw new IllegalArgumentException();
            Double design = blank(r.design) ? null : parse(r.design);
            points.add(new ProfileSample(parse(r.chainage), parse(r.ground), design));
        }
        if (points.size() < 2) throw new IllegalArgumentException();
        for (int i = 1; i < points.size(); i++) {
            if (points.get(i).chainage <= points.get(i - 1).chainage) throw new IllegalArgumentException();
        }
        if (!includeAutoDesign || profileMode == PROFILE_MODE_DISABLED) return points;

        double startPk = points.get(0).chainage;
        double endPk = points.get(points.size() - 1).chainage;
        double span = endPk - startPk;
        if (span <= 0) throw new IllegalArgumentException();

        if (profileMode == PROFILE_MODE_SLOPE) {
            double slope = parse(profileSlopeInput);
            double startDesign = points.get(0).design != null ? points.get(0).design : points.get(0).ground;
            for (ProfileSample sample : points) {
                sample.design = startDesign + slope / 100.0 * (sample.chainage - startPk);
            }
        } else if (profileMode == PROFILE_MODE_START_END) {
            double startDesign = blank(profileStartDesignInput)
                    ? (points.get(0).design != null ? points.get(0).design : points.get(0).ground)
                    : parse(profileStartDesignInput);
            double endDesign = blank(profileEndDesignInput)
                    ? (points.get(points.size() - 1).design != null ? points.get(points.size() - 1).design : points.get(points.size() - 1).ground)
                    : parse(profileEndDesignInput);
            for (ProfileSample sample : points) {
                double t = (sample.chainage - startPk) / span;
                sample.design = startDesign + t * (endDesign - startDesign);
            }
        }
        return points;
    }

    private void calculateProfile() {
        try {
            List<ProfileSample> points = buildProfilePoints(true);
            lastProfileSamples.clear();
            lastProfileSamples.addAll(points);
            profileChartView.setSamples(lastProfileSamples);
            if (profileChartBox != null) profileChartBox.setVisibility(View.VISIBLE);

            double min = points.get(0).ground;
            double max = points.get(0).ground;
            double totalCut = 0.0;
            double totalFill = 0.0;
            double totalLength = points.get(points.size() - 1).chainage - points.get(0).chainage;
            double avgSlope = totalLength <= 0 ? 0.0 : (points.get(points.size() - 1).ground - points.get(0).ground) / totalLength * 100.0;

            StringBuilder report = new StringBuilder("PUNTOS DEL PERFIL:");
            StringBuilder csv = new StringBuilder("progresiva,cota_terreno,cota_rasante,pendiente_terreno_pct,pendiente_rasante_pct,diferencia,tipo\n");

            for (int i = 0; i < points.size(); i++) {
                ProfileSample p = points.get(i);
                min = Math.min(min, p.ground);
                max = Math.max(max, p.ground);
                Double groundSlope = null;
                Double designSlope = null;
                if (i > 0) {
                    ProfileSample prev = points.get(i - 1);
                    double dx = p.chainage - prev.chainage;
                    groundSlope = (p.ground - prev.ground) / dx * 100.0;
                    if (p.design != null && prev.design != null) {
                        designSlope = (p.design - prev.design) / dx * 100.0;
                        integrateProfileCutFill(prev, p);
                    }
                }
                if (p.design != null) {
                    double delta = p.ground - p.design;
                    if (delta >= 0) totalCut += 0; else totalFill += 0;
                }
                String type;
                double diff = 0.0;
                if (p.design == null) {
                    type = "Sin rasante";
                } else {
                    diff = p.ground - p.design;
                    type = diff > 0 ? "Corte" : (diff < 0 ? "Relleno" : "Coincide");
                }
                report.append("\nPK ").append(f3(p.chainage))
                        .append(" · terreno ").append(f3(p.ground));
                if (p.design != null) report.append(" · rasante ").append(f3(p.design)).append(" · Δ ").append(signed(diff)).append(" m · ").append(type);
                if (groundSlope != null) report.append(" · pend. terreno ").append(signed(groundSlope)).append(" %");
                csv.append(f3(p.chainage)).append(',').append(f3(p.ground)).append(',')
                        .append(p.design == null ? "" : f3(p.design)).append(',')
                        .append(groundSlope == null ? "" : f3(groundSlope)).append(',')
                        .append(designSlope == null ? "" : f3(designSlope)).append(',')
                        .append(p.design == null ? "" : f3(diff)).append(',')
                        .append(type).append('\n');
            }

            double[] profileAreas = calculateProfileAreas(points);
            totalCut = profileAreas[0];
            totalFill = profileAreas[1];

            report.append("\n\nLongitud: ").append(f3(totalLength)).append(" m")
                    .append("\nCota mínima: ").append(f3(min)).append(" · máxima: ").append(f3(max)).append(" · rango: ").append(f3(max - min)).append(" m")
                    .append("\nPendiente promedio del terreno: ").append(signed(avgSlope)).append(" %")
                    .append("\nCorte longitudinal aprox.: ").append(f3(totalCut)).append(" m²")
                    .append("\nRelleno longitudinal aprox.: ").append(f3(totalFill)).append(" m²");

            profileMetricSlope.set(signed(avgSlope) + " %", avgSlope >= 0 ? "Ascendente" : "Descendente");
            profileMetricCut.set(f3(totalCut) + " m²", "Aprox. en perfil");
            profileMetricFill.set(f3(totalFill) + " m²", "Aprox. en perfil");
            profileResult.setText(report.toString());
            profileCsv = csv.toString();
            if (profileExportButton != null) profileExportButton.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            lastProfileSamples.clear();
            profileChartView.setSamples(lastProfileSamples);
            if (profileChartBox != null) profileChartBox.setVisibility(View.VISIBLE);
            profileMetricSlope.set("—", "Aún sin cálculo");
            profileMetricCut.set("—", "Aprox. en perfil");
            profileMetricFill.set("—", "Aprox. en perfil");
            profileResult.setText("Revisa el perfil: se necesitan dos o más progresivas crecientes con cota de terreno y una rasante válida si deseas comparar corte/relleno.");
            profileCsv = null;
            if (profileExportButton != null) profileExportButton.setVisibility(View.GONE);
        }
    }

    private void integrateProfileCutFill(ProfileSample a, ProfileSample b) {
        // Método conservado solo como punto de extensión; las áreas se calculan en calculateProfileAreas.
    }

    private double[] calculateProfileAreas(List<ProfileSample> points) {
        double cut = 0.0;
        double fill = 0.0;
        for (int i = 0; i < points.size() - 1; i++) {
            ProfileSample a = points.get(i);
            ProfileSample b = points.get(i + 1);
            if (a.design == null || b.design == null) continue;
            double w = b.chainage - a.chainage;
            double da = a.ground - a.design;
            double db = b.ground - b.design;
            if (da >= 0 && db >= 0) cut += w * (da + db) / 2.0;
            else if (da <= 0 && db <= 0) fill += w * (-da - db) / 2.0;
            else {
                double frac = Math.abs(da) / (Math.abs(da) + Math.abs(db));
                double w1 = w * frac;
                double w2 = w - w1;
                if (da > 0) {
                    cut += w1 * da / 2.0;
                    fill += w2 * (-db) / 2.0;
                } else {
                    fill += w1 * (-da) / 2.0;
                    cut += w2 * db / 2.0;
                }
            }
        }
        return new double[]{cut, fill};
    }

    private void addSectionRow() {
        int i = sectionRows.size() + 1;
        LinearLayout row = horizontal();
        TextView idx = text(String.valueOf(i), 13, true);
        idx.setGravity(Gravity.CENTER);
        row.addView(idx, new LinearLayout.LayoutParams(dp(30), dp(52)));
        EditText offset = numberInput("");
        EditText ground = numberInput("100.000");
        EditText design = numberInput("100.000");
        row.addView(labeled("Offset (m)", offset), weight());
        row.addView(labeled("Terreno (m)", ground), weight());
        row.addView(labeled("Proyecto (m)", design), weight());
        SectionRow sectionRow = new SectionRow(row, idx, offset, ground, design);
        Button delete = miniDangerButton("✕");
        delete.setOnClickListener(v -> removeSectionRow(sectionRow));
        row.addView(delete, new LinearLayout.LayoutParams(dp(40), dp(50)));
        sectionRows.add(sectionRow);
        sectionContainer.addView(row);
    }

    private void removeSectionRow(SectionRow row) {
        if (sectionRows.size() <= 2) {
            showToast("Conserva al menos dos puntos.");
            return;
        }
        sectionRows.remove(row);
        sectionContainer.removeView(row.container);
        refreshSectionIndexes();
    }

    private void refreshSectionIndexes() {
        for (int i = 0; i < sectionRows.size(); i++) {
            sectionRows.get(i).index.setText(String.valueOf(i + 1));
        }
    }

    private void sortSectionRows() {
        try {
            List<SectionSample> values = buildSectionPoints(false);
            Collections.sort(values, Comparator.comparingDouble(o -> o.offset));
            for (int i = 0; i < values.size() && i < sectionRows.size(); i++) {
                SectionSample v = values.get(i);
                sectionRows.get(i).offset.setText(f3(v.offset));
                sectionRows.get(i).ground.setText(f3(v.ground));
                sectionRows.get(i).design.setText(f3(v.design));
            }
            showToast("Offsets ordenados.");
        } catch (Exception e) {
            showToast("No se pudieron ordenar los offsets.");
        }
    }

    private void clearSection() {
        for (SectionRow r : sectionRows) {
            r.offset.setText("");
            r.ground.setText("");
            r.design.setText("");
        }
        sectionProgressiveInput.setText("");
        lastSectionSamples.clear();
        sectionChartView.setSamples(lastSectionSamples, null);
        if (sectionChartBox != null) sectionChartBox.setVisibility(View.GONE);
        sectionMetricCut.set("—", "m²");
        sectionMetricFill.set("—", "m²");
        sectionMetricCross.set("—", "Offset");
        sectionMetricWidth.set("—", "m");
        updateStatusChip(sectionStatusOffsets, "Offsets pendientes", false);
        updateStatusChip(sectionStatusData, "Datos pendientes", false);
        sectionResult.setText("Sección pendiente.");
        sectionCsv = null;
        if (sectionExportButton != null) sectionExportButton.setVisibility(View.GONE);
        if (volumeCardView != null) volumeCardView.setVisibility(View.GONE);
        currentSectionCutArea = 0.0;
        currentSectionFillArea = 0.0;
        currentSectionCrossOffset = null;
        currentSectionWidth = 0.0;
    }

    private List<SectionSample> buildSectionPoints(boolean requireSorted) {
        List<SectionSample> values = new ArrayList<>();
        for (SectionRow r : sectionRows) {
            if (blank(r.offset) && blank(r.ground) && blank(r.design)) continue;
            if (blank(r.offset) || blank(r.ground) || blank(r.design)) throw new IllegalArgumentException();
            values.add(new SectionSample(parse(r.offset), parse(r.ground), parse(r.design)));
        }
        if (values.size() < 2) throw new IllegalArgumentException();
        if (requireSorted) {
            for (int i = 1; i < values.size(); i++) {
                if (values.get(i).offset <= values.get(i - 1).offset) throw new IllegalArgumentException();
            }
        }
        return values;
    }

    private void calculateSection() {
        try {
            List<SectionSample> points = buildSectionPoints(false);
            Collections.sort(points, Comparator.comparingDouble(o -> o.offset));
            for (int i = 1; i < points.size(); i++) {
                if (points.get(i).offset <= points.get(i - 1).offset) throw new IllegalArgumentException();
            }
            syncSectionRows(points);
            lastSectionSamples.clear();
            lastSectionSamples.addAll(points);

            double cutArea = 0.0;
            double fillArea = 0.0;
            Double firstCrossOffset = null;
            StringBuilder csv = new StringBuilder("progresiva,offset,cota_terreno,cota_proyecto,diferencia,tipo\n");
            StringBuilder report = new StringBuilder("PUNTOS DE LA SECCIÓN:");
            String progressiveText = sectionProgressiveInput.getText().toString().trim();
            double width = points.get(points.size() - 1).offset - points.get(0).offset;

            for (int i = 0; i < points.size(); i++) {
                SectionSample q = points.get(i);
                double d = q.ground - q.design;
                String type = d > 0 ? "Corte" : (d < 0 ? "Relleno" : "Coincide");
                report.append("\nOffset ").append(signed(q.offset)).append(" m · Δ ").append(signed(d)).append(" m · ").append(type);
                csv.append(progressiveText).append(',').append(f3(q.offset)).append(',').append(f3(q.ground)).append(',').append(f3(q.design)).append(',').append(f3(d)).append(',').append(type).append('\n');
                if (i == 0) continue;
                SectionSample a = points.get(i - 1);
                SectionSample b = points.get(i);
                double w = b.offset - a.offset;
                double da = a.ground - a.design;
                double db = b.ground - b.design;
                if (da >= 0 && db >= 0) {
                    cutArea += w * (da + db) / 2.0;
                } else if (da <= 0 && db <= 0) {
                    fillArea += w * (-da - db) / 2.0;
                } else {
                    double frac = Math.abs(da) / (Math.abs(da) + Math.abs(db));
                    double cross = a.offset + frac * (b.offset - a.offset);
                    if (firstCrossOffset == null) firstCrossOffset = cross;
                    double w1 = w * frac;
                    double w2 = w - w1;
                    if (da > 0) {
                        cutArea += w1 * da / 2.0;
                        fillArea += w2 * (-db) / 2.0;
                    } else {
                        fillArea += w1 * (-da) / 2.0;
                        cutArea += w2 * db / 2.0;
                    }
                }
            }

            currentSectionCutArea = cutArea;
            currentSectionFillArea = fillArea;
            currentSectionCrossOffset = firstCrossOffset;
            currentSectionWidth = width;
            sectionMetricCut.set(f3(cutArea) + " m²", "Área de corte");
            sectionMetricFill.set(f3(fillArea) + " m²", "Área de relleno");
            sectionMetricCross.set(firstCrossOffset == null ? "Sin cruce" : f3(firstCrossOffset) + " m", "Offset");
            sectionMetricWidth.set(f3(width) + " m", "Ancho total");
            updateStatusChip(sectionStatusOffsets, "Offsets ordenados", true);
            updateStatusChip(sectionStatusData, "Datos válidos", true);
            sectionChartView.setSamples(lastSectionSamples, firstCrossOffset);
            if (sectionChartBox != null) sectionChartBox.setVisibility(View.VISIBLE);

            report.append("\n\nProgresiva: ").append(progressiveText.isEmpty() ? "—" : progressiveText)
                    .append("\nÁrea de corte aproximada: ").append(f3(cutArea)).append(" m²")
                    .append("\nÁrea de relleno aproximada: ").append(f3(fillArea)).append(" m²")
                    .append("\nPunto de cruce: ").append(firstCrossOffset == null ? "Sin cruce" : (f3(firstCrossOffset) + " m"))
                    .append("\nAncho total: ").append(f3(width)).append(" m");
            sectionResult.setText(report.toString());
            sectionCsv = csv.toString();
            if (sectionExportButton != null) sectionExportButton.setVisibility(View.VISIBLE);
            if (volumeCardView != null) volumeCardView.setVisibility(View.VISIBLE);

            if (!blank(volumeDistanceInput)) {
                calculateVolumes();
            }
        } catch (Exception e) {
            lastSectionSamples.clear();
            sectionChartView.setSamples(lastSectionSamples, null);
            if (sectionChartBox != null) sectionChartBox.setVisibility(View.GONE);
            sectionMetricCut.set("—", "m²");
            sectionMetricFill.set("—", "m²");
            sectionMetricCross.set("—", "Offset");
            sectionMetricWidth.set("—", "m");
            updateStatusChip(sectionStatusOffsets, "Offsets pendientes", false);
            updateStatusChip(sectionStatusData, "Datos inválidos", false);
            sectionResult.setText("Revisa la sección: completa las filas y evita offsets repetidos. La app los ordena automáticamente al calcular.");
            sectionCsv = null;
            if (sectionExportButton != null) sectionExportButton.setVisibility(View.GONE);
            if (volumeCardView != null) volumeCardView.setVisibility(View.GONE);
            currentSectionCutArea = 0.0;
            currentSectionFillArea = 0.0;
            currentSectionCrossOffset = null;
            currentSectionWidth = 0.0;
        }
    }

    private void syncSectionRows(List<SectionSample> values) {
        for (int i = 0; i < values.size() && i < sectionRows.size(); i++) {
            SectionSample v = values.get(i);
            sectionRows.get(i).offset.setText(f3(v.offset));
            sectionRows.get(i).ground.setText(f3(v.ground));
            sectionRows.get(i).design.setText(f3(v.design));
        }
    }

    private void calculateVolumes() {
        try {
            if (sectionCsv == null) {
                calculateSection();
                if (sectionCsv == null) return;
            }
            double prevCut = blank(volumePrevCutInput) ? 0.0 : parse(volumePrevCutInput);
            double prevFill = blank(volumePrevFillInput) ? 0.0 : parse(volumePrevFillInput);
            double distance = parse(volumeDistanceInput);
            if (distance <= 0) throw new IllegalArgumentException();

            double cutVolume = distance * (prevCut + currentSectionCutArea) / 2.0;
            double fillVolume = distance * (prevFill + currentSectionFillArea) / 2.0;
            double balance = fillVolume - cutVolume;

            volumeMetricCut.set(f3(cutVolume) + " m³", "Promedio de áreas");
            volumeMetricFill.set(f3(fillVolume) + " m³", "Promedio de áreas");
            volumeMetricBalance.set(signed(balance) + " m³", balance >= 0 ? "Exceso de relleno" : "Exceso de corte");

            StringBuilder text = new StringBuilder();
            text.append("Sección actual → corte ").append(f3(currentSectionCutArea)).append(" m² · relleno ").append(f3(currentSectionFillArea)).append(" m²")
                    .append("\nOtra sección → corte ").append(f3(prevCut)).append(" m² · relleno ").append(f3(prevFill)).append(" m²")
                    .append("\nDistancia entre secciones: ").append(f3(distance)).append(" m")
                    .append("\nVolumen de corte aprox.: ").append(f3(cutVolume)).append(" m³")
                    .append("\nVolumen de relleno aprox.: ").append(f3(fillVolume)).append(" m³")
                    .append("\nBalance (relleno - corte): ").append(signed(balance)).append(" m³");
            volumeResult.setText(text.toString());
        } catch (Exception e) {
            volumeMetricCut.set("—", "m³");
            volumeMetricFill.set("—", "m³");
            volumeMetricBalance.set("—", "Relleno - corte");
            volumeResult.setText("Primero calcula una sección válida y luego completa las áreas de la otra sección y la distancia entre ambas.");
        }
    }

    private void exportProfile() {
        if (profileCsv == null) calculateProfile();
        if (profileCsv != null) createFile(REQ_EXPORT_PROFILE, "GeoTopo_Perfil_");
    }

    private void exportSection() {
        if (sectionCsv == null) calculateSection();
        if (sectionCsv != null) createFile(REQ_EXPORT_SECTION, "GeoTopo_Seccion_");
    }

    private void createFile(int req, String prefix) {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/csv");
        i.putExtra(Intent.EXTRA_TITLE, prefix + new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date()) + ".csv");
        startActivityForResult(i, req);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        String content = requestCode == REQ_EXPORT_PROFILE ? profileCsv : (requestCode == REQ_EXPORT_SECTION ? sectionCsv : null);
        if (content != null && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try {
                ContentResolver resolver = getContentResolver();
                Uri uri = data.getData();
                OutputStream out = resolver.openOutputStream(uri);
                if (out == null) throw new IllegalStateException();
                out.write(content.getBytes(StandardCharsets.UTF_8));
                out.close();
                showToast("Archivo exportado.");
            } catch (Exception e) {
                showToast("No se pudo exportar.");
            }
        }
    }

    private LinearLayout infoPanel(String title, String text) {
        LinearLayout box = vertical();
        box.setPadding(dp(11), dp(10), dp(11), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == 0 ? Color.rgb(244, 248, 255) : Color.rgb(14, 33, 50));
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), withAlpha(borderColor, 150));
        box.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(2), 0, dp(8));
        box.setLayoutParams(lp);

        TextView t1 = text(title, 14, true);
        box.addView(t1);
        TextView t2 = text(text, 13, false);
        t2.setTextColor(subTextColor);
        t2.setLineSpacing(0, 1.12f);
        box.addView(t2);
        return box;
    }

    private Button flatToggleButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        ResponsiveUi.configureCompactText(button, 12, 9, 2);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        lp.setMargins(dp(3), dp(2), dp(3), dp(4));
        button.setLayoutParams(lp);
        return button;
    }

    private void styleModeButton(Button button, boolean selected) {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), selected ? accent : withAlpha(borderColor, 160));
        bg.setColor(selected ? withAlpha(accent, 80) : inputColor);
        button.setBackground(bg);
        button.setTextColor(selected ? Color.WHITE : textColor);
    }

    private Button dangerButton(String label) {
        Button button = secondaryButton(label);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == 0 ? Color.rgb(255, 245, 245) : Color.rgb(46, 20, 24));
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Color.rgb(239, 83, 80));
        button.setBackground(bg);
        button.setTextColor(themeMode == 0 ? Color.rgb(198, 40, 40) : Color.rgb(255, 138, 128));
        return button;
    }

    private Button miniDangerButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextColor(themeMode == 0 ? Color.rgb(198, 40, 40) : Color.rgb(255, 138, 128));
        ResponsiveUi.configureCompactText(button, 14, 10, 2);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == 0 ? Color.rgb(255, 245, 245) : Color.rgb(46, 20, 24));
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Color.rgb(239, 83, 80));
        button.setBackground(bg);
        return button;
    }

    private View chartBox(View chart) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == 0 ? Color.rgb(248, 251, 255) : Color.rgb(8, 26, 41));
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), withAlpha(borderColor, 160));
        chart.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(240));
        lp.setMargins(0, dp(4), 0, dp(8));
        chart.setLayoutParams(lp);
        return chart;
    }

    private MetricCard metricCard(String title, String value, String subtitle, int tintColor) {
        LinearLayout box = vertical();
        box.setPadding(dp(10), dp(10), dp(10), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == 0 ? Color.WHITE : Color.rgb(10, 29, 45));
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), withAlpha(tintColor, 210));
        box.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), dp(2), dp(3), dp(6));
        box.setLayoutParams(lp);

        TextView tTitle = text(title, 12, true);
        tTitle.setTextColor(withAlpha(tintColor, 235));
        TextView tValue = text(value, 18, true);
        tValue.setTextColor(textColor);
        TextView tSubtitle = text(subtitle, 11, false);
        tSubtitle.setTextColor(subTextColor);
        box.addView(tTitle);
        box.addView(tValue);
        box.addView(tSubtitle);
        return new MetricCard(box, tValue, tSubtitle);
    }

    private TextView statusChip(String label, boolean ok) {
        TextView view = text(label, 12, true);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(10), dp(9), dp(10), dp(9));
        updateStatusChip(view, label, ok);
        return view;
    }

    private void updateStatusChip(TextView view, String label, boolean ok) {
        view.setText(label);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(18));
        int color = ok ? Color.rgb(0, 184, 105) : Color.rgb(255, 167, 38);
        bg.setColor(ok ? withAlpha(color, 50) : withAlpha(color, 45));
        bg.setStroke(dp(1), withAlpha(color, 190));
        view.setBackground(bg);
        view.setTextColor(ok ? Color.rgb(170, 240, 205) : Color.rgb(255, 219, 156));
    }

    private static class MetricCard {
        final LinearLayout box;
        final TextView value;
        final TextView subtitle;

        MetricCard(LinearLayout box, TextView value, TextView subtitle) {
            this.box = box;
            this.value = value;
            this.subtitle = subtitle;
        }

        void set(String valueText, String subtitleText) {
            value.setText(valueText);
            subtitle.setText(subtitleText);
        }
    }

    private static class ProfileRow {
        final LinearLayout container;
        final TextView index;
        final EditText chainage;
        final EditText ground;
        final EditText design;

        ProfileRow(LinearLayout container, TextView index, EditText chainage, EditText ground, EditText design) {
            this.container = container;
            this.index = index;
            this.chainage = chainage;
            this.ground = ground;
            this.design = design;
        }
    }

    private static class ProfileSample {
        final double chainage;
        final double ground;
        Double design;

        ProfileSample(double chainage, double ground, Double design) {
            this.chainage = chainage;
            this.ground = ground;
            this.design = design;
        }
    }

    private static class SectionRow {
        final LinearLayout container;
        final TextView index;
        final EditText offset;
        final EditText ground;
        final EditText design;

        SectionRow(LinearLayout container, TextView index, EditText offset, EditText ground, EditText design) {
            this.container = container;
            this.index = index;
            this.offset = offset;
            this.ground = ground;
            this.design = design;
        }
    }

    private static class SectionSample {
        final double offset;
        final double ground;
        final double design;

        SectionSample(double offset, double ground, double design) {
            this.offset = offset;
            this.ground = ground;
            this.design = design;
        }
    }

    private class LongitudinalChartView extends View {
        private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint axisPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint terrainPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint designPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pointPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint cutPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private List<ProfileSample> samples = new ArrayList<>();

        LongitudinalChartView() {
            super(ProfileActivity.this);
            gridPaint.setColor(withAlpha(borderColor, 70));
            gridPaint.setStrokeWidth(dp(1));
            axisPaint.setColor(withAlpha(textColor, 180));
            axisPaint.setStrokeWidth(dp(1.2f));
            terrainPaint.setColor(Color.rgb(113, 221, 120));
            terrainPaint.setStrokeWidth(dp(2.2f));
            terrainPaint.setStyle(Paint.Style.STROKE);
            designPaint.setColor(accent);
            designPaint.setStrokeWidth(dp(2.0f));
            designPaint.setStyle(Paint.Style.STROKE);
            textPaint.setColor(subTextColor);
            textPaint.setTextSize(dp(3.6f));
            pointPaint.setStyle(Paint.Style.FILL);
            cutPaint.setColor(Color.argb(70, 239, 83, 80));
            cutPaint.setStyle(Paint.Style.FILL);
            fillPaint.setColor(Color.argb(70, 76, 175, 80));
            fillPaint.setStyle(Paint.Style.FILL);
        }

        void setSamples(List<ProfileSample> values) {
            samples = values == null ? new ArrayList<>() : new ArrayList<>(values);
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            canvas.drawColor(themeMode == 0 ? Color.rgb(248, 251, 255) : Color.rgb(8, 26, 41));
            float left = dp(40);
            float top = dp(22);
            float right = getWidth() - dp(18);
            float bottom = getHeight() - dp(32);

            for (int i = 0; i <= 5; i++) {
                float y = top + (bottom - top) * i / 5f;
                canvas.drawLine(left, y, right, y, gridPaint);
            }
            for (int i = 0; i <= 6; i++) {
                float x = left + (right - left) * i / 6f;
                canvas.drawLine(x, top, x, bottom, gridPaint);
            }
            canvas.drawLine(left, bottom, right, bottom, axisPaint);
            canvas.drawLine(left, top, left, bottom, axisPaint);

            if (samples == null || samples.size() < 2) {
                textPaint.setColor(subTextColor);
                canvas.drawText("El perfil aparecerá después del cálculo.", left + dp(8), top + dp(28), textPaint);
                return;
            }

            double minX = samples.get(0).chainage;
            double maxX = samples.get(samples.size() - 1).chainage;
            double minY = samples.get(0).ground;
            double maxY = samples.get(0).ground;
            for (ProfileSample s : samples) {
                minY = Math.min(minY, s.ground);
                maxY = Math.max(maxY, s.ground);
                if (s.design != null) {
                    minY = Math.min(minY, s.design);
                    maxY = Math.max(maxY, s.design);
                }
            }
            double spanX = Math.max(1.0, maxX - minX);
            double spanY = Math.max(0.5, maxY - minY);
            minY -= spanY * 0.2;
            maxY += spanY * 0.2;
            spanY = maxY - minY;

            List<PointF> terrainPts = new ArrayList<>();
            List<PointF> designPts = new ArrayList<>();
            for (ProfileSample s : samples) {
                float x = left + (float) ((s.chainage - minX) / spanX) * (right - left);
                float yTerrain = bottom - (float) ((s.ground - minY) / spanY) * (bottom - top);
                terrainPts.add(new PointF(x, yTerrain));
                if (s.design != null) {
                    float yDesign = bottom - (float) ((s.design - minY) / spanY) * (bottom - top);
                    designPts.add(new PointF(x, yDesign));
                } else {
                    designPts.add(null);
                }
            }

            for (int i = 0; i < terrainPts.size() - 1; i++) {
                PointF a1 = terrainPts.get(i);
                PointF a2 = terrainPts.get(i + 1);
                PointF b1 = designPts.get(i);
                PointF b2 = designPts.get(i + 1);
                if (b1 != null && b2 != null) {
                    double d1 = samples.get(i).ground - samples.get(i).design;
                    double d2 = samples.get(i + 1).ground - samples.get(i + 1).design;
                    Path area = new Path();
                    area.moveTo(a1.x, a1.y);
                    area.lineTo(a2.x, a2.y);
                    area.lineTo(b2.x, b2.y);
                    area.lineTo(b1.x, b1.y);
                    area.close();
                    if (d1 >= 0 && d2 >= 0) canvas.drawPath(area, cutPaint);
                    else if (d1 <= 0 && d2 <= 0) canvas.drawPath(area, fillPaint);
                }
            }

            Path terrainPath = new Path();
            for (int i = 0; i < terrainPts.size(); i++) {
                PointF p = terrainPts.get(i);
                if (i == 0) terrainPath.moveTo(p.x, p.y);
                else terrainPath.lineTo(p.x, p.y);
            }
            canvas.drawPath(terrainPath, terrainPaint);

            Path designPath = new Path();
            boolean started = false;
            for (PointF p : designPts) {
                if (p == null) continue;
                if (!started) {
                    designPath.moveTo(p.x, p.y);
                    started = true;
                } else {
                    designPath.lineTo(p.x, p.y);
                }
            }
            if (started) canvas.drawPath(designPath, designPaint);

            for (PointF p : terrainPts) {
                pointPaint.setColor(Color.rgb(113, 221, 120));
                canvas.drawCircle(p.x, p.y, dp(3.3f), pointPaint);
            }
            for (PointF p : designPts) {
                if (p == null) continue;
                pointPaint.setColor(accent);
                canvas.drawCircle(p.x, p.y, dp(3.0f), pointPaint);
            }

            textPaint.setColor(subTextColor);
            for (int i = 0; i <= 4; i++) {
                double value = maxY - spanY * i / 4.0;
                float y = top + (bottom - top) * i / 4f;
                canvas.drawText(f1(value), dp(4), y + dp(4), textPaint);
            }
            for (int i = 0; i <= 5; i++) {
                double value = minX + spanX * i / 5.0;
                float x = left + (right - left) * i / 5f;
                canvas.drawText(f1(value), x - dp(8), getHeight() - dp(10), textPaint);
            }
            canvas.drawText("Terreno", left + dp(6), dp(14), textPaint);
            textPaint.setColor(accent);
            canvas.drawText("Rasante", left + dp(80), dp(14), textPaint);
        }
    }

    private class SectionChartView extends View {
        private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint axisPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint terrainPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint projectPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint cutPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint crossPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private List<SectionSample> samples = new ArrayList<>();
        private Double crossOffset;

        SectionChartView() {
            super(ProfileActivity.this);
            gridPaint.setColor(withAlpha(borderColor, 70));
            gridPaint.setStrokeWidth(dp(1));
            axisPaint.setColor(withAlpha(textColor, 180));
            axisPaint.setStrokeWidth(dp(1.2f));
            terrainPaint.setColor(Color.rgb(230, 235, 245));
            terrainPaint.setStrokeWidth(dp(2.2f));
            terrainPaint.setStyle(Paint.Style.STROKE);
            projectPaint.setColor(accent);
            projectPaint.setStrokeWidth(dp(2.0f));
            projectPaint.setStyle(Paint.Style.STROKE);
            textPaint.setColor(subTextColor);
            textPaint.setTextSize(dp(3.6f));
            cutPaint.setColor(Color.argb(85, 239, 83, 80));
            cutPaint.setStyle(Paint.Style.FILL);
            fillPaint.setColor(Color.argb(85, 76, 175, 80));
            fillPaint.setStyle(Paint.Style.FILL);
            crossPaint.setColor(Color.rgb(255, 214, 10));
            crossPaint.setStyle(Paint.Style.FILL);
        }

        void setSamples(List<SectionSample> values, Double cross) {
            samples = values == null ? new ArrayList<>() : new ArrayList<>(values);
            crossOffset = cross;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            canvas.drawColor(themeMode == 0 ? Color.rgb(248, 251, 255) : Color.rgb(8, 26, 41));
            float left = dp(40);
            float top = dp(22);
            float right = getWidth() - dp(18);
            float bottom = getHeight() - dp(32);

            for (int i = 0; i <= 5; i++) {
                float y = top + (bottom - top) * i / 5f;
                canvas.drawLine(left, y, right, y, gridPaint);
            }
            for (int i = 0; i <= 6; i++) {
                float x = left + (right - left) * i / 6f;
                canvas.drawLine(x, top, x, bottom, gridPaint);
            }
            canvas.drawLine(left, bottom, right, bottom, axisPaint);
            canvas.drawLine(left, top, left, bottom, axisPaint);

            if (samples == null || samples.size() < 2) {
                canvas.drawText("La sección aparecerá después del cálculo.", left + dp(8), top + dp(28), textPaint);
                return;
            }

            double minX = samples.get(0).offset;
            double maxX = samples.get(samples.size() - 1).offset;
            double minY = Math.min(samples.get(0).ground, samples.get(0).design);
            double maxY = Math.max(samples.get(0).ground, samples.get(0).design);
            for (SectionSample s : samples) {
                minY = Math.min(minY, Math.min(s.ground, s.design));
                maxY = Math.max(maxY, Math.max(s.ground, s.design));
            }
            double spanX = Math.max(1.0, maxX - minX);
            double spanY = Math.max(0.5, maxY - minY);
            minY -= spanY * 0.2;
            maxY += spanY * 0.2;
            spanY = maxY - minY;

            List<PointF> terrainPts = new ArrayList<>();
            List<PointF> projectPts = new ArrayList<>();
            for (SectionSample s : samples) {
                float x = left + (float) ((s.offset - minX) / spanX) * (right - left);
                terrainPts.add(new PointF(x, bottom - (float) ((s.ground - minY) / spanY) * (bottom - top)));
                projectPts.add(new PointF(x, bottom - (float) ((s.design - minY) / spanY) * (bottom - top)));
            }

            for (int i = 0; i < terrainPts.size() - 1; i++) {
                PointF a1 = terrainPts.get(i);
                PointF a2 = terrainPts.get(i + 1);
                PointF b1 = projectPts.get(i);
                PointF b2 = projectPts.get(i + 1);
                double d1 = samples.get(i).ground - samples.get(i).design;
                double d2 = samples.get(i + 1).ground - samples.get(i + 1).design;
                Path area = new Path();
                area.moveTo(a1.x, a1.y);
                area.lineTo(a2.x, a2.y);
                area.lineTo(b2.x, b2.y);
                area.lineTo(b1.x, b1.y);
                area.close();
                if (d1 >= 0 && d2 >= 0) canvas.drawPath(area, cutPaint);
                else if (d1 <= 0 && d2 <= 0) canvas.drawPath(area, fillPaint);
            }

            Path terrainPath = new Path();
            Path projectPath = new Path();
            for (int i = 0; i < terrainPts.size(); i++) {
                PointF t = terrainPts.get(i);
                PointF p = projectPts.get(i);
                if (i == 0) {
                    terrainPath.moveTo(t.x, t.y);
                    projectPath.moveTo(p.x, p.y);
                } else {
                    terrainPath.lineTo(t.x, t.y);
                    projectPath.lineTo(p.x, p.y);
                }
            }
            canvas.drawPath(terrainPath, terrainPaint);
            canvas.drawPath(projectPath, projectPaint);

            Paint pointPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            pointPaint.setStyle(Paint.Style.FILL);
            pointPaint.setColor(Color.WHITE);
            for (PointF p : terrainPts) canvas.drawCircle(p.x, p.y, dp(3.2f), pointPaint);
            pointPaint.setColor(accent);
            for (PointF p : projectPts) canvas.drawCircle(p.x, p.y, dp(3.0f), pointPaint);

            if (crossOffset != null) {
                float x = left + (float) ((crossOffset - minX) / spanX) * (right - left);
                double crossElevation = 0;
                for (int i = 0; i < samples.size() - 1; i++) {
                    if (crossOffset >= samples.get(i).offset && crossOffset <= samples.get(i + 1).offset) {
                        double frac = (crossOffset - samples.get(i).offset) / (samples.get(i + 1).offset - samples.get(i).offset);
                        crossElevation = samples.get(i).design + frac * (samples.get(i + 1).design - samples.get(i).design);
                        break;
                    }
                }
                float y = bottom - (float) ((crossElevation - minY) / spanY) * (bottom - top);
                canvas.drawCircle(x, y, dp(4), crossPaint);
            }

            textPaint.setColor(subTextColor);
            for (int i = 0; i <= 4; i++) {
                double value = maxY - spanY * i / 4.0;
                float y = top + (bottom - top) * i / 4f;
                canvas.drawText(f1(value), dp(4), y + dp(4), textPaint);
            }
            for (int i = 0; i <= 5; i++) {
                double value = minX + spanX * i / 5.0;
                float x = left + (right - left) * i / 5f;
                canvas.drawText(f1(value), x - dp(8), getHeight() - dp(10), textPaint);
            }
        }
    }
}
