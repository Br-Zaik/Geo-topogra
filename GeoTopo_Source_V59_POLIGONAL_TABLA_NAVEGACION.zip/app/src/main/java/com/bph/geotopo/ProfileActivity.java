package com.bph.geotopo;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ProfileActivity extends BaseToolActivity {
    private static final int REQ_EXPORT_PROFILE = 9530;
    private static final int REQ_EXPORT_SECTION = 9531;

    private final List<ProfileRow> profileRows = new ArrayList<>();
    private LinearLayout profileContainer;
    private TextView profileResult;
    private String profileCsv;

    private final List<SectionRow> sectionRows = new ArrayList<>();
    private LinearLayout sectionContainer;
    private TextView sectionResult;
    private String sectionCsv;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        LinearLayout root = page("Perfiles y secciones", "Progresivas, cotas, pendientes y corte/relleno aproximado");
        LinearLayout content = vertical();
        content.addView(collapsibleCard(profileBlock(), "⌁", "Perfil longitudinal", false));
        content.addView(collapsibleCard(sectionBlock(), "⊥", "Sección transversal", false));
        root.addView(scrollWith(content), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private LinearLayout profileBlock() {
        LinearLayout box = vertical();
        box.addView(small("Ingresa progresiva, cota del terreno y, si existe, cota de rasante. Se calculan pendientes entre puntos y corte/relleno."));
        profileContainer = vertical(); box.addView(profileContainer);
        for (int i = 0; i < 5; i++) addProfileRow();
        LinearLayout actions = horizontal();
        Button add = secondaryButton("+ Punto"); add.setOnClickListener(v -> addProfileRow()); actions.addView(add, weight());
        Button remove = secondaryButton("− Punto"); remove.setOnClickListener(v -> removeProfileRow()); actions.addView(remove, weight());
        Button clear = secondaryButton("Limpiar"); clear.setOnClickListener(v -> clearProfile()); actions.addView(clear, weight());
        box.addView(actions);
        Button calc = primaryButton("Calcular perfil"); calc.setOnClickListener(v -> calculateProfile()); box.addView(calc);
        Button export = secondaryButton("Exportar perfil CSV"); export.setOnClickListener(v -> exportProfile()); box.addView(export);
        profileResult = resultBox("Perfil pendiente."); box.addView(profileResult);
        return box;
    }

    private void addProfileRow() {
        int i = profileRows.size() + 1;
        LinearLayout row = horizontal();
        TextView idx = text(String.valueOf(i), 13, true); idx.setGravity(Gravity.CENTER);
        row.addView(idx, new LinearLayout.LayoutParams(dp(30), dp(52)));
        EditText chainage = numberInput("");
        EditText ground = numberInput("Cota terreno");
        EditText design = numberInput("Opcional");
        row.addView(labeled("Progresiva", chainage), weight());
        row.addView(labeled("Terreno", ground), weight());
        row.addView(labeled("Rasante", design), weight());
        profileRows.add(new ProfileRow(row, chainage, ground, design));
        profileContainer.addView(row);
    }

    private void removeProfileRow() {
        if (profileRows.size() <= 2) { showToast("Conserva al menos dos puntos."); return; }
        ProfileRow r = profileRows.remove(profileRows.size() - 1); profileContainer.removeView(r.container);
    }

    private void clearProfile() {
        for (ProfileRow r : profileRows) { r.chainage.setText(""); r.ground.setText(""); r.design.setText(""); }
        profileResult.setText("Perfil pendiente."); profileCsv = null;
    }

    private void calculateProfile() {
        try {
            List<ProfilePoint> points = new ArrayList<>();
            for (ProfileRow r : profileRows) {
                if (blank(r.chainage) && blank(r.ground) && blank(r.design)) continue;
                if (blank(r.chainage) || blank(r.ground)) throw new IllegalArgumentException();
                points.add(new ProfilePoint(parse(r.chainage), parse(r.ground), blank(r.design) ? null : parse(r.design)));
            }
            if (points.size() < 2) throw new IllegalArgumentException();
            for (int i = 1; i < points.size(); i++) if (points.get(i).chainage <= points.get(i - 1).chainage) throw new IllegalArgumentException();

            StringBuilder report = new StringBuilder("PUNTOS DEL PERFIL:");
            StringBuilder csv = new StringBuilder("progresiva,cota_terreno,cota_rasante,pendiente_terreno_pct,pendiente_rasante_pct,corte_relleno\n");
            double min = points.get(0).ground, max = min;
            for (int i = 0; i < points.size(); i++) {
                ProfilePoint p = points.get(i);
                min = Math.min(min, p.ground); max = Math.max(max, p.ground);
                Double groundSlope = null, designSlope = null;
                if (i > 0) {
                    ProfilePoint prev = points.get(i - 1);
                    double dx = p.chainage - prev.chainage;
                    groundSlope = (p.ground - prev.ground) / dx * 100.0;
                    if (p.design != null && prev.design != null) designSlope = (p.design - prev.design) / dx * 100.0;
                }
                String cutFill = p.design == null ? "—" : (p.ground > p.design ? "Corte " + f3(p.ground - p.design) + " m" : "Relleno " + f3(p.design - p.ground) + " m");
                report.append("\nPK ").append(f3(p.chainage)).append(" · terreno ").append(f3(p.ground));
                if (p.design != null) report.append(" · rasante ").append(f3(p.design)).append(" · ").append(cutFill);
                if (groundSlope != null) report.append(" · pend. terreno ").append(signed(groundSlope)).append(" %");
                csv.append(f3(p.chainage)).append(',').append(f3(p.ground)).append(',')
                        .append(p.design == null ? "" : f3(p.design)).append(',')
                        .append(groundSlope == null ? "" : f3(groundSlope)).append(',')
                        .append(designSlope == null ? "" : f3(designSlope)).append(',').append('"').append(cutFill).append('"').append('\n');
            }
            report.append("\n\nLongitud: ").append(f3(points.get(points.size() - 1).chainage - points.get(0).chainage)).append(" m")
                    .append("\nCota mínima: ").append(f3(min)).append(" · máxima: ").append(f3(max)).append(" · rango: ").append(f3(max - min)).append(" m");
            profileResult.setText(report.toString()); profileCsv = csv.toString();
        } catch (Exception e) {
            profileResult.setText("Revisa el perfil: se necesitan dos o más progresivas crecientes con cota de terreno."); profileCsv = null;
        }
    }

    private LinearLayout sectionBlock() {
        LinearLayout box = vertical();
        box.addView(small("Ingresa offsets de izquierda a derecha. Con terreno y proyecto se estima el área de corte y relleno por integración trapezoidal."));
        sectionContainer = vertical(); box.addView(sectionContainer);
        for (int i = 0; i < 5; i++) addSectionRow();
        LinearLayout actions = horizontal();
        Button add = secondaryButton("+ Punto"); add.setOnClickListener(v -> addSectionRow()); actions.addView(add, weight());
        Button remove = secondaryButton("− Punto"); remove.setOnClickListener(v -> removeSectionRow()); actions.addView(remove, weight());
        Button clear = secondaryButton("Limpiar"); clear.setOnClickListener(v -> clearSection()); actions.addView(clear, weight());
        box.addView(actions);
        Button calc = primaryButton("Calcular sección"); calc.setOnClickListener(v -> calculateSection()); box.addView(calc);
        Button export = secondaryButton("Exportar sección CSV"); export.setOnClickListener(v -> exportSection()); box.addView(export);
        sectionResult = resultBox("Sección pendiente."); box.addView(sectionResult);
        return box;
    }

    private void addSectionRow() {
        int i = sectionRows.size() + 1;
        LinearLayout row = horizontal();
        TextView idx = text(String.valueOf(i), 13, true); idx.setGravity(Gravity.CENTER);
        row.addView(idx, new LinearLayout.LayoutParams(dp(30), dp(52)));
        EditText offset = numberInput("Offset"); EditText ground = numberInput("Terreno"); EditText design = numberInput("Proyecto");
        row.addView(labeled("Offset", offset), weight()); row.addView(labeled("Terreno", ground), weight()); row.addView(labeled("Proyecto", design), weight());
        sectionRows.add(new SectionRow(row, offset, ground, design)); sectionContainer.addView(row);
    }

    private void removeSectionRow() {
        if (sectionRows.size() <= 2) { showToast("Conserva al menos dos puntos."); return; }
        SectionRow r = sectionRows.remove(sectionRows.size() - 1); sectionContainer.removeView(r.container);
    }

    private void clearSection() {
        for (SectionRow r : sectionRows) { r.offset.setText(""); r.ground.setText(""); r.design.setText(""); }
        sectionResult.setText("Sección pendiente."); sectionCsv = null;
    }

    private void calculateSection() {
        try {
            List<SectionPoint> p = new ArrayList<>();
            for (SectionRow r : sectionRows) {
                if (blank(r.offset) && blank(r.ground) && blank(r.design)) continue;
                if (blank(r.offset) || blank(r.ground) || blank(r.design)) throw new IllegalArgumentException();
                p.add(new SectionPoint(parse(r.offset), parse(r.ground), parse(r.design)));
            }
            if (p.size() < 2) throw new IllegalArgumentException();
            for (int i = 1; i < p.size(); i++) if (p.get(i).offset <= p.get(i - 1).offset) throw new IllegalArgumentException();

            double cutArea = 0, fillArea = 0;
            for (int i = 0; i < p.size() - 1; i++) {
                SectionPoint a = p.get(i), b = p.get(i + 1);
                double w = b.offset - a.offset;
                double da = a.ground - a.design;
                double db = b.ground - b.design;
                if (da >= 0 && db >= 0) cutArea += w * (da + db) / 2.0;
                else if (da <= 0 && db <= 0) fillArea += w * (-da - db) / 2.0;
                else {
                    // Split at the zero crossing to avoid mixing cut and fill.
                    double frac = Math.abs(da) / (Math.abs(da) + Math.abs(db));
                    double w1 = w * frac, w2 = w - w1;
                    if (da > 0) { cutArea += w1 * da / 2.0; fillArea += w2 * (-db) / 2.0; }
                    else { fillArea += w1 * (-da) / 2.0; cutArea += w2 * db / 2.0; }
                }
            }
            StringBuilder csv = new StringBuilder("offset,cota_terreno,cota_proyecto,diferencia,tipo\n");
            StringBuilder report = new StringBuilder("PUNTOS:");
            for (SectionPoint q : p) {
                double d = q.ground - q.design;
                String type = d > 0 ? "Corte" : (d < 0 ? "Relleno" : "Coincide");
                report.append("\nOffset ").append(signed(q.offset)).append(" m · Δ ").append(signed(d)).append(" m · ").append(type);
                csv.append(f3(q.offset)).append(',').append(f3(q.ground)).append(',').append(f3(q.design)).append(',').append(f3(d)).append(',').append(type).append('\n');
            }
            report.append("\n\nÁrea de corte aproximada: ").append(f3(cutArea)).append(" m²")
                    .append("\nÁrea de relleno aproximada: ").append(f3(fillArea)).append(" m²")
                    .append("\nAncho total: ").append(f3(p.get(p.size() - 1).offset - p.get(0).offset)).append(" m");
            sectionResult.setText(report.toString()); sectionCsv = csv.toString();
        } catch (Exception e) {
            sectionResult.setText("Revisa la sección: offsets crecientes y las tres columnas completas."); sectionCsv = null;
        }
    }

    private void exportProfile() { if (profileCsv == null) calculateProfile(); if (profileCsv != null) createFile(REQ_EXPORT_PROFILE, "GeoTopo_Perfil_"); }
    private void exportSection() { if (sectionCsv == null) calculateSection(); if (sectionCsv != null) createFile(REQ_EXPORT_SECTION, "GeoTopo_Seccion_"); }

    private void createFile(int req, String prefix) {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("text/csv");
        i.putExtra(Intent.EXTRA_TITLE, prefix + new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date()) + ".csv"); startActivityForResult(i, req);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        String content = requestCode == REQ_EXPORT_PROFILE ? profileCsv : (requestCode == REQ_EXPORT_SECTION ? sectionCsv : null);
        if (content != null && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try {
                ContentResolver resolver = getContentResolver(); Uri uri = data.getData(); OutputStream out = resolver.openOutputStream(uri);
                if (out == null) throw new IllegalStateException(); out.write(content.getBytes(StandardCharsets.UTF_8)); out.close(); showToast("Archivo exportado.");
            } catch (Exception e) { showToast("No se pudo exportar."); }
        }
    }

    private static class ProfileRow { final LinearLayout container; final EditText chainage, ground, design; ProfileRow(LinearLayout c, EditText p, EditText g, EditText d){container=c;chainage=p;ground=g;design=d;} }
    private static class ProfilePoint { final double chainage, ground; final Double design; ProfilePoint(double c,double g,Double d){chainage=c;ground=g;design=d;} }
    private static class SectionRow { final LinearLayout container; final EditText offset, ground, design; SectionRow(LinearLayout c,EditText o,EditText g,EditText d){container=c;offset=o;ground=g;design=d;} }
    private static class SectionPoint { final double offset, ground, design; SectionPoint(double o,double g,double d){offset=o;ground=g;design=d;} }
}
