package com.bph.geotopo;

import android.Manifest;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public class ExternalGnssActivity extends BaseToolActivity {
    private static final int REQ_BT = 9560;
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private BluetoothAdapter adapter;
    private BluetoothSocket socket;
    private Thread readThread;
    private volatile boolean reading;
    private TextView result;
    private Button connectButton;
    private EditText projectInput, codeInput, descriptionInput;

    private Double latitude, longitude, altitude, hdop;
    private Integer satellites, quality;
    private String lastSentence = "—";
    private String connectedDevice = "—";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        adapter = BluetoothAdapter.getDefaultAdapter();
        LinearLayout root = page("GNSS externo Bluetooth", "Lectura NMEA desde un receptor emparejado");
        LinearLayout content = vertical();
        LinearLayout box = card();
        box.addView(sectionTitle("Conexión Bluetooth clásica"));
        box.addView(small("Empareja primero el receptor desde Ajustes de Android. GeoTopo se conecta al perfil serial SPP y lee mensajes NMEA GGA/RMC."));
        box.addView(warning("No todos los receptores usan Bluetooth clásico SPP. Algunos equipos BLE o con protocolo del fabricante necesitarán una integración específica."));
        connectButton = primaryButton("Seleccionar receptor emparejado"); connectButton.setOnClickListener(v -> requestDevice()); box.addView(connectButton);
        Button disconnect = secondaryButton("Desconectar"); disconnect.setOnClickListener(v -> disconnect()); box.addView(disconnect);
        result = resultBox("Sin receptor conectado."); box.addView(result);
        content.addView(box);

        LinearLayout save = card();
        save.addView(sectionTitle("Guardar solución en libreta"));
        projectInput = textInput("Proyecto"); projectInput.setText("General");
        codeInput = textInput("Código del punto");
        descriptionInput = textInput("Descripción");
        save.addView(labeled("Proyecto", projectInput));
        LinearLayout sr = horizontal(); sr.addView(labeled("Código", codeInput), weight()); sr.addView(labeled("Descripción", descriptionInput), weight()); save.addView(sr);
        Button saveButton = primaryButton("Guardar punto GNSS externo"); saveButton.setOnClickListener(v -> savePoint()); save.addView(saveButton);
        content.addView(save);

        root.addView(scrollWith(content), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)); setContentView(root);
    }

    private void requestDevice() {
        if (adapter == null) { result.setText("Este dispositivo no tiene Bluetooth compatible."); return; }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT); return;
        }
        showDevices();
    }

    private void showDevices() {
        try {
            if (!adapter.isEnabled()) { result.setText("Activa Bluetooth y empareja el receptor desde Ajustes de Android."); return; }
            Set<BluetoothDevice> bonded = adapter.getBondedDevices();
            if (bonded == null || bonded.isEmpty()) { result.setText("No hay dispositivos Bluetooth emparejados."); return; }
            List<BluetoothDevice> devices = new ArrayList<>(bonded);
            String[] names = new String[devices.size()];
            for (int i = 0; i < devices.size(); i++) {
                BluetoothDevice d = devices.get(i);
                names[i] = safeName(d) + "\n" + d.getAddress();
            }
            new AlertDialog.Builder(this).setTitle("Selecciona el receptor GNSS")
                    .setItems(names, (dialog, which) -> connect(devices.get(which)))
                    .setNegativeButton("Cancelar", null).show();
        } catch (SecurityException e) { result.setText("No se concedió permiso de Bluetooth."); }
    }

    private String safeName(BluetoothDevice d) {
        try { String n = d.getName(); return n == null || n.trim().isEmpty() ? "Dispositivo sin nombre" : n; }
        catch (SecurityException e) { return "Dispositivo Bluetooth"; }
    }

    private void connect(BluetoothDevice device) {
        disconnect();
        connectedDevice = safeName(device);
        result.setText("Conectando con " + connectedDevice + "...");
        connectButton.setEnabled(false);
        readThread = new Thread(() -> {
            try {
                BluetoothSocket s = device.createRfcommSocketToServiceRecord(SPP);
                socket = s;
                s.connect(); reading = true;
                runOnUiThread(() -> { connectButton.setEnabled(true); render(); });
                BufferedReader reader = new BufferedReader(new InputStreamReader(s.getInputStream()));
                String line;
                while (reading && (line = reader.readLine()) != null) {
                    parseNmea(line.trim());
                }
            } catch (Exception e) {
                runOnUiThread(() -> {
                    connectButton.setEnabled(true);
                    result.setText("No se pudo conectar con " + connectedDevice + ". Verifica que el receptor use Bluetooth clásico SPP y no esté conectado a otra app.");
                });
            } finally {
                reading = false;
                closeSocket();
            }
        }, "GeoTopo-NMEA");
        readThread.start();
    }

    private void parseNmea(String line) {
        if (line == null || line.isEmpty() || !validChecksum(line)) return;
        String[] f = line.split(",", -1);
        try {
            String type = f.length == 0 ? "" : f[0];
            if (type.endsWith("GGA") && f.length >= 10) {
                if (!f[2].isEmpty() && !f[4].isEmpty()) {
                    latitude = nmeaCoordinate(f[2], f[3]);
                    longitude = nmeaCoordinate(f[4], f[5]);
                }
                quality = f[6].isEmpty() ? 0 : Integer.parseInt(f[6]);
                satellites = f[7].isEmpty() ? null : Integer.parseInt(f[7]);
                hdop = f[8].isEmpty() ? null : Double.parseDouble(f[8]);
                altitude = f[9].isEmpty() ? null : Double.parseDouble(f[9]);
                lastSentence = "GGA";
            } else if (type.endsWith("RMC") && f.length >= 7) {
                if ("A".equals(f[2]) && !f[3].isEmpty() && !f[5].isEmpty()) {
                    latitude = nmeaCoordinate(f[3], f[4]);
                    longitude = nmeaCoordinate(f[5], f[6]);
                }
                lastSentence = "RMC";
            }
        } catch (Exception ignored) {}
        runOnUiThread(this::render);
    }

    private boolean validChecksum(String line) {
        if (!line.startsWith("$") || !line.contains("*")) return true;
        int star = line.indexOf('*');
        if (star <= 1 || star + 2 >= line.length()) return false;
        int checksum = 0;
        for (int i = 1; i < star; i++) checksum ^= line.charAt(i);
        try { return checksum == Integer.parseInt(line.substring(star + 1, star + 3), 16); }
        catch (Exception e) { return false; }
    }

    private double nmeaCoordinate(String raw, String hemisphere) {
        double value = Double.parseDouble(raw);
        double degrees = Math.floor(value / 100.0);
        double minutes = value - degrees * 100.0;
        double decimal = degrees + minutes / 60.0;
        if ("S".equalsIgnoreCase(hemisphere) || "W".equalsIgnoreCase(hemisphere)) decimal = -decimal;
        return decimal;
    }

    private void render() {
        result.setText("Receptor: " + connectedDevice
                + "\nEstado: " + (reading ? "CONECTADO / LEYENDO NMEA" : "DESCONECTADO")
                + "\nLatitud: " + value7(latitude) + "\nLongitud: " + value7(longitude)
                + "\nAltitud: " + (altitude == null ? "—" : f3(altitude) + " m")
                + "\nSolución: " + fixName(quality == null ? 0 : quality)
                + "\nSatélites: " + (satellites == null ? "—" : satellites)
                + " · HDOP: " + (hdop == null ? "—" : f2(hdop))
                + "\nÚltimo mensaje válido: " + lastSentence);
    }

    private String value7(Double d) { return d == null ? "—" : f7(d); }
    private String fixName(int q) {
        switch (q) { case 1: return "Autónomo"; case 2: return "DGPS"; case 4: return "RTK fijo"; case 5: return "RTK flotante"; case 6: return "Estimado"; default: return "Sin solución"; }
    }

    private void savePoint() {
        if (latitude == null || longitude == null || quality == null || quality == 0) { showToast("Todavía no existe una solución GNSS válida."); return; }
        String project = projectInput.getText().toString().trim(); if (project.isEmpty()) project = "General";
        String code = codeInput.getText().toString().trim(); if (code.isEmpty()) { showToast("Escribe un código para el punto."); return; }
        String description = descriptionInput.getText().toString().trim();
        String accuracy = hdop == null ? "" : "HDOP " + f2(hdop) + " · " + fixName(quality);
        NotebookStore.add(this, new NotebookStore.Entry(project, code, f7(latitude), f7(longitude),
                altitude == null ? "" : f3(altitude), "WGS84 geográficas", description, accuracy, "GNSS Bluetooth",
                new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())));
        codeInput.setText(""); descriptionInput.setText(""); showToast("Punto guardado en la libreta de campo.");
    }

    private void disconnect() {
        reading = false; closeSocket(); connectedDevice = "—";
        if (result != null) result.setText("Sin receptor conectado.");
        if (connectButton != null) connectButton.setEnabled(true);
    }

    private void closeSocket() {
        BluetoothSocket s = socket; socket = null;
        if (s != null) try { s.close(); } catch (Exception ignored) {}
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) showDevices();
        else if (requestCode == REQ_BT) result.setText("Sin permiso de Bluetooth no se puede conectar al receptor.");
    }

    @Override protected void onDestroy() { super.onDestroy(); disconnect(); }
}
