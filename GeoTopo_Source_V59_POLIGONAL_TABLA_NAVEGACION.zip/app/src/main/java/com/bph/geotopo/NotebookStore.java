package com.bph.geotopo;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Local-only storage for GeoTopo field notebook entries. */
public final class NotebookStore {
    public static final String PREFS = "geo_topo_prefs";
    public static final String KEY_V2 = "field_notebook_entries_v2";
    private static final String KEY_V1 = "field_notebook_entries_v1";

    private NotebookStore() {}

    public static List<Entry> load(Context context) {
        SharedPreferences sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = sp.getString(KEY_V2, null);
        if (raw == null) raw = migrateV1(sp);
        List<Entry> entries = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(raw == null ? "[]" : raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.optJSONObject(i);
                if (o == null) continue;
                entries.add(new Entry(
                        o.optString("project"), o.optString("code"), o.optString("north"),
                        o.optString("east"), o.optString("elevation"), o.optString("crs"), o.optString("description"),
                        o.optString("accuracy"), o.optString("source"), o.optString("time")
                ));
            }
        } catch (Exception ignored) {}
        return entries;
    }

    private static String migrateV1(SharedPreferences sp) {
        String old = sp.getString(KEY_V1, "[]");
        JSONArray migrated = new JSONArray();
        try {
            JSONArray array = new JSONArray(old);
            for (int i = 0; i < array.length(); i++) {
                JSONObject in = array.optJSONObject(i); if (in == null) continue;
                JSONObject out = new JSONObject();
                out.put("project", "General");
                out.put("code", in.optString("code"));
                out.put("north", in.optString("north"));
                out.put("east", in.optString("east"));
                out.put("elevation", in.optString("elevation"));
                out.put("crs", "No indicado");
                out.put("description", in.optString("description"));
                out.put("accuracy", "");
                out.put("source", "Migrado");
                out.put("time", in.optString("time"));
                migrated.put(out);
            }
        } catch (Exception ignored) {}
        String raw = migrated.toString();
        sp.edit().putString(KEY_V2, raw).apply();
        return raw;
    }

    public static void save(Context context, List<Entry> entries) {
        JSONArray array = new JSONArray();
        try {
            for (Entry e : entries) {
                JSONObject o = new JSONObject();
                o.put("project", e.project);
                o.put("code", e.code);
                o.put("north", e.north);
                o.put("east", e.east);
                o.put("elevation", e.elevation);
                o.put("crs", e.crs);
                o.put("description", e.description);
                o.put("accuracy", e.accuracy);
                o.put("source", e.source);
                o.put("time", e.time);
                array.put(o);
            }
        } catch (Exception ignored) {}
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_V2, array.toString()).apply();
    }

    public static void add(Context context, Entry entry) {
        List<Entry> entries = load(context);
        entries.add(entry);
        save(context, entries);
    }

    public static final class Entry {
        public final String project;
        public final String code;
        public final String north;
        public final String east;
        public final String elevation;
        public final String crs;
        public final String description;
        public final String accuracy;
        public final String source;
        public final String time;

        public Entry(String project, String code, String north, String east, String elevation, String crs,
                     String description, String accuracy, String source, String time) {
            this.project = safe(project);
            this.code = safe(code);
            this.north = safe(north);
            this.east = safe(east);
            this.elevation = safe(elevation);
            this.crs = safe(crs).isEmpty() ? "No indicado" : safe(crs);
            this.description = safe(description);
            this.accuracy = safe(accuracy);
            this.source = safe(source);
            this.time = safe(time);
        }

        private static String safe(String value) { return value == null ? "" : value; }
    }
}
