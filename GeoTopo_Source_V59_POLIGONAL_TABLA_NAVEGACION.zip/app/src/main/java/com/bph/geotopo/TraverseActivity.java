package com.bph.geotopo;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TraverseActivity extends BaseToolActivity {
    private static final int REQ_EXPORT = 9510;
    private EditText startN, startE, knownEndN, knownEndE;
    private CheckBox closedCheck;
    private final List<LegRow> rows = new ArrayList<>();
    private LinearLayout rowsContainer;
    private TextView result;
    private String lastCsv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        LinearLayout root = page("Poligonales", "Abierta o cerrada con compensación Bowditch");
        LinearLayout content = vertical();
        LinearLayout box = card();
        box.addView(sectionTitle("Configuración"));
        box.addView(small("Ingresa cada tramo con azimut y distancia horizontal. En modo cerrado, el punto final esperado normalmente coincide con el inicial; también puedes indicar otro punto de cierre conocido."));

        LinearLayout r0 = horizontal();
        startN = numberInput("N inicial"); startE = numberInput("E inicial");
        startN.setText("0.000"); startE.setText("0.000");
        r0.addView(labeled("N inicial", startN), weight()); r0.addView(labeled("E inicial", startE), weight()); box.addView(r0);

        closedCheck = new CheckBox(this);
        closedCheck.setText("Poligonal cerrada / con punto final conocido");
        closedCheck.setTextColor(textColor);
        closedCheck.setChecked(true);
        box.addView(closedCheck);

        LinearLayout rend = horizontal();
        knownEndN = numberInput("Vacío = N inicial"); knownEndE = numberInput("Vacío = E inicial");
        rend.addView(labeled("N final esperado", knownEndN), weight()); rend.addView(labeled("E final esperado", knownEndE), weight()); box.addView(rend);

        box.addView(sectionTitle("Tramos"));
        rowsContainer = vertical(); box.addView(rowsContainer);
        for (int i = 0; i < 4; i++) addRow();

        LinearLayout actions = horizontal();
        Button add = secondaryButton("+ Tramo"); add.setOnClickListener(v -> addRow()); actions.addView(add, weight());
        Button remove = secondaryButton("− Tramo"); remove.setOnClickListener(v -> removeRow()); actions.addView(remove, weight());
        Button clear = secondaryButton("Limpiar"); clear.setOnClickListener(v -> clear()); actions.addView(clear, weight());
        box.addView(actions);

        Button calc = primaryButton("Calcular poligonal"); calc.setOnClickListener(v -> calculate()); box.addView(calc);
        Button export = secondaryButton("Exportar tabla CSV"); export.setOnClickListener(v -> export()); box.addView(export);
        result = resultBox("Cálculo pendiente."); box.addView(result);
        content.addView(box);
        root.addView(scrollWith(content), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private void addRow() {
        int index = rows.size() + 1;
        LinearLayout row = horizontal();
        TextView number = text("T" + index, 13, true); number.setGravity(Gravity.CENTER);
        row.addView(number, new LinearLayout.LayoutParams(dp(38), dp(52)));
        EditText station = textInput("P" + index + "-P" + (index + 1));
        EditText az = numberInput("Azimut");
        EditText dist = numberInput("Distancia");
        row.addView(labeled("Tramo", station), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.1f));
        row.addView(labeled("Azimut °", az), weight());
        row.addView(labeled("Dist. m", dist), weight());
        rows.add(new LegRow(row, station, az, dist));
        rowsContainer.addView(row);
    }

    private void removeRow() {
        if (rows.size() <= 2) { showToast("Conserva al menos dos tramos."); return; }
        LegRow r = rows.remove(rows.size() - 1); rowsContainer.removeView(r.container);
    }

    private void clear() {
        for (LegRow r : rows) { r.name.setText(""); r.azimuth.setText(""); r.distance.setText(""); }
        result.setText("Cálculo pendiente."); lastCsv = null;
    }

    private void calculate() {
        try {
            double n0 = parse(startN), e0 = parse(startE);
            List<Leg> legs = new ArrayList<>();
            double sumN = 0, sumE = 0, perimeter = 0;
            for (int i = 0; i < rows.size(); i++) {
                LegRow row = rows.get(i);
                if (blank(row.azimuth) && blank(row.distance)) continue;
                if (blank(row.azimuth) || blank(row.distance)) throw new IllegalArgumentException();
                double az = normalizeBearing(parse(row.azimuth));
                double d = parse(row.distance);
                if (d <= 0) throw new IllegalArgumentException();
                double dn = d * Math.cos(Math.toRadians(az));
                double de = d * Math.sin(Math.toRadians(az));
                String name = row.name.getText().toString().trim();
                if (name.isEmpty()) name = "T" + (i + 1);
                legs.add(new Leg(name, az, d, dn, de));
                sumN += dn; sumE += de; perimeter += d;
            }
            if (legs.size() < 2) throw new IllegalArgumentException();

            boolean close = closedCheck.isChecked();
            double expectedN = close ? (blank(knownEndN) ? n0 : parse(knownEndN)) : n0 + sumN;
            double expectedE = close ? (blank(knownEndE) ? e0 : parse(knownEndE)) : e0 + sumE;
            double rawEndN = n0 + sumN, rawEndE = e0 + sumE;
            double fN = rawEndN - expectedN;
            double fE = rawEndE - expectedE;
            double linearError = Math.hypot(fN, fE);
            double precision = linearError > 0 ? perimeter / linearError : Double.POSITIVE_INFINITY;

            StringBuilder report = new StringBuilder();
            report.append(close ? "POLIGONAL CERRADA / ENLAZADA" : "POLIGONAL ABIERTA").append('\n');
            report.append("Longitud total: ").append(f3(perimeter)).append(" m\n");
            report.append("Final sin ajustar: N ").append(f3(rawEndN)).append(" · E ").append(f3(rawEndE)).append('\n');
            if (close) {
                report.append("Cierre ΔN: ").append(signed(fN)).append(" m · ΔE: ").append(signed(fE)).append(" m\n");
                report.append("Error lineal: ").append(f3(linearError)).append(" m\n");
                report.append("Precisión relativa: ").append(Double.isInfinite(precision) ? "sin error" : "1:" + Math.round(precision)).append('\n');
            }

            StringBuilder csv = new StringBuilder("tramo,azimut,distancia,dN,dE,corrN,corrE,dN_ajustada,dE_ajustada,N,E\n");
            double n = n0, e = e0;
            report.append("\nCOORDENADAS ").append(close ? "AJUSTADAS (BOWDITCH)" : "CALCULADAS").append(':');
            for (int i = 0; i < legs.size(); i++) {
                Leg leg = legs.get(i);
                double cN = close ? -fN * (leg.distance / perimeter) : 0;
                double cE = close ? -fE * (leg.distance / perimeter) : 0;
                double adn = leg.dn + cN, ade = leg.de + cE;
                n += adn; e += ade;
                report.append("\n").append(i + 1).append(". ").append(leg.name)
                        .append(" → N ").append(f3(n)).append(" · E ").append(f3(e))
                        .append(" · corr(").append(signed(cN)).append(", ").append(signed(cE)).append(')');
                csv.append(csvCell(leg.name)).append(',').append(f4(leg.azimuth)).append(',').append(f3(leg.distance)).append(',')
                        .append(f3(leg.dn)).append(',').append(f3(leg.de)).append(',').append(f3(cN)).append(',').append(f3(cE)).append(',')
                        .append(f3(adn)).append(',').append(f3(ade)).append(',').append(f3(n)).append(',').append(f3(e)).append('\n');
            }
            if (close) report.append("\nFinal esperado: N ").append(f3(expectedN)).append(" · E ").append(f3(expectedE));
            result.setText(report.toString());
            lastCsv = csv.toString();
        } catch (Exception e) {
            result.setText("Revisa la configuración y los tramos. Cada fila usada necesita azimut y distancia positiva.");
            lastCsv = null;
        }
    }

    private String csvCell(String v) { return '"' + v.replace("\"", "\"\"") + '"'; }

    private void export() {
        if (lastCsv == null) calculate();
        if (lastCsv == null) return;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("text/csv");
        intent.putExtra(Intent.EXTRA_TITLE, "GeoTopo_Poligonal_" + new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date()) + ".csv");
        startActivityForResult(intent, REQ_EXPORT);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_EXPORT && resultCode == RESULT_OK && data != null && data.getData() != null && lastCsv != null) {
            try {
                ContentResolver resolver = getContentResolver(); Uri uri = data.getData();
                OutputStream out = resolver.openOutputStream(uri); if (out == null) throw new IllegalStateException();
                out.write(lastCsv.getBytes(StandardCharsets.UTF_8)); out.close(); showToast("Poligonal exportada.");
            } catch (Exception e) { showToast("No se pudo exportar."); }
        }
    }

    private static class LegRow {
        final LinearLayout container; final EditText name, azimuth, distance;
        LegRow(LinearLayout c, EditText n, EditText a, EditText d) { container = c; name = n; azimuth = a; distance = d; }
    }
    private static class Leg {
        final String name; final double azimuth, distance, dn, de;
        Leg(String n, double a, double d, double dn, double de) { name = n; azimuth = a; distance = d; this.dn = dn; this.de = de; }
    }
}
