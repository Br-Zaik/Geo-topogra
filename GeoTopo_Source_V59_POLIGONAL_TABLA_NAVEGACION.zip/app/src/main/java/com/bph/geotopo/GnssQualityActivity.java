package com.bph.geotopo;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.GpsSatellite;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class GnssQualityActivity extends BaseToolActivity {
    private static final int REQ_LOCATION = 9550;
    private LocationManager manager;
    private TextView result;
    private Button startButton;
    private boolean running;
    private Location lastLocation;
    private int visibleSatellites;
    private int usedSatellites;
    private double averageCn0;
    private String constellationSummary = "—";
    private Double pdop, hdop, vdop;
    private String fixQuality = "—";
    private String nmeaTime = "—";
    private GnssBridge modernBridge;

    private final LocationListener locationListener = new LocationListener() {
        @Override public void onLocationChanged(Location location) { lastLocation = location; render(); }
        @Override public void onProviderEnabled(String provider) { render(); }
        @Override public void onProviderDisabled(String provider) { render(); }
    };

    private final GnssBridge.Sink modernSink = new GnssBridge.Sink() {
        @Override public void onSatellites(int visible, int used, double cn0, String summary) {
            visibleSatellites = visible; usedSatellites = used; averageCn0 = cn0;
            constellationSummary = summary == null || summary.isEmpty() ? "—" : summary;
            runOnUiThread(GnssQualityActivity.this::render);
        }
        @Override public void onNmea(String sentence) { parseNmea(sentence); }
    };

    private final GpsStatus.NmeaListener legacyNmeaListener = (timestamp, nmea) -> parseNmea(nmea);
    private final GpsStatus.Listener legacyGpsListener = event -> {
        if (event != GpsStatus.GPS_EVENT_SATELLITE_STATUS || manager == null) return;
        try {
            GpsStatus status = manager.getGpsStatus(null); if (status == null) return;
            visibleSatellites = 0; usedSatellites = 0; averageCn0 = 0; int n = 0;
            for (GpsSatellite sat : status.getSatellites()) {
                visibleSatellites++; if (sat.usedInFix()) usedSatellites++;
                if (sat.getSnr() > 0) { averageCn0 += sat.getSnr(); n++; }
            }
            if (n > 0) averageCn0 /= n;
            constellationSummary = "No desglosado en Android 6";
            render();
        } catch (SecurityException ignored) {}
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette(); manager = (LocationManager) getSystemService(LOCATION_SERVICE);
        LinearLayout root = page("Calidad GNSS", "Control de señal, satélites y precisión disponible");
        LinearLayout content = vertical();
        LinearLayout box = card();
        box.addView(sectionTitle("Diagnóstico del receptor del teléfono"));
        box.addView(small("Muestra la información que Android y el chip GNSS entregan. PDOP, HDOP y VDOP aparecen cuando el equipo transmite mensajes NMEA compatibles."));
        box.addView(warning("La precisión informada por el teléfono no garantiza exactitud topográfica. Obstáculos, reflexión de señal y geometría satelital pueden producir errores mayores."));
        startButton = primaryButton("Iniciar diagnóstico"); startButton.setOnClickListener(v -> toggle()); box.addView(startButton);
        result = resultBox("Diagnóstico detenido."); box.addView(result);
        content.addView(box);
        root.addView(scrollWith(content), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)); setContentView(root);
    }

    private void toggle() { if (running) stop(); else requestStart(); }

    private void requestStart() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION); return;
        }
        start();
    }

    private void start() {
        if (manager == null) { result.setText("Servicio de ubicación no disponible."); return; }
        stop();
        visibleSatellites = 0; usedSatellites = 0; averageCn0 = 0; constellationSummary = "—";
        pdop = null; hdop = null; vdop = null; fixQuality = "—"; nmeaTime = "—";
        try {
            if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) { result.setText("Activa el GPS del celular."); return; }
            manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locationListener);
            if (Build.VERSION.SDK_INT >= 24) {
                modernBridge = new ModernGnssBridge(modernSink);
                modernBridge.start(manager);
            } else {
                manager.addGpsStatusListener(legacyGpsListener);
                manager.addNmeaListener(legacyNmeaListener);
            }
            running = true; startButton.setText("Detener diagnóstico"); result.setText("Esperando señal GNSS...");
        } catch (SecurityException e) { result.setText("No se concedió permiso de ubicación."); }
        catch (Exception e) { result.setText("El receptor GNSS no pudo iniciar el diagnóstico."); }
    }

    private void stop() {
        if (manager != null) {
            try { manager.removeUpdates(locationListener); } catch (Exception ignored) {}
            if (modernBridge != null) { modernBridge.stop(manager); modernBridge = null; }
            try { manager.removeGpsStatusListener(legacyGpsListener); } catch (Exception ignored) {}
            try { manager.removeNmeaListener(legacyNmeaListener); } catch (Exception ignored) {}
        }
        running = false; if (startButton != null) startButton.setText("Iniciar diagnóstico"); if (result != null) render();
    }

    private void parseNmea(String nmea) {
        if (nmea == null) return;
        String line = nmea.trim();
        if (!validChecksum(line)) return;
        String[] f = line.split(",", -1);
        try {
            String type = f.length == 0 ? "" : f[0];
            if (type.endsWith("GSA") && f.length >= 6) {
                int end = f.length - 1;
                vdop = parseNullable(stripChecksum(f[end]));
                hdop = parseNullable(f[end - 1]);
                pdop = parseNullable(f[end - 2]);
            } else if (type.endsWith("GGA") && f.length >= 10) {
                nmeaTime = f[1].isEmpty() ? "—" : f[1];
                int quality = f[6].isEmpty() ? 0 : Integer.parseInt(f[6]);
                fixQuality = fixName(quality);
                if (!f[8].isEmpty()) hdop = Double.parseDouble(f[8]);
            }
        } catch (Exception ignored) {}
        runOnUiThread(this::render);
    }

    private boolean validChecksum(String line) {
        if (!line.startsWith("$") || !line.contains("*")) return true;
        int star = line.indexOf('*');
        if (star <= 1 || star + 2 >= line.length()) return false;
        int checksum = 0;
        for (int i = 1; i < star; i++) checksum ^= line.charAt(i);
        try { return checksum == Integer.parseInt(line.substring(star + 1, star + 3), 16); }
        catch (Exception e) { return false; }
    }

    private Double parseNullable(String value) { try { return value == null || value.isEmpty() ? null : Double.parseDouble(value); } catch (Exception e) { return null; } }
    private String stripChecksum(String v) { int i = v.indexOf('*'); return i >= 0 ? v.substring(0, i) : v; }

    private void render() {
        if (result == null) return;
        String position = lastLocation == null ? "—" : f7(lastLocation.getLatitude()) + ", " + f7(lastLocation.getLongitude());
        String acc = lastLocation == null || !lastLocation.hasAccuracy() ? "—" : "±" + f1(lastLocation.getAccuracy()) + " m";
        String vertical = lastLocation != null && Build.VERSION.SDK_INT >= 26 && lastLocation.hasVerticalAccuracy() ? "±" + f1(lastLocation.getVerticalAccuracyMeters()) + " m" : "—";
        String altitude = lastLocation != null && lastLocation.hasAltitude() ? f3(lastLocation.getAltitude()) + " m" : "—";
        result.setText("Estado: " + (running ? "ACTIVO" : "DETENIDO")
                + "\nPosición: " + position
                + "\nPrecisión horizontal reportada: " + acc
                + "\nPrecisión vertical reportada: " + vertical
                + "\nAltitud GNSS: " + altitude
                + "\nSatélites visibles: " + visibleSatellites + " · usados: " + usedSatellites
                + "\nC/N0 medio: " + (averageCn0 > 0 ? f1(averageCn0) + " dB-Hz" : "—")
                + "\nConstelaciones: " + constellationSummary
                + "\nPDOP: " + value(pdop) + " · HDOP: " + value(hdop) + " · VDOP: " + value(vdop)
                + "\nCalidad NMEA: " + fixQuality + " · hora NMEA: " + nmeaTime
                + "\nEvaluación rápida: " + qualityAssessment());
    }

    private String qualityAssessment() {
        if (lastLocation == null) return "sin posición";
        float a = lastLocation.hasAccuracy() ? lastLocation.getAccuracy() : 999f;
        if (usedSatellites >= 10 && a <= 3) return "buena para orientación y captura aproximada";
        if (usedSatellites >= 6 && a <= 10) return "media; espera y promedia antes de guardar";
        return "débil; busca cielo abierto y evita obstáculos";
    }

    private String value(Double d) { return d == null ? "—" : f2(d); }
    private String fixName(int q) {
        switch (q) { case 1: return "GPS autónomo"; case 2: return "DGPS"; case 4: return "RTK fijo"; case 5: return "RTK flotante"; case 6: return "estimado"; default: return "sin solución"; }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) start();
        else if (requestCode == REQ_LOCATION) result.setText("Sin permiso de ubicación no se puede leer el estado GNSS.");
    }

    @Override protected void onPause() { stop(); super.onPause(); }
}
