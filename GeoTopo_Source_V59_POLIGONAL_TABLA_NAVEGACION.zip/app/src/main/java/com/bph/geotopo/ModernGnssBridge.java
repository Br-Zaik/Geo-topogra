package com.bph.geotopo;

import android.annotation.TargetApi;
import android.location.GnssStatus;
import android.location.LocationManager;
import android.location.OnNmeaMessageListener;

import java.util.LinkedHashMap;
import java.util.Map;

/** GNSS APIs introduced in Android 7; instantiated only after an SDK check. */
@TargetApi(24)
final class ModernGnssBridge implements GnssBridge {
    private final Sink sink;
    private final GnssStatus.Callback callback;
    private final OnNmeaMessageListener nmea;

    ModernGnssBridge(Sink sink) {
        if (sink == null) throw new IllegalArgumentException("sink no puede ser null");
        this.sink = sink;

        this.callback = new GnssStatus.Callback() {
            @Override public void onSatelliteStatusChanged(GnssStatus status) {
                int visible = status.getSatelliteCount();
                int used = 0;
                double cn0 = 0;
                int cnCount = 0;
                Map<String, Integer> constellations = new LinkedHashMap<>();
                for (int i = 0; i < visible; i++) {
                    if (status.usedInFix(i)) used++;
                    float value = status.getCn0DbHz(i);
                    if (value > 0) {
                        cn0 += value;
                        cnCount++;
                    }
                    String name = constellationName(status.getConstellationType(i));
                    Integer count = constellations.get(name);
                    constellations.put(name, count == null ? 1 : count + 1);
                }
                if (cnCount > 0) cn0 /= cnCount;
                StringBuilder summary = new StringBuilder();
                for (Map.Entry<String, Integer> entry : constellations.entrySet()) {
                    if (summary.length() > 0) summary.append(" · ");
                    summary.append(entry.getKey()).append(' ').append(entry.getValue());
                }
                ModernGnssBridge.this.sink.onSatellites(
                        visible,
                        used,
                        cn0,
                        summary.toString()
                );
            }
        };

        this.nmea = (message, timestamp) -> ModernGnssBridge.this.sink.onNmea(message);
    }

    @Override public void start(LocationManager manager) throws SecurityException {
        manager.registerGnssStatusCallback(callback);
        manager.addNmeaListener(nmea);
    }

    @Override public void stop(LocationManager manager) {
        if (manager == null) return;
        try { manager.unregisterGnssStatusCallback(callback); } catch (Exception ignored) {}
        try { manager.removeNmeaListener(nmea); } catch (Exception ignored) {}
    }

    private String constellationName(int type) {
        switch (type) {
            case GnssStatus.CONSTELLATION_GPS: return "GPS";
            case GnssStatus.CONSTELLATION_GLONASS: return "GLONASS";
            case GnssStatus.CONSTELLATION_GALILEO: return "Galileo";
            case GnssStatus.CONSTELLATION_BEIDOU: return "BeiDou";
            case GnssStatus.CONSTELLATION_QZSS: return "QZSS";
            case GnssStatus.CONSTELLATION_SBAS: return "SBAS";
            case GnssStatus.CONSTELLATION_IRNSS: return "NavIC";
            default: return "Otros";
        }
    }
}
