package com.bph.geotopo;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class NotebookActivity extends BaseToolActivity {
    private static final int REQ_LOCATION = 9570;
    private LocationManager manager;
    private EditText projectInput, codeInput, northInput, eastInput, elevationInput, crsInput, accuracyInput, descriptionInput;
    private TextView listView;
    private List<NotebookStore.Entry> entries;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette(); manager = (LocationManager) getSystemService(LOCATION_SERVICE);
        LinearLayout root = page("Libreta de campo", "Registro local de puntos y observaciones");
        LinearLayout content = vertical();
        LinearLayout form = card();
        form.addView(sectionTitle("Nuevo punto"));
        form.addView(small("Usa un proyecto y un sistema de coordenadas coherente. N/E también puede almacenar latitud/longitud si lo indicas en la descripción."));
        projectInput = textInput("Proyecto"); projectInput.setText("General");
        codeInput = textInput("Código"); elevationInput = numberInput("Cota");
        northInput = numberInput("N / Latitud"); eastInput = numberInput("E / Longitud");
        crsInput = textInput("Ej.: WGS84 geográficas o WGS84 UTM 19S");
        accuracyInput = textInput("Ej.: ±3.5 m / RTK fijo"); descriptionInput = textInput("Descripción");
        form.addView(labeled("Proyecto", projectInput));
        LinearLayout r1 = horizontal(); r1.addView(labeled("Código", codeInput), weight()); r1.addView(labeled("Cota", elevationInput), weight()); form.addView(r1);
        LinearLayout r2 = horizontal(); r2.addView(labeled("N / Latitud", northInput), weight()); r2.addView(labeled("E / Longitud", eastInput), weight()); form.addView(r2);
        form.addView(labeled("Sistema de coordenadas / zona", crsInput));
        form.addView(labeled("Precisión / solución", accuracyInput)); form.addView(labeled("Descripción", descriptionInput));
        LinearLayout actions = horizontal();
        Button gps = secondaryButton("Tomar GPS actual"); gps.setOnClickListener(v -> captureGps()); actions.addView(gps, weight());
        Button save = primaryButton("Guardar punto"); save.setOnClickListener(v -> savePoint("Manual")); actions.addView(save, weight());
        form.addView(actions); content.addView(form);

        LinearLayout records = card(); records.addView(sectionTitle("Puntos guardados"));
        LinearLayout recordActions = horizontal();
        Button export = secondaryButton("Importar / exportar"); export.setOnClickListener(v -> startActivity(new Intent(this, DataExchangeActivity.class))); recordActions.addView(export, weight());
        Button deleteLast = secondaryButton("Borrar último"); deleteLast.setOnClickListener(v -> deleteLast()); recordActions.addView(deleteLast, weight());
        Button clear = secondaryButton("Borrar todo"); clear.setOnClickListener(v -> confirmClear()); recordActions.addView(clear, weight());
        records.addView(recordActions);
        listView = resultBox("No hay puntos guardados."); records.addView(listView); content.addView(records);

        root.addView(scrollWith(content), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)); setContentView(root);
        load();
    }

    @Override protected void onResume() { super.onResume(); load(); }

    private void load() { entries = NotebookStore.load(this); render(); }

    private void render() {
        if (listView == null) return;
        if (entries == null || entries.isEmpty()) { listView.setText("No hay puntos guardados."); return; }
        StringBuilder sb = new StringBuilder("Total: ").append(entries.size()).append(" puntos");
        for (int i = entries.size() - 1; i >= 0; i--) {
            NotebookStore.Entry e = entries.get(i);
            sb.append("\n\n").append(i + 1).append(". [").append(e.project).append("] ").append(e.code)
                    .append("\nN/Lat: ").append(e.north).append(" · E/Lon: ").append(e.east);
            if (!e.elevation.isEmpty()) sb.append(" · Cota: ").append(e.elevation);
            sb.append("\nSistema: ").append(e.crs);
            if (!e.accuracy.isEmpty()) sb.append("\nPrecisión: ").append(e.accuracy);
            if (!e.description.isEmpty()) sb.append("\n").append(e.description);
            sb.append("\nFuente: ").append(e.source).append(" · ").append(e.time);
        }
        listView.setText(sb.toString());
    }

    private void captureGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION); return;
        }
        try {
            Location gps = manager == null ? null : manager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location net = manager == null ? null : manager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            Location loc = newest(gps, net);
            if (loc == null) { showToast("No existe una posición reciente. Abre GPS y mapas o espera señal unos segundos."); return; }
            northInput.setText(f7(loc.getLatitude())); eastInput.setText(f7(loc.getLongitude()));
            crsInput.setText("WGS84 geográficas");
            if (loc.hasAltitude()) elevationInput.setText(f3(loc.getAltitude()));
            if (loc.hasAccuracy()) accuracyInput.setText("±" + f1(loc.getAccuracy()) + " m");
            showToast("Se copió la última posición disponible.");
        } catch (SecurityException e) { showToast("No se pudo leer la ubicación."); }
    }

    private Location newest(Location a, Location b) { if (a == null) return b; if (b == null) return a; return a.getTime() >= b.getTime() ? a : b; }

    private void savePoint(String source) {
        String project = projectInput.getText().toString().trim(); if (project.isEmpty()) project = "General";
        String code = codeInput.getText().toString().trim();
        String n = northInput.getText().toString().trim().replace(',', '.');
        String e = eastInput.getText().toString().trim().replace(',', '.');
        String z = elevationInput.getText().toString().trim().replace(',', '.');
        if (code.isEmpty() || n.isEmpty() || e.isEmpty()) { showToast("Proyecto, código y coordenadas son necesarios."); return; }
        try { Double.parseDouble(n); Double.parseDouble(e); if (!z.isEmpty()) Double.parseDouble(z); } catch (Exception ex) { showToast("Revisa las coordenadas y la cota."); return; }
        String crs = crsInput.getText().toString().trim(); if (crs.isEmpty()) crs = "No indicado";
        NotebookStore.add(this, new NotebookStore.Entry(project, code, n, e, z, crs,
                descriptionInput.getText().toString().trim(), accuracyInput.getText().toString().trim(), source,
                new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())));
        codeInput.setText(""); northInput.setText(""); eastInput.setText(""); elevationInput.setText(""); crsInput.setText(""); accuracyInput.setText(""); descriptionInput.setText("");
        load(); showToast("Punto guardado.");
    }

    private void deleteLast() {
        if (entries == null || entries.isEmpty()) return;
        entries.remove(entries.size() - 1); NotebookStore.save(this, entries); render();
    }

    private void confirmClear() {
        if (entries == null || entries.isEmpty()) return;
        new AlertDialog.Builder(this).setTitle("Borrar libreta")
                .setMessage("Se eliminarán todos los puntos guardados localmente.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Borrar", (d, w) -> { entries.clear(); NotebookStore.save(this, entries); render(); }).show();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) captureGps();
        else if (requestCode == REQ_LOCATION) showToast("Sin permiso no se puede copiar la posición GPS.");
    }
}
