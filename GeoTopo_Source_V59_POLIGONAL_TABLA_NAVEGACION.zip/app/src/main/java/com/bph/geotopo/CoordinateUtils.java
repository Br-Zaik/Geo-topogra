package com.bph.geotopo;

/** WGS84 geographic/UTM conversions used by field tools. */
public final class CoordinateUtils {
    private static final double A = 6378137.0;
    private static final double ECC_SQUARED = 0.00669438;
    private static final double K0 = 0.9996;

    private CoordinateUtils() {}

    public static Utm toUtm(double latitude, double longitude) {
        if (!validLatLon(latitude, longitude) || latitude < -80.0 || latitude > 84.0) return Utm.invalid();
        int zone = (int) Math.floor((longitude + 180.0) / 6.0) + 1;
        if (longitude == 180.0) zone = 60;
        if (latitude >= 56.0 && latitude < 64.0 && longitude >= 3.0 && longitude < 12.0) zone = 32;
        if (latitude >= 72.0 && latitude < 84.0) {
            if (longitude < 9.0) zone = 31;
            else if (longitude < 21.0) zone = 33;
            else if (longitude < 33.0) zone = 35;
            else if (longitude < 42.0) zone = 37;
        }
        return toUtm(latitude, longitude, zone);
    }

    /** Converts using a requested UTM zone, useful when staking a point near a zone boundary. */
    public static Utm toUtm(double latitude, double longitude, int zone) {
        if (!validLatLon(latitude, longitude) || latitude < -80.0 || latitude > 84.0 || zone < 1 || zone > 60) return Utm.invalid();
        double lonOrigin = (zone - 1) * 6.0 - 180.0 + 3.0;
        double latRad = Math.toRadians(latitude);
        double lonRad = Math.toRadians(longitude);
        double lonOriginRad = Math.toRadians(lonOrigin);
        double eccPrimeSquared = ECC_SQUARED / (1.0 - ECC_SQUARED);
        double sinLat = Math.sin(latRad);
        double cosLat = Math.cos(latRad);
        double tanLat = Math.tan(latRad);
        double n = A / Math.sqrt(1.0 - ECC_SQUARED * sinLat * sinLat);
        double t = tanLat * tanLat;
        double c = eccPrimeSquared * cosLat * cosLat;
        double aa = cosLat * (lonRad - lonOriginRad);
        double e2 = ECC_SQUARED * ECC_SQUARED;
        double e3 = e2 * ECC_SQUARED;
        double m = A * ((1.0 - ECC_SQUARED / 4.0 - 3.0 * e2 / 64.0 - 5.0 * e3 / 256.0) * latRad
                - (3.0 * ECC_SQUARED / 8.0 + 3.0 * e2 / 32.0 + 45.0 * e3 / 1024.0) * Math.sin(2.0 * latRad)
                + (15.0 * e2 / 256.0 + 45.0 * e3 / 1024.0) * Math.sin(4.0 * latRad)
                - (35.0 * e3 / 3072.0) * Math.sin(6.0 * latRad));
        double easting = K0 * n * (aa + (1.0 - t + c) * Math.pow(aa, 3) / 6.0
                + (5.0 - 18.0 * t + t * t + 72.0 * c - 58.0 * eccPrimeSquared) * Math.pow(aa, 5) / 120.0) + 500000.0;
        double northing = K0 * (m + n * tanLat * (aa * aa / 2.0
                + (5.0 - t + 9.0 * c + 4.0 * c * c) * Math.pow(aa, 4) / 24.0
                + (61.0 - 58.0 * t + t * t + 600.0 * c - 330.0 * eccPrimeSquared) * Math.pow(aa, 6) / 720.0));
        boolean south = latitude < 0.0;
        if (south) northing += 10000000.0;
        return new Utm(true, zone, south, easting, northing);
    }

    public static LatLon fromUtm(double easting, double northing, int zone, boolean south) {
        if (zone < 1 || zone > 60 || easting < 100000.0 || easting > 1000000.0 || northing < 0.0 || northing > 10000000.0) {
            return LatLon.invalid();
        }
        double x = easting - 500000.0;
        double y = south ? northing - 10000000.0 : northing;
        double eccPrimeSquared = ECC_SQUARED / (1.0 - ECC_SQUARED);
        double m = y / K0;
        double e2 = ECC_SQUARED * ECC_SQUARED;
        double e3 = e2 * ECC_SQUARED;
        double mu = m / (A * (1.0 - ECC_SQUARED / 4.0 - 3.0 * e2 / 64.0 - 5.0 * e3 / 256.0));
        double e1 = (1.0 - Math.sqrt(1.0 - ECC_SQUARED)) / (1.0 + Math.sqrt(1.0 - ECC_SQUARED));
        double e1_2 = e1 * e1, e1_3 = e1_2 * e1, e1_4 = e1_3 * e1;
        double phi1 = mu
                + (3.0 * e1 / 2.0 - 27.0 * e1_3 / 32.0) * Math.sin(2.0 * mu)
                + (21.0 * e1_2 / 16.0 - 55.0 * e1_4 / 32.0) * Math.sin(4.0 * mu)
                + (151.0 * e1_3 / 96.0) * Math.sin(6.0 * mu)
                + (1097.0 * e1_4 / 512.0) * Math.sin(8.0 * mu);
        double sin1 = Math.sin(phi1), cos1 = Math.cos(phi1), tan1 = Math.tan(phi1);
        double n1 = A / Math.sqrt(1.0 - ECC_SQUARED * sin1 * sin1);
        double r1 = A * (1.0 - ECC_SQUARED) / Math.pow(1.0 - ECC_SQUARED * sin1 * sin1, 1.5);
        double t1 = tan1 * tan1;
        double c1 = eccPrimeSquared * cos1 * cos1;
        double d = x / (n1 * K0);
        double latRad = phi1 - (n1 * tan1 / r1) * (d * d / 2.0
                - (5.0 + 3.0 * t1 + 10.0 * c1 - 4.0 * c1 * c1 - 9.0 * eccPrimeSquared) * Math.pow(d, 4) / 24.0
                + (61.0 + 90.0 * t1 + 298.0 * c1 + 45.0 * t1 * t1 - 252.0 * eccPrimeSquared - 3.0 * c1 * c1) * Math.pow(d, 6) / 720.0);
        double lonRad = (d - (1.0 + 2.0 * t1 + c1) * Math.pow(d, 3) / 6.0
                + (5.0 - 2.0 * c1 + 28.0 * t1 - 3.0 * c1 * c1 + 8.0 * eccPrimeSquared + 24.0 * t1 * t1) * Math.pow(d, 5) / 120.0) / cos1;
        double lonOrigin = (zone - 1) * 6.0 - 180.0 + 3.0;
        double latitude = Math.toDegrees(latRad);
        double longitude = lonOrigin + Math.toDegrees(lonRad);
        return validLatLon(latitude, longitude) ? new LatLon(true, latitude, longitude) : LatLon.invalid();
    }

    private static boolean validLatLon(double latitude, double longitude) {
        return !Double.isNaN(latitude) && !Double.isNaN(longitude)
                && latitude >= -90.0 && latitude <= 90.0 && longitude >= -180.0 && longitude <= 180.0;
    }

    public static final class Utm {
        public final boolean valid;
        public final int zone;
        public final boolean south;
        public final double easting;
        public final double northing;
        Utm(boolean valid, int zone, boolean south, double easting, double northing) {
            this.valid = valid; this.zone = zone; this.south = south; this.easting = easting; this.northing = northing;
        }
        static Utm invalid() { return new Utm(false, 0, false, Double.NaN, Double.NaN); }
        public String hemisphere() { return south ? "S" : "N"; }
    }

    public static final class LatLon {
        public final boolean valid;
        public final double latitude;
        public final double longitude;
        LatLon(boolean valid, double latitude, double longitude) {
            this.valid = valid; this.latitude = latitude; this.longitude = longitude;
        }
        static LatLon invalid() { return new LatLon(false, Double.NaN, Double.NaN); }
    }
}
