package com.bph.geotopo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

/** Native field tools launcher with direct navigation to each screen. */
public class FieldToolsActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NativeUi.styleWindow(this);
        setContentView(buildScreen());
    }

    private View buildScreen() {
        FrameLayout root = NativeUi.screen(this);
        LinearLayout page = NativeUi.column(this);
        page.addView(NativeUi.pageHeader(this, "Herramientas de campo",
                "Trabajo de campo topográfico", v -> finish(), null, null));

        LinearLayout content = NativeUi.column(this);
        content.setPadding(NativeUi.dp(this, 15), NativeUi.dp(this, 8),
                NativeUi.dp(this, 15), NativeUi.dp(this, 28));

        content.addView(NativeUi.sectionHeader(this, "⌖", "CAPTURA Y UBICACIÓN", null, null));
        add(content, "target", "Replanteo de punto", "Coordenadas, dirección, distancia y tolerancia", StakeoutActivity.class);
        add(content, "pin", "Registro de recorridos GPS", "Trayectos, distancia, tiempo y puntos", TrackActivity.class);
        add(content, "satellite", "Calidad GNSS", "Satélites, precisión, constelaciones y NMEA", GnssQualityActivity.class);
        add(content, "satellite", "GNSS externo Bluetooth", "Receptores NMEA emparejados", ExternalGnssActivity.class);

        content.addView(NativeUi.sectionHeader(this, "▦", "CÁLCULOS DE CAMPO", null, null));
        add(content, "swap", "COGO directo e inverso", "Directa, inversa, intersecciones y offsets", CogoActivity.class);
        add(content, "polygon", "Área y perímetro", "Cálculo por vértices, lados y rumbos", AreaActivity.class);
        add(content, "polygon", "Poligonales", "Abierta, cerrada, cierres y Bowditch", TraverseActivity.class);
        add(content, "level", "Nivelación de campo", "Vista atrás, intermedia, adelante y ajuste", LevelingFieldActivity.class);
        add(content, "slope", "Perfiles y secciones", "Progresivas, cotas y pendientes", ProfileActivity.class);

        content.addView(NativeUi.sectionHeader(this, "▱", "MAPAS Y ARCHIVOS", null, null));
        add(content, "grid", "Mapas sin internet", "Paquetes MBTiles propios o autorizados", OfflineMapActivity.class);
        add(content, "book", "Libreta de campo", "Puntos, códigos, cotas y observaciones", NotebookActivity.class);
        add(content, "share", "Importar y exportar", "CSV, GeoJSON, KML y respaldo JSON", DataExchangeActivity.class);

        page.addView(NativeUi.scroll(this, content), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(page, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return root;
    }

    private void add(LinearLayout content, String icon, String title, String subtitle, Class<?> target) {
        View card = NativeUi.menuCard(this, icon, title, subtitle,
                v -> startActivity(new Intent(this, target)), 91);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, NativeUi.dp(this, 10));
        content.addView(card, lp);
    }
}
