package com.bph.geotopo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * V137: lienzo del Visor de coordenadas. Dibuja los puntos en planta (2D) o en 3D,
 * con cuadrícula de coordenadas, flecha del norte, escala, ejes y colores por cota.
 * Un dedo: mover (2D) / girar (3D). Dos dedos: zoom y mover. Doble toque: acercar. Toque: elegir punto.
 */
public class PlotView extends View {
    public interface Listener {
        void onSelectionChanged();
    }

    public static final int VIEW_TOP = 0;
    public static final int VIEW_ISO = 1;
    public static final int VIEW_FRONT = 2;
    public static final int VIEW_SIDE = 3;

    private static final int BG = Color.rgb(24, 29, 36);
    private static final int GRID = Color.argb(46, 160, 190, 220);
    private static final int GRID_TEXT = Color.rgb(140, 160, 182);
    private static final int LINE = Color.rgb(80, 205, 255);
    private static final int[] CODE_COLORS = {
            Color.rgb(80, 205, 255), Color.rgb(255, 214, 10), Color.rgb(255, 120, 90), Color.rgb(120, 230, 120),
            Color.rgb(230, 130, 255), Color.rgb(255, 170, 60), Color.rgb(90, 160, 255), Color.rgb(240, 240, 240)
    };

    private final float d;
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint grid = new Paint();
    private final Path path = new Path();
    private final DashPathEffect dash;
    private final ScaleGestureDetector scaleDetector;
    private final GestureDetector gestures;

    private List<PlotMath.PlotPoint> pts = new ArrayList<>();
    private List<PlotMath.Run> runs = new ArrayList<>();
    private PlotMath.Bounds bounds = new PlotMath.Bounds();
    private Listener listener;

    // Opciones
    private boolean showNames = true, showZ = true, showDesc = false, showDist = false, colorByZ = true;
    private boolean measureMode = false, mode3d = false;
    private int lineMode = PlotMath.LINES_ORDER;
    private boolean closeLines = false;
    private double exaggeration = 1;

    // Vista 2D: centro en coordenadas y escala en píxeles por metro.
    private double cE, cN, s2 = 1;
    // Vista 3D
    private double yaw = Math.toRadians(-45), pitch = Math.toRadians(35.264), s3 = 1, panX, panY;
    private double c3E, c3N, c3Z;
    private boolean fitted;

    // Selección
    private int selA = -1, selB = -1;

    // Posiciones en pantalla del último dibujo (para tocar puntos).
    private float[] sx = new float[0], sy = new float[0];
    private double[] depth = new double[0];
    private int[] order = new int[0];
    private boolean[] labelGrid = new boolean[0];
    private float[] buf = new float[0];
    private final double[] tmp = new double[3];

    public PlotView(Context context) {
        super(context);
        d = context.getResources().getDisplayMetrics().density;
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        fill.setStyle(Paint.Style.FILL);
        text.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL));
        grid.setStyle(Paint.Style.STROKE);
        grid.setStrokeWidth(Math.max(1f, d * 0.7f));
        dash = new DashPathEffect(new float[]{6 * d, 4 * d}, 0);
        setBackgroundColor(BG);
        setFocusable(true);

        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector det) {
                zoomAt(det.getFocusX(), det.getFocusY(), det.getScaleFactor());
                return true;
            }
        });
        gestures = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }

            @Override public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                if (mode3d && e2.getPointerCount() == 1 && !scaleDetector.isInProgress()) orbit(dx, dy);
                else pan(dx, dy);
                return true;
            }

            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                tap(e.getX(), e.getY());
                return true;
            }

            @Override public boolean onDoubleTap(MotionEvent e) {
                zoomAt(e.getX(), e.getY(), 2f);
                return true;
            }
        });
    }

    // ------------------------------------------------------------ API para la pantalla
    public void setListener(Listener l) { listener = l; }

    public void setPoints(List<PlotMath.PlotPoint> list) {
        pts = list == null ? new ArrayList<PlotMath.PlotPoint>() : list;
        dataChanged();
    }

    /** Llamar después de agregar, editar o borrar puntos. */
    public void dataChanged() {
        bounds = PlotMath.bounds(pts);
        runs = PlotMath.buildRuns(pts, lineMode, closeLines);
        if (selA >= pts.size()) selA = -1;
        if (selB >= pts.size()) selB = -1;
        invalidate();
    }

    public List<PlotMath.Run> getRuns() { return runs; }

    public void setOptions(boolean names, boolean z, boolean desc, boolean dist, boolean byZ) {
        showNames = names; showZ = z; showDesc = desc; showDist = dist; colorByZ = byZ;
        invalidate();
    }

    public void setLines(int mode, boolean close) {
        lineMode = mode; closeLines = close;
        runs = PlotMath.buildRuns(pts, lineMode, closeLines);
        invalidate();
    }

    public void setExaggeration(double v) {
        exaggeration = v <= 0 ? 1 : v;
        if (mode3d) fit3d();
        invalidate();
    }

    public double getExaggeration() { return exaggeration; }

    public void setMode3d(boolean on) {
        mode3d = on;
        if (on) fit3d(); else fit2d();
        invalidate();
    }

    public boolean isMode3d() { return mode3d; }

    public void setMeasureMode(boolean on) {
        measureMode = on;
        selA = -1; selB = -1;
        invalidate();
        if (listener != null) listener.onSelectionChanged();
    }

    public boolean isMeasureMode() { return measureMode; }

    public int getSelA() { return selA; }
    public int getSelB() { return selB; }

    public void clearSelection() {
        selA = -1; selB = -1;
        invalidate();
        if (listener != null) listener.onSelectionChanged();
    }

    /** Selecciona un punto y lo lleva al centro de la pantalla. */
    public void focusPoint(int index) {
        if (index < 0 || index >= pts.size()) return;
        selA = index; selB = -1;
        PlotMath.PlotPoint p = pts.get(index);
        if (mode3d) {
            project3(p, tmp);
            panX = -tmp[0] * s3;
            panY = tmp[1] * s3;
        } else {
            cE = p.east; cN = p.north;
            if (getWidth() > 0 && s2 < getWidth() / 60.0) s2 = getWidth() / 60.0;
        }
        invalidate();
        if (listener != null) listener.onSelectionChanged();
    }

    public void setView(int preset) {
        switch (preset) {
            case VIEW_TOP: yaw = 0; pitch = Math.toRadians(90); break;
            case VIEW_FRONT: yaw = 0; pitch = 0; break;
            case VIEW_SIDE: yaw = Math.toRadians(-90); pitch = 0; break;
            case VIEW_ISO:
            default: yaw = Math.toRadians(-45); pitch = Math.toRadians(35.264); break;
        }
        fit3d();
        invalidate();
    }

    /** Encuadra todo en el próximo dibujo (sirve aunque la vista esté oculta). */
    public void requestFit() {
        fitted = false;
        invalidate();
    }

    public void zoomExtents() {
        if (mode3d) fit3d(); else fit2d();
        invalidate();
    }

    // ------------------------------------------------------------ encuadre
    private void fit2d() {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        fitted = true;
        if (bounds.empty()) { cE = 0; cN = 0; s2 = Math.min(w, h) / 100.0; return; }
        cE = (bounds.minE + bounds.maxE) / 2;
        cN = (bounds.minN + bounds.maxN) / 2;
        double re = bounds.maxE - bounds.minE, rn = bounds.maxN - bounds.minN;
        if (re < 1e-6 && rn < 1e-6) { s2 = Math.min(w, h) / 20.0; return; }
        double sE = re < 1e-6 ? Double.MAX_VALUE : w * 0.80 / re;
        double sN = rn < 1e-6 ? Double.MAX_VALUE : h * 0.74 / rn;
        s2 = clamp(Math.min(sE, sN), 1e-7, 1e5);
    }

    private void fit3d() {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        fitted = true;
        if (bounds.empty()) { c3E = 0; c3N = 0; c3Z = 0; s3 = Math.min(w, h) / 100.0; panX = 0; panY = 0; return; }
        c3E = (bounds.minE + bounds.maxE) / 2;
        c3N = (bounds.minN + bounds.maxN) / 2;
        c3Z = (bounds.minZ + bounds.maxZ) / 2;
        double minX = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, minY = Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (int i = 0; i < 8; i++) {
            double e = (i & 1) == 0 ? bounds.minE : bounds.maxE;
            double n = (i & 2) == 0 ? bounds.minN : bounds.maxN;
            double z = (i & 4) == 0 ? bounds.minZ : bounds.maxZ;
            PlotMath.project(e - c3E, n - c3N, (z - c3Z) * exaggeration, yaw, pitch, tmp);
            minX = Math.min(minX, tmp[0]); maxX = Math.max(maxX, tmp[0]);
            minY = Math.min(minY, tmp[1]); maxY = Math.max(maxY, tmp[1]);
        }
        double rx = maxX - minX, ry = maxY - minY;
        if (rx < 1e-6 && ry < 1e-6) s3 = Math.min(w, h) / 20.0;
        else {
            double a = rx < 1e-6 ? Double.MAX_VALUE : w * 0.78 / rx;
            double b = ry < 1e-6 ? Double.MAX_VALUE : h * 0.70 / ry;
            s3 = clamp(Math.min(a, b), 1e-7, 1e5);
        }
        panX = -(minX + maxX) / 2 * s3;
        panY = (minY + maxY) / 2 * s3;
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (!fitted) { if (mode3d) fit3d(); else fit2d(); }
    }

    // ------------------------------------------------------------ gestos
    @Override public boolean onTouchEvent(MotionEvent ev) {
        if (ev.getActionMasked() == MotionEvent.ACTION_DOWN && getParent() != null)
            getParent().requestDisallowInterceptTouchEvent(true);
        scaleDetector.onTouchEvent(ev);
        gestures.onTouchEvent(ev);
        return true;
    }

    private void zoomAt(float fx, float fy, float factor) {
        if (Float.isNaN(factor) || factor <= 0) return;
        float w = getWidth(), h = getHeight();
        if (mode3d) {
            double ns = clamp(s3 * factor, 1e-7, 1e5);
            double px = (fx - w / 2 - panX) / s3, py = (fy - h / 2 - panY) / s3;
            panX = fx - w / 2 - px * ns;
            panY = fy - h / 2 - py * ns;
            s3 = ns;
        } else {
            double wE = cE + (fx - w / 2) / s2, wN = cN - (fy - h / 2) / s2;
            double ns = clamp(s2 * factor, 1e-7, 1e5);
            cE = wE - (fx - w / 2) / ns;
            cN = wN + (fy - h / 2) / ns;
            s2 = ns;
        }
        invalidate();
    }

    private void pan(float dx, float dy) {
        if (mode3d) { panX -= dx; panY -= dy; }
        else { cE += dx / s2; cN -= dy / s2; }
        invalidate();
    }

    private void orbit(float dx, float dy) {
        yaw += dx * 0.0065;
        pitch = clamp(pitch - dy * 0.0065, 0, Math.PI / 2);
        invalidate();
    }

    private void tap(float x, float y) {
        int best = -1;
        float bestD = 30 * d;
        int n = Math.min(pts.size(), sx.length);
        for (int i = 0; i < n; i++) {
            float ddx = sx[i] - x, ddy = sy[i] - y;
            float dist = (float) Math.sqrt(ddx * ddx + ddy * ddy);
            if (dist < bestD) { bestD = dist; best = i; }
        }
        if (best < 0) {
            if (!measureMode) { selA = -1; selB = -1; }
        } else if (measureMode) {
            if (selA < 0 || selB >= 0) { selA = best; selB = -1; }
            else if (best != selA) selB = best;
        } else {
            selA = best; selB = -1;
        }
        invalidate();
        if (listener != null) listener.onSelectionChanged();
    }

    // ------------------------------------------------------------ dibujo
    @Override protected void onDraw(Canvas cv) {
        super.onDraw(cv);
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        if (!fitted) { if (mode3d) fit3d(); else fit2d(); }
        int n = pts.size();
        ensureArrays(n);
        if (n == 0) {
            drawEmpty(cv, w, h);
            return;
        }
        if (mode3d) draw3d(cv, w, h, n); else draw2d(cv, w, h, n);
        if (colorByZ && bounds.zRange() > 1e-9) drawLegend(cv, w, h);
    }

    private void ensureArrays(int n) {
        if (sx.length < n) {
            int cap = Math.max(n, 16);
            sx = new float[cap]; sy = new float[cap]; depth = new double[cap]; order = new int[cap];
        }
    }

    private void drawEmpty(Canvas cv, int w, int h) {
        drawGrid2d(cv, w, h);
        label(cv, "Sin puntos todavía", w / 2f, h / 2f - 10 * d, 17, Color.rgb(220, 232, 245), true, Paint.Align.CENTER);
        label(cv, "Agrega o pega coordenadas en «Datos»", w / 2f, h / 2f + 14 * d, 13, GRID_TEXT, false, Paint.Align.CENTER);
        drawNorth2d(cv, w);
    }

    // ---------- 2D
    private float toX(double e, int w) { return (float) (w / 2.0 + (e - cE) * s2); }
    private float toY(double n, int h) { return (float) (h / 2.0 - (n - cN) * s2); }

    private void draw2d(Canvas cv, int w, int h, int n) {
        drawGrid2d(cv, w, h);
        for (int i = 0; i < n; i++) {
            PlotMath.PlotPoint p = pts.get(i);
            sx[i] = toX(p.east, w);
            sy[i] = toY(p.north, h);
        }
        drawRuns(cv, w, h);
        if (showDist) drawDistances(cv, w, h);
        drawMeasureLine(cv);
        drawPoints(cv, w, h, n, null);
        drawSelection(cv);
        drawNorth2d(cv, w);
        drawScaleBar(cv, h, s2);
    }

    private void drawGrid2d(Canvas cv, int w, int h) {
        double worldW = w / s2;
        double step = PlotMath.niceStep(worldW / 5.0);
        int dec = PlotMath.decimalsFor(step);
        double minE = cE - w / 2.0 / s2, maxE = cE + w / 2.0 / s2;
        double minN = cN - h / 2.0 / s2, maxN = cN + h / 2.0 / s2;
        grid.setColor(GRID);
        text.setShadowLayer(0, 0, 0, 0);
        int guard = 0;
        for (double e = Math.ceil(minE / step) * step; e <= maxE && guard < 200; e += step, guard++) {
            float x = toX(e, w);
            cv.drawLine(x, 0, x, h, grid);
            label(cv, PlotMath.fmt(e, dec), x + 3 * d, h - 6 * d, 9.5f, GRID_TEXT, false, Paint.Align.LEFT);
        }
        guard = 0;
        for (double nn = Math.ceil(minN / step) * step; nn <= maxN && guard < 200; nn += step, guard++) {
            float y = toY(nn, h);
            cv.drawLine(0, y, w, y, grid);
            label(cv, PlotMath.fmt(nn, dec), 4 * d, y - 3 * d, 9.5f, GRID_TEXT, false, Paint.Align.LEFT);
        }
    }

    private void drawDistances(Canvas cv, int w, int h) {
        int drawn = 0;
        text.setTextSize(10.5f * d);
        text.setTextAlign(Paint.Align.CENTER);
        text.setColor(Color.rgb(255, 230, 140));
        text.setShadowLayer(3 * d, 0, 0, Color.BLACK);
        for (PlotMath.Run r : runs) {
            int segs = r.closed ? r.idx.length : r.idx.length - 1;
            for (int k = 0; k < segs && drawn < 500; k++) {
                int a = r.idx[k], b = r.idx[(k + 1) % r.idx.length];
                float x1 = sx[a], y1 = sy[a], x2 = sx[b], y2 = sy[b];
                float len = (float) Math.hypot(x2 - x1, y2 - y1);
                if (len < 70 * d) continue;
                float mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
                if (mx < 0 || my < 0 || mx > w || my > h) continue;
                float ang = (float) Math.toDegrees(Math.atan2(y2 - y1, x2 - x1));
                if (ang > 90) ang -= 180; else if (ang < -90) ang += 180;
                cv.save();
                cv.rotate(ang, mx, my);
                cv.drawText(PlotMath.fmt(PlotMath.horizontal(pts.get(a), pts.get(b)), 2) + " m", mx, my - 4 * d, text);
                cv.restore();
                drawn++;
            }
        }
        text.setShadowLayer(0, 0, 0, 0);
    }

    private void drawNorth2d(Canvas cv, int w) {
        float cx = w - 30 * d, cy = 42 * d, r = 17 * d;
        fill.setColor(Color.argb(150, 10, 16, 24));
        cv.drawCircle(cx, cy, r + 5 * d, fill);
        line.setPathEffect(null);
        line.setColor(Color.argb(170, 200, 215, 230));
        line.setStrokeWidth(1.2f * d);
        cv.drawCircle(cx, cy, r + 5 * d, line);
        drawArrow(cv, cx, cy, 0f, -1f, r);
        label(cv, "N", cx, cy - r - 9 * d, 12, Color.WHITE, true, Paint.Align.CENTER);
    }

    /** Flecha de norte: mitad clara y mitad oscura, como en los planos. */
    private void drawArrow(Canvas cv, float cx, float cy, float ux, float uy, float r) {
        float px = -uy, py = ux; // perpendicular
        float tipX = cx + ux * r, tipY = cy + uy * r;
        float tailX = cx - ux * r * 0.75f, tailY = cy - uy * r * 0.75f;
        float wdt = r * 0.38f;
        path.reset();
        path.moveTo(tipX, tipY);
        path.lineTo(cx + px * wdt, cy + py * wdt);
        path.lineTo(tailX, tailY);
        path.close();
        fill.setColor(Color.WHITE);
        cv.drawPath(path, fill);
        path.reset();
        path.moveTo(tipX, tipY);
        path.lineTo(cx - px * wdt, cy - py * wdt);
        path.lineTo(tailX, tailY);
        path.close();
        fill.setColor(Color.rgb(230, 70, 60));
        cv.drawPath(path, fill);
    }

    private void drawScaleBar(Canvas cv, int h, double pxPerM) {
        if (!(pxPerM > 0)) return;
        double target = 110 * d / pxPerM;
        double len = PlotMath.niceStep(target);
        float px = (float) (len * pxPerM);
        float x0 = 14 * d, y0 = h - 26 * d, bh = 5 * d;
        fill.setColor(Color.argb(150, 10, 16, 24));
        cv.drawRoundRect(new RectF(x0 - 6 * d, y0 - 20 * d, x0 + px + 34 * d, y0 + bh + 6 * d), 6 * d, 6 * d, fill);
        for (int i = 0; i < 4; i++) {
            fill.setColor(i % 2 == 0 ? Color.WHITE : Color.rgb(40, 46, 54));
            cv.drawRect(x0 + px * i / 4f, y0, x0 + px * (i + 1) / 4f, y0 + bh, fill);
        }
        line.setPathEffect(null);
        line.setColor(Color.WHITE);
        line.setStrokeWidth(1f * d);
        cv.drawRect(x0, y0, x0 + px, y0 + bh, line);
        label(cv, "0", x0, y0 - 5 * d, 10, Color.WHITE, false, Paint.Align.CENTER);
        label(cv, scaleText(len), x0 + px, y0 - 5 * d, 10, Color.WHITE, true, Paint.Align.CENTER);
    }

    private static String scaleText(double m) {
        if (m >= 1000) return PlotMath.fmt(m / 1000, m % 1000 == 0 ? 0 : 1) + " km";
        if (m >= 1) return PlotMath.fmt(m, 0) + " m";
        if (m >= 0.01) return PlotMath.fmt(m * 100, 0) + " cm";
        return PlotMath.fmt(m * 1000, 0) + " mm";
    }

    // ---------- 3D
    private void project3(PlotMath.PlotPoint p, double[] out) {
        double z = p.hasZ ? p.z : bounds.baseZ();
        PlotMath.project(p.east - c3E, p.north - c3N, (z - c3Z) * exaggeration, yaw, pitch, out);
    }

    private float sx3(double px, int w) { return (float) (w / 2.0 + panX + px * s3); }
    private float sy3(double py, int h) { return (float) (h / 2.0 + panY - py * s3); }

    private void draw3d(Canvas cv, int w, int h, int n) {
        double baseZ = (bounds.baseZ() - c3Z) * exaggeration;
        drawGround(cv, w, h, baseZ);
        for (int i = 0; i < n; i++) {
            project3(pts.get(i), tmp);
            sx[i] = sx3(tmp[0], w);
            sy[i] = sy3(tmp[1], h);
            depth[i] = tmp[2];
            order[i] = i;
        }
        // Líneas verticales hasta el plano base: ayudan a ver la altura.
        if (bounds.zRange() > 1e-9 && n <= 6000) {
            line.setPathEffect(null);
            line.setStrokeWidth(Math.max(1f, 0.8f * d));
            line.setColor(Color.argb(55, 200, 210, 225));
            for (int i = 0; i < n; i++) {
                PlotMath.PlotPoint p = pts.get(i);
                if (!p.hasZ) continue;
                PlotMath.project(p.east - c3E, p.north - c3N, baseZ, yaw, pitch, tmp);
                cv.drawLine(sx[i], sy[i], sx3(tmp[0], w), sy3(tmp[1], h), line);
            }
        }
        drawRuns(cv, w, h);
        drawMeasureLine(cv);
        PlotMath.sortDesc(order, depth, n);
        drawPoints(cv, w, h, n, order);
        drawSelection(cv);
        drawAxes(cv, h);
        drawNorth3d(cv, w);
    }

    private void drawGround(Canvas cv, int w, int h, double baseZ) {
        if (bounds.empty()) return;
        double span = Math.max(bounds.maxE - bounds.minE, bounds.maxN - bounds.minN);
        if (span < 1e-6) span = 20;
        double step = PlotMath.niceStep(span / 8.0);
        double e0 = Math.floor(bounds.minE / step) * step - step, e1 = Math.ceil(bounds.maxE / step) * step + step;
        double n0 = Math.floor(bounds.minN / step) * step - step, n1 = Math.ceil(bounds.maxN / step) * step + step;
        grid.setColor(Color.argb(40, 160, 190, 220));
        int guard = 0;
        for (double e = e0; e <= e1 + 1e-9 && guard < 80; e += step, guard++) {
            PlotMath.project(e - c3E, n0 - c3N, baseZ, yaw, pitch, tmp);
            float ax = sx3(tmp[0], w), ay = sy3(tmp[1], h);
            PlotMath.project(e - c3E, n1 - c3N, baseZ, yaw, pitch, tmp);
            cv.drawLine(ax, ay, sx3(tmp[0], w), sy3(tmp[1], h), grid);
        }
        guard = 0;
        for (double nn = n0; nn <= n1 + 1e-9 && guard < 80; nn += step, guard++) {
            PlotMath.project(e0 - c3E, nn - c3N, baseZ, yaw, pitch, tmp);
            float ax = sx3(tmp[0], w), ay = sy3(tmp[1], h);
            PlotMath.project(e1 - c3E, nn - c3N, baseZ, yaw, pitch, tmp);
            cv.drawLine(ax, ay, sx3(tmp[0], w), sy3(tmp[1], h), grid);
        }
        PlotMath.project(e0 - c3E, n0 - c3N, baseZ, yaw, pitch, tmp);
        label(cv, "Cuadrícula " + scaleText(step), sx3(tmp[0], w), sy3(tmp[1], h) + 14 * d, 9.5f, GRID_TEXT, false, Paint.Align.CENTER);
    }

    /** Ícono de ejes como el de AutoCAD: E (X) rojo, N (Y) verde, Cota (Z) azul. */
    private void drawAxes(Canvas cv, int h) {
        float ox = 40 * d, oy = h - 44 * d, len = 26 * d;
        fill.setColor(Color.argb(150, 10, 16, 24));
        cv.drawCircle(ox, oy, len + 12 * d, fill);
        double[][] axes = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
        int[] colors = {Color.rgb(240, 80, 70), Color.rgb(90, 220, 110), Color.rgb(90, 150, 255)};
        String[] names = {"E", "N", "Z"};
        line.setPathEffect(null);
        line.setStrokeWidth(2.4f * d);
        for (int i = 0; i < 3; i++) {
            PlotMath.project(axes[i][0], axes[i][1], axes[i][2], yaw, pitch, tmp);
            float ex = ox + (float) tmp[0] * len, ey = oy - (float) tmp[1] * len;
            line.setColor(colors[i]);
            cv.drawLine(ox, oy, ex, ey, line);
            float lx = ox + (float) tmp[0] * (len + 8 * d), ly = oy - (float) tmp[1] * (len + 8 * d);
            label(cv, names[i], lx, ly + 4 * d, 11, colors[i], true, Paint.Align.CENTER);
        }
    }

    private void drawNorth3d(Canvas cv, int w) {
        PlotMath.project(0, 1, 0, yaw, pitch, tmp);
        float ux = (float) tmp[0], uy = (float) -tmp[1];
        float len = (float) Math.sqrt(ux * ux + uy * uy);
        float cx = w - 30 * d, cy = 42 * d, r = 17 * d;
        fill.setColor(Color.argb(150, 10, 16, 24));
        cv.drawCircle(cx, cy, r + 5 * d, fill);
        if (len < 0.15f) {
            label(cv, "N", cx, cy + 4 * d, 12, Color.WHITE, true, Paint.Align.CENTER);
            return;
        }
        ux /= len; uy /= len;
        drawArrow(cv, cx, cy, ux, uy, r * Math.max(0.55f, Math.min(1f, len)));
        label(cv, "N", cx + ux * (r + 10 * d), cy + uy * (r + 10 * d) + 4 * d, 12, Color.WHITE, true, Paint.Align.CENTER);
    }

    // ---------- común
    private void drawRuns(Canvas cv, int w, int h) {
        line.setPathEffect(null);
        line.setStrokeWidth(1.8f * d);
        int colorIndex = 0;
        for (PlotMath.Run r : runs) {
            int segs = r.closed ? r.idx.length : r.idx.length - 1;
            if (buf.length < segs * 4) buf = new float[Math.max(segs * 4, 64)];
            int k = 0;
            for (int s = 0; s < segs; s++) {
                int a = r.idx[s], b = r.idx[(s + 1) % r.idx.length];
                float x1 = sx[a], y1 = sy[a], x2 = sx[b], y2 = sy[b];
                if ((x1 < 0 && x2 < 0) || (y1 < 0 && y2 < 0) || (x1 > w && x2 > w) || (y1 > h && y2 > h)) continue;
                buf[k++] = x1; buf[k++] = y1; buf[k++] = x2; buf[k++] = y2;
            }
            line.setColor(lineMode == PlotMath.LINES_CODE ? CODE_COLORS[colorIndex % CODE_COLORS.length] : LINE);
            if (k > 0) cv.drawLines(buf, 0, k, line);
            colorIndex++;
        }
    }

    private void drawPoints(Canvas cv, int w, int h, int n, int[] drawOrder) {
        float cell = 64 * d, cellH = 16 * d;
        int cols = (int) (w / cell) + 2, rows = (int) (h / cellH) + 2;
        if (labelGrid.length < cols * rows) labelGrid = new boolean[cols * rows];
        java.util.Arrays.fill(labelGrid, 0, cols * rows, false);

        int visible = 0;
        for (int i = 0; i < n; i++) if (sx[i] >= -10 && sy[i] >= -10 && sx[i] <= w + 10 && sy[i] <= h + 10) visible++;
        boolean light = visible > 4000;
        float r = (light ? 2.2f : mode3d ? 3.8f : 3.2f) * d;
        line.setPathEffect(null);

        for (int k = 0; k < n; k++) {
            int i = drawOrder == null ? k : drawOrder[k];
            float x = sx[i], y = sy[i];
            if (x < -10 || y < -10 || x > w + 10 || y > h + 10) continue;
            PlotMath.PlotPoint p = pts.get(i);
            int c = pointColor(p);
            if (mode3d || light) {
                fill.setColor(c);
                cv.drawCircle(x, y, r, fill);
                if (!light) {
                    line.setColor(Color.argb(200, 0, 0, 0));
                    line.setStrokeWidth(1f * d);
                    cv.drawCircle(x, y, r, line);
                }
            } else {
                // Marca tipo AutoCAD: cruz con círculo.
                line.setColor(c);
                line.setStrokeWidth(1.4f * d);
                float a = r * 1.6f;
                cv.drawLine(x - a, y, x + a, y, line);
                cv.drawLine(x, y - a, x, y + a, line);
                cv.drawCircle(x, y, r, line);
            }
        }
        if (!showNames && !showZ && !showDesc) return;
        // Etiquetas: primero las de adelante; no se encima ninguna.
        for (int k = n - 1; k >= 0; k--) {
            int i = drawOrder == null ? n - 1 - k : drawOrder[k];
            float x = sx[i], y = sy[i];
            if (x < 0 || y < 0 || x > w || y > h) continue;
            int gx = (int) (x / cell), gy = (int) (y / cellH);
            int lines = (showNames ? 1 : 0) + (showZ ? 1 : 0) + (showDesc ? 1 : 0);
            boolean free = true;
            for (int j = 0; j < lines && free; j++) {
                int row = gy - 1 + j;
                if (row < 0 || row >= rows || gx >= cols) { free = false; break; }
                if (labelGrid[row * cols + gx] || (gx + 1 < cols && labelGrid[row * cols + gx + 1])) free = false;
            }
            if (!free) continue;
            for (int j = 0; j < lines; j++) {
                int row = gy - 1 + j;
                labelGrid[row * cols + gx] = true;
                if (gx + 1 < cols) labelGrid[row * cols + gx + 1] = true;
            }
            PlotMath.PlotPoint p = pts.get(i);
            float tx = x + 6 * d, ty = y - 5 * d;
            text.setShadowLayer(2.5f * d, 0, 0, Color.BLACK);
            if (showNames) {
                label(cv, p.name, tx, ty, 11, Color.WHITE, true, Paint.Align.LEFT);
                ty += 12.5f * d;
            }
            if (showZ && p.hasZ) {
                label(cv, PlotMath.fmt(p.z, 2), tx, ty, 10, Color.rgb(150, 235, 160), false, Paint.Align.LEFT);
                ty += 12f * d;
            }
            if (showDesc && !p.desc.isEmpty()) {
                label(cv, p.desc, tx, ty, 10, Color.rgb(255, 214, 120), false, Paint.Align.LEFT);
            }
            text.setShadowLayer(0, 0, 0, 0);
        }
    }

    private void drawMeasureLine(Canvas cv) {
        if (selA < 0 || selB < 0 || selA >= pts.size() || selB >= pts.size()) return;
        line.setPathEffect(dash);
        line.setColor(Color.rgb(255, 214, 10));
        line.setStrokeWidth(2.2f * d);
        cv.drawLine(sx[selA], sy[selA], sx[selB], sy[selB], line);
        line.setPathEffect(null);
    }

    private void drawSelection(Canvas cv) {
        line.setPathEffect(null);
        line.setStrokeWidth(2.6f * d);
        if (selA >= 0 && selA < pts.size()) {
            line.setColor(Color.rgb(90, 230, 140));
            cv.drawCircle(sx[selA], sy[selA], 11 * d, line);
            if (measureMode) label(cv, "A", sx[selA] - 15 * d, sy[selA] - 12 * d, 12, Color.rgb(90, 230, 140), true, Paint.Align.CENTER);
        }
        if (selB >= 0 && selB < pts.size()) {
            line.setColor(Color.rgb(255, 150, 60));
            cv.drawCircle(sx[selB], sy[selB], 11 * d, line);
            label(cv, "B", sx[selB] - 15 * d, sy[selB] - 12 * d, 12, Color.rgb(255, 150, 60), true, Paint.Align.CENTER);
        }
    }

    private void drawLegend(Canvas cv, int w, int h) {
        float bw = 10 * d, bh = Math.min(140 * d, h * 0.32f);
        float x = w - 22 * d, y = 92 * d;
        fill.setColor(Color.argb(150, 10, 16, 24));
        cv.drawRoundRect(new RectF(x - 52 * d, y - 22 * d, x + bw + 6 * d, y + bh + 22 * d), 6 * d, 6 * d, fill);
        int[] colors = {rampColor(1), rampColor(0.75), rampColor(0.5), rampColor(0.25), rampColor(0)};
        float[] stops = {0f, 0.25f, 0.5f, 0.75f, 1f};
        fill.setShader(new LinearGradient(0, y, 0, y + bh, colors, stops, Shader.TileMode.CLAMP));
        cv.drawRect(x, y, x + bw, y + bh, fill);
        fill.setShader(null);
        label(cv, "Cota", x + bw / 2, y - 9 * d, 9.5f, GRID_TEXT, true, Paint.Align.CENTER);
        label(cv, PlotMath.fmt(bounds.maxZ, 1), x - 4 * d, y + 8 * d, 9.5f, Color.WHITE, false, Paint.Align.RIGHT);
        label(cv, PlotMath.fmt(bounds.minZ, 1), x - 4 * d, y + bh, 9.5f, Color.WHITE, false, Paint.Align.RIGHT);
        if (mode3d && Math.abs(exaggeration - 1) > 1e-9)
            label(cv, "Z ×" + PlotMath.fmt(exaggeration, 0), x + bw / 2, y + bh + 15 * d, 9.5f, Color.rgb(255, 214, 10), true, Paint.Align.CENTER);
    }

    private int pointColor(PlotMath.PlotPoint p) {
        if (!colorByZ || !p.hasZ || bounds.zRange() <= 1e-9) return p.hasZ || !colorByZ ? Color.WHITE : Color.rgb(170, 178, 190);
        return rampColor((p.z - bounds.minZ) / bounds.zRange());
    }

    /** Azul (bajo) → celeste → verde → amarillo → rojo (alto). */
    static int rampColor(double t) {
        t = clamp(t, 0, 1);
        int[][] c = {{50, 100, 255}, {0, 200, 255}, {50, 220, 120}, {255, 214, 10}, {255, 70, 60}};
        double pos = t * 4;
        int i = Math.min(3, (int) Math.floor(pos));
        double f = pos - i;
        return Color.rgb((int) (c[i][0] + (c[i + 1][0] - c[i][0]) * f),
                (int) (c[i][1] + (c[i + 1][1] - c[i][1]) * f),
                (int) (c[i][2] + (c[i + 1][2] - c[i][2]) * f));
    }

    private void label(Canvas cv, String value, float x, float y, float sizeSp, int color, boolean bold, Paint.Align align) {
        text.setTextSize(sizeSp * d);
        text.setColor(color);
        text.setTextAlign(align);
        text.setFakeBoldText(bold);
        cv.drawText(value, x, y, text);
        text.setFakeBoldText(false);
    }

    private static double clamp(double v, double min, double max) {
        return v < min ? min : v > max ? max : v;
    }
}
