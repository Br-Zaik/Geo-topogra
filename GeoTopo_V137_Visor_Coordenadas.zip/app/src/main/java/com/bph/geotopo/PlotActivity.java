package com.bph.geotopo;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * V137: Visor de coordenadas. Pones o pegas puntos (Este, Norte, Cota) y la app los dibuja
 * en planta 2D o en 3D, como para revisar un diseño sin PC. Sin límite de puntos.
 */
public class PlotActivity extends BaseToolActivity implements PlotView.Listener {
    private static final String FILE_NAME = "visor_coordenadas.txt";
    private static final String SP = "geo_topo_plot_viewer";
    private static final int REQ_DXF = 7301;
    private static final int REQ_CSV = 7302;
    private static final double[] EXAGGERATIONS = {1, 2, 5, 10};
    /** Guarda en orden, uno tras otro, sin trabar la pantalla. */
    private static final java.util.concurrent.ExecutorService SAVER =
            java.util.concurrent.Executors.newSingleThreadExecutor();

    private final List<PlotMath.PlotPoint> points = new ArrayList<>();

    private PlotView plot;
    private View pageData, pageList, pageGraph;
    private Button tabData, tabList, tabGraph;
    private int currentPage;

    private EditText inName, inDesc, inEast, inNorth, inZ, pasteBox;
    private Button breakButton, orderButton;
    private boolean nextBreak;
    private int pasteOrder = PlotMath.ORDER_AUTO;
    private TextView pasteResult;

    private TextView listHeader;
    private PointAdapter adapter;

    private Button chip3d, chipMeasure, chipLines, chipExag;
    private LinearLayout row3d;
    private TextView infoBox;

    private boolean optNames, optZ, optDesc, optDist, optColor, optClose;
    private int optLines;
    private int exagIndex;

    private String pendingExport;

    // ------------------------------------------------------------ ciclo de vida
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        NativeUi.styleWindow(this);
        loadOptions();
        loadPoints();
        setContentView(buildScreen());
        showPage(points.isEmpty() ? 0 : 2);
    }

    @Override public void onContentChanged() {
        super.onContentChanged();
        // Además de las barras del sistema, deja espacio para el teclado (Android 15+).
        View content = findViewById(android.R.id.content);
        if (!(content instanceof ViewGroup) || ((ViewGroup) content).getChildCount() == 0) return;
        View root = ((ViewGroup) content).getChildAt(0);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top, bottom, left, right;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(android.view.WindowInsets.Type.systemBars()
                        | android.view.WindowInsets.Type.displayCutout());
                android.graphics.Insets ime = insets.getInsets(android.view.WindowInsets.Type.ime());
                top = bars.top; left = bars.left; right = bars.right;
                // Desde Android 15 la ventana ya no se achica sola con el teclado.
                bottom = Build.VERSION.SDK_INT >= 35 ? Math.max(bars.bottom, ime.bottom) : bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
                left = insets.getSystemWindowInsetLeft();
                right = insets.getSystemWindowInsetRight();
            }
            v.setPadding(left, top, right, bottom);
            return insets;
        });
        root.requestApplyInsets();
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (plot != null) plot.invalidate();
    }

    // ------------------------------------------------------------ pantalla
    private View buildScreen() {
        LinearLayout root = page("Visor de coordenadas", "Plano 2D y 3D de tus puntos");

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(dp(10), dp(8), dp(10), dp(6));
        tabs.setBackgroundColor(bgColor);
        tabData = tabButton("✍ Datos");
        tabList = tabButton("☰ Lista");
        tabGraph = tabButton("📐 Gráfico");
        tabData.setOnClickListener(v -> showPage(0));
        tabList.setOnClickListener(v -> showPage(1));
        tabGraph.setOnClickListener(v -> showPage(2));
        tabs.addView(tabData, tabParams());
        tabs.addView(tabList, tabParams());
        tabs.addView(tabGraph, tabParams());
        root.addView(tabs);

        FrameLayout pages = new FrameLayout(this);
        pageData = buildDataPage();
        pageList = buildListPage();
        pageGraph = buildGraphPage();
        pages.addView(pageData, matchParams());
        pages.addView(pageList, matchParams());
        pages.addView(pageGraph, matchParams());
        root.addView(pages, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    private FrameLayout.LayoutParams matchParams() {
        return new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private LinearLayout.LayoutParams tabParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    private Button tabButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        ResponsiveUi.configureCompactText(b, 13.5f, 10, 1);
        b.setPadding(dp(4), 0, dp(4), 0);
        return b;
    }

    private void styleChoice(Button b, boolean on) {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(11));
        if (on) {
            bg.setColor(accent);
            b.setTextColor(Color.WHITE);
        } else {
            bg.setColor(inputColor);
            bg.setStroke(dp(1), withAlpha(borderColor, 150));
            b.setTextColor(textColor);
        }
        b.setBackground(bg);
    }

    private void showPage(int index) {
        currentPage = index;
        pageData.setVisibility(index == 0 ? View.VISIBLE : View.GONE);
        pageList.setVisibility(index == 1 ? View.VISIBLE : View.GONE);
        pageGraph.setVisibility(index == 2 ? View.VISIBLE : View.GONE);
        styleChoice(tabData, index == 0);
        styleChoice(tabList, index == 1);
        styleChoice(tabGraph, index == 2);
        tabList.setText("☰ Lista (" + points.size() + ")");
        if (index != 0) hideKeyboard();
        if (index == 1) refreshList();
        if (index == 2) { plot.invalidate(); updateInfo(); }
    }

    private void hideKeyboard() {
        View focus = getCurrentFocus();
        if (focus == null) return;
        android.view.inputmethod.InputMethodManager imm =
                (android.view.inputmethod.InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(focus.getWindowToken(), 0);
        focus.clearFocus();
    }

    // ------------------------------------------------------------ página Datos
    private View buildDataPage() {
        LinearLayout c = vertical();

        // Agregar a mano
        LinearLayout manual = card();
        manual.addView(sectionTitle("✍ Agregar punto a mano"));
        inName = textInput("Ej: P1");
        inName.setText(PlotMath.nextName(points.isEmpty() ? "" : points.get(points.size() - 1).name));
        inDesc = textInput("Ej: galería");
        inEast = numberInput("Ej: 345678.123");
        inNorth = numberInput("Ej: 8654321.456");
        inZ = numberInput("Ej: 3500.25");
        LinearLayout r1 = horizontal();
        r1.addView(labeled("Punto", inName), weight());
        r1.addView(labeled("Descripción / código", inDesc), weight());
        manual.addView(r1);
        LinearLayout r2 = horizontal();
        r2.addView(labeled("Este (X)", inEast), weight());
        r2.addView(labeled("Norte (Y)", inNorth), weight());
        manual.addView(r2);
        LinearLayout r3 = horizontal();
        r3.addView(labeled("Cota (Z) · opcional", inZ), weight());
        breakButton = secondaryButton("");
        updateBreakButton();
        breakButton.setOnClickListener(v -> { nextBreak = !nextBreak; updateBreakButton(); });
        LinearLayout breakBox = vertical();
        TextView breakLabel = text("Línea", 12, true);
        breakLabel.setTextColor(subTextColor);
        breakBox.addView(breakLabel);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        bl.setMargins(0, 0, 0, 0);
        breakBox.addView(breakButton, bl);
        LinearLayout.LayoutParams bbl = weight();
        bbl.setMargins(dp(3), 0, dp(3), 0);
        r3.addView(breakBox, bbl);
        manual.addView(r3);
        Button add = primaryButton("＋ Agregar punto");
        add.setOnClickListener(v -> addManualPoint());
        manual.addView(add);
        manual.addView(small("Sin límite de puntos. «Línea: nueva» hace que este punto no se una con el anterior (otra galería, otro tramo)."));
        c.addView(manual);

        // Pegar desde Excel
        LinearLayout paste = card();
        paste.addView(sectionTitle("📋 Pegar desde Excel"));
        paste.addView(small("1. En Excel del celular selecciona tus columnas (Punto, Este, Norte, Cota, Descripción) y toca Copiar.\n"
                + "2. Vuelve aquí y toca «Pegar desde el portapapeles».\n"
                + "Sirve con o sin encabezado, coma o punto decimal. Una fila vacía empieza una línea nueva."));
        orderButton = secondaryButton("");
        updateOrderButton();
        orderButton.setOnClickListener(v -> chooseOrder());
        paste.addView(orderButton);
        Button fromClip = primaryButton("📋 Pegar desde el portapapeles");
        fromClip.setOnClickListener(v -> pasteFromClipboard());
        paste.addView(fromClip);
        paste.addView(small("O escribe / pega las filas aquí:"));
        pasteBox = textInput("P1  345678.12  8654321.45  3500.25\nP2  345690.50  8654330.00  3498.10");
        pasteBox.setSingleLine(false);
        pasteBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        pasteBox.setGravity(Gravity.TOP | Gravity.START);
        pasteBox.setMinLines(4);
        pasteBox.setMaxLines(9);
        pasteBox.setHorizontallyScrolling(false);
        pasteBox.setPadding(dp(10), dp(9), dp(10), dp(9));
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pl.setMargins(dp(3), 0, dp(3), dp(6));
        paste.addView(pasteBox, pl);
        Button fromBox = secondaryButton("Cargar lo escrito");
        fromBox.setOnClickListener(v -> loadText(pasteBox.getText().toString(), "lo escrito"));
        paste.addView(fromBox);
        pasteResult = resultBox("");
        pasteResult.setVisibility(View.GONE);
        paste.addView(pasteResult);
        c.addView(paste);

        // Traer de GeoTopo
        LinearLayout bring = card();
        bring.addView(sectionTitle("📥 Traer puntos de GeoTopo"));
        Button notebook = secondaryButton("Libreta de campo (Este, Norte, Cota)");
        notebook.setOnClickListener(v -> importNotebook());
        bring.addView(notebook);
        Button gps = secondaryButton("Puntos GPS guardados (pasan a UTM)");
        gps.setOnClickListener(v -> importGpsPoints());
        bring.addView(gps);
        c.addView(bring);

        // Exportar
        LinearLayout export = card();
        export.addView(sectionTitle("📤 Exportar"));
        Button copy = secondaryButton("Copiar tabla para Excel");
        copy.setOnClickListener(v -> copyTable());
        export.addView(copy);
        Button dxf = secondaryButton("Guardar DXF para AutoCAD");
        dxf.setOnClickListener(v -> saveDxf());
        export.addView(dxf);
        Button csv = secondaryButton("Guardar CSV");
        csv.setOnClickListener(v -> saveCsv());
        export.addView(csv);
        Button clear = secondaryButton("Borrar todos los puntos");
        clear.setTextColor(Color.rgb(255, 110, 100));
        clear.setOnClickListener(v -> confirmClearAll());
        export.addView(clear);
        export.addView(small("El DXF trae capas PUNTOS, NOMBRES, COTAS, DESCRIPCION y LINEAS en 3D."));
        c.addView(export);

        return scrollWith(c);
    }

    private void updateBreakButton() {
        breakButton.setText(nextBreak ? "Nueva ✓" : "Seguir");
        styleChoice(breakButton, nextBreak);
    }

    private void updateOrderButton() {
        orderButton.setText("Columnas: " + PlotMath.ORDER_LABELS[pasteOrder]);
    }

    private void chooseOrder() {
        new AlertDialog.Builder(this)
                .setTitle("Orden de las columnas")
                .setSingleChoiceItems(PlotMath.ORDER_LABELS, pasteOrder, (dialog, which) -> {
                    pasteOrder = which;
                    updateOrderButton();
                    dialog.dismiss();
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void addManualPoint() {
        double e = PlotMath.parseNumber(inEast.getText().toString());
        double n = PlotMath.parseNumber(inNorth.getText().toString());
        if (Double.isNaN(e)) { inEast.setError("Pon el Este"); inEast.requestFocus(); return; }
        if (Double.isNaN(n)) { inNorth.setError("Pon el Norte"); inNorth.requestFocus(); return; }
        String zRaw = inZ.getText().toString().trim();
        double z = zRaw.isEmpty() ? Double.NaN : PlotMath.parseNumber(zRaw);
        if (!zRaw.isEmpty() && Double.isNaN(z)) { inZ.setError("Cota no válida"); inZ.requestFocus(); return; }
        String name = inName.getText().toString().trim();
        if (name.isEmpty()) name = String.valueOf(points.size() + 1);
        PlotMath.PlotPoint p = new PlotMath.PlotPoint(name, e, n, Double.isNaN(z) ? 0 : z, !Double.isNaN(z),
                inDesc.getText().toString(), nextBreak && !points.isEmpty());
        points.add(p);
        savePoints();
        plot.dataChanged();
        plot.requestFit();
        tabList.setText("☰ Lista (" + points.size() + ")");
        showToast(name + " agregado · " + points.size() + " puntos");
        inName.setText(PlotMath.nextName(name));
        inEast.setText("");
        inNorth.setText("");
        inZ.setText("");
        nextBreak = false;
        updateBreakButton();
        inEast.requestFocus();
    }

    private void pasteFromClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        String value = null;
        try {
            if (cm != null && cm.hasPrimaryClip()) {
                ClipData clip = cm.getPrimaryClip();
                if (clip != null && clip.getItemCount() > 0) {
                    CharSequence cs = clip.getItemAt(0).coerceToText(this);
                    if (cs != null) value = cs.toString();
                }
            }
        } catch (Exception ignored) { }
        if (value == null || value.trim().isEmpty()) {
            showResult("El portapapeles está vacío. Copia primero las celdas en Excel.", false);
            return;
        }
        loadText(value, "el portapapeles");
    }

    /** Lee el texto en segundo plano (puede tener miles de filas). */
    private void loadText(String raw, String source) {
        if (raw == null || raw.trim().isEmpty()) {
            showResult("No hay nada escrito para cargar.", false);
            return;
        }
        final int order = pasteOrder;
        final int first = points.size() + 1;
        showResult("Leyendo " + source + "…", true);
        new Thread(() -> {
            final PlotMath.ParseResult r = PlotMath.parse(raw, order, first);
            runOnUiThread(() -> {
                if (isFinishing()) return;
                StringBuilder sb = new StringBuilder();
                if (r.points.isEmpty()) {
                    sb.append("No se encontraron puntos en ").append(source).append(".");
                    if (!r.problems.isEmpty()) sb.append('\n').append(join(r.problems));
                    sb.append("\nRevisa que tenga Este y Norte, o elige el orden de columnas.");
                    showResult(sb.toString(), false);
                    return;
                }
                sb.append("✓ ").append(r.points.size()).append(" puntos leídos de ").append(source).append('.');
                if (!r.layout.isEmpty()) sb.append("\nColumnas: ").append(r.layout);
                if (r.ignored > 0) sb.append("\nFilas no leídas: ").append(r.ignored).append('\n').append(join(r.problems));
                showResult(sb.toString(), r.ignored == 0);
                importPoints(r.points);
            });
        }).start();
    }

    private static String join(List<String> list) {
        StringBuilder sb = new StringBuilder();
        for (String s : list) { if (sb.length() > 0) sb.append('\n'); sb.append("• ").append(s); }
        return sb.toString();
    }

    private void showResult(String msg, boolean ok) {
        pasteResult.setVisibility(View.VISIBLE);
        pasteResult.setText(msg);
        pasteResult.setTextColor(ok ? textColor : Color.rgb(255, 190, 90));
    }

    private void importPoints(List<PlotMath.PlotPoint> incoming) {
        if (incoming == null || incoming.isEmpty()) return;
        if (points.isEmpty()) { applyImport(incoming, false); return; }
        new AlertDialog.Builder(this)
                .setTitle("Ya tienes " + points.size() + " puntos")
                .setMessage("¿Qué hago con los " + incoming.size() + " puntos nuevos?")
                .setPositiveButton("Agregar", (d, w) -> applyImport(incoming, false))
                .setNegativeButton("Reemplazar todo", (d, w) -> applyImport(incoming, true))
                .setNeutralButton("Cancelar", null)
                .show();
    }

    private void applyImport(List<PlotMath.PlotPoint> incoming, boolean replace) {
        if (replace) points.clear();
        else if (!points.isEmpty()) incoming.get(0).breakBefore = true;
        points.addAll(incoming);
        savePoints();
        plot.clearSelection();
        plot.dataChanged();
        plot.requestFit();
        inName.setText(PlotMath.nextName(points.get(points.size() - 1).name));
        showToast(points.size() + " puntos en el visor");
        showPage(2);
    }

    private void importNotebook() {
        List<NotebookStore.Entry> entries = NotebookStore.load(this);
        List<PlotMath.PlotPoint> list = new ArrayList<>();
        int skipped = 0, k = points.size() + 1;
        for (NotebookStore.Entry e : entries) {
            double east = PlotMath.parseNumber(e.east), north = PlotMath.parseNumber(e.north);
            if (Double.isNaN(east) || Double.isNaN(north)) { skipped++; continue; }
            double z = PlotMath.parseNumber(e.elevation);
            String name = e.code.isEmpty() ? String.valueOf(k) : e.code;
            String desc = !e.description.isEmpty() ? e.description : e.type;
            list.add(new PlotMath.PlotPoint(name, east, north, Double.isNaN(z) ? 0 : z, !Double.isNaN(z), desc, false));
            k++;
        }
        if (list.isEmpty()) {
            showResult("La libreta de campo no tiene puntos con Este y Norte.", false);
            return;
        }
        showResult("✓ " + list.size() + " puntos de la libreta" + (skipped > 0 ? " (" + skipped + " sin coordenadas)" : "") + ".", true);
        importPoints(list);
    }

    private void importGpsPoints() {
        JSONArray arr;
        try {
            arr = new JSONArray(getSharedPreferences("geo_topo_gps_points", MODE_PRIVATE).getString("points_json", "[]"));
        } catch (Exception e) {
            arr = new JSONArray();
        }
        List<PlotMath.PlotPoint> list = new ArrayList<>();
        int zone = 0;
        boolean south = false;
        int k = points.size() + 1;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            double lat = o.optDouble("latitude", Double.NaN), lon = o.optDouble("longitude", Double.NaN);
            if (Double.isNaN(lat) || Double.isNaN(lon)) continue;
            CoordinateUtils.Utm u = zone == 0 ? CoordinateUtils.toUtm(lat, lon) : CoordinateUtils.toUtm(lat, lon, zone);
            if (u == null || !u.valid) continue;
            if (zone == 0) { zone = u.zone; south = u.south; }
            double alt = o.isNull("altitude") ? Double.NaN : o.optDouble("altitude", Double.NaN);
            String name = o.optString("name", "").trim();
            if (name.isEmpty()) name = String.valueOf(k);
            list.add(new PlotMath.PlotPoint(name, u.easting, u.northing, Double.isNaN(alt) ? 0 : alt,
                    !Double.isNaN(alt), o.optString("description", ""), false));
            k++;
        }
        if (list.isEmpty()) {
            showResult("No hay puntos GPS guardados todavía.", false);
            return;
        }
        showResult("✓ " + list.size() + " puntos GPS en UTM zona " + zone + (south ? " Sur" : " Norte")
                + ". La cota del GPS del celular es aproximada.", true);
        importPoints(list);
    }

    private void copyTable() {
        if (points.isEmpty()) { showToast("No hay puntos para copiar."); return; }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Puntos GeoTopo", PlotMath.toTable(points)));
        showToast("Tabla copiada: pégala en Excel");
    }

    private void saveDxf() {
        if (points.isEmpty()) { showToast("No hay puntos para guardar."); return; }
        pendingExport = PlotMath.toDxf(points, plot.getRuns());
        createDocument("application/dxf", "GeoTopo_plano_" + stamp() + ".dxf", REQ_DXF);
    }

    private void saveCsv() {
        if (points.isEmpty()) { showToast("No hay puntos para guardar."); return; }
        StringBuilder sb = new StringBuilder("Punto,Este,Norte,Cota,Descripcion\n");
        for (PlotMath.PlotPoint p : points) {
            sb.append(csv(p.name)).append(',').append(PlotMath.fmt(p.east, 3)).append(',')
              .append(PlotMath.fmt(p.north, 3)).append(',').append(p.hasZ ? PlotMath.fmt(p.z, 3) : "")
              .append(',').append(csv(p.desc)).append('\n');
        }
        pendingExport = sb.toString();
        createDocument("text/csv", "GeoTopo_puntos_" + stamp() + ".csv", REQ_CSV);
    }

    private static String csv(String v) {
        if (v.contains(",") || v.contains("\"")) return "\"" + v.replace("\"", "\"\"") + "\"";
        return v;
    }

    private static String stamp() {
        return new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date());
    }

    private void createDocument(String mime, String title, int request) {
        try {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType(mime);
            intent.putExtra(Intent.EXTRA_TITLE, title);
            startActivityForResult(intent, request);
        } catch (Exception e) {
            showToast("Este celular no permite elegir dónde guardar.");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode != REQ_DXF && requestCode != REQ_CSV) || resultCode != RESULT_OK
                || data == null || data.getData() == null || pendingExport == null) return;
        try {
            Uri uri = data.getData();
            OutputStream out = getContentResolver().openOutputStream(uri);
            if (out == null) throw new IllegalStateException();
            out.write(pendingExport.getBytes(StandardCharsets.UTF_8));
            out.close();
            showToast(requestCode == REQ_DXF ? "DXF guardado. Ábrelo en AutoCAD." : "CSV guardado.");
        } catch (Exception e) {
            showToast("No se pudo guardar el archivo.");
        }
        pendingExport = null;
    }

    private void confirmClearAll() {
        if (points.isEmpty()) { showToast("No hay puntos."); return; }
        new AlertDialog.Builder(this)
                .setTitle("¿Borrar los " + points.size() + " puntos?")
                .setMessage("Se borran solo del visor. No se puede deshacer.")
                .setPositiveButton("Borrar", (d, w) -> {
                    points.clear();
                    savePoints();
                    plot.clearSelection();
                    plot.dataChanged();
                    plot.requestFit();
                    inName.setText("1");
                    showPage(0);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ------------------------------------------------------------ página Lista
    private View buildListPage() {
        LinearLayout box = vertical();
        box.setBackgroundColor(bgColor);
        box.setPadding(dp(10), dp(4), dp(10), 0);
        listHeader = small("");
        box.addView(listHeader);
        ListView list = new ListView(this);
        list.setDivider(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        list.setDividerHeight(dp(7));
        list.setSelector(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        list.setFastScrollEnabled(true);
        list.setClipToPadding(false);
        list.setPadding(0, 0, 0, dp(20));
        adapter = new PointAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> editPoint(position));
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            showPage(2);
            plot.focusPoint(position);
            return true;
        });
        box.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return box;
    }

    private void refreshList() {
        if (adapter == null) return;
        listHeader.setText(points.isEmpty()
                ? "Todavía no hay puntos. Agrégalos en «Datos»."
                : points.size() + " puntos · Toca uno para editar o borrar · Mantén presionado para verlo en el gráfico.");
        adapter.notifyDataSetChanged();
        tabList.setText("☰ Lista (" + points.size() + ")");
    }

    private final class PointAdapter extends BaseAdapter {
        @Override public int getCount() { return points.size(); }
        @Override public Object getItem(int position) { return points.get(position); }
        @Override public long getItemId(int position) { return position; }

        @Override public View getView(int position, View convertView, ViewGroup parent) {
            LinearLayout row;
            TextView title, sub;
            if (convertView instanceof LinearLayout && convertView.getTag() instanceof TextView[]) {
                row = (LinearLayout) convertView;
                TextView[] h = (TextView[]) convertView.getTag();
                title = h[0]; sub = h[1];
            } else {
                row = vertical();
                row.setPadding(dp(12), dp(9), dp(12), dp(9));
                GradientDrawable bg = new GradientDrawable();
                bg.setColor(cardColor);
                bg.setCornerRadius(dp(11));
                bg.setStroke(dp(1), withAlpha(borderColor, 70));
                row.setBackground(bg);
                title = text("", 15, true);
                sub = text("", 12, false);
                sub.setTextColor(subTextColor);
                row.addView(title);
                row.addView(sub);
                row.setTag(new TextView[]{title, sub});
                row.setLayoutParams(new android.widget.AbsListView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            PlotMath.PlotPoint p = points.get(position);
            String head = (position + 1) + ".  " + p.name + (p.desc.isEmpty() ? "" : "   · " + p.desc);
            if (p.breakBefore) head += "   ↳ línea nueva";
            title.setText(head);
            sub.setText("E " + PlotMath.fmt(p.east, 3) + "    N " + PlotMath.fmt(p.north, 3)
                    + "    Z " + (p.hasZ ? PlotMath.fmt(p.z, 3) : "—"));
            return row;
        }
    }

    private void editPoint(int index) {
        if (index < 0 || index >= points.size()) return;
        PlotMath.PlotPoint p = points.get(index);
        LinearLayout form = vertical();
        form.setPadding(dp(18), dp(8), dp(18), 0);
        EditText name = textInput("Punto");
        name.setText(p.name);
        EditText east = numberInput("Este");
        east.setText(PlotMath.fmt(p.east, 4));
        EditText north = numberInput("Norte");
        north.setText(PlotMath.fmt(p.north, 4));
        EditText z = numberInput("Cota (vacío = sin cota)");
        z.setText(p.hasZ ? PlotMath.fmt(p.z, 4) : "");
        EditText desc = textInput("Descripción / código");
        desc.setText(p.desc);
        form.addView(dialogField("Punto", name));
        form.addView(dialogField("Este (X)", east));
        form.addView(dialogField("Norte (Y)", north));
        form.addView(dialogField("Cota (Z)", z));
        form.addView(dialogField("Descripción / código", desc));
        CheckBox br = new CheckBox(this);
        br.setText("Empieza una línea nueva (no se une con el anterior)");
        br.setTextColor(Color.rgb(225, 232, 240));
        br.setChecked(p.breakBefore);
        form.addView(br);
        ScrollView sc = new ScrollView(this);
        sc.addView(form);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Editar punto " + (index + 1))
                .setView(sc)
                .setPositiveButton("Guardar", null)
                .setNeutralButton("Eliminar", (d, w) -> confirmDelete(index))
                .setNegativeButton("Cancelar", null)
                .create();
        dialog.setOnShowListener(di -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            double e = PlotMath.parseNumber(east.getText().toString());
            double n = PlotMath.parseNumber(north.getText().toString());
            String zr = z.getText().toString().trim();
            double zz = zr.isEmpty() ? Double.NaN : PlotMath.parseNumber(zr);
            if (Double.isNaN(e)) { east.setError("Este no válido"); return; }
            if (Double.isNaN(n)) { north.setError("Norte no válido"); return; }
            if (!zr.isEmpty() && Double.isNaN(zz)) { z.setError("Cota no válida"); return; }
            String nm = name.getText().toString().trim();
            p.name = nm.isEmpty() ? String.valueOf(index + 1) : PlotMath.clean(nm);
            p.east = e;
            p.north = n;
            p.hasZ = !Double.isNaN(zz);
            p.z = p.hasZ ? zz : 0;
            p.desc = PlotMath.clean(desc.getText().toString());
            p.breakBefore = br.isChecked() && index > 0;
            savePoints();
            plot.dataChanged();
            refreshList();
            dialog.dismiss();
        }));
        dialog.show();
    }

    private View dialogField(String label, EditText input) {
        LinearLayout box = vertical();
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(Color.rgb(190, 204, 220));
        t.setTextSize(12);
        box.addView(t);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        lp.setMargins(0, dp(2), 0, dp(8));
        box.addView(input, lp);
        return box;
    }

    private void confirmDelete(int index) {
        if (index < 0 || index >= points.size()) return;
        new AlertDialog.Builder(this)
                .setTitle("¿Eliminar " + points.get(index).name + "?")
                .setPositiveButton("Eliminar", (d, w) -> {
                    points.remove(index);
                    savePoints();
                    plot.clearSelection();
                    plot.dataChanged();
                    refreshList();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ------------------------------------------------------------ página Gráfico
    private View buildGraphPage() {
        LinearLayout box = vertical();
        box.setBackgroundColor(bgColor);

        LinearLayout chips = chipRow();
        chip3d = chip("", v -> toggle3d());
        Button fit = chip("⤢ Encuadrar", v -> plot.zoomExtents());
        chipMeasure = chip("📏 Medir", v -> toggleMeasure());
        chipLines = chip("", v -> cycleLines());
        Button view = chip("👁 Ver…", v -> chooseVisible());
        chips.addView(chip3d);
        chips.addView(fit);
        chips.addView(chipMeasure);
        chips.addView(chipLines);
        chips.addView(view);
        box.addView(wrapChips(chips));

        row3d = chipRow();
        row3d.addView(chip("Planta", v -> plot.setView(PlotView.VIEW_TOP)));
        row3d.addView(chip("Isométrico", v -> plot.setView(PlotView.VIEW_ISO)));
        row3d.addView(chip("Frente (S)", v -> plot.setView(PlotView.VIEW_FRONT)));
        row3d.addView(chip("Lateral (E)", v -> plot.setView(PlotView.VIEW_SIDE)));
        chipExag = chip("", v -> cycleExaggeration());
        row3d.addView(chipExag);
        box.addView(wrapChips(row3d));

        plot = new PlotView(this);
        plot.setPoints(points);
        plot.setListener(this);
        plot.setOptions(optNames, optZ, optDesc, optDist, optColor);
        plot.setLines(optLines, optClose);
        plot.setExaggeration(EXAGGERATIONS[exagIndex]);
        box.addView(plot, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        infoBox = new TextView(this);
        infoBox.setTextColor(Color.rgb(232, 240, 248));
        ResponsiveUi.configureText(infoBox, 12.5f);
        infoBox.setLineSpacing(0, 1.12f);
        infoBox.setPadding(dp(14), dp(9), dp(14), dp(10));
        infoBox.setBackgroundColor(Color.rgb(12, 18, 26));
        infoBox.setTextIsSelectable(true);
        box.addView(infoBox, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        refreshChips();
        return box;
    }

    private LinearLayout chipRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(4), dp(8), dp(4));
        return row;
    }

    private View wrapChips(LinearLayout row) {
        HorizontalScrollView h = new HorizontalScrollView(this);
        h.setHorizontalScrollBarEnabled(false);
        h.setFillViewport(true);
        h.addView(row);
        return h;
    }

    private Button chip(String label, View.OnClickListener click) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(12.5f);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(12), 0, dp(12), 0);
        b.setOnClickListener(click);
        styleChoice(b, false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38));
        lp.setMargins(dp(3), 0, dp(3), 0);
        b.setLayoutParams(lp);
        return b;
    }

    private void refreshChips() {
        boolean three = plot.isMode3d();
        chip3d.setText(three ? "🗺 Ver 2D" : "🧊 Ver 3D");
        styleChoice(chip3d, three);
        styleChoice(chipMeasure, plot.isMeasureMode());
        chipMeasure.setText(plot.isMeasureMode() ? "📏 Midiendo ✕" : "📏 Medir");
        String[] lines = {"Sin líneas", "Líneas: en orden", "Líneas: por código"};
        chipLines.setText(lines[optLines] + (optClose && optLines != PlotMath.LINES_NONE ? " ⟲" : ""));
        styleChoice(chipLines, optLines != PlotMath.LINES_NONE);
        chipExag.setText("Altura ×" + PlotMath.fmt(EXAGGERATIONS[exagIndex], 0));
        styleChoice(chipExag, exagIndex > 0);
        View wrap = (View) row3d.getParent();
        if (wrap != null) wrap.setVisibility(three ? View.VISIBLE : View.GONE);
    }

    private void toggle3d() {
        plot.setMode3d(!plot.isMode3d());
        refreshChips();
        updateInfo();
    }

    private void toggleMeasure() {
        plot.setMeasureMode(!plot.isMeasureMode());
        refreshChips();
        updateInfo();
    }

    private void cycleLines() {
        optLines = (optLines + 1) % 3;
        plot.setLines(optLines, optClose);
        saveOptions();
        refreshChips();
        updateInfo();
        String[] msg = {"Puntos sueltos, sin líneas", "Une los puntos en el orden de la lista",
                "Une los puntos que tienen la misma descripción (código)"};
        showToast(msg[optLines]);
    }

    private void cycleExaggeration() {
        exagIndex = (exagIndex + 1) % EXAGGERATIONS.length;
        plot.setExaggeration(EXAGGERATIONS[exagIndex]);
        saveOptions();
        refreshChips();
    }

    private void chooseVisible() {
        final String[] items = {"Nombres de puntos", "Cotas", "Descripción / código", "Distancias en las líneas",
                "Colores por cota", "Cerrar las líneas (polígono)"};
        final boolean[] checked = {optNames, optZ, optDesc, optDist, optColor, optClose};
        new AlertDialog.Builder(this)
                .setTitle("¿Qué mostrar?")
                .setMultiChoiceItems(items, checked, (d, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton("Listo", (d, w) -> {
                    optNames = checked[0]; optZ = checked[1]; optDesc = checked[2];
                    optDist = checked[3]; optColor = checked[4]; optClose = checked[5];
                    plot.setOptions(optNames, optZ, optDesc, optDist, optColor);
                    plot.setLines(optLines, optClose);
                    saveOptions();
                    refreshChips();
                    updateInfo();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    @Override public void onSelectionChanged() {
        updateInfo();
    }

    private void updateInfo() {
        if (infoBox == null || plot == null) return;
        int a = plot.getSelA(), b = plot.getSelB();
        if (plot.isMeasureMode()) {
            if (a < 0) { infoBox.setText("📏 Medir: toca el punto A."); return; }
            if (b < 0) { infoBox.setText("📏 A = " + points.get(a).name + ". Ahora toca el punto B."); return; }
            infoBox.setText(measureText(points.get(a), points.get(b)));
            return;
        }
        if (a >= 0 && a < points.size()) {
            PlotMath.PlotPoint p = points.get(a);
            StringBuilder sb = new StringBuilder();
            sb.append("● ").append(p.name).append("   (").append(a + 1).append(" de ").append(points.size()).append(")\n");
            sb.append("Este: ").append(PlotMath.fmt(p.east, 3)).append("    Norte: ").append(PlotMath.fmt(p.north, 3));
            sb.append("\nCota: ").append(p.hasZ ? PlotMath.fmt(p.z, 3) : "sin cota");
            if (!p.desc.isEmpty()) sb.append("    Desc.: ").append(p.desc);
            infoBox.setText(sb.toString());
            return;
        }
        infoBox.setText(summaryText());
    }

    private String measureText(PlotMath.PlotPoint a, PlotMath.PlotPoint b) {
        double dh = PlotMath.horizontal(a, b);
        double az = PlotMath.azimuth(a, b);
        StringBuilder sb = new StringBuilder();
        sb.append("📏 ").append(a.name).append(" → ").append(b.name).append('\n');
        sb.append("Dist. horizontal: ").append(PlotMath.fmt(dh, 3)).append(" m");
        if (a.hasZ && b.hasZ) {
            double dz = b.z - a.z;
            double di = Math.sqrt(dh * dh + dz * dz);
            sb.append("    Inclinada: ").append(PlotMath.fmt(di, 3)).append(" m\n");
            sb.append("Desnivel: ").append(String.format(Locale.US, "%+.3f", dz)).append(" m");
            if (dh > 1e-9) {
                double pct = dz / dh * 100;
                double ang = Math.toDegrees(Math.atan2(dz, dh));
                sb.append("    Pendiente: ").append(String.format(Locale.US, "%+.2f", pct)).append(" %  (")
                  .append(ang < 0 ? "-" : "+").append(PlotMath.dms(ang)).append(")");
            }
        } else {
            sb.append("\n(sin cota en uno de los puntos)");
        }
        if (dh > 1e-9) {
            sb.append("\nAzimut: ").append(PlotMath.dms(az)).append("    Rumbo: ").append(PlotMath.bearing(az));
        }
        sb.append("\nΔE: ").append(String.format(Locale.US, "%+.3f", b.east - a.east))
          .append("    ΔN: ").append(String.format(Locale.US, "%+.3f", b.north - a.north));
        return sb.toString();
    }

    private String summaryText() {
        if (points.isEmpty()) return "Sin puntos. Ve a «Datos» para agregar o pegar coordenadas.";
        PlotMath.Bounds bd = PlotMath.bounds(points);
        StringBuilder sb = new StringBuilder();
        sb.append(points.size()).append(" puntos");
        List<PlotMath.Run> runs = plot.getRuns();
        if (!runs.isEmpty()) sb.append(" · ").append(runs.size()).append(runs.size() == 1 ? " línea" : " líneas");
        sb.append("\nAncho (E): ").append(PlotMath.fmt(bd.maxE - bd.minE, 2)).append(" m    Largo (N): ")
          .append(PlotMath.fmt(bd.maxN - bd.minN, 2)).append(" m");
        if (bd.withZ > 0) sb.append("\nCota: ").append(PlotMath.fmt(bd.minZ, 2)).append(" a ")
                .append(PlotMath.fmt(bd.maxZ, 2)).append("  (desnivel ").append(PlotMath.fmt(bd.zRange(), 2)).append(" m)");
        double area = 0, per = 0, len = 0;
        for (PlotMath.Run r : runs) {
            if (r.closed) { area += PlotMath.area(points, r.idx); per += PlotMath.length(points, r.idx, true); }
            else len += PlotMath.length(points, r.idx, false);
        }
        if (area > 0) sb.append("\nÁrea: ").append(PlotMath.fmt(area, 2)).append(" m² (")
                .append(PlotMath.fmt(area / 10000, 4)).append(" ha)    Perímetro: ").append(PlotMath.fmt(per, 2)).append(" m");
        if (len > 0) sb.append("\nLongitud de líneas: ").append(PlotMath.fmt(len, 2)).append(" m");
        sb.append("\nToca un punto para ver sus datos.");
        return sb.toString();
    }

    // ------------------------------------------------------------ guardar
    private File dataFile() {
        return new File(getFilesDir(), FILE_NAME);
    }

    private void loadPoints() {
        points.clear();
        File f = dataFile();
        if (!f.exists()) return;
        try {
            InputStream in = new FileInputStream(f);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int r;
            while ((r = in.read(buf)) > 0) bos.write(buf, 0, r);
            in.close();
            points.addAll(PlotMath.deserialize(new String(bos.toByteArray(), StandardCharsets.UTF_8)));
        } catch (Exception ignored) { }
    }

    private void savePoints() {
        final String raw = PlotMath.serialize(points);
        final File f = dataFile();
        SAVER.execute(() -> {
            try {
                File tmp = new File(f.getParentFile(), FILE_NAME + ".tmp");
                FileOutputStream out = new FileOutputStream(tmp);
                out.write(raw.getBytes(StandardCharsets.UTF_8));
                out.close();
                if (!tmp.renameTo(f)) {
                    FileOutputStream direct = new FileOutputStream(f);
                    direct.write(raw.getBytes(StandardCharsets.UTF_8));
                    direct.close();
                    //noinspection ResultOfMethodCallIgnored
                    tmp.delete();
                }
            } catch (Exception ignored) { }
        });
    }

    private void loadOptions() {
        SharedPreferences sp = getSharedPreferences(SP, MODE_PRIVATE);
        optNames = sp.getBoolean("names", true);
        optZ = sp.getBoolean("z", true);
        optDesc = sp.getBoolean("desc", false);
        optDist = sp.getBoolean("dist", false);
        optColor = sp.getBoolean("color", true);
        optClose = sp.getBoolean("close", false);
        optLines = Math.max(0, Math.min(2, sp.getInt("lines", PlotMath.LINES_ORDER)));
        exagIndex = Math.max(0, Math.min(EXAGGERATIONS.length - 1, sp.getInt("exag", 0)));
    }

    private void saveOptions() {
        getSharedPreferences(SP, MODE_PRIVATE).edit()
                .putBoolean("names", optNames).putBoolean("z", optZ).putBoolean("desc", optDesc)
                .putBoolean("dist", optDist).putBoolean("color", optColor).putBoolean("close", optClose)
                .putInt("lines", optLines).putInt("exag", exagIndex)
                .apply();
    }
}
