package com.bph.geotopo;

import android.Manifest;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class TrackActivity extends BaseToolActivity {
    private static final int REQ_LOCATION = 9540;
    private static final int REQ_NOTIFICATION = 9541;
    private static final int REQ_EXPORT_CSV = 9542;
    private static final int REQ_EXPORT_GPX = 9543;
    private static final String KEY_POIS = "track_pois";

    private TextView stateLabel;
    private TextView distanceValue;
    private TextView avgValue;
    private TextView gainValue;
    private TextView pointsValue;
    private TextView autoSaveLabel;
    private TrackStatusView statusView;
    private TrackMapView mapView;
    private Button mainActionButton;
    private Button stopButton;
    private Button poiButton;
    private String pendingExport;
    private boolean receiverRegistered;
    private boolean screenStarted;

    private final Handler tickerHandler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (!screenStarted) return;
            refreshClockOnly();
            tickerHandler.postDelayed(this, 1000L);
        }
    };

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { refresh(); }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();

        LinearLayout root = vertical();
        root.setBackgroundColor(bgColor);
        root.addView(trackTopBar());

        LinearLayout content = vertical();
        content.addView(buildInfoCard());
        content.addView(buildStatusCard());
        content.addView(buildMapCard());
        content.addView(buildExportCard());

        autoSaveLabel = text("☁  Se guarda automáticamente con cada punto GPS", 11, false);
        autoSaveLabel.setTextColor(withAlpha(subTextColor, 190));
        autoSaveLabel.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        saveLp.setMargins(dp(4), dp(2), dp(4), dp(10));
        autoSaveLabel.setLayoutParams(saveLp);
        content.addView(autoSaveLabel);

        root.addView(scrollWith(content), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        refresh();
    }

    private LinearLayout trackTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(8), dp(8), dp(8));
        bar.setBackgroundColor(barColor);

        Button back = new Button(this);
        back.setText("‹");
        back.setTextSize(30);
        back.setTextColor(Color.WHITE);
        back.setBackgroundColor(Color.TRANSPARENT);
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(50), dp(50)));

        LinearLayout titles = vertical();
        TextView title = text("Registro de recorrido GPS", 20, true);
        title.setTextColor(Color.WHITE);
        titles.addView(title);
        TextView sub = text("Seguimiento iniciado por el usuario con notificación permanente", 12, false);
        sub.setTextColor(Color.rgb(215, 228, 240));
        sub.setMaxLines(2);
        titles.addView(sub);
        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView info = text("i", 18, true);
        info.setTextColor(accent);
        info.setGravity(Gravity.CENTER);
        GradientDrawable infoBg = new GradientDrawable();
        infoBg.setColor(Color.TRANSPARENT);
        infoBg.setShape(GradientDrawable.OVAL);
        infoBg.setStroke(dp(2), accent);
        info.setBackground(infoBg);
        info.setOnClickListener(v -> showTrackInfo());
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(dp(42), dp(42));
        infoLp.setMargins(dp(5), 0, dp(4), 0);
        bar.addView(info, infoLp);
        return bar;
    }

    private View buildInfoCard() {
        LinearLayout box = card();
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(14), dp(14), dp(14), dp(14));

        TextView icon = text("⌖", 24, true);
        icon.setTextColor(accent);
        icon.setGravity(Gravity.CENTER);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setColor(withAlpha(accent, themeMode == 0 ? 20 : 38));
        iconBg.setCornerRadius(dp(26));
        iconBg.setStroke(dp(1), accent);
        icon.setBackground(iconBg);
        box.addView(icon, new LinearLayout.LayoutParams(dp(54), dp(54)));

        LinearLayout labels = vertical();
        labels.setPadding(dp(13), 0, dp(3), 0);
        TextView msg = text("Inicia el recorrido antes de caminar. Android mostrará una notificación y GeoTopo seguirá registrando aun con la pantalla apagada.", 13, false);
        msg.setTextColor(subTextColor);
        msg.setLineSpacing(0, 1.13f);
        labels.addView(msg);
        TextView privacy = text("El registro solo se activa al pulsar Iniciar y finaliza al pulsar Detener.", 11, false);
        privacy.setTextColor(withAlpha(subTextColor, 190));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pp.setMargins(0, dp(6), 0, 0);
        privacy.setLayoutParams(pp);
        labels.addView(privacy);
        box.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return box;
    }

    private View buildStatusCard() {
        LinearLayout box = card();
        box.setPadding(dp(12), dp(12), dp(12), dp(12));

        LinearLayout header = horizontal();
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(text("Estado del registro", 18, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        stateLabel = text("● DETENIDO", 13, true);
        ResponsiveUi.configureCompactText(stateLabel, 13, 9, 1);
        stateLabel.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        header.addView(stateLabel, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        box.addView(header);

        LinearLayout dashboard = horizontal();
        dashboard.setGravity(Gravity.CENTER_VERTICAL);
        statusView = new TrackStatusView(this);
        int statusSize = ResponsiveUi.isNarrow(this) ? dp(124) : dp(158);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(statusSize, statusSize);
        statusLp.setMargins(dp(2), dp(2), dp(8), dp(4));
        dashboard.addView(statusView, statusLp);

        LinearLayout metrics = vertical();
        LinearLayout row1 = horizontal();
        distanceValue = text("0.00 m", 18, true);
        row1.addView(metricCard("⌁", "Distancia", distanceValue), weight());
        avgValue = text("0.00 km/h", 18, true);
        row1.addView(metricCard("◴", "Velocidad media", avgValue), weight());
        metrics.addView(row1);
        LinearLayout row2 = horizontal();
        gainValue = text("0.0 m", 18, true);
        row2.addView(metricCard("△", "Desnivel +", gainValue), weight());
        pointsValue = text("0", 18, true);
        row2.addView(metricCard("○", "Puntos", pointsValue), weight());
        metrics.addView(row2);
        dashboard.addView(metrics, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        box.addView(dashboard);

        mainActionButton = primaryButton("▶  Iniciar nuevo recorrido");
        mainActionButton.setOnClickListener(v -> {
            SharedPreferences sp = getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE);
            if (sp.getBoolean(TrackService.KEY_RUNNING, false)) togglePause(); else startTrack();
        });
        LinearLayout.LayoutParams mainLp = (LinearLayout.LayoutParams) mainActionButton.getLayoutParams();
        mainLp.height = dp(58);
        mainActionButton.setLayoutParams(mainLp);
        box.addView(mainActionButton);

        stopButton = dangerOutlineButton("■  Detener recorrido");
        LinearLayout.LayoutParams stopLp = (LinearLayout.LayoutParams) stopButton.getLayoutParams();
        stopLp.height = dp(54);
        stopButton.setLayoutParams(stopLp);
        stopButton.setOnClickListener(v -> stopTrack());
        box.addView(stopButton);

        poiButton = secondaryButton("⚑  Marcar punto de interés");
        LinearLayout.LayoutParams poiLp = (LinearLayout.LayoutParams) poiButton.getLayoutParams();
        poiLp.height = dp(54);
        poiButton.setLayoutParams(poiLp);
        poiButton.setOnClickListener(v -> markPointOfInterest());
        box.addView(poiButton);
        return box;
    }

    private View metricCard(String iconText, String labelText, TextView valueView) {
        LinearLayout box = vertical();
        box.setPadding(dp(10), dp(8), dp(8), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == 0 ? Color.rgb(248, 251, 255) : Color.rgb(11, 31, 49));
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), withAlpha(borderColor, 105));
        box.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(70), 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        box.setLayoutParams(lp);

        LinearLayout titleRow = horizontal();
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.setPadding(0, 0, 0, 0);
        TextView icon = text(iconText, 14, true);
        icon.setTextColor(accent);
        titleRow.addView(icon, new LinearLayout.LayoutParams(dp(24), ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView label = text(labelText, 11, false);
        label.setTextColor(subTextColor);
        label.setMaxLines(2);
        titleRow.addView(label, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        box.addView(titleRow);
        ResponsiveUi.configureCompactText(valueView, 17, 11, 1);
        box.addView(valueView);
        return box;
    }

    private View buildMapCard() {
        LinearLayout box = card();
        box.setPadding(dp(10), dp(10), dp(10), dp(10));

        LinearLayout header = horizontal();
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(text("Mapa del recorrido", 17, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button center = secondaryButton("◎  Centrar en mi ubicación");
        center.setOnClickListener(v -> mapView.centerOnLatest());
        LinearLayout.LayoutParams centerLp = new LinearLayout.LayoutParams(ResponsiveUi.isNarrow(this) ? dp(145) : dp(205), dp(44));
        centerLp.setMargins(dp(3), 0, 0, 0);
        center.setLayoutParams(centerLp);
        header.addView(center);
        box.addView(header);

        mapView = new TrackMapView(this);
        int mapHeight = ResponsiveUi.isNarrow(this) ? dp(245) : dp(285);
        box.addView(mapView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, mapHeight));
        return box;
    }

    private View buildExportCard() {
        LinearLayout box = card();
        box.setPadding(dp(12), dp(10), dp(12), dp(10));
        box.addView(sectionTitle("Exportar y gestionar"));

        LinearLayout buttons = horizontal();
        Button csv = secondaryButton("▤  Exportar CSV");
        csv.setOnClickListener(v -> export(false));
        buttons.addView(csv, weight());
        Button gpx = secondaryButton("⌁  Exportar GPX");
        gpx.setOnClickListener(v -> export(true));
        buttons.addView(gpx, weight());
        Button clear = dangerOutlineButton("⌫  Borrar recorrido");
        clear.setOnClickListener(v -> clearTrack());
        buttons.addView(clear, weight());
        box.addView(buttons);
        return box;
    }

    private Button dangerOutlineButton(String label) {
        Button button = secondaryButton(label);
        button.setTextColor(Color.rgb(255, 92, 101));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == 0 ? Color.rgb(255, 248, 249) : Color.rgb(34, 17, 27));
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Color.rgb(255, 73, 86));
        button.setBackground(bg);
        return button;
    }

    private void showTrackInfo() {
        new AlertDialog.Builder(this)
                .setTitle("Registro de recorrido GPS")
                .setMessage("El recorrido se inicia únicamente cuando pulsas Iniciar. Mientras está activo, Android mantiene una notificación visible y GeoTopo registra los puntos GPS incluso con la pantalla apagada. Puedes pausar, reanudar, marcar puntos de interés, detener y exportar el trabajo en CSV o GPX.")
                .setPositiveButton("Entendido", null)
                .show();
    }

    @Override protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter(TrackService.ACTION_UPDATE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, filter);
        receiverRegistered = true;
        screenStarted = true;
        tickerHandler.removeCallbacks(ticker);
        tickerHandler.post(ticker);
        refresh();
    }

    @Override protected void onStop() {
        screenStarted = false;
        tickerHandler.removeCallbacks(ticker);
        if (receiverRegistered) { unregisterReceiver(receiver); receiverRegistered = false; }
        super.onStop();
    }

    private void startTrack() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATION);
            return;
        }
        getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE).edit().remove(KEY_POIS).apply();
        Intent i = new Intent(this, TrackService.class);
        i.setAction(TrackService.ACTION_START);
        i.putExtra("reset", true);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        showToast("Recorrido iniciado.");
        refreshDelayed();
    }

    private void togglePause() {
        SharedPreferences sp = getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE);
        if (!sp.getBoolean(TrackService.KEY_RUNNING, false)) { showToast("No hay recorrido activo."); return; }
        boolean paused = sp.getBoolean(TrackService.KEY_PAUSED, false);
        Intent i = new Intent(this, TrackService.class);
        i.setAction(paused ? TrackService.ACTION_RESUME : TrackService.ACTION_PAUSE);
        startService(i);
        refreshDelayed();
    }

    private void stopTrack() {
        SharedPreferences sp = getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE);
        if (!sp.getBoolean(TrackService.KEY_RUNNING, false)) { showToast("No hay recorrido activo."); return; }
        Intent i = new Intent(this, TrackService.class);
        i.setAction(TrackService.ACTION_STOP);
        startService(i);
        refreshDelayed();
    }

    private void refreshDelayed() {
        if (statusView != null) statusView.postDelayed(this::refresh, 350L);
    }

    private void refreshClockOnly() {
        SharedPreferences sp = getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE);
        boolean running = sp.getBoolean(TrackService.KEY_RUNNING, false);
        boolean paused = sp.getBoolean(TrackService.KEY_PAUSED, false);
        long start = sp.getLong(TrackService.KEY_START, 0L);
        long pausedAt = sp.getLong(TrackService.KEY_PAUSED_AT, 0L);
        long pausedTotal = sp.getLong(TrackService.KEY_PAUSED_TOTAL, 0L);
        long now = running ? System.currentTimeMillis() : sp.getLong(TrackService.KEY_END, System.currentTimeMillis());
        long currentPause = paused && pausedAt > 0 ? Math.max(0, now - pausedAt) : 0;
        long duration = start > 0 ? Math.max(0, now - start - pausedTotal - currentPause) : 0;
        String state = running ? (paused ? "PAUSADO" : "REGISTRANDO") : "DETENIDO";
        int stateColor = running && !paused ? Color.rgb(83, 216, 118) : (paused ? Color.rgb(255, 184, 52) : Color.rgb(129, 202, 97));
        if (stateLabel != null) {
            stateLabel.setText("● " + state);
            stateLabel.setTextColor(stateColor);
        }
        if (statusView != null) statusView.setState(state, duration, stateColor);
    }

    private void refresh() {
        SharedPreferences sp = getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE);
        boolean running = sp.getBoolean(TrackService.KEY_RUNNING, false);
        boolean paused = sp.getBoolean(TrackService.KEY_PAUSED, false);
        long start = sp.getLong(TrackService.KEY_START, 0L);
        long pausedAt = sp.getLong(TrackService.KEY_PAUSED_AT, 0L);
        long pausedTotal = sp.getLong(TrackService.KEY_PAUSED_TOTAL, 0L);
        double distance = Double.longBitsToDouble(sp.getLong(TrackService.KEY_DISTANCE, Double.doubleToLongBits(0)));
        JSONArray points = readArray(sp, TrackService.KEY_POINTS);
        JSONArray pois = readArray(sp, KEY_POIS);
        long now = running ? System.currentTimeMillis() : sp.getLong(TrackService.KEY_END, System.currentTimeMillis());
        long currentPause = paused && pausedAt > 0 ? Math.max(0, now - pausedAt) : 0;
        long duration = start > 0 ? Math.max(0, now - start - pausedTotal - currentPause) : 0;
        double hours = duration / 3600000.0;
        double avg = hours > 0 ? distance / 1000.0 / hours : 0;
        double elevationGain = calculateElevationGain(points);

        String state = running ? (paused ? "PAUSADO" : "REGISTRANDO") : "DETENIDO";
        int stateColor = running && !paused ? Color.rgb(83, 216, 118) : (paused ? Color.rgb(255, 184, 52) : Color.rgb(129, 202, 97));
        if (stateLabel != null) {
            stateLabel.setText("● " + state);
            stateLabel.setTextColor(stateColor);
        }
        if (statusView != null) statusView.setState(state, duration, stateColor);
        if (distanceValue != null) distanceValue.setText(formatDistance(distance));
        if (avgValue != null) avgValue.setText(f2(avg) + " km/h");
        if (gainValue != null) gainValue.setText(f1(elevationGain) + " m");
        if (pointsValue != null) pointsValue.setText(String.valueOf(points.length()));
        if (mapView != null) mapView.setData(points, pois, running, paused);

        if (mainActionButton != null) {
            mainActionButton.setText(!running ? "▶  Iniciar nuevo recorrido" : (paused ? "▶  Reanudar recorrido" : "Ⅱ  Pausar recorrido"));
            mainActionButton.setEnabled(true);
        }
        if (stopButton != null) stopButton.setEnabled(running);
        if (poiButton != null) poiButton.setEnabled(points.length() > 0);
    }

    private JSONArray readArray(SharedPreferences sp, String key) {
        try { return new JSONArray(sp.getString(key, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private double calculateElevationGain(JSONArray points) {
        double gain = 0.0;
        Double previous = null;
        for (int i = 0; i < points.length(); i++) {
            JSONObject p = points.optJSONObject(i);
            if (p == null || p.isNull("alt")) continue;
            double alt = p.optDouble("alt", Double.NaN);
            if (!Double.isFinite(alt)) continue;
            if (previous != null) {
                double delta = alt - previous;
                if (delta > 0 && delta < 50.0) gain += delta;
            }
            previous = alt;
        }
        return gain;
    }

    private String formatDistance(double meters) {
        return meters >= 1000.0 ? f2(meters / 1000.0) + " km" : f2(meters) + " m";
    }

    private String formatDuration(long millis) {
        long seconds = millis / 1000;
        long h = seconds / 3600;
        long m = (seconds % 3600) / 60;
        long s = seconds % 60;
        return String.format(Locale.US, "%02d:%02d:%02d", h, m, s);
    }

    private void markPointOfInterest() {
        SharedPreferences sp = getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE);
        JSONArray points = readArray(sp, TrackService.KEY_POINTS);
        if (points.length() == 0) { showToast("Aún no hay una posición GPS para marcar."); return; }
        JSONObject last = points.optJSONObject(points.length() - 1);
        if (last == null) return;
        JSONArray pois = readArray(sp, KEY_POIS);
        try {
            JSONObject poi = new JSONObject();
            poi.put("lat", last.optDouble("lat"));
            poi.put("lon", last.optDouble("lon"));
            poi.put("alt", last.isNull("alt") ? JSONObject.NULL : last.optDouble("alt"));
            poi.put("time", System.currentTimeMillis());
            poi.put("label", "P" + (pois.length() + 1));
            pois.put(poi);
            sp.edit().putString(KEY_POIS, pois.toString()).apply();
            showToast("Punto de interés marcado: P" + pois.length());
            refresh();
        } catch (Exception e) {
            showToast("No se pudo marcar el punto.");
        }
    }

    private void clearTrack() {
        SharedPreferences sp = getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE);
        if (sp.getBoolean(TrackService.KEY_RUNNING, false)) { showToast("Detén el recorrido antes de borrarlo."); return; }
        sp.edit().clear().apply();
        refresh();
    }

    private void export(boolean gpx) {
        SharedPreferences sp = getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE);
        JSONArray points = readArray(sp, TrackService.KEY_POINTS);
        if (points.length() == 0) { showToast("No hay puntos para exportar."); return; }
        pendingExport = gpx ? buildGpx(points) : buildCsv(points);
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(gpx ? "application/gpx+xml" : "text/csv");
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date());
        i.putExtra(Intent.EXTRA_TITLE, "GeoTopo_Recorrido_" + stamp + (gpx ? ".gpx" : ".csv"));
        startActivityForResult(i, gpx ? REQ_EXPORT_GPX : REQ_EXPORT_CSV);
    }

    private String buildCsv(JSONArray points) {
        StringBuilder sb = new StringBuilder("indice,latitud,longitud,altitud,precision,fecha_hora\n");
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
        for (int i = 0; i < points.length(); i++) {
            JSONObject p = points.optJSONObject(i);
            if (p == null) continue;
            sb.append(i + 1).append(',').append(f7(p.optDouble("lat"))).append(',').append(f7(p.optDouble("lon"))).append(',')
                    .append(p.isNull("alt") ? "" : f3(p.optDouble("alt"))).append(',')
                    .append(p.isNull("acc") ? "" : f1(p.optDouble("acc"))).append(',')
                    .append('"').append(df.format(new Date(p.optLong("time")))).append('"').append('\n');
        }
        return sb.toString();
    }

    private String buildGpx(JSONArray points) {
        StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<gpx version=\"1.1\" creator=\"GeoTopo\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n<trk><name>GeoTopo recorrido</name><trkseg>\n");
        SimpleDateFormat iso = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        iso.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
        for (int i = 0; i < points.length(); i++) {
            JSONObject p = points.optJSONObject(i);
            if (p == null) continue;
            sb.append("<trkpt lat=\"").append(f7(p.optDouble("lat"))).append("\" lon=\"").append(f7(p.optDouble("lon"))).append("\">");
            if (!p.isNull("alt")) sb.append("<ele>").append(f3(p.optDouble("alt"))).append("</ele>");
            sb.append("<time>").append(iso.format(new Date(p.optLong("time")))).append("</time></trkpt>\n");
        }
        return sb.append("</trkseg></trk></gpx>\n").toString();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode == REQ_EXPORT_CSV || requestCode == REQ_EXPORT_GPX) && resultCode == RESULT_OK
                && data != null && data.getData() != null && pendingExport != null) {
            try {
                ContentResolver resolver = getContentResolver();
                Uri uri = data.getData();
                OutputStream out = resolver.openOutputStream(uri);
                if (out == null) throw new IllegalStateException();
                out.write(pendingExport.getBytes(StandardCharsets.UTF_8));
                out.close();
                showToast("Recorrido exportado.");
            } catch (Exception e) { showToast("No se pudo exportar."); }
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if ((requestCode == REQ_LOCATION || requestCode == REQ_NOTIFICATION) && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startTrack();
        else if (requestCode == REQ_LOCATION || requestCode == REQ_NOTIFICATION) showToast("Se necesitan los permisos para registrar el recorrido con una notificación visible.");
    }

    private final class TrackStatusView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private String state = "DETENIDO";
        private long duration;
        private int stateColor = Color.rgb(129, 202, 97);

        TrackStatusView(Context context) { super(context); }

        void setState(String newState, long newDuration, int color) {
            state = newState;
            duration = newDuration;
            stateColor = color;
            invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2f;
            float cy = h / 2f;
            float r = Math.min(w, h) * 0.42f;

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setColor(withAlpha(accent, 130));
            canvas.drawCircle(cx, cy, r, paint);
            paint.setStrokeWidth(dp(2.4f));
            paint.setColor(stateColor);
            RectF arc = new RectF(cx - r, cy - r, cx + r, cy + r);
            float sweep = state.equals("DETENIDO") ? 22f : 300f;
            canvas.drawArc(arc, -90f, sweep, false, paint);

            float markerAngle = (float) ((duration / 1000L) % 60L) * 6f - 90f;
            double rad = Math.toRadians(markerAngle);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(stateColor);
            canvas.drawCircle(cx + (float) Math.cos(rad) * r, cy + (float) Math.sin(rad) * r, dp(5), paint);

            drawCenteredText(canvas, state.equals("REGISTRANDO") ? "Activa" : (state.equals("PAUSADO") ? "Pausada" : "Detenido"), cx, cy - dp(24), 14, stateColor, false);
            drawCenteredText(canvas, formatDuration(duration), cx, cy + dp(3), 18, textColor, true);
            drawCenteredText(canvas, "Tiempo", cx, cy + dp(28), 12, subTextColor, false);
        }

        private void drawCenteredText(Canvas c, String value, float x, float y, float sp, int color, boolean bold) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(color);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(sp * getResources().getDisplayMetrics().scaledDensity);
            paint.setTypeface(bold ? android.graphics.Typeface.DEFAULT_BOLD : android.graphics.Typeface.DEFAULT);
            c.drawText(value, x, y - (paint.ascent() + paint.descent()) / 2f, paint);
        }
    }

    private final class TrackMapView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private JSONArray points = new JSONArray();
        private JSONArray pois = new JSONArray();
        private boolean running;
        private boolean paused;
        private boolean centerLatest = false;

        TrackMapView(Context context) {
            super(context);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(themeMode == 0 ? Color.rgb(233, 242, 249) : Color.rgb(6, 27, 43));
            bg.setCornerRadius(dp(13));
            bg.setStroke(dp(1), withAlpha(borderColor, 125));
            setBackground(bg);
        }

        void setData(JSONArray p, JSONArray marked, boolean isRunning, boolean isPaused) {
            points = p == null ? new JSONArray() : p;
            pois = marked == null ? new JSONArray() : marked;
            running = isRunning;
            paused = isPaused;
            invalidate();
        }

        void centerOnLatest() {
            centerLatest = true;
            invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            drawTopoBackground(canvas);
            if (points.length() == 0) {
                drawEmptyState(canvas);
                return;
            }

            Bounds b = calculateBounds(points, centerLatest);
            float pad = dp(28);
            float top = dp(28);
            float bottom = getHeight() - dp(34);
            float left = pad;
            float right = getWidth() - pad;

            path.reset();
            for (int i = 0; i < points.length(); i++) {
                JSONObject p = points.optJSONObject(i);
                if (p == null) continue;
                float x = projectX(p.optDouble("lon"), b, left, right);
                float y = projectY(p.optDouble("lat"), b, top, bottom);
                if (path.isEmpty()) path.moveTo(x, y); else path.lineTo(x, y);
            }
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setStrokeWidth(dp(7));
            paint.setColor(withAlpha(accent, 45));
            canvas.drawPath(path, paint);
            paint.setStrokeWidth(dp(3.3f));
            paint.setColor(accent);
            canvas.drawPath(path, paint);

            JSONObject first = points.optJSONObject(0);
            JSONObject last = points.optJSONObject(points.length() - 1);
            if (first != null) {
                float sx = projectX(first.optDouble("lon"), b, left, right);
                float sy = projectY(first.optDouble("lat"), b, top, bottom);
                drawMarker(canvas, sx, sy, Color.rgb(77, 218, 118), "Inicio", false);
            }
            if (last != null) {
                float lx = projectX(last.optDouble("lon"), b, left, right);
                float ly = projectY(last.optDouble("lat"), b, top, bottom);
                drawAccuracy(canvas, last, b, lx, ly, left, right);
                if (running) drawMarker(canvas, lx, ly, accent, paused ? "Pausado" : "Actual", true);
                else drawFinishFlag(canvas, lx, ly);
            }
            drawPois(canvas, b, left, right, top, bottom);
            drawNorth(canvas);
            drawScale(canvas, b, left, right);
        }

        private void drawTopoBackground(Canvas canvas) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(1));
            int grid = themeMode == 0 ? Color.argb(30, 30, 90, 120) : Color.argb(42, 69, 128, 160);
            paint.setColor(grid);
            int step = dp(46);
            for (int x = step; x < getWidth(); x += step) canvas.drawLine(x, 0, x, getHeight(), paint);
            for (int y = step; y < getHeight(); y += step) canvas.drawLine(0, y, getWidth(), y, paint);

            paint.setColor(themeMode == 0 ? Color.argb(38, 50, 126, 70) : Color.argb(46, 51, 126, 85));
            paint.setStrokeWidth(dp(1));
            for (int k = 0; k < 6; k++) {
                Path contour = new Path();
                float base = dp(32 + k * 42);
                contour.moveTo(0, base);
                for (int x = 0; x <= getWidth(); x += dp(14)) {
                    float y = base + (float) Math.sin((x / (float) dp(38)) + k * 0.8f) * dp(9 + (k % 2) * 4);
                    contour.lineTo(x, y);
                }
                canvas.drawPath(contour, paint);
            }
        }

        private void drawEmptyState(Canvas canvas) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(withAlpha(accent, 35));
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f - dp(8);
            canvas.drawCircle(cx, cy, dp(32), paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(3));
            paint.setColor(accent);
            canvas.drawCircle(cx, cy, dp(13), paint);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(cx, cy, dp(4), paint);
            drawMapText(canvas, "El recorrido aparecerá aquí", cx, cy + dp(58), 13, subTextColor, Paint.Align.CENTER, false);
        }

        private Bounds calculateBounds(JSONArray data, boolean focusLast) {
            int startIndex = 0;
            if (focusLast && data.length() > 60) startIndex = Math.max(0, data.length() - 60);
            double minLat = Double.POSITIVE_INFINITY, maxLat = Double.NEGATIVE_INFINITY;
            double minLon = Double.POSITIVE_INFINITY, maxLon = Double.NEGATIVE_INFINITY;
            for (int i = startIndex; i < data.length(); i++) {
                JSONObject p = data.optJSONObject(i);
                if (p == null) continue;
                double lat = p.optDouble("lat", Double.NaN);
                double lon = p.optDouble("lon", Double.NaN);
                if (!Double.isFinite(lat) || !Double.isFinite(lon)) continue;
                minLat = Math.min(minLat, lat); maxLat = Math.max(maxLat, lat);
                minLon = Math.min(minLon, lon); maxLon = Math.max(maxLon, lon);
            }
            if (!Double.isFinite(minLat)) return new Bounds(0, 1, 0, 1);
            double latSpan = Math.max(0.00008, maxLat - minLat);
            double lonSpan = Math.max(0.00008, maxLon - minLon);
            double latPad = latSpan * 0.18;
            double lonPad = lonSpan * 0.18;
            return new Bounds(minLat - latPad, maxLat + latPad, minLon - lonPad, maxLon + lonPad);
        }

        private float projectX(double lon, Bounds b, float left, float right) {
            double span = Math.max(1e-12, b.maxLon - b.minLon);
            return left + (float) ((lon - b.minLon) / span) * (right - left);
        }

        private float projectY(double lat, Bounds b, float top, float bottom) {
            double span = Math.max(1e-12, b.maxLat - b.minLat);
            return bottom - (float) ((lat - b.minLat) / span) * (bottom - top);
        }

        private void drawMarker(Canvas canvas, float x, float y, int color, String label, boolean current) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(withAlpha(color, 40));
            canvas.drawCircle(x, y, current ? dp(19) : dp(15), paint);
            paint.setColor(color);
            canvas.drawCircle(x, y, current ? dp(9) : dp(7), paint);
            paint.setColor(Color.WHITE);
            canvas.drawCircle(x, y, current ? dp(4) : dp(3), paint);
            drawMapText(canvas, label, x, y - dp(18), 10, textColor, Paint.Align.CENTER, true);
        }

        private void drawFinishFlag(Canvas canvas, float x, float y) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(withAlpha(accent, 35));
            canvas.drawCircle(x, y, dp(18), paint);
            paint.setColor(textColor);
            canvas.drawRect(x - dp(1), y - dp(15), x + dp(1), y + dp(9), paint);
            float cell = dp(5);
            for (int row = 0; row < 2; row++) {
                for (int col = 0; col < 3; col++) {
                    paint.setColor(((row + col) % 2 == 0) ? Color.WHITE : Color.rgb(35, 55, 75));
                    float l = x + dp(1) + col * cell;
                    float t = y - dp(15) + row * cell;
                    canvas.drawRect(l, t, l + cell, t + cell, paint);
                }
            }
            drawMapText(canvas, "Final", x, y - dp(22), 10, textColor, Paint.Align.CENTER, true);
        }

        private void drawAccuracy(Canvas canvas, JSONObject last, Bounds b, float x, float y, float left, float right) {
            if (last == null || last.isNull("acc")) return;
            double acc = last.optDouble("acc", 0);
            if (acc <= 0 || acc > 1000) return;
            double centerLat = last.optDouble("lat", 0);
            double metersPerLonDegree = 111320.0 * Math.max(0.2, Math.cos(Math.toRadians(centerLat)));
            double widthMeters = Math.max(1, (b.maxLon - b.minLon) * metersPerLonDegree);
            float pixelsPerMeter = (right - left) / (float) widthMeters;
            float radius = Math.min(dp(42), Math.max(dp(5), (float) acc * pixelsPerMeter));
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(withAlpha(accent, 24));
            canvas.drawCircle(x, y, radius, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(1));
            paint.setColor(withAlpha(accent, 90));
            canvas.drawCircle(x, y, radius, paint);
        }

        private void drawPois(Canvas canvas, Bounds b, float left, float right, float top, float bottom) {
            for (int i = 0; i < pois.length(); i++) {
                JSONObject p = pois.optJSONObject(i);
                if (p == null) continue;
                double lon = p.optDouble("lon", Double.NaN);
                double lat = p.optDouble("lat", Double.NaN);
                if (!Double.isFinite(lat) || !Double.isFinite(lon)) continue;
                float x = projectX(lon, b, left, right);
                float y = projectY(lat, b, top, bottom);
                if (x < 0 || x > getWidth() || y < 0 || y > getHeight()) continue;
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(Color.rgb(255, 184, 52));
                canvas.drawRect(x - dp(1), y - dp(12), x + dp(1), y + dp(7), paint);
                Path flag = new Path();
                flag.moveTo(x, y - dp(12));
                flag.lineTo(x + dp(11), y - dp(8));
                flag.lineTo(x, y - dp(4));
                flag.close();
                canvas.drawPath(flag, paint);
                String label = p.optString("label", "P" + (i + 1));
                drawMapText(canvas, label, x + dp(13), y - dp(8), 9, textColor, Paint.Align.LEFT, true);
            }
        }

        private void drawNorth(Canvas canvas) {
            float x = dp(20);
            float y = dp(18);
            drawMapText(canvas, "N", x, y, 12, textColor, Paint.Align.CENTER, true);
            paint.setColor(textColor);
            paint.setStyle(Paint.Style.FILL);
            Path arrow = new Path();
            arrow.moveTo(x, y + dp(8));
            arrow.lineTo(x - dp(6), y + dp(22));
            arrow.lineTo(x, y + dp(19));
            arrow.lineTo(x + dp(6), y + dp(22));
            arrow.close();
            canvas.drawPath(arrow, paint);
        }

        private void drawScale(Canvas canvas, Bounds b, float left, float right) {
            JSONObject ref = points.optJSONObject(points.length() - 1);
            if (ref == null) return;
            double lat = ref.optDouble("lat", 0);
            double metersPerLonDegree = 111320.0 * Math.max(0.2, Math.cos(Math.toRadians(lat)));
            double widthMeters = Math.max(1, (b.maxLon - b.minLon) * metersPerLonDegree);
            double target = niceScale(widthMeters * 0.22);
            float px = (float) (target / widthMeters) * (right - left);
            float x2 = getWidth() - dp(18);
            float x1 = x2 - px;
            float y = getHeight() - dp(18);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setColor(textColor);
            canvas.drawLine(x1, y, x2, y, paint);
            canvas.drawLine(x1, y - dp(4), x1, y + dp(4), paint);
            canvas.drawLine(x2, y - dp(4), x2, y + dp(4), paint);
            drawMapText(canvas, target >= 1000 ? f1(target / 1000) + " km" : String.format(Locale.US, "%.0f m", target), (x1 + x2) / 2f, y - dp(8), 9, subTextColor, Paint.Align.CENTER, false);
        }

        private double niceScale(double raw) {
            if (raw <= 0) return 10;
            double power = Math.pow(10, Math.floor(Math.log10(raw)));
            double n = raw / power;
            double nice = n < 2 ? 1 : (n < 5 ? 2 : 5);
            return nice * power;
        }

        private void drawMapText(Canvas c, String value, float x, float y, float sp, int color, Paint.Align align, boolean bold) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(color);
            paint.setTextAlign(align);
            paint.setTextSize(sp * getResources().getDisplayMetrics().scaledDensity);
            paint.setTypeface(bold ? android.graphics.Typeface.DEFAULT_BOLD : android.graphics.Typeface.DEFAULT);
            c.drawText(value, x, y, paint);
        }
    }

    private static final class Bounds {
        final double minLat, maxLat, minLon, maxLon;
        Bounds(double minLat, double maxLat, double minLon, double maxLon) {
            this.minLat = minLat;
            this.maxLat = maxLat;
            this.minLon = minLon;
            this.maxLon = maxLon;
        }
    }
}
