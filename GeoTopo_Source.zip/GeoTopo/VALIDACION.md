# Validación GeoTopo 1.10

- Límite artificial de 25 MB eliminado.
- Límites rígidos de área eliminados.
- Descarga sectorizada y subdivisión adaptativa implementadas.
- Archivos grandes escritos por streaming para reducir el uso de memoria.
- Índice de sectores offline y carga progresiva de la zona visible implementados.
- Compatibilidad conservada con mapas antiguos que usan `data.json`.
- Código Java compilado contra Android API 35.
- JavaScript de `map.html` validado con `node --check`.
- XML verificado.
