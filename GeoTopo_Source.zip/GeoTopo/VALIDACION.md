# Validación GeoTopo 1.20.0

## Cambios revisados

- Puntos de medición reducidos de 42 dp a 30 dp en distancia y área.
- Etiquetas de tramos sin recuadros grandes; conservan contraste mediante halo blanco.
- Línea exterior e interior reducidas para ocupar menos pantalla.
- Relleno del polígono cambiado a azul suave con menor opacidad.
- Buscador sin ejemplos fijos de ciudades.
- Relieve compuesto por World Terrain Base, World Hillshade y nombres de referencia.
- Fuentes de relieve con `maxzoom` definido para evitar solicitudes a niveles inexistentes.
- No existen referencias a `LegacyMapActivity` ni `map.html`.

## Pruebas necesarias en el teléfono

1. Medir distancia y confirmar que P1, P2, P3 y las etiquetas no tapen el mapa.
2. Medir un área de 4 a 8 lados y revisar el relleno azul suave y el cierre.
3. Abrir Relieve en una zona montañosa y comprobar sombreado, formas del terreno y nombres.
4. Acercar Relieve hasta el máximo y verificar que no aparezca `Map data not yet available`.
5. Abrir la lupa y comprobar que el campo no muestre Cusco ni Espinar.
6. Girar el mapa con dos dedos y comprobar que la brújula continúe orientando el norte.
