# Validación GeoTopo 1.20.6

## Apariencia de medición

El botón visible `⚙ Apariencia de medición` permite configurar por separado:

- Color de líneas y puntos.
- Tamaño de puntos P1, P2, P3.
- Tamaño de números T1, T2, T3 y Cierre.
- Tamaño del resumen central.
- Grosor de las líneas.

Los tamaños disponibles son Pequeños, Normales, Grandes y Muy grandes. El tamaño profesional predeterminado para los números de tramo es Grande.

## Comprobaciones realizadas

- Sintaxis Java de `MapActivity.java` validada con parser.
- Preferencias guardadas con `SharedPreferences`.
- No se reintrodujo la capa Relieve.
- No se reintrodujo el relleno azul del polígono.
- Estructura ZIP validada.

## Prueba recomendada

1. Abrir Medir.
2. Tocar `⚙ Apariencia de medición`.
3. Elegir `Números de tramos T1, T2…`.
4. Probar Grande y Muy grande.
5. Comprobar puntos, resumen y grosor de línea.
