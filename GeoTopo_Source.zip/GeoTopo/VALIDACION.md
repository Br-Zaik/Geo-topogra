# Validación GeoTopo 1.9

- Opción de promedio GPS de 60 segundos añadida y persistente.
- Acceso directo a mapas descargados desde la pantalla GPS.
- Apertura de mapas guardados sin internet.
- Apertura de la misma extensión en mapa normal, satélite o híbrido cuando existe internet.
- Código Java compilado contra Android API 35.
- JavaScript de `map.html` validado con `node --check`.
- XML y ZIP verificados.
