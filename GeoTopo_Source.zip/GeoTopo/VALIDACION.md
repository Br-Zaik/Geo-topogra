# Validación de GeoTopo 1.6

Comprobaciones realizadas antes de empaquetar el proyecto:

- `MainActivity.java`, `GpsActivity.java` y `MapActivity.java` compilan juntos con `javac`, Java 8 y `android35.jar`; para la compilación aislada se utilizó un `R.java` temporal con los identificadores de los iconos existentes.
- El JavaScript extraído de `map.html` pasa la comprobación sintáctica de Node.js.
- `MapActivity.java` también pasa análisis sintáctico independiente con un parser de Java.
- El manifiesto y todos los XML de recursos se analizaron correctamente como XML.
- Se verificaron las funciones de selección rectangular, cálculo de dimensiones, radios alrededor de la ubicación y devolución de límites desde JavaScript a Android.
- El ZIP final se comprueba con `unzip -t`.

La generación definitiva del APK se realiza mediante GitHub Actions. Después debe probarse en el teléfono real, especialmente el arrastre de las esquinas, los gestos del mapa, la búsqueda de lugares, la descarga mediante Wi-Fi y el uso del mapa sin conexión.
