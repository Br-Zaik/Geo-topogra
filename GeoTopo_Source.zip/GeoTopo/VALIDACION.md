# Validación GeoTopo 1.12

- Código Java comprobado contra Android API 35.
- JavaScript de `map.html` validado sintácticamente.
- XML de recursos y manifiesto comprobados.
- Modo Solo GPS/GNSS filtrado para no aceptar proveedor de red.
- Promedio bloqueado con precisión peor de ±50 m.
- Rechazo de lecturas anómalas durante el promedio.
- Capa Relieve reemplazada por una fuente más estable y fallback a Topográfico.
- Medición sobre mapa marcada como referencial y con precisión visual reducida.
- Estructura del ZIP comprobada.
