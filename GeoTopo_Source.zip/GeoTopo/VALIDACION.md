# Validación GeoTopo 1.20.8

## Comportamiento del promedio

1. Elegir 60 segundos no significa 30 segundos: primero existe una búsqueda previa de hasta 30 s y después se ejecutan 60 s reales de promedio.
2. El promedio estricto no comienza hasta tener:
   - proveedor GPS/GNSS;
   - lectura de menos de 5 s;
   - precisión de ±10 m o mejor;
   - mínimo 6 satélites usados.
3. Durante el promedio se exigen lecturas de ±15 m o mejor y al menos 5 satélites usados.
4. Se descartan saltos bruscos, lecturas antiguas y datos incompatibles con un teléfono quieto.
5. Para aplicar el resultado se exige un número mínimo de lecturas estables según el tiempo seleccionado.
6. La precisión final no es el promedio simple de las precisiones de Android. Se usa el valor más conservador entre:
   - la mejor precisión reportada;
   - la dispersión del 68 % de las lecturas alrededor del punto promedio.
7. El resultado queda congelado y se guarda exactamente con la precisión mostrada.

## Pantalla esperada

- Mejor precisión observada.
- Estabilidad del promedio.
- Precisión final estimada.
- Tiempo real ejecutado.
- Lecturas válidas y descartadas.
- Máximo de satélites usados.

## Validaciones estructurales realizadas

- Sintaxis Java validada en MainActivity, GpsActivity, ConverterActivity y MapActivity.
- Estructura Gradle conservada.
- compileSdk 35, targetSdk 35 y MapLibre Android 11.8.0 conservados.
- Versión actualizada a 1.20.8.

## Prueba necesaria en teléfono

- Realizar una prueba al aire libre con el teléfono quieto.
- Seleccionar 60 s y comprobar que la fase 2 cuenta los 60 s completos.
- Confirmar que el resultado final permanece igual al abrir Guardar punto.
- Comparar la mejor precisión, la estabilidad y la precisión final; no deben confundirse entre sí.
