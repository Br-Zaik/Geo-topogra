# Validación GeoTopo 1.15

- Estructura Android y manifest revisados.
- XML validado.
- Archivos Java analizados sintácticamente.
- Se añadió la dependencia `org.maplibre.gl:android-sdk:11.8.0` desde Maven Central.
- MapLibre Native renderiza el mapa mediante GPU; la compilación final se ejecuta en GitHub Actions con Android API 35.
- La descarga y visualización de mapas offline anteriores se conserva en `LegacyMapActivity`.

Pruebas necesarias en el teléfono:

1. Fluidez del zoom y desplazamiento en el visor nativo.
2. Cambio entre capas.
3. Ubicación y geocodificación del lugar.
4. Medición de distancia y área.
5. Apertura de mapas descargados.
6. Promedio GPS de 10, 20, 30 y 60 segundos.
