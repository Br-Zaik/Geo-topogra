# Validación de GeoTopo 1.4

Comprobaciones realizadas antes de empaquetar el proyecto:

- `MainActivity.java`, `GpsActivity.java` y `MapActivity.java` compilan juntos con `javac`, Java 8 y las clases públicas de Android API 35.
- El JavaScript de `map.html` pasa la comprobación sintáctica de Node.js.
- El manifiesto y los XML de recursos se analizaron correctamente como XML.
- Se verificaron las referencias Java de los nuevos iconos del mapa.
- El ZIP final se comprueba con `unzip -t`.

La comprobación definitiva de recursos Android y la generación del APK se realizan mediante el workflow de GitHub Actions incluido en el repositorio. Después debe probarse en el teléfono real, porque la precisión GPS, los satélites y los sensores dependen del dispositivo y del entorno.
