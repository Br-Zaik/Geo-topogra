# Validación GeoTopo 1.8

- Código Java compilado con `javac` contra Android API 35.
- JavaScript de `map.html` validado con `node --check`.
- Selector de descarga reemplazado por un panel visible con botones de 1, 3, 5 y 10 km.
- Medición muestra total en metros y kilómetros, número de tramos y etiquetas por tramo.
- Archivo ZIP verificado con prueba de integridad.
