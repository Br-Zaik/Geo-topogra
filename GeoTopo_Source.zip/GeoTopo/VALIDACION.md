# Validación de GeoTopo 1.3

Comprobaciones realizadas antes de empaquetar el proyecto:

- Los tres archivos Java compilan juntos con `javac` usando las clases públicas de Android API 35 (`android.jar`).
- El código es compatible con nivel de lenguaje Java 8.
- El JavaScript de `map.html` pasa la verificación sintáctica de Node.js.
- Se ejecutó el visor del mapa en un entorno DOM simulado y se probaron las funciones de ubicación, puntos GPS, línea A-B, cambio de capa, zoom, medición y carga offline.
- El manifiesto XML y los XML de recursos son válidos.
- El ZIP final se verifica con `unzip -t`.

La generación definitiva del APK se realiza mediante el workflow de GitHub Actions incluido en el repositorio.
