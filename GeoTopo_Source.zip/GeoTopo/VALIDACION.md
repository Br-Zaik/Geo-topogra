# Validación GeoTopo 1.19.0

## Revisión realizada

- No quedan referencias a `LegacyMapActivity`, `map.html` ni rutas del visor antiguo.
- El manifiesto declara solamente el visor moderno `MapActivity`.
- El GPS abre el mapa moderno y ya no muestra botones que dependían del visor eliminado.
- La búsqueda acepta nombres de lugares y coordenadas `latitud, longitud`.
- Las consultas de lugares usan Nominatim al pulsar Buscar, con identificación de la aplicación y límite de ocho resultados.
- Relieve usa un mapa base visible más una capa de sombreado con zoom máximo controlado.
- La medición dibuja un borde exterior claro y una línea interior azul, sin cambiar puntos ni etiquetas.
- XML del nuevo icono de búsqueda revisado.
- Estructura de llaves Java y referencias de recursos revisadas.

## Pruebas recomendadas en el teléfono

1. Abrir el mapa desde Inicio, GPS y un punto guardado; siempre debe aparecer MapLibre.
2. Girar y ampliar el mapa con dos dedos.
3. Pulsar la lupa, buscar `Cusco` y `Espinar`, elegir un resultado y comprobar que centra el mapa y coloca un marcador.
4. Buscar coordenadas como `-13.5319, -71.9675`.
5. Abrir **Relieve** y acercar el mapa; el mapa base debe seguir visible aunque falle temporalmente el sombreado.
6. Medir distancia y área; verificar que P1, P2, P3 y las etiquetas se mantengan, con líneas de borde más limpias.
7. Revisar las categorías del conversor.
