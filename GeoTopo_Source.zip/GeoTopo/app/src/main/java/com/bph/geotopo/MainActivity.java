package com.bph.geotopo;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final String PREFS = "geo_topo_prefs";
    private static final int[] ACCENTS = {
            Color.rgb(41, 121, 255),
            Color.rgb(0, 200, 83),
            Color.rgb(255, 171, 0),
            Color.rgb(213, 0, 249),
            Color.rgb(255, 61, 0)
    };

    private boolean amoledMode;
    private int accentIndex;
    private int bgColor;
    private int cardColor;
    private int textColor;
    private int subTextColor;
    private int borderColor;

    private ZoomLayout zoomLayout;

    private EditText azInput;
    private TextView azResult;

    private EditText coordAzInput;
    private EditText distanceInput;
    private TextView coordResult;

    private final List<TableDataRow> tableRows = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadPrefs();
        buildUi();
    }

    private void loadPrefs() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        amoledMode = sp.getBoolean("amoled", true);
        accentIndex = sp.getInt("accent", 0);
    }

    private void savePrefs() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("amoled", amoledMode)
                .putInt("accent", accentIndex)
                .apply();
    }

    private void applyPalette() {
        bgColor = amoledMode ? Color.BLACK : Color.rgb(18, 18, 22);
        cardColor = amoledMode ? Color.rgb(9, 9, 12) : Color.rgb(30, 31, 38);
        textColor = Color.rgb(245, 245, 245);
        subTextColor = Color.rgb(190, 190, 198);
        borderColor = ACCENTS[accentIndex % ACCENTS.length];
    }

    private void buildUi() {
        applyPalette();
        tableRows.clear();

        FrameLayout screen = new FrameLayout(this);
        screen.setBackgroundColor(bgColor);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        zoomLayout = new ZoomLayout(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(14), dp(14), dp(28));
        content.setBackgroundColor(bgColor);

        content.addView(titleBlock());
        content.addView(settingsBlock());
        content.addView(azimuthBlock());
        content.addView(coordBlock());
        content.addView(partialTableBlock());
        content.addView(noteBlock());

        zoomLayout.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        scroll.addView(zoomLayout);
        screen.addView(scroll);
        setContentView(screen);
    }

    private View titleBlock() {
        LinearLayout box = card();

        TextView title = tv("Geo Topo", 28, true);
        title.setGravity(Gravity.CENTER);
        box.addView(title);

        TextView sub = tv("Calculadora topográfica offline · Sin IA · Sin internet · Sin APIs", 14, false);
        sub.setGravity(Gravity.CENTER);
        sub.setTextColor(subTextColor);
        sub.setPadding(0, dp(4), 0, 0);
        box.addView(sub);

        return box;
    }

    private View settingsBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("Ajustes visuales"));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);

        Button mode = btn(amoledMode ? "Modo negro" : "Modo oscuro");
        mode.setOnClickListener(v -> {
            amoledMode = !amoledMode;
            savePrefs();
            buildUi();
        });
        row.addView(mode, weightParams());

        Button color = btn("Color cuadros");
        color.setOnClickListener(v -> {
            accentIndex = (accentIndex + 1) % ACCENTS.length;
            savePrefs();
            buildUi();
        });
        row.addView(color, weightParams());

        Button reset = btn("Reset zoom");
        reset.setOnClickListener(v -> zoomLayout.resetZoom());
        row.addView(reset, weightParams());

        box.addView(row);

        TextView help = small("Zoom: usa dos dedos como en un PDF. La tabla se mueve de lado con el dedo.");
        help.setPadding(0, dp(10), 0, 0);
        box.addView(help);
        return box;
    }

    private View azimuthBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("1. Azimut a rumbo"));
        box.addView(small("Puedes escribir: 326°30'00\"  ·  326 30 00  ·  326.5"));

        azInput = edit("Azimut");
        box.addView(azInput);

        Button calc = btn("Calcular rumbo");
        calc.setOnClickListener(v -> calculateAzimuth());
        box.addView(calc);

        azResult = resultBox("Resultado pendiente");
        box.addView(azResult);
        return box;
    }

    private View coordBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("2. Distancia y coordenadas parciales"));

        coordAzInput = edit("Azimut");
        distanceInput = edit("Distancia horizontal");
        distanceInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);

        box.addView(coordAzInput);
        box.addView(distanceInput);

        Button calc = btn("Calcular E/O/N/S");
        calc.setOnClickListener(v -> calculateCoordinateSingle());
        box.addView(calc);

        coordResult = resultBox("Resultado pendiente");
        box.addView(coordResult);
        return box;
    }

    private View partialTableBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("3. Cuadro de coordenadas parciales"));
        box.addView(small("Llena estación, punto visado, azimut y distancia. Luego toca CALCULAR TABLA."));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        TableLayout table = new TableLayout(this);
        table.setStretchAllColumns(false);
        table.addView(headerRow("EST.", "P.V.", "AZIMUT", "DIST.", "RUMBO", "SEN", "COS", "ESTE", "OESTE", "NORTE", "SUR"));

        for (int i = 0; i < 6; i++) {
            TableDataRow row = new TableDataRow();
            TableRow tr = new TableRow(this);
            row.est = cellEdit("E" + (i + 1), false);
            row.pv = cellEdit("P" + (i + 1), false);
            row.az = cellEdit("0°00'00\"", false);
            row.dist = cellEdit("0.000", true);
            row.rumbo = cellText("—");
            row.sen = cellText("—");
            row.cos = cellText("—");
            row.este = cellText("—");
            row.oeste = cellText("—");
            row.norte = cellText("—");
            row.sur = cellText("—");
            tr.addView(row.est);
            tr.addView(row.pv);
            tr.addView(row.az);
            tr.addView(row.dist);
            tr.addView(row.rumbo);
            tr.addView(row.sen);
            tr.addView(row.cos);
            tr.addView(row.este);
            tr.addView(row.oeste);
            tr.addView(row.norte);
            tr.addView(row.sur);
            table.addView(tr);
            tableRows.add(row);
        }

        hsv.addView(table);
        box.addView(hsv);

        LinearLayout rowButtons = new LinearLayout(this);
        rowButtons.setOrientation(LinearLayout.HORIZONTAL);

        Button calc = btn("CALCULAR TABLA");
        calc.setOnClickListener(v -> calculateTable());
        rowButtons.addView(calc, weightParams());

        Button clear = btn("LIMPIAR");
        clear.setOnClickListener(v -> buildUi());
        rowButtons.addView(clear, weightParams());

        box.addView(rowButtons);
        return box;
    }

    private View noteBlock() {
        LinearLayout box = card();
        box.addView(sectionTitle("Versión inicial"));
        box.addView(small("Esta primera versión calcula azimut, rumbo, contraazimut, contrarumbo, seno, coseno y coordenadas parciales. Después se puede agregar poligonal cerrada, nivelación, áreas y exportación."));
        return box;
    }

    private void calculateAzimuth() {
        try {
            double az = normalize(parseAngle(azInput.getText().toString()));
            double contra = contraAzimuth(az);
            String out = "Azimut: " + formatDms(az) + "\n"
                    + "Rumbo: " + rumbo(az) + "\n"
                    + "Contraazimut: " + formatDms(contra) + "\n"
                    + "Contrarumbo: " + rumbo(contra);
            azResult.setText(out);
        } catch (Exception e) {
            showError("Revisa el azimut. Ejemplo correcto: 326°30'00\"");
        }
    }

    private void calculateCoordinateSingle() {
        try {
            double az = normalize(parseAngle(coordAzInput.getText().toString()));
            double distance = parseNumber(distanceInput.getText().toString());
            CoordinateResult r = coordinateResult(az, distance);
            coordResult.setText(coordinateOutput(az, distance, r));
        } catch (Exception e) {
            showError("Revisa azimut y distancia. Ejemplo: azimut 326°30'00\" y distancia 75.00");
        }
    }

    private void calculateTable() {
        int ok = 0;
        for (TableDataRow row : tableRows) {
            String azText = row.az.getText().toString().trim();
            String distText = row.dist.getText().toString().trim();
            if (azText.isEmpty() && distText.isEmpty()) continue;
            try {
                double az = normalize(parseAngle(azText));
                double distance = parseNumber(distText);
                CoordinateResult r = coordinateResult(az, distance);
                row.rumbo.setText(rumbo(az));
                row.sen.setText(f6(r.sen));
                row.cos.setText(f6(r.cos));
                row.este.setText(r.este > 0 ? f3(r.este) : "");
                row.oeste.setText(r.oeste > 0 ? f3(r.oeste) : "");
                row.norte.setText(r.norte > 0 ? f3(r.norte) : "");
                row.sur.setText(r.sur > 0 ? f3(r.sur) : "");
                ok++;
            } catch (Exception e) {
                row.rumbo.setText("ERROR");
            }
        }
        Toast.makeText(this, "Filas calculadas: " + ok, Toast.LENGTH_SHORT).show();
    }

    private CoordinateResult coordinateResult(double az, double distance) {
        double rad = Math.toRadians(az);
        double sen = Math.sin(rad);
        double cos = Math.cos(rad);
        double dx = distance * sen;
        double dy = distance * cos;
        CoordinateResult r = new CoordinateResult();
        r.sen = sen;
        r.cos = cos;
        r.dx = dx;
        r.dy = dy;
        r.este = dx > 0 ? dx : 0;
        r.oeste = dx < 0 ? -dx : 0;
        r.norte = dy > 0 ? dy : 0;
        r.sur = dy < 0 ? -dy : 0;
        return r;
    }

    private String coordinateOutput(double az, double distance, CoordinateResult r) {
        return "Azimut: " + formatDms(az) + "\n"
                + "Rumbo: " + rumbo(az) + "\n"
                + "Distancia: " + f3(distance) + "\n"
                + "Seno: " + f6(r.sen) + "\n"
                + "Coseno: " + f6(r.cos) + "\n"
                + "ΔX = D × sen(Az): " + f3(r.dx) + "\n"
                + "ΔY = D × cos(Az): " + f3(r.dy) + "\n"
                + "Este: " + f3(r.este) + "   Oeste: " + f3(r.oeste) + "\n"
                + "Norte: " + f3(r.norte) + "   Sur: " + f3(r.sur);
    }

    private double parseAngle(String value) {
        String s = value.trim().replace(',', '.');
        if (s.isEmpty()) throw new IllegalArgumentException("empty");

        Matcher m = Pattern.compile("-?\\d+(?:\\.\\d+)?").matcher(s);
        ArrayList<Double> nums = new ArrayList<>();
        while (m.find()) nums.add(Double.parseDouble(m.group()));
        if (nums.isEmpty()) throw new IllegalArgumentException("no number");

        double deg = nums.get(0);
        double sign = deg < 0 ? -1 : 1;
        deg = Math.abs(deg);
        double min = nums.size() > 1 ? Math.abs(nums.get(1)) : 0;
        double sec = nums.size() > 2 ? Math.abs(nums.get(2)) : 0;

        if (nums.size() == 1 && !s.contains("°") && !s.contains("º") && !s.contains("'") && !s.contains("\"") && !s.contains(" ")) {
            String clean = s.startsWith("-") ? s.substring(1) : s;
            // En muchos cuadernos se escribe 326.30 como 326°30'.
            // Si la parte decimal tiene 2 digitos, se interpreta como grados.minutos.
            // Si tiene 4 digitos, se interpreta como grados.minutossegundos.
            if (clean.matches("\\d+\\.\\d{2}")) {
                String[] parts = clean.split("\\.");
                double d = Double.parseDouble(parts[0]);
                double mm = Double.parseDouble(parts[1]);
                if (mm < 60) return sign * (d + mm / 60.0);
            }
            if (clean.matches("\\d+\\.\\d{4}")) {
                String[] parts = clean.split("\\.");
                double d = Double.parseDouble(parts[0]);
                double mm = Double.parseDouble(parts[1].substring(0, 2));
                double ss = Double.parseDouble(parts[1].substring(2, 4));
                if (mm < 60 && ss < 60) return sign * (d + mm / 60.0 + ss / 3600.0);
            }
            return nums.get(0);
        }
        return sign * (deg + min / 60.0 + sec / 3600.0);
    }

    private double parseNumber(String value) {
        String s = value.trim().replace(',', '.');
        if (s.isEmpty()) throw new IllegalArgumentException("empty");
        return Double.parseDouble(s);
    }

    private double normalize(double angle) {
        double a = angle % 360.0;
        if (a < 0) a += 360.0;
        if (Math.abs(a - 360.0) < 0.0000001) a = 0;
        return a;
    }

    private double contraAzimuth(double az) {
        return normalize(az + 180.0);
    }

    private String rumbo(double az) {
        double a = normalize(az);
        if (near(a, 0) || near(a, 360)) return "N 00°00'00\" E";
        if (near(a, 90)) return "E 90°00'00\"";
        if (near(a, 180)) return "S 00°00'00\" W";
        if (near(a, 270)) return "W 90°00'00\"";
        if (a > 0 && a < 90) return "N " + formatDms(a) + " E";
        if (a > 90 && a < 180) return "S " + formatDms(180 - a) + " E";
        if (a > 180 && a < 270) return "S " + formatDms(a - 180) + " W";
        return "N " + formatDms(360 - a) + " W";
    }

    private boolean near(double a, double b) {
        return Math.abs(a - b) < 0.0000001;
    }

    private String formatDms(double angle) {
        double a = Math.abs(angle);
        int deg = (int) Math.floor(a);
        double minFloat = (a - deg) * 60.0;
        int min = (int) Math.floor(minFloat);
        double secFloat = (minFloat - min) * 60.0;
        int sec = (int) Math.round(secFloat);
        if (sec == 60) { sec = 0; min++; }
        if (min == 60) { min = 0; deg++; }
        return String.format(Locale.US, "%02d°%02d'%02d\"", deg, min, sec);
    }

    private String f3(double v) {
        return String.format(Locale.US, "%.3f", cleanZero(v));
    }

    private String f6(double v) {
        return String.format(Locale.US, "%.6f", cleanZero(v));
    }

    private double cleanZero(double v) {
        return Math.abs(v) < 0.0000000001 ? 0 : v;
    }

    private void showError(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, 0, 0, dp(12));
        box.setLayoutParams(lp);

        GradientDrawable gd = new GradientDrawable();
        gd.setColor(cardColor);
        gd.setCornerRadius(dp(14));
        gd.setStroke(dp(2), borderColor);
        box.setBackground(gd);
        return box;
    }

    private TextView sectionTitle(String text) {
        TextView v = tv(text, 18, true);
        v.setPadding(0, 0, 0, dp(8));
        return v;
    }

    private TextView small(String text) {
        TextView v = tv(text, 13, false);
        v.setTextColor(subTextColor);
        v.setLineSpacing(0, 1.15f);
        return v;
    }

    private TextView tv(String text, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(textColor);
        v.setTextSize(sp);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextColor(textColor);
        e.setHintTextColor(Color.rgb(145, 145, 155));
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        e.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(8), 0, dp(8));
        e.setLayoutParams(lp);
        e.setBackground(inputBg(false));
        return e;
    }

    private Button btn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setPadding(dp(6), dp(8), dp(6), dp(8));
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(borderColor);
        gd.setCornerRadius(dp(10));
        b.setBackground(gd);
        return b;
    }

    private TextView resultBox(String text) {
        TextView v = tv(text, 15, false);
        v.setPadding(dp(10), dp(10), dp(10), dp(10));
        v.setBackground(inputBg(true));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(10), 0, 0);
        v.setLayoutParams(lp);
        return v;
    }

    private GradientDrawable inputBg(boolean result) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(result ? Color.rgb(16, 35, 28) : Color.rgb(17, 18, 24));
        gd.setCornerRadius(dp(9));
        gd.setStroke(dp(1), result ? Color.rgb(0, 200, 83) : Color.rgb(85, 86, 94));
        return gd;
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), dp(4), dp(3), dp(4));
        return lp;
    }

    private TableRow headerRow(String... headers) {
        TableRow tr = new TableRow(this);
        for (String h : headers) {
            TextView v = cellText(h);
            v.setTypeface(Typeface.DEFAULT_BOLD);
            v.setBackgroundColor(borderColor);
            v.setTextColor(Color.WHITE);
            tr.addView(v);
        }
        return tr;
    }

    private EditText cellEdit(String text, boolean number) {
        EditText e = new EditText(this);
        e.setText(text);
        e.setTextColor(textColor);
        e.setHintTextColor(subTextColor);
        e.setTextSize(13);
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER);
        e.setPadding(dp(6), dp(3), dp(6), dp(3));
        e.setMinWidth(dp(95));
        e.setBackground(cellBg(false));
        e.setInputType(number ? (InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED) : InputType.TYPE_CLASS_TEXT);
        return e;
    }

    private TextView cellText(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(textColor);
        v.setTextSize(13);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(6), dp(7), dp(6), dp(7));
        v.setMinWidth(dp(95));
        v.setBackground(cellBg(true));
        return v;
    }

    private GradientDrawable cellBg(boolean locked) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(locked ? Color.rgb(24, 25, 31) : Color.rgb(12, 19, 33));
        gd.setStroke(1, Color.rgb(80, 82, 92));
        return gd;
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }

    private static class CoordinateResult {
        double sen;
        double cos;
        double dx;
        double dy;
        double este;
        double oeste;
        double norte;
        double sur;
    }

    private static class TableDataRow {
        EditText est;
        EditText pv;
        EditText az;
        EditText dist;
        TextView rumbo;
        TextView sen;
        TextView cos;
        TextView este;
        TextView oeste;
        TextView norte;
        TextView sur;
    }

    public static class ZoomLayout extends FrameLayout {
        private final ScaleGestureDetector detector;
        private float scale = 1.0f;

        public ZoomLayout(Context context) {
            super(context);
            detector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScale(ScaleGestureDetector d) {
                    scale *= d.getScaleFactor();
                    scale = Math.max(0.75f, Math.min(scale, 2.8f));
                    setScaleX(scale);
                    setScaleY(scale);
                    setPivotX(0);
                    setPivotY(0);
                    return true;
                }
            });
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            detector.onTouchEvent(event);
            return true;
        }

        @Override
        public boolean dispatchTouchEvent(MotionEvent ev) {
            detector.onTouchEvent(ev);
            return super.dispatchTouchEvent(ev);
        }

        public void resetZoom() {
            scale = 1.0f;
            setScaleX(scale);
            setScaleY(scale);
        }
    }
}
