package com.bph.geotopo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.maplibre.android.MapLibre;
import org.maplibre.android.annotations.Marker;
import org.maplibre.android.annotations.MarkerOptions;
import org.maplibre.android.annotations.Polygon;
import org.maplibre.android.annotations.PolygonOptions;
import org.maplibre.android.annotations.Polyline;
import org.maplibre.android.annotations.PolylineOptions;
import org.maplibre.android.camera.CameraPosition;
import org.maplibre.android.camera.CameraUpdateFactory;
import org.maplibre.android.geometry.LatLng;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapView;
import org.maplibre.android.maps.Style;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Visor principal nativo. Usa MapLibre para que el zoom y el desplazamiento
 * se procesen con la GPU en lugar de redibujar un mapa dentro de WebView.
 */
public class MapActivity extends Activity implements LocationListener {
    private static final int REQ_LOCATION = 9002;
    private static final String PREFS = "geo_topo_prefs";
    private static final String GPS_PREFS = "geotopo_gps";
    private static final String KEY_POINTS = "points_json";

    private MapView mapView;
    private MapLibreMap map;
    private LocationManager locationManager;
    private Location currentLocation;
    private Marker locationMarker;
    private Polygon accuracyPolygon;
    private Marker selectedMarker;
    private final List<Marker> savedPointMarkers = new ArrayList<>();
    private Polyline measurementLine;
    private Polygon measurementPolygon;
    private final List<LatLng> measurementPoints = new ArrayList<>();
    private boolean measurementActive;
    private boolean areaMode;
    private String currentMode = "standard";
    private String currentPlaceName = "";

    private TextView subtitleView;
    private TextView statusView;
    private LinearLayout measurePanel;
    private TextView measureResultView;
    private LinearLayout selectedPanel;
    private TextView selectedPlaceView;
    private TextView selectedCoordsView;
    private TextView selectedUtmView;
    private LatLng selectedPoint;

    private int accentColor = Color.rgb(41, 121, 255);
    private int appBarColor = Color.rgb(3, 45, 73);
    private int cardColor = Color.rgb(4, 36, 58);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService lookupExecutor = Executors.newSingleThreadExecutor();
    private long locationRequestStartedAt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadPalette();
        MapLibre.getInstance(this);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        buildUi(savedInstanceState);
        loadRememberedLocation();
    }

    private void loadPalette() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        int[] accents = {
                Color.rgb(41, 121, 255), Color.rgb(0, 188, 212), Color.rgb(0, 150, 136),
                Color.rgb(0, 184, 148), Color.rgb(118, 210, 34), Color.rgb(255, 214, 10),
                Color.rgb(255, 171, 0), Color.rgb(255, 112, 20), Color.rgb(244, 67, 54),
                Color.rgb(255, 64, 129), Color.rgb(142, 68, 173), Color.rgb(92, 92, 210)
        };
        int index = sp.getInt("accent", 0);
        accentColor = accents[Math.floorMod(index, accents.length)];
    }

    private void buildUi(Bundle savedInstanceState) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(232, 239, 244));
        root.addView(buildTopBar());

        FrameLayout mapFrame = new FrameLayout(this);
        mapView = new MapView(this);
        mapView.onCreate(savedInstanceState);
        mapFrame.addView(mapView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(mapFrame, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        addMapOverlays(mapFrame);
        mapView.getMapAsync(mapLibreMap -> {
            map = mapLibreMap;
            map.getUiSettings().setCompassEnabled(false);
            map.getUiSettings().setLogoEnabled(false);
            map.getUiSettings().setAttributionEnabled(false);
            map.setMinZoomPreference(2.0);
            map.setMaxZoomPreference(20.0);
            map.addOnMapLongClickListener(point -> {
                showSelectedPoint(point);
                return true;
            });
            map.addOnMapClickListener(point -> {
                if (!measurementActive) return false;
                measurementPoints.add(point);
                redrawMeasurement();
                return true;
            });
            setMapMode("standard");
            loadSavedPoints();
            centerOnCurrentLocation(false);
        });
    }

    private View buildTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(10), dp(7), dp(12), dp(7));
        bar.setBackgroundColor(appBarColor);

        TextView back = text("‹", 42, true, Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(58), dp(58)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("Mapa topográfico", 22, true, Color.WHITE);
        titles.addView(title);
        subtitleView = text("Mapa nativo · calles y lugares", 12, false, Color.rgb(193, 218, 240));
        titles.addView(subtitleView);
        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView info = roundText("i", "Información");
        info.setOnClickListener(v -> showInfo());
        bar.addView(info, new LinearLayout.LayoutParams(dp(48), dp(48)));
        return bar;
    }

    private void addMapOverlays(FrameLayout frame) {
        TextView compass = buildCompass();
        FrameLayout.LayoutParams compassLp = new FrameLayout.LayoutParams(dp(70), dp(70));
        compassLp.gravity = Gravity.TOP | Gravity.END;
        compassLp.setMargins(0, dp(10), dp(10), 0);
        frame.addView(compass, compassLp);

        statusView = text("Preparando mapa nativo…", 12, true, Color.WHITE);
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(dp(10), dp(8), dp(10), dp(8));
        statusView.setBackground(pill(Color.argb(235, 4, 36, 58), dp(18), Color.argb(70, 255, 255, 255)));
        FrameLayout.LayoutParams statusLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        statusLp.gravity = Gravity.BOTTOM;
        statusLp.setMargins(dp(22), 0, dp(22), dp(86));
        frame.addView(statusView, statusLp);

        LinearLayout dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setGravity(Gravity.CENTER);
        dock.setPadding(dp(6), dp(6), dp(6), dp(5));
        dock.setBackground(pill(Color.argb(245, 4, 36, 58), dp(22), Color.argb(70, 255, 255, 255)));
        dock.setElevation(dp(12));
        dock.addView(mapTool("⌖", "Ubicación", v -> centerOnCurrentLocation(true)), toolParams());
        dock.addView(mapTool("▱", "Capas", v -> showLayers()), toolParams());
        dock.addView(mapTool("●", "Puntos", v -> loadSavedPoints()), toolParams());
        dock.addView(mapTool("□", "Medir", v -> showMeasureChooser()), toolParams());
        dock.addView(mapTool("↓", "Descargar", v -> openLegacy("download")), toolParams());
        FrameLayout.LayoutParams dockLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(72));
        dockLp.gravity = Gravity.BOTTOM;
        dockLp.setMargins(dp(10), 0, dp(10), dp(9));
        frame.addView(dock, dockLp);

        measurePanel = buildMeasurePanel();
        measurePanel.setVisibility(View.GONE);
        FrameLayout.LayoutParams measureLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        measureLp.gravity = Gravity.BOTTOM;
        measureLp.setMargins(dp(12), 0, dp(12), dp(88));
        frame.addView(measurePanel, measureLp);

        selectedPanel = buildSelectedPanel();
        selectedPanel.setVisibility(View.GONE);
        FrameLayout.LayoutParams selectedLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        selectedLp.gravity = Gravity.BOTTOM;
        selectedLp.setMargins(dp(12), 0, dp(12), dp(88));
        frame.addView(selectedPanel, selectedLp);
    }

    private TextView buildCompass() {
        TextView view = text("  N  \nO  ◆  E\n  S  ", 11, true, Color.WHITE);
        view.setGravity(Gravity.CENTER);
        view.setBackground(pill(Color.argb(235, 10, 22, 33), dp(35), Color.argb(110, 255, 255, 255)));
        view.setOnClickListener(v -> {
            if (map != null) {
                CameraPosition p = new CameraPosition.Builder(map.getCameraPosition()).bearing(0).tilt(0).build();
                map.animateCamera(CameraUpdateFactory.newCameraPosition(p), 350);
            }
        });
        return view;
    }

    private LinearLayout buildMeasurePanel() {
        LinearLayout panel = floatingPanel();
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Medición referencial sobre mapa", 17, true, Color.WHITE);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = text("×", 28, true, Color.WHITE);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> {
            measurementActive = false;
            panel.setVisibility(View.GONE);
            setStatus("La medición queda dibujada. Pulsa Medir para continuar o limpiar.");
        });
        header.addView(close, new LinearLayout.LayoutParams(dp(44), dp(40)));
        panel.addView(header);

        measureResultView = text("Toca el mapa para agregar el primer punto.", 15, true, Color.WHITE);
        measureResultView.setPadding(0, dp(5), 0, dp(3));
        panel.addView(measureResultView);
        TextView note = text("Cada tramo es una línea recta entre los puntos tocados. Resultado aproximado; no sustituye un levantamiento topográfico.", 11, false, Color.rgb(194, 220, 239));
        panel.addView(note);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(8), 0, 0);
        Button undo = panelButton("↶ Deshacer");
        undo.setOnClickListener(v -> undoMeasure());
        row.addView(undo, weightButton());
        Button finish = panelButton("✓ Finalizar");
        finish.setOnClickListener(v -> {
            measurementActive = false;
            redrawMeasurement();
        });
        row.addView(finish, weightButton());
        Button clear = panelButton("Limpiar");
        clear.setOnClickListener(v -> clearMeasurement());
        row.addView(clear, weightButton());
        panel.addView(row);
        return panel;
    }

    private LinearLayout buildSelectedPanel() {
        LinearLayout panel = floatingPanel();
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Lugar seleccionado", 17, true, Color.WHITE);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = text("×", 28, true, Color.WHITE);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> closeSelectedPoint());
        header.addView(close, new LinearLayout.LayoutParams(dp(44), dp(40)));
        panel.addView(header);

        selectedPlaceView = text("Buscando nombre del lugar…", 13, false, Color.rgb(194, 220, 239));
        selectedPlaceView.setPadding(0, dp(3), 0, dp(5));
        panel.addView(selectedPlaceView);
        selectedCoordsView = text("Latitud / longitud: —", 13, true, Color.WHITE);
        panel.addView(selectedCoordsView);
        selectedUtmView = text("UTM: —", 12, false, Color.rgb(194, 220, 239));
        selectedUtmView.setPadding(0, dp(3), 0, dp(8));
        panel.addView(selectedUtmView);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        Button save = panelButton("Guardar");
        save.setOnClickListener(v -> showSaveSelectedPoint());
        row1.addView(save, weightButton());
        Button copy = panelButton("Copiar");
        copy.setOnClickListener(v -> copySelectedPoint());
        row1.addView(copy, weightButton());
        Button share = panelButton("Compartir");
        share.setOnClickListener(v -> shareSelectedPoint());
        row1.addView(share, weightButton());
        panel.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button measure = panelButton("Medir desde aquí");
        measure.setOnClickListener(v -> startMeasureFromSelected());
        row2.addView(measure, weightButton());
        Button maps = panelButton("Abrir en Maps");
        maps.setOnClickListener(v -> openSelectedInMaps());
        row2.addView(maps, weightButton());
        panel.addView(row2);
        return panel;
    }

    private void setMapMode(String mode) {
        currentMode = mode;
        if (map == null) return;
        String label;
        String tiles;
        int maxZoom;
        if ("satellite".equals(mode)) {
            label = "Satélite";
            tiles = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}";
            maxZoom = 19;
        } else if ("hybrid".equals(mode)) {
            label = "Satélite + nombres";
            map.setStyle(new Style.Builder().fromJson(hybridStyleJson()), style -> onStyleReady(label));
            return;
        } else if ("topo".equals(mode)) {
            label = "Topográfico";
            tiles = "https://a.tile.opentopomap.org/{z}/{x}/{y}.png";
            maxZoom = 17;
        } else if ("relief".equals(mode)) {
            label = "Relieve";
            tiles = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Terrain_Base/MapServer/tile/{z}/{y}/{x}";
            maxZoom = 13;
        } else {
            label = "Calles y lugares";
            tiles = "https://tile.openstreetmap.org/{z}/{x}/{y}.png";
            maxZoom = 19;
        }
        map.setStyle(new Style.Builder().fromJson(rasterStyleJson(tiles, maxZoom)), style -> onStyleReady(label));
    }

    private void onStyleReady(String label) {
        subtitleView.setText("Mapa nativo · " + label.toLowerCase(Locale.ROOT));
        redrawAllAnnotations();
        setStatus(label + " · zoom fluido con dos dedos");
    }

    private String rasterStyleJson(String tileUrl, int maxZoom) {
        return "{\"version\":8,\"sources\":{\"base\":{\"type\":\"raster\",\"tiles\":[\""
                + tileUrl + "\"],\"tileSize\":256,\"maxzoom\":" + maxZoom
                + "}},\"layers\":[{\"id\":\"base\",\"type\":\"raster\",\"source\":\"base\",\"paint\":{\"raster-fade-duration\":120}}]}";
    }

    private String hybridStyleJson() {
        return "{\"version\":8,\"sources\":{"
                + "\"imagery\":{\"type\":\"raster\",\"tiles\":[\"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}\"],\"tileSize\":256,\"maxzoom\":19},"
                + "\"labels\":{\"type\":\"raster\",\"tiles\":[\"https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}\"],\"tileSize\":256,\"maxzoom\":19}"
                + "},\"layers\":["
                + "{\"id\":\"imagery\",\"type\":\"raster\",\"source\":\"imagery\",\"paint\":{\"raster-fade-duration\":120}},"
                + "{\"id\":\"labels\",\"type\":\"raster\",\"source\":\"labels\",\"paint\":{\"raster-opacity\":0.92}}]}";
    }

    private void showLayers() {
        String[] items = {"Calles y lugares", "Satélite", "Satélite + nombres", "Topográfico", "Relieve", "Mapas descargados sin internet"};
        new AlertDialog.Builder(this)
                .setTitle("Capas del mapa")
                .setItems(items, (d, which) -> {
                    if (which == 0) setMapMode("standard");
                    else if (which == 1) setMapMode("satellite");
                    else if (which == 2) setMapMode("hybrid");
                    else if (which == 3) setMapMode("topo");
                    else if (which == 4) setMapMode("relief");
                    else openLegacy("offline_maps");
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showMeasureChooser() {
        String[] items = {"Medir distancia por tramos", "Medir área y perímetro", "Continuar medición", "Limpiar medición"};
        new AlertDialog.Builder(this)
                .setTitle("Medición referencial")
                .setItems(items, (d, which) -> {
                    if (which == 0) startMeasurement(false, true);
                    else if (which == 1) startMeasurement(true, true);
                    else if (which == 2) startMeasurement(areaMode, false);
                    else clearMeasurement();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void startMeasurement(boolean area, boolean clear) {
        areaMode = area;
        measurementActive = true;
        if (clear) measurementPoints.clear();
        selectedPanel.setVisibility(View.GONE);
        measurePanel.setVisibility(View.VISIBLE);
        redrawMeasurement();
    }

    private void undoMeasure() {
        if (!measurementPoints.isEmpty()) measurementPoints.remove(measurementPoints.size() - 1);
        redrawMeasurement();
    }

    private void clearMeasurement() {
        measurementPoints.clear();
        measurementActive = false;
        if (map != null) {
            if (measurementLine != null) map.removePolyline(measurementLine);
            if (measurementPolygon != null) map.removePolygon(measurementPolygon);
        }
        measurementLine = null;
        measurementPolygon = null;
        measurePanel.setVisibility(View.GONE);
        setStatus("Medición eliminada.");
    }

    private void redrawMeasurement() {
        if (map == null) return;
        if (measurementLine != null) map.removePolyline(measurementLine);
        if (measurementPolygon != null) map.removePolygon(measurementPolygon);
        measurementLine = null;
        measurementPolygon = null;

        if (measurementPoints.size() >= 2) {
            measurementLine = map.addPolyline(new PolylineOptions()
                    .addAll(measurementPoints)
                    .color(Color.rgb(0, 188, 212))
                    .width(5f));
        }
        double distance = totalDistance(measurementPoints);
        if (areaMode && measurementPoints.size() >= 3) {
            measurementPolygon = map.addPolygon(new PolygonOptions()
                    .addAll(measurementPoints)
                    .fillColor(Color.argb(55, 0, 188, 212))
                    .strokeColor(Color.rgb(0, 188, 212)));
            double perimeter = distance + haversine(measurementPoints.get(measurementPoints.size() - 1), measurementPoints.get(0));
            double area = polygonArea(measurementPoints);
            measureResultView.setText(String.format(Locale.US, "≈ %.1f m² (%.4f ha) · perímetro ≈ %.1f m · %d lados",
                    area, area / 10000.0, perimeter, measurementPoints.size()));
        } else {
            String km = distance >= 1000 ? String.format(Locale.US, " (%.3f km)", distance / 1000.0) : "";
            measureResultView.setText(String.format(Locale.US, "Distancia total ≈ %.1f m%s · %d tramos",
                    distance, km, Math.max(0, measurementPoints.size() - 1)));
        }
    }

    private void showSelectedPoint(LatLng point) {
        selectedPoint = point;
        selectedPanel.setVisibility(View.VISIBLE);
        measurePanel.setVisibility(View.GONE);
        if (selectedMarker != null && map != null) map.removeMarker(selectedMarker);
        if (map != null) selectedMarker = map.addMarker(new MarkerOptions().position(point).title("Lugar seleccionado"));
        selectedCoordsView.setText(String.format(Locale.US, "Lat/Lon: %.8f, %.8f", point.getLatitude(), point.getLongitude()));
        UtmCoordinate utm = toUtm(point.getLatitude(), point.getLongitude());
        selectedUtmView.setText(utm.valid
                ? String.format(Locale.US, "UTM %d %s · E %.3f m · N %.3f m", utm.zone, utm.hemisphere, utm.easting, utm.northing)
                : "UTM no disponible");
        selectedPlaceView.setText("Buscando nombre del lugar y dirección…");
        lookupAddress(point, true);
    }

    private void closeSelectedPoint() {
        selectedPanel.setVisibility(View.GONE);
        selectedPoint = null;
        if (selectedMarker != null && map != null) map.removeMarker(selectedMarker);
        selectedMarker = null;
    }

    private void lookupAddress(LatLng point, boolean selected) {
        lookupExecutor.execute(() -> {
            String result = geocodeWithAndroid(point.getLatitude(), point.getLongitude());
            if (result.isEmpty()) result = geocodeWithNominatim(point.getLatitude(), point.getLongitude());
            final String address = result;
            runOnUiThread(() -> {
                if (selected) {
                    if (selectedPoint == null) return;
                    selectedPlaceView.setText(address.isEmpty()
                            ? "Lugar no identificado. Las coordenadas sí son válidas."
                            : "Lugar: " + address);
                } else {
                    currentPlaceName = address;
                    updateLocationStatus();
                }
            });
        });
    }

    private String geocodeWithAndroid(double lat, double lon) {
        try {
            Geocoder geocoder = new Geocoder(this, new Locale("es", "PE"));
            List<Address> addresses = geocoder.getFromLocation(lat, lon, 1);
            if (addresses == null || addresses.isEmpty()) return "";
            Address a = addresses.get(0);
            String line = a.getMaxAddressLineIndex() >= 0 ? a.getAddressLine(0) : "";
            if (line != null && !line.trim().isEmpty()) return line.trim();
            StringBuilder out = new StringBuilder();
            appendPart(out, a.getThoroughfare());
            appendPart(out, a.getSubLocality());
            appendPart(out, a.getLocality());
            appendPart(out, a.getAdminArea());
            return out.toString();
        } catch (Exception ignored) {
            return "";
        }
    }

    private String geocodeWithNominatim(double lat, double lon) {
        HttpURLConnection connection = null;
        try {
            String address = "https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=18&addressdetails=1&lat="
                    + URLEncoder.encode(Double.toString(lat), "UTF-8") + "&lon="
                    + URLEncoder.encode(Double.toString(lon), "UTF-8");
            connection = (HttpURLConnection) new URL(address).openConnection();
            connection.setConnectTimeout(8000);
            connection.setReadTimeout(10000);
            connection.setRequestProperty("User-Agent", "GeoTopo/1.15 Android");
            connection.setRequestProperty("Accept-Language", "es");
            if (connection.getResponseCode() < 200 || connection.getResponseCode() >= 300) return "";
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder json = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) json.append(line);
            return new JSONObject(json.toString()).optString("display_name", "");
        } catch (Exception ignored) {
            return "";
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private void showSaveSelectedPoint() {
        if (selectedPoint == null) return;
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(6), dp(18), 0);
        EditText name = new EditText(this);
        name.setHint("Nombre del punto");
        name.setText(nextMapPointName());
        panel.addView(name);
        EditText project = new EditText(this);
        project.setHint("Proyecto");
        project.setText(getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString("current_project", "Puntos de mapa"));
        panel.addView(project);
        EditText description = new EditText(this);
        description.setHint("Descripción");
        description.setText(selectedPlaceView.getText().toString().replace("Lugar: ", ""));
        panel.addView(description);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Guardar punto")
                .setView(panel)
                .setPositiveButton("Guardar", null)
                .setNegativeButton("Cancelar", null)
                .create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(b -> {
            String pointName = name.getText().toString().trim();
            if (pointName.isEmpty()) {
                name.setError("Escribe un nombre");
                return;
            }
            persistSelectedPoint(project.getText().toString().trim(), pointName, description.getText().toString().trim());
            dialog.dismiss();
        }));
        dialog.show();
    }

    private void persistSelectedPoint(String project, String name, String description) {
        if (selectedPoint == null) return;
        if (project.isEmpty()) project = "Puntos de mapa";
        try {
            SharedPreferences sp = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
            JSONArray array;
            try { array = new JSONArray(sp.getString(KEY_POINTS, "[]")); }
            catch (JSONException ex) { array = new JSONArray(); }
            JSONObject p = new JSONObject();
            p.put("project", project);
            p.put("name", name);
            p.put("description", description);
            p.put("latitude", selectedPoint.getLatitude());
            p.put("longitude", selectedPoint.getLongitude());
            p.put("altitude", JSONObject.NULL);
            p.put("accuracy", JSONObject.NULL);
            p.put("speedKmh", JSONObject.NULL);
            p.put("bearing", JSONObject.NULL);
            p.put("timestamp", System.currentTimeMillis());
            p.put("provider", "map_selection");
            p.put("photoUri", "");
            array.put(p);
            sp.edit().putString(KEY_POINTS, array.toString()).putString("current_project", project).apply();
            loadSavedPoints();
            Toast.makeText(this, "Punto guardado", Toast.LENGTH_SHORT).show();
        } catch (JSONException ex) {
            Toast.makeText(this, "No se pudo guardar el punto.", Toast.LENGTH_LONG).show();
        }
    }

    private void copySelectedPoint() {
        if (selectedPoint == null) return;
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("Punto GeoTopo", selectedPointText()));
        Toast.makeText(this, "Punto copiado", Toast.LENGTH_SHORT).show();
    }

    private void shareSelectedPoint() {
        if (selectedPoint == null) return;
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, selectedPointText());
        startActivity(Intent.createChooser(intent, "Compartir punto"));
    }

    private String selectedPointText() {
        if (selectedPoint == null) return "";
        StringBuilder out = new StringBuilder();
        String place = selectedPlaceView.getText().toString();
        if (!place.startsWith("Buscando") && !place.startsWith("Lugar no")) out.append(place).append('\n');
        out.append(String.format(Locale.US, "Latitud: %.8f\nLongitud: %.8f", selectedPoint.getLatitude(), selectedPoint.getLongitude()));
        UtmCoordinate utm = toUtm(selectedPoint.getLatitude(), selectedPoint.getLongitude());
        if (utm.valid) out.append(String.format(Locale.US, "\nUTM %d %s\nEste: %.3f m\nNorte: %.3f m", utm.zone, utm.hemisphere, utm.easting, utm.northing));
        return out.toString();
    }

    private void startMeasureFromSelected() {
        if (selectedPoint == null) return;
        measurementPoints.clear();
        measurementPoints.add(selectedPoint);
        startMeasurement(false, false);
        closeSelectedPoint();
    }

    private void openSelectedInMaps() {
        if (selectedPoint == null) return;
        Uri uri = Uri.parse(String.format(Locale.US, "geo:%.8f,%.8f?q=%.8f,%.8f", selectedPoint.getLatitude(), selectedPoint.getLongitude(), selectedPoint.getLatitude(), selectedPoint.getLongitude()));
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
        catch (Exception ex) { Toast.makeText(this, "No hay una app de mapas disponible.", Toast.LENGTH_LONG).show(); }
    }

    private void loadSavedPoints() {
        if (map == null) return;
        for (Marker marker : savedPointMarkers) map.removeMarker(marker);
        savedPointMarkers.clear();
        try {
            JSONArray array = new JSONArray(getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                double lat = item.optDouble("latitude", Double.NaN);
                double lon = item.optDouble("longitude", Double.NaN);
                if (Double.isNaN(lat) || Double.isNaN(lon)) continue;
                String name = item.optString("name", "P" + (i + 1));
                savedPointMarkers.add(map.addMarker(new MarkerOptions().position(new LatLng(lat, lon)).title(name)));
            }
            setStatus(array.length() == 0 ? "No hay puntos guardados." : "Mostrando " + array.length() + " puntos guardados.");
        } catch (Exception ex) {
            setStatus("No se pudieron cargar los puntos guardados.");
        }
    }

    private void centerOnCurrentLocation(boolean forceNew) {
        if (currentLocation != null) {
            moveCameraToLocation(currentLocation, 17.0);
            updateLocationStatus();
        }
        if (forceNew || currentLocation == null || System.currentTimeMillis() - currentLocation.getTime() > 30000L) {
            requestLocationUpdates();
        }
    }

    private void requestLocationUpdates() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
            return;
        }
        try {
            locationRequestStartedAt = System.currentTimeMillis();
            setStatus("Buscando tu ubicación actual…");
            Location gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location network = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            Location last = chooseBetter(gps, network);
            if (last != null && System.currentTimeMillis() - last.getTime() < 10 * 60 * 1000L) {
                onLocationChanged(last);
            }
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0.5f, this);
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1500L, 1f, this);
            }
            handler.removeCallbacks(locationTimeout);
            handler.postDelayed(locationTimeout, 15000L);
        } catch (Exception ex) {
            setStatus("No se pudo iniciar la ubicación. Revisa el permiso y el GPS.");
        }
    }

    private final Runnable locationTimeout = () -> {
        if (currentLocation == null) {
            setStatus("No llegó una ubicación nueva. Pulsa Ubicación para reintentar o abre GPS y puntos.");
        } else {
            updateLocationStatus();
        }
    };

    @Override
    public void onLocationChanged(Location location) {
        if (location == null || !location.hasAccuracy()) return;
        if (currentLocation == null || isBetterLocation(location, currentLocation)) {
            currentLocation = new Location(location);
            saveRememberedLocation(currentLocation);
            redrawLocation();
            if (map != null && (locationRequestStartedAt > 0 || map.getCameraPosition().zoom < 10)) {
                moveCameraToLocation(currentLocation, 17.0);
            }
            currentPlaceName = "";
            lookupAddress(new LatLng(location.getLatitude(), location.getLongitude()), false);
            updateLocationStatus();
        }
    }

    private void redrawLocation() {
        if (map == null || currentLocation == null) return;
        if (locationMarker != null) map.removeMarker(locationMarker);
        if (accuracyPolygon != null) map.removePolygon(accuracyPolygon);
        LatLng p = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());
        locationMarker = map.addMarker(new MarkerOptions().position(p).title("Tu ubicación"));
        if (currentLocation.hasAccuracy()) {
            accuracyPolygon = map.addPolygon(new PolygonOptions()
                    .addAll(circlePoints(p, currentLocation.getAccuracy(), 48))
                    .fillColor(Color.argb(35, 41, 121, 255))
                    .strokeColor(Color.argb(150, 41, 121, 255)));
        }
    }

    private void redrawAllAnnotations() {
        locationMarker = null;
        accuracyPolygon = null;
        measurementLine = null;
        measurementPolygon = null;
        selectedMarker = null;
        savedPointMarkers.clear();
        redrawLocation();
        redrawMeasurement();
        loadSavedPoints();
        if (selectedPoint != null) showSelectedPoint(selectedPoint);
    }

    private void moveCameraToLocation(Location location, double zoom) {
        if (map == null || location == null) return;
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(location.getLatitude(), location.getLongitude()), zoom), 650);
    }

    private void updateLocationStatus() {
        if (currentLocation == null) return;
        String provider = LocationManager.GPS_PROVIDER.equals(currentLocation.getProvider()) ? "GPS/GNSS" : "ubicación asistida";
        String place = currentPlaceName == null || currentPlaceName.isEmpty() ? "Tu ubicación" : shortPlace(currentPlaceName);
        setStatus(place + " · ± " + String.format(Locale.US, "%.1f", currentLocation.getAccuracy()) + " m · " + provider);
    }

    private String shortPlace(String value) {
        String[] parts = value.split(",");
        if (parts.length <= 3) return value;
        return parts[0].trim() + ", " + parts[1].trim() + ", " + parts[2].trim();
    }

    private void loadRememberedLocation() {
        SharedPreferences sp = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
        try {
            String lat = sp.getString("last_latitude", "");
            String lon = sp.getString("last_longitude", "");
            if (lat.isEmpty() || lon.isEmpty()) return;
            Location remembered = new Location("guardada");
            remembered.setLatitude(Double.parseDouble(lat));
            remembered.setLongitude(Double.parseDouble(lon));
            remembered.setAccuracy(sp.getFloat("last_accuracy", 0f));
            remembered.setTime(sp.getLong("last_location_time", System.currentTimeMillis()));
            currentLocation = remembered;
        } catch (Exception ignored) { }
    }

    private void saveRememberedLocation(Location location) {
        getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit()
                .putString("last_latitude", Double.toString(location.getLatitude()))
                .putString("last_longitude", Double.toString(location.getLongitude()))
                .putFloat("last_accuracy", location.getAccuracy())
                .putLong("last_location_time", location.getTime() > 0 ? location.getTime() : System.currentTimeMillis())
                .apply();
    }

    private Location chooseBetter(Location a, Location b) {
        if (a == null) return b;
        if (b == null) return a;
        if (a.hasAccuracy() && b.hasAccuracy() && a.getAccuracy() != b.getAccuracy()) return a.getAccuracy() < b.getAccuracy() ? a : b;
        return a.getTime() >= b.getTime() ? a : b;
    }

    private boolean isBetterLocation(Location candidate, Location current) {
        if (current == null) return true;
        long dt = candidate.getTime() - current.getTime();
        if (dt > 30000L) return true;
        if (dt < -120000L) return false;
        float ca = candidate.hasAccuracy() ? candidate.getAccuracy() : 9999f;
        float oa = current.hasAccuracy() ? current.getAccuracy() : 9999f;
        return ca <= oa + 5f || dt > 5000L;
    }

    private void openLegacy(String action) {
        Intent intent = new Intent(this, LegacyMapActivity.class);
        intent.putExtra("native_action", action);
        startActivity(intent);
    }

    private void showInfo() {
        new AlertDialog.Builder(this)
                .setTitle("Mapa nativo GeoTopo")
                .setMessage("El mapa ahora usa MapLibre y la GPU del teléfono para mover y ampliar con mayor fluidez.\n\n"
                        + "Mantén pulsado un lugar para ver su nombre, dirección, coordenadas y UTM.\n\n"
                        + "Las mediciones sobre imagen son referenciales. Los mapas descargados anteriormente siguen disponibles mediante la opción de mapas offline.")
                .setPositiveButton("Entendido", null)
                .show();
    }

    private void setStatus(String text) {
        if (statusView != null) statusView.setText(text);
    }

    private void appendPart(StringBuilder out, String value) {
        if (value == null || value.trim().isEmpty()) return;
        if (out.length() > 0) out.append(", ");
        out.append(value.trim());
    }

    private double totalDistance(List<LatLng> points) {
        double total = 0;
        for (int i = 1; i < points.size(); i++) total += haversine(points.get(i - 1), points.get(i));
        return total;
    }

    private double haversine(LatLng a, LatLng b) {
        final double r = 6371008.8;
        double p1 = Math.toRadians(a.getLatitude());
        double p2 = Math.toRadians(b.getLatitude());
        double dp = Math.toRadians(b.getLatitude() - a.getLatitude());
        double dl = Math.toRadians(b.getLongitude() - a.getLongitude());
        double q = Math.sin(dp / 2) * Math.sin(dp / 2)
                + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
        return 2 * r * Math.atan2(Math.sqrt(q), Math.sqrt(1 - q));
    }

    private double polygonArea(List<LatLng> points) {
        if (points.size() < 3) return 0;
        double meanLat = 0;
        for (LatLng p : points) meanLat += p.getLatitude();
        meanLat = Math.toRadians(meanLat / points.size());
        double scaleX = 111320.0 * Math.cos(meanLat);
        double scaleY = 110540.0;
        double area = 0;
        for (int i = 0; i < points.size(); i++) {
            LatLng a = points.get(i);
            LatLng b = points.get((i + 1) % points.size());
            area += (a.getLongitude() * scaleX) * (b.getLatitude() * scaleY)
                    - (b.getLongitude() * scaleX) * (a.getLatitude() * scaleY);
        }
        return Math.abs(area) / 2.0;
    }

    private List<LatLng> circlePoints(LatLng center, double radiusMeters, int count) {
        List<LatLng> points = new ArrayList<>();
        double lat = Math.toRadians(center.getLatitude());
        double lon = Math.toRadians(center.getLongitude());
        double angular = radiusMeters / 6371008.8;
        for (int i = 0; i <= count; i++) {
            double bearing = 2.0 * Math.PI * i / count;
            double lat2 = Math.asin(Math.sin(lat) * Math.cos(angular)
                    + Math.cos(lat) * Math.sin(angular) * Math.cos(bearing));
            double lon2 = lon + Math.atan2(Math.sin(bearing) * Math.sin(angular) * Math.cos(lat),
                    Math.cos(angular) - Math.sin(lat) * Math.sin(lat2));
            points.add(new LatLng(Math.toDegrees(lat2), Math.toDegrees(lon2)));
        }
        return points;
    }

    private String nextMapPointName() {
        try {
            JSONArray array = new JSONArray(getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]"));
            int n = 1;
            while (true) {
                String candidate = "M" + n;
                boolean used = false;
                for (int i = 0; i < array.length(); i++) {
                    JSONObject item = array.optJSONObject(i);
                    if (item != null && candidate.equalsIgnoreCase(item.optString("name"))) { used = true; break; }
                }
                if (!used) return candidate;
                n++;
            }
        } catch (Exception ignored) {
            return "M1";
        }
    }

    private static UtmCoordinate toUtm(double latitude, double longitude) {
        if (latitude < -80.0 || latitude > 84.0 || longitude < -180.0 || longitude > 180.0) return UtmCoordinate.invalid();
        final double a = 6378137.0;
        final double eccSquared = 0.00669438;
        final double k0 = 0.9996;
        int zoneNumber = (int) Math.floor((longitude + 180.0) / 6.0) + 1;
        if (longitude == 180.0) zoneNumber = 60;
        if (latitude >= 56.0 && latitude < 64.0 && longitude >= 3.0 && longitude < 12.0) zoneNumber = 32;
        if (latitude >= 72.0 && latitude < 84.0) {
            if (longitude < 9.0) zoneNumber = 31;
            else if (longitude < 21.0) zoneNumber = 33;
            else if (longitude < 33.0) zoneNumber = 35;
            else if (longitude < 42.0) zoneNumber = 37;
        }
        double lonOrigin = (zoneNumber - 1) * 6.0 - 180.0 + 3.0;
        double latRad = Math.toRadians(latitude);
        double lonRad = Math.toRadians(longitude);
        double lonOriginRad = Math.toRadians(lonOrigin);
        double eccPrimeSquared = eccSquared / (1.0 - eccSquared);
        double sinLat = Math.sin(latRad);
        double cosLat = Math.cos(latRad);
        double tanLat = Math.tan(latRad);
        double n = a / Math.sqrt(1.0 - eccSquared * sinLat * sinLat);
        double t = tanLat * tanLat;
        double c = eccPrimeSquared * cosLat * cosLat;
        double aa = cosLat * (lonRad - lonOriginRad);
        double m = a * ((1.0 - eccSquared / 4.0 - 3.0 * eccSquared * eccSquared / 64.0 - 5.0 * Math.pow(eccSquared, 3) / 256.0) * latRad
                - (3.0 * eccSquared / 8.0 + 3.0 * eccSquared * eccSquared / 32.0 + 45.0 * Math.pow(eccSquared, 3) / 1024.0) * Math.sin(2.0 * latRad)
                + (15.0 * eccSquared * eccSquared / 256.0 + 45.0 * Math.pow(eccSquared, 3) / 1024.0) * Math.sin(4.0 * latRad)
                - (35.0 * Math.pow(eccSquared, 3) / 3072.0) * Math.sin(6.0 * latRad));
        double easting = k0 * n * (aa + (1.0 - t + c) * Math.pow(aa, 3) / 6.0
                + (5.0 - 18.0 * t + t * t + 72.0 * c - 58.0 * eccPrimeSquared) * Math.pow(aa, 5) / 120.0) + 500000.0;
        double northing = k0 * (m + n * tanLat * (aa * aa / 2.0
                + (5.0 - t + 9.0 * c + 4.0 * c * c) * Math.pow(aa, 4) / 24.0
                + (61.0 - 58.0 * t + t * t + 600.0 * c - 330.0 * eccPrimeSquared) * Math.pow(aa, 6) / 720.0));
        String hemisphere = latitude < 0.0 ? "S" : "N";
        if (latitude < 0.0) northing += 10000000.0;
        return new UtmCoordinate(true, zoneNumber, hemisphere, easting, northing);
    }

    private LinearLayout floatingPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(11), dp(14), dp(11));
        panel.setBackground(pill(Color.argb(247, 4, 36, 58), dp(20), Color.argb(90, 255, 255, 255)));
        panel.setElevation(dp(14));
        return panel;
    }

    private Button panelButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setBackground(pill(accentColor, dp(12), Color.argb(80, 255, 255, 255)));
        return b;
    }

    private LinearLayout.LayoutParams weightButton() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(50), 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    private View mapTool(String icon, String label, View.OnClickListener listener) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setOnClickListener(listener);
        TextView iconView = text(icon, 23, true, Color.WHITE);
        iconView.setGravity(Gravity.CENTER);
        iconView.setBackground(pill(accentColor, dp(22), Color.argb(100, 255, 255, 255)));
        iconView.setOnClickListener(listener);
        item.addView(iconView, new LinearLayout.LayoutParams(dp(44), dp(44)));
        TextView caption = text(label, 9, false, Color.WHITE);
        caption.setGravity(Gravity.CENTER);
        item.addView(caption, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(18)));
        return item;
    }

    private LinearLayout.LayoutParams toolParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        return lp;
    }

    private TextView roundText(String value, String description) {
        TextView view = text(value, 24, true, Color.WHITE);
        view.setGravity(Gravity.CENTER);
        view.setContentDescription(description);
        view.setBackground(pill(accentColor, dp(24), Color.argb(110, 255, 255, 255)));
        return view;
    }

    private TextView text(String value, float size, boolean bold, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private GradientDrawable pill(int fill, int radius, int stroke) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(fill);
        gd.setCornerRadius(radius);
        gd.setStroke(dp(1), stroke);
        return gd;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            boolean granted = false;
            for (int value : grantResults) if (value == PackageManager.PERMISSION_GRANTED) granted = true;
            if (granted) requestLocationUpdates();
            else setStatus("Permiso de ubicación denegado.");
        }
    }

    @Override protected void onStart() { super.onStart(); mapView.onStart(); }
    @Override protected void onResume() { super.onResume(); mapView.onResume(); }
    @Override protected void onPause() { try { if (locationManager != null) locationManager.removeUpdates(this); } catch (Exception ignored) { } mapView.onPause(); super.onPause(); }
    @Override protected void onStop() { mapView.onStop(); super.onStop(); }
    @Override public void onLowMemory() { super.onLowMemory(); mapView.onLowMemory(); }
    @Override protected void onDestroy() { lookupExecutor.shutdownNow(); handler.removeCallbacksAndMessages(null); mapView.onDestroy(); super.onDestroy(); }
    @Override protected void onSaveInstanceState(Bundle outState) { super.onSaveInstanceState(outState); mapView.onSaveInstanceState(outState); }

    private static final class UtmCoordinate {
        final boolean valid;
        final int zone;
        final String hemisphere;
        final double easting;
        final double northing;

        UtmCoordinate(boolean valid, int zone, String hemisphere, double easting, double northing) {
            this.valid = valid;
            this.zone = zone;
            this.hemisphere = hemisphere;
            this.easting = easting;
            this.northing = northing;
        }

        static UtmCoordinate invalid() {
            return new UtmCoordinate(false, 0, "", Double.NaN, Double.NaN);
        }
    }
}
