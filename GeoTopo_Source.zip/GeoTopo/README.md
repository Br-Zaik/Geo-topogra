# GeoTopo 1.19.0

Aplicación Android de cálculos topográficos, GPS/GNSS, mapas, medición y conversión de unidades.

## Cambios principales

- El proyecto conserva únicamente el visor moderno MapLibre Native, con aceleración por GPU, giro con dos dedos y zoom fluido.
- Se eliminó por completo el visor antiguo basado en WebView (`LegacyMapActivity` y `map.html`) para evitar que vuelva a abrirse por error.
- La lupa superior permite buscar ciudades, distritos, comunidades, calles y coordenadas. La consulta se ejecuta solo al pulsar **Buscar**, no como autocompletado continuo.
- La capa **Relieve** combina el mapa base con sombreado de elevación. Si el sombreado no carga, el mapa base continúa visible y no queda una pantalla gris.
- Las mediciones conservan P1, P2, P3 y las etiquetas de los tramos; solo se mejoraron las líneas de borde con contraste blanco y azul.
- Se mantienen los conversores ampliados de la versión anterior.

## Categorías del conversor

- Área
- Distancia
- Peso
- Volumen
- Energía
- Temperatura
- Velocidad
- Potencia
- Ángulo y pendiente

La temperatura convierte entre Celsius, Fahrenheit y Kelvin mediante fórmulas con desplazamiento.

## Compilación en GitHub

El repositorio debe contener `GeoTopo_Source.zip`. Ejecuta el workflow **Build APK from ZIP** desde la pestaña Actions.
