# GeoTopo 1.12

Aplicación Android de apoyo para cálculos topográficos, GPS/GNSS y cartografía online/offline.

## Correcciones principales

- En modo **Solo GPS/GNSS**, la app ya no reutiliza ubicaciones de red ni presenta lecturas extremadamente imprecisas como si fueran satelitales.
- Una lectura con precisión peor de ±50 m no puede iniciar el promedio ni guardarse como punto definitivo.
- El botón **Promediar** solo se activa cuando existe una lectura reciente y válida.
- El promedio informa lecturas aceptadas y descartadas y elimina valores claramente anómalos.
- En modo automático, una posición de red queda identificada como aproximada y es sustituida cuando llega una lectura GPS mejor.
- La capa **Relieve** usa un mapa topográfico con relieve más estable. Si falla, la app cambia al mapa Topográfico y muestra el aviso en español.
- Las mediciones tocando el mapa ahora se identifican claramente como **referenciales** y usan el símbolo ≈.
- Se redujo la falsa precisión visual de distancias y áreas: las medidas sobre mapa se muestran con decimales razonables.
- El menú Medir permite abrir **GPS y puntos** para registrar vértices en campo.

## Aclaraciones

- La medición sobre la imagen satelital es aproximada y depende de dónde se toque y de la alineación del proveedor.
- Un perímetro de 300 m puede ser correcto para una manzana de aproximadamente 70 a 80 m por lado.
- La precisión indicada por Android es estimada; GeoTopo no sustituye un receptor GNSS RTK.
- La fotografía satelital necesita internet.

## Compilación en GitHub

El repositorio debe contener `GeoTopo_Source.zip`. Ejecuta el workflow **Build APK from ZIP** desde la pestaña Actions y descarga el artefacto `GeoTopo-debug-apk`.
