# GeoTopo 1.4

Aplicación Android de apoyo para cálculos topográficos, orientación, GPS y mapas.

## Funciones principales

- Azimut, rumbo, contraazimut y contrarrumbo.
- Coordenadas parciales, distancias, pendiente y desnivel.
- Distancia por dos hilos.
- Poligonal cerrada con corrección, coordenadas, área, perímetro y gráfico.
- Nivelación simple y nivelación con tres hilos.
- Registro GPS con latitud, longitud, UTM, altitud GNSS, precisión, velocidad, rumbo de movimiento y satélites.
- Promedio de lecturas GPS y organización de puntos por proyectos.
- Exportación en CSV, KML y GPX.
- Mapa estándar, satelital, híbrido y topográfico con internet.
- Cartografía vectorial descargable para uso offline.
- Medición de distancias y áreas sobre el mapa.

## Correcciones y mejoras de la versión 1.4

- El cuadro de configuración GPS ahora usa colores legibles en tema oscuro.
- La pantalla identifica claramente que los datos corresponden a la ubicación actual del teléfono.
- La fecha de la lectura muestra su antigüedad: ahora, segundos, minutos o lectura antigua.
- El rumbo GPS solo aparece cuando existe movimiento suficiente; estando detenido muestra que no está disponible.
- El rumbo guardado en los puntos también se descarta cuando el teléfono está detenido.
- La altitud se identifica como altitud GNSS para evitar confundirla con una cota topográfica.
- No se permite guardar silenciosamente una lectura con más de 30 segundos de antigüedad.
- El mapa intenta mostrar y centrar automáticamente la ubicación cuando ya existe permiso.
- La ubicación se representa con punto azul, círculo de precisión y flecha únicamente cuando hay un rumbo válido.
- La interfaz del mapa usa una barra inferior compacta con iconos y nombres: Ubicación, Capas, Puntos, Medir y Más.
- Se eliminan los controles flotantes ambiguos de la derecha.
- El tipo de mapa se muestra en el subtítulo superior.
- La escala se presenta como una barra convencional y se oculta en vistas demasiado alejadas.
- Se aumentó la saturación y el contraste de la cartografía para evitar el aspecto apagado.
- El gesto de zoom se actualiza mediante cuadros de animación para reducir bloqueos.
- La vista satelital limita la fuente a un nivel con mayor probabilidad de cobertura y aplica sobrezoom local.
- Los cuadros de descarga offline también usan texto legible.

## Importante

- Las calculadoras, el GPS, la exportación y el cálculo A-B funcionan sin internet.
- El mapa satelital requiere internet.
- Los mapas offline son vectoriales y no incluyen imágenes satelitales.
- El modo GPS indica la dirección de desplazamiento, no la orientación física del teléfono cuando está detenido.
- Un teléfono sin magnetómetro no puede conocer hacia dónde apunta estando quieto; para eso se usa la línea A-B.
- El GPS interno del teléfono no sustituye un receptor GNSS RTK para trabajos de precisión centimétrica.

## Compilar con GitHub Actions

El repositorio debe contener este proyecto dentro del archivo `GeoTopo_Source.zip`, junto al workflow `.github/workflows/build-apk.yml`.

1. Abre la pestaña **Actions**.
2. Ejecuta **Build APK from ZIP**.
3. Espera a que la compilación termine correctamente.
4. Descarga el artefacto **GeoTopo-debug-apk**.

El APK generado es una versión de depuración para instalación y pruebas.
