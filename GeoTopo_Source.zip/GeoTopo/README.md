# GeoTopo

Versión actual: **1.20.6**

La medición permite personalizar color, tamaño de puntos, números de tramos, resumen central y grosor de líneas desde el botón visible `⚙ Apariencia de medición`.

Los números T1, T2, T3 y Cierre tienen cuatro tamaños, incluyendo `Muy grandes`, y el valor predeterminado profesional es `Grandes`.
