# GeoTopo 1.8

Aplicación Android de apoyo para cálculos topográficos, orientación, GPS y mapas.

## Funciones principales

- Azimut, rumbo, contraazimut y contrarrumbo.
- Coordenadas parciales, distancias, pendiente y desnivel.
- Distancia por dos hilos.
- Poligonal cerrada con corrección, coordenadas, área, perímetro y gráfico.
- Nivelación simple y nivelación con tres hilos.
- Registro GPS con latitud, longitud, UTM, altitud GNSS, precisión, velocidad, rumbo de movimiento y satélites.
- Promedio de lecturas GPS y organización de puntos por proyectos.
- Exportación en CSV, KML y GPX.
- Mapas de calles y lugares, satélite, satélite con nombres, topográfico y cartografía offline.
- Medición guiada de distancias, áreas y perímetros sobre el mapa.

## Mejoras de la versión 1.8

- Nuevo asistente para descargar mapas offline sin depender de lo que casualmente esté visible en pantalla.
- Cuatro formas de elegir la zona:
  - Radio de 1, 3, 5 o 10 km alrededor de la ubicación actual.
  - Rectángulo ajustable directamente sobre el mapa.
  - Búsqueda de ciudad, distrito o lugar para centrar el mapa y elegir el sector exacto.
  - Uso del área visible actual como punto de partida.
- Marco visual con cuatro esquinas arrastrables.
- Cálculo en vivo del área seleccionada y de sus dimensiones aproximadas.
- Vista previa del sector antes de confirmar la descarga.
- Estimación orientativa del tamaño y visualización del espacio disponible.
- Opción para permitir la descarga únicamente cuando exista conexión Wi-Fi.
- Advertencia antes de iniciar una selección demasiado pesada para el nivel de detalle elegido.
- Botón para regresar al mapa y reajustar el marco sin perder la selección.

## Cómo descargar un mapa offline

1. Abre el mapa y entra en **Más → Descargar mapa offline**.
2. Elige una opción:
   - **Alrededor de mi ubicación** para usar un radio rápido.
   - **Seleccionar un área en el mapa** para dibujar el sector manualmente.
   - **Buscar ciudad, distrito o lugar** para llegar primero a una zona concreta.
   - **Usar el área visible actual** para comenzar con lo que aparece en pantalla.
3. Mueve el mapa y arrastra las cuatro esquinas del marco turquesa.
4. Revisa el área en km² y las dimensiones aproximadas.
5. Pulsa **Usar esta zona**.
6. Escribe un nombre y elige el detalle:
   - **Básico:** vías principales, poblaciones y agua.
   - **Medio:** calles, caminos, agua, ferrocarril y terreno.
   - **Alto:** agrega edificios y está pensado para sectores pequeños.
7. Revisa el tamaño orientativo y pulsa **Descargar**.

## Datos cartográficos

- **Calles y lugares** usa cartografía OpenStreetMap y muestra carreteras, edificios y lugares cuando existen en la base de datos y el zoom es suficiente.
- **Satélite** muestra solamente imagen aérea.
- **Satélite + nombres** superpone vías, límites y nombres sobre la imagen.
- Los mapas offline son vectoriales y no incluyen imagen satelital.

## Importante

- Las calculadoras, el GPS, la exportación, el cálculo A-B y los mapas ya descargados funcionan sin internet.
- La búsqueda de lugares, los mapas online y la descarga inicial requieren internet.
- La estimación del tamaño es orientativa: una zona urbana densa puede contener muchos más datos que una zona rural del mismo tamaño.
- El GPS interno del teléfono no sustituye un receptor GNSS RTK para trabajos de precisión centimétrica.

## Compilar con GitHub Actions

El repositorio debe contener este proyecto dentro del archivo `GeoTopo_Source.zip`, junto al workflow `.github/workflows/build-apk.yml`.

1. Abre **Actions**.
2. Ejecuta **Build APK from ZIP**.
3. Espera a que la compilación termine correctamente.
4. Descarga el artefacto **GeoTopo-debug-apk**.


## Cambios 1.8
- Selector de descarga visible con botones de 1, 3, 5 y 10 km.
- Selección manual, búsqueda de lugar y mapas guardados desde el mismo panel.
- Medición muestra metros, kilómetros y cantidad de tramos.
- Cada tramo se identifica en el mapa.
