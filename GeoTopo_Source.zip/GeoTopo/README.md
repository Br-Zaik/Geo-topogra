# GeoTopo 1.3

Aplicación Android de apoyo para cálculos topográficos, orientación, GPS y mapas.

## Funciones principales

- Azimut, rumbo, contraazimut y contrarrumbo.
- Coordenadas parciales, distancias, pendiente y desnivel.
- Distancia por dos hilos.
- Poligonal cerrada con corrección, coordenadas, área, perímetro y gráfico.
- Nivelación simple y nivelación con tres hilos.
- Registro GPS con latitud, longitud, UTM, altitud GNSS, precisión, velocidad, rumbo y satélites.
- Promedio de lecturas GPS y organización de puntos por proyectos.
- Exportación en CSV, KML y GPX.
- Mapa estándar, satelital, híbrido y topográfico con internet.
- Cartografía vectorial descargable para uso offline.
- Medición de distancias y áreas sobre el mapa.

## Mejoras de la versión 1.3

- Brújula magnética con filtrado de lecturas, compensación por rotación de pantalla e indicador de calidad del sensor.
- Opción de corregir la brújula a norte verdadero cuando existe una ubicación disponible.
- Aviso de calibración cuando el magnetómetro no es confiable.
- Dirección de movimiento GPS filtrada para teléfonos sin magnetómetro.
- Orientación mediante puntos A y B con promedio de lecturas durante 10 segundos en cada punto.
- Cálculo automático de distancia, azimut, rumbo, incertidumbre angular aproximada y distancia mínima recomendada.
- Visualización de la línea A-B, flecha, distancia, azimut y círculos de precisión en el mapa.
- Zoom del mapa con dos dedos, doble toque y arrastre sin redibujar todos los elementos durante cada movimiento.
- Sobrezoom de imágenes satelitales para evitar pedir mosaicos que el proveedor no tiene en niveles muy altos.
- Marcador GPS profesional con punto azul, círculo de precisión y flecha de movimiento.
- Interfaz del mapa simplificada con controles flotantes y menús compactos.
- Eliminación de la referencia extensa de cuadrantes debajo de Azimut y rumbo.

## Importante

- Las calculadoras, el GPS, la exportación y el cálculo A-B funcionan sin internet.
- El mapa satelital requiere internet.
- Los mapas offline son vectoriales y no incluyen imágenes satelitales.
- El modo GPS indica la dirección de desplazamiento, no la orientación física del teléfono cuando está detenido.
- Un teléfono sin magnetómetro no puede conocer hacia dónde apunta estando quieto; para eso se usa la línea A-B.
- El GPS interno del teléfono no sustituye un receptor GNSS RTK para trabajos de precisión centimétrica.

## Compilar con GitHub Actions

El repositorio debe contener este proyecto dentro del archivo `GeoTopo_Source.zip`, junto al workflow `.github/workflows/build-apk.yml`.

1. Abre la pestaña **Actions**.
2. Ejecuta **Build APK from ZIP**.
3. Espera a que la compilación termine correctamente.
4. Descarga el artefacto **GeoTopo-debug-apk**.

El APK generado es una versión de depuración para instalación y pruebas.
