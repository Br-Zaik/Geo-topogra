# GeoTopo

Versión actual: **1.20.8**

## Promedio GPS/GNSS mejorado

- Fase 1: espera una señal apta con mínimo 6 satélites usados, lectura GPS reciente y ±10 m o mejor.
- Fase 2: ejecuta completos los 10, 20, 30 o 60 segundos seleccionados.
- Acepta lecturas GPS de hasta ±15 m durante el promedio y descarta saltos, lecturas antiguas o señal débil.
- Usa promedio ponderado por precisión.
- Muestra por separado:
  - mejor precisión observada;
  - estabilidad real del promedio;
  - precisión final estimada;
  - lecturas válidas y descartadas;
  - satélites máximos usados.
- El resultado final queda congelado para que una lectura posterior peor no cambie el punto antes de guardarlo.

## Puntos y mapa

- Los puntos GPS y el mapa usan el mismo almacenamiento.
- Se pueden mostrar juntos todos los puntos de un proyecto.
- El mapa ajusta el zoom y mantiene resaltado el punto seleccionado.

## Otras funciones

- Capas de calles, satélite, satélite con nombres y topográfico.
- Búsqueda de lugares y coordenadas.
- Medición de distancia y área con puntos movibles y apariencia configurable.
