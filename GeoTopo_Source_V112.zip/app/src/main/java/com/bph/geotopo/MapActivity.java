package com.bph.geotopo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.maplibre.android.MapLibre;
import org.maplibre.android.annotations.IconFactory;
import org.maplibre.android.annotations.Marker;
import org.maplibre.android.annotations.MarkerOptions;
import org.maplibre.android.annotations.Polygon;
import org.maplibre.android.annotations.PolygonOptions;
import org.maplibre.android.annotations.Polyline;
import org.maplibre.android.annotations.PolylineOptions;
import org.maplibre.android.camera.CameraPosition;
import org.maplibre.android.camera.CameraUpdateFactory;
import org.maplibre.android.geometry.LatLng;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapView;
import org.maplibre.android.maps.Style;
import org.maplibre.android.style.layers.BackgroundLayer;
import org.maplibre.android.style.layers.FillExtrusionLayer;
import org.maplibre.android.style.layers.FillLayer;
import org.maplibre.android.style.layers.Layer;
import org.maplibre.android.style.layers.RasterLayer;
import org.maplibre.android.style.sources.RasterSource;
import org.maplibre.android.style.sources.TileSet;

import static org.maplibre.android.style.layers.PropertyFactory.backgroundOpacity;
import static org.maplibre.android.style.layers.PropertyFactory.fillOpacity;
import static org.maplibre.android.style.layers.PropertyFactory.rasterFadeDuration;
import static org.maplibre.android.style.layers.PropertyFactory.visibility;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Visor principal nativo. Usa MapLibre para que el zoom y el desplazamiento
 * se procesen con la GPU en lugar de redibujar un mapa dentro de WebView.
 */
public class MapActivity extends Activity implements LocationListener {
    private static final int REQ_LOCATION = 9002;
    private static final String PREFS = "geo_topo_prefs";
    private static final String GPS_PREFS = "geo_topo_gps_points";
    private static final String LEGACY_MAP_PREFS = "geotopo_gps";
    private static final String KEY_POINTS = "points_json";
    private static final String KEY_MAP_MODE = "map_mode";
    private static final String KEY_SEARCH_HISTORY = "search_history";
    private static final int MAX_SEARCH_HISTORY = 8;
    private static final String OFM_STANDARD = "https://tiles.openfreemap.org/styles/bright";
    private static final String OPEN_TOPO_TILE = "https://a.tile.opentopomap.org/{z}/{x}/{y}.png";
    private static final String MAPTERHORN_TERRAIN = "https://tiles.mapterhorn.com/{z}/{x}/{y}.webp";
    private static final double LOCATION_CONTEXT_ZOOM = 15.0;
    private static final double SATELLITE_DISPLAY_MAX_ZOOM = 22.0;
    private static final String KEY_OFFLINE_PATH = "offline_mbtiles_path";
    private static final String KEY_MEASURE_COLOR = "measure_color";
    private static final String KEY_MEASURE_POINT_SIZE = "measure_point_size";
    private static final String KEY_MEASURE_LABEL_SIZE = "measure_label_size";
    private static final String KEY_MEASURE_LINE_WIDTH = "measure_line_width";
    private static final String KEY_MEASURE_UNITS = "measure_units";
    private static final int[] MEASURE_COLORS = {
            Color.rgb(25, 132, 255),
            Color.rgb(0, 150, 136),
            Color.rgb(229, 57, 53),
            Color.rgb(255, 145, 0)
    };
    private static final String[] MEASURE_POINT_SIZE_NAMES = {"Pequeños", "Medianos", "Grandes", "Muy grandes"};
    private static final String[] MEASURE_LABEL_SIZE_NAMES = {"Pequeños", "Normales", "Grandes", "Muy grandes"};
    private static final String[] MEASURE_LINE_WIDTH_NAMES = {"Fina", "Normal", "Gruesa", "Muy gruesa"};
    private static final String[] MEASURE_UNIT_NAMES = {"Automático", "Metros / m²", "Kilómetros / ha", "Pies / acres"};

    private MapView mapView;
    private MapLibreMap map;
    private LocationManager locationManager;
    private Location currentLocation;
    private Marker locationMarker;
    private Polygon accuracyPolygon;
    private Marker selectedMarker;
    private final List<Marker> savedPointMarkers = new ArrayList<>();
    private final List<SavedPointInfo> visibleSavedPointInfos = new ArrayList<>();
    private final List<Marker> measurementMarkers = new ArrayList<>();
    private final List<Marker> measurementVertexMarkers = new ArrayList<>();
    private int selectedMeasurementIndex = -1;
    private int draggingMeasurementIndex = -1;
    private float measurementTouchDownX;
    private float measurementTouchDownY;
    private boolean measurementDragStarted;
    private Polyline measurementOutlineLine;
    private Polyline measurementLine;
    private Polygon measurementPolygon;
    private Polyline orientationLine;
    private final List<Marker> orientationMarkers = new ArrayList<>();
    private LatLng orientationPointA;
    private LatLng orientationPointB;
    private double orientationBearing;
    private double orientationDistance;
    private final List<LatLng> measurementPoints = new ArrayList<>();
    private final List<LatLng> measurementRedo = new ArrayList<>();
    private boolean measurementActive;
    private boolean areaMode;
    private String currentMode = "standard";
    private String currentPlaceName = "";
    private boolean focusSavedPointsPending;
    private boolean mapStyleInitialized;
    private int mapStyleRequestId;
    private int mapStyleLoadedId;
    private TextView mapLoadingOverlay;
    private TextView neutralMapOverlay;
    private boolean savedPointsVisible;
    private String savedPointsProjectFilter = "";
    private String selectedSavedPointName = "";
    private String selectedSavedPointProject = "";
    private int measureColorIndex = 0;
    private int measurePointSizeIndex = 1;
    private int measureLabelSizeIndex = 2;
    private int measureLineWidthIndex = 1;
    private int measureUnitIndex = 0;

    private TextView subtitleView;
    private ImageButton compassView;
    private TextView statusView;
    private View floatingTopBar;
    private LinearLayout measurePanel;
    private TextView measureResultView;
    private TextView measureHintView;
    private Button measureDistanceButton;
    private Button measureAreaButton;
    private Button measureProfileButton;
    private Button measureUnitsButton;
    private Button measureUndoButton;
    private Button measureRedoButton;
    private Button measureDeleteButton;
    private Button measureClearButton;
    private Button measureFinishButton;
    private LinearLayout selectedPanel;
    private TextView selectedPlaceView;
    private TextView selectedCoordsView;
    private TextView selectedUtmView;
    private LatLng selectedPoint;
    private LinearLayout searchPanel;
    private boolean searchPanelOpen;
    private EditText placeSearchInput;
    private LinearLayout placeSearchResults;
    private TextView placeSearchStatus;

    private int accentColor = Color.rgb(41, 121, 255);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService lookupExecutor = Executors.newSingleThreadExecutor();
    private static final long NOMINATIM_MIN_INTERVAL_MS = 1100L;
    private final Object nominatimRateLock = new Object();
    private long lastNominatimRequestElapsed;
    private long lastAutoGeocodeElapsed;
    private double lastAutoGeocodeLat = Double.NaN;
    private double lastAutoGeocodeLon = Double.NaN;
    private final LinkedHashMap<String, String> reverseGeocodeCache = new LinkedHashMap<>();
    private final LinkedHashMap<String, List<SearchResult>> placeSearchCache = new LinkedHashMap<>();
    private long locationRequestStartedAt;
    private boolean launchCameraPending;
    private double launchCameraLat;
    private double launchCameraLon;
    private double launchCameraZoom = LOCATION_CONTEXT_ZOOM;
    private double launchCameraBearing;
    private final MbtilesServer offlineServer = new MbtilesServer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadPalette();
        loadMeasurementAppearance();
        MapLibre.getInstance(this);
        MapEngineConfig.configure(this);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        migrateLegacyMapData();
        loadRememberedLocation();
        currentMode = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_MAP_MODE, "standard");
        if ("hybrid".equals(currentMode)) currentMode = "labels"; // migración V21
        if ("topo".equals(currentMode) || "relief".equals(currentMode)) currentMode = "topographic"; // migración V95
        if (currentMode == null || currentMode.trim().isEmpty() || "dark".equals(currentMode)) currentMode = "standard";
        if (isImageryMode(currentMode) && (!EsriSatellite.isConfigured() || EsriSatellite.isLocked(this))) {
            currentMode = "standard";
        }
        readLaunchIntent();
        buildUi(savedInstanceState);
    }

    private void loadPalette() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        int[] accents = {
                Color.rgb(41, 121, 255), Color.rgb(0, 188, 212), Color.rgb(0, 150, 136),
                Color.rgb(0, 184, 148), Color.rgb(118, 210, 34), Color.rgb(255, 214, 10),
                Color.rgb(255, 171, 0), Color.rgb(255, 112, 20), Color.rgb(244, 67, 54),
                Color.rgb(255, 64, 129), Color.rgb(142, 68, 173), Color.rgb(92, 92, 210)
        };
        int index = sp.getInt("accent", 0);
        int normalizedIndex = ((index % accents.length) + accents.length) % accents.length;
        accentColor = accents[normalizedIndex];
    }

    private void loadMeasurementAppearance() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        measureColorIndex = clampIndex(sp.getInt(KEY_MEASURE_COLOR, 0), MEASURE_COLORS.length);
        measurePointSizeIndex = clampIndex(sp.getInt(KEY_MEASURE_POINT_SIZE, 1), MEASURE_POINT_SIZE_NAMES.length);
        measureLabelSizeIndex = clampIndex(sp.getInt(KEY_MEASURE_LABEL_SIZE, 2), MEASURE_LABEL_SIZE_NAMES.length);
        measureLineWidthIndex = clampIndex(sp.getInt(KEY_MEASURE_LINE_WIDTH, 1), MEASURE_LINE_WIDTH_NAMES.length);
        measureUnitIndex = clampIndex(sp.getInt(KEY_MEASURE_UNITS, 0), MEASURE_UNIT_NAMES.length);
    }

    private void saveMeasurementAppearance() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt(KEY_MEASURE_COLOR, measureColorIndex)
                .putInt(KEY_MEASURE_POINT_SIZE, measurePointSizeIndex)
                .putInt(KEY_MEASURE_LABEL_SIZE, measureLabelSizeIndex)
                .putInt(KEY_MEASURE_LINE_WIDTH, measureLineWidthIndex)
                .putInt(KEY_MEASURE_UNITS, measureUnitIndex)
                .apply();
    }

    private int clampIndex(int value, int size) {
        if (size <= 0) return 0;
        if (value < 0) return 0;
        if (value >= size) return size - 1;
        return value;
    }

    private int getMeasureColor() {
        return MEASURE_COLORS[clampIndex(measureColorIndex, MEASURE_COLORS.length)];
    }

    private float getMeasurePointScale() {
        switch (measurePointSizeIndex) {
            case 0: return 0.92f;
            case 2: return 1.38f;
            case 3: return 1.68f;
            default: return 1.14f;
        }
    }

    private float getMeasureLabelScale() {
        switch (measureLabelSizeIndex) {
            case 0: return 1.00f;
            case 2: return 1.55f;
            case 3: return 1.90f;
            default: return 1.28f;
        }
    }


    private float getMeasureLineWidth() {
        switch (measureLineWidthIndex) {
            case 0: return 3.0f;
            case 2: return 5.6f;
            case 3: return 7.0f;
            default: return 4.3f;
        }
    }

    private int darkenColor(int color, float factor) {
        float f = Math.max(0f, Math.min(1f, factor));
        return Color.rgb(
                Math.round(Color.red(color) * f),
                Math.round(Color.green(color) * f),
                Math.round(Color.blue(color) * f)
        );
    }

    private void buildUi(Bundle savedInstanceState) {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(10, 20, 31));

        mapView = new MapView(this);
        mapView.onCreate(savedInstanceState);
        mapView.addOnDidFailLoadingMapListener(this::handleMapLoadFailure);
        root.addView(mapView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        neutralMapOverlay = text("Activa GPS para centrar tu ubicación", 14, true, Color.rgb(211, 225, 238));
        neutralMapOverlay.setGravity(Gravity.CENTER);
        neutralMapOverlay.setPadding(dp(28), 0, dp(28), 0);
        neutralMapOverlay.setBackgroundColor(Color.rgb(7, 20, 32));
        neutralMapOverlay.setClickable(false);
        neutralMapOverlay.setVisibility(View.GONE);
        root.addView(neutralMapOverlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        mapLoadingOverlay = text("Cargando mapa…", 13, true, Color.WHITE);
        mapLoadingOverlay.setGravity(Gravity.CENTER);
        // Azul translúcido: nunca tapamos el mapa con una pantalla negra al cargar.
        mapLoadingOverlay.setBackgroundColor(Color.argb(118, 18, 46, 66));
        mapLoadingOverlay.setClickable(false);
        mapLoadingOverlay.setVisibility(View.VISIBLE);
        root.addView(mapLoadingOverlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        View floatingTop = buildFloatingTopBar();
        floatingTopBar = floatingTop;
        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52), Gravity.TOP);
        topLp.setMargins(dp(10), dp(8), dp(10), 0);
        root.addView(floatingTop, topLp);

        addMapOverlays(root);

        View searchDropdown = buildSearchPanel();
        FrameLayout.LayoutParams panelLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP);
        panelLp.setMargins(dp(10), dp(8) + dp(52) + dp(6), dp(10), 0);
        root.addView(searchDropdown, panelLp);

        setContentView(root);

        mapView.getMapAsync(mapLibreMap -> {
            map = mapLibreMap;
            map.getUiSettings().setCompassEnabled(false);
            map.getUiSettings().setLogoEnabled(false);
            map.getUiSettings().setAttributionEnabled(true);
            map.getUiSettings().setAllGesturesEnabled(true);
            map.addOnCameraMoveListener(this::updateCompass);
            map.addOnCameraIdleListener(() -> {
                updateCompass();
                if (!measurementPoints.isEmpty()) redrawMeasurement();
            });
            map.setMinZoomPreference(2.0);
            map.setMaxZoomPreference(20.0);
            map.addOnMapLongClickListener(point -> {
                if (measurementActive) return true;
                showSelectedPoint(point);
                return true;
            });
            map.addOnMapClickListener(point -> {
                if (!measurementActive) return false;
                measurementPoints.add(point);
                measurementRedo.clear();
                selectedMeasurementIndex = measurementPoints.size() - 1;
                redrawMeasurement();
                setStatus(pointLabel(selectedMeasurementIndex) + " agregado · toca otro lugar o arrastra un punto para corregirlo");
                return true;
            });
            map.setOnMarkerClickListener(marker -> {
                if (handleMeasurementMarkerClick(marker)) return true;
                return handleSavedPointMarkerClick(marker);
            });
            installMeasurementDragHandler();
            updateCompass();
            setMapMode(currentMode);
            if (orientationPointA != null && orientationPointB != null) {
                centerOnOrientation();
            } else if (!focusSavedPointsPending && currentLocation == null) {
                showNeutralMapStart();
            }
        });
    }

    private View buildFloatingTopBar() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView back = text("‹", 30, true, Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription("Volver");
        back.setBackground(pill(Color.argb(238, 31, 36, 43), dp(22), Color.argb(80, 255, 255, 255)));
        back.setElevation(dp(7));
        // Con el buscador abierto, la flecha solo cierra la búsqueda.
        back.setOnClickListener(v -> {
            if (searchPanelOpen) closeSearchPanel();
            else finish();
        });
        row.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));

        // Esta MISMA barra es el buscador: al tocarla se escribe aquí, no se abre otro cuadro.
        EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("⌕   Buscar aquí");
        search.setTextColor(Color.WHITE);
        search.setHintTextColor(Color.rgb(225, 231, 237));
        search.setTextSize(16.5f);
        search.setGravity(Gravity.CENTER_VERTICAL);
        search.setPadding(dp(16), 0, dp(12), 0);
        search.setBackground(pill(Color.argb(246, 47, 51, 57), dp(23), Color.argb(75, 255, 255, 255)));
        search.setElevation(dp(8));
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        search.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH
                    || (event != null && event.getKeyCode() == android.view.KeyEvent.KEYCODE_ENTER)) {
                submitPlaceSearch();
                return true;
            }
            return false;
        });
        // Sin foco hasta que se toca: así el teclado no salta al abrir el mapa.
        search.setFocusable(false);
        search.setFocusableInTouchMode(false);
        search.setOnClickListener(v -> openSearchPanel());
        search.setOnFocusChangeListener((v, hasFocus) -> { if (hasFocus) openSearchPanel(); });
        search.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence t, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence t, int a, int b, int c) { }
            @Override public void afterTextChanged(android.text.Editable e) {
                if (searchPanelOpen && e.length() == 0) renderSearchHistory();
            }
        });
        placeSearchInput = search;
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        searchLp.setMargins(dp(8), 0, dp(8), 0);
        row.addView(search, searchLp);

        TextView more = text("⋮", 25, true, Color.WHITE);
        more.setGravity(Gravity.CENTER);
        more.setContentDescription("Más opciones");
        more.setBackground(pill(Color.argb(238, 31, 36, 43), dp(22), Color.argb(80, 255, 255, 255)));
        more.setElevation(dp(7));
        more.setOnClickListener(v -> showInfo());
        row.addView(more, new LinearLayout.LayoutParams(dp(44), dp(44)));
        return row;
    }


    private void addMapOverlays(FrameLayout frame) {
        LinearLayout rightControls = new LinearLayout(this);
        rightControls.setOrientation(LinearLayout.VERTICAL);
        rightControls.setGravity(Gravity.CENTER_HORIZONTAL);

        ImageButton layerQuick = floatingIconButton(R.drawable.ic_map_layers, "Capas", v -> showLayers());
        rightControls.addView(layerQuick, new LinearLayout.LayoutParams(dp(44), dp(44)));

        compassView = buildCompass();
        LinearLayout.LayoutParams compassButtonLp = new LinearLayout.LayoutParams(dp(44), dp(44));
        compassButtonLp.setMargins(0, dp(7), 0, 0);
        rightControls.addView(compassView, compassButtonLp);

        ImageButton locate = floatingIconButton(R.drawable.ic_map_location, "Mi ubicación", v -> centerOnCurrentLocation(true));
        LinearLayout.LayoutParams locateLp = new LinearLayout.LayoutParams(dp(44), dp(44));
        locateLp.setMargins(0, dp(7), 0, 0);
        rightControls.addView(locate, locateLp);

        FrameLayout.LayoutParams rightLp = new FrameLayout.LayoutParams(dp(46), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.END);
        rightLp.setMargins(0, dp(70), dp(10), 0);
        frame.addView(rightControls, rightLp);

        statusView = text("Preparando mapa…", 10.5f, true, Color.WHITE);
        statusView.setGravity(Gravity.CENTER);
        statusView.setMaxLines(2);
        statusView.setPadding(dp(10), dp(7), dp(10), dp(7));
        statusView.setBackground(pill(Color.argb(238, 18, 30, 43), dp(17), Color.argb(80, 255, 255, 255)));
        statusView.setElevation(dp(7));
        statusView.setOnClickListener(v -> showLocationDataPanel());
        FrameLayout.LayoutParams statusLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        statusLp.gravity = Gravity.BOTTOM;
        statusLp.setMargins(dp(34), 0, dp(34), dp(68));
        frame.addView(statusView, statusLp);

        LinearLayout dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setGravity(Gravity.CENTER);
        dock.setPadding(dp(6), dp(4), dp(6), dp(4));
        dock.setBackground(pill(Color.argb(244, 18, 30, 43), dp(19), Color.argb(75, 255, 255, 255)));
        dock.setElevation(dp(10));
        dock.addView(mapTool(R.drawable.ic_map_points, "Puntos", v -> showSavedPointsPanel()), toolParams());
        dock.addView(mapTool(R.drawable.ic_map_measure, "Medir", v -> activateMeasurementTool()), toolParams());
        FrameLayout.LayoutParams dockLp = new FrameLayout.LayoutParams(dp(300), dp(54), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        dockLp.setMargins(0, 0, 0, dp(8));
        frame.addView(dock, dockLp);

        measurePanel = buildMeasurePanel();
        measurePanel.setVisibility(View.GONE);
        FrameLayout.LayoutParams measureLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        measureLp.gravity = Gravity.BOTTOM;
        measureLp.setMargins(dp(12), 0, dp(12), dp(68));
        frame.addView(measurePanel, measureLp);

        selectedPanel = buildSelectedPanel();
        selectedPanel.setVisibility(View.GONE);
        FrameLayout.LayoutParams selectedLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        selectedLp.gravity = Gravity.BOTTOM;
        selectedLp.setMargins(dp(12), 0, dp(12), dp(68));
        frame.addView(selectedPanel, selectedLp);
    }

    private ImageButton floatingIconButton(int drawable, String description, View.OnClickListener click) {
        ImageButton button = new ImageButton(this);
        button.setImageResource(drawable);
        button.setColorFilter(Color.WHITE);
        button.setScaleType(android.widget.ImageView.ScaleType.CENTER);
        button.setPadding(dp(10), dp(10), dp(10), dp(10));
        button.setContentDescription(description);
        button.setBackground(pill(Color.argb(242, 38, 42, 48), dp(22), Color.argb(95, 255, 255, 255)));
        button.setElevation(dp(7));
        button.setOnClickListener(click);
        return button;
    }

    private ImageButton buildCompass() {
        ImageButton view = new ImageButton(this);
        view.setImageResource(R.drawable.ic_map_compass);
        view.setColorFilter(null);
        view.setScaleType(android.widget.ImageView.ScaleType.CENTER);
        view.setPadding(dp(8), dp(8), dp(8), dp(8));
        view.setContentDescription("Brújula: tocar para orientar el norte arriba");
        view.setBackground(pill(Color.argb(238, 10, 24, 38), dp(23), Color.argb(115, 255, 255, 255)));
        view.setElevation(dp(7));
        view.setOnClickListener(v -> {
            if (map != null) {
                CameraPosition p = new CameraPosition.Builder(map.getCameraPosition()).bearing(0).tilt(0).build();
                map.animateCamera(CameraUpdateFactory.newCameraPosition(p), 350);
            }
        });
        return view;
    }

    private void updateCompass() {
        if (compassView == null || map == null) return;
        CameraPosition camera = map.getCameraPosition();
        double bearing = camera.bearing;
        double normalized = ((bearing + 540.0) % 360.0) - 180.0;
        boolean needed = Math.abs(normalized) > 1.5 || Math.abs(camera.tilt) > 1.0;
        compassView.setVisibility(needed ? View.VISIBLE : View.GONE);
        if (needed) {
            compassView.setRotation((float) -bearing);
            compassView.setAlpha(1f);
        }
    }

    private LinearLayout buildMeasurePanel() {
        LinearLayout panel = floatingPanel();
        panel.setPadding(dp(10), dp(5), dp(10), dp(9));

        // Cabecera arrastrable: se baja el cuadro con el dedo y desaparece deslizándose.
        FrameLayout handleTouch = new FrameLayout(this);
        handleTouch.setContentDescription("Arrastra hacia abajo para ocultar el panel de medición");

        View handle = new View(this);
        GradientDrawable handleBg = new GradientDrawable();
        handleBg.setColor(Color.argb(170, 214, 225, 236));
        handleBg.setCornerRadius(dp(2));
        handle.setBackground(handleBg);
        FrameLayout.LayoutParams barLp = new FrameLayout.LayoutParams(dp(48), dp(4), Gravity.CENTER);
        handleTouch.addView(handle, barLp);
        LinearLayout.LayoutParams handleTouchLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(26));
        panel.addView(handleTouch, handleTouchLp);

        final float[] dragStartY = {0f};
        final long[] dragStartTime = {0L};
        final boolean[] dragMoved = {false};
        handleTouch.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dragStartY[0] = event.getRawY();
                    dragStartTime[0] = SystemClock.uptimeMillis();
                    dragMoved[0] = false;
                    panel.animate().cancel();
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dy = event.getRawY() - dragStartY[0];
                    if (dy > dp(4)) dragMoved[0] = true;
                    // Sólo baja: hacia arriba se frena con resistencia para que se sienta natural.
                    float applied = dy >= 0 ? dy : dy * 0.18f;
                    panel.setTranslationY(applied);
                    float travel = Math.max(1f, panel.getHeight());
                    panel.setAlpha(Math.max(0.35f, 1f - Math.max(0f, applied) / (travel * 1.6f)));
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL: {
                    v.getParent().requestDisallowInterceptTouchEvent(false);
                    float dy = Math.max(0f, event.getRawY() - dragStartY[0]);
                    long elapsed = Math.max(1L, SystemClock.uptimeMillis() - dragStartTime[0]);
                    float velocity = dy / elapsed; // px por ms
                    boolean dismiss = dragMoved[0]
                            && (dy > panel.getHeight() * 0.28f || (velocity > 0.9f && dy > dp(28)));
                    if (dismiss) {
                        dismissMeasurePanelByDrag();
                    } else {
                        panel.animate().translationY(0f).alpha(1f).setDuration(180)
                                .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
                    }
                    return true;
                }
                default:
                    return false;
            }
        });

        final int screenHeight = getResources().getDisplayMetrics().heightPixels;
        final int bodyMaxHeight = Math.min(dp(330), Math.max(dp(190), Math.round(screenHeight * 0.46f)));
        ScrollView bodyScroll = new ScrollView(this) {
            @Override
            protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
                int capped = View.MeasureSpec.makeMeasureSpec(bodyMaxHeight, View.MeasureSpec.AT_MOST);
                super.onMeasure(widthMeasureSpec, capped);
            }
        };
        bodyScroll.setFillViewport(false);
        bodyScroll.setVerticalScrollBarEnabled(false);
        bodyScroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(0, 0, 0, dp(1));

        LinearLayout modes = new LinearLayout(this);
        modes.setOrientation(LinearLayout.HORIZONTAL);
        modes.setGravity(Gravity.CENTER_VERTICAL);
        modes.setPadding(dp(5), dp(5), dp(5), dp(5));
        modes.setBackground(pill(Color.argb(225, 8, 30, 49), dp(18), Color.argb(72, 255, 255, 255)));

        measureDistanceButton = measureModeButton("↔", "Distancia");
        measureDistanceButton.setContentDescription("Medir distancia por tramos");
        measureDistanceButton.setOnClickListener(v -> switchMeasurementMode(false));
        modes.addView(measureDistanceButton, measureTopTileParams());

        measureAreaButton = measureModeButton("⬠", "Área");
        measureAreaButton.setContentDescription("Medir área y perímetro");
        measureAreaButton.setOnClickListener(v -> switchMeasurementMode(true));
        modes.addView(measureAreaButton, measureTopTileParams());

        measureProfileButton = measureModeButton("⌁", "Perfil");
        measureProfileButton.setContentDescription("Generar perfil de elevación");
        measureProfileButton.setOnClickListener(v -> openElevationProfile());
        modes.addView(measureProfileButton, measureTopTileParams());

        measureUnitsButton = measureModeButton("⌗", "Unidades");
        measureUnitsButton.setContentDescription("Cambiar unidades de medición");
        measureUnitsButton.setOnClickListener(v -> showMeasurementUnitsDialog());
        modes.addView(measureUnitsButton, measureTopTileParams());
        body.addView(modes, fullWidthSectionParams(0));

        LinearLayout edit = new LinearLayout(this);
        edit.setOrientation(LinearLayout.HORIZONTAL);
        edit.setGravity(Gravity.CENTER_VERTICAL);
        edit.setPadding(dp(7), dp(3), dp(7), dp(3));
        edit.setBackground(pill(Color.argb(218, 8, 30, 49), dp(16), Color.argb(62, 255, 255, 255)));

        measureUndoButton = measureInlineButton("↶", "Deshacer");
        measureUndoButton.setOnClickListener(v -> undoMeasure());
        edit.addView(measureUndoButton, measureInlineTileParams());

        measureRedoButton = measureInlineButton("↷", "Rehacer");
        measureRedoButton.setOnClickListener(v -> redoMeasure());
        edit.addView(measureRedoButton, measureInlineTileParams());

        measureDeleteButton = measureInlineButton("⌫", "Eliminar");
        measureDeleteButton.setOnClickListener(v -> deleteSelectedMeasurementPoint());
        edit.addView(measureDeleteButton, measureInlineTileParams());
        body.addView(edit, fullWidthSectionParams(6));

        LinearLayout summary = new LinearLayout(this);
        summary.setOrientation(LinearLayout.HORIZONTAL);
        summary.setGravity(Gravity.CENTER_VERTICAL);
        summary.setPadding(dp(12), dp(8), dp(12), dp(8));
        summary.setBackground(pill(Color.argb(228, 8, 30, 49), dp(16), Color.argb(62, 255, 255, 255)));

        TextView summaryIcon = text("◎", 17f, true, Color.rgb(214, 230, 246));
        summaryIcon.setPadding(0, 0, dp(9), 0);
        summary.addView(summaryIcon);

        LinearLayout summaryTexts = new LinearLayout(this);
        summaryTexts.setOrientation(LinearLayout.VERTICAL);
        summaryTexts.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        measureResultView = text("Distancia total 0.0 m • 0 tramos", 14f, true, Color.WHITE);
        measureResultView.setMaxLines(2);
        summaryTexts.addView(measureResultView);

        measureHintView = text("Toca el mapa para colocar P1.", 10.5f, false, Color.rgb(188, 209, 229));
        measureHintView.setMaxLines(2);
        measureHintView.setPadding(0, dp(1), 0, 0);
        summaryTexts.addView(measureHintView);
        summary.addView(summaryTexts);
        body.addView(summary, fullWidthSectionParams(6));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);

        measureFinishButton = measureActionButton("✓", "Finalizar", true);
        measureFinishButton.setOnClickListener(v -> finishMeasurement(true));
        actions.addView(measureFinishButton, measureActionTileParams());

        measureClearButton = measureActionButton("⌫", "Limpiar", false);
        measureClearButton.setOnClickListener(v -> clearMeasurement());
        actions.addView(measureClearButton, measureActionTileParams());
        body.addView(actions, fullWidthSectionParams(6));

        bodyScroll.addView(body, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(bodyScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        updateMeasurePanelUi();
        return panel;
    }

    /** Distancia que debe recorrer el panel para salir completamente de la pantalla. */
    private float measurePanelTravel() {
        if (measurePanel == null) return dp(280);
        int height = measurePanel.getHeight();
        if (height <= 0) height = dp(280);
        return height + dp(80);
    }

    /** Muestra el panel de medición deslizándolo desde abajo. */
    private void showMeasurePanel() {
        if (measurePanel == null) return;
        measurePanel.animate().cancel();
        boolean wasVisible = measurePanel.getVisibility() == View.VISIBLE
                && measurePanel.getTranslationY() == 0f
                && measurePanel.getAlpha() == 1f;
        measurePanel.setVisibility(View.VISIBLE);
        if (wasVisible) return;
        measurePanel.setAlpha(0f);
        float from = measurePanel.getHeight() > 0 ? measurePanelTravel() * 0.45f : dp(120);
        measurePanel.setTranslationY(from);
        measurePanel.animate().alpha(1f).translationY(0f).setDuration(230)
                .setInterpolator(new android.view.animation.DecelerateInterpolator(1.6f)).start();
    }

    /** Oculta el panel de medición deslizándolo hacia abajo. */
    private void hideMeasurePanel() {
        if (measurePanel == null) return;
        if (measurePanel.getVisibility() != View.VISIBLE) {
            measurePanel.setTranslationY(0f);
            measurePanel.setAlpha(1f);
            return;
        }
        measurePanel.animate().cancel();
        measurePanel.animate().alpha(0f).translationY(measurePanelTravel()).setDuration(200)
                .setInterpolator(new android.view.animation.AccelerateInterpolator())
                .withEndAction(() -> {
                    measurePanel.setVisibility(View.GONE);
                    measurePanel.setAlpha(1f);
                    measurePanel.setTranslationY(0f);
                }).start();
    }

    /** Al soltar el dedo tras arrastrar hacia abajo: el panel termina de bajar y se oculta. */
    private void dismissMeasurePanelByDrag() {
        if (measurePanel == null) return;
        measurePanel.animate().cancel();
        measurePanel.animate()
                .translationY(measurePanelTravel())
                .alpha(0f)
                .setDuration(190)
                .setInterpolator(new android.view.animation.AccelerateInterpolator())
                .withEndAction(() -> {
                    measurePanel.setVisibility(View.GONE);
                    measurePanel.setAlpha(1f);
                    measurePanel.setTranslationY(0f);
                    measurementActive = false;
                    draggingMeasurementIndex = -1;
                    measurementDragStarted = false;
                    if (map != null) map.getUiSettings().setAllGesturesEnabled(true);
                    redrawMeasurement();
                    updateMeasurePanelUi();
                    setStatus("Medición oculta · pulsa Medir para continuar.");
                })
                .start();
    }

    private void activateMeasurementTool() {
        if (measurementPoints.isEmpty()) {
            startMeasurement(false, true);
            setStatus("Medición activa · toca el mapa para P1");
        } else {
            measurementActive = true;
            draggingMeasurementIndex = -1;
            measurementDragStarted = false;
            selectedPanel.setVisibility(View.GONE);
            showMeasurePanel();
            redrawMeasurement();
            setStatus("Medición activa · toca para agregar puntos o arrastra P1, P2…");
        }
    }

    private void switchMeasurementMode(boolean area) {
        areaMode = area;
        measurementActive = true;
        redrawMeasurement();
        updateMeasurePanelUi();
        setStatus(area ? "Área activa · coloca al menos 3 puntos; puedes arrastrarlos"
                : "Distancia activa · toca para agregar tramos; puedes arrastrar los puntos");
    }

    private void finishMeasurement(boolean showMessage) {
        measurementActive = false;
        draggingMeasurementIndex = -1;
        measurementDragStarted = false;
        if (map != null) map.getUiSettings().setAllGesturesEnabled(true);
        hideMeasurePanel();
        redrawMeasurement();
        updateMeasurePanelUi();
        if (showMessage) setStatus("Medición finalizada · queda dibujada. Pulsa Medir para editarla.");
    }

    private LinearLayout buildSelectedPanel() {
        LinearLayout panel = floatingPanel();
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Lugar seleccionado", 17, true, Color.WHITE);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = text("×", 28, true, Color.WHITE);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> closeSelectedPoint());
        header.addView(close, new LinearLayout.LayoutParams(dp(44), dp(40)));
        panel.addView(header);

        selectedPlaceView = text("Buscando nombre del lugar…", 13, false, Color.rgb(194, 220, 239));
        selectedPlaceView.setPadding(0, dp(3), 0, dp(5));
        panel.addView(selectedPlaceView);
        selectedCoordsView = text("Latitud / longitud: —", 13, true, Color.WHITE);
        panel.addView(selectedCoordsView);
        selectedUtmView = text("UTM: —", 12, false, Color.rgb(194, 220, 239));
        selectedUtmView.setPadding(0, dp(3), 0, dp(8));
        panel.addView(selectedUtmView);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        Button save = panelButton("Guardar");
        save.setOnClickListener(v -> showSaveSelectedPoint());
        row1.addView(save, weightButton());
        Button copy = panelButton("Copiar");
        copy.setOnClickListener(v -> copySelectedPoint());
        row1.addView(copy, weightButton());
        Button share = panelButton("Compartir");
        share.setOnClickListener(v -> shareSelectedPoint());
        row1.addView(share, weightButton());
        panel.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button measure = panelButton("Medir");
        measure.setOnClickListener(v -> startMeasureFromSelected());
        row2.addView(measure, weightButton());
        Button stakeout = panelButton("Replantear");
        stakeout.setOnClickListener(v -> openStakeoutForSelected());
        row2.addView(stakeout, weightButton());
        Button maps = panelButton("Maps");
        maps.setOnClickListener(v -> openSelectedInMaps());
        row2.addView(maps, weightButton());
        panel.addView(row2);
        return panel;
    }

    private void setMapMode(String mode) {
        if (mode == null || mode.trim().isEmpty()) mode = "standard";
        if ("topo".equals(mode) || "relief".equals(mode)) mode = "topographic";
        if ("dark".equals(mode)) mode = "standard";
        if ("hybrid".equals(mode)) mode = "labels";
        if (!("standard".equals(mode) || "satellite".equals(mode) || "labels".equals(mode)
                || "topographic".equals(mode) || "terrain".equals(mode) || "offline".equals(mode))) {
            mode = "standard";
        }
        if (map == null) {
            currentMode = mode;
            return;
        }

        final CameraPosition preservedCamera = mapStyleInitialized ? map.getCameraPosition() : null;
        if (!"offline".equals(mode)) offlineServer.stop();

        if ("offline".equals(mode)) {
            currentMode = "offline";
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_MAP_MODE, currentMode).apply();
            map.setMaxZoomPreference(20.0);
            if (setOfflineMapStyle(preservedCamera)) return;
            Toast.makeText(this, "No hay MBTiles cargado. Se mostrará el mapa normal.", Toast.LENGTH_SHORT).show();
            useStandardMap(preservedCamera);
            return;
        }
        if (isImageryMode(mode)) {
            requestImageryMode(mode, preservedCamera);
            return;
        }
        if ("topographic".equals(mode)) {
            useTopographicMap(preservedCamera);
            return;
        }
        if ("terrain".equals(mode)) {
            useTerrainMap(preservedCamera);
            return;
        }
        useStandardMap(preservedCamera);
    }

    private void useStandardMap(CameraPosition preservedCamera) {
        currentMode = "standard";
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_MAP_MODE, currentMode).apply();
        if (map == null) return;
        map.setMaxZoomPreference(20.0);
        loadRemoteMapStyle(OFM_STANDARD, "Mapa", normalizeCameraForMode(preservedCamera, false), "standard");
    }

    private void useTopographicMap(CameraPosition preservedCamera) {
        currentMode = "topographic";
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_MAP_MODE, currentMode).apply();
        if (map == null) return;
        map.setMaxZoomPreference(18.0);
        loadTopographicMapStyle(normalizeCameraForMode(preservedCamera, false));
    }

    private void useTerrainMap(CameraPosition preservedCamera) {
        currentMode = "terrain";
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_MAP_MODE, currentMode).apply();
        if (map == null) return;
        map.setMaxZoomPreference(18.0);
        loadTerrainMapStyle(normalizeCameraForMode(preservedCamera, true));
    }

    private void requestImageryMode(String requestedMode, CameraPosition preservedCamera) {
        final CameraPosition imageryCamera = normalizeCameraForMode(preservedCamera, false);
        showMapLoading("Comprobando satélite…");
        EsriSatellite.checkAvailability(this, result -> {
            if (isFinishing() || map == null) return;
            if (!result.available) {
                hideMapLoading();
                Toast.makeText(this, result.message, Toast.LENGTH_LONG).show();
                useStandardMap(imageryCamera);
                return;
            }
            currentMode = requestedMode;
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_MAP_MODE, currentMode).apply();
            map.setMaxZoomPreference(SATELLITE_DISPLAY_MAX_ZOOM);
            if ("labels".equals(currentMode)) loadLabelsMapStyle(imageryCamera);
            else loadSatelliteMapStyle(imageryCamera, false);
        });
    }

    private boolean isImageryMode(String mode) {
        return "satellite".equals(mode) || "labels".equals(mode);
    }

    private void loadRemoteMapStyle(String uri, String label, CameraPosition preservedCamera, String requestedMode) {
        final int requestId = ++mapStyleRequestId;
        mapStyleInitialized = false;
        showMapLoading("Cargando " + label.toLowerCase(Locale.ROOT) + "…");
        map.setStyle(new Style.Builder().fromUri(uri), style -> onStyleReady(label, preservedCamera, requestId));
        handler.postDelayed(() -> {
            if (map == null || requestId != mapStyleRequestId || mapStyleLoadedId == requestId) return;
            hideMapLoading();
            alertStatus("Mapa base sin respuesta · revisa la conexión");
        }, 5500L);
    }

    private void loadTopographicMapStyle(CameraPosition preservedCamera) {
        final int requestId = ++mapStyleRequestId;
        mapStyleInitialized = false;
        showMapLoading("Cargando topográfico…");
        String styleJson = "{\"version\":8,\"sources\":{\"topo\":{\"type\":\"raster\",\"tiles\":[\""
                + OPEN_TOPO_TILE + "\"],\"tileSize\":256,\"minzoom\":0,\"maxzoom\":17,\"attribution\":\"© OpenStreetMap contributors, SRTM | OpenTopoMap (CC-BY-SA)\"}},"
                + "\"layers\":[{\"id\":\"topo\",\"type\":\"raster\",\"source\":\"topo\",\"paint\":{\"raster-fade-duration\":0}}]}";
        map.setStyle(new Style.Builder().fromJson(styleJson), style -> onStyleReady("Topográfico", preservedCamera, requestId));
        handler.postDelayed(() -> {
            if (map == null || requestId != mapStyleRequestId || mapStyleLoadedId == requestId) return;
            hideMapLoading();
            alertStatus("Topográfico sin respuesta · revisa la conexión");
        }, 6500L);
    }

    private void loadTerrainMapStyle(CameraPosition preservedCamera) {
        final int requestId = ++mapStyleRequestId;
        mapStyleInitialized = false;
        showMapLoading("Cargando terreno 3D…");
        String styleJson = "{\"version\":8,"
                + "\"sources\":{"
                + "\"topo\":{\"type\":\"raster\",\"tiles\":[\"" + OPEN_TOPO_TILE + "\"],\"tileSize\":256,\"minzoom\":0,\"maxzoom\":17,\"attribution\":\"© OpenStreetMap contributors, SRTM | OpenTopoMap (CC-BY-SA)\"},"
                + "\"dem\":{\"type\":\"raster-dem\",\"tiles\":[\"" + MAPTERHORN_TERRAIN + "\"],\"tileSize\":512,\"minzoom\":0,\"maxzoom\":12,\"encoding\":\"terrarium\",\"attribution\":\"© Mapterhorn terrain data\"}},"
                + "\"terrain\":{\"source\":\"dem\",\"exaggeration\":1.18},"
                + "\"layers\":["
                + "{\"id\":\"topo\",\"type\":\"raster\",\"source\":\"topo\",\"paint\":{\"raster-opacity\":0.88,\"raster-saturation\":-0.12,\"raster-contrast\":0.10}},"
                + "{\"id\":\"terrain-hillshade\",\"type\":\"hillshade\",\"source\":\"dem\",\"paint\":{\"hillshade-exaggeration\":0.82,\"hillshade-shadow-color\":\"#5d4127\",\"hillshade-highlight-color\":\"#fff3cf\",\"hillshade-accent-color\":\"#9a7a4d\"}}]}";
        map.setStyle(new Style.Builder().fromJson(styleJson), style -> onStyleReady("Terreno", preservedCamera, requestId));
        handler.postDelayed(() -> {
            if (map == null || requestId != mapStyleRequestId || mapStyleLoadedId == requestId) return;
            hideMapLoading();
            alertStatus("Terreno sin respuesta · revisa la conexión");
        }, 7000L);
    }

    private CameraPosition normalizeCameraForMode(CameraPosition camera, boolean terrain) {
        if (camera == null) return null;
        CameraPosition.Builder builder = new CameraPosition.Builder(camera);
        if (terrain) builder.tilt(Math.max(45.0, camera.tilt));
        else if (camera.tilt > 1.0) builder.tilt(0.0);
        return builder.build();
    }

    private void loadLabelsMapStyle(CameraPosition preservedCamera) {
        final int requestId = ++mapStyleRequestId;
        mapStyleInitialized = false;
        map.setMaxZoomPreference(SATELLITE_DISPLAY_MAX_ZOOM);
        showMapLoading("Cargando calles y lugares…");

        // Load the same OpenFreeMap Bright vector data used by the normal map so
        // Calles keeps real POIs (hotels, restaurants, schools, parks, shops, etc.)
        // and road/place labels. Then place ArcGIS imagery underneath those vector
        // layers. This is a true hybrid view instead of the previous labels-only
        // raster overlay.
        map.setStyle(new Style.Builder().fromUri(OFM_STANDARD), style -> {
            if (requestId != mapStyleRequestId) return;
            try {
                addSatelliteUnderlayToStreetStyle(style);
            } catch (Exception ignored) {
                // If the vector overlay cannot be prepared for an unexpected style
                // change, keep Calles usable with ArcGIS' lighter reference overlay.
                map.setStyle(new Style.Builder().fromJson(EsriSatellite.hybridStyleJson()),
                        fallback -> onStyleReady("Calles", clampCameraForCurrentMode(preservedCamera), requestId));
                return;
            }
            onStyleReady("Calles", clampCameraForCurrentMode(preservedCamera), requestId);
        });
    }

    /**
     * Turns OpenFreeMap Bright into a transparent reference overlay and inserts
     * sharp 256 px ArcGIS World Imagery below it. Line and symbol layers stay
     * fully visible so streets, names and POIs remain useful over the satellite.
     */
    private void addSatelliteUnderlayToStreetStyle(Style style) {
        if (style == null) return;

        TileSet imageryTiles = new TileSet("2.2.0", EsriSatellite.satelliteTileUrl());
        imageryTiles.setMinZoom(0f);
        imageryTiles.setMaxZoom((float) SATELLITE_DISPLAY_MAX_ZOOM);
        imageryTiles.setAttribution(EsriSatellite.satelliteAttribution());

        RasterSource imagerySource = new RasterSource("geotopo-hybrid-imagery", imageryTiles, 256);
        style.addSource(imagerySource);

        RasterLayer imageryLayer = new RasterLayer("geotopo-hybrid-imagery-layer", "geotopo-hybrid-imagery")
                .withProperties(rasterFadeDuration(0f));
        imageryLayer.setMinZoom(0f);
        imageryLayer.setMaxZoom((float) SATELLITE_DISPLAY_MAX_ZOOM);
        style.addLayerAt(imageryLayer, 0);

        for (Layer layer : style.getLayers()) {
            if (layer == null || "geotopo-hybrid-imagery-layer".equals(layer.getId())) continue;

            // The base-map canvas and solid land polygons must not cover the
            // satellite. Keep a faint amount of fill color for water, parks and
            // buildings so the reference information is still easy to read.
            if (layer instanceof BackgroundLayer) {
                layer.setProperties(backgroundOpacity(0f));
            } else if (layer instanceof FillLayer) {
                String id = layer.getId() == null ? "" : layer.getId().toLowerCase(Locale.ROOT);
                float opacity = (id.contains("water") || id.contains("park") || id.contains("landuse")
                        || id.contains("landcover") || id.contains("building")) ? 0.14f : 0.0f;
                layer.setProperties(fillOpacity(opacity));
            } else if (layer instanceof FillExtrusionLayer) {
                layer.setProperties(visibility("none"));
            }
        }
    }

    private void loadSatelliteMapStyle(CameraPosition preservedCamera, boolean fallback) {
        final int requestId = ++mapStyleRequestId;
        mapStyleInitialized = false;
        map.setMaxZoomPreference(SATELLITE_DISPLAY_MAX_ZOOM);
        showMapLoading(fallback ? "Abriendo satélite…" : "Cargando satélite…");
        map.setStyle(new Style.Builder().fromJson(EsriSatellite.satelliteStyleJson()),
                style -> onStyleReady("Satélite", clampCameraForCurrentMode(preservedCamera), requestId));
    }

    private CameraPosition clampCameraForCurrentMode(CameraPosition camera) {
        if (camera == null || !isImageryMode(currentMode) || camera.zoom <= SATELLITE_DISPLAY_MAX_ZOOM) return camera;
        return new CameraPosition.Builder(camera)
                .zoom(SATELLITE_DISPLAY_MAX_ZOOM)
                .build();
    }

    private void onStyleReady(String label, CameraPosition preservedCamera, int requestId) {
        if (requestId != mapStyleRequestId) return;
        mapStyleLoadedId = requestId;
        if (subtitleView != null) subtitleView.setText("GeoTopo · " + label.toLowerCase(Locale.ROOT));
        if (map != null) map.getUiSettings().setAllGesturesEnabled(true);
        redrawAllAnnotations();

        if (preservedCamera != null) {
            mapStyleInitialized = true;
            hideNeutralMapOverlay();
            CameraPosition safeCamera = clampCameraForCurrentMode(preservedCamera);
            map.moveCamera(CameraUpdateFactory.newCameraPosition(safeCamera));
            if (currentLocation != null) updateLocationStatus();
            else setStatus(label + " · misma zona y escala");
            handler.postDelayed(this::hideMapLoading, 650L);
            return;
        }

        mapStyleInitialized = true;
        if (launchCameraPending) {
            launchCameraPending = false;
            hideNeutralMapOverlay();
            CameraPosition launch = new CameraPosition.Builder()
                    .target(new LatLng(launchCameraLat, launchCameraLon))
                    .zoom(Math.max(2.0, Math.min(isImageryMode(currentMode) ? SATELLITE_DISPLAY_MAX_ZOOM : 20.0, launchCameraZoom)))
                    .bearing(launchCameraBearing)
                    .tilt("terrain".equals(currentMode) ? 45.0 : 0.0)
                    .build();
            map.moveCamera(CameraUpdateFactory.newCameraPosition(launch));
            if (currentLocation != null) updateLocationStatus();
            else setStatus(label + " · misma zona y escala");
        } else if (focusSavedPointsPending) {
            hideNeutralMapOverlay();
            focusSavedPointsPending = false;
            focusVisibleSavedPoints();
        } else if (currentLocation == null && orientationPointA == null) {
            showNeutralMapStart();
        } else if (currentLocation != null) {
            hideNeutralMapOverlay();
            moveCameraToLocation(currentLocation, LOCATION_CONTEXT_ZOOM);
            updateLocationStatus();
        } else {
            hideNeutralMapOverlay();
            setStatus(label + " · mueve y amplía el mapa con dos dedos");
        }
        handler.postDelayed(this::hideMapLoading, 650L);
    }

    private void showMapLoading(String text) {
        if (mapLoadingOverlay == null) return;
        mapLoadingOverlay.setText(text == null ? "Cargando mapa…" : text);
        mapLoadingOverlay.setVisibility(View.VISIBLE);
    }

    private void hideMapLoading() {
        if (mapLoadingOverlay != null) mapLoadingOverlay.setVisibility(View.GONE);
    }

    private void hideNeutralMapOverlay() {
        if (neutralMapOverlay != null) neutralMapOverlay.setVisibility(View.GONE);
    }

    private void handleMapLoadFailure(String errorMessage) {
        runOnUiThread(() -> {
            hideMapLoading();
            if (isImageryMode(currentMode) && EsriSatellite.looksLikeAccessFailure(errorMessage)) {
                String message = EsriSatellite.accessFailureMessage(errorMessage);
                if (EsriSatellite.shouldLockForError(errorMessage)) EsriSatellite.markLocked(this, message);
                else EsriSatellite.clearLocked(this);
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                CameraPosition camera = map == null ? null : map.getCameraPosition();
                useStandardMap(camera);
                return;
            }
            if ("satellite".equals(currentMode)) alertStatus("Satélite · conexión inestable · puedes seguir moviendo el mapa");
            else if ("labels".equals(currentMode)) alertStatus("Calles · conexión inestable · se conserva el mapa cargado");
            else if ("topographic".equals(currentMode)) alertStatus("Topográfico · conexión inestable · se conserva el mapa cargado");
            else if ("terrain".equals(currentMode)) alertStatus("Terreno · conexión inestable · se conserva el mapa cargado");
            else alertStatus("Mapa · conexión inestable · puedes seguir moviendo el mapa");
        });
    }

    private boolean setOfflineMapStyle(CameraPosition preservedCamera) {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        String path = sp.getString(KEY_OFFLINE_PATH, "");
        if (path == null || path.trim().isEmpty()) return false;
        java.io.File file = new java.io.File(path);
        if (!file.isFile()) return false;
        try {
            offlineServer.start(file);
            String url = "http://127.0.0.1:" + offlineServer.getPort() + "/tiles/{z}/{x}/{y}." + offlineServer.getFormat();
            String attribution = escapeJson(offlineServer.getAttribution());
            String style = "{\"version\":8,\"sources\":{\"offline\":{\"type\":\"raster\",\"tiles\":[\"" + url
                    + "\"],\"tileSize\":256,\"minzoom\":" + offlineServer.getMinZoom() + ",\"maxzoom\":" + offlineServer.getMaxZoom()
                    + ",\"attribution\":\"" + attribution + "\"}},\"layers\":[{\"id\":\"background\",\"type\":\"background\",\"paint\":{\"background-color\":\"#091827\"}},{\"id\":\"offline\",\"type\":\"raster\",\"source\":\"offline\",\"paint\":{\"raster-fade-duration\":0}}]}";
            final int requestId = ++mapStyleRequestId;
            mapStyleInitialized = false;
            showMapLoading("Abriendo mapa offline…");
            map.setStyle(new Style.Builder().fromJson(style), loaded -> onStyleReady("Offline", preservedCamera, requestId));
            return true;
        } catch (Exception e) {
            offlineServer.stop();
            return false;
        }
    }

    private String escapeJson(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", " ");
    }

    private void showNeutralMapStart() {
        if (map == null) return;
        clearLocationGraphic();
        if (neutralMapOverlay != null) {
            neutralMapOverlay.setText("Activa GPS para centrar tu ubicación");
            neutralMapOverlay.setVisibility(View.VISIBLE);
        }
        setLocationStatus("Ubicación aún no disponible · pulsa Ubicación para centrar el GPS");
    }

    private void showLayers() {
        MapLayerPicker.show(this, currentMode, new MapLayerPicker.Listener() {
            @Override public void onLayerSelected(String mode) {
                setMapMode(mode);
            }

            @Override public void onManageOffline() {
                startActivity(new Intent(MapActivity.this, OfflineMapActivity.class));
            }
        });
    }


    private void showMeasurementUnitsDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Unidades de medición")
                .setSingleChoiceItems(MEASURE_UNIT_NAMES, measureUnitIndex, (dialog, which) -> {
                    measureUnitIndex = which;
                    saveMeasurementAppearance();
                    redrawMeasurement();
                    updateMeasurePanelUi();
                    setStatus("Unidades: " + MEASURE_UNIT_NAMES[measureUnitIndex]);
                    dialog.dismiss();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }








    private void startMeasurement(boolean area, boolean clear) {
        areaMode = area;
        measurementActive = true;
        if (clear) {
            measurementPoints.clear();
            measurementRedo.clear();
            selectedMeasurementIndex = -1;
            draggingMeasurementIndex = -1;
            measurementDragStarted = false;
            if (map != null) {
                if (measurementOutlineLine != null) map.removePolyline(measurementOutlineLine);
                if (measurementLine != null) map.removePolyline(measurementLine);
                if (measurementPolygon != null) map.removePolygon(measurementPolygon);
                clearMeasurementMarkers();
            }
            measurementOutlineLine = null;
            measurementLine = null;
            measurementPolygon = null;
        }
        selectedPanel.setVisibility(View.GONE);
        showMeasurePanel();
        redrawMeasurement();
        updateMeasurePanelUi();
        setStatus(areaMode ? "Área activa · toca el mapa para P1" : "Distancia activa · toca el mapa para P1");
    }

    private void undoMeasure() {
        if (!measurementPoints.isEmpty()) {
            measurementRedo.add(measurementPoints.remove(measurementPoints.size() - 1));
            if (selectedMeasurementIndex >= measurementPoints.size()) selectedMeasurementIndex = measurementPoints.size() - 1;
        }
        redrawMeasurement();
        updateMeasurePanelUi();
        setStatus(measurementPoints.isEmpty() ? "Sin puntos · toca el mapa para P1" : "Último punto retirado · puedes rehacerlo");
    }

    private void redoMeasure() {
        if (!measurementRedo.isEmpty()) {
            LatLng point = measurementRedo.remove(measurementRedo.size() - 1);
            measurementPoints.add(point);
            selectedMeasurementIndex = measurementPoints.size() - 1;
            redrawMeasurement();
            updateMeasurePanelUi();
            setStatus(pointLabel(selectedMeasurementIndex) + " restaurado");
        } else {
            setStatus("No hay puntos para rehacer.");
        }
    }

    private void deleteSelectedMeasurementPoint() {
        if (measurementPoints.isEmpty()) {
            setStatus("No hay puntos para borrar.");
            return;
        }
        int index = selectedMeasurementIndex >= 0 && selectedMeasurementIndex < measurementPoints.size()
                ? selectedMeasurementIndex : measurementPoints.size() - 1;
        LatLng removed = measurementPoints.remove(index);
        measurementRedo.clear();
        selectedMeasurementIndex = measurementPoints.isEmpty() ? -1 : Math.min(index, measurementPoints.size() - 1);
        redrawMeasurement();
        updateMeasurePanelUi();
        setStatus("P" + (index + 1) + " eliminado · toca el mapa para agregar otro punto");
    }

    private void clearMeasurement() {
        measurementPoints.clear();
        measurementRedo.clear();
        selectedMeasurementIndex = -1;
        measurementActive = true;
        draggingMeasurementIndex = -1;
        measurementDragStarted = false;
        if (map != null) {
            map.getUiSettings().setAllGesturesEnabled(true);
            if (measurementOutlineLine != null) map.removePolyline(measurementOutlineLine);
            if (measurementLine != null) map.removePolyline(measurementLine);
            if (measurementPolygon != null) map.removePolygon(measurementPolygon);
            clearMeasurementMarkers();
        }
        measurementOutlineLine = null;
        measurementLine = null;
        measurementPolygon = null;
        showMeasurePanel();
        redrawMeasurement();
        updateMeasurePanelUi();
        setStatus(areaMode ? "Área reiniciada · toca el mapa para P1" : "Distancia reiniciada · toca el mapa para P1");
    }

    private void redrawMeasurement() {
        if (map == null) return;
        if (measurementOutlineLine != null) map.removePolyline(measurementOutlineLine);
        if (measurementLine != null) map.removePolyline(measurementLine);
        if (measurementPolygon != null) map.removePolygon(measurementPolygon);
        clearMeasurementMarkers();
        measurementOutlineLine = null;
        measurementLine = null;
        measurementPolygon = null;

        int lineColor = getMeasureColor();
        float lineWidth = getMeasureLineWidth();

        if (measurementPoints.size() >= 2) {
            if (areaMode && measurementPoints.size() >= 3) {
                measurementPolygon = map.addPolygon(new PolygonOptions()
                        .addAll(new ArrayList<>(measurementPoints))
                        // Interior 100% transparente: sólo se ve el contorno y el mapa debajo.
                        .fillColor(Color.TRANSPARENT)
                        .strokeColor(Color.argb(190, Color.red(lineColor), Color.green(lineColor), Color.blue(lineColor))));
            }
            List<LatLng> borderPoints = new ArrayList<>(measurementPoints);
            if (areaMode && measurementPoints.size() >= 3) {
                borderPoints.add(measurementPoints.get(0));
            }
            measurementOutlineLine = map.addPolyline(new PolylineOptions()
                    .addAll(borderPoints)
                    .color(Color.argb(170, 255, 255, 255))
                    .width(lineWidth + 2.2f));
            measurementLine = map.addPolyline(new PolylineOptions()
                    .addAll(borderPoints)
                    .color(lineColor)
                    .width(lineWidth));

            for (int i = 1; i < measurementPoints.size(); i++) {
                LatLng a = measurementPoints.get(i - 1);
                LatLng b = measurementPoints.get(i);
                String label = measurementSegmentLabel(a, b, i, false);
                measurementMarkers.add(map.addMarker(new MarkerOptions()
                        .position(measurementSegmentLabelPosition(a, b, i, areaMode))
                        .icon(IconFactory.getInstance(this).fromBitmap(createMeasurementLabelBitmap(label)))));
            }
        }

        double distance = totalDistance(measurementPoints);
        String summaryTitle;
        String summaryHint;
        if (measurementPoints.isEmpty()) {
            summaryTitle = areaMode ? "\u00c1rea total 0.0 m\u00b2 \u2022 per\u00edmetro 0.0 m" : "Distancia total 0.0 m • 0 tramos";
            summaryHint = areaMode ? "Toca el mapa para colocar P1 del pol\u00edgono." : "Toca el mapa para colocar P1.";
        } else if (measurementPoints.size() == 1) {
            summaryTitle = areaMode ? "\u00c1rea total 0.0 m\u00b2 \u2022 per\u00edmetro 0.0 m" : "Distancia total 0.0 m • 0 tramos";
            summaryHint = "P1 listo \u2022 toca otro lugar para continuar o arrastra P1 para corregirlo.";
        } else if (areaMode && measurementPoints.size() >= 3) {
            LatLng last = measurementPoints.get(measurementPoints.size() - 1);
            LatLng first = measurementPoints.get(0);
            double closingDistance = haversine(last, first);
            String closingLabel = measurementSegmentLabel(last, first, measurementPoints.size(), true);
            measurementMarkers.add(map.addMarker(new MarkerOptions()
                    .position(measurementSegmentLabelPosition(last, first, measurementPoints.size(), true))
                    .icon(IconFactory.getInstance(this).fromBitmap(createMeasurementLabelBitmap(closingLabel)))));
            double perimeter = distance + closingDistance;
            double area = polygonArea(measurementPoints);
            summaryTitle = formatAreaPlain(area) + " \u2022 per\u00edmetro " + formatDistance(perimeter);
            summaryHint = measurementPoints.size() + " lados \u2022 arrastra los v\u00e9rtices para ajustar el pol\u00edgono.";
            if (hasRoomForMeasurementSummary()) {
                measurementMarkers.add(map.addMarker(new MarkerOptions()
                        .position(measurementCenter(measurementPoints, true))
                        .icon(IconFactory.getInstance(this).fromBitmap(
                                createMeasurementSummaryBitmap("Per\u00edmetro \u2022 " + formatDistance(perimeter), formatArea(area))))));
            }
        } else {
            String azimuth = measurementPoints.size() >= 2
                    ? "\u00daltimo azimut " + formatAzimuth(initialBearing(measurementPoints.get(measurementPoints.size() - 2), measurementPoints.get(measurementPoints.size() - 1)))
                    : "";
            summaryTitle = "Distancia total " + formatDistance(distance) + " • " + Math.max(0, measurementPoints.size() - 1) + " tramos";
            summaryHint = azimuth.isEmpty() ? "Sigue tocando el mapa para agregar m\u00e1s tramos." : azimuth + " \u2022 arrastra un punto para corregirlo.";
        }

        if (measureResultView != null) measureResultView.setText(summaryTitle);
        if (measureHintView != null) measureHintView.setText(summaryHint);

        for (int i = 0; i < measurementPoints.size(); i++) {
            String pointName = pointLabel(i);
            measurementVertexMarkers.add(map.addMarker(new MarkerOptions()
                    .position(measurementPoints.get(i))
                    .icon(IconFactory.getInstance(this).fromBitmap(createMeasurementPointBitmap(pointName, i == selectedMeasurementIndex)))));
        }
        updateMeasurePanelUi();
    }

    private String measurementSegmentLabel(LatLng a, LatLng b, int index, boolean closing) {
        double meters = haversine(a, b);
        double bearing = initialBearing(a, b);
        float pixels = measurementSegmentPixelLength(a, b);
        String distanceText = formatDistance(meters);
        if (pixels >= dp(205)) {
            return (closing ? "Cierre" : "T" + index) + " • " + distanceText + " • Az " + formatAzimuth(bearing);
        }
        if (pixels >= dp(118)) {
            return (closing ? "Cierre" : "T" + index) + " • " + distanceText;
        }
        return distanceText;
    }

    private float measurementSegmentPixelLength(LatLng a, LatLng b) {
        if (map == null) return 0f;
        PointF pa = map.getProjection().toScreenLocation(a);
        PointF pb = map.getProjection().toScreenLocation(b);
        float dx = pb.x - pa.x;
        float dy = pb.y - pa.y;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private LatLng measurementSegmentLabelPosition(LatLng a, LatLng b, int index, boolean polygon) {
        if (map == null) return midpoint(a, b);
        PointF pa = map.getProjection().toScreenLocation(a);
        PointF pb = map.getProjection().toScreenLocation(b);
        float mx = (pa.x + pb.x) / 2f;
        float my = (pa.y + pb.y) / 2f;
        float dx = pb.x - pa.x;
        float dy = pb.y - pa.y;
        float length = Math.max(1f, (float) Math.sqrt(dx * dx + dy * dy));
        float nx = -dy / length;
        float ny = dx / length;
        float offset = dp(17);

        if (polygon && measurementPoints.size() >= 3) {
            PointF center = map.getProjection().toScreenLocation(measurementCenter(measurementPoints, true));
            float outwardX = mx - center.x;
            float outwardY = my - center.y;
            if (outwardX * nx + outwardY * ny < 0f) {
                nx = -nx;
                ny = -ny;
            }
            offset = dp(20);
        } else if ((index & 1) == 0) {
            nx = -nx;
            ny = -ny;
        }

        return map.getProjection().fromScreenLocation(new PointF(mx + nx * offset, my + ny * offset));
    }

    private boolean hasRoomForMeasurementSummary() {
        if (map == null || measurementPoints.size() < 3) return false;
        float minX = Float.POSITIVE_INFINITY;
        float minY = Float.POSITIVE_INFINITY;
        float maxX = Float.NEGATIVE_INFINITY;
        float maxY = Float.NEGATIVE_INFINITY;
        for (LatLng point : measurementPoints) {
            PointF p = map.getProjection().toScreenLocation(point);
            minX = Math.min(minX, p.x);
            minY = Math.min(minY, p.y);
            maxX = Math.max(maxX, p.x);
            maxY = Math.max(maxY, p.y);
        }
        return (maxX - minX) >= dp(210) && (maxY - minY) >= dp(125);
    }

    private void clearMeasurementMarkers() {
        if (map != null) {
            for (Marker marker : measurementMarkers) {
                try { map.removeMarker(marker); } catch (Exception ignored) { }
            }
            for (Marker marker : measurementVertexMarkers) {
                try { map.removeMarker(marker); } catch (Exception ignored) { }
            }
        }
        measurementMarkers.clear();
        measurementVertexMarkers.clear();
    }

    private Bitmap createLocationDotBitmap() {
        int size = dp(22);
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        float center = size / 2f;

        paint.setColor(Color.argb(70, 66, 133, 244));
        canvas.drawCircle(center, center, dp(8.0f), paint);

        paint.setColor(Color.WHITE);
        canvas.drawCircle(center, center, dp(5.2f), paint);

        paint.setColor(Color.rgb(66, 133, 244));
        canvas.drawCircle(center, center, dp(3.8f), paint);
        return bitmap;
    }

    private Bitmap createSavedPointBitmap(String text, boolean selected) {
        int size = dp(selected ? 38 : 32);
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        float center = size / 2f;

        paint.setColor(Color.argb(selected ? 90 : 45, 0, 0, 0));
        canvas.drawCircle(center + dp(0.8f), center + dp(1.5f), dp(selected ? 15.5f : 13.0f), paint);
        paint.setColor(Color.WHITE);
        canvas.drawCircle(center, center, dp(selected ? 15.0f : 12.7f), paint);
        paint.setColor(selected ? Color.rgb(255, 149, 0) : Color.rgb(25, 132, 255));
        canvas.drawCircle(center, center, dp(selected ? 12.2f : 10.2f), paint);

        paint.setColor(Color.WHITE);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(dp(text.length() > 3 ? 6.2f : 7.2f));
        Paint.FontMetrics fm = paint.getFontMetrics();
        float y = center - (fm.ascent + fm.descent) / 2f;
        canvas.drawText(text, center, y, paint);
        return bitmap;
    }

    private Bitmap createMeasurementPointBitmap(String text, boolean selected) {
        float scale = getMeasurePointScale();
        int size = dp(Math.round((selected ? 24f : 20f) * scale));
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        float center = size / 2f;
        float outerRadius = dp((selected ? 10.4f : 8.8f) * scale);
        float innerRadius = dp((selected ? 7.8f : 6.6f) * scale);
        int measureColor = getMeasureColor();

        paint.setColor(selected ? darkenColor(measureColor, 0.55f) : Color.WHITE);
        canvas.drawCircle(center, center, outerRadius, paint);
        paint.setColor(measureColor);
        canvas.drawCircle(center, center, innerRadius, paint);

        paint.setColor(Color.WHITE);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(dp((text.length() > 2 ? 5.2f : 6.0f) * scale));
        paint.setTextAlign(Paint.Align.CENTER);
        Paint.FontMetrics fm = paint.getFontMetrics();
        float y = center - (fm.ascent + fm.descent) / 2f;
        canvas.drawText(text, center, y, paint);
        return bitmap;
    }

    private Bitmap createMeasurementLabelBitmap(String text) {
        float scale = getMeasureLabelScale();
        Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setTextSize(dp(7.0f * scale));
        float horizontal = dp(4.5f * scale);
        int width = Math.max(dp(42), Math.round(textPaint.measureText(text) + horizontal * 2));
        int height = Math.max(dp(18), Math.round(dp(18f * scale)));
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        textPaint.setTextAlign(Paint.Align.CENTER);
        Paint.FontMetrics fm = textPaint.getFontMetrics();
        float y = height / 2f - (fm.ascent + fm.descent) / 2f;

        textPaint.setStyle(Paint.Style.STROKE);
        textPaint.setStrokeJoin(Paint.Join.ROUND);
        textPaint.setStrokeWidth(dp(2.7f * scale));
        textPaint.setColor(Color.argb(248, 255, 255, 255));
        canvas.drawText(text, width / 2f, y, textPaint);

        textPaint.setStyle(Paint.Style.FILL);
        textPaint.setColor(Color.rgb(24, 58, 91));
        canvas.drawText(text, width / 2f, y, textPaint);
        return bitmap;
    }

    private Bitmap createMeasurementSummaryBitmap(String line1, String line2) {
        float scale = getMeasureLabelScale();
        Paint titlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        titlePaint.setTypeface(Typeface.DEFAULT_BOLD);
        titlePaint.setTextSize(dp(7.2f * scale));

        Paint bodyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        bodyPaint.setTypeface(Typeface.DEFAULT_BOLD);
        bodyPaint.setTextSize(dp(7.0f * scale));

        int paddingH = dp(8);
        int paddingV = dp(6);
        int gap = dp(2);
        int width = Math.max(dp(92), Math.round(Math.max(titlePaint.measureText(line1), bodyPaint.measureText(line2)) + paddingH * 2));
        int lineHeight = dp(14);
        int height = paddingV * 2 + lineHeight * 2 + gap;
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);

        Paint shadow = new Paint(Paint.ANTI_ALIAS_FLAG);
        shadow.setColor(Color.argb(55, 0, 0, 0));
        canvas.drawRoundRect(dp(1.2f), dp(1.8f), width - dp(0.2f), height - dp(0.2f), dp(10), dp(10), shadow);

        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setColor(Color.argb(248, 255, 255, 255));
        canvas.drawRoundRect(0, 0, width - dp(1.2f), height - dp(1.2f), dp(10), dp(10), bg);

        Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(1.15f));
        stroke.setColor(Color.argb(210, Color.red(getMeasureColor()), Color.green(getMeasureColor()), Color.blue(getMeasureColor())));
        canvas.drawRoundRect(dp(0.6f), dp(0.6f), width - dp(1.8f), height - dp(1.8f), dp(10), dp(10), stroke);

        titlePaint.setColor(Color.rgb(24, 58, 91));
        bodyPaint.setColor(Color.rgb(24, 58, 91));
        titlePaint.setTextAlign(Paint.Align.CENTER);
        bodyPaint.setTextAlign(Paint.Align.CENTER);
        Paint.FontMetrics titleFm = titlePaint.getFontMetrics();
        Paint.FontMetrics bodyFm = bodyPaint.getFontMetrics();
        float y1 = paddingV + lineHeight / 2f - (titleFm.ascent + titleFm.descent) / 2f;
        float y2 = paddingV + lineHeight + gap + lineHeight / 2f - (bodyFm.ascent + bodyFm.descent) / 2f;
        canvas.drawText(line1, (width - dp(1.2f)) / 2f, y1, titlePaint);
        canvas.drawText(line2, (width - dp(1.2f)) / 2f, y2, bodyPaint);
        return bitmap;
    }

    private void installMeasurementDragHandler() {
        if (mapView == null) return;
        mapView.setOnTouchListener((view, event) -> {
            int action = event.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) hideNeutralMapOverlay();
            if (!measurementActive || map == null || measurementPoints.isEmpty()) return false;

            if (action == MotionEvent.ACTION_DOWN) {
                int index = findMeasurementPointNear(event.getX(), event.getY(), dp(32));
                if (index < 0) return false;

                draggingMeasurementIndex = index;
                selectedMeasurementIndex = index;
                measurementTouchDownX = event.getX();
                measurementTouchDownY = event.getY();
                measurementDragStarted = false;
                map.getUiSettings().setAllGesturesEnabled(false);
                redrawMeasurement();
                return true;
            }

            if (draggingMeasurementIndex < 0) return false;

            if (action == MotionEvent.ACTION_MOVE) {
                float dx = event.getX() - measurementTouchDownX;
                float dy = event.getY() - measurementTouchDownY;
                if (!measurementDragStarted && dx * dx + dy * dy >= dp(5) * dp(5)) {
                    measurementDragStarted = true;
                }
                if (measurementDragStarted) {
                    LatLng moved = map.getProjection().fromScreenLocation(new PointF(event.getX(), event.getY()));
                    measurementPoints.set(draggingMeasurementIndex, moved);
                    redrawMeasurement();
                    setStatus("Moviendo " + pointLabel(draggingMeasurementIndex) + "…");
                }
                return true;
            }

            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                int finishedIndex = draggingMeasurementIndex;
                boolean moved = measurementDragStarted;
                draggingMeasurementIndex = -1;
                measurementDragStarted = false;
                map.getUiSettings().setAllGesturesEnabled(true);
                redrawMeasurement();
                setStatus(moved
                        ? pointLabel(finishedIndex) + " movido. La medición se actualizó."
                        : pointLabel(finishedIndex) + " seleccionado. Arrástralo para moverlo.");
                return true;
            }

            return true;
        });
    }

    private int findMeasurementPointNear(float x, float y, float maxDistancePx) {
        if (map == null) return -1;
        int bestIndex = -1;
        float bestDistanceSquared = maxDistancePx * maxDistancePx;
        for (int i = 0; i < measurementPoints.size(); i++) {
            PointF screen = map.getProjection().toScreenLocation(measurementPoints.get(i));
            float dx = screen.x - x;
            float dy = screen.y - y;
            float distanceSquared = dx * dx + dy * dy;
            if (distanceSquared <= bestDistanceSquared) {
                bestDistanceSquared = distanceSquared;
                bestIndex = i;
            }
        }
        return bestIndex;
    }

    private boolean handleMeasurementMarkerClick(Marker marker) {
        int index = indexOfMeasurementVertex(marker);
        if (index < 0) return false;
        selectedMeasurementIndex = index;
        redrawMeasurement();
        setStatus(pointLabel(index) + " seleccionado. Arrástralo para moverlo.");
        return true;
    }

    private int indexOfMeasurementVertex(Marker marker) {
        if (marker == null) return -1;
        for (int i = 0; i < measurementVertexMarkers.size(); i++) {
            if (marker.equals(measurementVertexMarkers.get(i))) return i;
        }
        return -1;
    }

    private String pointLabel(int index) {
        return "P" + (index + 1);
    }

    private LatLng midpoint(LatLng a, LatLng b) {
        return new LatLng((a.getLatitude() + b.getLatitude()) / 2.0,
                (a.getLongitude() + b.getLongitude()) / 2.0);
    }

    private LatLng measurementCenter(List<LatLng> points, boolean polygon) {
        if (points == null || points.isEmpty()) return new LatLng(0, 0);
        if (!polygon || points.size() < 3) {
            double sumLat = 0;
            double sumLon = 0;
            for (LatLng point : points) {
                sumLat += point.getLatitude();
                sumLon += point.getLongitude();
            }
            return new LatLng(sumLat / points.size(), sumLon / points.size());
        }

        double twiceArea = 0;
        double centerX = 0;
        double centerY = 0;
        for (int i = 0; i < points.size(); i++) {
            LatLng a = points.get(i);
            LatLng b = points.get((i + 1) % points.size());
            double cross = a.getLongitude() * b.getLatitude() - b.getLongitude() * a.getLatitude();
            twiceArea += cross;
            centerX += (a.getLongitude() + b.getLongitude()) * cross;
            centerY += (a.getLatitude() + b.getLatitude()) * cross;
        }
        if (Math.abs(twiceArea) < 1e-12) {
            double sumLat = 0;
            double sumLon = 0;
            for (LatLng point : points) {
                sumLat += point.getLatitude();
                sumLon += point.getLongitude();
            }
            return new LatLng(sumLat / points.size(), sumLon / points.size());
        }
        return new LatLng(centerY / (3.0 * twiceArea), centerX / (3.0 * twiceArea));
    }

    private String formatDistance(double meters) {
        switch (measureUnitIndex) {
            case 1:
                return String.format(Locale.US, "%.2f m", meters);
            case 2:
                return String.format(Locale.US, "%.3f km", meters / 1000.0);
            case 3:
                return String.format(Locale.US, "%.1f ft", meters * 3.280839895);
            default:
                return meters >= 1000.0
                        ? String.format(Locale.US, "%.2f km", meters / 1000.0)
                        : String.format(Locale.US, "%.1f m", meters);
        }
    }

    private String formatArea(double areaMeters) {
        return "Área · " + formatAreaPlain(areaMeters);
    }

    private String formatAreaPlain(double areaMeters) {
        switch (measureUnitIndex) {
            case 1:
                return String.format(Locale.US, "%.1f m²", areaMeters);
            case 2:
                return String.format(Locale.US, "%.4f ha", areaMeters / 10000.0);
            case 3:
                return String.format(Locale.US, "%.4f acres", areaMeters / 4046.8564224);
            default:
                return areaMeters >= 10000.0
                        ? String.format(Locale.US, "%.4f ha", areaMeters / 10000.0)
                        : String.format(Locale.US, "%.1f m²", areaMeters);
        }
    }

    private double initialBearing(LatLng a, LatLng b) {
        double lat1 = Math.toRadians(a.getLatitude());
        double lat2 = Math.toRadians(b.getLatitude());
        double dLon = Math.toRadians(b.getLongitude() - a.getLongitude());
        double y = Math.sin(dLon) * Math.cos(lat2);
        double x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
        return (Math.toDegrees(Math.atan2(y, x)) + 360.0) % 360.0;
    }

    private String formatAzimuth(double value) {
        return String.format(Locale.US, "%03.1f°", (value + 360.0) % 360.0);
    }

    private void showSelectedPoint(LatLng point) {
        showSelectedPoint(point, "");
    }

    private void showSelectedPoint(LatLng point, String knownPlace) {
        selectedPoint = point;
        selectedPanel.setVisibility(View.VISIBLE);
        hideMeasurePanel();
        if (selectedMarker != null && map != null) map.removeMarker(selectedMarker);
        if (map != null) selectedMarker = map.addMarker(new MarkerOptions().position(point).title("Lugar seleccionado"));
        selectedCoordsView.setText(String.format(Locale.US, "Lat/Lon: %.8f, %.8f", point.getLatitude(), point.getLongitude()));
        UtmCoordinate utm = toUtm(point.getLatitude(), point.getLongitude());
        selectedUtmView.setText(utm.valid
                ? String.format(Locale.US, "UTM %d %s · E %.3f m · N %.3f m", utm.zone, utm.hemisphere, utm.easting, utm.northing)
                : "UTM no disponible");
        if (knownPlace != null && !knownPlace.trim().isEmpty()) {
            selectedPlaceView.setText("Lugar: " + knownPlace.trim());
        } else {
            selectedPlaceView.setText("Buscando nombre del lugar y dirección…");
            lookupAddress(point, true);
        }
    }

    private void closeSelectedPoint() {
        selectedPanel.setVisibility(View.GONE);
        selectedPoint = null;
        if (selectedMarker != null && map != null) map.removeMarker(selectedMarker);
        selectedMarker = null;
    }

    private void lookupAddress(LatLng point, boolean selected) {
        lookupExecutor.execute(() -> {
            String result = geocodeWithAndroid(point.getLatitude(), point.getLongitude());
            if (result.isEmpty()) result = geocodeWithNominatim(point.getLatitude(), point.getLongitude());
            final String address = result;
            runOnUiThread(() -> {
                if (selected) {
                    if (selectedPoint == null) return;
                    selectedPlaceView.setText(address.isEmpty()
                            ? "Lugar no identificado. Las coordenadas sí son válidas."
                            : "Lugar: " + address);
                } else {
                    currentPlaceName = address;
                    updateLocationStatus();
                }
            });
        });
    }

    private String geocodeWithAndroid(double lat, double lon) {
        try {
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(lat, lon, 1);
            if (addresses == null || addresses.isEmpty()) return "";
            Address a = addresses.get(0);
            String line = a.getMaxAddressLineIndex() >= 0 ? a.getAddressLine(0) : "";
            if (line != null && !line.trim().isEmpty()) return line.trim();
            StringBuilder out = new StringBuilder();
            appendPart(out, a.getThoroughfare());
            appendPart(out, a.getSubLocality());
            appendPart(out, a.getLocality());
            appendPart(out, a.getAdminArea());
            return out.toString();
        } catch (Exception ignored) {
            return "";
        }
    }

    private String geocodeWithNominatim(double lat, double lon) {
        String cacheKey = String.format(Locale.US, "%.4f,%.4f", lat, lon);
        synchronized (reverseGeocodeCache) {
            String cached = reverseGeocodeCache.get(cacheKey);
            if (cached != null) return cached;
        }
        HttpURLConnection connection = null;
        try {
            awaitNominatimSlot();
            String language = Locale.getDefault().toLanguageTag();
            String address = "https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=18&addressdetails=1&accept-language="
                    + URLEncoder.encode(language, "UTF-8") + "&lat="
                    + URLEncoder.encode(Double.toString(lat), "UTF-8") + "&lon="
                    + URLEncoder.encode(Double.toString(lon), "UTF-8");
            connection = (HttpURLConnection) new URL(address).openConnection();
            connection.setConnectTimeout(8000);
            connection.setReadTimeout(10000);
            connection.setRequestProperty("User-Agent", "GeoTopo/1.29 Android (com.bph.geotopo)");
            connection.setRequestProperty("Accept-Language", language);
            if (connection.getResponseCode() < 200 || connection.getResponseCode() >= 300) return "";
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder json = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) json.append(line);
            String result = new JSONObject(json.toString()).optString("display_name", "").trim();
            if (!result.isEmpty()) putReverseCache(cacheKey, result);
            return result;
        } catch (Exception ignored) {
            return "";
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private void awaitNominatimSlot() throws InterruptedException {
        synchronized (nominatimRateLock) {
            long now = SystemClock.elapsedRealtime();
            long wait = NOMINATIM_MIN_INTERVAL_MS - (now - lastNominatimRequestElapsed);
            if (lastNominatimRequestElapsed > 0L && wait > 0L) Thread.sleep(wait);
            lastNominatimRequestElapsed = SystemClock.elapsedRealtime();
        }
    }

    private void putReverseCache(String key, String value) {
        synchronized (reverseGeocodeCache) {
            reverseGeocodeCache.put(key, value);
            while (reverseGeocodeCache.size() > 50) {
                String first = reverseGeocodeCache.keySet().iterator().next();
                reverseGeocodeCache.remove(first);
            }
        }
    }

    private List<SearchResult> cachedSearch(String key) {
        synchronized (placeSearchCache) {
            List<SearchResult> cached = placeSearchCache.get(key);
            return cached == null ? null : new ArrayList<>(cached);
        }
    }

    private void putSearchCache(String key, List<SearchResult> value) {
        synchronized (placeSearchCache) {
            placeSearchCache.put(key, new ArrayList<>(value));
            while (placeSearchCache.size() > 30) {
                String first = placeSearchCache.keySet().iterator().next();
                placeSearchCache.remove(first);
            }
        }
    }

    private void showSaveSelectedPoint() {
        if (selectedPoint == null) return;
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(6), dp(18), 0);
        EditText name = new EditText(this);
        name.setHint("Nombre del punto");
        name.setText(nextMapPointName());
        panel.addView(name);
        EditText project = new EditText(this);
        project.setHint("Proyecto");
        project.setText(getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString("current_project", "Puntos de mapa"));
        panel.addView(project);
        EditText description = new EditText(this);
        description.setHint("Descripción");
        description.setText(selectedPlaceView.getText().toString().replace("Lugar: ", ""));
        panel.addView(description);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Guardar punto")
                .setView(panel)
                .setPositiveButton("Guardar", null)
                .setNegativeButton("Cancelar", null)
                .create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(b -> {
            String pointName = name.getText().toString().trim();
            if (pointName.isEmpty()) {
                name.setError("Escribe un nombre");
                return;
            }
            persistSelectedPoint(project.getText().toString().trim(), pointName, description.getText().toString().trim());
            dialog.dismiss();
        }));
        dialog.show();
    }

    private void persistSelectedPoint(String project, String name, String description) {
        if (selectedPoint == null) return;
        if (project.isEmpty()) project = "Puntos de mapa";
        try {
            SharedPreferences sp = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
            JSONArray array;
            try { array = new JSONArray(sp.getString(KEY_POINTS, "[]")); }
            catch (JSONException ex) { array = new JSONArray(); }
            JSONObject p = new JSONObject();
            p.put("project", project);
            p.put("name", name);
            p.put("description", description);
            p.put("latitude", selectedPoint.getLatitude());
            p.put("longitude", selectedPoint.getLongitude());
            p.put("altitude", JSONObject.NULL);
            p.put("accuracy", JSONObject.NULL);
            p.put("speedKmh", JSONObject.NULL);
            p.put("bearing", JSONObject.NULL);
            p.put("timestamp", System.currentTimeMillis());
            p.put("provider", "map_selection");
            p.put("photoUri", "");
            array.put(p);
            sp.edit().putString(KEY_POINTS, array.toString()).putString("current_project", project).apply();
            if (savedPointsVisible) loadSavedPoints();
            Toast.makeText(this, "Punto guardado · permanece oculto hasta abrir Puntos", Toast.LENGTH_SHORT).show();
        } catch (JSONException ex) {
            Toast.makeText(this, "No se pudo guardar el punto.", Toast.LENGTH_LONG).show();
        }
    }

    private void copySelectedPoint() {
        if (selectedPoint == null) return;
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("Punto GeoTopo", selectedPointText()));
        Toast.makeText(this, "Punto copiado", Toast.LENGTH_SHORT).show();
    }

    private void shareSelectedPoint() {
        if (selectedPoint == null) return;
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, selectedPointText());
        startActivity(Intent.createChooser(intent, "Compartir punto"));
    }

    private String selectedPointText() {
        if (selectedPoint == null) return "";
        StringBuilder out = new StringBuilder();
        String place = selectedPlaceView.getText().toString();
        if (!place.startsWith("Buscando") && !place.startsWith("Lugar no")) out.append(place).append('\n');
        out.append(String.format(Locale.US, "Latitud: %.8f\nLongitud: %.8f", selectedPoint.getLatitude(), selectedPoint.getLongitude()));
        UtmCoordinate utm = toUtm(selectedPoint.getLatitude(), selectedPoint.getLongitude());
        if (utm.valid) out.append(String.format(Locale.US, "\nUTM %d %s\nEste: %.3f m\nNorte: %.3f m", utm.zone, utm.hemisphere, utm.easting, utm.northing));
        return out.toString();
    }

    private void startMeasureFromSelected() {
        if (selectedPoint == null) return;
        measurementPoints.clear();
        measurementRedo.clear();
        measurementPoints.add(selectedPoint);
        selectedMeasurementIndex = 0;
        startMeasurement(false, false);
        closeSelectedPoint();
    }

    private void openStakeoutForSelected() {
        if (selectedPoint == null) return;
        Intent intent = new Intent(this, StakeoutActivity.class);
        intent.putExtra("target_lat", selectedPoint.getLatitude());
        intent.putExtra("target_lon", selectedPoint.getLongitude());
        String place = selectedPlaceView == null ? "" : selectedPlaceView.getText().toString().replace("Lugar: ", "").trim();
        if (!place.startsWith("Buscando") && !place.startsWith("Lugar no")) intent.putExtra("target_name", place);
        startActivity(intent);
    }

    private void openElevationProfile() {
        if (measurementPoints.size() < 2) {
            Toast.makeText(this, "Mide una línea con al menos dos puntos para generar el perfil.", Toast.LENGTH_LONG).show();
            return;
        }
        JSONArray array = new JSONArray();
        try {
            for (LatLng point : measurementPoints) {
                JSONObject obj = new JSONObject();
                obj.put("lat", point.getLatitude());
                obj.put("lon", point.getLongitude());
                array.put(obj);
            }
        } catch (JSONException ex) {
            Toast.makeText(this, "No se pudo preparar el perfil.", Toast.LENGTH_LONG).show();
            return;
        }
        Intent intent = new Intent(this, ElevationProfileActivity.class);
        intent.putExtra(ElevationProfileActivity.EXTRA_POINTS_JSON, array.toString());
        startActivity(intent);
    }

    private void openSelectedInMaps() {
        if (selectedPoint == null) return;
        Uri uri = Uri.parse(String.format(Locale.US, "geo:%.8f,%.8f?q=%.8f,%.8f", selectedPoint.getLatitude(), selectedPoint.getLongitude(), selectedPoint.getLatitude(), selectedPoint.getLongitude()));
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
        catch (Exception ex) { Toast.makeText(this, "No hay una app de mapas disponible.", Toast.LENGTH_LONG).show(); }
    }

    private void loadSavedPoints() {
        if (map == null) return;
        for (Marker marker : savedPointMarkers) {
            try { map.removeMarker(marker); } catch (Exception ignored) { }
        }
        savedPointMarkers.clear();
        visibleSavedPointInfos.clear();
        try {
            JSONArray array = new JSONArray(getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                double lat = item.optDouble("latitude", Double.NaN);
                double lon = item.optDouble("longitude", Double.NaN);
                if (Double.isNaN(lat) || Double.isNaN(lon)) continue;
                String name = item.optString("name", "P" + (i + 1)).trim();
                String project = item.optString("project", "Proyecto general").trim();
                String description = item.optString("description", "").trim();
                if (!savedPointsProjectFilter.isEmpty()
                        && !savedPointsProjectFilter.equalsIgnoreCase(project)) continue;

                boolean selected = !selectedSavedPointName.isEmpty()
                        && selectedSavedPointName.equalsIgnoreCase(name)
                        && (selectedSavedPointProject.isEmpty()
                        || selectedSavedPointProject.equalsIgnoreCase(project));
                SavedPointInfo info = new SavedPointInfo(name, project, description, new LatLng(lat, lon));
                visibleSavedPointInfos.add(info);
                savedPointMarkers.add(map.addMarker(new MarkerOptions()
                        .position(info.point)
                        .title(name + " · " + project)
                        .snippet(description)
                        .icon(IconFactory.getInstance(this).fromBitmap(createSavedPointBitmap(name, selected)))));
            }
            if (visibleSavedPointInfos.isEmpty()) {
                setStatus(savedPointsProjectFilter.isEmpty()
                        ? "No hay puntos guardados."
                        : "No hay puntos guardados en “" + savedPointsProjectFilter + "”.");
            } else {
                String scope = savedPointsProjectFilter.isEmpty()
                        ? "puntos guardados"
                        : "puntos de “" + savedPointsProjectFilter + "”";
                setStatus("Mostrando " + visibleSavedPointInfos.size() + " " + scope + ".");
            }
        } catch (Exception ex) {
            alertStatus("No se pudieron cargar los puntos guardados.");
        }
    }

    private void showSavedPointsPanel() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(dp(16), dp(10), dp(16), dp(16));
        sheet.setBackground(pill(Color.rgb(9, 28, 46), dp(22), Color.rgb(47, 83, 116)));
        sheet.addView(text("Puntos guardados", 19, true, Color.WHITE));
        TextView sub = text("Muestra todos, ocúltalos o centra un punto concreto sin salir del mapa.", 12, false, Color.rgb(184, 208, 229));
        sub.setPadding(0, dp(2), 0, dp(10));
        sheet.addView(sub);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button show = panelButton("Mostrar todos");
        show.setOnClickListener(v -> { dialog.dismiss(); showAllSavedPointsOnMap(); });
        actions.addView(show, weightButton());
        Button hide = panelButton("Ocultar");
        hide.setOnClickListener(v -> { dialog.dismiss(); hideSavedPointsOnMap(); });
        actions.addView(hide, weightButton());
        sheet.addView(actions);

        JSONArray array;
        try { array = new JSONArray(getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]")); }
        catch (Exception e) { array = new JSONArray(); }
        if (array.length() == 0) {
            TextView empty = text("Todavía no hay puntos guardados.", 13, false, Color.rgb(184, 208, 229));
            empty.setPadding(dp(4), dp(14), dp(4), dp(8));
            sheet.addView(empty);
        } else {
            int first = Math.max(0, array.length() - 12);
            for (int i = array.length() - 1; i >= first; i--) {
                JSONObject o = array.optJSONObject(i); if (o == null) continue;
                double lat = o.optDouble("latitude", Double.NaN), lon = o.optDouble("longitude", Double.NaN);
                if (Double.isNaN(lat) || Double.isNaN(lon)) continue;
                String name = o.optString("name", "Punto"), project = o.optString("project", "Proyecto general");
                TextView row = text(name + " · " + project, 13.5f, true, Color.WHITE);
                row.setPadding(dp(12), dp(11), dp(12), dp(11));
                row.setBackground(pill(Color.rgb(13, 39, 63), dp(12), Color.rgb(45, 82, 116)));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.setMargins(0, dp(7), 0, 0);
                sheet.addView(row, lp);
                final LatLng point = new LatLng(lat, lon);
                final String pointName = name, pointProject = project;
                row.setOnClickListener(v -> {
                    dialog.dismiss();
                    savedPointsProjectFilter = pointProject;
                    selectedSavedPointName = pointName;
                    selectedSavedPointProject = pointProject;
                    savedPointsVisible = true;
                    loadSavedPoints();
                    CameraPosition position = new CameraPosition.Builder(map.getCameraPosition()).target(point).zoom(Math.max(16.0, map.getCameraPosition().zoom)).build();
                    map.animateCamera(CameraUpdateFactory.newCameraPosition(position), 450);
                    setStatus(pointName + " · " + pointProject);
                });
            }
        }
        dialog.setContentView(sheet);
        dialog.setCanceledOnTouchOutside(true);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setGravity(Gravity.BOTTOM);
            WindowManager.LayoutParams params = window.getAttributes();
            params.width = WindowManager.LayoutParams.MATCH_PARENT; params.height = WindowManager.LayoutParams.WRAP_CONTENT; params.dimAmount = .35f;
            window.setAttributes(params); window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
        dialog.show();
        if (window != null) window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private void hideSavedPointsOnMap() {
        if (map != null) {
            for (Marker marker : savedPointMarkers) { try { map.removeMarker(marker); } catch (Exception ignored) { } }
        }
        savedPointMarkers.clear();
        visibleSavedPointInfos.clear();
        savedPointsVisible = false;
        savedPointsProjectFilter = ""; selectedSavedPointName = ""; selectedSavedPointProject = "";
        setStatus("Puntos guardados ocultos.");
    }

    private void showAllSavedPointsOnMap() {
        savedPointsVisible = true;
        savedPointsProjectFilter = "";
        selectedSavedPointName = "";
        selectedSavedPointProject = "";
        loadSavedPoints();
        focusVisibleSavedPoints();
    }

    private boolean handleSavedPointMarkerClick(Marker marker) {
        if (marker == null) return false;
        int index = savedPointMarkers.indexOf(marker);
        if (index < 0 || index >= visibleSavedPointInfos.size()) return false;
        SavedPointInfo info = visibleSavedPointInfos.get(index);
        selectedSavedPointName = info.name;
        selectedSavedPointProject = info.project;
        loadSavedPoints();
        CameraPosition position = new CameraPosition.Builder(map.getCameraPosition())
                .target(info.point)
                .zoom(Math.max(17.0, map.getCameraPosition().zoom))
                .build();
        map.animateCamera(CameraUpdateFactory.newCameraPosition(position), 450);
        String detail = info.description.isEmpty() ? "" : " · " + info.description;
        setStatus(info.name + " · " + info.project + detail);
        return true;
    }

    private void focusVisibleSavedPoints() {
        if (map == null || visibleSavedPointInfos.isEmpty()) return;
        double minLat = Double.POSITIVE_INFINITY;
        double maxLat = Double.NEGATIVE_INFINITY;
        double minLon = Double.POSITIVE_INFINITY;
        double maxLon = Double.NEGATIVE_INFINITY;
        for (SavedPointInfo info : visibleSavedPointInfos) {
            minLat = Math.min(minLat, info.point.getLatitude());
            maxLat = Math.max(maxLat, info.point.getLatitude());
            minLon = Math.min(minLon, info.point.getLongitude());
            maxLon = Math.max(maxLon, info.point.getLongitude());
        }
        LatLng center = new LatLng((minLat + maxLat) / 2.0, (minLon + maxLon) / 2.0);
        double diagonal = haversine(new LatLng(minLat, minLon), new LatLng(maxLat, maxLon));
        double zoom;
        if (visibleSavedPointInfos.size() == 1 || diagonal < 25.0) zoom = 18.5;
        else if (diagonal < 80.0) zoom = 18.0;
        else if (diagonal < 250.0) zoom = 17.0;
        else if (diagonal < 700.0) zoom = 16.0;
        else if (diagonal < 2000.0) zoom = 14.5;
        else if (diagonal < 6000.0) zoom = 13.0;
        else if (diagonal < 20000.0) zoom = 11.0;
        else zoom = 9.0;
        CameraPosition position = new CameraPosition.Builder()
                .target(center)
                .zoom(zoom)
                .bearing(0)
                .tilt(0)
                .build();
        map.animateCamera(CameraUpdateFactory.newCameraPosition(position), 650);
        String scope = savedPointsProjectFilter.isEmpty()
                ? "todos los puntos guardados"
                : "el proyecto “" + savedPointsProjectFilter + "”";
        setStatus("Mostrando " + visibleSavedPointInfos.size() + " puntos de " + scope + ".");
    }

    private void centerOnCurrentLocation(boolean forceNew) {
        if (currentLocation != null) {
            moveCameraToLocation(currentLocation, LOCATION_CONTEXT_ZOOM);
            updateLocationStatus();
        } else if (!forceNew) {
            showNeutralMapStart();
        }
        if (forceNew) requestLocationUpdates();
    }

    private void requestLocationUpdates() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
            return;
        }
        try {
            locationRequestStartedAt = System.currentTimeMillis();
            setLocationStatus("Buscando tu ubicación actual…");
            Location gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location network = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            Location last = chooseBetter(gps, network);
            if (last != null && System.currentTimeMillis() - last.getTime() < 30 * 1000L) {
                onLocationChanged(last);
            }
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0.5f, this);
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1500L, 1f, this);
            }
            handler.removeCallbacks(locationTimeout);
            handler.postDelayed(locationTimeout, 15000L);
        } catch (Exception ex) {
            setLocationStatus("No se pudo iniciar la ubicación. Revisa el permiso y el GPS.");
        }
    }

    private final Runnable locationTimeout = () -> {
        locationRequestStartedAt = 0L;
        if (currentLocation == null) {
            setLocationStatus("No llegó una ubicación nueva. Revisa el GPS y pulsa Ubicación para reintentar.");
        } else {
            updateLocationStatus();
        }
    };

    @Override
    public void onLocationChanged(Location location) {
        if (location == null || !location.hasAccuracy()) return;
        if (currentLocation == null || isBetterLocation(location, currentLocation)) {
            currentLocation = new Location(location);
            saveRememberedLocation(currentLocation);
            redrawLocation();
            if (map != null) {
                boolean shouldCenter = locationRequestStartedAt > 0 || map.getCameraPosition().zoom < 5.0;
                if (shouldCenter) {
                    moveCameraToLocation(currentLocation, LOCATION_CONTEXT_ZOOM);
                    locationRequestStartedAt = 0L;
                }
            }
            if (shouldAutoLookupAddress(location)) {
                currentPlaceName = "";
                lookupAddress(new LatLng(location.getLatitude(), location.getLongitude()), false);
            }
            updateLocationStatus();
        }
    }

    private boolean shouldAutoLookupAddress(Location location) {
        if (location == null) return false;
        long now = SystemClock.elapsedRealtime();
        if (Double.isNaN(lastAutoGeocodeLat) || Double.isNaN(lastAutoGeocodeLon)) {
            lastAutoGeocodeLat = location.getLatitude();
            lastAutoGeocodeLon = location.getLongitude();
            lastAutoGeocodeElapsed = now;
            return true;
        }

        float[] distance = new float[1];
        Location.distanceBetween(lastAutoGeocodeLat, lastAutoGeocodeLon,
                location.getLatitude(), location.getLongitude(), distance);
        // Do not reverse-geocode every GPS update. Refresh only after meaningful
        // movement and a cooldown; manual map selections can still query immediately.
        if (now - lastAutoGeocodeElapsed < 30_000L || distance[0] < 100f) return false;

        lastAutoGeocodeLat = location.getLatitude();
        lastAutoGeocodeLon = location.getLongitude();
        lastAutoGeocodeElapsed = now;
        return true;
    }

    private void redrawLocation() {
        if (map == null || currentLocation == null) return;
        if (locationMarker != null) map.removeMarker(locationMarker);
        if (accuracyPolygon != null) {
            map.removePolygon(accuracyPolygon);
            accuracyPolygon = null;
        }
        LatLng p = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());
        // Con precisiones pobres (por ejemplo ±100 m) un círculo real tapa media pantalla.
        // Solo se dibuja cuando aporta información útil; la cifra exacta sigue en la barra inferior.
        if (currentLocation.hasAccuracy() && currentLocation.getAccuracy() > 0f && currentLocation.getAccuracy() <= 35f) {
            accuracyPolygon = map.addPolygon(new PolygonOptions()
                    .addAll(buildAccuracyCircle(p, currentLocation.getAccuracy()))
                    .fillColor(Color.argb(16, 66, 133, 244))
                    .strokeColor(Color.argb(72, 66, 133, 244)));
        }
        locationMarker = map.addMarker(new MarkerOptions()
                .position(p)
                .title("Tu ubicación")
                .icon(IconFactory.getInstance(this).fromBitmap(createLocationDotBitmap())));
    }

    private List<LatLng> buildAccuracyCircle(LatLng center, float radiusMeters) {
        List<LatLng> ring = new ArrayList<>();
        double latRad = Math.toRadians(center.getLatitude());
        double metersPerDegLat = 111320.0;
        double metersPerDegLon = Math.max(1.0, 111320.0 * Math.cos(latRad));
        for (int i = 0; i <= 48; i++) {
            double a = Math.toRadians(i * 360.0 / 48.0);
            double dLat = Math.sin(a) * radiusMeters / metersPerDegLat;
            double dLon = Math.cos(a) * radiusMeters / metersPerDegLon;
            ring.add(new LatLng(center.getLatitude() + dLat, center.getLongitude() + dLon));
        }
        return ring;
    }

    private void clearLocationGraphic() {
        if (map == null) {
            locationMarker = null;
            accuracyPolygon = null;
            return;
        }
        if (locationMarker != null) {
            map.removeMarker(locationMarker);
            locationMarker = null;
        }
        if (accuracyPolygon != null) {
            map.removePolygon(accuracyPolygon);
            accuracyPolygon = null;
        }
    }

    private void redrawAllAnnotations() {
        locationMarker = null;
        accuracyPolygon = null;
        measurementOutlineLine = null;
        measurementLine = null;
        measurementPolygon = null;
        measurementMarkers.clear();
        measurementVertexMarkers.clear();
        orientationLine = null;
        orientationMarkers.clear();
        selectedMarker = null;
        savedPointMarkers.clear();
        visibleSavedPointInfos.clear();
        redrawLocation();
        redrawMeasurement();
        redrawOrientation();
        if (savedPointsVisible) loadSavedPoints();
        if (selectedPoint != null) showSelectedPoint(selectedPoint);
    }

    private void moveCameraToLocation(Location location, double zoom) {
        if (map == null || location == null) return;
        hideNeutralMapOverlay();
        double safeZoom = isImageryMode(currentMode) ? Math.min(zoom, SATELLITE_DISPLAY_MAX_ZOOM) : zoom;
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(location.getLatitude(), location.getLongitude()), safeZoom), 650);
    }

    private void updateLocationStatus() {
        if (currentLocation == null) return;
        String provider = LocationManager.GPS_PROVIDER.equals(currentLocation.getProvider()) ? "GPS/GNSS" : "ubicación asistida";
        String place = currentPlaceName == null || currentPlaceName.isEmpty() ? "Tu ubicación" : shortPlace(currentPlaceName);
        setLocationStatus(place + " · ± " + String.format(Locale.US, "%.1f", currentLocation.getAccuracy()) + " m · " + provider);
    }

    private String shortPlace(String value) {
        String[] parts = value.split(",");
        if (parts.length <= 3) return value;
        return parts[0].trim() + ", " + parts[1].trim() + ", " + parts[2].trim();
    }

    private void readLaunchIntent() {
        Intent intent = getIntent();
        if (intent == null) return;

        String requestedMode = intent.getStringExtra("map_mode");
        if ("dark".equals(requestedMode)) requestedMode = "standard";
        if ("hybrid".equals(requestedMode)) requestedMode = "labels"; // migración V21
        if ("topo".equals(requestedMode) || "relief".equals(requestedMode)) requestedMode = "topographic";
        if (requestedMode != null && ("standard".equals(requestedMode)
                || "satellite".equals(requestedMode) || "labels".equals(requestedMode)
                || "topographic".equals(requestedMode) || "terrain".equals(requestedMode) || "offline".equals(requestedMode))) {
            currentMode = requestedMode;
        }

        if (intent.hasExtra("camera_lat") && intent.hasExtra("camera_lon")) {
            launchCameraLat = intent.getDoubleExtra("camera_lat", 0.0);
            launchCameraLon = intent.getDoubleExtra("camera_lon", 0.0);
            launchCameraZoom = intent.getDoubleExtra("camera_zoom", LOCATION_CONTEXT_ZOOM);
            launchCameraBearing = intent.getDoubleExtra("camera_bearing", 0.0);
            launchCameraPending = true;
        }

        focusSavedPointsPending = intent.getBooleanExtra("show_saved_points", false);
        savedPointsVisible = focusSavedPointsPending;
        boolean showAllSaved = intent.getBooleanExtra("show_all_saved_points", false);
        if (focusSavedPointsPending) {
            savedPointsProjectFilter = showAllSaved ? ""
                    : intent.getStringExtra("saved_points_project");
            if (savedPointsProjectFilter == null) savedPointsProjectFilter = "";
            selectedSavedPointName = intent.getStringExtra("selected_saved_point_name");
            if (selectedSavedPointName == null) selectedSavedPointName = "";
            selectedSavedPointProject = savedPointsProjectFilter;
        }

        if (!focusSavedPointsPending && intent.hasExtra("latitude") && intent.hasExtra("longitude")) {
            Location supplied = new Location("enviada");
            supplied.setLatitude(intent.getDoubleExtra("latitude", -9.19));
            supplied.setLongitude(intent.getDoubleExtra("longitude", -75.015));
            supplied.setAccuracy(intent.getFloatExtra("location_accuracy", 0f));
            supplied.setBearing(intent.getFloatExtra("location_bearing", 0f));
            supplied.setTime(System.currentTimeMillis());
            currentLocation = supplied;
        }
        if (intent.hasExtra("ab_a_lat") && intent.hasExtra("ab_b_lat")) {
            orientationPointA = new LatLng(intent.getDoubleExtra("ab_a_lat", 0), intent.getDoubleExtra("ab_a_lon", 0));
            orientationPointB = new LatLng(intent.getDoubleExtra("ab_b_lat", 0), intent.getDoubleExtra("ab_b_lon", 0));
            orientationBearing = intent.getDoubleExtra("ab_bearing", 0);
            orientationDistance = intent.getDoubleExtra("ab_distance", haversine(orientationPointA, orientationPointB));
        }
    }

    private void redrawOrientation() {
        if (map == null) return;
        if (orientationLine != null) {
            try { map.removePolyline(orientationLine); } catch (Exception ignored) { }
        }
        for (Marker marker : orientationMarkers) {
            try { map.removeMarker(marker); } catch (Exception ignored) { }
        }
        orientationMarkers.clear();
        orientationLine = null;
        if (orientationPointA == null || orientationPointB == null) return;
        List<LatLng> points = new ArrayList<>();
        points.add(orientationPointA);
        points.add(orientationPointB);
        orientationLine = map.addPolyline(new PolylineOptions()
                .addAll(points)
                .color(Color.rgb(255, 149, 0))
                .width(6f));
        orientationMarkers.add(map.addMarker(new MarkerOptions()
                .position(orientationPointA)
                .icon(IconFactory.getInstance(this).fromBitmap(createMeasurementPointBitmap("A", false)))));
        orientationMarkers.add(map.addMarker(new MarkerOptions()
                .position(orientationPointB)
                .icon(IconFactory.getInstance(this).fromBitmap(createMeasurementPointBitmap("B", false)))));
        setStatus(String.format(Locale.US, "Línea A–B: %.2f m · azimut %.2f°", orientationDistance, orientationBearing));
    }

    private void centerOnOrientation() {
        if (map == null || orientationPointA == null || orientationPointB == null) return;
        LatLng centerPoint = midpoint(orientationPointA, orientationPointB);
        double distance = Math.max(1.0, haversine(orientationPointA, orientationPointB));
        double targetZoom;
        if (distance < 50) targetZoom = 19.0;
        else if (distance < 200) targetZoom = 18.0;
        else if (distance < 600) targetZoom = 17.0;
        else if (distance < 2000) targetZoom = 15.5;
        else if (distance < 10000) targetZoom = 13.0;
        else targetZoom = 10.0;
        CameraPosition position = new CameraPosition.Builder()
                .target(centerPoint)
                .zoom(targetZoom)
                .bearing(0)
                .tilt(0)
                .build();
        map.animateCamera(CameraUpdateFactory.newCameraPosition(position), 600);
    }

    private void migrateLegacyMapData() {
        SharedPreferences primary = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
        SharedPreferences legacy = getSharedPreferences(LEGACY_MAP_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = primary.edit();
        boolean changed = false;
        if (!primary.contains(KEY_POINTS) && legacy.contains(KEY_POINTS)) {
            editor.putString(KEY_POINTS, legacy.getString(KEY_POINTS, "[]"));
            changed = true;
        }
        if (!primary.contains("last_latitude") && legacy.contains("last_latitude")) {
            editor.putString("last_latitude", legacy.getString("last_latitude", ""));
            editor.putString("last_longitude", legacy.getString("last_longitude", ""));
            editor.putFloat("last_accuracy", legacy.getFloat("last_accuracy", 0f));
            editor.putLong("last_location_time", legacy.getLong("last_location_time", System.currentTimeMillis()));
            changed = true;
        }
        if (changed) editor.apply();
    }

    private void loadRememberedLocation() {
        SharedPreferences sp = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
        try {
            String lat = sp.getString("last_latitude", "");
            String lon = sp.getString("last_longitude", "");
            if (lat.isEmpty() || lon.isEmpty()) return;
            Location remembered = new Location("guardada");
            remembered.setLatitude(Double.parseDouble(lat));
            remembered.setLongitude(Double.parseDouble(lon));
            remembered.setAccuracy(sp.getFloat("last_accuracy", 0f));
            remembered.setTime(sp.getLong("last_location_time", System.currentTimeMillis()));
            currentLocation = remembered;
        } catch (Exception ignored) { }
    }

    private void saveRememberedLocation(Location location) {
        getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit()
                .putString("last_latitude", Double.toString(location.getLatitude()))
                .putString("last_longitude", Double.toString(location.getLongitude()))
                .putFloat("last_accuracy", location.getAccuracy())
                .putLong("last_location_time", location.getTime() > 0 ? location.getTime() : System.currentTimeMillis())
                .apply();
    }

    private Location chooseBetter(Location a, Location b) {
        if (a == null) return b;
        if (b == null) return a;
        if (a.hasAccuracy() && b.hasAccuracy() && a.getAccuracy() != b.getAccuracy()) return a.getAccuracy() < b.getAccuracy() ? a : b;
        return a.getTime() >= b.getTime() ? a : b;
    }

    private boolean isBetterLocation(Location candidate, Location current) {
        if (current == null) return true;
        long dt = candidate.getTime() - current.getTime();
        if (dt > 30000L) return true;
        if (dt < -120000L) return false;
        float ca = candidate.hasAccuracy() ? candidate.getAccuracy() : 9999f;
        float oa = current.hasAccuracy() ? current.getAccuracy() : 9999f;
        return ca <= oa + 5f || dt > 5000L;
    }

    private void showLocationDataPanel() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(dp(16), dp(10), dp(16), dp(16));
        sheet.setBackground(pill(Color.rgb(17, 29, 42), dp(22), Color.rgb(64, 78, 94)));
        sheet.addView(text("Datos del mapa", 19, true, Color.WHITE));
        if (currentLocation == null) {
            TextView empty = text("Todavía no hay una lectura GPS actual. Pulsa el botón de ubicación.", 13, false, Color.rgb(195, 207, 219));
            empty.setPadding(0, dp(8), 0, 0);
            sheet.addView(empty);
        } else {
            UtmCoordinate utm = toUtm(currentLocation.getLatitude(), currentLocation.getLongitude());
            String provider = LocationManager.GPS_PROVIDER.equals(currentLocation.getProvider()) ? "GPS/GNSS" : "Ubicación asistida";
            sheet.addView(dataLine("Precisión", "± " + String.format(Locale.US, "%.1f m", currentLocation.getAccuracy())));
            sheet.addView(dataLine("Latitud", String.format(Locale.US, "%.8f°", currentLocation.getLatitude())));
            sheet.addView(dataLine("Longitud", String.format(Locale.US, "%.8f°", currentLocation.getLongitude())));
            if (utm.valid) {
                sheet.addView(dataLine("UTM", String.format(Locale.US, "%d %s · E %.3f · N %.3f", utm.zone, utm.hemisphere, utm.easting, utm.northing)));
            }
            sheet.addView(dataLine("Fuente", provider));
            if (currentLocation.hasAltitude()) sheet.addView(dataLine("Altitud", String.format(Locale.US, "%.1f m", currentLocation.getAltitude())));
        }
        dialog.setContentView(sheet);
        dialog.setCanceledOnTouchOutside(true);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setGravity(Gravity.BOTTOM);
            WindowManager.LayoutParams p = window.getAttributes();
            p.width = WindowManager.LayoutParams.MATCH_PARENT;
            p.height = WindowManager.LayoutParams.WRAP_CONTENT;
            p.dimAmount = .28f;
            window.setAttributes(p);
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
        dialog.show();
        if (window != null) window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private View dataLine(String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(7), 0, dp(7));
        TextView left = text(label, 12.5f, false, Color.rgb(174, 193, 210));
        TextView right = text(value, 13.5f, true, Color.WHITE);
        right.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        row.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(right, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f));
        return row;
    }

    /** Activa el buscador de la barra fija de arriba (no abre otro buscador). */
    private void showPlaceSearchDialog() {
        openSearchPanel();
    }

    private void openSearchPanel() {
        if (placeSearchInput == null) return;
        searchPanelOpen = true;
        if (searchPanel != null) searchPanel.setVisibility(View.VISIBLE);
        if (placeSearchInput.getText().length() == 0) renderSearchHistory();
        placeSearchInput.setFocusable(true);
        placeSearchInput.setFocusableInTouchMode(true);
        placeSearchInput.requestFocus();
        placeSearchInput.postDelayed(() -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null && placeSearchInput != null) {
                imm.showSoftInput(placeSearchInput, InputMethodManager.SHOW_IMPLICIT);
            }
        }, 90);
    }

    private void closeSearchPanel() {
        searchPanelOpen = false;
        hideSearchKeyboard();
        if (searchPanel != null) searchPanel.setVisibility(View.GONE);
        if (placeSearchInput != null) {
            placeSearchInput.clearFocus();
            placeSearchInput.setFocusable(false);
            placeSearchInput.setFocusableInTouchMode(false);
        }
    }

    /** Panel de resultados/historial que cuelga justo debajo de la barra de búsqueda. */
    private View buildSearchPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(6), dp(6), dp(6), dp(4));
        panel.setBackground(pill(Color.argb(250, 26, 30, 37), dp(20), Color.argb(46, 255, 255, 255)));
        panel.setElevation(dp(14));
        panel.setVisibility(View.GONE);
        panel.setOnClickListener(v -> { });

        final int screenHeight = getResources().getDisplayMetrics().heightPixels;
        final int resultsMaxHeight = Math.min(dp(280), Math.max(dp(130), Math.round(screenHeight * 0.32f)));
        ScrollView scroll = new ScrollView(this) {
            @Override
            protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
                int capped = View.MeasureSpec.makeMeasureSpec(resultsMaxHeight, View.MeasureSpec.AT_MOST);
                super.onMeasure(widthMeasureSpec, capped);
            }
        };
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);

        placeSearchResults = new LinearLayout(this);
        placeSearchResults.setOrientation(LinearLayout.VERTICAL);
        placeSearchResults.setPadding(dp(4), dp(2), dp(4), dp(2));
        scroll.addView(placeSearchResults, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        placeSearchStatus = text("Ciudad, distrito, calle o coordenadas", 12f, false, Color.rgb(158, 168, 180));
        placeSearchStatus.setGravity(Gravity.CENTER);
        placeSearchStatus.setPadding(dp(12), dp(9), dp(12), dp(7));
        panel.addView(placeSearchStatus);

        searchPanel = panel;
        return panel;
    }

    // ----- Historial de búsquedas -----

    private List<SearchResult> loadSearchHistory() {
        List<SearchResult> history = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(
                    getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_SEARCH_HISTORY, "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                String name = item.optString("name", "").trim();
                double lat = item.optDouble("lat", Double.NaN);
                double lon = item.optDouble("lon", Double.NaN);
                if (name.isEmpty() || Double.isNaN(lat) || Double.isNaN(lon)) continue;
                history.add(new SearchResult(name, new LatLng(lat, lon)));
            }
        } catch (Exception ignored) { }
        return history;
    }

    private void storeSearchHistory(List<SearchResult> history) {
        try {
            JSONArray array = new JSONArray();
            for (SearchResult item : history) {
                JSONObject json = new JSONObject();
                json.put("name", item.name);
                json.put("lat", item.point.getLatitude());
                json.put("lon", item.point.getLongitude());
                array.put(json);
            }
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_SEARCH_HISTORY, array.toString()).apply();
        } catch (Exception ignored) { }
    }

    /** Guarda el lugar elegido arriba del historial, sin duplicados. */
    private void rememberSearch(String name, LatLng point) {
        if (name == null || name.trim().isEmpty() || point == null) return;
        List<SearchResult> history = loadSearchHistory();
        for (int i = history.size() - 1; i >= 0; i--) {
            if (history.get(i).name.equalsIgnoreCase(name.trim())) history.remove(i);
        }
        history.add(0, new SearchResult(name.trim(), point));
        while (history.size() > MAX_SEARCH_HISTORY) history.remove(history.size() - 1);
        storeSearchHistory(history);
    }

    private void renderSearchHistory() {
        if (placeSearchResults == null) return;
        placeSearchResults.removeAllViews();
        List<SearchResult> history = loadSearchHistory();
        if (history.isEmpty()) {
            if (placeSearchStatus != null) {
                placeSearchStatus.setText("Ciudad, distrito, calle o coordenadas");
                placeSearchStatus.setVisibility(View.VISIBLE);
            }
            return;
        }
        if (placeSearchStatus != null) placeSearchStatus.setVisibility(View.GONE);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(10), dp(6), dp(6), dp(2));
        TextView title = text("Búsquedas recientes", 11.5f, true, Color.rgb(150, 161, 174));
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView clearAll = text("Borrar", 11.5f, true, Color.rgb(104, 160, 255));
        clearAll.setPadding(dp(8), dp(4), dp(6), dp(4));
        clearAll.setOnClickListener(v -> {
            storeSearchHistory(new ArrayList<>());
            renderSearchHistory();
        });
        header.addView(clearAll);
        placeSearchResults.addView(header);

        for (int i = 0; i < history.size(); i++) {
            final SearchResult item = history.get(i);
            placeSearchResults.addView(buildHistoryRow(item));
        }
    }

    private View buildHistoryRow(SearchResult item) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(4), dp(6), dp(2), dp(6));
        row.setOnClickListener(v -> {
            if (placeSearchInput != null) placeSearchInput.setText(shortPlace(item.name));
            closeSearchPanel();
            rememberSearch(item.name, item.point);
            centerSearchResult(item.point, item.name);
        });

        TextView icon = text("↺", 17, false, Color.rgb(168, 180, 194));
        icon.setGravity(Gravity.CENTER);
        row.addView(icon, new LinearLayout.LayoutParams(dp(36), dp(40)));

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.setPadding(dp(6), 0, dp(4), 0);
        String[] parts = splitSearchResultLabel(item.name);
        TextView title = text(parts[0], 14f, false, Color.rgb(232, 237, 243));
        title.setMaxLines(1);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        labels.addView(title);
        TextView subtitle = text(parts[1], 11.5f, false, Color.rgb(152, 164, 178));
        subtitle.setMaxLines(1);
        subtitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
        labels.addView(subtitle);
        row.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView remove = text("×", 19, false, Color.rgb(140, 151, 164));
        remove.setGravity(Gravity.CENTER);
        remove.setContentDescription("Quitar del historial");
        remove.setOnClickListener(v -> {
            List<SearchResult> history = loadSearchHistory();
            for (int i = history.size() - 1; i >= 0; i--) {
                if (history.get(i).name.equalsIgnoreCase(item.name)) history.remove(i);
            }
            storeSearchHistory(history);
            renderSearchHistory();
        });
        row.addView(remove, new LinearLayout.LayoutParams(dp(34), dp(40)));
        return row;
    }

    private void submitPlaceSearch() {
        if (placeSearchInput == null) return;
        String query = placeSearchInput.getText().toString().trim();
        if (query.isEmpty()) {
            placeSearchInput.setError("Escribe un lugar o coordenadas");
            return;
        }
        hideSearchKeyboard();
        if (placeSearchResults != null) placeSearchResults.removeAllViews();
        if (placeSearchStatus != null) {
            placeSearchStatus.setText("Buscando “" + query + "”…");
            placeSearchStatus.setVisibility(View.VISIBLE);
        }
        searchPlace(query);
    }

    private void hideSearchKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null && placeSearchInput != null) {
                imm.hideSoftInputFromWindow(placeSearchInput.getWindowToken(), 0);
            }
        } catch (Exception ignored) { }
    }

    private void searchPlace(String query) {
        LatLng coordinates = parseCoordinates(query);
        if (coordinates != null) {
            List<SearchResult> direct = new ArrayList<>();
            direct.add(new SearchResult(String.format(Locale.US, "%.6f, %.6f", coordinates.getLatitude(), coordinates.getLongitude()), coordinates));
            showSearchResults(query, direct);
            return;
        }
        setStatus("Buscando “" + query + "”…");
        lookupExecutor.execute(() -> {
            List<SearchResult> results = searchWithNominatim(query);
            final List<SearchResult> finalResults = results;
            runOnUiThread(() -> showSearchResults(query, finalResults));
        });
    }

    private LatLng parseCoordinates(String value) {
        try {
            String normalized = value.trim().replace(';', ',');
            String[] parts = normalized.contains(",") ? normalized.split(",") : normalized.split("\\s+");
            if (parts.length != 2) return null;
            double lat = Double.parseDouble(parts[0].trim());
            double lon = Double.parseDouble(parts[1].trim());
            if (lat < -90 || lat > 90 || lon < -180 || lon > 180) return null;
            return new LatLng(lat, lon);
        } catch (Exception ignored) {
            return null;
        }
    }

    private List<SearchResult> searchWithNominatim(String query) {
        String cacheKey = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        List<SearchResult> cached = cachedSearch(cacheKey);
        if (cached != null) return cached;

        List<SearchResult> results = new ArrayList<>();
        HttpURLConnection connection = null;
        try {
            awaitNominatimSlot();
            String language = Locale.getDefault().toLanguageTag();
            String endpoint = "https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&limit=8&accept-language="
                    + URLEncoder.encode(language, "UTF-8") + "&q=" + URLEncoder.encode(query, "UTF-8");
            connection = (HttpURLConnection) new URL(endpoint).openConnection();
            connection.setConnectTimeout(8000);
            connection.setReadTimeout(12000);
            connection.setRequestProperty("User-Agent", "GeoTopo/1.29 Android (com.bph.geotopo)");
            connection.setRequestProperty("Accept-Language", language);
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) return results;
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder json = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) json.append(line);
            JSONArray array = new JSONArray(json.toString());
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                double lat = item.optDouble("lat", Double.NaN);
                double lon = item.optDouble("lon", Double.NaN);
                String name = item.optString("display_name", "").trim();
                if (Double.isNaN(lat) || Double.isNaN(lon) || name.isEmpty()) continue;
                results.add(new SearchResult(name, new LatLng(lat, lon)));
            }
            putSearchCache(cacheKey, results);
        } catch (Exception ignored) {
            // Se informa al usuario en showSearchResults.
        } finally {
            if (connection != null) connection.disconnect();
        }
        return results;
    }

    private void showSearchResults(String query, List<SearchResult> results) {
        if (results == null || results.isEmpty()) {
            if (placeSearchResults != null) placeSearchResults.removeAllViews();
            if (placeSearchStatus != null) {
                placeSearchStatus.setText("No se encontraron resultados para “" + query + "”.");
                placeSearchStatus.setVisibility(View.VISIBLE);
            }
            setStatus("No se encontraron resultados para “" + query + "”.");
            if (!searchPanelOpen) {
                Toast.makeText(this, "No se encontró el lugar. Revisa internet o escribe provincia y región.", Toast.LENGTH_LONG).show();
            }
            return;
        }

        if (placeSearchResults == null || !searchPanelOpen) {
            SearchResult first = results.get(0);
            rememberSearch(first.name, first.point);
            centerSearchResult(first.point, first.name);
            return;
        }

        placeSearchResults.removeAllViews();
        int count = Math.min(5, results.size());
        for (int i = 0; i < count; i++) {
            SearchResult result = results.get(i);
            placeSearchResults.addView(buildSearchResultRow(result));
            if (i < count - 1) {
                View divider = new View(this);
                divider.setBackgroundColor(Color.argb(30, 255, 255, 255));
                LinearLayout.LayoutParams dividerLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
                dividerLp.setMargins(dp(44), 0, 0, 0);
                placeSearchResults.addView(divider, dividerLp);
            }
        }
        if (placeSearchStatus != null) placeSearchStatus.setVisibility(View.GONE);
        setStatus(results.size() + " resultados encontrados.");
    }

    private View buildSearchResultRow(SearchResult result) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(2), dp(8), dp(2), dp(8));
        row.setBackground(pill(Color.TRANSPARENT, dp(12), Color.TRANSPARENT));
        row.setOnClickListener(v -> {
            closeSearchPanel();
            rememberSearch(result.name, result.point);
            centerSearchResult(result.point, result.name);
        });

        ImageButton pin = new ImageButton(this);
        pin.setImageResource(R.drawable.ic_map_points);
        pin.setColorFilter(Color.rgb(68, 137, 255));
        pin.setBackgroundColor(Color.TRANSPARENT);
        pin.setPadding(dp(5), dp(5), dp(5), dp(5));
        pin.setClickable(false);
        row.addView(pin, new LinearLayout.LayoutParams(dp(38), dp(38)));

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.setPadding(dp(8), 0, dp(4), 0);

        String[] parts = splitSearchResultLabel(result.name);
        TextView title = text(parts[0], 14.2f, false, Color.WHITE);
        title.setMaxLines(1);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        labels.addView(title);
        TextView subtitle = text(parts[1], 11.8f, false, Color.rgb(165, 181, 198));
        subtitle.setMaxLines(1);
        subtitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
        subtitle.setPadding(0, dp(2), 0, 0);
        labels.addView(subtitle);

        row.addView(labels, new LinearLayout.LayoutParams(0, dp(52), 1f));
        return row;
    }

    private String[] splitSearchResultLabel(String name) {
        if (name == null || name.trim().isEmpty()) return new String[]{"Resultado", ""};
        String trimmed = name.trim();
        if (parseCoordinates(trimmed) != null) return new String[]{trimmed, "Coordenadas"};
        String[] chunks = trimmed.split(",");
        String title = chunks.length > 0 ? chunks[0].trim() : trimmed;
        StringBuilder sub = new StringBuilder();
        for (int i = 1; i < chunks.length && i <= 3; i++) {
            String part = chunks[i].trim();
            if (part.isEmpty()) continue;
            if (sub.length() > 0) sub.append(", ");
            sub.append(part);
        }
        if (sub.length() == 0) sub.append("Lugar");
        return new String[]{title, sub.toString()};
    }

    private void centerSearchResult(LatLng point, String name) {
        if (map == null) return;
        CameraPosition position = new CameraPosition.Builder(map.getCameraPosition())
                .target(point)
                .zoom(Math.max(15.5, map.getCameraPosition().zoom))
                .build();
        map.animateCamera(CameraUpdateFactory.newCameraPosition(position), 650);
        showSelectedPoint(point, name);
        setStatus(shortPlace(name) + " · resultado de búsqueda");
    }

    private void showInfo() {
        new AlertDialog.Builder(this)
                .setTitle("Mapa nativo GeoTopo")
                .setMessage("El mapa ahora usa MapLibre y la GPU del teléfono para mover y ampliar con mayor fluidez.\n\n"
                        + "Mantén pulsado un lugar para ver su nombre, dirección, coordenadas y UTM.\n\n"
                        + "Usa la lupa para buscar lugares o coordenadas. Las mediciones sobre imagen son referenciales.")
                .setPositiveButton("Entendido", null)
                .show();
    }

    /**
     * La barra negra inferior es exclusivamente el indicador de ubicación:
     * los avisos de medición y de estado ya no la sobrescriben.
     */
    private void setStatus(String text) {
        // Intencionalmente sin efecto. Usa setLocationStatus() o alertStatus().
    }

    /** Único punto que escribe en la barra inferior (ubicación / GPS). */
    private void setLocationStatus(String text) {
        if (statusView != null) statusView.setText(text);
    }

    /** Avisos puntuales que antes tapaban la ubicación. */
    private void alertStatus(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }

    private void appendPart(StringBuilder out, String value) {
        if (value == null || value.trim().isEmpty()) return;
        if (out.length() > 0) out.append(", ");
        out.append(value.trim());
    }

    private double totalDistance(List<LatLng> points) {
        double total = 0;
        for (int i = 1; i < points.size(); i++) total += haversine(points.get(i - 1), points.get(i));
        return total;
    }

    private double haversine(LatLng a, LatLng b) {
        final double r = 6371008.8;
        double p1 = Math.toRadians(a.getLatitude());
        double p2 = Math.toRadians(b.getLatitude());
        double dp = Math.toRadians(b.getLatitude() - a.getLatitude());
        double dl = Math.toRadians(b.getLongitude() - a.getLongitude());
        double q = Math.sin(dp / 2) * Math.sin(dp / 2)
                + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
        return 2 * r * Math.atan2(Math.sqrt(q), Math.sqrt(1 - q));
    }

    private double polygonArea(List<LatLng> points) {
        if (points.size() < 3) return 0;
        double meanLat = 0;
        for (LatLng p : points) meanLat += p.getLatitude();
        meanLat = Math.toRadians(meanLat / points.size());
        double scaleX = 111320.0 * Math.cos(meanLat);
        double scaleY = 110540.0;
        double area = 0;
        for (int i = 0; i < points.size(); i++) {
            LatLng a = points.get(i);
            LatLng b = points.get((i + 1) % points.size());
            area += (a.getLongitude() * scaleX) * (b.getLatitude() * scaleY)
                    - (b.getLongitude() * scaleX) * (a.getLatitude() * scaleY);
        }
        return Math.abs(area) / 2.0;
    }


    private String nextMapPointName() {
        try {
            JSONArray array = new JSONArray(getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]"));
            int n = 1;
            while (true) {
                String candidate = "M" + n;
                boolean used = false;
                for (int i = 0; i < array.length(); i++) {
                    JSONObject item = array.optJSONObject(i);
                    if (item != null && candidate.equalsIgnoreCase(item.optString("name"))) { used = true; break; }
                }
                if (!used) return candidate;
                n++;
            }
        } catch (Exception ignored) {
            return "M1";
        }
    }

    private static UtmCoordinate toUtm(double latitude, double longitude) {
        if (latitude < -80.0 || latitude > 84.0 || longitude < -180.0 || longitude > 180.0) return UtmCoordinate.invalid();
        final double a = 6378137.0;
        final double eccSquared = 0.00669438;
        final double k0 = 0.9996;
        int zoneNumber = (int) Math.floor((longitude + 180.0) / 6.0) + 1;
        if (longitude == 180.0) zoneNumber = 60;
        if (latitude >= 56.0 && latitude < 64.0 && longitude >= 3.0 && longitude < 12.0) zoneNumber = 32;
        if (latitude >= 72.0 && latitude < 84.0) {
            if (longitude < 9.0) zoneNumber = 31;
            else if (longitude < 21.0) zoneNumber = 33;
            else if (longitude < 33.0) zoneNumber = 35;
            else if (longitude < 42.0) zoneNumber = 37;
        }
        double lonOrigin = (zoneNumber - 1) * 6.0 - 180.0 + 3.0;
        double latRad = Math.toRadians(latitude);
        double lonRad = Math.toRadians(longitude);
        double lonOriginRad = Math.toRadians(lonOrigin);
        double eccPrimeSquared = eccSquared / (1.0 - eccSquared);
        double sinLat = Math.sin(latRad);
        double cosLat = Math.cos(latRad);
        double tanLat = Math.tan(latRad);
        double n = a / Math.sqrt(1.0 - eccSquared * sinLat * sinLat);
        double t = tanLat * tanLat;
        double c = eccPrimeSquared * cosLat * cosLat;
        double aa = cosLat * (lonRad - lonOriginRad);
        double m = a * ((1.0 - eccSquared / 4.0 - 3.0 * eccSquared * eccSquared / 64.0 - 5.0 * Math.pow(eccSquared, 3) / 256.0) * latRad
                - (3.0 * eccSquared / 8.0 + 3.0 * eccSquared * eccSquared / 32.0 + 45.0 * Math.pow(eccSquared, 3) / 1024.0) * Math.sin(2.0 * latRad)
                + (15.0 * eccSquared * eccSquared / 256.0 + 45.0 * Math.pow(eccSquared, 3) / 1024.0) * Math.sin(4.0 * latRad)
                - (35.0 * Math.pow(eccSquared, 3) / 3072.0) * Math.sin(6.0 * latRad));
        double easting = k0 * n * (aa + (1.0 - t + c) * Math.pow(aa, 3) / 6.0
                + (5.0 - 18.0 * t + t * t + 72.0 * c - 58.0 * eccPrimeSquared) * Math.pow(aa, 5) / 120.0) + 500000.0;
        double northing = k0 * (m + n * tanLat * (aa * aa / 2.0
                + (5.0 - t + 9.0 * c + 4.0 * c * c) * Math.pow(aa, 4) / 24.0
                + (61.0 - 58.0 * t + t * t + 600.0 * c - 330.0 * eccPrimeSquared) * Math.pow(aa, 6) / 720.0));
        String hemisphere = latitude < 0.0 ? "S" : "N";
        if (latitude < 0.0) northing += 10000000.0;
        return new UtmCoordinate(true, zoneNumber, hemisphere, easting, northing);
    }

    private LinearLayout floatingPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(11), dp(14), dp(11));
        panel.setBackground(pill(Color.argb(247, 4, 36, 58), dp(20), Color.argb(90, 255, 255, 255)));
        panel.setElevation(dp(14));
        return panel;
    }

    private Button panelButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        ResponsiveUi.configureCompactText(b, 12, 9, 2);
        b.setBackground(pill(accentColor, dp(12), Color.argb(80, 255, 255, 255)));
        return b;
    }

    private LinearLayout.LayoutParams weightButton() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(50), 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    private Button measureModeButton(String icon, String label) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setMinHeight(dp(74));
        button.setMinimumHeight(dp(74));
        button.setPadding(dp(4), dp(6), dp(4), dp(6));
        button.setGravity(Gravity.CENTER);
        button.setTextColor(Color.WHITE);
        ResponsiveUi.configureCompactText(button, 12.2f, 9.4f, 2);
        setMeasureButtonText(button, icon, label, true);
        return button;
    }

    private Button measureInlineButton(String icon, String label) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setMinHeight(dp(54));
        button.setMinimumHeight(dp(54));
        button.setPadding(dp(8), dp(6), dp(8), dp(6));
        button.setGravity(Gravity.CENTER);
        button.setTextColor(Color.WHITE);
        ResponsiveUi.configureCompactText(button, 11.6f, 9f, 1);
        setMeasureButtonText(button, icon, label, false);
        return button;
    }

    private Button measureActionButton(String icon, String label, boolean primary) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setMinHeight(dp(62));
        button.setMinimumHeight(dp(62));
        button.setPadding(dp(10), dp(8), dp(10), dp(8));
        button.setGravity(Gravity.CENTER);
        button.setTextColor(Color.WHITE);
        ResponsiveUi.configureCompactText(button, 12.6f, 10.2f, 1);
        setMeasureButtonText(button, icon, label, false);
        button.setTag(primary ? "measure_primary" : "measure_secondary");
        return button;
    }

    private void setMeasureButtonText(Button button, String icon, String label, boolean stacked) {
        SpannableStringBuilder builder = new SpannableStringBuilder();
        int iconStart = 0;
        builder.append(icon == null ? "" : icon);
        builder.setSpan(new RelativeSizeSpan(stacked ? 1.34f : 1.18f), iconStart, builder.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (stacked) {
            builder.append("\n");
        } else {
            builder.append("  ");
        }
        int labelStart = builder.length();
        builder.append(label == null ? "" : label);
        builder.setSpan(new RelativeSizeSpan(1f), labelStart, builder.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        button.setText(builder);
        button.setLineSpacing(0f, stacked ? 1.05f : 1f);
    }

    private LinearLayout.LayoutParams measureTopTileParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(80), 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        return lp;
    }

    private LinearLayout.LayoutParams measureInlineTileParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(52), 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    private LinearLayout.LayoutParams measureActionTileParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(58), 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    private LinearLayout.LayoutParams fullWidthSectionParams(int topMarginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(topMarginDp), 0, 0);
        return lp;
    }

    private void styleMeasureModeButton(Button button, boolean active, boolean enabled) {
        if (button == null) return;
        int fill;
        int stroke;
        int textColor;
        if (!enabled) {
            fill = Color.argb(128, 19, 39, 58);
            stroke = Color.argb(40, 255, 255, 255);
            textColor = Color.argb(150, 210, 223, 236);
        } else if (active) {
            fill = accentColor;
            stroke = Color.argb(110, 255, 255, 255);
            textColor = Color.WHITE;
        } else {
            fill = Color.TRANSPARENT;
            stroke = Color.TRANSPARENT;
            textColor = Color.rgb(232, 239, 248);
        }
        button.setBackground(pill(fill, dp(16), stroke));
        button.setTextColor(textColor);
        button.setEnabled(enabled);
        button.setAlpha(enabled ? 1f : 0.56f);
    }

    private void styleMeasureInlineButton(Button button, boolean enabled, boolean danger) {
        if (button == null) return;
        int fill = Color.TRANSPARENT;
        int stroke = Color.TRANSPARENT;
        int textColor = danger ? Color.rgb(255, 174, 174) : Color.rgb(235, 242, 250);
        if (!enabled) {
            textColor = Color.argb(145, 205, 218, 232);
        }
        button.setBackground(pill(fill, dp(14), stroke));
        button.setTextColor(textColor);
        button.setEnabled(enabled);
        button.setAlpha(enabled ? 1f : 0.5f);
    }

    private void styleMeasureActionButton(Button button, boolean primary, boolean enabled) {
        if (button == null) return;
        int fill = primary ? accentColor : Color.TRANSPARENT;
        int stroke = primary ? Color.argb(95, 255, 255, 255) : Color.argb(105, 72, 152, 255);
        int textColor = enabled ? Color.WHITE : Color.argb(170, 215, 228, 240);
        if (!enabled && primary) {
            fill = Color.argb(145, 26, 72, 122);
        }
        button.setBackground(pill(fill, dp(18), stroke));
        button.setTextColor(textColor);
        button.setEnabled(enabled);
        button.setAlpha(enabled ? 1f : 0.62f);
    }


    private void updateMeasurePanelUi() {
        if (measureDistanceButton == null) return;
        setMeasureButtonText(measureDistanceButton, "↔", "Distancia", true);
        setMeasureButtonText(measureAreaButton, "⬠", "Área", true);
        setMeasureButtonText(measureProfileButton, "⌁", "Perfil", true);
        setMeasureButtonText(measureUnitsButton, "⌗", "Unidades", true);
        setMeasureButtonText(measureUndoButton, "↶", "Deshacer", false);
        setMeasureButtonText(measureRedoButton, "↷", "Rehacer", false);
        setMeasureButtonText(measureDeleteButton, "⌫", "Eliminar punto", false);
        setMeasureButtonText(measureFinishButton, "✓", "Finalizar", false);
        setMeasureButtonText(measureClearButton, "⌫", "Limpiar", false);
        styleMeasureModeButton(measureDistanceButton, !areaMode, true);
        styleMeasureModeButton(measureAreaButton, areaMode, true);
        styleMeasureModeButton(measureProfileButton, false, measurementPoints.size() >= 2);
        styleMeasureModeButton(measureUnitsButton, false, true);
        styleMeasureInlineButton(measureUndoButton, !measurementPoints.isEmpty(), false);
        styleMeasureInlineButton(measureRedoButton, !measurementRedo.isEmpty(), false);
        styleMeasureInlineButton(measureDeleteButton, !measurementPoints.isEmpty(), true);
        styleMeasureActionButton(measureFinishButton, true, true);
        styleMeasureActionButton(measureClearButton, false, !measurementPoints.isEmpty());
    }

    private View mapTool(int iconRes, String label, View.OnClickListener listener) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setContentDescription(label);
        item.setOnClickListener(listener);

        ImageButton icon = new ImageButton(this);
        icon.setImageResource(iconRes);
        icon.setScaleType(android.widget.ImageView.ScaleType.CENTER);
        icon.setPadding(dp(7), dp(7), dp(7), dp(7));
        icon.setColorFilter(Color.WHITE);
        icon.setContentDescription(label);
        icon.setOnClickListener(listener);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setShape(GradientDrawable.OVAL);
        iconBg.setColor(Color.argb(210, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)));
        iconBg.setStroke(dp(1), Color.argb(95, 255, 255, 255));
        icon.setBackground(iconBg);
        icon.setElevation(dp(4));
        item.addView(icon, new LinearLayout.LayoutParams(dp(34), dp(34)));

        TextView caption = text(label, 8.3f, false, Color.WHITE);
        caption.setGravity(Gravity.CENTER);
        caption.setMaxLines(1);
        item.addView(caption, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(15)));
        return item;
    }

    private LinearLayout.LayoutParams toolParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        return lp;
    }


    private TextView text(String value, float size, boolean bold, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        ResponsiveUi.configureText(view, size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private GradientDrawable pill(int fill, int radius, int stroke) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(fill);
        gd.setCornerRadius(radius);
        gd.setStroke(dp(1), stroke);
        return gd;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            boolean granted = false;
            for (int value : grantResults) if (value == PackageManager.PERMISSION_GRANTED) granted = true;
            if (granted) requestLocationUpdates();
            else setLocationStatus("Permiso de ubicación denegado.");
        }
    }

    @Override protected void onStart() { super.onStart(); mapView.onStart(); }
    @Override protected void onResume() { super.onResume(); mapView.onResume(); }
    @Override protected void onPause() { try { if (locationManager != null) locationManager.removeUpdates(this); } catch (Exception ignored) { } mapView.onPause(); super.onPause(); }
    @Override protected void onStop() { mapView.onStop(); super.onStop(); }
    @Override public void onLowMemory() { super.onLowMemory(); mapView.onLowMemory(); }
    @Override protected void onDestroy() { offlineServer.stop(); lookupExecutor.shutdownNow(); handler.removeCallbacksAndMessages(null); mapView.onDestroy(); super.onDestroy(); }
    @Override protected void onSaveInstanceState(Bundle outState) { super.onSaveInstanceState(outState); mapView.onSaveInstanceState(outState); }

    private static final class SavedPointInfo {
        final String name;
        final String project;
        final String description;
        final LatLng point;

        SavedPointInfo(String name, String project, String description, LatLng point) {
            this.name = name;
            this.project = project;
            this.description = description;
            this.point = point;
        }
    }

    private static final class SearchResult {
        final String name;
        final LatLng point;

        SearchResult(String name, LatLng point) {
            this.name = name;
            this.point = point;
        }
    }

    private static final class UtmCoordinate {
        final boolean valid;
        final int zone;
        final String hemisphere;
        final double easting;
        final double northing;

        UtmCoordinate(boolean valid, int zone, String hemisphere, double easting, double northing) {
            this.valid = valid;
            this.zone = zone;
            this.hemisphere = hemisphere;
            this.easting = easting;
            this.northing = northing;
        }

        static UtmCoordinate invalid() {
            return new UtmCoordinate(false, 0, "", Double.NaN, Double.NaN);
        }
    }

    @Override public void onBackPressed() {
        if (searchPanelOpen) {
            closeSearchPanel();
            return;
        }
        super.onBackPressed();
    }

    @Override public void onContentChanged() {
        super.onContentChanged();
        NativeUi.applySystemBarInsets(this);
    }
}
