import com.bph.geotopo.AzimuthMath;

/** Run offline with javac -d /tmp/test app/.../AzimuthMath.java tests/AzimuthMathTest.java && java -cp /tmp/test AzimuthMathTest */
public final class AzimuthMathTest {
    private static int checks;
    private static void eq(double actual, double expected) {
        checks++;
        if (Math.abs(actual - expected) > 1e-8) throw new AssertionError(actual + " != " + expected);
    }
    private static void eq(String actual, String expected) {
        checks++;
        if (!actual.equals(expected)) throw new AssertionError(actual + " != " + expected);
    }
    private static void reject(String raw, int mode) {
        checks++;
        try { AzimuthMath.toAzimuth(raw, mode); }
        catch (IllegalArgumentException expected) { return; }
        throw new AssertionError("Invalid input was accepted: " + raw);
    }
    public static void main(String[] args) {
        eq(AzimuthMath.toAzimuth("190", 0), 190);
        eq(AzimuthMath.toAzimuth("190.5", 0), 190.5);
        eq(AzimuthMath.toAzimuth("190,5", 0), 190.5);
        eq(AzimuthMath.toAzimuth("190.30", 0), 190.3);
        eq(AzimuthMath.toAzimuth("190°30'00\"", 0), 190.5);
        eq(AzimuthMath.toAzimuth("360°00'00\"", 0), 0);
        eq(AzimuthMath.toAzimuth("0", 0), 0);
        eq(AzimuthMath.toAzimuth("S 60° O", 1), 240);
        eq(AzimuthMath.toAzimuth("S 60° W", 1), 240);
        eq(AzimuthMath.toAzimuth("N 30 E", 1), 30);
        eq(AzimuthMath.toAzimuth("S 30 E", 1), 150);
        eq(AzimuthMath.toAzimuth("N 30 W", 1), 330);
        eq(AzimuthMath.toAzimuth("N", 1), 0);
        eq(AzimuthMath.toAzimuth("O", 1), 270);
        eq(AzimuthMath.toAzimuth("E", 1), 90);
        eq(AzimuthMath.toAzimuth("S 90 O", 1), 270);
        eq(AzimuthMath.toAzimuth("N 0 W", 1), 0);
        eq(AzimuthMath.toAzimuth("190", 2), 10);
        eq(AzimuthMath.toAzimuth("S 60 O", 3), 60);
        eq(AzimuthMath.counter(240), 60);
        eq(AzimuthMath.dms(190.5), "190°30'00\"");
        eq(AzimuthMath.dms(360), "0°00'00\"");
        eq(AzimuthMath.quadrant(190), "SO");
        eq(AzimuthMath.quadrant(90), "Eje cardinal");
        reject("361", 0);
        reject("720", 0);
        reject("-1", 0);
        reject("360°00'01\"", 0);
        reject("359°60'00\"", 0);
        reject("359°59'60\"", 0);
        reject("360.0001", 0);
        reject("NaN", 0);
        reject("Infinity", 0);
        reject("100º2º1º7", 0);
        reject("S 91 O", 1);
        reject("N 360 E", 1);
        reject("N 30", 1);
        reject("N -30 W", 1);
        reject("S 45°60' O", 1);
        reject("S 360 O", 3);
        reject("1e300", 0);
        eq(AzimuthMath.toAzimuth("360", 0), 0);
        eq(AzimuthMath.toAzimuth("90", 0), 90);
        eq(AzimuthMath.toAzimuth("270", 0), 270);
        System.out.println("OK: " + checks + " independent offline direction tests");
    }
}
