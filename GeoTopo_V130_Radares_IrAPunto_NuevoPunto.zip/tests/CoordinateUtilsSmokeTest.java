import com.bph.geotopo.CoordinateUtils;

/** Standalone smoke test: javac CoordinateUtils.java tests/CoordinateUtilsSmokeTest.java */
public class CoordinateUtilsSmokeTest {
    static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
    static void checkRoundtrip(double latitude, double longitude) {
        CoordinateUtils.Utm u = CoordinateUtils.toUtm(latitude, longitude);
        check(u.valid, "UTM invalid " + latitude + ", " + longitude);
        CoordinateUtils.LatLon r = CoordinateUtils.fromUtm(u.easting, u.northing, u.zone, u.south);
        check(r.valid, "inverse invalid");
        check(Math.abs(latitude - r.latitude) < 0.00001, "latitude mismatch");
        check(Math.abs(longitude - r.longitude) < 0.00001, "longitude mismatch");
    }
    public static void main(String[] args) {
        check("19L (Sur)".equals(CoordinateUtils.zoneWithBand(-14.782345, -71.418765)),
            "The Handy GPS 19L example must show band L and southern hemisphere separately");
        check("18N (Norte)".equals(CoordinateUtils.zoneWithBand(0, -75)), "Equator is band N");
        check(CoordinateUtils.latitudeBand(-14.8) == 'L', "Southern Peru band L");
        check(CoordinateUtils.latitudeBand(-8.5) == 'L', "Latitude band boundary");
        check(CoordinateUtils.latitudeBand(-7.9) == 'M', "Band above boundary");
        check(CoordinateUtils.latitudeBand(83) == 'X', "Band X covers last 12 degrees");
        checkRoundtrip(-14.782345, -71.418765);
        checkRoundtrip(0, -75);
        checkRoundtrip(40.71, -74.0);
        checkRoundtrip(-33.43, -70.65);
        checkRoundtrip(83.99, 12.0);
        System.out.println("OK: UTM zone, band and WGS84 roundtrip tests");
    }
}
