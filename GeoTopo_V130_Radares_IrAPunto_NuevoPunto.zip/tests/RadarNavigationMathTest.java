import com.bph.geotopo.RadarNavigationMath;

public class RadarNavigationMathTest {
    static int checks;
    static void near(double expected, double actual) {
        if (!Double.isFinite(actual) || Math.abs(expected - actual) > 0.000001)
            throw new AssertionError("Expected " + expected + ", got " + actual);
        checks++;
    }
    static void condition(boolean ok, String why) {
        if (!ok) throw new AssertionError(why);
        checks++;
    }
    public static void main(String[] args) {
        near(0, RadarNavigationMath.wrap(360));
        near(359, RadarNavigationMath.wrap(-1));
        near(0, RadarNavigationMath.wrap(720));
        near(180, RadarNavigationMath.wrap(-180));
        near(2, RadarNavigationMath.relativeAngle(1,359));
        near(-2, RadarNavigationMath.relativeAngle(359,1));
        near(90, RadarNavigationMath.relativeAngle(90,0));
        near(-90, RadarNavigationMath.relativeAngle(270,0));
        near(180, RadarNavigationMath.relativeAngle(180,0));
        near(25, RadarNavigationMath.autoRange(0));
        near(25, RadarNavigationMath.autoRange(25));
        near(50, RadarNavigationMath.autoRange(25.01));
        near(1000, RadarNavigationMath.autoRange(999));
        near(100000, RadarNavigationMath.autoRange(1e9));
        near(100, RadarNavigationMath.autoRange(Double.NaN));
        near(50, RadarNavigationMath.manualRange(100,true));
        near(250, RadarNavigationMath.manualRange(100,false));
        near(25, RadarNavigationMath.manualRange(25,true));
        near(100000, RadarNavigationMath.manualRange(100000,false));
        condition(RadarNavigationMath.withinAccuracy(6,15), "within ±15");
        condition(!RadarNavigationMath.withinAccuracy(16,15), "outside ±15");
        condition(!RadarNavigationMath.withinAccuracy(0,Double.NaN), "unknown accuracy not near");
        condition(!RadarNavigationMath.withinAccuracy(-1,15), "negative distance");
        condition(Double.isNaN(RadarNavigationMath.relativeAngle(Double.NaN,0)), "missing direction");
        System.out.println("OK: " + checks + " independent offline radar navigation tests");
    }
}
