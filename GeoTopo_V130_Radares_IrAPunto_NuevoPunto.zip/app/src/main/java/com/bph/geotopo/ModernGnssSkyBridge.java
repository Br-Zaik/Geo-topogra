package com.bph.geotopo;

import android.annotation.TargetApi;
import android.location.GnssStatus;
import android.location.LocationManager;
import java.util.ArrayList;
import java.util.List;

@TargetApi(24)
final class ModernGnssSkyBridge implements GnssSkyBridge {
    private final GnssStatus.Callback callback;
    ModernGnssSkyBridge(Sink sink) {
        callback = new GnssStatus.Callback() {
            @Override public void onSatelliteStatusChanged(GnssStatus status) {
                List<Satellite> newSats = new ArrayList<>();
                for (int i=0; i<status.getSatelliteCount();i++) {
                    Satellite sat = new Satellite();
                    sat.azimuth=status.getAzimuthDegrees(i);
                    sat.elevation=status.getElevationDegrees(i);
                    sat.cn0=status.getCn0DbHz(i);
                    sat.used=status.usedInFix(i);
                    sat.prefix=prefix(status.getConstellationType(i));
                    sat.svid=status.getSvid(i);
                    newSats.add(sat);
                }
                sink.onSatellites(newSats);
            }
        };
    }
    @Override public void start(LocationManager manager){manager.registerGnssStatusCallback(callback);}
    @Override public void stop(LocationManager manager){if(manager!=null)manager.unregisterGnssStatusCallback(callback);}
    private static String prefix(int constellation){
        switch(constellation){
            case GnssStatus.CONSTELLATION_GPS:return "G";
            case GnssStatus.CONSTELLATION_GLONASS:return "R";
            case GnssStatus.CONSTELLATION_GALILEO:return "E";
            case GnssStatus.CONSTELLATION_BEIDOU:return "C";
            case GnssStatus.CONSTELLATION_QZSS:return "J";
            case GnssStatus.CONSTELLATION_SBAS:return "S";
            case GnssStatus.CONSTELLATION_IRNSS:return "I";
            default:return "?";
        }
    }
}
