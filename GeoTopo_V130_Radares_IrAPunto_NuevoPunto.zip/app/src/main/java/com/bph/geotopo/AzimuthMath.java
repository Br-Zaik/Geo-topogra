package com.bph.geotopo;

import java.util.Locale;

/** Offline surveying azimuth/bearing math. Never silently wraps invalid input. */
public final class AzimuthMath {
    private AzimuthMath() { }

    /** Accepts decimal degrees (e.g. 190.5) or explicit DMS (190°30'00\").
     *  Bare 190.30 means DECIMAL degrees, not 190°30'. */
    public static double angle(String value, double max) {
        if (value == null) throw new IllegalArgumentException("Introduce un ángulo.");
        String raw = value.trim().replace(',', '.');
        if (raw.isEmpty()) throw new IllegalArgumentException("Introduce un ángulo.");
        if (!raw.matches("[0-9.°º'′\"″\\s]+"))
            throw new IllegalArgumentException("Solo números, grados, minutos y segundos; sin signos negativos.");
        String[] parts = raw.replaceAll("[°º'′\"″]", " ").trim().split("\\s+");
        if (parts.length == 0 || parts.length > 3)
            throw new IllegalArgumentException("Usa grados decimales o grados° minutos' segundos\".");
        double deg = component(parts[0]);
        double minutes = parts.length > 1 ? component(parts[1]) : 0;
        double seconds = parts.length > 2 ? component(parts[2]) : 0;
        if (minutes >= 60 || seconds >= 60)
            throw new IllegalArgumentException("Los minutos y segundos deben ser menores de 60.");
        double result = deg + minutes / 60d + seconds / 3600d;
        if (Double.isNaN(result) || Double.isInfinite(result) || result > max + 1e-11)
            throw new IllegalArgumentException("Máximo permitido: " + (int) max + "°. No se admiten vueltas adicionales.");
        return result;
    }

    private static double component(String str) {
        if (!str.matches("[0-9]+(?:\\.[0-9]+)?"))
            throw new IllegalArgumentException("Número angular incompleto o mal escrito.");
        double v = Double.parseDouble(str);
        if (Double.isNaN(v) || Double.isInfinite(v)) throw new IllegalArgumentException("Número demasiado grande.");
        return v;
    }

    /** Azimuth, counterazimuth and quadrant bearings from a strict input. */
    public static double toAzimuth(String raw, int inputMode) {
        double entered;
        if (inputMode == 0 || inputMode == 2) {
            entered = angle(raw, 360d);
        } else if (inputMode == 1 || inputMode == 3) {
            entered = bearing(raw);
        } else {
            throw new IllegalArgumentException("Tipo de dirección desconocido.");
        }
        double value = (inputMode == 2 || inputMode == 3) ? entered + 180d : entered;
        return normal(value);
    }

    /** N 30° E, S 60° O/W, single-axis N/S/E/O/W; quadrant 0..90°. */
    public static double bearing(String value) {
        if (value == null) throw new IllegalArgumentException("Introduce un rumbo.");
        String s = value.trim().toUpperCase(Locale.ROOT).replace('O', 'W');
        if ("N".equals(s)) return 0;
        if ("E".equals(s)) return 90;
        if ("S".equals(s)) return 180;
        if ("W".equals(s)) return 270;
        if (s.length() < 3 || (s.charAt(0) != 'N' && s.charAt(0) != 'S') ||
                (s.charAt(s.length() - 1) != 'E' && s.charAt(s.length() - 1) != 'W'))
            throw new IllegalArgumentException("Escribe el rumbo como N 30° E o S 60° O.");
        double a = angle(s.substring(1, s.length() - 1).trim(), 90d);
        if (s.charAt(0) == 'N') return s.charAt(s.length() - 1) == 'E' ? a : normal(360d - a);
        return s.charAt(s.length() - 1) == 'E' ? 180d - a : 180d + a;
    }

    public static double normal(double a) {
        if (Double.isNaN(a) || Double.isInfinite(a)) throw new IllegalArgumentException("Ángulo no válido.");
        double n = a % 360d;
        return n < 0d ? n + 360d : n;
    }

    public static double counter(double a) { return normal(a + 180d); }

    /** Formatted DMS; rounding carries seconds/minutes correctly. */
    public static String dms(double v) {
        long total = Math.round(normal(v) * 3600d) % (360L * 3600L);
        long d = total / 3600L;
        long m = (total % 3600L) / 60L;
        long s = total % 60L;
        return String.format(Locale.US, "%d°%02d'%02d\"", d, m, s);
    }

    public static String quadrant(double v) {
        double a = normal(v);
        if (a < 1e-9 || Math.abs(a - 90) < 1e-9 || Math.abs(a - 180) < 1e-9 || Math.abs(a - 270) < 1e-9)
            return "Eje cardinal";
        if (a < 90) return "NE";
        if (a < 180) return "SE";
        if (a < 270) return "SO";
        return "NO";
    }
}
