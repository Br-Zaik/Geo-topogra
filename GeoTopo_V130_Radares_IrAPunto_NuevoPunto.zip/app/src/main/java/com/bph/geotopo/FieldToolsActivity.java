package com.bph.geotopo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;

/** V128: Herramientas de campo con el nuevo diseño; mismas herramientas que V126. */
public class FieldToolsActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NativeUi.styleWindow(this);
        setContentView(buildScreen());
    }

    private View buildScreen() {
        FrameLayout root = NativeUi.screen(this);
        LinearLayout page = NativeUi.column(this);
        page.addView(DesignUi.toolsHeader(this, v -> finish(), null));

        LinearLayout c = NativeUi.column(this);
        c.setPadding(NativeUi.dp(this, 16), 0, NativeUi.dp(this, 16), NativeUi.dp(this, 24));

        c.addView(DesignUi.sectionHeader(this, "target", "CAPTURA Y UBICACIÓN"));
        c.addView(DesignUi.twoColumns(this,
                DesignUi.gridCard(this, "stakeout", "Replanteo de punto", "Coordenadas, dirección, distancia y tolerancia",
                        v -> open(StakeoutActivity.class)),
                DesignUi.gridCard(this, "track_grid", "Registro de recorridos GPS", "Trayectos, distancia, tiempo y puntos",
                        v -> open(TrackActivity.class))));
        c.addView(DesignUi.twoColumns(this,
                DesignUi.gridCard(this, "quality", "Calidad GNSS", "Satélites, precisión, constelaciones y NMEA",
                        v -> open(GnssQualityActivity.class)),
                DesignUi.gridCard(this, "external", "GNSS externo Bluetooth", "Receptores NMEA emparejados",
                        v -> open(ExternalGnssActivity.class))));

        c.addView(DesignUi.sectionHeader(this, "calculator", "CÁLCULOS DE CAMPO"));
        c.addView(DesignUi.full(this, DesignUi.wideCard(this, "cogo", true, "COGO directo e inverso",
                "Directa, inversa, intersecciones y offsets", v -> open(CogoActivity.class))));
        c.addView(DesignUi.twoColumns(this,
                DesignUi.gridCard(this, "area", "Área y perímetro", "Cálculo por vértices, lados y rumbos",
                        v -> open(AreaActivity.class)),
                DesignUi.gridCard(this, "traverse", "Poligonales", "Abierta, cerrada, cierres y Bowditch",
                        v -> open(TraverseActivity.class))));
        c.addView(DesignUi.twoColumns(this,
                DesignUi.gridCard(this, "leveling", "Nivelación de campo", "Vista atrás, intermedia, adelante y ajuste",
                        v -> open(LevelingFieldActivity.class)),
                DesignUi.gridCard(this, "profile", "Perfiles y secciones", "Progresivas, cotas y pendientes",
                        v -> open(ProfileActivity.class))));

        c.addView(DesignUi.sectionHeader(this, "map", "MAPAS Y ARCHIVOS"));
        c.addView(DesignUi.twoColumns(this,
                DesignUi.gridCard(this, "offline", "Mapas sin internet", "Paquetes MBTiles propios o autorizados",
                        v -> open(OfflineMapActivity.class)),
                DesignUi.gridCard(this, "notebook", "Libreta de campo", "Puntos, códigos, cotas y observaciones",
                        v -> open(NotebookActivity.class))));

        ScrollView scroll = NativeUi.scroll(this, c);
        scroll.setVerticalScrollBarEnabled(false);
        page.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(page, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return root;
    }

    private void open(Class<?> target) {
        startActivity(new Intent(this, target));
    }

    @Override public void onContentChanged() {
        super.onContentChanged();
        NativeUi.applySystemBarInsets(this);
    }
}
