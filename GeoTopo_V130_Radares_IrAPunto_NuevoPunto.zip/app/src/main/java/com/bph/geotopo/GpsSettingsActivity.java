package com.bph.geotopo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/** Ajustes de visualización. No modifica lecturas GNSS brutas ni finge modelo geoidal EGM. */
public class GpsSettingsActivity extends Activity {
    static final String PREFS = "geo_topo_gps_points";
    static final String FORMAT = "coordinate_display_format";
    static final String HEIGHT_OFFSET = "manual_height_offset_m";
    private static final int MINT = Color.rgb(95, 233, 184);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        NativeUi.styleWindow(this);
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        FrameLayout root = NativeUi.screen(this);
        LinearLayout page = NativeUi.column(this);
        page.addView(NativeUi.pageHeader(this, "Ajustes GPS",
                "Formatos y correcciones de campo", v -> finish(), null, null));
        LinearLayout body = NativeUi.column(this);
        body.setPadding(dp(15), dp(13), dp(15), dp(29));

        TextView banner = NativeUi.text(this, "⌖  WGS84  /  REFERENCIA TOPOGRÁFICA", 12.7f, true, MINT);
        banner.setPadding(dp(13), dp(18), dp(13), dp(18));
        banner.setBackground(NativeUi.gradient(Color.rgb(15, 68, 76), Color.rgb(7, 34, 55),
                16, NativeUi.withAlpha(MINT, 137), this));
        body.addView(banner);

        body.addView(section("01   REPRESENTACIÓN DE COORDENADAS"));
        LinearLayout formatsCard = card();
        formatsCard.addView(line("Formato geográfico", 15, NativeUi.TEXT));
        Spinner formats = selector(new String[]{
                "Grados decimales (DD)",
                "Grados y minutos (DM)",
                "Grados, minutos y segundos (DMS)"});
        formats.setSelection(Math.max(0, Math.min(2, sp.getInt(FORMAT, 0))));
        formatsCard.addView(formats);
        TextView explanation = line("La lectura UTM se mantiene en metros con zona, banda y hemisferio. "
                + "Esta opción modifica solo cómo se muestra la latitud y longitud.", 11.7f, NativeUi.SUB);
        explanation.setPadding(0, dp(10), 0, 0);
        formatsCard.addView(explanation);
        body.addView(formatsCard);

        body.addView(section("02   ALTITUD Y DATUM"));
        LinearLayout heightCard = card();
        heightCard.addView(line("Corrección manual de altitud (m)", 14.5f, NativeUi.TEXT));
        EditText offset = new EditText(this);
        offset.setHint("Ej.: -28.50");
        offset.setText(String.format(Locale.US, "%.2f", Double.longBitsToDouble(
                sp.getLong(HEIGHT_OFFSET, Double.doubleToLongBits(0d)))));
        offset.setTextColor(Color.WHITE);
        offset.setHintTextColor(NativeUi.SUB);
        offset.setTextSize(16);
        offset.setInputType(android.text.InputType.TYPE_CLASS_NUMBER
                | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                | android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
        offset.setPadding(dp(12), dp(13), dp(12), dp(13));
        offset.setBackground(NativeUi.rounded(Color.rgb(9, 30, 50), 12, 1,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 120), this));
        heightCard.addView(offset);
        TextView caveat = line("Altitud ajustada = altitud informada por Android + corrección manual. "
                + "No calcula automáticamente un geoide EGM ni modifica el registro GNSS original. "
                + "Utiliza solo valores comprobados para tu zona y datum.", 11.7f, NativeUi.SUB);
        caveat.setPadding(0, dp(10), 0, 0);
        heightCard.addView(caveat);
        body.addView(heightCard);

        body.addView(section("03   HERRAMIENTA DE ZONA UTM"));
        LinearLayout zoneCard = card();
        zoneCard.addView(line("Longitud → zona UTM (1–60)", 14.5f, NativeUi.TEXT));
        zoneCard.addView(line("Calcula la zona nominal de 6° y el meridiano central.",
                11.7f, NativeUi.SUB));
        Button zone = button("⌖  CALCULAR ZONA UTM", false);
        zone.setOnClickListener(v -> zoneTool());
        zoneCard.addView(zone);
        body.addView(zoneCard);

        Button save = button("✓  GUARDAR AJUSTES GPS", true);
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        saveLp.topMargin = dp(21);
        body.addView(save, saveLp);
        save.setOnClickListener(v -> {
            try {
                double d = Double.parseDouble(offset.getText().toString().trim().replace(',', '.'));
                if (Double.isNaN(d) || Double.isInfinite(d) || Math.abs(d) > 300)
                    throw new IllegalArgumentException("Comprueba el desplazamiento: máximo ±300 m para este ajuste manual.");
                sp.edit().putInt(FORMAT, formats.getSelectedItemPosition())
                        .putLong(HEIGHT_OFFSET, Double.doubleToLongBits(d)).apply();
                Toast.makeText(this, "Ajustes guardados.", Toast.LENGTH_SHORT).show();
                finish();
            } catch (Exception ex) {
                new AlertDialog.Builder(this).setTitle("Revisa la corrección")
                        .setMessage(ex.getMessage() == null ? "Introduce un número válido." : ex.getMessage())
                        .setPositiveButton("Entendido", null).show();
            }
        });
        page.addView(NativeUi.scroll(this, body),
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        root.addView(page, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
    }

    private int dp(int n) { return NativeUi.dp(this, n); }

    private TextView line(String text, float size, int color) {
        TextView t = NativeUi.text(this, text, size, false, color);
        t.setLineSpacing(dp(2), 1.0f);
        return t;
    }

    private TextView section(String label) {
        TextView t = NativeUi.text(this, label, 12.1f, true, NativeUi.BLUE_LIGHT);
        t.setLetterSpacing(.065f);
        t.setPadding(dp(2), dp(21), 0, dp(9));
        return t;
    }

    private LinearLayout card() {
        LinearLayout card = NativeUi.column(this);
        card.setPadding(dp(14), dp(15), dp(14), dp(15));
        card.setBackground(NativeUi.gradient(Color.rgb(15, 48, 75), Color.rgb(6, 27, 49),
                16, NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 120), this));
        return card;
    }

    private Button button(String text, boolean primary) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setMinHeight(dp(49));
        ResponsiveUi.configureCompactText(b, 13.5f, 11, 2);
        b.setBackground(NativeUi.gradient(primary ? Color.rgb(15, 117, 90) : Color.rgb(25, 88, 141),
                primary ? Color.rgb(7, 61, 61) : Color.rgb(10, 44, 78), 12,
                NativeUi.withAlpha(primary ? MINT : NativeUi.BLUE_LIGHT, 160), this));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(11);
        b.setLayoutParams(lp);
        return b;
    }

    private Spinner selector(String[] choices) {
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, choices) {
            @Override public View getView(int index, View convert, ViewGroup parent) {
                TextView t = (TextView) super.getView(index, convert, parent);
                t.setTextColor(Color.WHITE);
                t.setTextSize(14);
                t.setPadding(dp(9), dp(12), dp(9), dp(12));
                return t;
            }
            @Override public View getDropDownView(int index, View convert, ViewGroup parent) {
                TextView t = (TextView) super.getDropDownView(index, convert, parent);
                t.setTextColor(Color.WHITE);
                t.setBackgroundColor(Color.rgb(12, 37, 61));
                t.setPadding(dp(12), dp(13), dp(12), dp(13));
                return t;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setBackground(NativeUi.rounded(Color.rgb(10, 32, 53), 11, 1,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 110), this));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        spinner.setLayoutParams(lp);
        return spinner;
    }

    private void zoneTool() {
        EditText longitude = new EditText(this);
        longitude.setHint("Longitud, ej.: -71.42");
        longitude.setTextColor(Color.BLACK);
        longitude.setInputType(android.text.InputType.TYPE_CLASS_NUMBER
                | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                | android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
        new AlertDialog.Builder(this).setTitle("Longitud → zona UTM")
                .setMessage("Introduce longitud entre -180° y 180°. En Noruega/Svalbard "
                        + "hay excepciones según la latitud.")
                .setView(longitude)
                .setPositiveButton("Calcular", (d, w) -> {
                    try {
                        double lon = Double.parseDouble(longitude.getText().toString().trim().replace(',', '.'));
                        if (Double.isNaN(lon) || Double.isInfinite(lon) || lon < -180 || lon > 180)
                            throw new IllegalArgumentException();
                        int z = lon == 180 ? 60 : (int) Math.floor((lon + 180) / 6) + 1;
                        double central = z * 6 - 183;
                        new AlertDialog.Builder(this).setTitle("Zona UTM " + z)
                                .setMessage(String.format(Locale.US,
                                        "Meridiano central: %.0f°\nLímites nominales: %.0f° a %.0f°\n\nLa banda latitudinal y el hemisferio dependen de la latitud.",
                                        central, central - 3, central + 3))
                                .setPositiveButton("Cerrar", null).show();
                    } catch (Exception ex) {
                        Toast.makeText(this, "Longitud inválida (−180 a 180).", Toast.LENGTH_LONG).show();
                    }
                }).setNegativeButton("Cancelar", null).show();
    }

    static String latLon(double x, boolean latitude, int format) {
        if (Double.isNaN(x) || Double.isInfinite(x)) return "Sin lectura";
        String axis = latitude ? (x < 0 ? "S" : "N") : (x < 0 ? "O" : "E");
        if (format == 0) return String.format(Locale.US, "%.6f°", x);
        double val = Math.abs(x);
        int deg = (int) Math.floor(val);
        double minutes = (val - deg) * 60;
        if (format == 1) return String.format(Locale.US, "%d° %.4f′ %s", deg, minutes, axis);
        int min = (int) Math.floor(minutes);
        double seconds = (minutes - min) * 60;
        if (seconds >= 59.995) {
            seconds = 0;
            min++;
            if (min >= 60) { min = 0; deg++; }
        }
        return String.format(Locale.US, "%d° %02d′ %05.2f″ %s", deg, min, seconds, axis);
    }

    @Override public void onContentChanged() {
        super.onContentChanged();
        NativeUi.applySystemBarInsets(this);
    }
}
