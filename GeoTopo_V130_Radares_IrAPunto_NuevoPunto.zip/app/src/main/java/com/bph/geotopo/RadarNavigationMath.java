package com.bph.geotopo;

/** Cálculos puros del radar: no necesita red, Android ni sensor para probar límites. */
public final class RadarNavigationMath {
    private RadarNavigationMath() { }
    private static final float[] RANGES_METERS = {
            25, 50, 100, 250, 500, 1000, 2000, 5000, 10000, 25000, 50000, 100000
    };

    public static double wrap(double degrees) {
        if (!Double.isFinite(degrees)) return Double.NaN;
        double result = degrees % 360d;
        if (result < 0) result += 360d;
        return result == 360d ? 0d : result;
    }

    /** Giro menor hacia el objetivo desde el frente del teléfono, positivo a la derecha. */
    public static double relativeAngle(double bearing, double heading) {
        if (!Double.isFinite(bearing) || !Double.isFinite(heading)) return Double.NaN;
        double result = wrap(bearing - heading + 180d) - 180d;
        return result == -180d ? 180d : result;
    }

    public static float autoRange(double meters) {
        if (!Double.isFinite(meters) || meters < 0) return 100f;
        for (float range : RANGES_METERS) if (meters <= range) return range;
        return RANGES_METERS[RANGES_METERS.length - 1];
    }

    public static float manualRange(float current, boolean zoomIn) {
        int index = 0;
        while (index < RANGES_METERS.length - 1 && RANGES_METERS[index] < current) index++;
        index = Math.max(0, Math.min(RANGES_METERS.length - 1, index + (zoomIn ? -1 : 1)));
        return RANGES_METERS[index];
    }

    public static boolean withinAccuracy(double meters, double reportedAccuracy) {
        return Double.isFinite(meters) && meters >= 0 && Double.isFinite(reportedAccuracy)
                && reportedAccuracy > 0 && meters <= Math.max(3, reportedAccuracy);
    }
}
