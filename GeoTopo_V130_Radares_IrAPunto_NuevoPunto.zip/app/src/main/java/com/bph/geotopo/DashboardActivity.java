package com.bph.geotopo;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import java.util.Locale;

/** V128: Inicio con el nuevo diseño; mismas herramientas y mismo orden que V126. */
public class DashboardActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NativeUi.styleWindow(this);
        setContentView(buildScreen());
    }

    private View buildScreen() {
        FrameLayout root = NativeUi.screen(this);
        LinearLayout content = NativeUi.column(this);
        content.setPadding(NativeUi.dp(this, 16), 0, NativeUi.dp(this, 16), NativeUi.dp(this, 20));

        content.addView(DesignUi.homeHeader(this, v -> openSettings()));
        View fieldStatus = buildFieldStatus();
        if (fieldStatus != null) content.addView(fieldStatus);

        content.addView(DesignUi.twoColumns(this,
                DesignUi.heroCard(this, "gps", "GPS y mapas", "Posición, mapas y datos GNSS",
                        v -> open(GpsOverviewActivity.class)),
                DesignUi.heroCard(this, "field", "Herramientas de campo", "Instrumentos y utilidades de campo",
                        v -> open(FieldToolsActivity.class))));

        content.addView(DesignUi.sectionHeader(this, null, "ACCESO RÁPIDO"));
        content.addView(DesignUi.twoColumns(this,
                DesignUi.quickCard(this, "converter", "Conversor de unidades", "Longitud, área, ángulos y más",
                        v -> open(ConverterActivity.class)),
                DesignUi.quickCard(this, "compass", "Orientación y brújula", "Rumbos, norte y dirección",
                        v -> openTool("compass"))));
        content.addView(DesignUi.twoColumns(this,
                DesignUi.quickCard(this, "azimuth", "Azimut y rumbo", "Cálculos y conversiones",
                        v -> openTool("azimuth")),
                DesignUi.quickCard(this, "coordinates", "Coordenadas parciales", "Cálculos, offsets e intersecciones",
                        v -> openTool("coordinates"))));
        content.addView(DesignUi.twoColumns(this,
                DesignUi.quickCard(this, "distance", "Distancia y pendiente", "Distancia inclinada, horizontal y desnivel",
                        v -> openTool("distance")),
                DesignUi.quickCard(this, "two_hair", "Distancia por dos hilos", "Lecturas taquimétricas y cálculo de distancias",
                        v -> openTool("two_hair"))));

        content.addView(DesignUi.sectionHeader(this, null, "CÁLCULOS"));
        content.addView(DesignUi.full(this, DesignUi.wideCard(this, "polygon", true, "Poligonal cerrada",
                "Área, perímetro, cierres y compensación", v -> openTool("polygon"))));

        content.addView(DesignUi.sectionHeader(this, null, "NIVELACIÓN"));
        content.addView(DesignUi.twoColumns(this,
                DesignUi.stackCard(this, "level", "Nivelación", "Vista atrás, intermedia, adelante y ajuste",
                        v -> openTool("level")),
                DesignUi.stackCard(this, "stadia", "Nivelación con tres hilos", "Lectura con tres hilos",
                        v -> openTool("stadia"))));

        LinearLayout page = NativeUi.column(this);
        ScrollView scroll = NativeUi.scroll(this, content);
        scroll.setVerticalScrollBarEnabled(false);
        page.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        page.addView(DesignUi.bottomNav(this, 0,
                null,
                this::openPoints,
                () -> open(NotebookActivity.class),
                this::openSettings));
        root.addView(page, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return root;
    }

    /** Compact real GPS summary in the home screen; never displays mock coordinates. */
    private View buildFieldStatus() {
        SharedPreferences data = getSharedPreferences("geo_topo_gps_points", MODE_PRIVATE);
        boolean valid = false;
        double lat = 0, lon = 0;
        try {
            String storedLat = data.getString("last_latitude", "");
            String storedLon = data.getString("last_longitude", "");
            if (storedLat != null && storedLon != null) {
                lat = Double.parseDouble(storedLat);
                lon = Double.parseDouble(storedLon);
                valid = !Double.isNaN(lat) && !Double.isInfinite(lat)
                        && !Double.isNaN(lon) && !Double.isInfinite(lon)
                        && Math.abs(lat) <= 90 && Math.abs(lon) <= 180;
            }
        } catch (Exception ignored) { }
        if (!valid) return null; // No banner de error al abrir Inicio sin haber usado GPS.
        int points = 0;
        try {
            points = new JSONArray(data.getString("points_json", "[]")).length();
        } catch (Exception ignored) { }
        long when = data.getLong("last_location_time", 0L);
        long age = System.currentTimeMillis() - when;
        String state = !valid ? "GPS sin iniciar"
                : age < 0 ? "Posición guardada"
                : age < 60000 ? "Última lectura · <1 min"
                : age < 3600000 ? "Última lectura · " + age / 60000 + " min"
                : "Última posición guardada";
        String location = valid ? String.format(Locale.US, "UTM %s  ·  WGS84",
                CoordinateUtils.zoneWithBand(lat, lon)) : "Abre GPS y mapas para comenzar a registrar";
        LinearLayout panel = NativeUi.row(this);
        panel.setPadding(NativeUi.dp(this, 12), NativeUi.dp(this, 10),
                NativeUi.dp(this, 11), NativeUi.dp(this, 10));
        panel.setBackground(NativeUi.gradient(Color.rgb(15, 49, 75), Color.rgb(7, 29, 49),
                13, NativeUi.withAlpha(valid ? Color.rgb(93, 205, 192) : Color.rgb(83, 150, 226), 110), this));
        LinearLayout labels = NativeUi.column(this);
        labels.addView(NativeUi.text(this, "●  " + state, 12.1f, true,
                valid ? Color.rgb(103, 237, 187) : Color.rgb(144, 195, 255)));
        TextView details = NativeUi.text(this, location, 10.8f, false, NativeUi.SUB);
        details.setPadding(0, NativeUi.dp(this, 3), 0, 0);
        labels.addView(details);
        panel.addView(labels, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView pointsView = NativeUi.text(this, points + " puntos  ›", 11.2f, true, NativeUi.BLUE_LIGHT);
        pointsView.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        panel.addView(pointsView);
        panel.setOnClickListener(v -> open(GpsOverviewActivity.class));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, NativeUi.dp(this, 5), 0, NativeUi.dp(this, 8));
        panel.setLayoutParams(lp);
        return panel;
    }

    private void open(Class<?> target) {
        startActivity(new Intent(this, target));
    }

    private void openTool(String key) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("single_tool", key);
        startActivity(intent);
    }

    private void openPoints() {
        Intent intent = new Intent(this, GpsOverviewActivity.class);
        intent.putExtra("gps_tools_action", "points");
        startActivity(intent);
    }

    private void openSettings() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("show_settings", true);
        intent.putExtra("settings_only", true);
        startActivity(intent);
    }

    @Override public void onContentChanged() {
        super.onContentChanged();
        NativeUi.applySystemBarInsets(this);
    }
}
