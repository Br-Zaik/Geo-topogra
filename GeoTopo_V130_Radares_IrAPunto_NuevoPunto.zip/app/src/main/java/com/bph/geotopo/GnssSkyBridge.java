package com.bph.geotopo;

import android.location.LocationManager;
import java.util.List;

/** Satellite geometry bridge; implementation for Android 7+ is loaded conditionally. */
interface GnssSkyBridge {
    final class Satellite {
        float azimuth, elevation, cn0;
        boolean used;
        String prefix;
        int svid;
    }
    interface Sink { void onSatellites(List<Satellite> satellites); }
    void start(LocationManager manager);
    void stop(LocationManager manager);
}
