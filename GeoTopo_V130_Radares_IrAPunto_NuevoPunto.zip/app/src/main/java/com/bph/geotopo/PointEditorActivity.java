package com.bph.geotopo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * V130: crear / editar punto, rediseñado desde cero con funciones al estilo Handy GPS:
 * formatos Grados · G M S · G M · UTM, "Usar mi posición GPS", símbolos rápidos y nombre automático.
 */
public class PointEditorActivity extends Activity implements LocationListener {
    private static final String PREFS = "geo_topo_gps_points";
    private static final int PICK_IMAGE = 6801;
    private static final int REQ_LOC = 6802;
    private static final int MODE_DEG = 0, MODE_DMS = 1, MODE_DM = 2, MODE_UTM = 3;
    private static final String[] SYMBOLS = {"●", "◆", "▲", "⚑", "■", "★"};
    private static final String[] SYMBOL_NAMES = {"Punto", "Vértice", "Cumbre", "Estación", "Referencia", "Importante"};
    private static final int EDGE = Color.argb(120, 88, 148, 214);
    private static final int MINT = Color.rgb(74, 231, 176);

    private EditText project, name, description, first, second, zone, altitude;
    private TextView firstLabel, secondLabel, photoLabel, gpsStatus, preview;
    private LinearLayout utmBox;
    private final List<TextView> modeChips = new ArrayList<>();
    private final List<TextView> symbolChips = new ArrayList<>();
    private final List<TextView> hemiChips = new ArrayList<>();
    private int mode = MODE_DEG, symbolIndex = 0;
    private boolean south = true;
    private int editIndex = -1;
    private JSONObject original;
    private String photoUri = "";
    private double lastLat = Double.NaN, lastLon = Double.NaN;

    private LocationManager manager;
    private Location live;
    private boolean waitingFill;
    private double filledLat = Double.NaN, filledLon = Double.NaN;
    private float filledAccuracy = Float.NaN;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NativeUi.styleWindow(this);
        manager = (LocationManager) getSystemService(LOCATION_SERVICE);
        editIndex = getIntent().getIntExtra("edit_index", -1);
        JSONArray all = points();
        original = editIndex >= 0 && editIndex < all.length() ? all.optJSONObject(editIndex) : null;
        if (original != null) {
            photoUri = original.optString("photoUri", "");
            lastLat = original.optDouble("latitude", Double.NaN);
            lastLon = original.optDouble("longitude", Double.NaN);
            for (int i = 0; i < SYMBOLS.length; i++) if (SYMBOLS[i].equals(original.optString("symbol", "●"))) symbolIndex = i;
        } else if (getIntent().hasExtra("prefill_lat") && getIntent().hasExtra("prefill_lon")) {
            double la = getIntent().getDoubleExtra("prefill_lat", Double.NaN);
            double lo = getIntent().getDoubleExtra("prefill_lon", Double.NaN);
            if (valid(la, lo)) { lastLat = la; lastLon = lo; }
        }
        mode = getSharedPreferences(PREFS, MODE_PRIVATE).getInt("editor_coordinate_mode", MODE_DEG);
        if (mode < 0 || mode > 3) mode = MODE_DEG;

        FrameLayout root = NativeUi.screen(this);
        LinearLayout page = NativeUi.column(this);
        page.addView(NativeUi.pageHeader(this, original == null ? "Nuevo punto" : "Editar punto",
                "WGS84 · Grados, GMS, GM o UTM", v -> finish(), "⌖", v -> previewOnMap()));
        LinearLayout body = NativeUi.column(this);
        body.setPadding(dp(14), dp(6), dp(14), dp(20));

        // ---- Posición actual (como "New waypoint" de Handy GPS)
        body.addView(DesignUi.sectionHeader(this, "target", "POSICIÓN ACTUAL"));
        LinearLayout gpsCard = card();
        gpsStatus = NativeUi.text(this, "GPS en espera", 12.5f, false, NativeUi.SUB);
        gpsCard.addView(gpsStatus);
        TextView useGps = bigButton("◉  Usar mi posición GPS", Color.rgb(18, 120, 92), Color.rgb(8, 70, 62), MINT);
        useGps.setOnClickListener(v -> useCurrentPosition());
        LinearLayout.LayoutParams ug = full();
        ug.topMargin = dp(10);
        gpsCard.addView(useGps, ug);
        body.addView(gpsCard, full());

        // ---- Punto
        body.addView(DesignUi.sectionHeader(this, "pin", "PUNTO"));
        LinearLayout pointCard = card();
        pointCard.addView(caption("Nombre"));
        name = field("Ej.: P1", original == null ? nextName(all) : original.optString("name", ""));
        pointCard.addView(name);
        pointCard.addView(caption("Proyecto"));
        project = field("Proyecto", original == null ? getSharedPreferences(PREFS, MODE_PRIVATE)
                .getString("current_project", "Proyecto general") : original.optString("project", "Proyecto general"));
        pointCard.addView(project);
        pointCard.addView(caption("Descripción"));
        description = field("Referencia de campo (opcional)", original == null ? "" : original.optString("description", ""));
        description.setSingleLine(false);
        description.setMinLines(2);
        description.setGravity(Gravity.TOP | Gravity.START);
        pointCard.addView(description);
        pointCard.addView(caption("Símbolo"));
        LinearLayout symbols = NativeUi.row(this);
        for (int i = 0; i < SYMBOLS.length; i++) {
            final int idx = i;
            TextView chip = chip(SYMBOLS[i], 18f);
            chip.setContentDescription(SYMBOL_NAMES[i]);
            chip.setOnClickListener(v -> { symbolIndex = idx; paintChips(symbolChips, symbolIndex); });
            symbolChips.add(chip);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1f);
            lp.setMargins(i == 0 ? 0 : dp(3), 0, i == SYMBOLS.length - 1 ? 0 : dp(3), 0);
            symbols.addView(chip, lp);
        }
        pointCard.addView(symbols);
        paintChips(symbolChips, symbolIndex);
        body.addView(pointCard, full());

        // ---- Coordenadas
        body.addView(DesignUi.sectionHeader(this, "map", "COORDENADAS"));
        LinearLayout coordCard = card();
        LinearLayout modes = NativeUi.row(this);
        String[] modeNames = {"Grados", "G M S", "G M", "UTM"};
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            TextView chip = chip(modeNames[i], 13f);
            chip.setOnClickListener(v -> switchMode(idx));
            modeChips.add(chip);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(40), 1f);
            lp.setMargins(i == 0 ? 0 : dp(3), 0, i == 3 ? 0 : dp(3), 0);
            modes.addView(chip, lp);
        }
        coordCard.addView(modes);
        firstLabel = caption("Latitud");
        coordCard.addView(firstLabel);
        first = field("", "");
        coordCard.addView(first);
        secondLabel = caption("Longitud");
        coordCard.addView(secondLabel);
        second = field("", "");
        coordCard.addView(second);
        utmBox = NativeUi.column(this);
        utmBox.addView(caption("Zona UTM y hemisferio"));
        LinearLayout zr = NativeUi.row(this);
        zone = field("Zona 1–60", "19");
        zone.setInputType(InputType.TYPE_CLASS_NUMBER);
        LinearLayout.LayoutParams zlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        zlp.rightMargin = dp(6);
        zr.addView(zone, zlp);
        String[] hemi = {"Sur (S)", "Norte (N)"};
        for (int i = 0; i < 2; i++) {
            final int idx = i;
            TextView chip = chip(hemi[i], 13f);
            chip.setOnClickListener(v -> { south = idx == 0; paintChips(hemiChips, south ? 0 : 1); });
            hemiChips.add(chip);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1f);
            lp.leftMargin = dp(3);
            zr.addView(chip, lp);
        }
        utmBox.addView(zr);
        coordCard.addView(utmBox);
        preview = NativeUi.text(this, "", 11.5f, false, NativeUi.SUB);
        preview.setPadding(dp(2), dp(10), dp(2), 0);
        coordCard.addView(preview);
        body.addView(coordCard, full());

        // ---- Altitud y foto
        body.addView(DesignUi.sectionHeader(this, null, "ALTITUD Y FOTO"));
        LinearLayout extraCard = card();
        extraCard.addView(caption("Altitud (m, opcional)"));
        altitude = field("Ej.: 3825.4", original == null || original.isNull("altitude") ? ""
                : fmt(original.optDouble("altitude", Double.NaN), 3));
        altitude.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        extraCard.addView(altitude);
        TextView photo = bigButton("📷  Adjuntar / cambiar foto", Color.rgb(23, 62, 100), Color.rgb(10, 33, 60), DesignUi.ACCENT_LIGHT);
        photo.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, PICK_IMAGE);
        });
        LinearLayout.LayoutParams plp = full();
        plp.topMargin = dp(10);
        extraCard.addView(photo, plp);
        photoLabel = NativeUi.text(this, photoUri.isEmpty() ? "Sin foto adjunta" : "Foto adjunta al punto", 11.5f, false, NativeUi.SUB);
        photoLabel.setPadding(dp(2), dp(6), 0, 0);
        extraCard.addView(photoLabel);
        body.addView(extraCard, full());

        ScrollView scroll = NativeUi.scroll(this, body);
        page.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // ---- Acciones fijas abajo
        LinearLayout actions = NativeUi.row(this);
        actions.setPadding(dp(14), dp(10), dp(14), dp(10));
        actions.setBackgroundColor(DesignUi.NAV_BG);
        TextView map = bigButton("⌖  Ver en mapa", Color.rgb(24, 90, 150), Color.rgb(10, 50, 96), DesignUi.ACCENT_LIGHT);
        map.setOnClickListener(v -> previewOnMap());
        TextView save = bigButton(original == null ? "✓  Guardar punto" : "✓  Guardar cambios",
                Color.rgb(20, 130, 96), Color.rgb(8, 72, 64), MINT);
        save.setOnClickListener(v -> save());
        LinearLayout.LayoutParams a1 = new LinearLayout.LayoutParams(0, dp(50), 1f);
        a1.rightMargin = dp(5);
        LinearLayout.LayoutParams a2 = new LinearLayout.LayoutParams(0, dp(50), 1.3f);
        a2.leftMargin = dp(5);
        actions.addView(map, a1);
        actions.addView(save, a2);
        page.addView(actions);

        root.addView(page, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        if (valid(lastLat, lastLon)) {
            CoordinateUtils.Utm u = CoordinateUtils.toUtm(lastLat, lastLon);
            if (u.valid) { zone.setText(String.valueOf(u.zone)); south = u.south; }
        }
        paintChips(hemiChips, south ? 0 : 1);
        applyMode(mode);
        writeFields();
    }

    // ------------------------------------------------------------------ UI helpers
    private int dp(int v) { return NativeUi.dp(this, v); }

    private LinearLayout.LayoutParams full() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        return lp;
    }

    private LinearLayout card() {
        LinearLayout c = NativeUi.column(this);
        c.setPadding(dp(13), dp(12), dp(13), dp(14));
        c.setBackground(NativeUi.gradient(DesignUi.CARD_TOP, DesignUi.CARD_BOTTOM, 18, EDGE, this));
        return c;
    }

    private TextView caption(String text) {
        TextView v = NativeUi.text(this, text, 11.5f, true, NativeUi.SUB);
        v.setPadding(dp(2), dp(10), 0, dp(4));
        return v;
    }

    private EditText field(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.rgb(120, 150, 176));
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setMinHeight(dp(48));
        e.setBackground(NativeUi.rounded(Color.rgb(8, 26, 46), 12, 1, Color.argb(130, 92, 159, 255), this));
        e.setLayoutParams(full());
        return e;
    }

    private TextView chip(String label, float sp) {
        TextView v = NativeUi.text(this, label, sp, true, Color.WHITE);
        v.setGravity(Gravity.CENTER);
        v.setSingleLine(true);
        return v;
    }

    private void paintChips(List<TextView> chips, int selected) {
        for (int i = 0; i < chips.size(); i++) {
            boolean on = i == selected;
            TextView c = chips.get(i);
            c.setTextColor(on ? Color.WHITE : NativeUi.SUB);
            c.setBackground(on
                    ? NativeUi.gradient(Color.rgb(40, 120, 235), Color.rgb(22, 78, 180), 12, Color.argb(200, 150, 205, 255), this)
                    : NativeUi.rounded(Color.rgb(8, 26, 46), 12, 1, EDGE, this));
        }
    }

    private TextView bigButton(String label, int start, int end, int stroke) {
        TextView v = NativeUi.text(this, label, 14.5f, true, Color.WHITE);
        v.setGravity(Gravity.CENTER);
        v.setMinHeight(dp(50));
        v.setPadding(dp(8), 0, dp(8), 0);
        v.setBackground(NativeUi.gradient(start, end, 14, NativeUi.withAlpha(stroke, 170), this));
        return v;
    }

    // ------------------------------------------------------------------ Formatos
    private void switchMode(int next) {
        if (next == mode) return;
        try { double[] c = readFields(); lastLat = c[0]; lastLon = c[1]; } catch (Exception ignored) { }
        applyMode(next);
        writeFields();
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt("editor_coordinate_mode", next).apply();
    }

    private void applyMode(int m) {
        mode = m;
        paintChips(modeChips, mode);
        boolean utm = mode == MODE_UTM;
        utmBox.setVisibility(utm ? View.VISIBLE : View.GONE);
        int numeric = InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED;
        int text = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS;
        first.setInputType(mode == MODE_DMS || mode == MODE_DM ? text : numeric);
        second.setInputType(mode == MODE_DMS || mode == MODE_DM ? text : numeric);
        switch (mode) {
            case MODE_DMS:
                firstLabel.setText("Latitud  (grados minutos segundos + N/S)");
                secondLabel.setText("Longitud  (grados minutos segundos + E/O)");
                first.setHint("Ej.: 14 47 18.04 S");
                second.setHint("Ej.: 71 24 58.59 O");
                break;
            case MODE_DM:
                firstLabel.setText("Latitud  (grados minutos + N/S)");
                secondLabel.setText("Longitud  (grados minutos + E/O)");
                first.setHint("Ej.: 14 47.3007 S");
                second.setHint("Ej.: 71 24.9765 O");
                break;
            case MODE_UTM:
                firstLabel.setText("Este (m)");
                secondLabel.setText("Norte (m)");
                first.setHint("Ej.: 240514.000");
                second.setHint("Ej.: 8363678.000");
                break;
            default:
                firstLabel.setText("Latitud  (− Sur / + Norte)");
                secondLabel.setText("Longitud  (− Oeste / + Este)");
                first.setHint("Ej.: -14.788344");
                second.setHint("Ej.: -71.416275");
        }
    }

    private void writeFields() {
        if (!valid(lastLat, lastLon)) {
            first.setText("");
            second.setText("");
            preview.setText("Escribe las coordenadas o toca «Usar mi posición GPS».");
            return;
        }
        switch (mode) {
            case MODE_DMS: first.setText(dms(lastLat, true)); second.setText(dms(lastLon, false)); break;
            case MODE_DM: first.setText(dm(lastLat, true)); second.setText(dm(lastLon, false)); break;
            case MODE_UTM: {
                CoordinateUtils.Utm u = CoordinateUtils.toUtm(lastLat, lastLon);
                if (u.valid) {
                    first.setText(fmt(u.easting, 3));
                    second.setText(fmt(u.northing, 3));
                    zone.setText(String.valueOf(u.zone));
                    south = u.south;
                    paintChips(hemiChips, south ? 0 : 1);
                }
                break;
            }
            default: first.setText(fmt(lastLat, 8)); second.setText(fmt(lastLon, 8));
        }
        updatePreview();
    }

    private void updatePreview() {
        if (!valid(lastLat, lastLon)) return;
        CoordinateUtils.Utm u = CoordinateUtils.toUtm(lastLat, lastLon);
        preview.setText(String.format(Locale.US, "%.6f°, %.6f°%s", lastLat, lastLon,
                u.valid ? String.format(Locale.US, "\nUTM %s  E %.3f  N %.3f",
                        CoordinateUtils.zoneWithBand(lastLat, lastLon), u.easting, u.northing) : ""));
    }

    private double[] readFields() {
        String a = first.getText().toString().trim(), b = second.getText().toString().trim();
        if (a.isEmpty() || b.isEmpty()) throw new IllegalArgumentException("Escribe los dos valores de la coordenada.");
        double lat, lon;
        if (mode == MODE_UTM) {
            double e = number(a), n = number(b);
            int z;
            try { z = Integer.parseInt(zone.getText().toString().trim()); }
            catch (Exception ex) { throw new IllegalArgumentException("Escribe la zona UTM (1 a 60)."); }
            if (z < 1 || z > 60) throw new IllegalArgumentException("La zona UTM debe estar entre 1 y 60.");
            CoordinateUtils.LatLon c = CoordinateUtils.fromUtm(e, n, z, south);
            if (!c.valid || c.latitude < -80 || c.latitude > 84 || (south && c.latitude > 0.000001)
                    || (!south && c.latitude < -0.000001))
                throw new IllegalArgumentException("UTM inválida: comprueba zona, Este, Norte y hemisferio.");
            lat = c.latitude; lon = c.longitude;
        } else if (mode == MODE_DEG) {
            lat = number(a); lon = number(b);
        } else {
            lat = parseAngle(a, true); lon = parseAngle(b, false);
        }
        if (!valid(lat, lon)) throw new IllegalArgumentException("Latitud entre −90 y 90, longitud entre −180 y 180.");
        return new double[]{lat, lon};
    }

    private static double number(String s) {
        double v = Double.parseDouble(s.replace(" ", "").replace(',', '.'));
        if (!Double.isFinite(v)) throw new NumberFormatException();
        return v;
    }

    private static final Pattern NUM = Pattern.compile("[0-9]+(?:[.,][0-9]+)?");

    /** Acepta "14 47 18.04 S", "14°47'18.04\"S", "-14 47.3", "S 14 47 18". */
    static double parseAngle(String raw, boolean latitude) {
        String s = raw.toUpperCase(Locale.US).trim();
        boolean negative = s.startsWith("-");
        if (latitude) {
            if (s.contains("S")) negative = true;
            else if (s.contains("N")) negative = false;
        } else {
            if (s.contains("W") || s.contains("O")) negative = true;
            else if (s.contains("E")) negative = false;
        }
        Matcher m = NUM.matcher(s);
        List<Double> parts = new ArrayList<>();
        while (m.find() && parts.size() < 3) parts.add(Double.parseDouble(m.group().replace(',', '.')));
        if (parts.isEmpty()) throw new IllegalArgumentException("Coordenada vacía o mal escrita: " + raw);
        double deg = parts.get(0), min = parts.size() > 1 ? parts.get(1) : 0, sec = parts.size() > 2 ? parts.get(2) : 0;
        if (min >= 60 || sec >= 60) throw new IllegalArgumentException("Minutos y segundos deben ser menores que 60.");
        double v = deg + min / 60.0 + sec / 3600.0;
        if (v > (latitude ? 90 : 180)) throw new IllegalArgumentException((latitude ? "Latitud" : "Longitud") + " fuera de rango.");
        return negative ? -v : v;
    }

    static String dms(double value, boolean latitude) {
        String h = latitude ? (value < 0 ? "S" : "N") : (value < 0 ? "O" : "E");
        double a = Math.abs(value);
        int d = (int) Math.floor(a);
        double mm = (a - d) * 60;
        int m = (int) Math.floor(mm);
        double s = (mm - m) * 60;
        if (Math.round(s * 100) >= 6000) { s = 0; m++; }
        if (m >= 60) { m = 0; d++; }
        return String.format(Locale.US, "%d° %02d' %05.2f\" %s", d, m, s, h);
    }

    static String dm(double value, boolean latitude) {
        String h = latitude ? (value < 0 ? "S" : "N") : (value < 0 ? "O" : "E");
        double a = Math.abs(value);
        int d = (int) Math.floor(a);
        double m = (a - d) * 60;
        if (Math.round(m * 10000) >= 600000) { m = 0; d++; }
        return String.format(Locale.US, "%d° %07.4f' %s", d, m, h);
    }

    private static String fmt(double v, int decimals) {
        if (!Double.isFinite(v)) return "";
        return String.format(Locale.US, "%." + decimals + "f", v).replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    private static boolean valid(double lat, double lon) {
        return Double.isFinite(lat) && Double.isFinite(lon) && Math.abs(lat) <= 90 && Math.abs(lon) <= 180;
    }

    // ------------------------------------------------------------------ GPS (usar posición actual)
    @Override protected void onResume() {
        super.onResume();
        startGps();
    }

    @Override protected void onPause() {
        stopGps();
        super.onPause();
    }

    private void startGps() {
        if (manager == null) { gpsStatus.setText("Servicio de ubicación no disponible"); return; }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            gpsStatus.setText("Permite la ubicación precisa para usar tu posición");
            return;
        }
        try {
            if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                gpsStatus.setText("Ubicación del teléfono apagada");
                return;
            }
            manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper());
            gpsStatus.setText("Buscando GPS… (sal al aire libre)");
        } catch (Exception e) {
            gpsStatus.setText("No se pudo iniciar el GPS");
        }
    }

    private void stopGps() {
        try { if (manager != null) manager.removeUpdates(this); } catch (Exception ignored) { }
    }

    @Override public void onLocationChanged(Location location) {
        if (location == null || !valid(location.getLatitude(), location.getLongitude())) return;
        live = new Location(location);
        String acc = location.hasAccuracy() ? String.format(Locale.US, "±%.1f m", location.getAccuracy()) : "sin precisión";
        gpsStatus.setText("● GPS con señal · " + acc + "\n" + dms(location.getLatitude(), true) + "   "
                + dms(location.getLongitude(), false));
        gpsStatus.setTextColor(MINT);
        if (waitingFill) { waitingFill = false; fillFrom(live); }
    }

    @Override public void onProviderEnabled(String provider) { startGps(); }
    @Override public void onProviderDisabled(String provider) {
        live = null;
        gpsStatus.setText("Ubicación del teléfono apagada");
        gpsStatus.setTextColor(NativeUi.SUB);
    }
    @Override public void onStatusChanged(String provider, int status, Bundle extras) { }

    private void useCurrentPosition() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOC);
            return;
        }
        if (live != null && Math.abs(System.currentTimeMillis() - live.getTime()) < 30000) {
            fillFrom(live);
            return;
        }
        waitingFill = true;
        Toast.makeText(this, "Esperando señal GPS… se llenará al obtener posición.", Toast.LENGTH_LONG).show();
        startGps();
    }

    private void fillFrom(Location l) {
        lastLat = l.getLatitude();
        lastLon = l.getLongitude();
        filledLat = lastLat;
        filledLon = lastLon;
        filledAccuracy = l.hasAccuracy() ? l.getAccuracy() : Float.NaN;
        if (l.hasAltitude()) altitude.setText(fmt(l.getAltitude(), 2));
        writeFields();
        Toast.makeText(this, "Posición GPS colocada", Toast.LENGTH_SHORT).show();
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_LOC && res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) {
            startGps();
            useCurrentPosition();
        }
    }

    // ------------------------------------------------------------------ Acciones
    private void previewOnMap() {
        try {
            double[] c = readFields();
            lastLat = c[0]; lastLon = c[1];
            updatePreview();
            Intent map = new Intent(this, MapActivity.class);
            map.putExtra("camera_lat", c[0]); map.putExtra("camera_lon", c[1]); map.putExtra("camera_zoom", 16d);
            map.putExtra("preview_manual_lat", c[0]); map.putExtra("preview_manual_lon", c[1]);
            startActivity(map);
        } catch (Exception e) {
            error("Revisa las coordenadas", e);
        }
    }

    private void save() {
        try {
            double[] c = readFields();
            String n = name.getText().toString().trim();
            if (n.isEmpty()) { name.setError("Escribe un nombre"); return; }
            String p = project.getText().toString().trim();
            if (p.isEmpty()) p = "Proyecto general";
            double alt = Double.NaN;
            if (!altitude.getText().toString().trim().isEmpty()) {
                alt = number(altitude.getText().toString().trim());
                if (alt < -12000 || alt > 12000) throw new IllegalArgumentException("Altitud fuera de rango.");
            }
            boolean fromGps = Double.isFinite(filledLat) && Math.abs(c[0] - filledLat) < 1e-7 && Math.abs(c[1] - filledLon) < 1e-7;
            JSONArray a = points();
            JSONObject o = original == null ? new JSONObject() : new JSONObject(original.toString());
            o.put("name", n); o.put("project", p); o.put("description", description.getText().toString().trim());
            o.put("latitude", c[0]); o.put("longitude", c[1]);
            o.put("altitude", Double.isFinite(alt) ? alt : JSONObject.NULL);
            o.put("symbol", SYMBOLS[symbolIndex]);
            o.put("photoUri", photoUri);
            o.put("timestamp", original == null ? System.currentTimeMillis() : original.optLong("timestamp", System.currentTimeMillis()));
            if (original == null) {
                o.put("provider", fromGps ? "gps" : "manual");
                o.put("accuracy", fromGps && Float.isFinite(filledAccuracy) ? (double) filledAccuracy : JSONObject.NULL);
                a.put(o);
            } else a.put(editIndex, o);
            boolean ok = getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("points_json", a.toString())
                    .putString("current_project", p).commit();
            if (!ok) throw new IllegalStateException("No se pudieron guardar los cambios en el dispositivo.");
            setResult(RESULT_OK);
            Toast.makeText(this, "Punto guardado: " + n, Toast.LENGTH_SHORT).show();
            finish();
        } catch (Exception e) {
            error("No se pudo guardar", e);
        }
    }

    private void error(String title, Exception e) {
        new AlertDialog.Builder(this).setTitle(title)
                .setMessage(e instanceof NumberFormatException ? "Revisa los números escritos." : e.getMessage())
                .setPositiveButton("Entendido", null).show();
    }

    private String nextName(JSONArray all) {
        int n = 1; boolean found;
        do {
            found = false;
            for (int i = 0; i < all.length(); i++) {
                JSONObject o = all.optJSONObject(i);
                if (o != null && ("P" + n).equalsIgnoreCase(o.optString("name"))) { found = true; break; }
            }
            if (found) n++;
        } while (found && n < 100000);
        return "P" + n;
    }

    private JSONArray points() {
        try { return new JSONArray(getSharedPreferences(PREFS, MODE_PRIVATE).getString("points_json", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_IMAGE && result == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
            photoUri = uri.toString();
            photoLabel.setText("Foto adjunta: " + uri.getLastPathSegment());
        }
    }

    @Override public void onContentChanged() { super.onContentChanged(); NativeUi.applySystemBarInsets(this); }
}
