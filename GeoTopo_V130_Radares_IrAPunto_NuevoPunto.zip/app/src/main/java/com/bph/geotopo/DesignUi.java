package com.bph.geotopo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * V127: componentes visuales del rediseño (Inicio y Herramientas de campo).
 * Todo se dibuja con Canvas: sin imágenes insertadas, escalable a cualquier pantalla.
 */
public final class DesignUi {
    private DesignUi() {}

    public static final int CARD_TOP = Color.rgb(14, 42, 72);
    public static final int CARD_BOTTOM = Color.rgb(6, 24, 45);
    public static final int STROKE = Color.argb(120, 88, 148, 214);
    public static final int ACCENT = Color.rgb(64, 148, 255);
    public static final int ACCENT_LIGHT = Color.rgb(120, 186, 255);
    public static final int TITLE = Color.rgb(246, 249, 253);
    public static final int SUBTITLE = Color.rgb(178, 199, 222);
    public static final int NAV_BG = Color.rgb(6, 20, 37);

    private static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    // ------------------------------------------------------------------ Cabeceras

    /** Inicio: "Cálculos topográficos" + botón de ajustes circular. */
    public static View homeHeader(Context c, View.OnClickListener settingsClick) {
        LinearLayout bar = NativeUi.row(c);
        bar.setPadding(dp(c, 6), dp(c, 16), dp(c, 2), dp(c, 12));
        LinearLayout labels = NativeUi.column(c);
        TextView title = NativeUi.text(c, "Cálculos topográficos", 26f, true, TITLE);
        ResponsiveUi.configureCompactText(title, 26f, 18, 1);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        TextView sub = NativeUi.text(c, "Herramientas para trabajo de campo", 13.5f, false, SUBTITLE);
        ResponsiveUi.configureCompactText(sub, 13.5f, 10, 1);
        sub.setSingleLine(true);
        sub.setPadding(0, dp(c, 2), 0, 0);
        labels.addView(title);
        labels.addView(sub);
        bar.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        FrameLayout gear = new FrameLayout(c);
        gear.setBackground(NativeUi.rounded(Color.argb(40, 43, 121, 255), 24, 1,
                Color.argb(170, 92, 159, 255), c));
        Glyph g = new Glyph(c, "gear", TITLE);
        FrameLayout.LayoutParams glp = new FrameLayout.LayoutParams(dp(c, 24), dp(c, 24), Gravity.CENTER);
        gear.addView(g, glp);
        gear.setContentDescription("Ajustes");
        gear.setOnClickListener(settingsClick);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(c, 48), dp(c, 48));
        lp.leftMargin = dp(c, 8);
        bar.addView(gear, lp);
        return bar;
    }

    /** Herramientas de campo: volver, título/subtítulo y altitud real (si existe). */
    public static View toolsHeader(Context c, View.OnClickListener backClick, String altitudeText) {
        LinearLayout bar = NativeUi.row(c);
        bar.setPadding(dp(c, 4), dp(c, 8), dp(c, 14), dp(c, 8));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.argb(245, 9, 34, 60), Color.argb(225, 5, 24, 44)});
        bar.setBackground(bg);

        FrameLayout back = new FrameLayout(c);
        back.addView(new Glyph(c, "back", TITLE), new FrameLayout.LayoutParams(
                dp(c, 22), dp(c, 22), Gravity.CENTER));
        back.setContentDescription("Volver");
        back.setOnClickListener(backClick);
        bar.addView(back, new LinearLayout.LayoutParams(dp(c, 44), dp(c, 52)));

        LinearLayout labels = NativeUi.column(c);
        TextView title = NativeUi.text(c, "Herramientas de campo", 21f, true, TITLE);
        ResponsiveUi.configureCompactText(title, 21f, 15, 1);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        TextView sub = NativeUi.text(c, "Trabajo de campo topográfico", 12.8f, false, SUBTITLE);
        ResponsiveUi.configureCompactText(sub, 12.8f, 10, 1);
        sub.setSingleLine(true);
        labels.addView(title);
        labels.addView(sub);
        bar.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        if (altitudeText != null) {
            LinearLayout alt = NativeUi.column(c);
            alt.setGravity(Gravity.CENTER_HORIZONTAL);
            alt.addView(new Glyph(c, "mountain", ACCENT_LIGHT),
                    new LinearLayout.LayoutParams(dp(c, 38), dp(c, 20)));
            TextView value = NativeUi.text(c, altitudeText, 11.5f, false, ACCENT_LIGHT);
            value.setGravity(Gravity.CENTER);
            value.setPadding(0, dp(c, 1), 0, dp(c, 2));
            alt.addView(value);
            View line = new View(c);
            line.setBackgroundColor(Color.argb(150, 92, 159, 255));
            alt.addView(line, new LinearLayout.LayoutParams(dp(c, 44), dp(c, 1)));
            alt.setContentDescription("Altitud " + altitudeText);
            bar.addView(alt);
        }
        return bar;
    }

    /** Título de sección en mayúsculas con icono opcional y línea divisoria. */
    public static View sectionHeader(Context c, String glyph, String titleValue) {
        LinearLayout row = NativeUi.row(c);
        row.setPadding(dp(c, 2), dp(c, 18), dp(c, 2), dp(c, 12));
        if (glyph != null) {
            Glyph g = new Glyph(c, glyph, ACCENT);
            LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(dp(c, 22), dp(c, 22));
            glp.rightMargin = dp(c, 12);
            row.addView(g, glp);
        }
        TextView title = NativeUi.text(c, titleValue, 15.5f, true, TITLE);
        ResponsiveUi.configureCompactText(title, 15.5f, 11, 1);
        title.setSingleLine(true);
        title.setLetterSpacing(0.07f);
        row.addView(title);
        View line = new View(c);
        line.setBackgroundColor(Color.argb(95, 88, 148, 214));
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(0, dp(c, 1), 1f);
        llp.leftMargin = dp(c, 16);
        llp.rightMargin = dp(c, 4);
        row.addView(line, llp);
        return row;
    }

    // ------------------------------------------------------------------ Navegación inferior

    /** Barra inferior: Inicio · Puntos · Proyectos · Ajustes. */
    public static View bottomNav(Context c, int active, Runnable home, Runnable points,
                                 Runnable projects, Runnable settings) {
        LinearLayout wrap = NativeUi.column(c);
        View top = new View(c);
        top.setBackgroundColor(Color.argb(90, 88, 148, 214));
        wrap.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 1)));
        LinearLayout row = NativeUi.row(c);
        row.setBackgroundColor(NAV_BG);
        row.setPadding(0, dp(c, 7), 0, dp(c, 4));
        String[] glyphs = {"home", "pin", "folder", "gear"};
        String[] names = {"Inicio", "Puntos", "Proyectos", "Ajustes"};
        Runnable[] actions = {home, points, projects, settings};
        for (int i = 0; i < 4; i++) {
            final Runnable action = actions[i];
            boolean on = i == active;
            int color = on ? ACCENT : Color.rgb(160, 180, 204);
            LinearLayout item = NativeUi.column(c);
            item.setGravity(Gravity.CENTER_HORIZONTAL);
            Glyph g = new Glyph(c, glyphs[i], color);
            g.setFilled(on);
            item.addView(g, new LinearLayout.LayoutParams(dp(c, 26), dp(c, 26)));
            TextView label = NativeUi.text(c, names[i], 12.5f, on, color);
            label.setGravity(Gravity.CENTER);
            label.setSingleLine(true);
            label.setPadding(0, dp(c, 3), 0, dp(c, 4));
            item.addView(label);
            View bar = new View(c);
            bar.setBackground(NativeUi.rounded(on ? ACCENT : Color.TRANSPARENT, 2, 0, Color.TRANSPARENT, c));
            item.addView(bar, new LinearLayout.LayoutParams(dp(c, 42), dp(c, 3)));
            item.setContentDescription(names[i]);
            if (action != null) item.setOnClickListener(v -> action.run());
            row.addView(item, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        wrap.addView(row);
        return wrap;
    }

    // ------------------------------------------------------------------ Tarjetas

    private static RatioFrame cardBase(Context c, float ratio, String art,
                                       float l, float t, float r, float b, boolean divider) {
        RatioFrame card = new RatioFrame(c, ratio);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{CARD_TOP, CARD_BOTTOM});
        bg.setCornerRadius(dp(c, 18));
        bg.setStroke(dp(c, 1), STROKE);
        card.setBackground(bg);
        card.setClipToOutline(true);
        card.setElevation(dp(c, 2));
        ArtView view = new ArtView(c, art, l, t, r, b, divider);
        card.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        // El borde se repite encima del dibujo para que siempre se vea nítido.
        View edge = new View(c);
        edge.setBackground(NativeUi.rounded(Color.TRANSPARENT, 18, 1, STROKE, c));
        card.addView(edge, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        return card;
    }

    private static LinearLayout textBlock(Context c, String titleValue, String subtitleValue,
                                          float titleSp, float subSp) {
        LinearLayout labels = NativeUi.column(c);
        TextView title = NativeUi.text(c, titleValue, titleSp, true, TITLE);
        ResponsiveUi.configureCompactText(title, titleSp, 11, 2);
        title.setMaxLines(2);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setLineSpacing(0, 0.98f);
        labels.addView(title);
        if (subtitleValue != null) {
            TextView sub = NativeUi.text(c, subtitleValue, subSp, false, SUBTITLE);
            ResponsiveUi.configureCompactText(sub, subSp, 9, 2);
            sub.setMaxLines(2);
            sub.setEllipsize(TextUtils.TruncateAt.END);
            sub.setLineSpacing(0, 1.04f);
            sub.setPadding(0, dp(c, 4), 0, 0);
            labels.addView(sub);
        }
        return labels;
    }

    private static View chevron(Context c) {
        return new Glyph(c, "chevron", TITLE);
    }

    /** Fila inferior: textos a la izquierda y flecha a la derecha. */
    private static View bottomTextRow(Context c, String titleValue, String subtitleValue,
                                      float titleSp, float subSp, int padH, int padB) {
        LinearLayout row = NativeUi.row(c);
        row.setPadding(dp(c, padH), 0, dp(c, padH - 4), dp(c, padB));
        row.addView(textBlock(c, titleValue, subtitleValue, titleSp, subSp),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(c, 22), dp(c, 22));
        alp.leftMargin = dp(c, 6);
        row.addView(chevron(c), alp);
        return row;
    }

    /** Tarjeta grande de Inicio (GPS y mapas / Herramientas de campo). */
    public static View heroCard(Context c, String art, String titleValue, String subtitleValue,
                                View.OnClickListener click) {
        RatioFrame card = cardBase(c, 0.76f, art, 0f, 0f, 1f, 0.62f, false);
        card.addView(bottomTextRow(c, titleValue, subtitleValue, 19.5f, 12.8f, 15, 16),
                new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));
        card.setContentDescription(titleValue + ". " + subtitleValue);
        card.setOnClickListener(click);
        return card;
    }

    /** Tarjeta de Acceso rápido de Inicio. */
    public static View quickCard(Context c, String art, String titleValue, String subtitleValue,
                                 View.OnClickListener click) {
        RatioFrame card = cardBase(c, 0.92f, art, 0.04f, 0.03f, 0.96f, 0.56f, false);
        card.addView(bottomTextRow(c, titleValue, subtitleValue, 17.5f, 12.6f, 15, 14),
                new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));
        card.setContentDescription(titleValue + ". " + subtitleValue);
        card.setOnClickListener(click);
        return card;
    }

    /** Tarjeta con ilustración arriba, línea divisoria y texto abajo (Nivelación, etc.). */
    public static View stackCard(Context c, String art, String titleValue, String subtitleValue,
                                 View.OnClickListener click) {
        RatioFrame card = cardBase(c, 1.0f, art, 0f, 0f, 1f, 0.58f, true);
        card.addView(bottomTextRow(c, titleValue, subtitleValue, 16.5f, 12.4f, 14, 12),
                new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));
        card.setContentDescription(titleValue + ". " + subtitleValue);
        card.setOnClickListener(click);
        return card;
    }

    /** Tarjeta ancha: ilustración a un lado y texto al otro (Poligonal cerrada, Dos hilos). */
    public static View wideCard(Context c, String art, boolean artLeft, String titleValue,
                                String subtitleValue, View.OnClickListener click) {
        RatioFrame card = artLeft
                ? cardBase(c, 3.45f, art, 0f, 0f, 0.60f, 1f, false)
                : cardBase(c, 3.45f, art, 0.43f, 0f, 0.93f, 1f, false);
        LinearLayout row = NativeUi.row(c);
        row.setPadding(dp(c, 16), 0, dp(c, 10), 0);
        LinearLayout.LayoutParams textLp;
        if (artLeft) {
            row.addView(new View(c), new LinearLayout.LayoutParams(0, 1, 0.60f));
            textLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.40f);
        } else {
            textLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.42f);
        }
        row.addView(textBlock(c, titleValue, subtitleValue, 16.5f, 12.4f), textLp);
        if (!artLeft) row.addView(new View(c), new LinearLayout.LayoutParams(0, 1, 0.50f));
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(c, 22), dp(c, 22));
        alp.leftMargin = dp(c, 4);
        row.addView(chevron(c), alp);
        card.addView(row, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        card.setContentDescription(titleValue + ". " + subtitleValue);
        card.setOnClickListener(click);
        return card;
    }

    /** Tarjeta de cuadrícula: título arriba, flecha arriba a la derecha, dibujo abajo a la derecha. */
    public static View gridCard(Context c, String art, String titleValue, String subtitleValue,
                                View.OnClickListener click) {
        RatioFrame card = cardBase(c, 1.42f, art, 0.40f, 0.26f, 1f, 1f, false);
        LinearLayout top = NativeUi.row(c);
        top.setGravity(Gravity.TOP);
        top.setPadding(dp(c, 14), dp(c, 12), dp(c, 10), 0);
        LinearLayout labels = NativeUi.column(c);
        TextView title = NativeUi.text(c, titleValue, 16.5f, true, TITLE);
        ResponsiveUi.configureCompactText(title, 16.5f, 11, 2);
        title.setMaxLines(2);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setLineSpacing(0, 0.98f);
        labels.addView(title);
        top.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(c, 20), dp(c, 20));
        alp.topMargin = dp(c, 2);
        top.addView(chevron(c), alp);
        LinearLayout column = NativeUi.column(c);
        column.addView(top);
        TextView sub = NativeUi.text(c, subtitleValue, 12.2f, false, SUBTITLE);
        ResponsiveUi.configureCompactText(sub, 12.2f, 9, 2);
        sub.setMaxLines(2);
        sub.setEllipsize(TextUtils.TruncateAt.END);
        sub.setLineSpacing(0, 1.04f);
        sub.setPadding(dp(c, 14), dp(c, 4), 0, 0);
        LinearLayout subRow = NativeUi.row(c);
        subRow.setGravity(Gravity.TOP);
        subRow.addView(sub, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.66f));
        subRow.addView(new View(c), new LinearLayout.LayoutParams(0, 1, 0.34f));
        column.addView(subRow);
        card.addView(column, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));
        card.setContentDescription(titleValue + ". " + subtitleValue);
        card.setOnClickListener(click);
        return card;
    }

    /** Dos tarjetas lado a lado con separación uniforme. */
    public static View twoColumns(Context c, View left, View right) {
        LinearLayout row = NativeUi.row(c);
        row.setGravity(Gravity.TOP);
        row.setBaselineAligned(false);
        LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        a.rightMargin = dp(c, 6);
        LinearLayout.LayoutParams b = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        b.leftMargin = dp(c, 6);
        row.addView(left, a);
        row.addView(right, b);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(c, 12);
        row.setLayoutParams(lp);
        return row;
    }

    public static View full(Context c, View card) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(c, 12);
        card.setLayoutParams(lp);
        return card;
    }

    /** FrameLayout con proporción ancho/alto fija. */
    public static class RatioFrame extends FrameLayout {
        private final float ratio;
        public RatioFrame(Context c, float ratio) {
            super(c);
            this.ratio = ratio <= 0 ? 1f : ratio;
        }
        @Override protected void onMeasure(int wSpec, int hSpec) {
            int w = MeasureSpec.getSize(wSpec);
            if (w <= 0) { super.onMeasure(wSpec, hSpec); return; }
            int h = Math.max(1, Math.round(w / ratio));
            super.onMeasure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY));
        }
    }

    // ------------------------------------------------------------------ Iconos de línea

    public static class Glyph extends View {
        private final String type;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private boolean filled;

        public Glyph(Context c, String type, int color) {
            super(c);
            this.type = type;
            p.setColor(color);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
        }

        public void setFilled(boolean value) { filled = value; invalidate(); }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight(), s = Math.min(w, h);
            float cx = w / 2f, cy = h / 2f;
            p.setStrokeWidth(Math.max(2f, s * 0.085f));
            p.setStyle(Paint.Style.STROKE);
            path.reset();
            switch (type) {
                case "chevron":
                    cv.drawLine(cx - s * .14f, cy - s * .30f, cx + s * .16f, cy, p);
                    cv.drawLine(cx + s * .16f, cy, cx - s * .14f, cy + s * .30f, p);
                    break;
                case "back":
                    cv.drawLine(cx + s * .12f, cy - s * .34f, cx - s * .20f, cy, p);
                    cv.drawLine(cx - s * .20f, cy, cx + s * .12f, cy + s * .34f, p);
                    break;
                case "gear": {
                    float r1 = s * .40f, r2 = s * .30f;
                    for (int i = 0; i < 16; i++) {
                        double a = Math.PI * 2 * i / 16.0;
                        float r = (i % 2 == 0) ? r1 : r2;
                        double a2 = Math.PI * 2 * (i + 1) / 16.0;
                        float x1 = cx + (float) Math.cos(a) * r, y1 = cy + (float) Math.sin(a) * r;
                        float x2 = cx + (float) Math.cos(a2) * r, y2 = cy + (float) Math.sin(a2) * r;
                        if (i == 0) path.moveTo(x1, y1);
                        path.lineTo(x1, y1);
                        path.lineTo(x2, y2);
                    }
                    path.close();
                    cv.drawPath(path, p);
                    cv.drawCircle(cx, cy, s * .13f, p);
                    break;
                }
                case "home":
                    path.moveTo(cx - s * .40f, cy - s * .02f);
                    path.lineTo(cx, cy - s * .40f);
                    path.lineTo(cx + s * .40f, cy - s * .02f);
                    path.lineTo(cx + s * .30f, cy - s * .02f);
                    path.lineTo(cx + s * .30f, cy + s * .38f);
                    path.lineTo(cx + s * .10f, cy + s * .38f);
                    path.lineTo(cx + s * .10f, cy + s * .12f);
                    path.lineTo(cx - s * .10f, cy + s * .12f);
                    path.lineTo(cx - s * .10f, cy + s * .38f);
                    path.lineTo(cx - s * .30f, cy + s * .38f);
                    path.lineTo(cx - s * .30f, cy - s * .02f);
                    path.close();
                    if (filled) { p.setStyle(Paint.Style.FILL_AND_STROKE); }
                    cv.drawPath(path, p);
                    break;
                case "pin":
                    cv.drawCircle(cx, cy - s * .10f, s * .28f, p);
                    cv.drawCircle(cx, cy - s * .10f, s * .09f, p);
                    cv.drawLine(cx - s * .22f, cy + s * .08f, cx, cy + s * .42f, p);
                    cv.drawLine(cx + s * .22f, cy + s * .08f, cx, cy + s * .42f, p);
                    break;
                case "folder":
                    path.moveTo(cx - s * .42f, cy - s * .26f);
                    path.lineTo(cx - s * .12f, cy - s * .26f);
                    path.lineTo(cx - s * .02f, cy - s * .14f);
                    path.lineTo(cx + s * .42f, cy - s * .14f);
                    path.lineTo(cx + s * .42f, cy + s * .32f);
                    path.lineTo(cx - s * .42f, cy + s * .32f);
                    path.close();
                    cv.drawPath(path, p);
                    cv.drawLine(cx - s * .42f, cy - s * .04f, cx + s * .42f, cy - s * .04f, p);
                    break;
                case "target":
                    cv.drawCircle(cx, cy, s * .30f, p);
                    cv.drawCircle(cx, cy, s * .09f, p);
                    cv.drawLine(cx, cy - s * .46f, cx, cy - s * .20f, p);
                    cv.drawLine(cx, cy + s * .20f, cx, cy + s * .46f, p);
                    cv.drawLine(cx - s * .46f, cy, cx - s * .20f, cy, p);
                    cv.drawLine(cx + s * .20f, cy, cx + s * .46f, cy, p);
                    break;
                case "compass":
                    cv.drawCircle(cx, cy, s * .42f, p);
                    p.setStyle(Paint.Style.FILL);
                    path.moveTo(cx + s * .20f, cy - s * .20f);
                    path.lineTo(cx + s * .06f, cy + s * .06f);
                    path.lineTo(cx - s * .20f, cy + s * .20f);
                    path.lineTo(cx - s * .06f, cy - s * .06f);
                    path.close();
                    cv.drawPath(path, p);
                    break;
                case "calculator":
                    cv.drawRoundRect(new RectF(cx - s * .30f, cy - s * .42f, cx + s * .30f, cy + s * .42f),
                            s * .08f, s * .08f, p);
                    cv.drawRect(cx - s * .17f, cy - s * .28f, cx + s * .17f, cy - s * .10f, p);
                    p.setStyle(Paint.Style.FILL);
                    for (int r = 0; r < 2; r++) for (int k = 0; k < 3; k++)
                        cv.drawCircle(cx - s * .15f + k * s * .15f, cy + s * .07f + r * s * .17f, s * .04f, p);
                    break;
                case "map":
                    path.moveTo(cx - s * .42f, cy - s * .28f);
                    path.lineTo(cx - s * .14f, cy - s * .40f);
                    path.lineTo(cx + s * .14f, cy - s * .28f);
                    path.lineTo(cx + s * .42f, cy - s * .40f);
                    path.lineTo(cx + s * .42f, cy + s * .30f);
                    path.lineTo(cx + s * .14f, cy + s * .42f);
                    path.lineTo(cx - s * .14f, cy + s * .30f);
                    path.lineTo(cx - s * .42f, cy + s * .42f);
                    path.close();
                    cv.drawPath(path, p);
                    cv.drawLine(cx - s * .14f, cy - s * .40f, cx - s * .14f, cy + s * .30f, p);
                    cv.drawLine(cx + s * .14f, cy - s * .28f, cx + s * .14f, cy + s * .42f, p);
                    break;
                case "mountain":
                    p.setStrokeWidth(Math.max(1.5f, h * .07f));
                    path.moveTo(w * .02f, h * .92f);
                    path.lineTo(w * .30f, h * .20f);
                    path.lineTo(w * .45f, h * .55f);
                    path.lineTo(w * .62f, h * .08f);
                    path.lineTo(w * .98f, h * .92f);
                    cv.drawPath(path, p);
                    cv.drawLine(w * .20f, h * .45f, w * .38f, h * .42f, p);
                    cv.drawLine(w * .54f, h * .30f, w * .72f, h * .32f, p);
                    break;
                default:
                    cv.drawCircle(cx, cy, s * .2f, p);
            }
        }
    }

    // ------------------------------------------------------------------ Ilustraciones

    /**
     * Fondo con curvas de nivel + ilustración dentro de un rectángulo relativo (l,t,r,b).
     * Los números que aparecen son rótulos decorativos del dibujo, no lecturas GPS.
     */
    public static class ArtView extends View {
        private final String key;
        private final float fl, ft, fr, fb;
        private final boolean divider;
        private final Paint s = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint f = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final float d;
        private final DashPathEffect dash;

        public ArtView(Context c, String key, float l, float top, float r, float b, boolean divider) {
            super(c);
            this.key = key;
            this.fl = l; this.ft = top; this.fr = r; this.fb = b;
            this.divider = divider;
            d = c.getResources().getDisplayMetrics().density;
            dash = new DashPathEffect(new float[]{4 * d, 4 * d}, 0);
            s.setStyle(Paint.Style.STROKE);
            s.setStrokeCap(Paint.Cap.ROUND);
            s.setStrokeJoin(Paint.Join.ROUND);
            f.setStyle(Paint.Style.FILL);
            t.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        @Override protected void onDraw(Canvas cv) {
            float W = getWidth(), H = getHeight();
            if (W <= 0 || H <= 0) return;
            drawContours(cv, W, H);
            float x = W * fl, y = H * ft, w = W * (fr - fl), h = H * (fb - ft);
            // Halo suave detrás del dibujo.
            f.setShader(new RadialGradient(x + w * .55f, y + h * .45f, Math.max(w, h) * .65f,
                    Color.argb(60, 60, 140, 255), Color.argb(0, 60, 140, 255), Shader.TileMode.CLAMP));
            cv.drawRect(x, y, x + w, y + h, f);
            f.setShader(null);
            if (divider) {
                f.setColor(Color.argb(70, 2, 12, 26));
                cv.drawRect(0, y + h, W, H, f);
                s.setPathEffect(null);
                s.setStrokeWidth(d);
                s.setColor(Color.argb(110, 88, 148, 214));
                cv.drawLine(0, y + h, W, y + h, s);
            }
            cv.save();
            cv.translate(x, y);
            cv.clipRect(0, 0, w, h);
            drawArt(cv, w, h);
            cv.restore();
        }

        private void drawContours(Canvas cv, float W, float H) {
            s.setPathEffect(null);
            s.setStrokeWidth(Math.max(1f, d * .8f));
            s.setColor(Color.argb(34, 120, 180, 245));
            int seed = key.hashCode();
            for (int i = -2; i < 12; i++) {
                float base = H * (i * .11f);
                path.reset();
                for (float xx = -10; xx <= W + 20; xx += Math.max(8f, W / 24f)) {
                    float yy = base + (float) Math.sin(xx * .012f + i * .9f + seed * .01f) * H * .06f
                            + (float) Math.cos(xx * .02f - i * .5f) * H * .03f;
                    if (xx == -10) path.moveTo(xx, yy); else path.lineTo(xx, yy);
                }
                cv.drawPath(path, s);
            }
        }

        // ---------- utilidades de dibujo
        private void stroke(int color, float widthDp) {
            s.setPathEffect(null);
            s.setColor(color);
            s.setStrokeWidth(widthDp * d);
        }
        private void dashed(int color, float widthDp) {
            stroke(color, widthDp);
            s.setPathEffect(dash);
        }
        private void label(Canvas cv, String value, float x, float y, float size, int color,
                           boolean bold, Paint.Align align) {
            t.setTextSize(size);
            t.setColor(color);
            t.setTextAlign(align);
            t.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
            cv.drawText(value, x, y, t);
        }
        private void node(Canvas cv, float x, float y, float r) {
            f.setColor(Color.rgb(8, 28, 56));
            cv.drawCircle(x, y, r * 1.45f, f);
            f.setColor(Color.WHITE);
            cv.drawCircle(x, y, r * 1.1f, f);
            f.setColor(ACCENT);
            cv.drawCircle(x, y, r * .62f, f);
            f.setColor(Color.WHITE);
            cv.drawCircle(x, y, r * .28f, f);
        }
        private void smallDot(Canvas cv, float x, float y, float r) {
            f.setColor(ACCENT_LIGHT);
            cv.drawCircle(x, y, r, f);
        }
        private void pin(Canvas cv, float x, float tipY, float r) {
            float cy = tipY - r * 1.6f;
            path.reset();
            path.moveTo(x, tipY);
            path.cubicTo(x - r * .55f, cy + r * .9f, x - r, cy + r * .45f, x - r, cy);
            path.arcTo(new RectF(x - r, cy - r, x + r, cy + r), 180, 180);
            path.cubicTo(x + r, cy + r * .45f, x + r * .55f, cy + r * .9f, x, tipY);
            path.close();
            f.setShader(new LinearGradient(x, cy - r, x, tipY,
                    Color.rgb(90, 170, 255), Color.rgb(28, 108, 235), Shader.TileMode.CLAMP));
            cv.drawPath(path, f);
            f.setShader(null);
            stroke(Color.argb(200, 200, 230, 255), 1f);
            cv.drawPath(path, s);
            f.setColor(Color.WHITE);
            cv.drawCircle(x, cy, r * .38f, f);
        }
        private void staff(Canvas cv, float x, float top, float bottom, float width, boolean numbers) {
            f.setColor(Color.rgb(222, 234, 246));
            cv.drawRect(x, top, x + width, bottom, f);
            float seg = (bottom - top) / 12f;
            for (int i = 0; i < 12; i++) {
                float yy = top + i * seg;
                f.setColor(i % 4 == 1 ? Color.rgb(226, 64, 70) : Color.rgb(24, 40, 62));
                cv.drawRect(x, yy + seg * .15f, x + width * (i % 2 == 0 ? .55f : .35f), yy + seg * .5f, f);
            }
            stroke(Color.rgb(70, 110, 150), 1f);
            cv.drawRect(x, top, x + width, bottom, s);
            if (numbers) {
                float size = Math.max(9 * d, width * .9f);
                label(cv, "10", x + width * 1.25f, top + seg * 2.6f, size, ACCENT_LIGHT, false, Paint.Align.LEFT);
                label(cv, "09", x + width * 1.25f, top + seg * 6.6f, size, ACCENT_LIGHT, false, Paint.Align.LEFT);
                label(cv, "08", x + width * 1.25f, top + seg * 10.6f, size, ACCENT_LIGHT, false, Paint.Align.LEFT);
            }
        }
        private void textLines(Canvas cv, String[] lines, float x, float y, float size, float gap) {
            for (int i = 0; i < lines.length; i++)
                label(cv, lines[i], x, y + i * size * gap, size, Color.rgb(196, 214, 234), false, Paint.Align.LEFT);
        }

        private void drawArt(Canvas cv, float w, float h) {
            switch (key) {
                case "gps": gps(cv, w, h); break;
                case "field": station(cv, w, h, true); break;
                case "converter": converter(cv, w, h); break;
                case "compass": compass(cv, w, h); break;
                case "azimuth": azimuth(cv, w, h); break;
                case "coordinates": coordinates(cv, w, h); break;
                case "polygon": polygon(cv, w, h, "2.35 ha", true); break;
                case "level": level(cv, w, h); break;
                case "distance": slope(cv, w, h); break;
                case "two_hair": twoHair(cv, w, h); break;
                case "stadia": stadia(cv, w, h); break;
                case "cogo": cogo(cv, w, h); break;
                case "track": track(cv, w, h, false); break;
                case "track_grid": track(cv, w, h, true); break;
                case "tripod": tripod(cv, w, h); break;
                case "stakeout": stakeout(cv, w, h); break;
                case "quality": quality(cv, w, h); break;
                case "external": external(cv, w, h); break;
                case "area": polygon(cv, w, h, "1.25 ha", false); break;
                case "traverse": traverse(cv, w, h); break;
                case "leveling": leveling(cv, w, h); break;
                case "profile": profile(cv, w, h); break;
                case "offline": offline(cv, w, h); break;
                case "notebook": notebook(cv, w, h); break;
                default: break;
            }
        }

        // ---------- Inicio
        private void gps(Canvas cv, float w, float h) {
            float m = Math.min(w, h);
            dashed(Color.argb(160, 120, 180, 245), 1.2f);
            path.reset();
            path.moveTo(w * .30f, h * .20f);
            path.cubicTo(w * .45f, h * .08f, w * .58f, h * .35f, w * .75f, h * .15f);
            path.lineTo(w * .95f, h * .05f);
            cv.drawPath(path, s);
            dashed(Color.argb(110, 120, 180, 245), 1f);
            cv.drawLine(w * .40f, h * .98f, w * .62f, h * .45f, s);
            stroke(ACCENT, 2.6f);
            path.reset();
            path.moveTo(w * .27f, h * .25f);
            path.lineTo(w * .33f, h * .40f);
            path.cubicTo(w * .42f, h * .46f, w * .50f, h * .50f, w * .55f, h * .56f);
            path.cubicTo(w * .62f, h * .64f, w * .70f, h * .66f, w * .76f, h * .64f);
            path.cubicTo(w * .82f, h * .62f, w * .86f, h * .72f, w * .90f, h * .85f);
            path.lineTo(w * 1.05f, h * .95f);
            cv.drawPath(path, s);
            node(cv, w * .27f, h * .25f, m * .030f);
            smallDot(cv, w * .33f, h * .40f, m * .022f);
            smallDot(cv, w * .55f, h * .56f, m * .022f);
            node(cv, w * .76f, h * .64f, m * .026f);
            smallDot(cv, w * .90f, h * .85f, m * .022f);
            pin(cv, w * .76f, h * .60f, m * .10f);
            // Norte
            f.setColor(Color.rgb(170, 200, 235));
            path.reset();
            path.moveTo(w * .88f, h * .05f);
            path.lineTo(w * .91f, h * .14f);
            path.lineTo(w * .88f, h * .12f);
            path.lineTo(w * .85f, h * .14f);
            path.close();
            cv.drawPath(path, f);
            label(cv, "N", w * .88f, h * .23f, m * .075f, Color.rgb(190, 212, 238), false, Paint.Align.CENTER);
            textLines(cv, new String[]{"N 4897532", "E 324621", "H 1184  m"}, w * .08f, h * .58f, m * .06f, 1.45f);
        }

        private void station(Canvas cv, float w, float h, boolean scenery) {
            float m = Math.min(w, h);
            if (scenery) {
                stroke(Color.argb(90, 120, 180, 245), 1f);
                path.reset();
                path.moveTo(0, h * .45f); path.lineTo(w * .15f, h * .22f); path.lineTo(w * .28f, h * .38f);
                path.lineTo(w * .45f, h * .12f); path.lineTo(w * .62f, h * .40f); path.lineTo(w * .80f, h * .18f);
                path.lineTo(w, h * .42f);
                cv.drawPath(path, s);
                stroke(Color.argb(170, 150, 190, 235), 1.2f);
                float tx = w * .84f, ty = h * .26f, tr = m * .07f;
                cv.drawCircle(tx, ty, tr, s);
                cv.drawLine(tx - tr * 1.6f, ty, tx + tr * 1.6f, ty, s);
                cv.drawLine(tx, ty - tr * 1.6f, tx, ty + tr * 1.6f, s);
                dashed(Color.argb(140, 150, 190, 235), 1f);
                cv.drawLine(w * .60f, h * .45f, w, h * .45f, s);
                cv.drawLine(tx, ty + tr * 1.6f, tx, h * .75f, s);
                cv.drawLine(w * .62f, h * .75f, w * .95f, h * .75f, s);
            }
            float cx = w * .50f;
            int green = Color.rgb(64, 150, 128), dark = Color.rgb(24, 70, 66), light = Color.rgb(120, 200, 176);
            // Trípode
            stroke(dark, 5f);
            cv.drawLine(cx - m * .06f, h * .74f, cx - m * .26f, h * 1.0f, s);
            cv.drawLine(cx + m * .06f, h * .74f, cx + m * .26f, h * 1.0f, s);
            cv.drawLine(cx, h * .74f, cx, h * 1.0f, s);
            stroke(green, 2.5f);
            cv.drawLine(cx - m * .06f, h * .74f, cx - m * .26f, h * 1.0f, s);
            cv.drawLine(cx + m * .06f, h * .74f, cx + m * .26f, h * 1.0f, s);
            // Base
            f.setColor(dark);
            cv.drawRoundRect(new RectF(cx - m * .20f, h * .66f, cx + m * .20f, h * .75f), m * .02f, m * .02f, f);
            // Soportes (U) y asa
            f.setShader(new LinearGradient(cx - m * .2f, 0, cx + m * .2f, 0, light, green, Shader.TileMode.CLAMP));
            cv.drawRoundRect(new RectF(cx - m * .22f, h * .10f, cx - m * .12f, h * .62f), m * .03f, m * .03f, f);
            cv.drawRoundRect(new RectF(cx + m * .12f, h * .10f, cx + m * .22f, h * .62f), m * .03f, m * .03f, f);
            cv.drawRoundRect(new RectF(cx - m * .20f, h * .04f, cx + m * .20f, h * .09f), m * .02f, m * .02f, f);
            cv.drawRoundRect(new RectF(cx - m * .22f, h * .50f, cx + m * .22f, h * .67f), m * .03f, m * .03f, f);
            f.setShader(null);
            // Anteojo
            f.setColor(Color.rgb(34, 92, 86));
            cv.drawRoundRect(new RectF(cx - m * .12f, h * .15f, cx + m * .12f, h * .47f), m * .04f, m * .04f, f);
            f.setColor(Color.rgb(12, 36, 44));
            cv.drawCircle(cx + m * .02f, h * .30f, m * .075f, f);
            f.setColor(Color.rgb(90, 150, 200));
            cv.drawCircle(cx + m * .02f, h * .30f, m * .045f, f);
            f.setColor(Color.rgb(210, 235, 255));
            cv.drawCircle(cx + m * .005f, h * .285f, m * .015f, f);
            // Teclado
            f.setColor(Color.rgb(20, 50, 70));
            cv.drawRoundRect(new RectF(cx - m * .12f, h * .52f, cx + m * .12f, h * .65f), m * .015f, m * .015f, f);
            f.setColor(Color.rgb(120, 190, 230));
            for (int r = 0; r < 3; r++) for (int k = 0; k < 5; k++)
                cv.drawRect(cx - m * .10f + k * m * .042f, h * .535f + r * h * .035f,
                        cx - m * .075f + k * m * .042f, h * .56f + r * h * .035f, f);
        }

        private void converter(Canvas cv, float w, float h) {
            float m = Math.min(w, h);
            RectF panel = new RectF(w * .18f, h * .10f, w * .86f, h * .92f);
            f.setColor(Color.argb(120, 10, 34, 60));
            cv.drawRoundRect(panel, m * .06f, m * .06f, f);
            stroke(Color.argb(150, 88, 148, 214), 1f);
            cv.drawRoundRect(panel, m * .06f, m * .06f, s);
            float split = w * .52f;
            cv.drawLine(split, panel.top, split, panel.bottom, s);
            // Calculadora
            RectF calc = new RectF(w * .23f, h * .18f, w * .47f, h * .84f);
            f.setShader(new LinearGradient(0, calc.top, 0, calc.bottom,
                    Color.rgb(150, 190, 230), Color.rgb(80, 130, 190), Shader.TileMode.CLAMP));
            cv.drawRoundRect(calc, m * .04f, m * .04f, f);
            f.setShader(null);
            f.setColor(Color.rgb(18, 44, 78));
            float cw = calc.width();
            cv.drawRoundRect(new RectF(calc.left + cw * .12f, calc.top + cw * .12f, calc.right - cw * .12f,
                    calc.top + cw * .40f), m * .015f, m * .015f, f);
            for (int r = 0; r < 3; r++) for (int k = 0; k < 3; k++) {
                float kx = calc.left + cw * (.12f + k * .27f);
                float ky = calc.top + cw * .55f + r * cw * .30f;
                cv.drawRoundRect(new RectF(kx, ky, kx + cw * .22f, ky + cw * .22f), m * .01f, m * .01f, f);
            }
            String[][] units = {{"m", "ft"}, {"km", "mi"}, {"ha", "ac"}, {"°", "‰"}};
            float size = m * .085f;
            for (int i = 0; i < 4; i++) {
                float yy = h * (.30f + i * .17f);
                label(cv, units[i][0], w * .61f, yy, size, Color.rgb(170, 196, 226), false, Paint.Align.CENTER);
                label(cv, units[i][1], w * .76f, yy, size, Color.rgb(170, 196, 226), false, Paint.Align.CENTER);
            }
        }

        private void compass(Canvas cv, float w, float h) {
            float cx = w * .52f, cy = h * .52f, r = Math.min(w, h) * .46f;
            f.setColor(Color.argb(150, 6, 22, 42));
            cv.drawCircle(cx, cy, r, f);
            stroke(Color.rgb(90, 150, 220), 1.5f);
            cv.drawCircle(cx, cy, r, s);
            stroke(Color.argb(140, 90, 150, 220), 1f);
            cv.drawCircle(cx, cy, r * .80f, s);
            for (int i = 0; i < 72; i++) {
                double a = Math.toRadians(i * 5 - 90);
                boolean major = i % 18 == 0;
                float r1 = r * (major ? .80f : (i % 2 == 0 ? .86f : .90f)), r2 = r * .96f;
                stroke(major ? Color.WHITE : Color.argb(170, 170, 200, 235), major ? 2f : 1f);
                cv.drawLine(cx + (float) Math.cos(a) * r1, cy + (float) Math.sin(a) * r1,
                        cx + (float) Math.cos(a) * r2, cy + (float) Math.sin(a) * r2, s);
            }
            float size = r * .22f;
            label(cv, "N", cx, cy - r * .56f, size, Color.WHITE, true, Paint.Align.CENTER);
            label(cv, "S", cx, cy + r * .72f, size, Color.WHITE, true, Paint.Align.CENTER);
            label(cv, "E", cx + r * .64f, cy + size * .36f, size, Color.WHITE, true, Paint.Align.CENTER);
            label(cv, "O", cx - r * .64f, cy + size * .36f, size, Color.WHITE, true, Paint.Align.CENTER);
            double a = Math.toRadians(-55);
            float nx = cx + (float) Math.cos(a) * r * .62f, ny = cy + (float) Math.sin(a) * r * .62f;
            float sx = cx - (float) Math.cos(a) * r * .62f, sy = cy - (float) Math.sin(a) * r * .62f;
            float px = -(float) Math.sin(a) * r * .11f, py = (float) Math.cos(a) * r * .11f;
            path.reset();
            path.moveTo(nx, ny); path.lineTo(cx + px, cy + py); path.lineTo(cx - px, cy - py); path.close();
            f.setColor(Color.rgb(70, 160, 255));
            cv.drawPath(path, f);
            path.reset();
            path.moveTo(sx, sy); path.lineTo(cx + px, cy + py); path.lineTo(cx - px, cy - py); path.close();
            f.setColor(Color.rgb(140, 196, 255));
            cv.drawPath(path, f);
            f.setColor(Color.rgb(20, 60, 120));
            cv.drawCircle(cx, cy, r * .09f, f);
            f.setColor(Color.WHITE);
            cv.drawCircle(cx, cy, r * .04f, f);
        }

        private void azimuth(Canvas cv, float w, float h) {
            float m = Math.min(w, h);
            float ax = w * .28f, ay = h * .82f, bx = w * .82f, by = h * .38f;
            label(cv, "N", ax, h * .12f, m * .10f, Color.WHITE, true, Paint.Align.CENTER);
            dashed(Color.rgb(200, 215, 235), 1.2f);
            cv.drawLine(ax, h * .17f, ax, ay, s);
            stroke(ACCENT, 2.4f);
            cv.drawLine(ax, ay, bx, by, s);
            float rr = m * .42f;
            cv.drawArc(new RectF(ax - rr, ay - rr, ax + rr, ay + rr), -90, 51, false, s);
            node(cv, ax, ay, m * .03f);
            node(cv, bx, by, m * .03f);
            label(cv, "135.6°", ax + m * .10f, ay - rr - m * .02f, m * .10f, ACCENT_LIGHT, false, Paint.Align.LEFT);
        }

        private void coordinates(Canvas cv, float w, float h) {
            float m = Math.min(w, h);
            stroke(Color.argb(90, 120, 180, 245), 1f);
            for (int i = 0; i <= 8; i++) cv.drawLine(w * (.08f + i * .105f), h * .12f, w * (.08f + i * .105f), h * .92f, s);
            for (int i = 0; i <= 5; i++) cv.drawLine(w * .06f, h * (.14f + i * .15f), w * .96f, h * (.14f + i * .15f), s);
            float px = w * .45f, py = h * .60f;
            dashed(Color.rgb(200, 215, 235), 1.2f);
            cv.drawLine(px, h * .02f, px, h * .98f, s);
            cv.drawLine(w * .02f, py, w * .98f, py, s);
            stroke(Color.rgb(200, 215, 235), 1f);
            cv.drawLine(w * .62f, h * .10f, w * .62f, h * .50f, s);
            node(cv, px, py, m * .04f);
            textLines(cv, new String[]{"E  324621", "N  4897532", "Z  1184.25"}, w * .66f, h * .22f, m * .075f, 1.35f);
        }

        // ---------- Herramientas de campo (parte 1)
        private void polygon(Canvas cv, float w, float h, String area, boolean wide) {
            float m = Math.min(w, h);
            float[] xs = wide ? new float[]{.17f, .40f, .64f, .70f, .32f} : new float[]{.22f, .52f, .80f, .84f, .30f};
            float[] ys = wide ? new float[]{.57f, .19f, .38f, .75f, .93f} : new float[]{.40f, .14f, .30f, .82f, .90f};
            path.reset();
            for (int i = 0; i < xs.length; i++) {
                if (i == 0) path.moveTo(xs[i] * w, ys[i] * h); else path.lineTo(xs[i] * w, ys[i] * h);
            }
            path.close();
            f.setColor(Color.argb(70, 60, 140, 255));
            cv.drawPath(path, f);
            stroke(ACCENT_LIGHT, 2.2f);
            cv.drawPath(path, s);
            for (int i = 0; i < xs.length; i++) node(cv, xs[i] * w, ys[i] * h, m * .045f);
            float cx = wide ? w * .43f : w * .55f;
            label(cv, area, cx, h * .58f, m * .13f, Color.WHITE, false, Paint.Align.CENTER);
        }

        private void level(Canvas cv, float w, float h) {
            float m = Math.min(w, h);
            float cy = h * .45f;
            // Cuerpo del nivel automático
            f.setShader(new LinearGradient(0, cy - m * .25f, 0, cy + m * .25f,
                    Color.rgb(90, 160, 230), Color.rgb(30, 80, 150), Shader.TileMode.CLAMP));
            cv.drawRoundRect(new RectF(w * .10f, cy - m * .20f, w * .55f, cy + m * .20f), m * .08f, m * .08f, f);
            cv.drawRoundRect(new RectF(w * .20f, cy - m * .30f, w * .40f, cy - m * .18f), m * .03f, m * .03f, f);
            f.setShader(null);
            stroke(Color.rgb(150, 205, 255), 1.4f);
            cv.drawRoundRect(new RectF(w * .10f, cy - m * .20f, w * .55f, cy + m * .20f), m * .08f, m * .08f, s);
            // Objetivo
            f.setColor(Color.rgb(40, 100, 170));
            cv.drawOval(new RectF(w * .50f, cy - m * .22f, w * .63f, cy + m * .22f), f);
            cv.drawOval(new RectF(w * .50f, cy - m * .22f, w * .63f, cy + m * .22f), s);
            stroke(Color.rgb(150, 205, 255), 1.4f);
            cv.drawCircle(w * .25f, cy - m * .02f, m * .09f, s);
            cv.drawCircle(w * .33f, cy + m * .12f, m * .05f, s);
            // Base
            f.setColor(Color.rgb(40, 90, 150));
            cv.drawRect(w * .18f, cy + m * .20f, w * .47f, cy + m * .30f, f);
            cv.drawRect(w * .14f, cy + m * .34f, w * .51f, cy + m * .40f, f);
            stroke(Color.rgb(120, 180, 240), 2f);
            cv.drawLine(w * .22f, cy + m * .40f, w * .20f, h, s);
            cv.drawLine(w * .43f, cy + m * .40f, w * .45f, h, s);
            staff(cv, w * .76f, 0, h, w * .07f, true);
        }

        private void slope(Canvas cv, float w, float h) {
            float m = Math.min(w, h);
            f.setColor(Color.argb(90, 40, 100, 170));
            path.reset();
            path.moveTo(0, h * .92f);
            path.cubicTo(w * .40f, h * .85f, w * .70f, h * .55f, w, h * .18f);
            path.lineTo(w, h); path.lineTo(0, h); path.close();
            cv.drawPath(path, f);
            stroke(Color.argb(200, 120, 190, 250), 1.4f);
            path.reset();
            path.moveTo(0, h * .92f);
            path.cubicTo(w * .40f, h * .85f, w * .70f, h * .55f, w, h * .18f);
            cv.drawPath(path, s);
            stroke(Color.argb(150, 180, 210, 240), 1f);
            cv.drawLine(0, h * .96f, w, h * .96f, s);
            float x1 = w * .15f, y1 = h * .80f, x2 = w * .84f, y2 = h * .22f;
            dashed(Color.rgb(200, 220, 245), 1.4f);
            cv.drawLine(x1, y1, x2, y2, s);
            cv.drawLine(x2, y2 + m * .06f, x2, h * .96f, s);
            stroke(Color.WHITE, 1.4f);
            cv.drawLine(x2 - m * .03f, y2 + m * .10f, x2, y2 + m * .05f, s);
            cv.drawLine(x2 + m * .03f, y2 + m * .10f, x2, y2 + m * .05f, s);
            cv.drawLine(x2 - m * .03f, h * .91f, x2, h * .96f, s);
            cv.drawLine(x2 + m * .03f, h * .91f, x2, h * .96f, s);
            smallDot(cv, w * .38f, h * .61f, m * .018f);
            smallDot(cv, w * .61f, h * .41f, m * .018f);
            node(cv, x1, y1, m * .035f);
            node(cv, x2, y2, m * .035f);
            cv.save();
            float ang = (float) Math.toDegrees(Math.atan2(y2 - y1, x2 - x1));
            cv.rotate(ang, w * .50f, h * .47f);
            label(cv, "125.4 m", w * .50f, h * .47f - m * .05f, m * .11f, ACCENT_LIGHT, false, Paint.Align.CENTER);
            cv.restore();
            label(cv, "Δh 12.6 m", x2 - m * .05f, h * .62f, m * .10f, Color.WHITE, false, Paint.Align.RIGHT);
        }

        private void twoHair(Canvas cv, float w, float h) {
            float m = Math.min(w, h);
            float r = Math.min(h * .47f, w * .27f);
            float cx = r + w * .03f, cy = h * .52f;
            cv.save();
            path.reset();
            path.addCircle(cx, cy, r, Path.Direction.CW);
            cv.clipPath(path);
            f.setColor(Color.rgb(12, 40, 74));
            cv.drawCircle(cx, cy, r, f);
            // Montañas y árboles en el visor
            f.setColor(Color.rgb(24, 62, 104));
            path.reset();
            path.moveTo(cx - r, cy + r * .10f);
            path.lineTo(cx - r * .50f, cy - r * .30f);
            path.lineTo(cx - r * .10f, cy);
            path.lineTo(cx + r * .40f, cy - r * .40f);
            path.lineTo(cx + r, cy);
            path.lineTo(cx + r, cy + r); path.lineTo(cx - r, cy + r); path.close();
            cv.drawPath(path, f);
            f.setColor(Color.rgb(10, 32, 58));
            for (int i = 0; i < 5; i++) {
                float tx = cx - r * .80f + i * r * .40f, ty = cy + r * .60f;
                path.reset();
                path.moveTo(tx, ty - r * .35f); path.lineTo(tx - r * .10f, ty); path.lineTo(tx + r * .10f, ty); path.close();
                cv.drawPath(path, f);
            }
            staff(cv, cx - r * .07f, cy - r * .95f, cy + r * .95f, r * .14f, false);
            stroke(Color.argb(210, 220, 235, 250), 1f);
            cv.drawLine(cx - r, cy, cx + r, cy, s);
            cv.drawLine(cx, cy - r, cx, cy + r, s);
            cv.drawLine(cx - r * .30f, cy - r * .34f, cx + r * .30f, cy - r * .34f, s);
            cv.drawLine(cx - r * .30f, cy + r * .34f, cx + r * .30f, cy + r * .34f, s);
            cv.restore();
            stroke(Color.rgb(20, 40, 64), 5f);
            cv.drawCircle(cx, cy, r, s);
            stroke(Color.rgb(90, 140, 200), 1.2f);
            cv.drawCircle(cx, cy, r, s);
            // Rótulos ajustados al espacio libre a la derecha del visor.
            float lx = cx + r + w * .05f;
            float room = w - lx - w * .02f;
            float size = Math.min(h * .15f, room / 5.6f);
            t.setTextSize(size);
            float gap = t.measureText("H cen ") ;
            String[] names = {"H sup", "H cen", "H inf"};
            String[] vals = {"1.832", "1.275", "0.718"};
            for (int i = 0; i < 3; i++) {
                float yy = cy + (i - 1) * size * 1.7f + size * .35f;
                label(cv, names[i], lx, yy, size, ACCENT_LIGHT, false, Paint.Align.LEFT);
                label(cv, vals[i], lx + gap, yy, size, Color.rgb(200, 220, 240), false, Paint.Align.LEFT);
            }
        }

        private void stadia(Canvas cv, float w, float h) {
            float m = Math.min(w, h);
            float sw = m * .10f, sx = w * .30f;
            staff(cv, sx, 0, h, sw, false);
            String[] names = {"H sup", "H cen", "H inf"};
            float[] ys = {.25f, .50f, .75f};
            float size = Math.min(h * .12f, w * .075f);
            for (int i = 0; i < 3; i++) {
                float yy = h * ys[i];
                stroke(Color.rgb(220, 235, 250), 1.3f);
                cv.drawLine(sx - m * .12f, yy, sx + sw + m * .12f, yy, s);
                dashed(Color.argb(150, 120, 180, 245), 1f);
                cv.drawLine(sx + sw + m * .14f, yy, w * .60f, yy, s);
                label(cv, names[i], w * .63f, yy + size * .35f, size, ACCENT_LIGHT, false, Paint.Align.LEFT);
            }
        }

        private void cogo(Canvas cv, float w, float h) {
            float m = Math.min(w, h);
            stroke(Color.argb(80, 120, 180, 245), 1f);
            for (int i = 0; i <= 8; i++) cv.drawLine(w * i / 8f, 0, w * i / 8f, h, s);
            for (int i = 0; i <= 4; i++) cv.drawLine(0, h * i / 4f, w, h * i / 4f, s);
            float ax = w * .14f, ay = h * .78f, bx = w * .74f, by = h * .22f, px = w * .62f, py = h * .80f;
            stroke(ACCENT_LIGHT, 2.2f);
            cv.drawLine(ax, ay, bx, by, s);
            // Pie de la perpendicular (offset) desde P sobre la línea AB
            float dx = bx - ax, dy = by - ay, k = ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy);
            float fx = ax + k * dx, fy = ay + k * dy;
            dashed(Color.rgb(200, 220, 245), 1.2f);
            cv.drawLine(px, py, fx, fy, s);
            dashed(Color.rgb(200, 215, 235), 1f);
            cv.drawLine(ax, ay, ax, h * .08f, s);
            node(cv, ax, ay, m * .045f);
            node(cv, bx, by, m * .045f);
            node(cv, px, py, m * .040f);
            float size = m * .12f;
            label(cv, "A", ax - m * .08f, ay + size * .4f, size, Color.WHITE, true, Paint.Align.RIGHT);
            label(cv, "B", bx + m * .08f, by + size * .4f, size, Color.WHITE, true, Paint.Align.LEFT);
            label(cv, "P", px + m * .08f, py + size * .4f, size, Color.WHITE, true, Paint.Align.LEFT);
        }

        private void track(Canvas cv, float w, float h, boolean grid) {
            float m = Math.min(w, h);
            float[] xs = grid ? new float[]{.18f, .32f, .48f, .62f, .74f, .80f} : new float[]{.20f, .45f, .62f, .78f, .87f};
            float[] ys = grid ? new float[]{.98f, .70f, .60f, .55f, .40f, .22f} : new float[]{.40f, .86f, .70f, .66f, .42f};
            stroke(ACCENT, 2.4f);
            path.reset();
            path.moveTo(xs[0] * w, ys[0] * h);
            for (int i = 1; i < xs.length; i++) {
                float px = xs[i - 1] * w, py = ys[i - 1] * h, qx = xs[i] * w, qy = ys[i] * h;
                path.cubicTo(px + (qx - px) * .5f, py, px + (qx - px) * .5f, qy, qx, qy);
            }
            cv.drawPath(path, s);
            dashed(Color.argb(160, 150, 200, 250), 1.2f);
            float lx = xs[xs.length - 1] * w, ly = ys[ys.length - 1] * h;
            cv.drawLine(lx, ly, w, ly + h * (grid ? -.1f : .25f), s);
            for (int i = 0; i < xs.length - 1; i++) node(cv, xs[i] * w, ys[i] * h, m * .03f);
            node(cv, lx, ly, m * .03f);
            pin(cv, lx, ly - m * .05f, m * .10f);
        }

        private void tripod(Canvas cv, float w, float h) {
            float m = Math.min(w, h);
            stroke(Color.argb(80, 120, 180, 245), 1f);
            for (int i = 0; i <= 8; i++) cv.drawLine(w * i / 8f, 0, w * i / 8f, h, s);
            for (int i = 0; i <= 5; i++) cv.drawLine(0, h * i / 5f, w, h * i / 5f, s);
            float cx = w * .42f, cy = h * .40f;
            dashed(Color.rgb(200, 215, 235), 1.1f);
            cv.drawLine(cx, 0, cx, cy, s);
            cv.drawLine(cx, cy, 0, h * .95f, s);
            cv.drawLine(cx, cy, w * .92f, h * .95f, s);
            stroke(Color.rgb(90, 140, 200), 3f);
            cv.drawLine(cx - m * .03f, cy + m * .10f, cx - m * .16f, h, s);
            cv.drawLine(cx + m * .03f, cy + m * .10f, cx + m * .16f, h, s);
            cv.drawLine(cx, cy + m * .10f, cx, h, s);
            f.setColor(Color.rgb(60, 110, 170));
            cv.drawRect(cx - m * .08f, cy + m * .06f, cx + m * .08f, cy + m * .12f, f);
            node(cv, cx, cy, m * .05f);
            RectF box = new RectF(w * .62f, h * .08f, w * .98f, h * .55f);
            f.setColor(Color.argb(150, 8, 26, 48));
            cv.drawRect(box, f);
            stroke(Color.argb(120, 88, 148, 214), 1f);
            cv.drawRect(box, s);
            textLines(cv, new String[]{"N 4897532", "E 324621", "Z 1184.25"}, w * .65f, h * .20f, m * .085f, 1.35f);
        }

        // ---------- Herramientas de campo (parte 2: cuadrícula)
        private void stakeout(Canvas cv, float w, float h) {
            float m = Math.min(w, h);
            int line = Color.rgb(90, 160, 235);
            float cx = w * .66f;
            stroke(line, 1.4f);
            cv.drawRoundRect(new RectF(cx - m * .16f, h * .04f, cx + m * .16f, h * .10f), 4, 4, s);
            cv.drawRect(cx - m * .20f, h * .10f, cx - m * .11f, h * .62f, s);
            cv.drawRect(cx + m * .11f, h * .10f, cx + m * .20f, h * .62f, s);
            cv.drawRoundRect(new RectF(cx - m * .10f, h * .16f, cx + m * .10f, h * .52f), 6, 6, s);
            cv.drawCircle(cx, h * .32f, m * .07f, s);
            cv.drawCircle(cx, h * .32f, m * .035f, s);
            cv.drawRect(cx - m * .30f, h * .58f, cx - m * .02f, h * .80f, s);
            for (int k = 0; k < 4; k++) cv.drawLine(cx - m * .27f, h * (.63f + k * .04f), cx - m * .05f, h * (.63f + k * .04f), s);
            cv.drawRoundRect(new RectF(cx - m * .22f, h * .80f, cx + m * .22f, h * .90f), 4, 4, s);
            cv.drawLine(cx - m * .12f, h * .90f, cx - m * .20f, h, s);
            cv.drawLine(cx + m * .12f, h * .90f, cx + m * .20f, h, s);
            float tx = w * .08f, ty = h * .70f, tr = m * .05f;
            stroke(Color.rgb(210, 225, 245), 1.2f);
            cv.drawCircle(tx, ty, tr, s);
            cv.drawLine(tx - tr * 1.8f, ty, tx + tr * 1.8f, ty, s);
            cv.drawLine(tx, ty - tr * 1.8f, tx, ty + tr * 1.8f, s);
            dashed(Color.rgb(210, 225, 245), 1.2f);
            cv.drawLine(tx + tr * 2f, ty, cx - m * .31f, ty, s);
        }

        private void quality(Canvas cv, float w, float h) {
            float m = Math.min(w, h);
            float cx = w * .58f, cy = h * .28f;
            cv.save();
            cv.rotate(35, cx, cy);
            f.setColor(Color.rgb(30, 70, 120));
            stroke(Color.rgb(120, 180, 240), 1.3f);
            RectF p1 = new RectF(cx - m * .40f, cy - m * .10f, cx - m * .14f, cy + m * .10f);
            RectF p2 = new RectF(cx + m * .14f, cy - m * .10f, cx + m * .40f, cy + m * .10f);
            cv.drawRect(p1, f); cv.drawRect(p1, s);
            cv.drawRect(p2, f); cv.drawRect(p2, s);
            cv.drawLine(cx - m * .27f, p1.top, cx - m * .27f, p1.bottom, s);
            cv.drawLine(cx + m * .27f, p2.top, cx + m * .27f, p2.bottom, s);
            cv.drawLine(cx - m * .14f, cy, cx + m * .14f, cy, s);
            f.setColor(Color.rgb(60, 110, 170));
            cv.drawRoundRect(new RectF(cx - m * .09f, cy - m * .07f, cx + m * .09f, cy + m * .07f), 4, 4, f);
            cv.drawRoundRect(new RectF(cx - m * .09f, cy - m * .07f, cx + m * .09f, cy + m * .07f), 4, 4, s);
            cv.restore();
            stroke(Color.rgb(70, 225, 160), 1.8f);
            for (int i = 0; i < 3; i++) {
                float rr = m * (.10f + i * .08f);
                cv.drawArc(new RectF(w * .32f - rr, h * .56f - rr, w * .32f + rr, h * .56f + rr), 110, 90, false, s);
            }
            for (int i = 0; i < 5; i++) {
                float bw = m * .05f, bx = w * .38f + i * m * .085f, bh = m * (.08f + i * .06f);
                f.setColor(i < 2 ? Color.rgb(70, 225, 160) : Color.rgb(60, 200, 220));
                cv.drawRoundRect(new RectF(bx, h * .95f - bh, bx + bw, h * .95f), 3, 3, f);
            }
        }

        private void external(Canvas cv, float w, float h) {
            float m = Math.min(w, h);
            float cx = w * .55f;
            f.setShader(new LinearGradient(0, h * .10f, 0, h * .35f,
                    Color.rgb(90, 140, 190), Color.rgb(30, 60, 100), Shader.TileMode.CLAMP));
            cv.drawArc(new RectF(cx - m * .30f, h * .05f, cx + m * .30f, h * .45f), 180, 180, true, f);
            f.setShader(null);
            f.setColor(Color.rgb(24, 48, 80));
            cv.drawRoundRect(new RectF(cx - m * .32f, h * .23f, cx + m * .32f, h * .31f), 6, 6, f);
            stroke(Color.rgb(140, 190, 240), 1.2f);
            cv.drawArc(new RectF(cx - m * .30f, h * .05f, cx + m * .30f, h * .45f), 180, 180, false, s);
            cv.drawRoundRect(new RectF(cx - m * .32f, h * .23f, cx + m * .32f, h * .31f), 6, 6, s);
            f.setColor(Color.rgb(30, 58, 92));
            cv.drawRect(cx - m * .035f, h * .31f, cx + m * .035f, h, f);
            cv.drawRect(cx - m * .035f, h * .31f, cx + m * .035f, h, s);
            float bx = w * .80f, by = h * .70f, br = m * .13f;
            f.setColor(Color.rgb(30, 110, 230));
            cv.drawCircle(bx, by, br, f);
            stroke(Color.WHITE, 1.8f);
            path.reset();
            path.moveTo(bx - br * .40f, by - br * .35f);
            path.lineTo(bx + br * .40f, by + br * .30f);
            path.lineTo(bx, by + br * .65f);
            path.lineTo(bx, by - br * .65f);
            path.lineTo(bx + br * .40f, by - br * .30f);
            path.lineTo(bx - br * .40f, by + br * .35f);
            cv.drawPath(path, s);
        }

        private void traverse(Canvas cv, float w, float h) {
            float m = Math.min(w, h);
            float[][] pts = {{.08f, .88f}, {.38f, .62f}, {.62f, .78f}, {.72f, .55f}, {.62f, .38f}, {.78f, .16f}};
            stroke(ACCENT, 2f);
            for (int i = 0; i < pts.length - 1; i++)
                cv.drawLine(pts[i][0] * w, pts[i][1] * h, pts[i + 1][0] * w, pts[i + 1][1] * h, s);
            dashed(Color.argb(170, 150, 200, 250), 1.2f);
            cv.drawLine(pts[5][0] * w, pts[5][1] * h, w * .98f, h * .44f, s);
            for (float[] pt : pts) node(cv, pt[0] * w, pt[1] * h, m * .035f);
            smallDot(cv, w * .98f, h * .44f, m * .025f);
        }

        private void leveling(Canvas cv, float w, float h) {
            float m = Math.min(w, h);
            stroke(Color.argb(170, 120, 180, 245), 1.3f);
            path.reset();
            path.moveTo(-w * .7f, h * .75f);
            path.cubicTo(-w * .4f, h * .45f, -w * .1f, h * .95f, w * .10f, h * .75f);
            path.cubicTo(w * .30f, h * .60f, w * .60f, h * .80f, w, h * .70f);
            cv.drawPath(path, s);
            staff(cv, w * .22f, h * .10f, h * 1.02f, m * .12f, true);
        }

        private void profile(Canvas cv, float w, float h) {
            float m = Math.min(w, h);
            stroke(Color.argb(180, 150, 190, 235), 1f);
            cv.drawLine(-w * .7f, h * .80f, w, h * .80f, s);
            stroke(Color.rgb(140, 200, 255), 1.6f);
            path.reset();
            path.moveTo(-w * .7f, h * .75f);
            path.cubicTo(-w * .3f, h * .50f, -w * .05f, h * .70f, w * .15f, h * .55f);
            path.cubicTo(w * .35f, h * .40f, w * .55f, h * .15f, w * .75f, h * .05f);
            path.lineTo(w, h * .20f);
            cv.drawPath(path, s);
            dashed(Color.argb(170, 180, 210, 240), 1f);
            float[] px = {-.25f, .15f, .55f};
            float[] py = {.60f, .55f, .20f};
            for (int i = 0; i < 3; i++) {
                cv.drawLine(w * px[i], h * py[i], w * px[i], h * .80f, s);
                smallDot(cv, w * px[i], h * py[i], m * .025f);
            }
            String[] marks = {"0+000", "0+500", "1+000"};
            for (int i = 0; i < 3; i++)
                label(cv, marks[i], w * px[i], h * .95f, m * .10f, Color.rgb(170, 195, 225), false, Paint.Align.CENTER);
        }

        private void offline(Canvas cv, float w, float h) {
            float m = Math.min(w, h);
            float cx = w * .45f;
            for (int i = 2; i >= 0; i--) {
                float oy = h * (.42f + i * .17f);
                path.reset();
                path.moveTo(cx - m * .42f, oy);
                path.lineTo(cx, oy - m * .20f);
                path.lineTo(cx + m * .42f, oy);
                path.lineTo(cx, oy + m * .20f);
                path.close();
                f.setColor(Color.argb(i == 0 ? 220 : 170, 20, 60, 110));
                cv.drawPath(path, f);
                stroke(Color.rgb(100, 160, 230), 1.2f);
                cv.drawPath(path, s);
                if (i == 0) {
                    stroke(Color.argb(140, 150, 200, 250), 1f);
                    cv.drawLine(cx - m * .25f, oy, cx + m * .05f, oy - m * .12f, s);
                    cv.drawLine(cx - m * .10f, oy + m * .10f, cx + m * .25f, oy - m * .02f, s);
                }
            }
            pin(cv, cx + m * .05f, h * .42f, m * .09f);
        }

        private void notebook(Canvas cv, float w, float h) {
            float m = Math.min(w, h);
            RectF book = new RectF(w * .20f, h * .10f, w * .62f, h * .98f);
            f.setColor(Color.argb(160, 14, 40, 72));
            cv.drawRoundRect(book, 6, 6, f);
            stroke(Color.rgb(120, 180, 240), 1.3f);
            cv.drawRoundRect(book, 6, 6, s);
            for (int i = 0; i < 7; i++) {
                float yy = book.top + (i + .7f) * book.height() / 7.5f;
                cv.drawRoundRect(new RectF(book.left - m * .05f, yy - m * .015f, book.left + m * .04f, yy + m * .015f), 3, 3, s);
            }
            for (int i = 0; i < 5; i++) {
                float yy = book.top + book.height() * (.22f + i * .13f);
                cv.drawLine(book.left + book.width() * .20f, yy, book.right - book.width() * .15f, yy, s);
            }
            cv.save();
            cv.rotate(28, w * .76f, h * .60f);
            f.setColor(Color.rgb(60, 120, 200));
            cv.drawRect(w * .73f, h * .15f, w * .79f, h * .85f, f);
            cv.drawRect(w * .73f, h * .15f, w * .79f, h * .85f, s);
            path.reset();
            path.moveTo(w * .73f, h * .85f); path.lineTo(w * .76f, h * .98f); path.lineTo(w * .79f, h * .85f); path.close();
            cv.drawPath(path, s);
            cv.restore();
        }
    }
}
