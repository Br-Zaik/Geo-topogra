package com.bph.geotopo;

import android.Manifest;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;

import org.maplibre.android.MapLibre;
import org.maplibre.android.annotations.IconFactory;
import org.maplibre.android.annotations.Marker;
import org.maplibre.android.annotations.MarkerOptions;
import org.maplibre.android.annotations.Polygon;
import org.maplibre.android.annotations.PolygonOptions;
import org.maplibre.android.annotations.Polyline;
import org.maplibre.android.annotations.PolylineOptions;
import org.maplibre.android.camera.CameraUpdateFactory;
import org.maplibre.android.geometry.LatLng;
import org.maplibre.android.geometry.LatLngBounds;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapView;
import org.maplibre.android.maps.Style;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TrackActivity extends BaseToolActivity {
    private static final int REQ_LOCATION = 9540;
    private static final int REQ_NOTIFICATION = 9541;
    private static final int REQ_EXPORT_CSV = 9542;
    private static final int REQ_EXPORT_GPX = 9543;
    private static final String KEY_POIS = "track_pois";
    private static final String TRACK_MAP_STYLE = "https://tiles.openfreemap.org/styles/bright";

    private TextView stateLabel;
    private TextView distanceValue;
    private TextView avgValue;
    private TextView gainValue;
    private TextView pointsValue;
    private TextView autoSaveLabel;
    private TrackStatusView statusView;
    private MapView trackMapView;
    private MapLibreMap trackMap;
    private TextView mapHintLabel;
    private TextView mapAccuracyLabel;
    private Button mapCenterButton;
    private Button mainActionButton;
    private Button stopButton;
    private Button poiButton;
    private String pendingExport;
    private boolean receiverRegistered;
    private boolean screenStarted;
    private boolean trackMapStyleReady;
    private boolean followLatest = true;
    private boolean mapInitialViewportSet;
    private int lastCenteredPointCount = -1;
    private double lastLiveLat = Double.NaN;
    private double lastLiveLon = Double.NaN;
    private float lastLiveAccuracy = -1f;
    private double smoothedLiveLat = Double.NaN;
    private double smoothedLiveLon = Double.NaN;
    private JSONArray latestMapPoints = new JSONArray();
    private JSONArray latestMapPois = new JSONArray();
    private boolean latestMapRunning;
    private boolean latestMapPaused;
    private Polyline routeGlowLine;
    private Polyline routeLine;
    private int lastRenderedRouteSize = -1;
    private double lastRenderedEndLat = Double.NaN;
    private double lastRenderedEndLon = Double.NaN;
    private Polygon routeAccuracyPolygon;
    private Marker routeStartMarker;
    private Marker routeCurrentMarker;
    private final List<Marker> routePoiMarkers = new ArrayList<>();

    private final Handler tickerHandler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (!screenStarted) return;
            refreshClockOnly();
            tickerHandler.postDelayed(this, 1000L);
        }
    };

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (intent != null && intent.hasExtra("lat") && intent.hasExtra("lon")) {
                lastLiveLat = intent.getDoubleExtra("lat", Double.NaN);
                lastLiveLon = intent.getDoubleExtra("lon", Double.NaN);
                lastLiveAccuracy = intent.getFloatExtra("accuracy", -1f);
                updateSmoothedLivePosition();
            }
            refresh();
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        MapLibre.getInstance(this);
        MapEngineConfig.configure(this);

        LinearLayout root = vertical();
        root.setBackgroundColor(bgColor);
        root.addView(trackTopBar());

        LinearLayout content = vertical();
        content.addView(buildInfoCard());
        content.addView(buildStatusCard());
        content.addView(buildMapCard(savedInstanceState));
        content.addView(buildExportCard());

        autoSaveLabel = text("☁  Se guarda automáticamente con cada punto GPS", 11, false);
        autoSaveLabel.setTextColor(withAlpha(subTextColor, 190));
        autoSaveLabel.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        saveLp.setMargins(dp(4), dp(2), dp(4), dp(10));
        autoSaveLabel.setLayoutParams(saveLp);
        content.addView(autoSaveLabel);

        root.addView(scrollWith(content), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        refresh();
    }

    private LinearLayout trackTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(8), dp(8), dp(8));
        bar.setBackgroundColor(barColor);

        Button back = new Button(this);
        back.setText("‹");
        back.setTextSize(30);
        back.setTextColor(Color.WHITE);
        back.setBackgroundColor(Color.TRANSPARENT);
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(50), dp(50)));

        LinearLayout titles = vertical();
        TextView title = text("Registro de recorrido GPS", 20, true);
        title.setTextColor(Color.WHITE);
        titles.addView(title);
        TextView sub = text("Seguimiento iniciado por el usuario con notificación permanente", 12, false);
        sub.setTextColor(Color.rgb(215, 228, 240));
        sub.setMaxLines(2);
        titles.addView(sub);
        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView info = text("i", 18, true);
        info.setTextColor(accent);
        info.setGravity(Gravity.CENTER);
        GradientDrawable infoBg = new GradientDrawable();
        infoBg.setColor(Color.TRANSPARENT);
        infoBg.setShape(GradientDrawable.OVAL);
        infoBg.setStroke(dp(2), accent);
        info.setBackground(infoBg);
        info.setOnClickListener(v -> showTrackInfo());
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(dp(42), dp(42));
        infoLp.setMargins(dp(5), 0, dp(4), 0);
        bar.addView(info, infoLp);
        return bar;
    }

    private View buildInfoCard() {
        LinearLayout box = card();
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(14), dp(14), dp(14), dp(14));

        TextView icon = text("⌖", 24, true);
        icon.setTextColor(accent);
        icon.setGravity(Gravity.CENTER);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setColor(withAlpha(accent, themeMode == 0 ? 20 : 38));
        iconBg.setCornerRadius(dp(26));
        iconBg.setStroke(dp(1), accent);
        icon.setBackground(iconBg);
        box.addView(icon, new LinearLayout.LayoutParams(dp(54), dp(54)));

        LinearLayout labels = vertical();
        labels.setPadding(dp(13), 0, dp(3), 0);
        TextView msg = text("Inicia el recorrido antes de caminar. Android mostrará una notificación y GeoTopo seguirá registrando aun con la pantalla apagada.", 13, false);
        msg.setTextColor(subTextColor);
        msg.setLineSpacing(0, 1.13f);
        labels.addView(msg);
        TextView privacy = text("El registro solo se activa al pulsar Iniciar y finaliza al pulsar Detener.", 11, false);
        privacy.setTextColor(withAlpha(subTextColor, 190));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pp.setMargins(0, dp(6), 0, 0);
        privacy.setLayoutParams(pp);
        labels.addView(privacy);
        box.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return box;
    }

    private View buildStatusCard() {
        LinearLayout box = card();
        box.setPadding(dp(12), dp(12), dp(12), dp(12));

        LinearLayout header = horizontal();
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(text("Estado del registro", 18, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        stateLabel = text("● DETENIDO", 13, true);
        ResponsiveUi.configureCompactText(stateLabel, 13, 9, 1);
        stateLabel.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        header.addView(stateLabel, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        box.addView(header);

        LinearLayout dashboard = horizontal();
        dashboard.setGravity(Gravity.CENTER_VERTICAL);
        statusView = new TrackStatusView(this);
        int statusSize = ResponsiveUi.isNarrow(this) ? dp(124) : dp(158);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(statusSize, statusSize);
        statusLp.setMargins(dp(2), dp(2), dp(8), dp(4));
        dashboard.addView(statusView, statusLp);

        LinearLayout metrics = vertical();
        LinearLayout row1 = horizontal();
        distanceValue = text("0.00 m", 17, true);
        row1.addView(metricCard("⌁", "Distancia", distanceValue), metricWeight());
        avgValue = text("0.00 km/h", 17, true);
        row1.addView(metricCard("◴", "Vel. media", avgValue), metricWeight());
        metrics.addView(row1);
        LinearLayout row2 = horizontal();
        gainValue = text("0.0 m", 17, true);
        row2.addView(metricCard("△", "Desnivel +", gainValue), metricWeight());
        pointsValue = text("0", 17, true);
        row2.addView(metricCard("○", "Puntos", pointsValue), metricWeight());
        metrics.addView(row2);
        dashboard.addView(metrics, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        box.addView(dashboard);

        mainActionButton = primaryButton("▶  Iniciar nuevo recorrido");
        mainActionButton.setOnClickListener(v -> {
            SharedPreferences sp = getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE);
            if (sp.getBoolean(TrackService.KEY_RUNNING, false)) togglePause(); else startTrack();
        });
        LinearLayout.LayoutParams mainLp = (LinearLayout.LayoutParams) mainActionButton.getLayoutParams();
        mainLp.height = dp(58);
        mainActionButton.setLayoutParams(mainLp);
        box.addView(mainActionButton);

        stopButton = dangerOutlineButton("■  Detener recorrido");
        LinearLayout.LayoutParams stopLp = (LinearLayout.LayoutParams) stopButton.getLayoutParams();
        stopLp.height = dp(54);
        stopButton.setLayoutParams(stopLp);
        stopButton.setOnClickListener(v -> stopTrack());
        box.addView(stopButton);

        poiButton = secondaryButton("⚑  Marcar punto de interés");
        LinearLayout.LayoutParams poiLp = (LinearLayout.LayoutParams) poiButton.getLayoutParams();
        poiLp.height = dp(54);
        poiButton.setLayoutParams(poiLp);
        poiButton.setOnClickListener(v -> markPointOfInterest());
        box.addView(poiButton);
        return box;
    }

    private View metricCard(String iconText, String labelText, TextView valueView) {
        LinearLayout box = vertical();
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(10), dp(9), dp(9), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == 0 ? Color.rgb(248, 251, 255) : Color.rgb(11, 31, 49));
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), withAlpha(borderColor, 105));
        box.setBackground(bg);

        LinearLayout titleRow = horizontal();
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = text(iconText, 13, true);
        icon.setTextColor(accent);
        icon.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.addView(icon, new LinearLayout.LayoutParams(dp(22), dp(24)));
        TextView label = text(labelText, 10, false);
        label.setTextColor(subTextColor);
        label.setSingleLine(true);
        ResponsiveUi.configureCompactText(label, 10.5f, 9f, 1);
        titleRow.addView(label, new LinearLayout.LayoutParams(0, dp(24), 1f));
        box.addView(titleRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));

        valueView.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        valueView.setSingleLine(true);
        ResponsiveUi.configureCompactText(valueView, 17f, 13f, 1);
        box.addView(valueView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(32)));
        return box;
    }

    private LinearLayout.LayoutParams metricWeight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(74), 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        return lp;
    }

    private View buildMapCard(Bundle savedInstanceState) {
        LinearLayout box = card();
        box.setPadding(dp(10), dp(10), dp(10), dp(10));

        LinearLayout header = horizontal();
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(text("Mapa del recorrido", 17, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        mapCenterButton = secondaryButton(ResponsiveUi.isNarrow(this) ? "◎  Seguir" : "◎  Seguir ubicación");
        mapCenterButton.setOnClickListener(v -> {
            followLatest = true;
            centerTrackMapOnLatest(true);
            updateMapCenterButton();
        });
        LinearLayout.LayoutParams centerLp = new LinearLayout.LayoutParams(ResponsiveUi.isNarrow(this) ? dp(118) : dp(185), dp(44));
        centerLp.setMargins(dp(3), 0, 0, 0);
        mapCenterButton.setLayoutParams(centerLp);
        header.addView(mapCenterButton);
        box.addView(header);

        mapAccuracyLabel = text("Pulsa Iniciar para registrar el recorrido", 12, true);
        mapAccuracyLabel.setTextColor(subTextColor);
        mapAccuracyLabel.setGravity(Gravity.CENTER_VERTICAL);
        mapAccuracyLabel.setPadding(dp(10), dp(6), dp(10), dp(6));
        GradientDrawable qualityBg = new GradientDrawable();
        qualityBg.setColor(themeMode == 0 ? Color.rgb(244, 248, 252) : Color.rgb(8, 30, 48));
        qualityBg.setCornerRadius(dp(12));
        qualityBg.setStroke(dp(1), withAlpha(borderColor, 95));
        mapAccuracyLabel.setBackground(qualityBg);
        LinearLayout.LayoutParams qualityLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        qualityLp.setMargins(0, dp(7), 0, dp(7));
        box.addView(mapAccuracyLabel, qualityLp);

        FrameLayout mapFrame = new FrameLayout(this);
        GradientDrawable frameBg = new GradientDrawable();
        frameBg.setColor(themeMode == 0 ? Color.rgb(232, 239, 244) : Color.rgb(7, 24, 38));
        frameBg.setCornerRadius(dp(14));
        frameBg.setStroke(dp(1), withAlpha(accent, 145));
        mapFrame.setBackground(frameBg);
        mapFrame.setClipToOutline(true);

        trackMapView = new MapView(this);
        trackMapView.onCreate(savedInstanceState);
        trackMapView.addOnDidFailLoadingMapListener(error -> runOnUiThread(() -> {
            if (mapHintLabel != null) {
                mapHintLabel.setText("No se pudo cargar el mapa. El recorrido GPS sigue registrándose.");
                mapHintLabel.setVisibility(View.VISIBLE);
            }
        }));
        mapFrame.addView(trackMapView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        mapHintLabel = text("Esperando posición GPS…", 13, true);
        mapHintLabel.setTextColor(Color.WHITE);
        mapHintLabel.setGravity(Gravity.CENTER);
        mapHintLabel.setPadding(dp(12), dp(7), dp(12), dp(7));
        GradientDrawable hintBg = new GradientDrawable();
        hintBg.setColor(Color.argb(210, 8, 28, 44));
        hintBg.setCornerRadius(dp(14));
        mapHintLabel.setBackground(hintBg);
        FrameLayout.LayoutParams hintLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        hintLp.setMargins(dp(12), 0, dp(12), dp(12));
        mapFrame.addView(mapHintLabel, hintLp);

        int mapHeight = ResponsiveUi.isNarrow(this) ? dp(260) : dp(305);
        box.addView(mapFrame, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, mapHeight));

        trackMapView.setOnTouchListener((v, event) -> {
            int action = event.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) {
                followLatest = false;
                updateMapCenterButton();
            }
            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE || action == MotionEvent.ACTION_POINTER_DOWN) {
                if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(true);
            } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(false);
            }
            return false;
        });

        trackMapView.getMapAsync(map -> {
            trackMap = map;
            trackMap.getUiSettings().setCompassEnabled(false);
            trackMap.getUiSettings().setLogoEnabled(false);
            trackMap.getUiSettings().setAttributionEnabled(true);
            trackMap.getUiSettings().setAllGesturesEnabled(true);
            trackMap.setMinZoomPreference(2.0);
            trackMap.setMaxZoomPreference(20.0);
            trackMap.setStyle(new Style.Builder().fromUri(TRACK_MAP_STYLE), style -> {
                trackMapStyleReady = true;
                renderTrackMap();
                if (!mapInitialViewportSet) centerMapOnLastKnownLocation();
            });
        });
        return box;
    }

    private View buildExportCard() {
        LinearLayout box = card();
        box.setPadding(dp(12), dp(10), dp(12), dp(10));
        box.addView(sectionTitle("Exportar y gestionar"));

        LinearLayout buttons = horizontal();
        Button csv = secondaryButton("▤  Exportar CSV");
        csv.setOnClickListener(v -> export(false));
        buttons.addView(csv, weight());
        Button gpx = secondaryButton("⌁  Exportar GPX");
        gpx.setOnClickListener(v -> export(true));
        buttons.addView(gpx, weight());
        Button clear = dangerOutlineButton("⌫  Borrar recorrido");
        clear.setOnClickListener(v -> clearTrack());
        buttons.addView(clear, weight());
        box.addView(buttons);
        return box;
    }

    private Button dangerOutlineButton(String label) {
        Button button = secondaryButton(label);
        button.setTextColor(Color.rgb(255, 92, 101));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == 0 ? Color.rgb(255, 248, 249) : Color.rgb(34, 17, 27));
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Color.rgb(255, 73, 86));
        button.setBackground(bg);
        return button;
    }

    private void showTrackInfo() {
        new AlertDialog.Builder(this)
                .setTitle("Registro de recorrido GPS")
                .setMessage("El recorrido se inicia únicamente cuando pulsas Iniciar. Mientras está activo, Android mantiene una notificación visible y GeoTopo registra los puntos GPS incluso con la pantalla apagada. Puedes pausar, reanudar, marcar puntos de interés, detener y exportar el trabajo en CSV o GPX.")
                .setPositiveButton("Entendido", null)
                .show();
    }

    @Override protected void onResume() {
        super.onResume();
        if (trackMapView != null) trackMapView.onResume();
    }

    @Override protected void onPause() {
        if (trackMapView != null) trackMapView.onPause();
        super.onPause();
    }

    @Override public void onLowMemory() {
        super.onLowMemory();
        if (trackMapView != null) trackMapView.onLowMemory();
    }

    @Override protected void onDestroy() {
        if (trackMapView != null) trackMapView.onDestroy();
        super.onDestroy();
    }

    @Override protected void onStart() {
        super.onStart();
        if (trackMapView != null) trackMapView.onStart();
        IntentFilter filter = new IntentFilter(TrackService.ACTION_UPDATE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, filter);
        receiverRegistered = true;
        screenStarted = true;
        tickerHandler.removeCallbacks(ticker);
        tickerHandler.post(ticker);
        refresh();
    }

    @Override protected void onStop() {
        screenStarted = false;
        tickerHandler.removeCallbacks(ticker);
        if (receiverRegistered) { unregisterReceiver(receiver); receiverRegistered = false; }
        if (trackMapView != null) trackMapView.onStop();
        super.onStop();
    }

    private void startTrack() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATION);
            return;
        }
        getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE).edit().remove(KEY_POIS).apply();
        followLatest = true;
        mapInitialViewportSet = false;
        lastCenteredPointCount = -1;
        lastLiveLat = Double.NaN;
        lastLiveLon = Double.NaN;
        lastLiveAccuracy = -1f;
        smoothedLiveLat = Double.NaN;
        smoothedLiveLon = Double.NaN;
        updateMapCenterButton();
        Intent i = new Intent(this, TrackService.class);
        i.setAction(TrackService.ACTION_START);
        i.putExtra("reset", true);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        showToast("Recorrido iniciado.");
        refreshDelayed();
    }

    private void togglePause() {
        SharedPreferences sp = getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE);
        if (!sp.getBoolean(TrackService.KEY_RUNNING, false)) { showToast("No hay recorrido activo."); return; }
        boolean paused = sp.getBoolean(TrackService.KEY_PAUSED, false);
        Intent i = new Intent(this, TrackService.class);
        i.setAction(paused ? TrackService.ACTION_RESUME : TrackService.ACTION_PAUSE);
        startService(i);
        refreshDelayed();
    }

    private void stopTrack() {
        SharedPreferences sp = getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE);
        if (!sp.getBoolean(TrackService.KEY_RUNNING, false)) { showToast("No hay recorrido activo."); return; }
        Intent i = new Intent(this, TrackService.class);
        i.setAction(TrackService.ACTION_STOP);
        startService(i);
        refreshDelayed();
    }

    private void refreshDelayed() {
        if (statusView != null) statusView.postDelayed(this::refresh, 350L);
    }

    private void refreshClockOnly() {
        SharedPreferences sp = getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE);
        boolean running = sp.getBoolean(TrackService.KEY_RUNNING, false);
        boolean paused = sp.getBoolean(TrackService.KEY_PAUSED, false);
        long start = sp.getLong(TrackService.KEY_START, 0L);
        long pausedAt = sp.getLong(TrackService.KEY_PAUSED_AT, 0L);
        long pausedTotal = sp.getLong(TrackService.KEY_PAUSED_TOTAL, 0L);
        long now = running ? System.currentTimeMillis() : sp.getLong(TrackService.KEY_END, System.currentTimeMillis());
        long currentPause = paused && pausedAt > 0 ? Math.max(0, now - pausedAt) : 0;
        long duration = start > 0 ? Math.max(0, now - start - pausedTotal - currentPause) : 0;
        String state = running ? (paused ? "PAUSADO" : "REGISTRANDO") : "DETENIDO";
        int stateColor = running && !paused ? Color.rgb(83, 216, 118) : (paused ? Color.rgb(255, 184, 52) : Color.rgb(129, 202, 97));
        if (stateLabel != null) {
            stateLabel.setText("● " + state);
            stateLabel.setTextColor(stateColor);
        }
        if (statusView != null) statusView.setState(state, duration, stateColor);
    }

    private void refresh() {
        SharedPreferences sp = getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE);
        boolean running = sp.getBoolean(TrackService.KEY_RUNNING, false);
        boolean paused = sp.getBoolean(TrackService.KEY_PAUSED, false);
        long start = sp.getLong(TrackService.KEY_START, 0L);
        long pausedAt = sp.getLong(TrackService.KEY_PAUSED_AT, 0L);
        long pausedTotal = sp.getLong(TrackService.KEY_PAUSED_TOTAL, 0L);
        double distance = Double.longBitsToDouble(sp.getLong(TrackService.KEY_DISTANCE, Double.doubleToLongBits(0)));
        JSONArray points = readArray(sp, TrackService.KEY_POINTS);
        JSONArray pois = readArray(sp, KEY_POIS);
        long now = running ? System.currentTimeMillis() : sp.getLong(TrackService.KEY_END, System.currentTimeMillis());
        long currentPause = paused && pausedAt > 0 ? Math.max(0, now - pausedAt) : 0;
        long duration = start > 0 ? Math.max(0, now - start - pausedTotal - currentPause) : 0;
        double hours = duration / 3600000.0;
        double avg = hours > 0 ? distance / 1000.0 / hours : 0;
        double elevationGain = calculateElevationGain(points);

        String state = running ? (paused ? "PAUSADO" : "REGISTRANDO") : "DETENIDO";
        int stateColor = running && !paused ? Color.rgb(83, 216, 118) : (paused ? Color.rgb(255, 184, 52) : Color.rgb(129, 202, 97));
        if (stateLabel != null) {
            stateLabel.setText("● " + state);
            stateLabel.setTextColor(stateColor);
        }
        if (statusView != null) statusView.setState(state, duration, stateColor);
        if (distanceValue != null) distanceValue.setText(formatDistance(distance));
        if (avgValue != null) avgValue.setText(f2(avg) + " km/h");
        if (gainValue != null) gainValue.setText(f1(elevationGain) + " m");
        if (pointsValue != null) pointsValue.setText(String.valueOf(points.length()));
        updateTrackMap(points, pois, running, paused);

        if (mainActionButton != null) {
            mainActionButton.setText(!running ? "▶  Iniciar nuevo recorrido" : (paused ? "▶  Reanudar recorrido" : "Ⅱ  Pausar recorrido"));
            mainActionButton.setEnabled(true);
        }
        if (stopButton != null) stopButton.setEnabled(running);
        if (poiButton != null) poiButton.setEnabled(points.length() > 0);
    }

    private void updateTrackMap(JSONArray points, JSONArray pois, boolean running, boolean paused) {
        latestMapPoints = points == null ? new JSONArray() : points;
        latestMapPois = pois == null ? new JSONArray() : pois;
        latestMapRunning = running;
        latestMapPaused = paused;
        updateTrackMapStatus();
        renderTrackMap();
    }

    private void updateTrackMapStatus() {
        if (mapAccuracyLabel == null) return;
        int pointCount = latestMapPoints == null ? 0 : latestMapPoints.length();
        float accuracy = lastLiveAccuracy;
        if (accuracy <= 0 && pointCount > 0) {
            JSONObject last = latestMapPoints.optJSONObject(pointCount - 1);
            if (last != null && !last.isNull("acc")) accuracy = (float) last.optDouble("acc", -1);
        }

        String label;
        int color;
        if (!latestMapRunning && pointCount == 0) {
            label = "Pulsa Iniciar para registrar el recorrido";
            color = subTextColor;
        } else if (latestMapPaused) {
            label = "Recorrido pausado · el mapa conserva la última posición";
            color = Color.rgb(255, 184, 52);
        } else if (latestMapRunning && accuracy > 50f) {
            label = "GPS débil · ±" + String.format(Locale.US, "%.0f", accuracy) + " m · esperando mejor precisión";
            color = Color.rgb(255, 106, 116);
        } else if (latestMapRunning && pointCount == 0) {
            label = "Buscando una posición GPS suficientemente precisa…";
            color = Color.rgb(255, 184, 52);
        } else if (accuracy > 25f) {
            label = "Precisión baja · ±" + String.format(Locale.US, "%.0f", accuracy) + " m · ruta registrada con cautela";
            color = Color.rgb(255, 184, 52);
        } else if (accuracy > 0f) {
            label = "GPS activo · ±" + String.format(Locale.US, "%.0f", accuracy) + " m · " + pointCount + " puntos";
            color = Color.rgb(76, 210, 126);
        } else {
            label = pointCount + " puntos registrados";
            color = subTextColor;
        }
        mapAccuracyLabel.setText(label);
        mapAccuracyLabel.setTextColor(color);

        if (mapHintLabel != null) {
            if (pointCount == 0) {
                mapHintLabel.setVisibility(View.VISIBLE);
                mapHintLabel.setText(latestMapRunning ? "Esperando primera posición GPS…" : "El mapa mostrará tu recorrido al iniciar");
            } else {
                mapHintLabel.setVisibility(View.GONE);
            }
        }
        updateMapCenterButton();
    }

    private void updateMapCenterButton() {
        if (mapCenterButton == null) return;
        String text = followLatest ? (ResponsiveUi.isNarrow(this) ? "◎  Siguiendo" : "◎  Siguiendo ubicación")
                : (ResponsiveUi.isNarrow(this) ? "◎  Seguir" : "◎  Seguir ubicación");
        mapCenterButton.setText(text);
    }

    private void renderTrackMap() {
        if (trackMap == null || !trackMapStyleReady) return;
        List<LatLng> routePoints = new ArrayList<>();
        for (int i = 0; i < latestMapPoints.length(); i++) {
            JSONObject p = latestMapPoints.optJSONObject(i);
            if (p == null) continue;
            double lat = p.optDouble("lat", Double.NaN);
            double lon = p.optDouble("lon", Double.NaN);
            if (!Double.isFinite(lat) || !Double.isFinite(lon)) continue;
            routePoints.add(new LatLng(lat, lon));
        }

        // Avoid removing and recreating the route on every GPS refresh.
        // Rebuilding the polyline causes visible blue-line flicker on the map.
        if (!routePoints.isEmpty()) {
            LatLng end = routePoints.get(routePoints.size() - 1);
            if (routePoints.size() == lastRenderedRouteSize
                    && Double.compare(end.getLatitude(), lastRenderedEndLat) == 0
                    && Double.compare(end.getLongitude(), lastRenderedEndLon) == 0) {
                return;
            }
        }
        clearTrackMapAnnotations();
        if (!routePoints.isEmpty()) {
            LatLng end = routePoints.get(routePoints.size() - 1);
            lastRenderedRouteSize = routePoints.size();
            lastRenderedEndLat = end.getLatitude();
            lastRenderedEndLon = end.getLongitude();
        }

        if (routePoints.size() >= 2) {
            List<LatLng> displayRoute = smoothRouteForDisplay(routePoints);
            // Draw a single clean route line. The previous glow layer created a blue halo
            // that looked like a border and made the track appear to flicker.
            PolylineOptions lineOptions = new PolylineOptions()
                    .color(Color.rgb(25, 132, 255))
                    .width(4.8f);
            for (LatLng point : displayRoute) {
                lineOptions.add(point);
            }
            routeLine = trackMap.addPolyline(lineOptions);
            routeGlowLine = null;
        }

        if (!routePoints.isEmpty()) {
            LatLng first = routePoints.get(0);
            routeStartMarker = trackMap.addMarker(new MarkerOptions()
                    .position(first)
                    .title("Inicio")
                    .icon(IconFactory.getInstance(this).fromBitmap(createTrackDotBitmap(Color.rgb(50, 200, 105), false))));
        }

        LatLng current = chooseCurrentMapPosition(routePoints);
        if (current != null) {
            float accuracy = effectiveMapAccuracy();
            if (accuracy > 0f && accuracy <= 35f) {
                routeAccuracyPolygon = trackMap.addPolygon(new PolygonOptions()
                        .addAll(buildAccuracyCircle(current, accuracy))
                        .fillColor(Color.argb(18, 66, 133, 244))
                        .strokeColor(Color.argb(78, 66, 133, 244)));
            }
            int currentColor = latestMapPaused ? Color.rgb(255, 184, 52) : Color.rgb(41, 121, 255);
            String title = latestMapPaused ? "Última posición · pausado" : "Tu ubicación";
            routeCurrentMarker = trackMap.addMarker(new MarkerOptions()
                    .position(current)
                    .title(title)
                    .icon(IconFactory.getInstance(this).fromBitmap(createTrackDotBitmap(currentColor, true))));
        }

        for (int i = 0; i < latestMapPois.length(); i++) {
            JSONObject p = latestMapPois.optJSONObject(i);
            if (p == null) continue;
            double lat = p.optDouble("lat", Double.NaN);
            double lon = p.optDouble("lon", Double.NaN);
            if (!Double.isFinite(lat) || !Double.isFinite(lon)) continue;
            String label = p.optString("label", "P" + (i + 1));
            Marker marker = trackMap.addMarker(new MarkerOptions()
                    .position(new LatLng(lat, lon))
                    .title("Punto de interés " + label)
                    .icon(IconFactory.getInstance(this).fromBitmap(createTrackPoiBitmap())));
            routePoiMarkers.add(marker);
        }

        int pointCount = routePoints.size();
        if (latestMapRunning && followLatest && current != null) {
            centerTrackMapOnLatest(false);
            lastCenteredPointCount = pointCount;
        } else if (!mapInitialViewportSet && !routePoints.isEmpty()) {
            fitTrackMap(routePoints);
        }
    }

    private List<LatLng> smoothRouteForDisplay(List<LatLng> source) {
        if (source == null || source.size() < 3) return source == null ? new ArrayList<>() : source;
        List<LatLng> result = new ArrayList<>();
        result.add(source.get(0));
        for (int i = 1; i < source.size() - 1; i++) {
            LatLng prev = source.get(i - 1);
            LatLng cur = source.get(i);
            LatLng next = source.get(i + 1);
            double lat = prev.getLatitude() * 0.18 + cur.getLatitude() * 0.64 + next.getLatitude() * 0.18;
            double lon = prev.getLongitude() * 0.18 + cur.getLongitude() * 0.64 + next.getLongitude() * 0.18;
            result.add(new LatLng(lat, lon));
        }
        result.add(source.get(source.size() - 1));
        return result;
    }

    private LatLng chooseCurrentMapPosition(List<LatLng> routePoints) {
        if (Double.isFinite(smoothedLiveLat) && Double.isFinite(smoothedLiveLon) && lastLiveAccuracy > 0f && lastLiveAccuracy <= 50f) {
            return new LatLng(smoothedLiveLat, smoothedLiveLon);
        }
        return routePoints.isEmpty() ? null : routePoints.get(routePoints.size() - 1);
    }

    private void updateSmoothedLivePosition() {
        if (!Double.isFinite(lastLiveLat) || !Double.isFinite(lastLiveLon) || lastLiveAccuracy <= 0f || lastLiveAccuracy > 50f) return;
        if (!Double.isFinite(smoothedLiveLat) || !Double.isFinite(smoothedLiveLon)) {
            smoothedLiveLat = lastLiveLat;
            smoothedLiveLon = lastLiveLon;
            return;
        }
        double alpha;
        if (lastLiveAccuracy <= 8f) alpha = 0.50;
        else if (lastLiveAccuracy <= 20f) alpha = 0.34;
        else alpha = 0.22;
        smoothedLiveLat += (lastLiveLat - smoothedLiveLat) * alpha;
        smoothedLiveLon += (lastLiveLon - smoothedLiveLon) * alpha;
    }

    private float effectiveMapAccuracy() {
        if (lastLiveAccuracy > 0f) return lastLiveAccuracy;
        if (latestMapPoints.length() > 0) {
            JSONObject last = latestMapPoints.optJSONObject(latestMapPoints.length() - 1);
            if (last != null && !last.isNull("acc")) return (float) last.optDouble("acc", -1);
        }
        return -1f;
    }

    private void centerTrackMapOnLatest(boolean force) {
        if (trackMap == null || !trackMapStyleReady) return;
        List<LatLng> routePoints = new ArrayList<>();
        for (int i = 0; i < latestMapPoints.length(); i++) {
            JSONObject p = latestMapPoints.optJSONObject(i);
            if (p == null) continue;
            double lat = p.optDouble("lat", Double.NaN);
            double lon = p.optDouble("lon", Double.NaN);
            if (Double.isFinite(lat) && Double.isFinite(lon)) routePoints.add(new LatLng(lat, lon));
        }
        LatLng current = chooseCurrentMapPosition(routePoints);
        if (current == null) {
            centerMapOnLastKnownLocation();
            return;
        }
        double currentZoom = trackMap.getCameraPosition().zoom;
        double zoom = force || currentZoom < 14.0 ? 16.5 : Math.min(19.0, currentZoom);
        trackMap.animateCamera(CameraUpdateFactory.newLatLngZoom(current, zoom), force ? 550 : 380);
        mapInitialViewportSet = true;
    }

    private void fitTrackMap(List<LatLng> routePoints) {
        if (trackMap == null || routePoints == null || routePoints.isEmpty()) return;
        if (routePoints.size() == 1) {
            trackMap.animateCamera(CameraUpdateFactory.newLatLngZoom(routePoints.get(0), 16.5), 450);
        } else {
            try {
                LatLngBounds.Builder builder = new LatLngBounds.Builder();
                for (LatLng p : routePoints) builder.include(p);
                trackMap.animateCamera(CameraUpdateFactory.newLatLngBounds(builder.build(), dp(42)), 500);
            } catch (Exception ignored) {
                trackMap.animateCamera(CameraUpdateFactory.newLatLngZoom(routePoints.get(routePoints.size() - 1), 16.0), 450);
            }
        }
        mapInitialViewportSet = true;
    }

    private void centerMapOnLastKnownLocation() {
        if (trackMap == null || mapInitialViewportSet) return;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        try {
            LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            if (lm == null) return;
            Location best = null;
            for (String provider : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}) {
                Location loc = lm.getLastKnownLocation(provider);
                if (loc == null) continue;
                if (best == null || loc.getTime() > best.getTime()) best = loc;
            }
            if (best != null) {
                trackMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(best.getLatitude(), best.getLongitude()), 15.5));
                mapInitialViewportSet = true;
            }
        } catch (SecurityException ignored) { }
    }

    private void clearTrackMapAnnotations() {
        if (trackMap == null) return;
        try { if (routeGlowLine != null) trackMap.removePolyline(routeGlowLine); } catch (Exception ignored) { }
        try { if (routeLine != null) trackMap.removePolyline(routeLine); } catch (Exception ignored) { }
        try { if (routeAccuracyPolygon != null) trackMap.removePolygon(routeAccuracyPolygon); } catch (Exception ignored) { }
        try { if (routeStartMarker != null) trackMap.removeMarker(routeStartMarker); } catch (Exception ignored) { }
        try { if (routeCurrentMarker != null) trackMap.removeMarker(routeCurrentMarker); } catch (Exception ignored) { }
        for (Marker marker : routePoiMarkers) {
            try { trackMap.removeMarker(marker); } catch (Exception ignored) { }
        }
        routeGlowLine = null;
        routeLine = null;
        routeAccuracyPolygon = null;
        routeStartMarker = null;
        routeCurrentMarker = null;
        routePoiMarkers.clear();
    }

    private Bitmap createTrackDotBitmap(int color, boolean current) {
        int size = dp(current ? 34 : 28);
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float c = size / 2f;
        p.setColor(Color.argb(current ? 55 : 35, Color.red(color), Color.green(color), Color.blue(color)));
        canvas.drawCircle(c, c, dp(current ? 14f : 11f), p);
        p.setColor(Color.WHITE);
        canvas.drawCircle(c, c, dp(current ? 8f : 7f), p);
        p.setColor(color);
        canvas.drawCircle(c, c, dp(current ? 5.7f : 4.8f), p);
        return bitmap;
    }

    private Bitmap createTrackPoiBitmap() {
        int size = dp(30);
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float c = size / 2f;
        p.setColor(Color.WHITE);
        canvas.drawCircle(c, c, dp(9f), p);
        p.setColor(Color.rgb(255, 171, 0));
        canvas.drawCircle(c, c, dp(6.5f), p);
        p.setColor(Color.WHITE);
        p.setStrokeWidth(dp(2));
        canvas.drawLine(c, c + dp(6), c, c + dp(12), p);
        return bitmap;
    }

    private List<LatLng> buildAccuracyCircle(LatLng center, float radiusMeters) {
        List<LatLng> ring = new ArrayList<>();
        double latRad = Math.toRadians(center.getLatitude());
        double metersPerDegLat = 111320.0;
        double metersPerDegLon = Math.max(1.0, 111320.0 * Math.cos(latRad));
        for (int i = 0; i <= 48; i++) {
            double a = Math.toRadians(i * 360.0 / 48.0);
            double dLat = Math.sin(a) * radiusMeters / metersPerDegLat;
            double dLon = Math.cos(a) * radiusMeters / metersPerDegLon;
            ring.add(new LatLng(center.getLatitude() + dLat, center.getLongitude() + dLon));
        }
        return ring;
    }

    private JSONArray readArray(SharedPreferences sp, String key) {
        try { return new JSONArray(sp.getString(key, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private double calculateElevationGain(JSONArray points) {
        double gain = 0.0;
        Double anchor = null;
        for (int i = 0; i < points.length(); i++) {
            JSONObject p = points.optJSONObject(i);
            if (p == null || p.isNull("alt")) continue;
            double alt = p.optDouble("alt", Double.NaN);
            if (!Double.isFinite(alt)) continue;

            double verticalAccuracy = p.isNull("vacc") ? Double.NaN : p.optDouble("vacc", Double.NaN);
            if (Double.isFinite(verticalAccuracy) && verticalAccuracy > 35.0) continue;
            double deadband = Double.isFinite(verticalAccuracy)
                    ? Math.max(1.8, Math.min(6.0, verticalAccuracy * 0.35))
                    : 2.8;

            if (anchor == null) {
                anchor = alt;
                continue;
            }
            double delta = alt - anchor;
            if (delta >= deadband) {
                gain += delta;
                anchor = alt;
            } else if (delta <= -deadband) {
                anchor = alt;
            }
        }
        return gain;
    }

    private String formatDistance(double meters) {
        return meters >= 1000.0 ? f2(meters / 1000.0) + " km" : f2(meters) + " m";
    }

    private String formatDuration(long millis) {
        long seconds = millis / 1000;
        long h = seconds / 3600;
        long m = (seconds % 3600) / 60;
        long s = seconds % 60;
        return String.format(Locale.US, "%02d:%02d:%02d", h, m, s);
    }

    private void markPointOfInterest() {
        SharedPreferences sp = getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE);
        JSONArray points = readArray(sp, TrackService.KEY_POINTS);
        if (points.length() == 0) { showToast("Aún no hay una posición GPS para marcar."); return; }
        JSONObject last = points.optJSONObject(points.length() - 1);
        if (last == null) return;
        JSONArray pois = readArray(sp, KEY_POIS);
        try {
            JSONObject poi = new JSONObject();
            poi.put("lat", last.optDouble("lat"));
            poi.put("lon", last.optDouble("lon"));
            poi.put("alt", last.isNull("alt") ? JSONObject.NULL : last.optDouble("alt"));
            poi.put("time", System.currentTimeMillis());
            poi.put("label", "P" + (pois.length() + 1));
            pois.put(poi);
            sp.edit().putString(KEY_POIS, pois.toString()).apply();
            showToast("Punto de interés marcado: P" + pois.length());
            refresh();
        } catch (Exception e) {
            showToast("No se pudo marcar el punto.");
        }
    }

    private void clearTrack() {
        SharedPreferences sp = getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE);
        if (sp.getBoolean(TrackService.KEY_RUNNING, false)) { showToast("Detén el recorrido antes de borrarlo."); return; }
        sp.edit().clear().apply();
        refresh();
    }

    private void export(boolean gpx) {
        SharedPreferences sp = getSharedPreferences(TrackService.PREFS_TRACK, MODE_PRIVATE);
        JSONArray points = readArray(sp, TrackService.KEY_POINTS);
        if (points.length() == 0) { showToast("No hay puntos para exportar."); return; }
        pendingExport = gpx ? buildGpx(points) : buildCsv(points);
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(gpx ? "application/gpx+xml" : "text/csv");
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date());
        i.putExtra(Intent.EXTRA_TITLE, "GeoTopo_Recorrido_" + stamp + (gpx ? ".gpx" : ".csv"));
        startActivityForResult(i, gpx ? REQ_EXPORT_GPX : REQ_EXPORT_CSV);
    }

    private String buildCsv(JSONArray points) {
        StringBuilder sb = new StringBuilder("indice,latitud,longitud,altitud,precision,fecha_hora\n");
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
        for (int i = 0; i < points.length(); i++) {
            JSONObject p = points.optJSONObject(i);
            if (p == null) continue;
            sb.append(i + 1).append(',').append(f7(p.optDouble("lat"))).append(',').append(f7(p.optDouble("lon"))).append(',')
                    .append(p.isNull("alt") ? "" : f3(p.optDouble("alt"))).append(',')
                    .append(p.isNull("acc") ? "" : f1(p.optDouble("acc"))).append(',')
                    .append('"').append(df.format(new Date(p.optLong("time")))).append('"').append('\n');
        }
        return sb.toString();
    }

    private String buildGpx(JSONArray points) {
        StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<gpx version=\"1.1\" creator=\"GeoTopo\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n<trk><name>GeoTopo recorrido</name><trkseg>\n");
        SimpleDateFormat iso = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        iso.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
        for (int i = 0; i < points.length(); i++) {
            JSONObject p = points.optJSONObject(i);
            if (p == null) continue;
            sb.append("<trkpt lat=\"").append(f7(p.optDouble("lat"))).append("\" lon=\"").append(f7(p.optDouble("lon"))).append("\">");
            if (!p.isNull("alt")) sb.append("<ele>").append(f3(p.optDouble("alt"))).append("</ele>");
            sb.append("<time>").append(iso.format(new Date(p.optLong("time")))).append("</time></trkpt>\n");
        }
        return sb.append("</trkseg></trk></gpx>\n").toString();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode == REQ_EXPORT_CSV || requestCode == REQ_EXPORT_GPX) && resultCode == RESULT_OK
                && data != null && data.getData() != null && pendingExport != null) {
            try {
                ContentResolver resolver = getContentResolver();
                Uri uri = data.getData();
                OutputStream out = resolver.openOutputStream(uri);
                if (out == null) throw new IllegalStateException();
                out.write(pendingExport.getBytes(StandardCharsets.UTF_8));
                out.close();
                showToast("Recorrido exportado.");
            } catch (Exception e) { showToast("No se pudo exportar."); }
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (trackMapView != null) trackMapView.onSaveInstanceState(outState);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if ((requestCode == REQ_LOCATION || requestCode == REQ_NOTIFICATION) && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startTrack();
        else if (requestCode == REQ_LOCATION || requestCode == REQ_NOTIFICATION) showToast("Se necesitan los permisos para registrar el recorrido con una notificación visible.");
    }

    private final class TrackStatusView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private String state = "DETENIDO";
        private long duration;
        private int stateColor = Color.rgb(129, 202, 97);

        TrackStatusView(Context context) { super(context); }

        void setState(String newState, long newDuration, int color) {
            state = newState;
            duration = newDuration;
            stateColor = color;
            invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2f;
            float cy = h / 2f;
            float r = Math.min(w, h) * 0.42f;

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(dp(2.2f));
            paint.setColor(withAlpha(accent, 95));
            canvas.drawCircle(cx, cy, r, paint);

            paint.setStrokeWidth(dp(3.0f));
            paint.setColor(stateColor);
            canvas.drawCircle(cx, cy, r, paint);

            paint.setStrokeWidth(dp(1.0f));
            paint.setColor(withAlpha(stateColor, 55));
            canvas.drawCircle(cx, cy, r - dp(7), paint);
            paint.setStrokeCap(Paint.Cap.BUTT);

            drawCenteredText(canvas, state.equals("REGISTRANDO") ? "Activa" : (state.equals("PAUSADO") ? "Pausada" : "Detenido"), cx, cy - dp(24), 14, stateColor, false);
            drawCenteredText(canvas, formatDuration(duration), cx, cy + dp(3), 18, textColor, true);
            drawCenteredText(canvas, "Tiempo", cx, cy + dp(28), 12, subTextColor, false);
        }

        private void drawCenteredText(Canvas c, String value, float x, float y, float sp, int color, boolean bold) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(color);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(sp * getResources().getDisplayMetrics().scaledDensity);
            paint.setTypeface(bold ? android.graphics.Typeface.DEFAULT_BOLD : android.graphics.Typeface.DEFAULT);
            c.drawText(value, x, y - (paint.ascent() + paint.descent()) / 2f, paint);
        }
    }


}
