package com.bph.geotopo;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Locale;

/**
 * Official ArcGIS World Imagery access for GeoTopo.
 *
 * The API key is supplied at build time with the Gradle property or environment
 * variable ESRI_API_KEY. End users never need an ArcGIS account or login.
 */
public final class EsriSatellite {
    private static final String PREFS = "geo_topo_prefs";
    private static final String KEY_LOCKED = "esri_satellite_locked";
    private static final String KEY_LOCK_REASON = "esri_satellite_lock_reason";
    private static final String KEY_ATTRIBUTION = "esri_satellite_attribution";
    private static final String KEY_LAST_OK = "esri_satellite_last_ok";
    private static final long CHECK_CACHE_MS = 15L * 60L * 1000L;

    // Official World Imagery map-tile endpoint documented by Esri for MapLibre.
    private static final String WORLD_IMAGERY =
            "https://ibasemaps-api.arcgis.com/arcgis/rest/services/World_Imagery/MapServer";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private EsriSatellite() { }

    public interface Callback {
        void onResult(Result result);
    }

    public static final class Result {
        public final boolean available;
        public final boolean locked;
        public final String message;

        Result(boolean available, boolean locked, String message) {
            this.available = available;
            this.locked = locked;
            this.message = message == null ? "" : message;
        }
    }

    public static boolean isConfigured() {
        return BuildConfig.ESRI_API_KEY != null && !BuildConfig.ESRI_API_KEY.trim().isEmpty();
    }

    public static boolean isLocked(Context context) {
        if (!isConfigured()) return true;
        return prefs(context).getBoolean(KEY_LOCKED, false);
    }

    public static String lockMessage(Context context) {
        if (!isConfigured()) {
            return "Satélite no configurado todavía por el desarrollador.";
        }
        String reason = prefs(context).getString(KEY_LOCK_REASON, "");
        return reason == null || reason.trim().isEmpty()
                ? "Satélite temporalmente no disponible."
                : reason;
    }

    public static String imageryTileTemplate() {
        return WORLD_IMAGERY + "/tile/{z}/{y}/{x}?token=" + encodedKey();
    }

    public static String attribution(Context context) {
        String saved = prefs(context).getString(KEY_ATTRIBUTION, "");
        if (saved != null && !saved.trim().isEmpty()) return saved.trim();
        return "Esri, Vantor, Earthstar Geographics, and the GIS User Community";
    }

    public static void checkAvailability(Context context, Callback callback) {
        if (context == null) return;
        Context app = context.getApplicationContext();
        if (!isConfigured()) {
            MAIN.post(() -> {
                if (callback != null) callback.onResult(new Result(false, true,
                        "Satélite no configurado todavía por el desarrollador."));
            });
            return;
        }

        SharedPreferences sp = prefs(app);
        long lastOk = sp.getLong(KEY_LAST_OK, 0L);
        boolean locked = sp.getBoolean(KEY_LOCKED, false);
        if (!locked && lastOk > 0L && System.currentTimeMillis() - lastOk < CHECK_CACHE_MS) {
            MAIN.post(() -> {
                if (callback != null) callback.onResult(new Result(true, false, ""));
            });
            return;
        }

        new Thread(() -> {
            Result result = checkNow(app);
            MAIN.post(() -> {
                if (callback != null) callback.onResult(result);
            });
        }, "GeoTopo-Esri-Check").start();
    }

    private static Result checkNow(Context context) {
        // Metadata gives current provider attribution and verifies that the key can
        // access the World Imagery service before MapLibre starts requesting tiles.
        String metadataUrl = WORLD_IMAGERY + "?f=json&token=" + encodedKey();
        HttpURLConnection connection = null;
        try {
            connection = open(metadataUrl, 8000, 10000);
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) return handleAccessCode(context, code);
            String body = readText(connection.getInputStream());
            JSONObject json = new JSONObject(body);
            Result jsonError = parseArcGisError(context, json);
            if (jsonError != null) return jsonError;

            String copyright = json.optString("copyrightText", "").trim();
            if (!copyright.isEmpty()) {
                prefs(context).edit().putString(KEY_ATTRIBUTION, copyright).apply();
            }
        } catch (Exception e) {
            return new Result(false, false, "Satélite sin conexión. Se mantiene el mapa normal.");
        } finally {
            if (connection != null) connection.disconnect();
        }

        // One real imagery tile verifies current authentication/quota. Level 0 is
        // tiny and is only requested when the 15-minute availability cache expires.
        String sampleUrl = WORLD_IMAGERY + "/tile/0/0/0?token=" + encodedKey();
        connection = null;
        try {
            connection = open(sampleUrl, 8000, 12000);
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) return handleAccessCode(context, code);

            String contentType = connection.getContentType();
            if (contentType != null && (contentType.contains("json") || contentType.contains("text"))) {
                String body = readText(connection.getInputStream());
                try {
                    Result jsonError = parseArcGisError(context, new JSONObject(body));
                    if (jsonError != null) return jsonError;
                } catch (Exception ignored) { }
                return new Result(false, false, "El servicio satelital no devolvió una imagen válida.");
            }

            try (InputStream input = connection.getInputStream()) {
                byte[] buffer = new byte[256];
                int read = input.read(buffer);
                if (read <= 0) {
                    return new Result(false, false, "El servicio satelital no devolvió una imagen válida.");
                }
            }
            clearLocked(context);
            prefs(context).edit().putLong(KEY_LAST_OK, System.currentTimeMillis()).apply();
            return new Result(true, false, "");
        } catch (Exception e) {
            return new Result(false, false, "Satélite sin conexión. Se mantiene el mapa normal.");
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static Result parseArcGisError(Context context, JSONObject json) {
        if (json == null) return null;
        JSONObject error = json.optJSONObject("error");
        if (error == null) return null;
        int code = error.optInt("code", 0);
        String message = error.optString("message", "");
        if (code == 401 || code == 402 || code == 403 || code == 429 || code == 498 || code == 499) return handleAccessCode(context, code);
        if (code >= 500) return new Result(false, false, "Servicio satelital temporalmente sin respuesta.");
        if (!message.trim().isEmpty()) {
            return new Result(false, false, "No se pudo abrir el satélite: " + message.trim());
        }
        return new Result(false, false, "No se pudo abrir el satélite.");
    }

    private static HttpURLConnection open(String address, int connectTimeout, int readTimeout) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        connection.setConnectTimeout(connectTimeout);
        connection.setReadTimeout(readTimeout);
        connection.setRequestProperty("User-Agent", "GeoTopo/1.29 Android (com.bph.geotopo)");
        connection.setRequestProperty("Accept", "application/json,image/jpeg,image/png,*/*");
        return connection;
    }

    private static Result handleAccessCode(Context context, int code) {
        String message;
        if (code == 401 || code == 498 || code == 499) {
            message = "Satélite bloqueado: la clave Esri no es válida.";
        } else if (code == 402 || code == 403 || code == 429) {
            message = "Satélite temporalmente no disponible. Revisa la cuota gratuita o permisos de Esri.";
        } else if (code >= 500) {
            return new Result(false, false, "Servicio satelital temporalmente sin respuesta.");
        } else {
            return new Result(false, false, "No se pudo abrir el satélite (código " + code + ").");
        }
        markLocked(context, message);
        return new Result(false, true, message);
    }

    public static void markLocked(Context context, String reason) {
        if (context == null) return;
        prefs(context).edit()
                .putBoolean(KEY_LOCKED, true)
                .putString(KEY_LOCK_REASON, reason == null ? "Satélite temporalmente no disponible." : reason)
                .remove(KEY_LAST_OK)
                .apply();
    }

    public static void clearLocked(Context context) {
        if (context == null) return;
        prefs(context).edit()
                .putBoolean(KEY_LOCKED, false)
                .remove(KEY_LOCK_REASON)
                .apply();
    }

    public static boolean looksLikeAccessFailure(String errorMessage) {
        if (errorMessage == null) return false;
        String lower = errorMessage.toLowerCase(Locale.ROOT);
        return lower.contains("401") || lower.contains("402") || lower.contains("403") || lower.contains("429")
                || lower.contains("498") || lower.contains("499")
                || lower.contains("unauthor") || lower.contains("forbidden")
                || lower.contains("quota") || lower.contains("rate limit")
                || lower.contains("billing");
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static String encodedKey() {
        try {
            return URLEncoder.encode(BuildConfig.ESRI_API_KEY == null ? "" : BuildConfig.ESRI_API_KEY.trim(), "UTF-8");
        } catch (Exception ignored) {
            return BuildConfig.ESRI_API_KEY == null ? "" : BuildConfig.ESRI_API_KEY.trim();
        }
    }

    private static String readText(InputStream input) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(input, "UTF-8"));
        StringBuilder out = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) out.append(line);
        return out.toString();
    }
}
