plugins {
    id("com.android.application")
}

val esriApiKeyProvider = providers.gradleProperty("ESRI_API_KEY")
    .orElse(providers.environmentVariable("ESRI_API_KEY"))
    .orElse("")

fun quotedBuildConfig(value: String): String = "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"") + "\""

android {
    namespace = "com.bph.geotopo"
    compileSdk = 36

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    defaultConfig {
        applicationId = "com.bph.geotopo"
        minSdk = 23
        targetSdk = 36
        versionCode = 60
        versionName = "1.29.0"
        buildConfigField("String", "ESRI_API_KEY", quotedBuildConfig(esriApiKeyProvider.get()))
    }
}

dependencies {
    implementation("org.maplibre.gl:android-sdk:11.13.5")
}
