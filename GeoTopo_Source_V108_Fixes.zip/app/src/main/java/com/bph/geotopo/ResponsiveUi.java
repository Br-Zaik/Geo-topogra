package com.bph.geotopo;

import android.content.Context;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.widget.TextView;

/**
 * Small, visual-only responsive helpers shared by GeoTopo screens.
 * It intentionally does not alter calculations, data, navigation or colors.
 */
public final class ResponsiveUi {
    private ResponsiveUi() {}

    public static float widthDp(Context context) {
        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        return dm.widthPixels / Math.max(0.01f, dm.density);
    }

    /** Keep the current look on normal phones; only compact or slightly relax text at the edges. */
    public static float textScale(Context context) {
        float width = widthDp(context);
        if (width <= 320f) return 0.88f;
        if (width <= 340f) return 0.91f;
        if (width <= 380f) return 0.95f;
        if (width >= 600f) return 1.06f;
        if (width >= 480f) return 1.03f;
        return 1.00f;
    }

    public static float scaledSp(Context context, float baseSp) {
        return baseSp * textScale(context);
    }

    /**
     * Default text behavior: preserve the design, disable ugly automatic hyphenation,
     * and make only a small width-aware type-size adjustment.
     */
    public static void configureText(TextView view, float baseSp) {
        if (view == null) return;
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, scaledSp(view.getContext(), baseSp));
        view.setHorizontallyScrolling(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            view.setBreakStrategy(android.text.Layout.BREAK_STRATEGY_SIMPLE);
            view.setHyphenationFrequency(android.text.Layout.HYPHENATION_FREQUENCY_NONE);
        }
    }

    /**
     * For short labels/buttons/metric cards. Auto-size is used where Android supports it,
     * so words such as PENDIENTE stay intact instead of breaking in the middle.
     */
    public static void configureCompactText(TextView view, float baseSp, float minSp, int maxLines) {
        if (view == null) return;
        configureText(view, baseSp);
        if (maxLines > 0) view.setMaxLines(maxLines);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            float maxSp = scaledSp(view.getContext(), baseSp);
            float min = Math.min(minSp, maxSp);
            view.setAutoSizeTextTypeUniformWithConfiguration(
                    Math.max(7, Math.round(min)),
                    Math.max(Math.max(8, Math.round(min)), Math.round(maxSp)),
                    1,
                    TypedValue.COMPLEX_UNIT_SP);
        }
    }

    public static boolean isNarrow(Context context) {
        return widthDp(context) <= 380f;
    }

    /** Reduce only horizontal gaps on narrow screens, never the component itself. */
    public static int adaptiveGapPx(Context context, int normalDp) {
        float factor = isNarrow(context) ? 0.72f : (widthDp(context) >= 600f ? 1.08f : 1.0f);
        return Math.round(normalDp * factor * context.getResources().getDisplayMetrics().density);
    }
}
