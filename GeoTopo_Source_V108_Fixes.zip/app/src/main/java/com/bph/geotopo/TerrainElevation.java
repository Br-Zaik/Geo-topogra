package com.bph.geotopo;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;

import org.maplibre.android.geometry.LatLng;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Lightweight elevation sampler backed by Mapterhorn Terrarium DEM tiles.
 * The public DEM is suitable for terrain context and profiles, not survey-grade heights.
 */
public final class TerrainElevation {
    private static final int ZOOM = 12;
    private static final int TILE_SIZE = 512;
    private static final String TILE_URL = "https://tiles.mapterhorn.com/%d/%d/%d.webp";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private TerrainElevation() { }

    public interface Callback {
        void onResult(Result result);
    }

    public static final class Sample {
        public final double distanceMeters;
        public final double latitude;
        public final double longitude;
        public final double elevationMeters;

        Sample(double distanceMeters, double latitude, double longitude, double elevationMeters) {
            this.distanceMeters = distanceMeters;
            this.latitude = latitude;
            this.longitude = longitude;
            this.elevationMeters = elevationMeters;
        }
    }

    public static final class Result {
        public final boolean ok;
        public final String message;
        public final List<Sample> samples;

        Result(boolean ok, String message, List<Sample> samples) {
            this.ok = ok;
            this.message = message == null ? "" : message;
            this.samples = samples == null ? new ArrayList<>() : samples;
        }
    }

    public static void sampleProfile(List<LatLng> path, Callback callback) {
        List<LatLng> copy = path == null ? new ArrayList<>() : new ArrayList<>(path);
        new Thread(() -> {
            Result result;
            try {
                result = sampleNow(copy);
            } catch (Exception e) {
                result = new Result(false, "No se pudo obtener el perfil de elevación.", new ArrayList<>());
            }
            Result finalResult = result;
            MAIN.post(() -> {
                if (callback != null) callback.onResult(finalResult);
            });
        }, "GeoTopo-Terrain-Profile").start();
    }

    private static Result sampleNow(List<LatLng> path) throws Exception {
        if (path.size() < 2) {
            return new Result(false, "Se necesitan al menos dos puntos.", new ArrayList<>());
        }

        List<Double> segmentLengths = new ArrayList<>();
        double total = 0.0;
        for (int i = 1; i < path.size(); i++) {
            double length = haversine(path.get(i - 1), path.get(i));
            segmentLengths.add(length);
            total += length;
        }
        if (total < 0.5) {
            return new Result(false, "La línea es demasiado corta para generar un perfil.", new ArrayList<>());
        }

        int count = Math.max(28, Math.min(240, (int) Math.ceil(total / 7.5) + 1));
        List<RoutePoint> route = interpolatePath(path, segmentLengths, total, count);
        Map<String, Bitmap> tileCache = new HashMap<>();
        List<Sample> out = new ArrayList<>();
        int valid = 0;

        try {
            for (RoutePoint p : route) {
                TilePixel tile = tilePixel(p.latitude, p.longitude);
                String key = tile.x + ":" + tile.y;
                Bitmap bitmap = tileCache.get(key);
                if (bitmap == null) {
                    bitmap = downloadTile(tile.x, tile.y);
                    if (bitmap != null) tileCache.put(key, bitmap);
                }
                double elevation = Double.NaN;
                if (bitmap != null && bitmap.getWidth() > 0 && bitmap.getHeight() > 0) {
                    int px = Math.max(0, Math.min(bitmap.getWidth() - 1,
                            (int) Math.floor(tile.localX * bitmap.getWidth())));
                    int py = Math.max(0, Math.min(bitmap.getHeight() - 1,
                            (int) Math.floor(tile.localY * bitmap.getHeight())));
                    int color = bitmap.getPixel(px, py);
                    elevation = terrariumHeight(color);
                    if (Double.isFinite(elevation)) valid++;
                }
                out.add(new Sample(p.distanceMeters, p.latitude, p.longitude, elevation));
            }
        } finally {
            for (Bitmap bitmap : tileCache.values()) {
                if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            }
        }

        if (valid < Math.max(8, out.size() * 2 / 3)) {
            return new Result(false, "El terreno no respondió con suficientes datos. Intenta de nuevo con conexión estable.", out);
        }
        fillSmallGaps(out);
        return new Result(true, "", out);
    }

    private static List<RoutePoint> interpolatePath(List<LatLng> path, List<Double> segmentLengths,
                                                     double total, int count) {
        List<RoutePoint> out = new ArrayList<>();
        int segment = 0;
        double segmentStart = 0.0;
        for (int i = 0; i < count; i++) {
            double target = total * i / (double) (count - 1);
            while (segment < segmentLengths.size() - 1
                    && target > segmentStart + segmentLengths.get(segment)) {
                segmentStart += segmentLengths.get(segment);
                segment++;
            }
            double length = Math.max(1e-9, segmentLengths.get(segment));
            double t = Math.max(0.0, Math.min(1.0, (target - segmentStart) / length));
            LatLng a = path.get(segment);
            LatLng b = path.get(segment + 1);
            double lat = a.getLatitude() + (b.getLatitude() - a.getLatitude()) * t;
            double lon = a.getLongitude() + (b.getLongitude() - a.getLongitude()) * t;
            out.add(new RoutePoint(target, lat, lon));
        }
        return out;
    }

    private static TilePixel tilePixel(double latitude, double longitude) {
        double lat = Math.max(-85.05112878, Math.min(85.05112878, latitude));
        double lon = longitude;
        while (lon < -180.0) lon += 360.0;
        while (lon > 180.0) lon -= 360.0;

        double n = Math.pow(2.0, ZOOM);
        double xFloat = (lon + 180.0) / 360.0 * n;
        double latRad = Math.toRadians(lat);
        double yFloat = (1.0 - Math.log(Math.tan(latRad) + 1.0 / Math.cos(latRad)) / Math.PI) / 2.0 * n;
        int x = floorMod((int) Math.floor(xFloat), (int) n);
        int y = Math.max(0, Math.min((int) n - 1, (int) Math.floor(yFloat)));
        return new TilePixel(x, y, xFloat - Math.floor(xFloat), yFloat - Math.floor(yFloat));
    }

    private static int floorMod(int value, int mod) {
        int r = value % mod;
        return r < 0 ? r + mod : r;
    }

    private static Bitmap downloadTile(int x, int y) {
        HttpURLConnection connection = null;
        try {
            String address = String.format(Locale.US, TILE_URL, ZOOM, x, y);
            connection = (HttpURLConnection) new URL(address).openConnection();
            connection.setConnectTimeout(9000);
            connection.setReadTimeout(12000);
            connection.setRequestProperty("User-Agent", "GeoTopo/1.30 Android (terrain profile)");
            connection.setRequestProperty("Accept", "image/webp,image/*,*/*");
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) return null;
            try (InputStream in = connection.getInputStream()) {
                return BitmapFactory.decodeStream(in);
            }
        } catch (Exception ignored) {
            return null;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static double terrariumHeight(int color) {
        int r = Color.red(color);
        int g = Color.green(color);
        int b = Color.blue(color);
        return r * 256.0 + g + b / 256.0 - 32768.0;
    }

    private static void fillSmallGaps(List<Sample> samples) {
        for (int i = 0; i < samples.size(); i++) {
            Sample current = samples.get(i);
            if (Double.isFinite(current.elevationMeters)) continue;
            int left = i - 1;
            while (left >= 0 && !Double.isFinite(samples.get(left).elevationMeters)) left--;
            int right = i + 1;
            while (right < samples.size() && !Double.isFinite(samples.get(right).elevationMeters)) right++;
            double value = Double.NaN;
            if (left >= 0 && right < samples.size()) {
                Sample a = samples.get(left);
                Sample b = samples.get(right);
                double span = Math.max(1e-9, b.distanceMeters - a.distanceMeters);
                double t = (current.distanceMeters - a.distanceMeters) / span;
                value = a.elevationMeters + (b.elevationMeters - a.elevationMeters) * t;
            } else if (left >= 0) {
                value = samples.get(left).elevationMeters;
            } else if (right < samples.size()) {
                value = samples.get(right).elevationMeters;
            }
            if (Double.isFinite(value)) {
                samples.set(i, new Sample(current.distanceMeters, current.latitude, current.longitude, value));
            }
        }
    }

    private static double haversine(LatLng a, LatLng b) {
        final double r = 6371008.8;
        double p1 = Math.toRadians(a.getLatitude());
        double p2 = Math.toRadians(b.getLatitude());
        double dp = Math.toRadians(b.getLatitude() - a.getLatitude());
        double dl = Math.toRadians(b.getLongitude() - a.getLongitude());
        double q = Math.sin(dp / 2.0) * Math.sin(dp / 2.0)
                + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2.0) * Math.sin(dl / 2.0);
        return 2.0 * r * Math.atan2(Math.sqrt(q), Math.sqrt(Math.max(0.0, 1.0 - q)));
    }

    private static final class RoutePoint {
        final double distanceMeters;
        final double latitude;
        final double longitude;

        RoutePoint(double distanceMeters, double latitude, double longitude) {
            this.distanceMeters = distanceMeters;
            this.latitude = latitude;
            this.longitude = longitude;
        }
    }

    private static final class TilePixel {
        final int x;
        final int y;
        final double localX;
        final double localY;

        TilePixel(int x, int y, double localX, double localY) {
            this.x = x;
            this.y = y;
            this.localX = localX;
            this.localY = localY;
        }
    }
}
