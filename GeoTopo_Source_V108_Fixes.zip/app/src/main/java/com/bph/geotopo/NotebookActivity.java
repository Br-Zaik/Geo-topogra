package com.bph.geotopo;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.GpsSatellite;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class NotebookActivity extends BaseToolActivity {
    private static final int REQ_LOCATION = 9570;
    private static final int REQ_PHOTO = 9571;
    private static final String DEFAULT_UTM_CRS = "WGS84 UTM · Seleccionar zona";

    private LocationManager manager;
    private ScrollView mainScroll;

    private Button projectButton;
    private Button crsButton;
    private Button coordinateUtmButton;
    private Button coordinateGeoButton;
    private Button saveButton;
    private Button projectFilterButton;

    private Button typeSelectorButton;

    private EditText codeInput;
    private EditText northInput;
    private EditText eastInput;
    private EditText elevationInput;
    private EditText accuracyInput;
    private EditText descriptionInput;
    private EditText searchInput;

    private TextView northLabel;
    private TextView eastLabel;
    private TextView statusSource;
    private TextView statusAccuracy;
    private TextView statusSatellites;
    private TextView statusSolution;
    private TextView recordsCount;
    private LinearLayout recordsContainer;

    private List<NotebookStore.Entry> entries = new ArrayList<>();
    private String currentProject = "General";
    private String currentCrs = DEFAULT_UTM_CRS;
    private String currentType = "Control";
    private String currentSource = "Manual";
    private String currentPhotoUri = "";
    private String projectFilter = "Todos";
    private boolean geographicMode = false;
    private int editingIndex = -1;
    private int satelliteCount = 0;
    private Location lastFreshLocation;
    private boolean gpsListening = false;
    private GpsStatus.Listener gpsStatusListener;

    private final LocationListener gpsListener = new LocationListener() {
        @Override public void onLocationChanged(Location location) {
            if (location == null) return;
            lastFreshLocation = location;
            currentSource = "GPS teléfono";
            applyPhoneLocation(location);
        }
        @Override public void onProviderEnabled(String provider) {}
        @Override public void onProviderDisabled(String provider) {}
        @SuppressWarnings("deprecation")
        @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        manager = (LocationManager) getSystemService(LOCATION_SERVICE);

        LinearLayout root = page("Libreta de campo", "Registro local de puntos y observaciones");
        LinearLayout content = vertical();
        content.addView(buildStatusStrip());
        content.addView(buildPointForm());
        content.addView(buildRecordsCard());

        mainScroll = scrollWith(content);
        root.addView(mainScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        load();
        refreshTypeUi();
        refreshCoordinateUi();
    }

    @Override protected void onResume() {
        super.onResume();
        load();
    }

    @Override protected void onPause() {
        stopGpsCapture();
        super.onPause();
    }

    private View buildStatusStrip() {
        LinearLayout strip = card();
        strip.setPadding(dp(10), dp(9), dp(10), dp(9));
        statusSource = statusMetric("Fuente", "Manual", "◎");
        statusAccuracy = statusMetric("Precisión", "—", "⊕");
        // Se conservan internamente para el registro GNSS, pero no ocupan espacio en la vista principal.
        statusSatellites = statusMetric("Satélites", "—", "⌁");
        statusSolution = statusMetric("Solución", "Sin captura", "✓");

        LinearLayout row = horizontal();
        row.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        row.addView(statusSource, weight());
        row.addView(statusAccuracy, weight());
        strip.addView(row);
        return strip;
    }

    private View buildPointForm() {
        LinearLayout form = card();
        LinearLayout titleRow = horizontal();
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView title = sectionTitle("Nuevo punto");
        titleRow.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button clear = compactAction("🗑", Color.rgb(244, 81, 81), true);
        clear.setContentDescription("Limpiar formulario");
        clear.setOnClickListener(v -> clearForm());
        titleRow.addView(clear, new LinearLayout.LayoutParams(dp(46), dp(42)));

        Button more = compactAction("⋮", accent, false);
        more.setContentDescription("Más opciones");
        more.setOnClickListener(v -> showPointOptions());
        LinearLayout.LayoutParams moreLp = new LinearLayout.LayoutParams(dp(46), dp(42));
        moreLp.setMargins(dp(5), 0, 0, 0);
        titleRow.addView(more, moreLp);
        form.addView(titleRow);

        form.addView(fieldCaption("Tipo"));
        typeSelectorButton = selectorButton(currentType + "  ▼");
        typeSelectorButton.setOnClickListener(v -> choosePointType());
        form.addView(typeSelectorButton, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));

        projectButton = selectorButton(currentProject);
        projectButton.setOnClickListener(v -> chooseProject());
        codeInput = textInput("CTRL-0001");
        elevationInput = numberInput("Cota");
        fitSingleLineInput(codeInput);
        fitSingleLineInput(elevationInput);
        if (ResponsiveUi.isNarrow(this)) {
            form.addView(labeled("Proyecto", projectButton));
            LinearLayout row1b = horizontal();
            row1b.addView(labeled("Código (auto)", codeInput), weight());
            row1b.addView(labeled("Cota (m)", elevationInput), weight());
            form.addView(row1b);
        } else {
            LinearLayout row1 = horizontal();
            row1.addView(labeled("Proyecto", projectButton), weight());
            row1.addView(labeled("Código (auto)", codeInput), weight());
            row1.addView(labeled("Cota (m)", elevationInput), weight());
            form.addView(row1);
        }

        LinearLayout coordinateModes = horizontal();
        coordinateModes.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        coordinateUtmButton = segmentButton("N / E (UTM)");
        coordinateGeoButton = segmentButton("Latitud / Longitud");
        coordinateUtmButton.setOnClickListener(v -> switchCoordinateMode(false));
        coordinateGeoButton.setOnClickListener(v -> switchCoordinateMode(true));
        coordinateModes.addView(coordinateUtmButton, weight());
        coordinateModes.addView(coordinateGeoButton, weight());
        form.addView(coordinateModes);

        northInput = numberInput("Norte");
        eastInput = numberInput("Este");
        fitSingleLineInput(northInput);
        fitSingleLineInput(eastInput);
        northLabel = text("Norte (m)", 12, true);
        eastLabel = text("Este (m)", 12, true);
        northLabel.setTextColor(subTextColor);
        eastLabel.setTextColor(subTextColor);
        LinearLayout row2 = horizontal();
        row2.addView(labeledDynamic(northLabel, northInput), weight());
        row2.addView(labeledDynamic(eastLabel, eastInput), weight());
        form.addView(row2);

        crsButton = selectorButton(currentCrs);
        crsButton.setOnClickListener(v -> chooseCrs());
        form.addView(labeled("Sistema de coordenadas", crsButton));

        // Se mantiene para guardar/editar la precisión sin mostrar otro campo editable redundante.
        accuracyInput = textInput("");
        accuracyInput.setVisibility(View.GONE);

        descriptionInput = textInput("Agregar descripción del punto...");
        descriptionInput.setSingleLine(false);
        descriptionInput.setMinLines(2);
        descriptionInput.setMaxLines(4);
        descriptionInput.setGravity(Gravity.TOP | Gravity.START);
        descriptionInput.setPadding(dp(10), dp(10), dp(10), dp(10));
        form.addView(labeledTall("Descripción (opcional)", descriptionInput, dp(76)));

        Button gps = secondaryButton("Tomar GPS");
        gps.setOnClickListener(v -> captureGps());
        saveButton = primaryButton("Guardar punto");
        saveButton.setOnClickListener(v -> savePoint());
        LinearLayout actions = horizontal();
        actions.addView(gps, weight());
        actions.addView(saveButton, weight());
        form.addView(actions);
        return form;
    }

    private View buildRecordsCard() {
        LinearLayout records = card();
        LinearLayout header = horizontal();
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView title = sectionTitle("Puntos guardados");
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        recordsCount = badge("0 puntos", accent);
        header.addView(recordsCount);
        Button options = compactAction("⋮", accent, false);
        options.setContentDescription("Opciones de la libreta");
        options.setOnClickListener(v -> showRecordsOptions());
        LinearLayout.LayoutParams optionsLp = new LinearLayout.LayoutParams(dp(46), dp(42));
        optionsLp.setMargins(dp(6), 0, 0, 0);
        header.addView(options, optionsLp);
        records.addView(header);

        searchInput = textInput("Buscar por código, descripción...");
        fitSingleLineInput(searchInput);
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { renderRecords(); }
            @Override public void afterTextChanged(Editable s) {}
        });
        projectFilterButton = selectorButton("Proyecto: Todos");
        projectFilterButton.setOnClickListener(v -> chooseProjectFilter());
        if (ResponsiveUi.isNarrow(this)) {
            LinearLayout searchRowA = horizontal();
            searchRowA.addView(searchInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));
            records.addView(searchRowA);
            LinearLayout searchRowB = horizontal();
            searchRowB.addView(projectFilterButton, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));
            records.addView(searchRowB);
        } else {
            LinearLayout searchRow = horizontal();
            searchRow.addView(searchInput, new LinearLayout.LayoutParams(0, dp(50), 1.6f));
            LinearLayout.LayoutParams filterLp = new LinearLayout.LayoutParams(0, dp(50), 1f);
            filterLp.setMargins(dp(5), 0, 0, 0);
            searchRow.addView(projectFilterButton, filterLp);
            records.addView(searchRow);
        }

        recordsContainer = vertical();
        records.addView(recordsContainer);
        return records;
    }

    private void load() {
        entries = NotebookStore.load(this);
        if (projectButton != null && editingIndex < 0) {
            projectButton.setText(currentProject);
            ensureAutoCode();
        }
        renderRecords();
    }

    private void renderRecords() {
        if (recordsContainer == null) return;
        recordsContainer.removeAllViews();
        recordsCount.setText(entries.size() + (entries.size() == 1 ? " punto" : " puntos"));
        String query = searchInput == null ? "" : searchInput.getText().toString().trim().toLowerCase(Locale.US);
        int shown = 0;
        for (int i = entries.size() - 1; i >= 0; i--) {
            NotebookStore.Entry entry = entries.get(i);
            if (!"Todos".equals(projectFilter) && !projectFilter.equals(entry.project)) continue;
            String haystack = (entry.code + " " + entry.description + " " + entry.project + " " + entry.type).toLowerCase(Locale.US);
            if (!query.isEmpty() && !haystack.contains(query)) continue;
            recordsContainer.addView(savedPointRow(entry, i));
            shown++;
        }
        if (shown == 0) {
            recordsContainer.addView(resultBox(entries.isEmpty() ? "No hay puntos guardados." : "No hay puntos que coincidan con el filtro."));
        }
    }

    private View savedPointRow(NotebookStore.Entry entry, int index) {
        LinearLayout row = vertical();
        row.setPadding(dp(10), dp(9), dp(10), dp(9));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(inputColor);
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), withAlpha(typeColor(entry.type), 160));
        row.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(8));
        row.setLayoutParams(lp);

        if (ResponsiveUi.isNarrow(this)) {
            LinearLayout head = horizontal();
            head.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            TextView icon = typeIcon(entry.type);
            head.addView(icon, new LinearLayout.LayoutParams(dp(40), dp(40)));

            LinearLayout identity = vertical();
            identity.setPadding(dp(8), 0, dp(6), 0);
            identity.addView(text(entry.code, 15, true));
            TextView desc = text(entry.description.isEmpty() ? entry.type + " · " + entry.project : entry.description, 11, false);
            desc.setTextColor(subTextColor);
            identity.addView(desc);
            head.addView(identity, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            Button edit = squareAction("✎", accent);
            edit.setOnClickListener(v -> editEntry(index));
            Button delete = squareAction("×", Color.rgb(244, 81, 81));
            delete.setOnClickListener(v -> deleteEntry(index));
            head.addView(edit, new LinearLayout.LayoutParams(dp(40), dp(40)));
            LinearLayout.LayoutParams deleteLp = new LinearLayout.LayoutParams(dp(40), dp(40));
            deleteLp.setMargins(dp(5), 0, 0, 0);
            head.addView(delete, deleteLp);
            row.addView(head);

            LinearLayout data = horizontal();
            data.setPadding(dp(48), dp(6), 0, 0);
            TextView coords = text("N: " + entry.north + "\nE: " + entry.east, 11, false);
            coords.setTextColor(subTextColor);
            data.addView(coords, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.25f));
            LinearLayout values = vertical();
            TextView cota = text(entry.elevation.isEmpty() ? "Cota —" : entry.elevation + " m", 11, true);
            values.addView(cota);
            TextView acc = text(entry.accuracy.isEmpty() ? entry.source : entry.accuracy, 10, false);
            acc.setTextColor(Color.rgb(109, 224, 122));
            values.addView(acc);
            data.addView(values, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.75f));
            row.addView(data);
        } else {
            LinearLayout top = horizontal();
            top.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            TextView icon = typeIcon(entry.type);
            top.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(42)));

            LinearLayout identity = vertical();
            identity.setPadding(dp(9), 0, dp(8), 0);
            identity.addView(text(entry.code, 15, true));
            TextView desc = text(entry.description.isEmpty() ? entry.type + " · " + entry.project : entry.description, 12, false);
            desc.setTextColor(subTextColor);
            identity.addView(desc);
            top.addView(identity, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.2f));

            TextView coords = text("N: " + entry.north + "\nE: " + entry.east, 12, false);
            coords.setTextColor(subTextColor);
            top.addView(coords, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.15f));

            LinearLayout values = vertical();
            TextView cota = text(entry.elevation.isEmpty() ? "Cota —" : entry.elevation + " m", 12, true);
            values.addView(cota);
            TextView acc = text(entry.accuracy.isEmpty() ? entry.source : entry.accuracy, 11, false);
            acc.setTextColor(Color.rgb(109, 224, 122));
            values.addView(acc);
            if (!entry.photoUri.isEmpty()) {
                TextView photo = text("Foto adjunta", 10, false);
                photo.setTextColor(accent);
                values.addView(photo);
            }
            top.addView(values, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.8f));

            LinearLayout actions = horizontal();
            actions.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            Button edit = squareAction("✎", accent);
            edit.setOnClickListener(v -> editEntry(index));
            Button delete = squareAction("×", Color.rgb(244, 81, 81));
            delete.setOnClickListener(v -> deleteEntry(index));
            actions.addView(edit, new LinearLayout.LayoutParams(dp(42), dp(42)));
            LinearLayout.LayoutParams deleteLp = new LinearLayout.LayoutParams(dp(42), dp(42));
            deleteLp.setMargins(dp(5), 0, 0, 0);
            actions.addView(delete, deleteLp);
            top.addView(actions);
            row.addView(top);
        }

        TextView meta = text(entry.type + " · " + entry.project + " · " + entry.crs + " · " + entry.time, 10, false);
        meta.setTextColor(subTextColor);
        meta.setPadding(ResponsiveUi.isNarrow(this) ? dp(48) : dp(51), dp(5), 0, 0);
        row.addView(meta);
        return row;
    }

    private void selectType(String type) {
        boolean wasAuto = codeInput == null || codeInput.getText().toString().trim().isEmpty() || looksAutoGenerated(codeInput.getText().toString().trim());
        currentType = type;
        refreshTypeUi();
        if (wasAuto) codeInput.setText(nextCodeForType(type));
    }

    private void choosePointType() {
        String[] options = {"Control", "BM", "Detalle"};
        new AlertDialog.Builder(this)
                .setTitle("Tipo de punto")
                .setItems(options, (dialog, which) -> selectType(options[which]))
                .show();
    }

    private void refreshTypeUi() {
        if (typeSelectorButton != null) typeSelectorButton.setText(currentType + "  ▼");
    }

    private void showPointOptions() {
        List<String> options = new ArrayList<>();
        options.add(currentPhotoUri.isEmpty() ? "Adjuntar foto" : "Cambiar foto");
        if (!currentPhotoUri.isEmpty()) options.add("Quitar foto");
        options.add("Abrir GNSS externo");
        new AlertDialog.Builder(this)
                .setTitle("Más opciones")
                .setItems(options.toArray(new String[0]), (dialog, which) -> {
                    String selected = options.get(which);
                    if ("Adjuntar foto".equals(selected) || "Cambiar foto".equals(selected)) {
                        choosePhoto();
                    } else if ("Quitar foto".equals(selected)) {
                        currentPhotoUri = "";
                        showToast("Foto quitada del punto.");
                    } else if ("Abrir GNSS externo".equals(selected)) {
                        startActivity(new Intent(this, ExternalGnssActivity.class));
                    }
                }).show();
    }

    private void showRecordsOptions() {
        String[] options = {"Importar / exportar", "Borrar todos los puntos"};
        new AlertDialog.Builder(this)
                .setTitle("Opciones de la libreta")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) startActivity(new Intent(this, DataExchangeActivity.class));
                    else confirmClear();
                }).show();
    }

    private void switchCoordinateMode(boolean geo) {
        if (geo == geographicMode) return;
        if (hasCoordinateValues()) {
            if (geo) convertUtmToGeographic();
            else convertGeographicToUtm();
        } else {
            geographicMode = geo;
            if (geo) currentCrs = "WGS84 geográficas";
            else if (!currentCrs.toUpperCase(Locale.US).contains("UTM")) currentCrs = DEFAULT_UTM_CRS;
            crsButton.setText(currentCrs);
            refreshCoordinateUi();
        }
    }

    private void refreshCoordinateUi() {
        if (coordinateUtmButton == null) return;
        styleSegment(coordinateUtmButton, !geographicMode);
        styleSegment(coordinateGeoButton, geographicMode);
        if (geographicMode) {
            northLabel.setText("Latitud");
            eastLabel.setText("Longitud");
            northInput.setHint("-13.0000000");
            eastInput.setHint("-72.0000000");
        } else {
            northLabel.setText("Norte (m)");
            eastLabel.setText("Este (m)");
            northInput.setHint("Norte");
            eastInput.setHint("Este");
        }
    }

    private void convertGeographicToUtm() {
        try {
            double lat = parse(northInput);
            double lon = parse(eastInput);
            if (lat < -80 || lat > 84 || lon < -180 || lon > 180) throw new IllegalArgumentException();
            UtmCoordinate utm = latLonToUtm(lat, lon);
            northInput.setText(f3(utm.northing));
            eastInput.setText(f3(utm.easting));
            currentCrs = "WGS84 UTM " + utm.zone + utm.hemisphere;
            geographicMode = false;
            crsButton.setText(currentCrs);
            refreshCoordinateUi();
            showToast("Coordenadas convertidas a " + currentCrs + ".");
        } catch (Exception e) {
            showToast("Revisa latitud y longitud antes de convertir.");
        }
    }

    private void convertUtmToGeographic() {
        try {
            int[] zoneInfo = parseUtmZone(currentCrs);
            if (zoneInfo == null) { showToast("Selecciona primero un sistema UTM válido."); return; }
            double northing = parse(northInput);
            double easting = parse(eastInput);
            LatLon ll = utmToLatLon(northing, easting, zoneInfo[0], zoneInfo[1] < 0);
            northInput.setText(f7(ll.lat));
            eastInput.setText(f7(ll.lon));
            currentCrs = "WGS84 geográficas";
            geographicMode = true;
            crsButton.setText(currentCrs);
            refreshCoordinateUi();
            showToast("Coordenadas convertidas a latitud/longitud.");
        } catch (Exception e) {
            showToast("Revisa las coordenadas UTM y la zona antes de convertir.");
        }
    }

    private void chooseProject() {
        Set<String> values = new LinkedHashSet<>();
        values.add("General");
        for (NotebookStore.Entry entry : entries) if (!entry.project.trim().isEmpty()) values.add(entry.project);
        List<String> options = new ArrayList<>(values);
        options.add("Nuevo proyecto…");
        new AlertDialog.Builder(this)
                .setTitle("Proyecto")
                .setItems(options.toArray(new String[0]), (dialog, which) -> {
                    String selected = options.get(which);
                    if ("Nuevo proyecto…".equals(selected)) askNewProject();
                    else {
                        currentProject = selected;
                        projectButton.setText(currentProject);
                        ensureAutoCode();
                    }
                }).show();
    }

    private void askNewProject() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Nombre del proyecto");
        new AlertDialog.Builder(this)
                .setTitle("Nuevo proyecto")
                .setView(input)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Usar", (d, w) -> {
                    String value = input.getText().toString().trim();
                    if (!value.isEmpty()) {
                        currentProject = value;
                        projectButton.setText(value);
                        ensureAutoCode();
                    }
                }).show();
    }

    private void chooseCrs() {
        String[] options = {"WGS84 geográficas", "WGS84 UTM · Elegir zona…", "Coordenadas locales"};
        new AlertDialog.Builder(this)
                .setTitle("Sistema de coordenadas")
                .setItems(options, (dialog, which) -> {
                    if (which == 1) {
                        showUtmZoneDialog();
                        return;
                    }
                    currentCrs = options[which];
                    crsButton.setText(currentCrs);
                    geographicMode = which == 0;
                    refreshCoordinateUi();
                }).show();
    }

    private void showUtmZoneDialog() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20), dp(8), dp(20), 0);

        TextView zoneLabel = new TextView(this);
        zoneLabel.setText("Zona UTM (1–60)");
        zoneLabel.setTextColor(textColor);
        zoneLabel.setTextSize(14);
        panel.addView(zoneLabel);

        EditText zoneInput = new EditText(this);
        zoneInput.setSingleLine(true);
        zoneInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        zoneInput.setHint("Ej.: 19");
        int[] existing = parseUtmZone(currentCrs);
        if (existing != null) zoneInput.setText(Integer.toString(existing[0]));
        panel.addView(zoneInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView hemiLabel = new TextView(this);
        hemiLabel.setText("Hemisferio");
        hemiLabel.setTextColor(textColor);
        hemiLabel.setTextSize(14);
        LinearLayout.LayoutParams hemiLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hemiLp.setMargins(0, dp(8), 0, 0);
        panel.addView(hemiLabel, hemiLp);

        RadioGroup hemispheres = new RadioGroup(this);
        hemispheres.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton north = new RadioButton(this);
        north.setText("Norte (N)");
        north.setTextColor(textColor);
        north.setId(View.generateViewId());
        RadioButton south = new RadioButton(this);
        south.setText("Sur (S)");
        south.setTextColor(textColor);
        south.setId(View.generateViewId());
        hemispheres.addView(north, new RadioGroup.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        hemispheres.addView(south, new RadioGroup.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (existing != null && existing[1] < 0) south.setChecked(true);
        else north.setChecked(true);
        panel.addView(hemispheres);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("UTM mundial")
                .setView(panel)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Usar", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String raw = zoneInput.getText().toString().trim();
            int zone;
            try { zone = Integer.parseInt(raw); } catch (Exception ex) { zone = -1; }
            if (zone < 1 || zone > 60) {
                zoneInput.setError("Usa una zona entre 1 y 60");
                return;
            }
            char hemi = south.isChecked() ? 'S' : 'N';
            currentCrs = "WGS84 UTM " + zone + hemi;
            geographicMode = false;
            crsButton.setText(currentCrs);
            refreshCoordinateUi();
            dialog.dismiss();
        }));
        dialog.show();
    }

    private void chooseProjectFilter() {
        Set<String> values = new LinkedHashSet<>();
        values.add("Todos");
        for (NotebookStore.Entry entry : entries) if (!entry.project.trim().isEmpty()) values.add(entry.project);
        List<String> options = new ArrayList<>(values);
        new AlertDialog.Builder(this)
                .setTitle("Filtrar por proyecto")
                .setItems(options.toArray(new String[0]), (d, which) -> {
                    projectFilter = options.get(which);
                    projectFilterButton.setText("Proyecto: " + projectFilter);
                    renderRecords();
                }).show();
    }

    private void choosePhoto() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_PHOTO);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PHOTO && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            currentPhotoUri = uri.toString();
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
                showToast("Foto adjunta al punto.");
        }
    }

    private void captureGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        startGpsCapture();
    }

    private void startGpsCapture() {
        if (manager == null) return;
        try {
            currentSource = "GPS teléfono";
            statusSource.setText("Fuente\nGPS teléfono");
            statusSolution.setText("Solución\nBuscando…");
            Location gps = manager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location net = manager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            Location recent = newest(gps, net);
            if (recent != null) applyPhoneLocation(recent);
            manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, gpsListener);
            if (manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                manager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000L, 0f, gpsListener);
            }
            gpsListening = true;
            registerGnssStatus();
            showToast("GPS activo. Los campos se actualizarán con posiciones nuevas hasta salir de la pantalla.");
        } catch (SecurityException e) {
            showToast("No se pudo iniciar el GPS.");
        } catch (Exception e) {
            showToast("Activa la ubicación del teléfono e inténtalo nuevamente.");
        }
    }

    @SuppressWarnings("deprecation")
    private void registerGnssStatus() {
        if (manager == null || gpsStatusListener != null) return;
        gpsStatusListener = event -> {
            if (event != GpsStatus.GPS_EVENT_SATELLITE_STATUS) return;
            try {
                GpsStatus gpsStatus = manager.getGpsStatus(null);
                if (gpsStatus == null) return;
                int used = 0;
                for (GpsSatellite satellite : gpsStatus.getSatellites()) {
                    if (satellite.usedInFix()) used++;
                }
                satelliteCount = used;
                statusSatellites.setText("Satélites\n" + used);
            } catch (SecurityException ignored) {}
        };
        try { manager.addGpsStatusListener(gpsStatusListener); } catch (SecurityException ignored) {}
    }

    @SuppressWarnings("deprecation")
    private void stopGpsCapture() {
        if (manager != null && gpsListening) {
            try { manager.removeUpdates(gpsListener); } catch (Exception ignored) {}
        }
        if (manager != null && gpsStatusListener != null) {
            try { manager.removeGpsStatusListener(gpsStatusListener); } catch (Exception ignored) {}
        }
        gpsListening = false;
        gpsStatusListener = null;
    }

    private void applyPhoneLocation(Location loc) {
        if (loc == null) return;
        currentSource = "GPS teléfono";
        if (!geographicMode && loc.getLatitude() >= -80.0 && loc.getLatitude() <= 84.0) {
            UtmCoordinate utm = latLonToUtm(loc.getLatitude(), loc.getLongitude());
            northInput.setText(f3(utm.northing));
            eastInput.setText(f3(utm.easting));
            currentCrs = "WGS84 UTM " + utm.zone + utm.hemisphere;
            crsButton.setText(currentCrs);
        } else {
            geographicMode = true;
            northInput.setText(f7(loc.getLatitude()));
            eastInput.setText(f7(loc.getLongitude()));
            currentCrs = "WGS84 geográficas";
            crsButton.setText(currentCrs);
        }
        if (loc.hasAltitude()) elevationInput.setText(f3(loc.getAltitude()));
        String acc = loc.hasAccuracy() ? "±" + f1(loc.getAccuracy()) + " m / GPS" : "GPS";
        accuracyInput.setText(acc);
        statusSource.setText("Fuente\nGPS teléfono");
        statusAccuracy.setText("Precisión\n" + (loc.hasAccuracy() ? "±" + f1(loc.getAccuracy()) + " m" : "—"));
        statusSatellites.setText("Satélites\n" + (satelliteCount > 0 ? satelliteCount : "—"));
        statusSolution.setText("Solución\nGPS");
    }

    private Location newest(Location a, Location b) {
        if (a == null) return b;
        if (b == null) return a;
        return a.getTime() >= b.getTime() ? a : b;
    }

    private void savePoint() {
        String project = currentProject.trim().isEmpty() ? "General" : currentProject.trim();
        String code = codeInput.getText().toString().trim();
        String n = northInput.getText().toString().trim().replace(',', '.');
        String e = eastInput.getText().toString().trim().replace(',', '.');
        String z = elevationInput.getText().toString().trim().replace(',', '.');
        if (code.isEmpty() || n.isEmpty() || e.isEmpty()) {
            showToast("Código y coordenadas son necesarios.");
            return;
        }
        try {
            Double.parseDouble(n);
            Double.parseDouble(e);
            if (!z.isEmpty()) Double.parseDouble(z);
        } catch (Exception ex) {
            showToast("Revisa las coordenadas y la cota.");
            return;
        }
        if (!geographicMode && currentCrs.toUpperCase(Locale.US).contains("UTM") && parseUtmZone(currentCrs) == null) {
            showToast("Selecciona la zona UTM (1–60) y hemisferio antes de guardar.");
            return;
        }
        String accuracy = accuracyInput.getText().toString().trim();
        String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
        NotebookStore.Entry entry = new NotebookStore.Entry(
                project, code, n, e, z, currentCrs,
                descriptionInput.getText().toString().trim(), accuracy, currentSource, time,
                currentType, currentPhotoUri
        );
        if (editingIndex >= 0 && editingIndex < entries.size()) {
            entries.set(editingIndex, entry);
            NotebookStore.save(this, entries);
            showToast("Punto actualizado.");
        } else {
            NotebookStore.add(this, entry);
            showToast("Punto guardado.");
        }
        editingIndex = -1;
        saveButton.setText("Guardar punto");
        clearFormAfterSave();
        load();
    }

    private void editEntry(int index) {
        if (index < 0 || index >= entries.size()) return;
        NotebookStore.Entry e = entries.get(index);
        editingIndex = index;
        currentProject = e.project;
        projectButton.setText(currentProject);
        currentType = e.type;
        refreshTypeUi();
        codeInput.setText(e.code);
        elevationInput.setText(e.elevation);
        northInput.setText(e.north);
        eastInput.setText(e.east);
        currentCrs = e.crs;
        crsButton.setText(currentCrs);
        geographicMode = currentCrs.toLowerCase(Locale.US).contains("geográficas");
        refreshCoordinateUi();
        accuracyInput.setText(e.accuracy);
        descriptionInput.setText(e.description);
        currentPhotoUri = e.photoUri;
        currentSource = e.source.isEmpty() ? "Manual" : e.source;
        statusSource.setText("Fuente\n" + currentSource);
        saveButton.setText("Actualizar punto");
        if (mainScroll != null) mainScroll.smoothScrollTo(0, 0);
    }

    private void deleteEntry(int index) {
        if (index < 0 || index >= entries.size()) return;
        NotebookStore.Entry e = entries.get(index);
        new AlertDialog.Builder(this)
                .setTitle("Eliminar punto")
                .setMessage("¿Eliminar " + e.code + " de la libreta?")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Eliminar", (d, w) -> {
                    entries.remove(index);
                    NotebookStore.save(this, entries);
                    if (editingIndex == index) clearForm();
                    else if (editingIndex > index) editingIndex--;
                    renderRecords();
                }).show();
    }

    private void confirmClear() {
        if (entries.isEmpty()) return;
        new AlertDialog.Builder(this)
                .setTitle("Borrar libreta")
                .setMessage("Se eliminarán todos los puntos guardados localmente.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Borrar todo", (d, w) -> {
                    entries.clear();
                    NotebookStore.save(this, entries);
                    clearForm();
                    renderRecords();
                }).show();
    }

    private void clearFormAfterSave() {
        codeInput.setText("");
        northInput.setText("");
        eastInput.setText("");
        elevationInput.setText("");
        accuracyInput.setText("");
        descriptionInput.setText("");
        currentPhotoUri = "";
        currentSource = "Manual";
        resetStatus();
        ensureAutoCode();
    }

    private void clearForm() {
        editingIndex = -1;
        saveButton.setText("Guardar punto");
        currentProject = "General";
        projectButton.setText(currentProject);
        currentType = "Control";
        refreshTypeUi();
        currentCrs = DEFAULT_UTM_CRS;
        crsButton.setText(currentCrs);
        geographicMode = false;
        refreshCoordinateUi();
        northInput.setText("");
        eastInput.setText("");
        elevationInput.setText("");
        accuracyInput.setText("");
        descriptionInput.setText("");
        currentPhotoUri = "";
        currentSource = "Manual";
        resetStatus();
        ensureAutoCode();
    }

    private void resetStatus() {
        statusSource.setText("Fuente\nManual");
        statusAccuracy.setText("Precisión\n—");
        statusSatellites.setText("Satélites\n—");
        statusSolution.setText("Solución\nSin captura");
    }

    private void ensureAutoCode() {
        if (codeInput == null || editingIndex >= 0) return;
        String current = codeInput.getText().toString().trim();
        if (current.isEmpty() || looksAutoGenerated(current)) codeInput.setText(nextCodeForType(currentType));
    }

    private String nextCodeForType(String type) {
        String prefix;
        if ("Control".equals(type)) prefix = "CTRL-";
        else if ("BM".equals(type)) prefix = "BM-";
        else if ("Replanteo".equals(type)) prefix = "REP-";
        else prefix = "DET-";
        int max = 0;
        for (NotebookStore.Entry entry : entries) {
            String code = entry.code == null ? "" : entry.code.toUpperCase(Locale.US);
            if (!code.startsWith(prefix)) continue;
            try {
                int value = Integer.parseInt(code.substring(prefix.length()).replaceAll("[^0-9]", ""));
                max = Math.max(max, value);
            } catch (Exception ignored) {}
        }
        return prefix + String.format(Locale.US, "%04d", max + 1);
    }

    private boolean looksAutoGenerated(String code) {
        return code.matches("(?i)(CTRL|BM|DET|REP)-\\d{1,6}");
    }

    private boolean hasCoordinateValues() {
        return !blank(northInput) && !blank(eastInput);
    }

    private int[] parseUtmZone(String crs) {
        if (crs == null) return null;
        String upper = crs.toUpperCase(Locale.US);
        int idx = upper.indexOf("UTM");
        if (idx < 0) return null;
        String tail = upper.substring(idx + 3).trim().replace("ZONA", "").trim();
        String digits = tail.replaceAll("[^0-9].*$", "").replaceAll("[^0-9]", "");
        if (digits.isEmpty()) {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{1,2})\\s*([NS])").matcher(upper);
            if (!m.find()) return null;
            int zone = Integer.parseInt(m.group(1));
            if (zone < 1 || zone > 60) return null;
            boolean south = "S".equals(m.group(2));
            return new int[]{zone, south ? -1 : 1};
        }
        int zone = Integer.parseInt(digits);
        if (zone < 1 || zone > 60) return null;
        boolean south = upper.contains(zone + "S") || upper.endsWith("S");
        return new int[]{zone, south ? -1 : 1};
    }

    private UtmCoordinate latLonToUtm(double lat, double lon) {
        final double a = 6378137.0;
        final double eccSquared = 0.00669437999014;
        final double k0 = 0.9996;
        int zone = (int) Math.floor((lon + 180.0) / 6.0) + 1;
        if (lon == 180.0) zone = 60;
        // Excepciones UTM oficiales para Noruega y Svalbard.
        if (lat >= 56.0 && lat < 64.0 && lon >= 3.0 && lon < 12.0) zone = 32;
        if (lat >= 72.0 && lat < 84.0) {
            if (lon >= 0.0 && lon < 9.0) zone = 31;
            else if (lon >= 9.0 && lon < 21.0) zone = 33;
            else if (lon >= 21.0 && lon < 33.0) zone = 35;
            else if (lon >= 33.0 && lon < 42.0) zone = 37;
        }
        double lonOrigin = (zone - 1) * 6 - 180 + 3;
        double latRad = Math.toRadians(lat);
        double lonRad = Math.toRadians(lon);
        double lonOriginRad = Math.toRadians(lonOrigin);
        double eccPrimeSquared = eccSquared / (1 - eccSquared);
        double n = a / Math.sqrt(1 - eccSquared * Math.sin(latRad) * Math.sin(latRad));
        double t = Math.tan(latRad) * Math.tan(latRad);
        double c = eccPrimeSquared * Math.cos(latRad) * Math.cos(latRad);
        double aa = Math.cos(latRad) * (lonRad - lonOriginRad);
        double m = a * ((1 - eccSquared / 4 - 3 * eccSquared * eccSquared / 64 - 5 * eccSquared * eccSquared * eccSquared / 256) * latRad
                - (3 * eccSquared / 8 + 3 * eccSquared * eccSquared / 32 + 45 * eccSquared * eccSquared * eccSquared / 1024) * Math.sin(2 * latRad)
                + (15 * eccSquared * eccSquared / 256 + 45 * eccSquared * eccSquared * eccSquared / 1024) * Math.sin(4 * latRad)
                - (35 * eccSquared * eccSquared * eccSquared / 3072) * Math.sin(6 * latRad));
        double easting = k0 * n * (aa + (1 - t + c) * Math.pow(aa, 3) / 6
                + (5 - 18 * t + t * t + 72 * c - 58 * eccPrimeSquared) * Math.pow(aa, 5) / 120) + 500000.0;
        double northing = k0 * (m + n * Math.tan(latRad) * (aa * aa / 2
                + (5 - t + 9 * c + 4 * c * c) * Math.pow(aa, 4) / 24
                + (61 - 58 * t + t * t + 600 * c - 330 * eccPrimeSquared) * Math.pow(aa, 6) / 720));
        char hemisphere = lat < 0 ? 'S' : 'N';
        if (lat < 0) northing += 10000000.0;
        return new UtmCoordinate(zone, hemisphere, easting, northing);
    }

    private LatLon utmToLatLon(double northing, double easting, int zone, boolean south) {
        final double a = 6378137.0;
        final double eccSquared = 0.00669437999014;
        final double k0 = 0.9996;
        double x = easting - 500000.0;
        double y = northing;
        if (south) y -= 10000000.0;
        double eccPrimeSquared = eccSquared / (1 - eccSquared);
        double m = y / k0;
        double mu = m / (a * (1 - eccSquared / 4 - 3 * eccSquared * eccSquared / 64 - 5 * eccSquared * eccSquared * eccSquared / 256));
        double e1 = (1 - Math.sqrt(1 - eccSquared)) / (1 + Math.sqrt(1 - eccSquared));
        double phi1Rad = mu
                + (3 * e1 / 2 - 27 * Math.pow(e1, 3) / 32) * Math.sin(2 * mu)
                + (21 * e1 * e1 / 16 - 55 * Math.pow(e1, 4) / 32) * Math.sin(4 * mu)
                + (151 * Math.pow(e1, 3) / 96) * Math.sin(6 * mu)
                + (1097 * Math.pow(e1, 4) / 512) * Math.sin(8 * mu);
        double n1 = a / Math.sqrt(1 - eccSquared * Math.sin(phi1Rad) * Math.sin(phi1Rad));
        double t1 = Math.tan(phi1Rad) * Math.tan(phi1Rad);
        double c1 = eccPrimeSquared * Math.cos(phi1Rad) * Math.cos(phi1Rad);
        double r1 = a * (1 - eccSquared) / Math.pow(1 - eccSquared * Math.sin(phi1Rad) * Math.sin(phi1Rad), 1.5);
        double d = x / (n1 * k0);
        double lat = phi1Rad - (n1 * Math.tan(phi1Rad) / r1) * (d * d / 2
                - (5 + 3 * t1 + 10 * c1 - 4 * c1 * c1 - 9 * eccPrimeSquared) * Math.pow(d, 4) / 24
                + (61 + 90 * t1 + 298 * c1 + 45 * t1 * t1 - 252 * eccPrimeSquared - 3 * c1 * c1) * Math.pow(d, 6) / 720);
        double lon = (d - (1 + 2 * t1 + c1) * Math.pow(d, 3) / 6
                + (5 - 2 * c1 + 28 * t1 - 3 * c1 * c1 + 8 * eccPrimeSquared + 24 * t1 * t1) * Math.pow(d, 5) / 120) / Math.cos(phi1Rad);
        double lonOrigin = (zone - 1) * 6 - 180 + 3;
        return new LatLon(Math.toDegrees(lat), lonOrigin + Math.toDegrees(lon));
    }

    private TextView statusMetric(String label, String value, String icon) {
        TextView tv = text(icon + "  " + label + "\n" + value, 12, true);
        tv.setGravity(Gravity.CENTER);
        tv.setTextColor(textColor);
        tv.setPadding(dp(4), dp(4), dp(4), dp(4));
        return tv;
    }

    private TextView fieldCaption(String value) {
        TextView tv = text(value, 13, true);
        tv.setTextColor(subTextColor);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), dp(4), 0, dp(4));
        tv.setLayoutParams(lp);
        return tv;
    }

    private Button segmentButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextColor(textColor);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(8), 0, dp(8), 0);
        button.setSingleLine(true);
        button.setEllipsize(TextUtils.TruncateAt.END);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setMinHeight(0);
        button.setMinimumHeight(0);
        ResponsiveUi.configureCompactText(button, 12, 9, 1);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        lp.setMargins(dp(2), 0, dp(2), dp(4));
        button.setLayoutParams(lp);
        return button;
    }

    private void styleSegment(Button button, boolean selected) {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(10));
        bg.setColor(selected ? accent : inputColor);
        bg.setStroke(dp(1), selected ? accent : withAlpha(borderColor, 150));
        button.setBackground(bg);
        button.setTextColor(selected ? Color.WHITE : textColor);
    }

    private Button selectorButton(String label) {
        Button button = secondaryButton(label);
        button.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        button.setSingleLine(true);
        button.setEllipsize(TextUtils.TruncateAt.END);
        button.setPadding(dp(14), 0, dp(14), 0);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setMinHeight(0);
        button.setMinimumHeight(0);
        ResponsiveUi.configureCompactText(button, 13f, 9.5f, 1);
        return button;
    }

    private void fitSingleLineInput(EditText input) {
        if (input == null) return;
        ResponsiveUi.configureCompactText(input, 13.6f, 9.5f, 1);
        input.setSingleLine(true);
        input.setMaxLines(1);
        input.setHorizontallyScrolling(true);
        input.setPadding(dp(12), 0, dp(12), 0);
        input.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        input.setMinWidth(0);
        input.setMinimumWidth(0);
    }

    private LinearLayout labeledDynamic(TextView label, View child) {
        LinearLayout box = vertical();
        box.addView(label);
        box.addView(child, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), 0, dp(3), 0);
        box.setLayoutParams(lp);
        return box;
    }

    private LinearLayout labeledTall(String labelText, View child, int height) {
        LinearLayout box = vertical();
        TextView label = text(labelText, 12, true);
        label.setTextColor(subTextColor);
        box.addView(label);
        box.addView(child, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), 0, dp(3), dp(5));
        box.setLayoutParams(lp);
        return box;
    }

    private Button compactAction(String label, int color, boolean danger) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextColor(danger ? Color.rgb(244, 81, 81) : color);
        ResponsiveUi.configureCompactText(button, 12, 8, 1);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(inputColor);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), danger ? Color.rgb(244, 81, 81) : withAlpha(color, 180));
        button.setBackground(bg);
        return button;
    }

    private Button squareAction(String label, int color) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextColor(color);
        ResponsiveUi.configureCompactText(button, 17, 4, 1);
        button.setPadding(0, 0, 0, 0);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(inputColor);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), color);
        button.setBackground(bg);
        return button;
    }

    private TextView badge(String label, int color) {
        TextView tv = text(label, 12, true);
        tv.setTextColor(color);
        tv.setPadding(dp(10), dp(5), dp(10), dp(5));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(withAlpha(color, 35));
        bg.setCornerRadius(dp(30));
        bg.setStroke(dp(1), withAlpha(color, 170));
        tv.setBackground(bg);
        return tv;
    }

    private TextView typeIcon(String type) {
        String icon = "•••";
        if ("Control".equals(type)) icon = "◎";
        else if ("BM".equals(type)) icon = "△";
        else if ("Replanteo".equals(type)) icon = "⚑";
        TextView tv = text(icon, 17, true);
        int color = typeColor(type);
        tv.setTextColor(color);
        tv.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(withAlpha(color, 38));
        bg.setCornerRadius(dp(22));
        tv.setBackground(bg);
        return tv;
    }

    private int typeColor(String type) {
        if ("Control".equals(type)) return Color.rgb(84, 210, 108);
        if ("BM".equals(type)) return Color.rgb(255, 171, 0);
        if ("Replanteo".equals(type)) return Color.rgb(62, 154, 255);
        return Color.rgb(190, 100, 230);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startGpsCapture();
        } else if (requestCode == REQ_LOCATION) {
            showToast("Sin permiso no se puede capturar la posición GPS.");
        }
    }

    private static final class UtmCoordinate {
        final int zone;
        final char hemisphere;
        final double easting;
        final double northing;
        UtmCoordinate(int zone, char hemisphere, double easting, double northing) {
            this.zone = zone;
            this.hemisphere = hemisphere;
            this.easting = easting;
            this.northing = northing;
        }
    }

    private static final class LatLon {
        final double lat;
        final double lon;
        LatLon(double lat, double lon) { this.lat = lat; this.lon = lon; }
    }
}
