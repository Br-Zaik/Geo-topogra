package com.bph.geotopo;

import android.Manifest;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public class ExternalGnssActivity extends BaseToolActivity {
    private static final int REQ_BT = 9560;
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    // Dedicated palette for the approved design 2.
    private static final int SCREEN_BG = Color.rgb(3, 20, 33);
    private static final int BAR_START = Color.rgb(5, 53, 82);
    private static final int BAR_END = Color.rgb(4, 32, 52);
    private static final int CARD_START = Color.rgb(15, 39, 63);
    private static final int CARD_END = Color.rgb(8, 29, 45);
    private static final int TILE_START = Color.rgb(10, 33, 52);
    private static final int TILE_END = Color.rgb(7, 25, 40);
    private static final int FIELD_BG = Color.rgb(8, 27, 42);
    private static final int STROKE = Color.rgb(28, 104, 185);
    private static final int TEXT = Color.rgb(245, 248, 252);
    private static final int SUBTEXT = Color.rgb(188, 203, 216);
    private static final int PRIMARY_A = Color.rgb(31, 147, 255);
    private static final int PRIMARY_B = Color.rgb(22, 95, 236);
    private static final int WARN = Color.rgb(255, 190, 25);
    private static final int WARN_DARK_A = Color.rgb(63, 46, 11);
    private static final int WARN_DARK_B = Color.rgb(41, 34, 16);
    private static final int RED = Color.rgb(255, 102, 86);
    private static final int BLUE = Color.rgb(44, 141, 255);

    private BluetoothAdapter adapter;
    private BluetoothSocket socket;
    private Thread readThread;
    private volatile boolean reading;

    private TextView summaryStateValue;
    private TextView summaryStateDot;
    private TextView summaryProfileValue;
    private TextView summaryReceiverValue;
    private TextView statusInfo;
    private Button connectButton;
    private Button disconnectButton;
    private EditText projectInput, codeInput, descriptionInput;

    private Double latitude, longitude, altitude, hdop;
    private Integer satellites, quality;
    private String lastSentence = "—";
    private String connectedDevice = "—";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        adapter = BluetoothAdapter.getDefaultAdapter();

        getWindow().setStatusBarColor(Color.rgb(1, 12, 25));
        getWindow().setNavigationBarColor(Color.BLACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(SCREEN_BG);
        root.addView(buildTopBar(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setBackgroundColor(SCREEN_BG);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundColor(SCREEN_BG);
        content.setPadding(dp(12), dp(10), dp(12), dp(24));

        content.addView(buildSummaryRow());
        content.addView(buildConnectionCard());
        content.addView(buildSaveCard());

        scroll.addView(content, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        render();
    }

    private View buildTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(7), dp(7), dp(8), dp(9));
        bar.setBackground(gradient(BAR_START, BAR_END, 0, 0, 0));

        TextView back = label("‹", 34f, false, Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(54), dp(58)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);

        TextView title = label("GNSS externo Bluetooth", 22.5f, true, TEXT);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        titles.addView(title);

        TextView subtitle = label("Lectura NMEA desde un receptor emparejado", 12.8f, false, Color.rgb(214, 226, 238));
        subtitle.setMaxLines(2);
        subtitle.setLineSpacing(0, 1.02f);
        titles.addView(subtitle);

        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView btBadge = label("ᛒ", 24f, true, BLUE);
        btBadge.setGravity(Gravity.CENTER);
        btBadge.setBackground(gradient(Color.rgb(10, 35, 58), Color.rgb(8, 27, 43), 14, 1, STROKE));
        LinearLayout.LayoutParams badgeLp = new LinearLayout.LayoutParams(dp(42), dp(42));
        bar.addView(btBadge, badgeLp);
        return bar;
    }

    private View buildSummaryRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, 0, 0, 0);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rowLp.setMargins(0, 0, 0, dp(10));
        row.setLayoutParams(rowLp);

        summaryStateDot = value("•", 18f, true, RED);
        summaryStateValue = value("Desconectado", 14f, true, RED);
        summaryProfileValue = value("SPP / NMEA", 14f, true, TEXT);
        summaryReceiverValue = value("No seleccionado", 14f, true, SUBTEXT);

        row.addView(summaryTile("◉", "Estado", summaryStateDot, summaryStateValue), summaryLp());
        row.addView(summaryTile("⇄", "Perfil", null, summaryProfileValue), summaryLp());
        row.addView(summaryTile("▭", "Receptor", null, summaryReceiverValue), summaryLp());
        return row;
    }

    private LinearLayout.LayoutParams summaryLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(108), 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        return lp;
    }

    private View summaryTile(String iconText, String titleText, TextView leftValue, TextView mainValue) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setPadding(dp(10), dp(10), dp(10), dp(10));
        tile.setBackground(gradient(TILE_START, TILE_END, 14, 1, STROKE));

        TextView icon = label(iconText, 20f, true, BLUE);
        icon.setGravity(Gravity.START);
        tile.addView(icon);

        TextView title = label(titleText, 11.3f, false, SUBTEXT);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        titleLp.setMargins(0, dp(2), 0, dp(8));
        title.setLayoutParams(titleLp);
        tile.addView(title);

        if (leftValue != null) {
            LinearLayout line = new LinearLayout(this);
            line.setOrientation(LinearLayout.HORIZONTAL);
            line.setGravity(Gravity.CENTER_VERTICAL);
            line.addView(leftValue);
            mainValue.setPadding(dp(3), 0, 0, 0);
            line.addView(mainValue, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            tile.addView(line);
        } else {
            tile.addView(mainValue);
        }
        return tile;
    }

    private View buildConnectionCard() {
        LinearLayout card = cardContainer();

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);

        TextView icon = iconBox("ᛒ", 22f, BLUE, dp(48), dp(48));
        head.addView(icon);

        TextView title = label("Conexión Bluetooth clásica", 18f, true, TEXT);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        titleLp.setMargins(dp(10), 0, 0, 0);
        head.addView(title, titleLp);

        TextView info = label("i", 18f, true, Color.rgb(112, 189, 255));
        info.setGravity(Gravity.CENTER);
        head.addView(info, new LinearLayout.LayoutParams(dp(28), dp(28)));
        card.addView(head);

        TextView description = label(
                "Empareja primero el receptor desde Ajustes de Android.\nGeoTopo se conecta al perfil serial SPP y lee mensajes\nNMEA GGA/RMC.",
                12.9f, false, SUBTEXT);
        description.setLineSpacing(0, 1.12f);
        LinearLayout.LayoutParams descLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        descLp.setMargins(0, dp(10), 0, 0);
        description.setLayoutParams(descLp);
        card.addView(description);

        card.addView(warnBox(
                "No todos los receptores usan Bluetooth clásico SPP.\nAlgunos equipos BLE o con protocolo del fabricante\nnecesitarán una integración específica."));

        connectButton = actionButton("ᛒ   Seleccionar receptor emparejado", true);
        connectButton.setOnClickListener(v -> requestDevice());
        card.addView(connectButton);

        disconnectButton = actionButton("⌁   Desconectar", false);
        disconnectButton.setOnClickListener(v -> disconnect());
        card.addView(disconnectButton);

        statusInfo = statusPanel();
        card.addView(statusInfo);

        return card;
    }

    private View buildSaveCard() {
        LinearLayout card = cardContainer();

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(iconBox("▤", 20f, BLUE, dp(48), dp(48)));

        TextView title = label("Guardar solución en libreta", 18f, true, TEXT);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        titleLp.setMargins(dp(10), 0, 0, 0);
        head.addView(title, titleLp);
        card.addView(head);

        projectInput = entryField("General");
        codeInput = entryField("Código del punto");
        descriptionInput = entryField("Descripción");

        card.addView(fieldBlock("Proyecto", projectInput, true));

        LinearLayout fieldsRow = new LinearLayout(this);
        fieldsRow.setOrientation(LinearLayout.HORIZONTAL);
        fieldsRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rowLp.setMargins(0, dp(4), 0, dp(6));
        fieldsRow.setLayoutParams(rowLp);

        LinearLayout codeBlock = fieldBlock("Código", codeInput, false);
        LinearLayout.LayoutParams codeLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        codeLp.setMargins(0, 0, dp(5), 0);
        fieldsRow.addView(codeBlock, codeLp);

        LinearLayout descBlock = fieldBlock("Descripción", descriptionInput, false);
        LinearLayout.LayoutParams descLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        descLp.setMargins(dp(5), 0, 0, 0);
        fieldsRow.addView(descBlock, descLp);

        card.addView(fieldsRow);

        Button saveButton = actionButton("◈   Guardar punto GNSS externo", true);
        saveButton.setOnClickListener(v -> savePoint());
        card.addView(saveButton);
        return card;
    }

    private LinearLayout fieldBlock(String labelText, EditText input, boolean showArrow) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);

        TextView label = label(labelText, 11.8f, false, SUBTEXT);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        labelLp.setMargins(dp(2), 0, dp(2), dp(5));
        label.setLayoutParams(labelLp);
        box.addView(label);

        if (showArrow) {
            LinearLayout holder = new LinearLayout(this);
            holder.setOrientation(LinearLayout.HORIZONTAL);
            holder.setGravity(Gravity.CENTER_VERTICAL);
            holder.setBackground(fieldBg());
            holder.setPadding(dp(12), 0, dp(12), 0);
            holder.addView(input, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
            TextView arrow = label("⌄", 22f, true, SUBTEXT);
            arrow.setGravity(Gravity.CENTER);
            holder.addView(arrow, new LinearLayout.LayoutParams(dp(26), ViewGroup.LayoutParams.MATCH_PARENT));
            box.addView(holder, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        } else {
            box.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        }
        return box;
    }

    private EditText entryField(String hint) {
        EditText input = new EditText(this);
        input.setTextColor(TEXT);
        input.setHintTextColor(Color.rgb(132, 154, 177));
        input.setHint(hint);
        input.setBackgroundColor(Color.TRANSPARENT);
        input.setPadding(0, 0, 0, 0);
        input.setSingleLine(true);
        ResponsiveUi.configureText(input, 14);
        if ("General".equals(hint)) input.setText("General");
        return input;
    }

    private TextView statusPanel() {
        TextView view = label("Sin receptor conectado.", 13.2f, false, SUBTEXT);
        view.setLineSpacing(0, 1.1f);
        view.setPadding(dp(14), dp(13), dp(14), dp(13));
        view.setBackground(fieldBg());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(8), 0, dp(0));
        view.setLayoutParams(lp);
        return view;
    }

    private Button actionButton(String text, boolean primary) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(10), 0, dp(10), 0);
        button.setMinWidth(0);
        button.setMinHeight(0);
        ResponsiveUi.configureCompactText(button, 14.5f, 11f, 1);
        button.setBackground(primary
                ? gradient(PRIMARY_A, PRIMARY_B, 12, 0, 0)
                : gradient(Color.rgb(9, 28, 44), Color.rgb(7, 24, 39), 12, 1, STROKE));
        if (Build.VERSION.SDK_INT >= 21) {
            button.setStateListAnimator(null);
            button.setElevation(primary ? dp(2) : 0);
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        lp.setMargins(0, dp(8), 0, 0);
        button.setLayoutParams(lp);
        return button;
    }

    private TextView warnBox(String text) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(13), 0, dp(2));

        TextView warn = label("⚠   " + text, 12.9f, false, Color.rgb(240, 226, 159));
        warn.setLineSpacing(0, 1.12f);
        warn.setPadding(dp(14), dp(12), dp(14), dp(12));
        warn.setBackground(gradient(WARN_DARK_A, WARN_DARK_B, 13, 1, WARN));
        warn.setLayoutParams(lp);
        return warn;
    }

    private LinearLayout cardContainer() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(13), dp(12), dp(13));
        card.setBackground(gradient(CARD_START, CARD_END, 18, 1, STROKE));
        if (Build.VERSION.SDK_INT >= 21) card.setElevation(dp(1.5f));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(11));
        card.setLayoutParams(lp);
        return card;
    }

    private GradientDrawable fieldBg() {
        return gradient(FIELD_BG, FIELD_BG, 12, 1, Color.rgb(33, 91, 146));
    }

    private GradientDrawable gradient(int start, int end, int radiusDp, int strokeDp, int strokeColor) {
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{start, end});
        bg.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) bg.setStroke(dp(strokeDp), strokeColor);
        return bg;
    }

    private TextView label(String text, float size, boolean bold, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(color);
        ResponsiveUi.configureText(view, size);
        view.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return view;
    }

    private TextView value(String text, float size, boolean bold, int color) {
        TextView view = label(text, size, bold, color);
        view.setSingleLine(true);
        view.setEllipsize(TextUtils.TruncateAt.END);
        return view;
    }

    private TextView iconBox(String text, float size, int color, int width, int height) {
        TextView view = label(text, size, true, color);
        view.setGravity(Gravity.CENTER);
        view.setBackground(gradient(Color.rgb(13, 47, 80), Color.rgb(8, 35, 57), 14, 1, Color.rgb(40, 111, 187)));
        view.setLayoutParams(new LinearLayout.LayoutParams(width, height));
        return view;
    }

    private void requestDevice() {
        if (adapter == null) {
            statusInfo.setText("Este dispositivo no tiene Bluetooth compatible.");
            return;
        }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT);
            return;
        }
        showDevices();
    }

    private void showDevices() {
        try {
            if (!adapter.isEnabled()) {
                statusInfo.setText("Activa Bluetooth y empareja el receptor desde Ajustes de Android.");
                return;
            }
            Set<BluetoothDevice> bonded = adapter.getBondedDevices();
            if (bonded == null || bonded.isEmpty()) {
                statusInfo.setText("No hay dispositivos Bluetooth emparejados.");
                return;
            }
            List<BluetoothDevice> devices = new ArrayList<>(bonded);
            String[] names = new String[devices.size()];
            for (int i = 0; i < devices.size(); i++) {
                BluetoothDevice d = devices.get(i);
                names[i] = safeName(d) + "\n" + d.getAddress();
            }
            new AlertDialog.Builder(this).setTitle("Selecciona el receptor GNSS")
                    .setItems(names, (dialog, which) -> connect(devices.get(which)))
                    .setNegativeButton("Cancelar", null)
                    .show();
        } catch (SecurityException e) {
            statusInfo.setText("No se concedió permiso de Bluetooth.");
        }
    }

    private String safeName(BluetoothDevice d) {
        try {
            String n = d.getName();
            return n == null || n.trim().isEmpty() ? "Dispositivo sin nombre" : n;
        } catch (SecurityException e) {
            return "Dispositivo Bluetooth";
        }
    }

    private void connect(BluetoothDevice device) {
        disconnect();
        connectedDevice = safeName(device);
        statusInfo.setText("Conectando con " + connectedDevice + "...");
        connectButton.setEnabled(false);
        disconnectButton.setEnabled(false);
        render();
        readThread = new Thread(() -> {
            try {
                BluetoothSocket s = device.createRfcommSocketToServiceRecord(SPP);
                socket = s;
                s.connect();
                reading = true;
                runOnUiThread(() -> {
                    connectButton.setEnabled(true);
                    disconnectButton.setEnabled(true);
                    render();
                });
                BufferedReader reader = new BufferedReader(new InputStreamReader(s.getInputStream()));
                String line;
                while (reading && (line = reader.readLine()) != null) {
                    parseNmea(line.trim());
                }
            } catch (Exception e) {
                runOnUiThread(() -> {
                    connectButton.setEnabled(true);
                    disconnectButton.setEnabled(true);
                    statusInfo.setText("No se pudo conectar con " + connectedDevice + ". Verifica que el receptor use Bluetooth clásico SPP y no esté conectado a otra app.");
                    render();
                });
            } finally {
                reading = false;
                closeSocket();
                runOnUiThread(this::render);
            }
        }, "GeoTopo-NMEA");
        readThread.start();
    }

    private void parseNmea(String line) {
        if (line == null || line.isEmpty() || !validChecksum(line)) return;
        String[] f = line.split(",", -1);
        try {
            String type = f.length == 0 ? "" : f[0];
            if (type.endsWith("GGA") && f.length >= 10) {
                if (!f[2].isEmpty() && !f[4].isEmpty()) {
                    latitude = nmeaCoordinate(f[2], f[3]);
                    longitude = nmeaCoordinate(f[4], f[5]);
                }
                quality = f[6].isEmpty() ? 0 : Integer.parseInt(f[6]);
                satellites = f[7].isEmpty() ? null : Integer.parseInt(f[7]);
                hdop = f[8].isEmpty() ? null : Double.parseDouble(f[8]);
                altitude = f[9].isEmpty() ? null : Double.parseDouble(f[9]);
                lastSentence = "GGA";
            } else if (type.endsWith("RMC") && f.length >= 7) {
                if ("A".equals(f[2]) && !f[3].isEmpty() && !f[5].isEmpty()) {
                    latitude = nmeaCoordinate(f[3], f[4]);
                    longitude = nmeaCoordinate(f[5], f[6]);
                }
                lastSentence = "RMC";
            }
        } catch (Exception ignored) {
        }
        runOnUiThread(this::render);
    }

    private boolean validChecksum(String line) {
        if (!line.startsWith("$") || !line.contains("*")) return true;
        int star = line.indexOf('*');
        if (star <= 1 || star + 2 >= line.length()) return false;
        int checksum = 0;
        for (int i = 1; i < star; i++) checksum ^= line.charAt(i);
        try {
            return checksum == Integer.parseInt(line.substring(star + 1, star + 3), 16);
        } catch (Exception e) {
            return false;
        }
    }

    private double nmeaCoordinate(String raw, String hemisphere) {
        double value = Double.parseDouble(raw);
        double degrees = Math.floor(value / 100.0);
        double minutes = value - degrees * 100.0;
        double decimal = degrees + minutes / 60.0;
        if ("S".equalsIgnoreCase(hemisphere) || "W".equalsIgnoreCase(hemisphere)) decimal = -decimal;
        return decimal;
    }

    private void render() {
        boolean connected = reading;
        String shortState = connected ? "Conectado" : "Desconectado";
        summaryStateDot.setText("•");
        summaryStateDot.setTextColor(connected ? Color.rgb(70, 230, 120) : RED);
        summaryStateValue.setText(shortState);
        summaryStateValue.setTextColor(connected ? Color.rgb(70, 230, 120) : RED);
        summaryProfileValue.setText("SPP / NMEA");
        summaryReceiverValue.setText(connectedDevice.equals("—") ? "No seleccionado" : connectedDevice);
        summaryReceiverValue.setTextColor(connectedDevice.equals("—") ? SUBTEXT : TEXT);

        connectButton.setEnabled(!connected && adapter != null);
        disconnectButton.setEnabled(connected || !connectedDevice.equals("—"));

        if (!connected && connectedDevice.equals("—")) {
            statusInfo.setText("Sin receptor conectado.");
        } else if (!connected) {
            statusInfo.setText("Receptor: " + connectedDevice + "\nEstado: DESCONECTADO");
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append("Receptor: ").append(connectedDevice)
                    .append("\nEstado: CONECTADO / LEYENDO NMEA")
                    .append("\nLatitud: ").append(value7(latitude))
                    .append("\nLongitud: ").append(value7(longitude))
                    .append("\nAltitud: ").append(altitude == null ? "—" : f3(altitude) + " m")
                    .append("\nSolución: ").append(fixName(quality == null ? 0 : quality))
                    .append("\nSatélites: ").append(satellites == null ? "—" : satellites)
                    .append(" · HDOP: ").append(hdop == null ? "—" : f2(hdop))
                    .append("\nÚltimo mensaje válido: ").append(lastSentence);
            statusInfo.setText(sb.toString());
        }
    }

    private String value7(Double d) {
        return d == null ? "—" : f7(d);
    }

    private String fixName(int q) {
        switch (q) {
            case 1:
                return "Autónomo";
            case 2:
                return "DGPS";
            case 4:
                return "RTK fijo";
            case 5:
                return "RTK flotante";
            case 6:
                return "Estimado";
            default:
                return "Sin solución";
        }
    }

    private void savePoint() {
        if (latitude == null || longitude == null || quality == null || quality == 0) {
            showToast("Todavía no existe una solución GNSS válida.");
            return;
        }
        String project = projectInput.getText().toString().trim();
        if (project.isEmpty()) project = "General";
        String code = codeInput.getText().toString().trim();
        if (code.isEmpty()) {
            showToast("Escribe un código para el punto.");
            return;
        }
        String description = descriptionInput.getText().toString().trim();
        String accuracy = hdop == null ? "" : "HDOP " + f2(hdop) + " · " + fixName(quality);
        NotebookStore.add(this, new NotebookStore.Entry(project, code, f7(latitude), f7(longitude),
                altitude == null ? "" : f3(altitude), "WGS84 geográficas", description, accuracy, "GNSS Bluetooth",
                new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())));
        codeInput.setText("");
        descriptionInput.setText("");
        showToast("Punto guardado en la libreta de campo.");
    }

    private void disconnect() {
        reading = false;
        closeSocket();
        connectedDevice = "—";
        render();
    }

    private void closeSocket() {
        BluetoothSocket s = socket;
        socket = null;
        if (s != null) {
            try {
                s.close();
            } catch (Exception ignored) {
            }
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            showDevices();
        } else if (requestCode == REQ_BT) {
            statusInfo.setText("Sin permiso de Bluetooth no se puede conectar al receptor.");
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        disconnect();
    }
}
