package com.bph.geotopo;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import org.maplibre.android.MapLibre;
import org.maplibre.android.annotations.Marker;
import org.maplibre.android.annotations.MarkerOptions;
import org.maplibre.android.camera.CameraUpdateFactory;
import org.maplibre.android.geometry.LatLng;
import org.maplibre.android.geometry.LatLngBounds;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapView;
import org.maplibre.android.maps.Style;
import org.maplibre.android.style.layers.Layer;
import org.maplibre.android.style.layers.PropertyFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class OfflineMapActivity extends BaseToolActivity {
    private static final int REQ_IMPORT = 9590;
    private static final int REQ_LOCATION = 9591;
    private static final String KEY_PATH = "offline_mbtiles_path";
    private static final String KEY_NAME = "offline_mbtiles_name";
    private static final String KEY_OPACITY = "offline_mbtiles_opacity";

    private MapView mapView;
    private MapLibreMap map;
    private final MbtilesServer server = new MbtilesServer();
    private Marker locationMarker;
    private LocationManager locationManager;

    private LinearLayout libraryList;
    private TextView libraryCount;
    private TextView selectedTitle;
    private TextView selectedBadge;
    private TextView metaLeft;
    private TextView metaRight;
    private TextView statusBox;
    private TextView emptyHint;
    private Button renameButton;
    private Button deleteButton;
    private Button locationButton;
    private Button extentButton;
    private Button validateButton;
    private SeekBar opacitySeek;
    private TextView opacityLabel;
    private TextView mapEmptyOverlay;

    private final List<OfflineMapInfo> library = new ArrayList<>();
    private OfflineMapInfo selectedMap;
    private float currentOpacity = 1f;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        MapLibre.getInstance(this);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        currentOpacity = getSharedPreferences(PREFS, MODE_PRIVATE).getFloat(KEY_OPACITY, 1f);

        LinearLayout root = page("Mapas sin internet", "Paquetes ráster MBTiles propios o autorizados");
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout topContent = vertical();
        int pagePad = ResponsiveUi.isNarrow(this) ? dp(10) : dp(12);
        topContent.setPadding(pagePad, dp(10), pagePad, dp(18));
        scroll.addView(topContent, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        topContent.addView(buildIntroCard());
        topContent.addView(buildLibraryCard());
        topContent.addView(buildSelectedCard());
        topContent.addView(buildOpacityCard());

        FrameLayout mapHolder = new FrameLayout(this);
        GradientDrawable mapBg = new GradientDrawable();
        mapBg.setColor(Color.rgb(5, 24, 39));
        mapBg.setCornerRadius(dp(14));
        mapBg.setStroke(dp(1), withAlpha(borderColor, 120));
        mapHolder.setBackground(mapBg);
        LinearLayout.LayoutParams mapLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ResponsiveUi.isNarrow(this) ? dp(320) : dp(380));
        mapLp.setMargins(0, 0, 0, dp(10));
        topContent.addView(mapHolder, mapLp);

        mapView = new MapView(this);
        mapView.onCreate(savedInstanceState);
        mapHolder.addView(mapView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        mapEmptyOverlay = text("Sin mapa offline\n\nImporta un archivo MBTiles para visualizarlo aquí.", 14, true);
        mapEmptyOverlay.setTextColor(Color.rgb(183, 205, 226));
        mapEmptyOverlay.setGravity(Gravity.CENTER);
        mapEmptyOverlay.setPadding(dp(28), dp(28), dp(28), dp(28));
        GradientDrawable emptyBg = new GradientDrawable();
        emptyBg.setColor(Color.rgb(5, 24, 39));
        emptyBg.setCornerRadius(dp(14));
        emptyBg.setStroke(dp(1), withAlpha(borderColor, 120));
        mapEmptyOverlay.setBackground(emptyBg);
        mapHolder.addView(mapEmptyOverlay, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        mapHolder.addView(buildMapOverlay(), new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END | Gravity.CENTER_VERTICAL));

        setContentView(root);
        mapView.getMapAsync(m -> {
            map = m;
            map.getUiSettings().setAttributionEnabled(false);
            map.getUiSettings().setLogoEnabled(false);
            map.getUiSettings().setCompassEnabled(false);
            refreshLibrary(true);
        });
    }

    private View buildIntroCard() {
        LinearLayout card = card();
        card.addView(infoBanner("▣", "Importa un archivo MBTiles ráster (PNG, JPG o WEBP). GeoTopo lo copia al almacenamiento privado del dispositivo y lo abre sin internet mediante un servidor local."));
        card.addView(warning("GeoTopo no descarga masivamente desde OpenStreetMap u otros servidores públicos. Debes usar un paquete creado por ti o cuyo proveedor permita almacenamiento offline y conservar su atribución."));
        return card;
    }

    private View buildLibraryCard() {
        LinearLayout card = card();

        LinearLayout header = horizontal();
        header.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView title = text("Biblioteca de mapas", 17, true);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        libraryCount = pillText("0 mapas", accent, withAlpha(accent, 44), false);
        header.addView(libraryCount);
        card.addView(header);

        Button importButton = primaryButton("Importar MBTiles");
        importButton.setOnClickListener(v -> chooseFile());
        card.addView(importButton);

        libraryList = vertical();
        card.addView(libraryList);
        return card;
    }

    private View buildSelectedCard() {
        LinearLayout card = card();

        LinearLayout header = horizontal();
        header.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        selectedTitle = text("Ningún mapa seleccionado", 18, true);
        header.addView(selectedTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        selectedBadge = pillText("SIN MAPA", Color.rgb(140, 148, 161), withAlpha(Color.rgb(140, 148, 161), 40), false);
        header.addView(selectedBadge);
        card.addView(header);

        LinearLayout actionsHeader = horizontal();
        renameButton = inlineActionButton("Renombrar", accent);
        renameButton.setOnClickListener(v -> renameSelected());
        actionsHeader.addView(renameButton, weight());
        deleteButton = inlineActionButton("Eliminar", Color.rgb(240, 97, 97));
        deleteButton.setOnClickListener(v -> deleteSelected());
        actionsHeader.addView(deleteButton, weight());
        card.addView(actionsHeader);

        LinearLayout metaRow = horizontal();
        metaLeft = resultBoxCompact("Extensión: —\nZoom mínimo: —\nZoom máximo: —");
        metaRow.addView(metaLeft, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        metaRight = resultBoxCompact("Formato: —\nTamaño: —\nAtribución: —");
        metaRow.addView(metaRight, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(metaRow);

        locationButton = secondaryButton("Mi ubicación");
        locationButton.setOnClickListener(v -> centerLocation());
        extentButton = secondaryButton("Ver extensión completa");
        extentButton.setOnClickListener(v -> showFullExtent());
        validateButton = secondaryButton("Validar archivo");
        validateButton.setOnClickListener(v -> validateSelected());
        if (ResponsiveUi.isNarrow(this)) {
            LinearLayout toolRowA = horizontal();
            toolRowA.addView(locationButton, weight());
            toolRowA.addView(validateButton, weight());
            card.addView(toolRowA);
            LinearLayout toolRowB = horizontal();
            toolRowB.addView(extentButton, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));
            card.addView(toolRowB);
        } else {
            LinearLayout toolRow = horizontal();
            toolRow.addView(locationButton, weight());
            toolRow.addView(extentButton, weight());
            toolRow.addView(validateButton, weight());
            card.addView(toolRow);
        }

        statusBox = resultBox("No hay mapa offline cargado.");
        card.addView(statusBox);

        emptyHint = small("Consejo: importa varios paquetes MBTiles y toca uno para activarlo como mapa de trabajo offline.");
        card.addView(emptyHint);
        return card;
    }

    private View buildOpacityCard() {
        LinearLayout card = card();
        card.addView(sectionTitle("Capas y visualización"));
        LinearLayout row = vertical();
        opacityLabel = text("Opacidad 100%", 14, true);
        opacityLabel.setTextColor(textColor);
        row.addView(opacityLabel);
        opacitySeek = new SeekBar(this);
        opacitySeek.setMax(100);
        opacitySeek.setProgress(Math.round(currentOpacity * 100f));
        opacitySeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                currentOpacity = Math.max(0f, Math.min(1f, progress / 100f));
                opacityLabel.setText("Opacidad " + progress + "%");
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putFloat(KEY_OPACITY, currentOpacity).apply();
                applyOpacity();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        row.addView(opacitySeek);
        card.addView(row);
        card.addView(resultBox("Mostrar capas: 1 capa activa\nLa capa ráster offline se dibuja sobre el mapa local y puedes ajustar su opacidad para ver mejor el contenido."));
        return card;
    }

    private View buildMapOverlay() {
        LinearLayout overlay = vertical();
        overlay.setPadding(0, 0, dp(8), dp(8));
        overlay.addView(mapControlButton("◎", v -> centerLocation()));
        overlay.addView(mapControlButton("+", v -> { if (map != null) map.animateCamera(CameraUpdateFactory.zoomIn()); }));
        overlay.addView(mapControlButton("−", v -> { if (map != null) map.animateCamera(CameraUpdateFactory.zoomOut()); }));
        return overlay;
    }

    private Button mapControlButton(String label, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        ResponsiveUi.configureText(button, 18);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(withAlpha(Color.rgb(5, 34, 58), 232));
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), withAlpha(accent, 120));
        button.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(48), dp(48));
        lp.bottomMargin = dp(8);
        button.setLayoutParams(lp);
        button.setOnClickListener(listener);
        return button;
    }

    private View infoBanner(String iconText, String message) {
        LinearLayout row = horizontal();
        row.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        row.setPadding(dp(4), dp(2), dp(4), dp(4));

        TextView boxIcon = new TextView(this);
        boxIcon.setText(iconText);
        boxIcon.setTextColor(accent);
        ResponsiveUi.configureText(boxIcon, 22);
        boxIcon.setTypeface(Typeface.DEFAULT_BOLD);
        boxIcon.setGravity(Gravity.CENTER);
        GradientDrawable ibg = new GradientDrawable();
        ibg.setColor(withAlpha(accent, 42));
        ibg.setCornerRadius(dp(16));
        boxIcon.setBackground(ibg);
        row.addView(boxIcon, new LinearLayout.LayoutParams(dp(54), dp(54)));

        TextView info = small(message);
        info.setTextColor(textColor);
        info.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        info.setPadding(dp(10), 0, 0, 0);
        row.addView(info);
        return row;
    }

    private void chooseFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_IMPORT);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_IMPORT && resultCode == RESULT_OK && data != null && data.getData() != null) {
            importFile(data.getData());
        }
    }

    private void importFile(Uri uri) {
        statusBox.setText("Copiando y verificando paquete MBTiles...");
        new Thread(() -> {
            File imported = null;
            try {
                File dir = mapsDir();
                if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("No se pudo crear la carpeta de mapas.");
                String displayName = displayName(uri);
                if (!displayName.toLowerCase(Locale.US).endsWith(".mbtiles")) displayName = displayName + ".mbtiles";
                imported = uniqueFile(dir, displayName);
                try (InputStream in = getContentResolver().openInputStream(uri);
                     FileOutputStream out = new FileOutputStream(imported)) {
                    if (in == null) throw new IllegalStateException("No se pudo abrir el archivo seleccionado.");
                    byte[] buffer = new byte[1024 * 128];
                    int read;
                    while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
                    out.flush();
                }
                OfflineMapInfo info = inspect(imported);
                rememberActive(info.file);
                runOnUiThread(() -> {
                    refreshLibrary(true);
                    statusBox.setText("Mapa importado correctamente: " + info.name + "\nAtribución: " + info.attribution);
                });
            } catch (Exception e) {
                File failed = imported;
                if (failed != null && failed.isFile()) failed.delete();
                runOnUiThread(() -> statusBox.setText("No se pudo importar el archivo. Debe ser un MBTiles ráster válido: " + e.getMessage()));
            }
        }, "GeoTopo-MBTiles-Import").start();
    }

    private String displayName(Uri uri) {
        String name = null;
        Cursor c = getContentResolver().query(uri, null, null, null, null);
        if (c != null) {
            try {
                if (c.moveToFirst()) {
                    int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (i >= 0) name = c.getString(i);
                }
            } finally { c.close(); }
        }
        return name == null || name.trim().isEmpty() ? "mapa.mbtiles" : name;
    }

    private void refreshLibrary(boolean openActiveMap) {
        library.clear();
        File[] files = mapsDir().listFiles((dir, name) -> name.toLowerCase(Locale.US).endsWith(".mbtiles"));
        if (files != null) {
            Arrays.sort(files, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
            for (File file : files) {
                try { library.add(inspect(file)); }
                catch (Exception ignored) {}
            }
        }
        libraryCount.setText(library.size() + (library.size() == 1 ? " mapa" : " mapas"));
        resolveSelected();
        rebuildLibraryList();
        updateSelectedPanel();
        if (mapEmptyOverlay != null) mapEmptyOverlay.setVisibility(selectedMap == null ? View.VISIBLE : View.GONE);
        if (openActiveMap) {
            if (selectedMap != null) openMap(selectedMap.file, selectedMap);
            else { server.stop(); setEmptyStyle(); }
        }
    }

    private void resolveSelected() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        String rememberedPath = sp.getString(KEY_PATH, "");
        selectedMap = null;
        for (OfflineMapInfo info : library) {
            if (info.file.getAbsolutePath().equals(rememberedPath)) {
                selectedMap = info;
                break;
            }
        }
        if (selectedMap == null && !library.isEmpty()) {
            selectedMap = library.get(0);
            rememberActive(selectedMap.file);
        }
    }

    private void rebuildLibraryList() {
        libraryList.removeAllViews();
        if (library.isEmpty()) {
            libraryList.addView(resultBox("No hay mapas offline cargados. Importa un archivo MBTiles para comenzar."));
            return;
        }
        for (OfflineMapInfo info : library) libraryList.addView(createLibraryRow(info));
    }

    private View createLibraryRow(OfflineMapInfo info) {
        LinearLayout row = vertical();
        row.setPadding(dp(10), dp(10), dp(10), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(inputColor);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), selectedMap != null && selectedMap.file.equals(info.file) ? accent : withAlpha(borderColor, 120));
        row.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(8));
        row.setLayoutParams(lp);

        LinearLayout top = horizontal();
        top.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView thumb = text("MAPA", 12, true);
        thumb.setTextColor(Color.WHITE);
        thumb.setGravity(Gravity.CENTER);
        GradientDrawable tbg = new GradientDrawable();
        tbg.setColor(withAlpha(accent, 55));
        tbg.setCornerRadius(dp(12));
        thumb.setBackground(tbg);
        top.addView(thumb, new LinearLayout.LayoutParams(dp(68), dp(56)));

        LinearLayout textBox = vertical();
        textBox.setPadding(dp(10), 0, dp(10), 0);
        TextView name = text(info.name, 16, true);
        textBox.addView(name);
        TextView meta = text(humanSize(info.sizeBytes) + "  ·  Zoom " + info.minZoom + " – " + info.maxZoom + "\n" + info.modifiedText(), 12, false);
        meta.setTextColor(subTextColor);
        textBox.addView(meta);
        top.addView(textBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout right = vertical();
        right.setGravity(Gravity.END);
        TextView badge = pillText(selectedMap != null && selectedMap.file.equals(info.file) ? "ACTIVO" : "ABRIR", selectedMap != null && selectedMap.file.equals(info.file) ? accent : textColor, selectedMap != null && selectedMap.file.equals(info.file) ? withAlpha(accent, 40) : withAlpha(subTextColor, 35), false);
        right.addView(badge);
        TextView dots = text("⋮", 20, true);
        dots.setTextColor(subTextColor);
        dots.setPadding(0, dp(8), dp(3), 0);
        right.addView(dots);
        top.addView(right);
        row.addView(top);

        row.setOnClickListener(v -> {
            selectedMap = info;
            rememberActive(info.file);
            updateSelectedPanel();
            rebuildLibraryList();
            openMap(info.file, info);
        });
        return row;
    }

    private void updateSelectedPanel() {
        boolean hasMap = selectedMap != null;
        selectedTitle.setText(hasMap ? selectedMap.name : "Ningún mapa seleccionado");
        selectedBadge.setText(hasMap ? "ACTIVO" : "SIN MAPA");
        stylePill(selectedBadge, hasMap ? accent : Color.rgb(140, 148, 161), hasMap ? withAlpha(accent, 40) : withAlpha(Color.rgb(140, 148, 161), 40), false);
        renameButton.setEnabled(hasMap);
        deleteButton.setEnabled(hasMap);
        locationButton.setEnabled(hasMap);
        extentButton.setEnabled(hasMap);
        validateButton.setEnabled(hasMap);
        emptyHint.setVisibility(hasMap ? View.GONE : View.VISIBLE);
        if (!hasMap) {
            metaLeft.setText("Extensión: —\nZoom mínimo: —\nZoom máximo: —");
            metaRight.setText("Formato: —\nTamaño: —\nAtribución: —");
            statusBox.setText("No hay mapa offline cargado.");
            return;
        }
        metaLeft.setText("Extensión: " + selectedMap.boundsText() + "\nZoom mínimo: " + selectedMap.minZoom + "\nZoom máximo: " + selectedMap.maxZoom);
        metaRight.setText("Formato: " + selectedMap.format.toUpperCase(Locale.US) + "\nTamaño: " + humanSize(selectedMap.sizeBytes) + "\nAtribución: " + selectedMap.attribution);
        statusBox.setText("Mapa cargado: " + selectedMap.name + "\nNombre interno: " + selectedMap.internalName + " · formato " + selectedMap.format.toUpperCase(Locale.US) + " · zoom " + selectedMap.minZoom + "–" + selectedMap.maxZoom);
    }

    private OfflineMapInfo inspect(File file) {
        SQLiteDatabase db = SQLiteDatabase.openDatabase(file.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
        try {
            OfflineMapInfo info = new OfflineMapInfo();
            info.file = file;
            info.name = file.getName();
            info.sizeBytes = file.length();
            info.lastModified = file.lastModified();
            Cursor meta = db.rawQuery("SELECT name, value FROM metadata", null);
            while (meta.moveToNext()) {
                String key = meta.getString(0) == null ? "" : meta.getString(0).toLowerCase(Locale.US);
                String value = meta.getString(1) == null ? "" : meta.getString(1);
                if ("name".equals(key)) info.internalName = value;
                else if ("attribution".equals(key)) info.attribution = value;
                else if ("bounds".equals(key)) info.bounds = value;
                else if ("center".equals(key)) info.center = value;
                else if ("format".equals(key)) info.format = normalizeFormat(value);
            }
            meta.close();

            Cursor zoom = db.rawQuery("SELECT MIN(zoom_level), MAX(zoom_level) FROM tiles", null);
            if (!zoom.moveToFirst() || zoom.isNull(0) || zoom.isNull(1)) throw new IllegalArgumentException("El paquete MBTiles no contiene teselas.");
            info.minZoom = zoom.getInt(0);
            info.maxZoom = zoom.getInt(1);
            zoom.close();

            Cursor tile = db.rawQuery("SELECT tile_data FROM tiles LIMIT 1", null);
            if (!tile.moveToFirst()) throw new IllegalArgumentException("El paquete MBTiles no contiene teselas.");
            byte[] sample = tile.getBlob(0);
            tile.close();
            if (info.format == null || info.format.isEmpty()) info.format = detectFormat(sample);
            if (info.format == null || info.format.isEmpty()) info.format = "png";
            if (info.internalName == null || info.internalName.trim().isEmpty()) info.internalName = info.name;
            if (info.attribution == null || info.attribution.trim().isEmpty()) info.attribution = "Paquete MBTiles importado por el usuario";
            return info;
        } finally {
            db.close();
        }
    }

    private String normalizeFormat(String value) {
        if (value == null) return "";
        String f = value.trim().toLowerCase(Locale.US);
        return "jpeg".equals(f) ? "jpg" : f;
    }

    private String detectFormat(byte[] data) {
        if (data == null || data.length < 4) return "";
        if ((data[0] & 0xff) == 0x89 && data[1] == 0x50 && data[2] == 0x4e && data[3] == 0x47) return "png";
        if ((data[0] & 0xff) == 0xff && (data[1] & 0xff) == 0xd8) return "jpg";
        if (data.length >= 12 && data[0] == 'R' && data[1] == 'I' && data[2] == 'F' && data[3] == 'F' && data[8] == 'W' && data[9] == 'E' && data[10] == 'B' && data[11] == 'P') return "webp";
        return "";
    }

    private void openMap(File file, OfflineMapInfo info) {
        if (map == null) return;
        if (mapEmptyOverlay != null) mapEmptyOverlay.setVisibility(View.GONE);
        try {
            server.start(file);
            String url = "http://127.0.0.1:" + server.getPort() + "/tiles/{z}/{x}/{y}." + server.getFormat();
            String style = "{\"version\":8,\"sources\":{\"offline\":{\"type\":\"raster\",\"tiles\":[\"" + url
                    + "\"],\"tileSize\":256,\"minzoom\":" + server.getMinZoom() + ",\"maxzoom\":" + server.getMaxZoom()
                    + "}},\"layers\":[{\"id\":\"background\",\"type\":\"background\",\"paint\":{\"background-color\":\"#dfe7ed\"}},{\"id\":\"offline\",\"type\":\"raster\",\"source\":\"offline\",\"paint\":{\"raster-fade-duration\":0,\"raster-opacity\":" + currentOpacity + "}}]}";
            map.setStyle(new Style.Builder().fromJson(style), s -> {
                centerToInfo(info, false);
                applyOpacity();
            });
        } catch (Exception e) {
            statusBox.setText("El archivo no se pudo abrir: " + e.getMessage());
            setEmptyStyle();
        }
    }

    private void applyOpacity() {
        if (map == null || map.getStyle() == null) return;
        Layer layer = map.getStyle().getLayer("offline");
        if (layer != null) layer.setProperties(PropertyFactory.rasterOpacity(currentOpacity));
    }

    private void showFullExtent() {
        if (selectedMap == null || map == null) return;
        centerToInfo(selectedMap, true);
    }

    private void centerToInfo(OfflineMapInfo info, boolean preferBounds) {
        if (map == null || info == null) return;
        try {
            if (!preferBounds && info.center != null && !info.center.trim().isEmpty()) {
                String[] c = info.center.split(",");
                double lon = Double.parseDouble(c[0]);
                double lat = Double.parseDouble(c[1]);
                double zoom = c.length > 2 ? Double.parseDouble(c[2]) : Math.max(info.minZoom, Math.min(info.maxZoom, 13));
                map.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lon), zoom));
                return;
            }
            if (info.bounds != null && !info.bounds.trim().isEmpty()) {
                String[] b = info.bounds.split(",");
                double west = Double.parseDouble(b[0]);
                double south = Double.parseDouble(b[1]);
                double east = Double.parseDouble(b[2]);
                double north = Double.parseDouble(b[3]);
                LatLngBounds bounds = new LatLngBounds.Builder()
                        .include(new LatLng(south, west))
                        .include(new LatLng(north, east))
                        .build();
                map.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, dp(20)));
                return;
            }
            double zoom = Math.max(info.minZoom, Math.min(info.maxZoom, 13));
            map.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(-13.635, -72.9), zoom));
        } catch (Exception ignored) {}
    }

    private void setEmptyStyle() {
        if (map == null) return;
        if (mapEmptyOverlay != null) mapEmptyOverlay.setVisibility(View.VISIBLE);
        String style = "{\"version\":8,\"sources\":{},\"layers\":[{\"id\":\"background\",\"type\":\"background\",\"paint\":{\"background-color\":\"#051827\"}}]}";
        map.setStyle(new Style.Builder().fromJson(style));
    }

    private void centerLocation() {
        if (selectedMap == null) { showToast("Primero importa o activa un mapa offline."); return; }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        try {
            Location gps = locationManager == null ? null : locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location net = locationManager == null ? null : locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            Location loc = gps == null ? net : (net == null || gps.getTime() >= net.getTime() ? gps : net);
            if (loc == null) { showToast("Todavía no hay una posición reciente."); return; }
            if (locationMarker != null && map != null) map.removeMarker(locationMarker);
            if (map == null) return;
            locationMarker = map.addMarker(new MarkerOptions().position(new LatLng(loc.getLatitude(), loc.getLongitude())).title("Mi ubicación aproximada"));
            double zoom = Math.max(server.getMinZoom() > 0 ? server.getMinZoom() : selectedMap.minZoom, Math.min(server.getMaxZoom() > 0 ? server.getMaxZoom() : selectedMap.maxZoom, 15));
            map.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(loc.getLatitude(), loc.getLongitude()), zoom));
        } catch (SecurityException e) { showToast("No se pudo leer la ubicación."); }
    }

    private void validateSelected() {
        if (selectedMap == null) return;
        new Thread(() -> {
            try {
                OfflineMapInfo checked = inspect(selectedMap.file);
                runOnUiThread(() -> statusBox.setText("Archivo válido\nFormato: MBTiles ráster " + checked.format.toUpperCase(Locale.US)
                        + "\nZoom: " + checked.minZoom + "–" + checked.maxZoom + "\nAtribución disponible: " + checked.attribution));
            } catch (Exception e) {
                runOnUiThread(() -> statusBox.setText("Validación fallida: " + e.getMessage()));
            }
        }, "GeoTopo-MBTiles-Validate").start();
    }

    private void renameSelected() {
        if (selectedMap == null) return;
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setSingleLine(true);
        input.setText(selectedMap.name.replaceFirst("\\.mbtiles$", ""));
        input.setSelection(input.getText().length());
        new AlertDialog.Builder(this)
                .setTitle("Renombrar mapa")
                .setView(input)
                .setPositiveButton("Guardar", (d, w) -> {
                    String value = input.getText().toString().trim();
                    if (value.isEmpty()) { showToast("Escribe un nombre válido."); return; }
                    if (!value.toLowerCase(Locale.US).endsWith(".mbtiles")) value += ".mbtiles";
                    File target = uniqueFile(selectedMap.file.getParentFile(), value, selectedMap.file);
                    server.stop();
                    if (selectedMap.file.renameTo(target)) {
                        rememberActive(target);
                        refreshLibrary(true);
                    } else {
                        showToast("No se pudo renombrar el archivo.");
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void deleteSelected() {
        if (selectedMap == null) return;
        new AlertDialog.Builder(this)
                .setTitle("Eliminar mapa")
                .setMessage("Se eliminará el archivo offline: " + selectedMap.name)
                .setPositiveButton("Eliminar", (d, w) -> {
                    File file = selectedMap.file;
                    server.stop();
                    if (file.isFile()) file.delete();
                    SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
                    if (file.getAbsolutePath().equals(sp.getString(KEY_PATH, ""))) {
                        sp.edit().remove(KEY_PATH).remove(KEY_NAME).apply();
                    }
                    refreshLibrary(true);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void rememberActive(File file) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(KEY_PATH, file.getAbsolutePath())
                .putString(KEY_NAME, file.getName())
                .apply();
    }

    private File mapsDir() {
        return new File(getFilesDir(), "offline_maps");
    }

    private File uniqueFile(File dir, String name) {
        return uniqueFile(dir, name, null);
    }

    private File uniqueFile(File dir, String name, File keepSame) {
        String base = name;
        String ext = "";
        int dot = name.lastIndexOf('.');
        if (dot > 0) { base = name.substring(0, dot); ext = name.substring(dot); }
        File file = new File(dir, name);
        int index = 2;
        while (file.exists() && (keepSame == null || !file.equals(keepSame))) {
            file = new File(dir, base + "_" + index + ext);
            index++;
        }
        return file;
    }

    private String humanSize(long bytes) {
        if (bytes < 1024L) return bytes + " B";
        double kb = bytes / 1024.0;
        if (kb < 1024.0) return String.format(Locale.US, "%.0f KB", kb);
        double mb = kb / 1024.0;
        if (mb < 1024.0) return String.format(Locale.US, "%.1f MB", mb);
        return String.format(Locale.US, "%.2f GB", mb / 1024.0);
    }

    private TextView pillText(String label, int stroke, int fill, boolean danger) {
        TextView tv = text(label, 12, true);
        stylePill(tv, stroke, fill, danger);
        return tv;
    }

    private void stylePill(TextView tv, int stroke, int fill, boolean danger) {
        tv.setTextColor(danger ? Color.rgb(255, 108, 108) : stroke);
        tv.setPadding(dp(10), dp(5), dp(10), dp(5));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(fill);
        bg.setCornerRadius(dp(50));
        bg.setStroke(dp(1), danger ? Color.rgb(255, 108, 108) : stroke);
        tv.setBackground(bg);
    }

    private Button inlineActionButton(String label, int color) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(label);
        button.setTextColor(color);
        ResponsiveUi.configureCompactText(button, 13, 9, 2);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(inputColor);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), withAlpha(color, 160));
        button.setBackground(bg);
        return button;
    }

    private TextView resultBoxCompact(String value) {
        TextView tv = resultBox(value);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), dp(2), dp(3), dp(2));
        tv.setLayoutParams(lp);
        return tv;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) centerLocation();
        else if (requestCode == REQ_LOCATION) showToast("Sin permiso no se puede centrar en tu ubicación.");
    }

    @Override protected void onStart() { super.onStart(); mapView.onStart(); }
    @Override protected void onResume() { super.onResume(); mapView.onResume(); }
    @Override protected void onPause() { mapView.onPause(); super.onPause(); }
    @Override protected void onStop() { mapView.onStop(); super.onStop(); }
    @Override public void onLowMemory() { super.onLowMemory(); mapView.onLowMemory(); }
    @Override protected void onDestroy() { server.stop(); mapView.onDestroy(); super.onDestroy(); }
    @Override protected void onSaveInstanceState(Bundle outState) { super.onSaveInstanceState(outState); mapView.onSaveInstanceState(outState); }

    private static final class OfflineMapInfo {
        File file;
        String name;
        String internalName;
        String attribution;
        String bounds;
        String center;
        String format;
        long sizeBytes;
        long lastModified;
        int minZoom;
        int maxZoom;

        String modifiedText() {
            java.text.SimpleDateFormat fmt = new java.text.SimpleDateFormat("d MMM. yyyy HH:mm", Locale.getDefault());
            return fmt.format(new java.util.Date(lastModified));
        }

        String boundsText() {
            if (bounds == null || bounds.trim().isEmpty()) return "—";
            String[] p = bounds.split(",");
            if (p.length < 4) return bounds;
            return p[0] + ", " + p[1] + " | " + p[2] + ", " + p[3];
        }
    }
}
