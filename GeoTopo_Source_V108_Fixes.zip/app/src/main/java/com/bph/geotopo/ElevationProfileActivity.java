package com.bph.geotopo;

import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;
import org.maplibre.android.geometry.LatLng;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Profile generated directly from a line measured on the map. */
public class ElevationProfileActivity extends BaseToolActivity {
    public static final String EXTRA_POINTS_JSON = "profile_points_json";
    private static final int REQ_EXPORT_CSV = 9651;
    private static final int REQ_EXPORT_DXF = 9652;

    private final List<LatLng> path = new ArrayList<>();
    private final List<TerrainElevation.Sample> samples = new ArrayList<>();
    private ProfileChartView chart;
    private TextView status;
    private TextView minValue;
    private TextView maxValue;
    private TextView gainValue;
    private TextView lossValue;
    private TextView netValue;
    private TextView averageSlopeValue;
    private TextView maxSlopeValue;
    private TextView lengthValue;
    private ProgressBar progress;
    private Button recalcButton;
    private Button csvButton;
    private Button dxfButton;
    private String csvContent;
    private String dxfContent;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        readPath();

        LinearLayout root = page("Perfil de elevación", "Perfil automático desde la línea medida en el mapa");
        LinearLayout content = vertical();
        content.addView(warning("Alturas aproximadas de un modelo digital de terreno público (~30 m). Úsalo para análisis y planificación; no sustituye una nivelación, RTK ni estación total."));
        content.addView(buildChartCard());
        content.addView(buildMetricsCard());
        content.addView(buildActionsCard());
        root.addView(scrollWith(content), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        if (path.size() >= 2) loadProfile();
        else setStatus("No se recibió una línea válida. Vuelve al mapa y mide al menos dos puntos.", false);
    }

    private void readPath() {
        try {
            String json = getIntent() == null ? null : getIntent().getStringExtra(EXTRA_POINTS_JSON);
            if (json == null || json.trim().isEmpty()) return;
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.optJSONObject(i);
                if (obj == null) continue;
                double lat = obj.optDouble("lat", Double.NaN);
                double lon = obj.optDouble("lon", Double.NaN);
                if (Double.isFinite(lat) && Double.isFinite(lon)
                        && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180) {
                    path.add(new LatLng(lat, lon));
                }
            }
        } catch (Exception ignored) { }
    }

    private LinearLayout buildChartCard() {
        LinearLayout card = card();
        card.addView(sectionTitle("Perfil del terreno"));
        TextView info = small("Se muestrea la elevación a lo largo de toda la línea. Toca o desliza sobre la gráfica para consultar distancia, elevación y pendiente.");
        card.addView(info);

        chart = new ProfileChartView();
        GradientDrawable chartBg = new GradientDrawable();
        chartBg.setColor(themeMode == 0 ? Color.rgb(250, 252, 255) : Color.rgb(7, 25, 40));
        chartBg.setCornerRadius(dp(12));
        chartBg.setStroke(dp(1), withAlpha(borderColor, 150));
        chart.setBackground(chartBg);
        LinearLayout.LayoutParams chartLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(280));
        chartLp.setMargins(0, dp(3), 0, dp(8));
        card.addView(chart, chartLp);

        LinearLayout loading = horizontal();
        loading.setGravity(Gravity.CENTER_VERTICAL);
        progress = new ProgressBar(this);
        progress.setIndeterminate(true);
        loading.addView(progress, new LinearLayout.LayoutParams(dp(28), dp(28)));
        status = text("Preparando perfil…", 13, true);
        status.setTextColor(subTextColor);
        status.setPadding(dp(9), 0, 0, 0);
        loading.addView(status, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(loading);
        return card;
    }

    private LinearLayout buildMetricsCard() {
        LinearLayout card = card();
        card.addView(sectionTitle("Resumen"));

        LinearLayout row1 = horizontal();
        Metric min = metric("Elevación mínima", "—", Color.rgb(0, 188, 212));
        Metric max = metric("Elevación máxima", "—", Color.rgb(255, 171, 0));
        minValue = min.value;
        maxValue = max.value;
        row1.addView(min.root, weight());
        row1.addView(max.root, weight());
        card.addView(row1);

        LinearLayout row2 = horizontal();
        Metric gain = metric("Ascenso acumulado", "—", Color.rgb(76, 175, 80));
        Metric loss = metric("Descenso acumulado", "—", Color.rgb(239, 83, 80));
        gainValue = gain.value;
        lossValue = loss.value;
        row2.addView(gain.root, weight());
        row2.addView(loss.root, weight());
        card.addView(row2);

        LinearLayout row3 = horizontal();
        Metric net = metric("Desnivel neto", "—", Color.rgb(0, 188, 212));
        Metric averageSlope = metric("Pendiente media", "—", Color.rgb(126, 87, 194));
        netValue = net.value;
        averageSlopeValue = averageSlope.value;
        row3.addView(net.root, weight());
        row3.addView(averageSlope.root, weight());
        card.addView(row3);

        LinearLayout row4 = horizontal();
        Metric maxSlope = metric("Pendiente máxima", "—", Color.rgb(255, 145, 0));
        Metric length = metric("Longitud del perfil", "—", accent);
        maxSlopeValue = maxSlope.value;
        lengthValue = length.value;
        row4.addView(maxSlope.root, weight());
        row4.addView(length.root, weight());
        card.addView(row4);
        return card;
    }

    private LinearLayout buildActionsCard() {
        LinearLayout card = card();
        card.addView(sectionTitle("Acciones"));

        recalcButton = secondaryButton("Recalcular elevación");
        recalcButton.setOnClickListener(v -> loadProfile());
        card.addView(recalcButton);

        LinearLayout row = horizontal();
        csvButton = secondaryButton("Exportar CSV");
        csvButton.setEnabled(false);
        csvButton.setOnClickListener(v -> exportCsv());
        dxfButton = primaryButton("Exportar DXF");
        dxfButton.setEnabled(false);
        dxfButton.setOnClickListener(v -> exportDxf());
        row.addView(csvButton, weight());
        row.addView(dxfButton, weight());
        card.addView(row);

        TextView note = small("DXF exporta el perfil como una polilínea 2D: X = distancia acumulada (m), Y = elevación (m). Es compatible con CAD para continuar el trabajo.");
        note.setPadding(0, dp(6), 0, 0);
        card.addView(note);
        return card;
    }

    private Metric metric(String titleText, String valueText, int tint) {
        LinearLayout root = vertical();
        root.setPadding(dp(10), dp(10), dp(10), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeMode == 0 ? Color.WHITE : Color.rgb(10, 29, 45));
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), withAlpha(tint, 170));
        root.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), dp(3), dp(3), dp(6));
        root.setLayoutParams(lp);

        TextView title = text(titleText, 12, true);
        title.setTextColor(withAlpha(tint, 235));
        TextView value = text(valueText, 18, true);
        value.setTextColor(textColor);
        root.addView(title);
        root.addView(value);
        return new Metric(root, value);
    }

    private void loadProfile() {
        if (path.size() < 2) return;
        csvContent = null;
        dxfContent = null;
        csvButton.setEnabled(false);
        dxfButton.setEnabled(false);
        recalcButton.setEnabled(false);
        progress.setVisibility(View.VISIBLE);
        setStatus("Leyendo el terreno a lo largo de la línea…", true);
        samples.clear();
        chart.setSamples(samples);

        TerrainElevation.sampleProfile(path, result -> {
            if (isFinishing()) return;
            recalcButton.setEnabled(true);
            progress.setVisibility(View.GONE);
            if (!result.ok) {
                samples.clear();
                if (result.samples != null) samples.addAll(result.samples);
                chart.setSamples(samples);
                setStatus(result.message, false);
                return;
            }
            samples.clear();
            samples.addAll(result.samples);
            chart.setSamples(samples);
            calculateMetrics();
            csvContent = buildCsv();
            dxfContent = buildDxf();
            csvButton.setEnabled(true);
            dxfButton.setEnabled(true);
            setStatus("Perfil calculado · " + samples.size() + " muestras de terreno.", true);
        });
    }

    private void calculateMetrics() {
        if (samples.isEmpty()) return;
        double min = Double.POSITIVE_INFINITY;
        double max = Double.NEGATIVE_INFINITY;
        double gain = 0.0;
        double loss = 0.0;
        Double previous = null;
        TerrainElevation.Sample firstValid = null;
        TerrainElevation.Sample lastValid = null;
        for (TerrainElevation.Sample sample : samples) {
            if (!Double.isFinite(sample.elevationMeters)) continue;
            if (firstValid == null) firstValid = sample;
            lastValid = sample;
            min = Math.min(min, sample.elevationMeters);
            max = Math.max(max, sample.elevationMeters);
            if (previous != null) {
                double delta = sample.elevationMeters - previous;
                if (delta > 0) gain += delta;
                else loss += -delta;
            }
            previous = sample.elevationMeters;
        }
        double length = samples.get(samples.size() - 1).distanceMeters;
        double net = firstValid != null && lastValid != null
                ? lastValid.elevationMeters - firstValid.elevationMeters : Double.NaN;
        double averageSlope = Double.isFinite(net) && length > 0.01 ? net / length * 100.0 : Double.NaN;
        double maxSlope = calculateMaximumSlopePercent();

        minValue.setText(Double.isFinite(min) ? f1(min) + " m" : "—");
        maxValue.setText(Double.isFinite(max) ? f1(max) + " m" : "—");
        gainValue.setText(f1(gain) + " m");
        lossValue.setText(f1(loss) + " m");
        netValue.setText(Double.isFinite(net) ? signed(net, " m") : "—");
        averageSlopeValue.setText(Double.isFinite(averageSlope) ? signed(averageSlope, " %") : "—");
        maxSlopeValue.setText(Double.isFinite(maxSlope) ? f1(maxSlope) + " %" : "—");
        lengthValue.setText(length >= 1000 ? String.format(Locale.US, "%.3f km", length / 1000.0)
                : f1(length) + " m");
    }

    private double calculateMaximumSlopePercent() {
        if (samples.size() < 2) return Double.NaN;
        double best = Double.NaN;
        final double targetWindowMeters = 25.0;
        for (int i = 0; i < samples.size() - 1; i++) {
            TerrainElevation.Sample a = samples.get(i);
            if (!Double.isFinite(a.elevationMeters)) continue;
            int j = i + 1;
            while (j < samples.size() - 1
                    && samples.get(j).distanceMeters - a.distanceMeters < targetWindowMeters) {
                j++;
            }
            TerrainElevation.Sample b = samples.get(j);
            if (!Double.isFinite(b.elevationMeters)) continue;
            double run = b.distanceMeters - a.distanceMeters;
            if (run <= 0.01) continue;
            double slope = Math.abs((b.elevationMeters - a.elevationMeters) / run * 100.0);
            if (!Double.isFinite(best) || slope > best) best = slope;
        }
        return best;
    }

    private String signed(double value, String suffix) {
        return String.format(Locale.US, "%+.1f%s", value, suffix);
    }

    private double localSlopePercent(int index) {
        if (index < 0 || index >= samples.size()) return Double.NaN;
        TerrainElevation.Sample center = samples.get(index);
        if (!Double.isFinite(center.elevationMeters)) return Double.NaN;
        final double halfWindow = 15.0;
        int left = index;
        while (left > 0 && center.distanceMeters - samples.get(left).distanceMeters < halfWindow) left--;
        while (left < index && !Double.isFinite(samples.get(left).elevationMeters)) left++;
        int right = index;
        while (right < samples.size() - 1 && samples.get(right).distanceMeters - center.distanceMeters < halfWindow) right++;
        while (right > index && !Double.isFinite(samples.get(right).elevationMeters)) right--;
        TerrainElevation.Sample a = samples.get(left);
        TerrainElevation.Sample b = samples.get(right);
        if (!Double.isFinite(a.elevationMeters) || !Double.isFinite(b.elevationMeters)) return Double.NaN;
        double run = b.distanceMeters - a.distanceMeters;
        if (run <= 0.01) return Double.NaN;
        return (b.elevationMeters - a.elevationMeters) / run * 100.0;
    }

    private void setStatus(String value, boolean ok) {
        if (status == null) return;
        status.setText(value);
        status.setTextColor(ok ? (themeMode == 0 ? Color.rgb(30, 120, 70) : Color.rgb(126, 226, 162))
                : (themeMode == 0 ? Color.rgb(150, 74, 20) : Color.rgb(255, 196, 120)));
    }

    private String buildCsv() {
        StringBuilder out = new StringBuilder();
        out.append("distancia_m,elevacion_m,latitud,longitud\n");
        for (TerrainElevation.Sample s : samples) {
            out.append(String.format(Locale.US, "%.3f,%.3f,%.8f,%.8f\n",
                    s.distanceMeters, s.elevationMeters, s.latitude, s.longitude));
        }
        return out.toString();
    }

    private String buildDxf() {
        StringBuilder out = new StringBuilder();
        out.append("0\nSECTION\n2\nHEADER\n9\n$INSUNITS\n70\n6\n0\nENDSEC\n");
        out.append("0\nSECTION\n2\nENTITIES\n");
        out.append("0\nLWPOLYLINE\n8\nGEOTOPO_PROFILE\n90\n").append(samples.size()).append("\n70\n0\n");
        for (TerrainElevation.Sample s : samples) {
            out.append("10\n").append(String.format(Locale.US, "%.3f", s.distanceMeters)).append("\n");
            out.append("20\n").append(String.format(Locale.US, "%.3f", s.elevationMeters)).append("\n");
        }
        out.append("0\nENDSEC\n0\nEOF\n");
        return out.toString();
    }

    private void exportCsv() {
        if (csvContent == null) return;
        createDocument(REQ_EXPORT_CSV, "text/csv", "GeoTopo_Perfil_Elevacion_", ".csv");
    }

    private void exportDxf() {
        if (dxfContent == null) return;
        createDocument(REQ_EXPORT_DXF, "application/dxf", "GeoTopo_Perfil_Elevacion_", ".dxf");
    }

    private void createDocument(int requestCode, String mime, String prefix, String extension) {
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date());
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime);
        intent.putExtra(Intent.EXTRA_TITLE, prefix + stamp + extension);
        startActivityForResult(intent, requestCode);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        String content = requestCode == REQ_EXPORT_CSV ? csvContent
                : (requestCode == REQ_EXPORT_DXF ? dxfContent : null);
        if (content == null) return;
        try {
            ContentResolver resolver = getContentResolver();
            Uri uri = data.getData();
            OutputStream stream = resolver.openOutputStream(uri);
            if (stream == null) throw new IllegalStateException();
            stream.write(content.getBytes(StandardCharsets.UTF_8));
            stream.close();
            showToast("Archivo exportado.");
        } catch (Exception e) {
            showToast("No se pudo exportar el archivo.");
        }
    }

    private final class ProfileChartView extends View {
        private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint axis = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint selection = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tooltipBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tooltipText = new Paint(Paint.ANTI_ALIAS_FLAG);
        private List<TerrainElevation.Sample> data = new ArrayList<>();
        private int selectedIndex = -1;

        ProfileChartView() {
            super(ElevationProfileActivity.this);
            setClickable(true);
            grid.setColor(withAlpha(borderColor, 65));
            grid.setStrokeWidth(dp(1));
            axis.setColor(withAlpha(textColor, 170));
            axis.setStrokeWidth(dp(1.2f));
            line.setColor(Color.rgb(79, 207, 111));
            line.setStrokeWidth(dp(2.3f));
            line.setStyle(Paint.Style.STROKE);
            fill.setColor(Color.argb(themeMode == 0 ? 45 : 55, 79, 207, 111));
            fill.setStyle(Paint.Style.FILL);
            label.setColor(subTextColor);
            label.setTextSize(dp(6.4f));
            selection.setColor(accent);
            selection.setStrokeWidth(dp(1.2f));
            tooltipBg.setColor(themeMode == 0 ? Color.argb(245, 255, 255, 255) : Color.argb(245, 8, 27, 43));
            tooltipText.setColor(textColor);
            tooltipText.setTextSize(dp(6.4f));
            tooltipText.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        }

        void setSamples(List<TerrainElevation.Sample> values) {
            data = values == null ? new ArrayList<>() : new ArrayList<>(values);
            selectedIndex = -1;
            invalidate();
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            if (data.size() < 2) return super.onTouchEvent(event);
            int action = event.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE) {
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                selectedIndex = nearestSampleIndex(event.getX());
                invalidate();
                return true;
            }
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                if (action == MotionEvent.ACTION_UP) performClick();
                return true;
            }
            return true;
        }

        @Override public boolean performClick() {
            super.performClick();
            return true;
        }

        private int nearestSampleIndex(float touchX) {
            if (data.isEmpty()) return -1;
            float left = dp(52);
            float right = getWidth() - dp(14);
            double maxX = Math.max(1.0, data.get(data.size() - 1).distanceMeters);
            double ratio = Math.max(0.0, Math.min(1.0, (touchX - left) / Math.max(1f, right - left)));
            double target = maxX * ratio;
            int bestIndex = -1;
            double bestDistance = Double.POSITIVE_INFINITY;
            for (int i = 0; i < data.size(); i++) {
                TerrainElevation.Sample s = data.get(i);
                if (!Double.isFinite(s.elevationMeters)) continue;
                double delta = Math.abs(s.distanceMeters - target);
                if (delta < bestDistance) {
                    bestDistance = delta;
                    bestIndex = i;
                }
            }
            return bestIndex;
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float left = dp(52);
            float right = getWidth() - dp(14);
            float top = dp(18);
            float bottom = getHeight() - dp(40);

            for (int i = 0; i <= 5; i++) {
                float y = top + (bottom - top) * i / 5f;
                canvas.drawLine(left, y, right, y, grid);
            }
            for (int i = 0; i <= 6; i++) {
                float x = left + (right - left) * i / 6f;
                canvas.drawLine(x, top, x, bottom, grid);
            }
            canvas.drawLine(left, bottom, right, bottom, axis);
            canvas.drawLine(left, top, left, bottom, axis);

            List<TerrainElevation.Sample> valid = new ArrayList<>();
            for (TerrainElevation.Sample s : data) if (Double.isFinite(s.elevationMeters)) valid.add(s);
            if (valid.size() < 2) {
                label.setTextAlign(Paint.Align.LEFT);
                canvas.drawText("El perfil aparecerá al terminar el cálculo.", left + dp(8), top + dp(26), label);
                return;
            }

            double maxX = Math.max(1.0, valid.get(valid.size() - 1).distanceMeters);
            double minY = Double.POSITIVE_INFINITY;
            double maxY = Double.NEGATIVE_INFINITY;
            for (TerrainElevation.Sample s : valid) {
                minY = Math.min(minY, s.elevationMeters);
                maxY = Math.max(maxY, s.elevationMeters);
            }
            double spanY = Math.max(2.0, maxY - minY);
            minY -= spanY * 0.12;
            maxY += spanY * 0.12;
            spanY = maxY - minY;

            Path profile = new Path();
            Path area = new Path();
            boolean started = false;
            float firstX = left;
            float lastX = left;
            for (TerrainElevation.Sample s : valid) {
                float x = left + (float) (s.distanceMeters / maxX) * (right - left);
                float y = bottom - (float) ((s.elevationMeters - minY) / spanY) * (bottom - top);
                if (!started) {
                    profile.moveTo(x, y);
                    area.moveTo(x, bottom);
                    area.lineTo(x, y);
                    firstX = x;
                    started = true;
                } else {
                    profile.lineTo(x, y);
                    area.lineTo(x, y);
                }
                lastX = x;
            }
            area.lineTo(lastX, bottom);
            area.lineTo(firstX, bottom);
            area.close();
            canvas.drawPath(area, fill);
            canvas.drawPath(profile, line);

            label.setColor(subTextColor);
            label.setTextAlign(Paint.Align.RIGHT);
            for (int i = 0; i <= 4; i++) {
                double value = maxY - spanY * i / 4.0;
                float y = top + (bottom - top) * i / 4f;
                canvas.drawText(String.format(Locale.US, "%.0f", value), left - dp(6), y + dp(3), label);
            }
            label.setTextAlign(Paint.Align.CENTER);
            for (int i = 0; i <= 4; i++) {
                double value = maxX * i / 4.0;
                float x = left + (right - left) * i / 4f;
                String txt = maxX >= 1000 ? String.format(Locale.US, "%.1f km", value / 1000.0)
                        : String.format(Locale.US, "%.0f m", value);
                canvas.drawText(txt, x, getHeight() - dp(12), label);
            }

            if (selectedIndex >= 0 && selectedIndex < data.size()) {
                TerrainElevation.Sample s = data.get(selectedIndex);
                if (Double.isFinite(s.elevationMeters)) {
                    float x = left + (float) (s.distanceMeters / maxX) * (right - left);
                    float y = bottom - (float) ((s.elevationMeters - minY) / spanY) * (bottom - top);
                    canvas.drawLine(x, top, x, bottom, selection);
                    Paint point = new Paint(Paint.ANTI_ALIAS_FLAG);
                    point.setColor(accent);
                    canvas.drawCircle(x, y, dp(4.2f), point);
                    point.setStyle(Paint.Style.STROKE);
                    point.setStrokeWidth(dp(1.5f));
                    point.setColor(Color.WHITE);
                    canvas.drawCircle(x, y, dp(4.2f), point);

                    double slope = localSlopePercent(selectedIndex);
                    String distanceText = s.distanceMeters >= 1000
                            ? String.format(Locale.US, "%.3f km", s.distanceMeters / 1000.0)
                            : String.format(Locale.US, "%.1f m", s.distanceMeters);
                    String slopeText = Double.isFinite(slope) ? String.format(Locale.US, "%+.1f%%", slope) : "--";
                    String tip = distanceText + "  •  " + String.format(Locale.US, "%.1f m", s.elevationMeters)
                            + "  •  " + slopeText;
                    float pad = dp(7);
                    float tipWidth = tooltipText.measureText(tip) + pad * 2;
                    float tipHeight = dp(26);
                    float tipLeft = Math.max(dp(6), Math.min(getWidth() - tipWidth - dp(6), x - tipWidth / 2f));
                    float tipTop = y - tipHeight - dp(10);
                    if (tipTop < dp(5)) tipTop = y + dp(10);
                    canvas.drawRoundRect(tipLeft, tipTop, tipLeft + tipWidth, tipTop + tipHeight,
                            dp(8), dp(8), tooltipBg);
                    tooltipText.setTextAlign(Paint.Align.CENTER);
                    Paint.FontMetrics fm = tooltipText.getFontMetrics();
                    float textY = tipTop + tipHeight / 2f - (fm.ascent + fm.descent) / 2f;
                    canvas.drawText(tip, tipLeft + tipWidth / 2f, textY, tooltipText);
                }
            }
        }
    }

    private static final class Metric {
        final LinearLayout root;
        final TextView value;
        Metric(LinearLayout root, TextView value) {
            this.root = root;
            this.value = value;
        }
    }
}
