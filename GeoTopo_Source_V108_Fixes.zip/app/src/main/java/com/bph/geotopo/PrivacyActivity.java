package com.bph.geotopo;

import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Privacy and data-use summary available inside GeoTopo. */
public class PrivacyActivity extends BaseToolActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();

        LinearLayout root = page("Privacidad", "GeoTopo · uso de datos");
        LinearLayout content = vertical();

        content.addView(infoCard("Resumen",
                "GeoTopo no requiere crear una cuenta. Los cálculos topográficos se realizan en el dispositivo. "
                        + "Los puntos, proyectos y preferencias se guardan localmente hasta que el usuario los borra o exporta."));

        content.addView(infoCard("Ubicación y GNSS",
                "La ubicación precisa se usa únicamente cuando activas funciones que la necesitan, como GPS, mapas, "
                        + "replanteo, registro de recorridos o captura de puntos. El registro de recorridos usa una notificación "
                        + "visible mientras trabaja en primer plano. La precisión depende del dispositivo, receptor y entorno."));

        content.addView(infoCard("Mapas y búsquedas por internet",
                "El mapa normal usa OpenFreeMap/OpenMapTiles y datos de OpenStreetMap. Las búsquedas de lugares y la obtención "
                        + "de nombres de ubicación pueden usar el servicio de geocodificación del dispositivo y, cuando haga falta, Nominatim de OpenStreetMap. Si el desarrollador configura la "
                        + "capa satelital, GeoTopo usa el servicio oficial de Esri. Estos servicios reciben las solicitudes de red "
                        + "necesarias para entregar el mapa o la búsqueda, como la zona del mapa, coordenadas o texto buscado."));

        content.addView(infoCard("Datos locales y copias de seguridad",
                "GeoTopo tiene desactivada la copia de seguridad automática de Android para sus datos. Los proyectos y puntos "
                        + "permanecen en el dispositivo salvo que el usuario elija exportarlos o compartirlos. Si borras los datos "
                        + "de la app o la desinstalas sin exportar, puedes perder esa información."));

        content.addView(infoCard("Archivos y fotos",
                "Los archivos MBTiles, imágenes y documentos que selecciones se usan para la función solicitada. GeoTopo no los "
                        + "sube a un servidor propio. Solo salen del dispositivo cuando tú utilizas una función de compartir o exportar."));

        content.addView(infoCard("Uso profesional",
                "GeoTopo es una herramienta de apoyo para cálculos, registro y visualización topográfica. No sustituye un levantamiento "
                        + "certificado, un control geodésico oficial ni a un profesional autorizado cuando la normativa local lo exija. "
                        + "No debe utilizarse como única fuente para definir límites legales de propiedad."));

        content.addView(infoCard("Contacto y versión de la política",
                "El contacto del desarrollador se publica en la ficha oficial de GeoTopo en Google Play. "
                        + "Versión de esta política: 17 de agosto de 2026."));

        root.addView(scrollWith(content), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private LinearLayout infoCard(String title, String body) {
        LinearLayout box = card();
        TextView heading = text(title, 17, true);
        box.addView(heading);

        TextView paragraph = text(body, 13, false);
        paragraph.setTextColor(subTextColor);
        paragraph.setLineSpacing(dp(2), 1.08f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(6), 0, 0);
        box.addView(paragraph, lp);
        return box;
    }
}
