package com.bph.geotopo;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;

/**
 * Traslado subterráneo: lleva coordenadas (poligonal abierta con azimut inicial y
 * ángulos a la derecha) y cota (nivelación con puntos de piso o de techo) desde
 * superficie hasta la labor. Dos pestañas que comparten los mismos puntos y un
 * croquis dibujado con los datos de la libreta: planta y perfil.
 */
public class MineTransferActivity extends BaseToolActivity {

    private static final String WORK_KEY = "mine_transfer_work_v1";

    /** Un punto de la libreta. Los textos son lo que escribe el usuario; lo demás se calcula. */
    private static class Row {
        String name = "", dist = "", az = "", ang = "", e = "", n = "";
        String va = "", vad = "", cota = "";
        boolean roof;
        double azC = Double.NaN, eC = Double.NaN, nC = Double.NaN;
        double aiC = Double.NaN, cotaC = Double.NaN, chain = Double.NaN;
    }

    private interface Setter { void set(Row r, String value); }

    private final ArrayList<Row> rows = new ArrayList<>();
    private int tab = 0;
    private boolean binding;
    private boolean light;

    // Colores de la pantalla
    private int panelTop, panelBottom, cellEdit, cellLocked, cellLine, ink, inkSoft;
    private int red, green, amber, rock;

    // Vistas
    private TextView tabPlan, tabProfile;
    private LinearLayout tabBody;
    private TableLayout table;
    private final ArrayList<TextView[]> outs = new ArrayList<>();
    private final ArrayList<EditText[]> angleCells = new ArrayList<>();
    private LinearLayout summary;
    private PlanView planView;
    private ProfileView profileView;
    private EditText activeAngle;
    private EditText stakeDelta;
    private TextView stakeResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        NativeUi.styleWindow(this);
        light = themeMode == 0;
        setupColors();
        loadWork();
        compute();

        FrameLayout root;
        if (light) {
            root = new FrameLayout(this);
            root.setBackgroundColor(bgColor);
        } else {
            root = NativeUi.screen(this);
        }
        LinearLayout page = NativeUi.column(this);
        page.addView(NativeUi.pageHeader(this, "Traslado subterráneo",
                "Coordenadas y cota de superficie a mina", v -> finish(), null, null));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout content = NativeUi.column(this);
        int hp = ResponsiveUi.isNarrow(this) ? dp(9) : dp(12);
        content.setPadding(hp, dp(8), hp, dp(22));

        content.addView(buildTabs());
        tabBody = NativeUi.column(this);
        content.addView(tabBody, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        scroll.addView(content);
        page.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(page, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        tab = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(WORK_KEY + "_tab", 0) == 1 ? 1 : 0;
        showTab(tab);
    }

    @Override
    protected void onPause() {
        saveWork();
        super.onPause();
    }

    // ------------------------------------------------------------------ colores

    private void setupColors() {
        if (light) {
            panelTop = Color.rgb(252, 253, 255);
            panelBottom = Color.rgb(241, 247, 255);
            cellEdit = Color.rgb(252, 253, 255);
            cellLocked = Color.rgb(240, 244, 249);
            cellLine = Color.rgb(190, 198, 210);
            ink = Color.rgb(24, 34, 50);
            inkSoft = Color.rgb(96, 108, 124);
            red = Color.rgb(214, 44, 58);
            green = Color.rgb(16, 150, 92);
            amber = Color.rgb(205, 125, 0);
            rock = Color.rgb(150, 118, 86);
        } else {
            panelTop = Color.rgb(10, 31, 49);
            panelBottom = Color.rgb(6, 22, 38);
            cellEdit = Color.rgb(10, 31, 50);
            cellLocked = Color.rgb(19, 39, 57);
            cellLine = Color.rgb(70, 98, 124);
            ink = Color.rgb(242, 247, 252);
            inkSoft = Color.rgb(170, 192, 214);
            red = Color.rgb(255, 92, 104);
            green = Color.rgb(52, 222, 146);
            amber = Color.rgb(255, 186, 72);
            rock = Color.rgb(176, 146, 112);
        }
    }

    // ------------------------------------------------------------------ pestañas

    private View buildTabs() {
        LinearLayout panel = panel();
        panel.setPadding(dp(5), dp(6), dp(5), dp(6));
        LinearLayout row = NativeUi.row(this);
        tabPlan = tabButton("◇  Planta", "Coordenadas");
        tabProfile = tabButton("≋  Perfil", "Cota");
        tabPlan.setOnClickListener(v -> showTab(0));
        tabProfile.setOnClickListener(v -> showTab(1));
        LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(0, dp(58), 1f);
        a.setMargins(dp(3), 0, dp(3), 0);
        LinearLayout.LayoutParams b = new LinearLayout.LayoutParams(0, dp(58), 1f);
        b.setMargins(dp(3), 0, dp(3), 0);
        row.addView(tabPlan, a);
        row.addView(tabProfile, b);
        panel.addView(row);
        return panel;
    }

    private TextView tabButton(String title, String sub) {
        TextView t = new TextView(this);
        t.setText(title + "\n" + sub);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        ResponsiveUi.configureCompactText(t, 14, 10, 2);
        t.setLineSpacing(0, 1.05f);
        return t;
    }

    private void styleTab(TextView t, boolean on) {
        GradientDrawable gd;
        if (on) {
            gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{borderColor, darken(borderColor, .70f)});
            gd.setStroke(dp(1), withAlpha(Color.WHITE, 60));
            t.setTextColor(Color.WHITE);
        } else {
            gd = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    light ? new int[]{Color.WHITE, Color.rgb(244, 248, 253)}
                          : new int[]{Color.rgb(12, 34, 54), Color.rgb(7, 24, 41)});
            gd.setStroke(dp(1), withAlpha(borderColor, 150));
            t.setTextColor(light ? darken(borderColor, .8f) : inkSoft);
        }
        gd.setCornerRadius(dp(13));
        t.setBackground(gd);
    }

    private void showTab(int which) {
        tab = which;
        styleTab(tabPlan, tab == 0);
        styleTab(tabProfile, tab == 1);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(WORK_KEY + "_tab", tab).apply();
        tabBody.removeAllViews();
        planView = null;
        profileView = null;
        stakeDelta = null;
        stakeResult = null;
        activeAngle = null;

        // Libreta
        LinearLayout book = panel();
        LinearLayout head = NativeUi.row(this);
        TextView title = label(tab == 0 ? "Libreta de planta" : "Libreta de nivelación", 17, true, ink);
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView badge = label(rows.size() + " ptos", 11, true, borderColor);
        badge.setPadding(dp(9), dp(4), dp(9), dp(4));
        badge.setBackground(round(withAlpha(borderColor, 30), 20, withAlpha(borderColor, 140)));
        head.addView(badge);
        book.addView(head);
        TextView hint = label(tab == 0
                ? "En BM1 escribe E y N. En la segunda fila el azimut inicial. En cada estación el ángulo a la derecha."
                : "En BM1 escribe la cota. Marca Techo cuando la mira cuelga del techo de la labor.", 12, false, inkSoft);
        hint.setPadding(0, dp(3), 0, dp(6));
        book.addView(hint);
        if (tab == 0) book.addView(angleKeys());

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        table = new TableLayout(this);
        hsv.addView(table);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.setMargins(0, dp(4), 0, dp(8));
        book.addView(hsv, tlp);
        buildTable();

        LinearLayout buttons = NativeUi.row(this);
        TextView add = actionButton("＋ Punto", false, false);
        add.setOnClickListener(v -> addRow());
        TextView del = actionButton("－ Último", false, false);
        del.setOnClickListener(v -> removeLastRow());
        TextView clear = actionButton("⌫ Limpiar", false, true);
        clear.setOnClickListener(v -> confirmClear());
        buttons.addView(add, btnLp(1.1f, 0));
        buttons.addView(del, btnLp(1f, 5));
        buttons.addView(clear, btnLp(1f, 5));
        book.addView(buttons);
        tabBody.addView(book);

        // Resultados
        LinearLayout res = panel();
        res.addView(label(tab == 0 ? "Resultados" : "Resultados y comprobación", 16, true, ink));
        summary = NativeUi.column(this);
        res.addView(summary);
        tabBody.addView(res);

        if (tab == 1) tabBody.addView(stakePanel());

        // Croquis
        LinearLayout sketch = panel();
        LinearLayout sh = NativeUi.row(this);
        sh.addView(label(tab == 0 ? "Croquis en planta" : "Perfil longitudinal", 17, true, ink),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        sh.addView(label("Pellizca · doble toque", 11, false, inkSoft));
        sketch.addView(sh);
        View canvasView;
        if (tab == 0) {
            planView = new PlanView(this);
            canvasView = planView;
        } else {
            profileView = new ProfileView(this);
            canvasView = profileView;
        }
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(tab == 0 ? 400 : 380));
        clp.setMargins(0, dp(8), 0, 0);
        sketch.addView(canvasView, clp);
        sketch.addView(legend());
        tabBody.addView(sketch);

        refreshOutputs();
    }

    // ------------------------------------------------------------------ tabla

    private void buildTable() {
        binding = true;
        table.removeAllViews();
        outs.clear();
        angleCells.clear();
        if (tab == 0) {
            table.addView(headerRow(new String[]{"Pto", "Dist. (m)", "Azimut", "∠ Derecha", "E (m)", "N (m)"},
                    new int[]{66, 84, 104, 104, 112, 118}));
        } else {
            table.addView(headerRow(new String[]{"Pto", "Dist. H", "V. Atrás", "A.I", "V. Adel.", "Cota", "Mira en"},
                    new int[]{66, 78, 86, 100, 86, 100, 84}));
        }
        for (int i = 0; i < rows.size(); i++) table.addView(tab == 0 ? planRow(i) : profileRow(i));
        binding = false;
    }

    private TableRow headerRow(String[] titles, int[] widths) {
        TableRow tr = new TableRow(this);
        for (int i = 0; i < titles.length; i++) {
            TextView v = new TextView(this);
            v.setText(titles[i]);
            v.setGravity(Gravity.CENTER);
            v.setTypeface(Typeface.DEFAULT_BOLD);
            v.setTextColor(Color.WHITE);
            ResponsiveUi.configureCompactText(v, 12.5f, 9, 1);
            v.setPadding(dp(4), dp(9), dp(4), dp(9));
            GradientDrawable gd = new GradientDrawable();
            gd.setColor(borderColor);
            gd.setStroke(1, withAlpha(Color.WHITE, 45));
            if (i == 0) gd.setCornerRadii(new float[]{dp(10), dp(10), 0, 0, 0, 0, 0, 0});
            if (i == titles.length - 1) gd.setCornerRadii(new float[]{0, 0, dp(10), dp(10), 0, 0, 0, 0});
            v.setBackground(gd);
            v.setMinWidth(dp(widths[i]));
            v.setWidth(dp(widths[i]));
            tr.addView(v);
        }
        return tr;
    }

    private TableRow planRow(int i) {
        Row r = rows.get(i);
        TableRow tr = new TableRow(this);
        TextView[] o = new TextView[3]; // az, e, n
        EditText[] ang = new EditText[2];
        tr.addView(edit(r.name, i, false, false, (row, s) -> row.name = s, 66, true));
        if (i == 0) tr.addView(locked("—", 84)); else tr.addView(edit(r.dist, i, true, false, (row, s) -> row.dist = s, 84, false));
        if (i == 1) {
            EditText az = edit(r.az, i, false, true, (row, s) -> row.az = s, 104, false);
            ang[0] = az;
            tr.addView(az);
        } else if (i == 0) {
            tr.addView(locked("—", 104));
        } else {
            o[0] = locked("", 104);
            o[0].setTextColor(borderColor);
            tr.addView(o[0]);
        }
        if (i == 0) tr.addView(locked("—", 104));
        else {
            EditText a = edit(r.ang, i, false, true, (row, s) -> row.ang = s, 104, false);
            ang[1] = a;
            tr.addView(a);
        }
        if (i == 0) {
            tr.addView(edit(r.e, i, true, false, (row, s) -> row.e = s, 112, false));
            tr.addView(edit(r.n, i, true, false, (row, s) -> row.n = s, 118, false));
        } else {
            o[1] = locked("", 112);
            o[2] = locked("", 118);
            o[1].setTypeface(Typeface.DEFAULT_BOLD);
            o[2].setTypeface(Typeface.DEFAULT_BOLD);
            tr.addView(o[1]);
            tr.addView(o[2]);
        }
        outs.add(o);
        angleCells.add(ang);
        return tr;
    }

    private TableRow profileRow(int i) {
        Row r = rows.get(i);
        TableRow tr = new TableRow(this);
        TextView[] o = new TextView[2]; // ai, cota
        tr.addView(edit(r.name, i, false, false, (row, s) -> row.name = s, 66, true));
        if (i == 0) tr.addView(locked("—", 78)); else tr.addView(edit(r.dist, i, true, false, (row, s) -> row.dist = s, 78, false));
        tr.addView(edit(r.va, i, true, false, (row, s) -> row.va = s, 86, false));
        o[0] = locked("", 100);
        o[0].setTextColor(borderColor);
        tr.addView(o[0]);
        if (i == 0) tr.addView(locked("—", 86)); else tr.addView(edit(r.vad, i, true, false, (row, s) -> row.vad = s, 86, false));
        if (i == 0) tr.addView(edit(r.cota, i, true, false, (row, s) -> row.cota = s, 100, false));
        else {
            o[1] = locked("", 100);
            o[1].setTypeface(Typeface.DEFAULT_BOLD);
            tr.addView(o[1]);
        }
        TextView pos = new TextView(this);
        pos.setGravity(Gravity.CENTER);
        pos.setTypeface(Typeface.DEFAULT_BOLD);
        ResponsiveUi.configureCompactText(pos, 12.5f, 9, 1);
        pos.setPadding(dp(4), dp(8), dp(4), dp(8));
        pos.setMinWidth(dp(84));
        pos.setWidth(dp(84));
        styleRoof(pos, r.roof);
        final int idx = i;
        pos.setOnClickListener(v -> {
            Row rr = rows.get(idx);
            rr.roof = !rr.roof;
            styleRoof((TextView) v, rr.roof);
            recompute();
        });
        tr.addView(pos);
        outs.add(o);
        return tr;
    }

    private void styleRoof(TextView v, boolean roof) {
        v.setText(roof ? "▲ Techo" : "▼ Piso");
        int c = roof ? amber : (light ? darken(borderColor, .8f) : Color.rgb(140, 196, 255));
        v.setTextColor(c);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(roof ? withAlpha(amber, light ? 30 : 38) : cellEdit);
        gd.setStroke(1, cellLine);
        v.setBackground(gd);
    }

    private EditText edit(String value, int rowIndex, boolean number, boolean angle,
                          Setter setter, int widthDp, boolean bold) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setTextColor(ink);
        e.setHintTextColor(withAlpha(inkSoft, 150));
        ResponsiveUi.configureText(e, 13.5f);
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER);
        e.setPadding(dp(4), dp(6), dp(4), dp(6));
        e.setMinWidth(dp(widthDp));
        e.setWidth(dp(widthDp));
        if (bold) e.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(cellEdit);
        gd.setStroke(1, cellLine);
        e.setBackground(gd);
        if (angle) {
            e.setRawInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            e.setHint("0°00'00\"");
            e.setOnFocusChangeListener((v, has) -> { if (has) activeAngle = (EditText) v; });
            e.setOnClickListener(v -> activeAngle = (EditText) v);
        } else if (number) {
            e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL
                    | InputType.TYPE_NUMBER_FLAG_SIGNED);
        } else {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        }
        final int idx = rowIndex;
        e.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) {
                if (binding || idx >= rows.size()) return;
                setter.set(rows.get(idx), s.toString());
                recompute();
            }
        });
        return e;
    }

    private TextView locked(String value, int widthDp) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextColor(ink);
        v.setGravity(Gravity.CENTER);
        ResponsiveUi.configureCompactText(v, 13, 9, 1);
        v.setPadding(dp(4), dp(8), dp(4), dp(8));
        v.setMinWidth(dp(widthDp));
        v.setWidth(dp(widthDp));
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(cellLocked);
        gd.setStroke(1, cellLine);
        v.setBackground(gd);
        return v;
    }

    private View angleKeys() {
        LinearLayout row = NativeUi.row(this);
        String[] keys = {"°", "'", "\"", "⌫"};
        for (String k : keys) {
            TextView b = new TextView(this);
            b.setText(k);
            b.setGravity(Gravity.CENTER);
            b.setTypeface(Typeface.DEFAULT_BOLD);
            b.setTextColor(light ? darken(borderColor, .8f) : Color.WHITE);
            ResponsiveUi.configureCompactText(b, 15, 11, 1);
            b.setBackground(round(light ? Color.rgb(244, 249, 255) : Color.rgb(7, 23, 39), 11,
                    withAlpha(borderColor, 160)));
            b.setOnClickListener(v -> {
                if ("⌫".equals(k)) deleteAngleChar(); else insertAngleText(k);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(40), 1f);
            lp.setMargins(dp(3), dp(2), dp(3), dp(4));
            row.addView(b, lp);
        }
        return row;
    }

    private void insertAngleText(String text) {
        EditText t = activeAngle;
        if (t == null) { showToast("Toca primero una celda de ángulo."); return; }
        t.requestFocus();
        Editable ed = t.getText();
        if (ed == null) return;
        int len = ed.length();
        int start = Math.max(0, Math.min(len, t.getSelectionStart()));
        int end = Math.max(0, Math.min(len, t.getSelectionEnd()));
        if (end < start) { int x = start; start = end; end = x; }
        int before = ed.length() - (end - start);
        try {
            ed.replace(start, end, text);
            int inserted = Math.max(0, ed.length() - before);
            t.setSelection(Math.max(0, Math.min(ed.length(), start + inserted)));
        } catch (RuntimeException ex) {
            try { t.setSelection(Math.max(0, Math.min(t.length(), start))); } catch (RuntimeException ignored) { }
        }
    }

    private void deleteAngleChar() {
        EditText t = activeAngle;
        if (t == null) return;
        t.requestFocus();
        Editable ed = t.getText();
        if (ed == null) return;
        int start = Math.max(0, Math.min(ed.length(), t.getSelectionStart()));
        int end = Math.max(0, Math.min(ed.length(), t.getSelectionEnd()));
        try {
            if (end > start) { ed.delete(start, end); t.setSelection(start); }
            else if (start > 0) { ed.delete(start - 1, start); t.setSelection(start - 1); }
        } catch (RuntimeException ignored) { }
    }

    private void addRow() {
        Row r = new Row();
        r.name = nextName();
        rows.add(r);
        rebuildAfterRowsChange();
    }

    private void removeLastRow() {
        if (rows.size() <= 2) { showToast("Se necesitan al menos dos puntos."); return; }
        rows.remove(rows.size() - 1);
        rebuildAfterRowsChange();
    }

    private void confirmClear() {
        new AlertDialog.Builder(this)
                .setTitle("Limpiar libreta")
                .setMessage("Se borrarán los datos de planta y de perfil.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Limpiar", (d, w) -> {
                    rows.clear();
                    defaultRows();
                    rebuildAfterRowsChange();
                })
                .show();
    }

    private void rebuildAfterRowsChange() {
        compute();
        saveWork();
        showTab(tab);
    }

    private String nextName() {
        if (rows.isEmpty()) return "BM1";
        String last = rows.get(rows.size() - 1).name.trim().toUpperCase(Locale.ROOT);
        if (last.length() == 1 && last.charAt(0) >= 'A' && last.charAt(0) < 'Z') {
            return String.valueOf((char) (last.charAt(0) + 1));
        }
        if (last.startsWith("BM")) {
            try { return "BM" + (Integer.parseInt(last.substring(2)) + 1); } catch (RuntimeException ignored) { }
        }
        return "P" + (rows.size() + 1);
    }

    // ------------------------------------------------------------------ cálculo

    private static double num(String s) {
        if (s == null) return Double.NaN;
        String t = s.trim().replace(',', '.');
        if (t.isEmpty()) return Double.NaN;
        try {
            double v = Double.parseDouble(t);
            return (Double.isNaN(v) || Double.isInfinite(v)) ? Double.NaN : v;
        } catch (RuntimeException ex) {
            return Double.NaN;
        }
    }

    private static double ang(String s) {
        if (s == null || s.trim().isEmpty()) return Double.NaN;
        try { return AzimuthMath.angle(s, 360d); } catch (RuntimeException ex) { return Double.NaN; }
    }

    private static boolean ok(double v) { return !Double.isNaN(v) && !Double.isInfinite(v); }

    private void compute() {
        int n = rows.size();
        if (n == 0) return;
        // Planta: poligonal abierta con azimut inicial y ángulos a la derecha.
        Row r0 = rows.get(0);
        r0.eC = num(r0.e);
        r0.nC = num(r0.n);
        r0.azC = Double.NaN;
        double az = Double.NaN;
        for (int i = 1; i < n; i++) {
            Row r = rows.get(i);
            Row p = rows.get(i - 1);
            if (i == 1) az = ang(r.az);
            else {
                double a = ang(p.ang);
                az = (ok(az) && ok(a)) ? AzimuthMath.normal(az + a - 180d) : Double.NaN;
            }
            r.azC = az;
            double d = num(r.dist);
            if (ok(az) && ok(d) && ok(p.eC) && ok(p.nC)) {
                double rad = Math.toRadians(az);
                r.eC = p.eC + d * Math.sin(rad);
                r.nC = p.nC + d * Math.cos(rad);
            } else {
                r.eC = Double.NaN;
                r.nC = Double.NaN;
            }
        }
        // Progresivas (comparten la distancia de planta)
        double chain = 0;
        double known = 0;
        int count = 0;
        for (int i = 1; i < n; i++) {
            double d = num(rows.get(i).dist);
            if (ok(d) && d > 0) { known += d; count++; }
        }
        double fallback = count > 0 ? known / count : 10d;
        r0.chain = 0;
        for (int i = 1; i < n; i++) {
            double d = num(rows.get(i).dist);
            chain += (ok(d) && d >= 0) ? d : fallback;
            rows.get(i).chain = chain;
        }
        // Perfil: nivelación. Piso: cota = A.I − lectura. Techo: cota = A.I + lectura.
        r0.cotaC = num(r0.cota);
        double ai = Double.NaN;
        for (int i = 0; i < n; i++) {
            Row r = rows.get(i);
            double s = r.roof ? -1d : 1d;
            if (i > 0) {
                double vad = num(r.vad);
                r.cotaC = (ok(ai) && ok(vad)) ? ai - s * vad : Double.NaN;
            }
            r.aiC = Double.NaN;
            double va = num(r.va);
            if (ok(va)) {
                if (ok(r.cotaC)) { ai = r.cotaC + s * va; r.aiC = ai; }
                else ai = Double.NaN;
            }
        }
    }

    private void recompute() {
        compute();
        refreshOutputs();
        saveWork();
    }

    private int lastWithCota() {
        int last = -1;
        for (int i = 1; i < rows.size(); i++) if (ok(rows.get(i).cotaC)) last = i;
        return last;
    }

    private void refreshOutputs() {
        for (int i = 0; i < outs.size() && i < rows.size(); i++) {
            Row r = rows.get(i);
            TextView[] o = outs.get(i);
            if (tab == 0) {
                if (o[0] != null) o[0].setText(ok(r.azC) ? AzimuthMath.dms(r.azC) : "");
                if (o[1] != null) o[1].setText(ok(r.eC) ? f3(r.eC) : "");
                if (o[2] != null) o[2].setText(ok(r.nC) ? f3(r.nC) : "");
                EditText[] a = i < angleCells.size() ? angleCells.get(i) : null;
                if (a != null) {
                    if (a[0] != null) markAngle(a[0]);
                    if (a[1] != null) markAngle(a[1]);
                }
            } else {
                if (o[0] != null) o[0].setText(ok(r.aiC) ? f3(r.aiC) : "");
                if (o[1] != null) {
                    o[1].setText(ok(r.cotaC) ? f3(r.cotaC) : "");
                    o[1].setTextColor(r.roof ? amber : green);
                }
            }
        }
        refreshSummary();
        refreshStake();
        if (planView != null) planView.invalidate();
        if (profileView != null) profileView.invalidate();
    }

    private void markAngle(EditText e) {
        String t = e.getText() == null ? "" : e.getText().toString();
        boolean bad = !t.trim().isEmpty() && !ok(ang(t));
        e.setTextColor(bad ? red : ink);
    }

    private void refreshSummary() {
        if (summary == null) return;
        summary.removeAllViews();
        if (tab == 0) {
            int last = -1;
            double total = 0;
            for (int i = 1; i < rows.size(); i++) {
                if (ok(rows.get(i).eC)) last = i;
                double d = num(rows.get(i).dist);
                if (ok(d)) total += d;
            }
            LinearLayout chips = NativeUi.row(this);
            chips.addView(chip("Longitud", ok(total) && total > 0 ? f2(total) + " m" : "—", borderColor), chipLp(0));
            chips.addView(chip("Azimut final", last > 0 ? AzimuthMath.dms(rows.get(last).azC) : "—", red), chipLp(6));
            summary.addView(chips);
            int shown = 0;
            for (int i = 1; i < rows.size(); i++) {
                Row r = rows.get(i);
                if (!ok(r.eC)) continue;
                summary.addView(coordLine(r));
                shown++;
            }
            if (shown == 0) summary.addView(note("Completa BM1 (E, N), el azimut inicial y las distancias."));
        } else {
            int last = lastWithCota();
            Row r0 = rows.get(0);
            LinearLayout chips = NativeUi.row(this);
            chips.addView(chip("Cota final", last > 0 ? rows.get(last).name + "  " + f3(rows.get(last).cotaC) : "—", green), chipLp(0));
            chips.addView(chip("Desnivel", last > 0 && ok(r0.cotaC) ? signed(rows.get(last).cotaC - r0.cotaC) + " m" : "—", borderColor), chipLp(6));
            summary.addView(chips);
            if (last > 0 && ok(r0.cotaC)) {
                double sumVa = 0, sumVad = 0;
                for (int i = 0; i <= last; i++) {
                    Row r = rows.get(i);
                    double s = r.roof ? -1d : 1d;
                    double va = num(r.va);
                    if (i < last && ok(va) && ok(r.aiC)) sumVa += s * va;
                    double vad = num(r.vad);
                    if (i > 0 && ok(vad) && (i == last || ok(r.aiC))) sumVad += s * vad;
                }
                double diff = rows.get(last).cotaC - r0.cotaC;
                boolean good = Math.abs((sumVa - sumVad) - diff) < 0.0005;
                LinearLayout check = NativeUi.column(this);
                check.setPadding(dp(12), dp(10), dp(12), dp(10));
                check.setBackground(round(light ? Color.rgb(240, 252, 246) : Color.rgb(5, 40, 36), 13,
                        good ? green : red));
                check.addView(label((good ? "✓  " : "✗  ") + "Comprobación aritmética", 14, true, good ? green : red));
                TextView l1 = label("ΣV.Atrás − ΣV.Adel. = " + signed(sumVa - sumVad) + " m", 13, false, ink);
                TextView l2 = label("Cota final − Cota inicial = " + signed(diff) + " m", 13, false, ink);
                l1.setPadding(0, dp(4), 0, 0);
                check.addView(l1);
                check.addView(l2);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.setMargins(0, dp(8), 0, 0);
                summary.addView(check, lp);
            } else {
                summary.addView(note("Completa la cota de BM1 y las lecturas de mira."));
            }
        }
    }

    private View coordLine(Row r) {
        LinearLayout line = NativeUi.row(this);
        line.setPadding(dp(10), dp(8), dp(10), dp(8));
        line.setBackground(round(light ? Color.WHITE : Color.rgb(8, 29, 47), 11, withAlpha(borderColor, 90)));
        TextView name = label(r.name.isEmpty() ? "—" : r.name, 14, true, ink);
        line.addView(name, new LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView e = label("E " + f3(r.eC), 13, false, ink);
        TextView n = label("N " + f3(r.nC), 13, false, ink);
        line.addView(e, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        line.addView(n, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.1f));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(6), 0, 0);
        line.setLayoutParams(lp);
        return line;
    }

    // ------------------------------------------------------------------ replanteo de cota

    private View stakePanel() {
        LinearLayout p = panel();
        p.addView(label("Marcar a desnivel", 16, true, ink));
        TextView h = label("Desnivel respecto a " + (rows.get(0).name.isEmpty() ? "BM1" : rows.get(0).name)
                + " con la primera estación. Ejemplo: +1.000 para marcar 1 m más arriba.", 12, false, inkSoft);
        h.setPadding(0, dp(3), 0, dp(4));
        p.addView(h);
        stakeDelta = new EditText(this);
        stakeDelta.setHint("Desnivel (m)  ej. +1.000");
        stakeDelta.setText(getSharedPreferences(PREFS, MODE_PRIVATE).getString(WORK_KEY + "_stake", ""));
        stakeDelta.setTextColor(ink);
        stakeDelta.setHintTextColor(withAlpha(inkSoft, 170));
        ResponsiveUi.configureText(stakeDelta, 15);
        stakeDelta.setSingleLine(true);
        stakeDelta.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL
                | InputType.TYPE_NUMBER_FLAG_SIGNED);
        stakeDelta.setPadding(dp(12), dp(10), dp(12), dp(10));
        stakeDelta.setBackground(round(light ? Color.WHITE : Color.rgb(8, 31, 50), 11, withAlpha(borderColor, 150)));
        stakeDelta.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(WORK_KEY + "_stake", s.toString()).apply();
                refreshStake();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        lp.setMargins(0, dp(4), 0, dp(6));
        p.addView(stakeDelta, lp);
        stakeResult = label("", 14, false, ink);
        stakeResult.setLineSpacing(0, 1.15f);
        p.addView(stakeResult);
        refreshStake();
        return p;
    }

    private void refreshStake() {
        if (stakeResult == null || stakeDelta == null) return;
        Row r0 = rows.get(0);
        double d = num(stakeDelta.getText() == null ? "" : stakeDelta.getText().toString());
        if (!ok(r0.aiC) || !ok(r0.cotaC)) {
            stakeResult.setText("Necesita la cota de " + r0.name + " y su V. Atrás.");
            stakeResult.setTextColor(inkSoft);
            return;
        }
        if (!ok(d)) {
            stakeResult.setText("A.I = " + f3(r0.aiC) + "   ·   escribe el desnivel.");
            stakeResult.setTextColor(inkSoft);
            return;
        }
        double target = r0.cotaC + d;
        double reading = r0.aiC - target;
        StringBuilder sb = new StringBuilder();
        sb.append("A.I = ").append(f3(r0.aiC)).append('\n');
        sb.append("Cota a marcar = ").append(f3(target)).append('\n');
        if (reading >= 0) {
            sb.append("Lectura en mira (piso) = ").append(f3(reading));
        } else {
            sb.append("La marca queda sobre la visual: mira invertida en techo, lectura = ").append(f3(-reading));
        }
        stakeResult.setText(sb.toString());
        stakeResult.setTextColor(ink);
    }

    // ------------------------------------------------------------------ guardar

    private void defaultRows() {
        String[] names = {"BM1", "BM2", "A", "B", "C"};
        for (String s : names) {
            Row r = new Row();
            r.name = s;
            rows.add(r);
        }
    }

    private void loadWork() {
        rows.clear();
        String raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString(WORK_KEY, "");
        try {
            if (raw != null && !raw.isEmpty()) {
                JSONArray arr = new JSONArray(raw);
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    Row r = new Row();
                    r.name = o.optString("name", "");
                    r.dist = o.optString("dist", "");
                    r.az = o.optString("az", "");
                    r.ang = o.optString("ang", "");
                    r.e = o.optString("e", "");
                    r.n = o.optString("n", "");
                    r.va = o.optString("va", "");
                    r.vad = o.optString("vad", "");
                    r.cota = o.optString("cota", "");
                    r.roof = o.optBoolean("roof", false);
                    rows.add(r);
                }
            }
        } catch (Exception ex) {
            rows.clear();
        }
        if (rows.size() < 2) {
            rows.clear();
            defaultRows();
        }
    }

    private void saveWork() {
        try {
            JSONArray arr = new JSONArray();
            for (Row r : rows) {
                JSONObject o = new JSONObject();
                o.put("name", r.name);
                o.put("dist", r.dist);
                o.put("az", r.az);
                o.put("ang", r.ang);
                o.put("e", r.e);
                o.put("n", r.n);
                o.put("va", r.va);
                o.put("vad", r.vad);
                o.put("cota", r.cota);
                o.put("roof", r.roof);
                arr.put(o);
            }
            SharedPreferences.Editor ed = getSharedPreferences(PREFS, MODE_PRIVATE).edit();
            ed.putString(WORK_KEY, arr.toString());
            ed.apply();
        } catch (Exception ignored) { }
    }

    // ------------------------------------------------------------------ piezas visuales

    private LinearLayout panel() {
        LinearLayout p = NativeUi.column(this);
        int hp = ResponsiveUi.isNarrow(this) ? dp(10) : dp(13);
        p.setPadding(hp, dp(12), hp, dp(12));
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{panelTop, panelBottom});
        gd.setCornerRadius(dp(16));
        gd.setStroke(dp(1), withAlpha(borderColor, light ? 110 : 150));
        p.setBackground(gd);
        if (Build.VERSION.SDK_INT >= 21) p.setElevation(dp(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(6), 0, dp(6));
        p.setLayoutParams(lp);
        return p;
    }

    private TextView label(String value, float sp, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        ResponsiveUi.configureText(t, sp);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView note(String value) {
        TextView t = label(value, 13, false, inkSoft);
        t.setPadding(0, dp(8), 0, 0);
        return t;
    }

    private View chip(String title, String value, int color) {
        LinearLayout c = NativeUi.column(this);
        c.setPadding(dp(11), dp(8), dp(11), dp(9));
        c.setBackground(round(light ? Color.WHITE : Color.rgb(8, 29, 47), 12, withAlpha(color, 170)));
        TextView t = label(title, 11, true, inkSoft);
        TextView v = label(value, 14.5f, true, color);
        ResponsiveUi.configureCompactText(v, 14.5f, 10, 1);
        v.setPadding(0, dp(2), 0, 0);
        c.addView(t);
        c.addView(v);
        return c;
    }

    private LinearLayout.LayoutParams chipLp(int leftDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(leftDp), dp(8), 0, 0);
        return lp;
    }

    private TextView actionButton(String text, boolean primary, boolean danger) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setGravity(Gravity.CENTER);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        ResponsiveUi.configureCompactText(b, 13.5f, 10, 1);
        GradientDrawable gd;
        if (primary) {
            gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{borderColor, darken(borderColor, .70f)});
            b.setTextColor(Color.WHITE);
        } else if (danger) {
            gd = new GradientDrawable();
            gd.setColor(light ? Color.rgb(255, 247, 248) : Color.rgb(36, 18, 29));
            gd.setStroke(dp(1), Color.rgb(235, 73, 93));
            b.setTextColor(light ? Color.rgb(190, 35, 55) : Color.rgb(255, 104, 118));
        } else {
            gd = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    light ? new int[]{Color.WHITE, Color.rgb(246, 249, 253)}
                          : new int[]{Color.rgb(14, 39, 60), Color.rgb(7, 27, 45)});
            gd.setStroke(dp(1), withAlpha(borderColor, 175));
            b.setTextColor(ink);
        }
        gd.setCornerRadius(dp(12));
        b.setBackground(gd);
        return b;
    }

    private LinearLayout.LayoutParams btnLp(float weight, int leftDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), weight);
        lp.setMargins(dp(leftDp), 0, 0, 0);
        return lp;
    }

    private View legend() {
        LinearLayout row = NativeUi.row(this);
        row.setPadding(0, dp(8), 0, 0);
        if (tab == 0) {
            row.addView(legendItem("▲ BM", borderColor));
            row.addView(legendItem("○ Estación", ink));
            row.addView(legendItem("∠ Ángulo", red));
            row.addView(legendItem("— Distancia", green));
        } else {
            row.addView(legendItem("┅ Visual", borderColor));
            row.addView(legendItem("▼ Piso", ink));
            row.addView(legendItem("▲ Techo", amber));
            row.addView(legendItem("Cota", green));
        }
        return row;
    }

    private View legendItem(String text, int color) {
        TextView t = label(text, 11, true, color);
        t.setGravity(Gravity.CENTER);
        t.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return t;
    }

    private GradientDrawable round(int fill, int radiusDp, int stroke) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(fill);
        gd.setCornerRadius(dp(radiusDp));
        gd.setStroke(dp(1), stroke);
        return gd;
    }

    private static int darken(int color, float factor) {
        return Color.rgb(
                Math.max(0, Math.min(255, Math.round(Color.red(color) * factor))),
                Math.max(0, Math.min(255, Math.round(Color.green(color) * factor))),
                Math.max(0, Math.min(255, Math.round(Color.blue(color) * factor))));
    }

    private static String shortAngle(double a) {
        String d = AzimuthMath.dms(a);
        if (d.endsWith("°00'00\"")) return d.substring(0, d.length() - 6);
        if (d.endsWith("'00\"")) return d.substring(0, d.length() - 3);
        return d;
    }

    private static boolean isBm(Row r) {
        return r.name != null && r.name.trim().toUpperCase(Locale.ROOT).startsWith("BM");
    }

    /** Primer punto que ya no es BM de superficie: ahí empieza la labor. */
    private int portalIndex() {
        for (int i = 0; i < rows.size(); i++) if (!isBm(rows.get(i))) return i;
        return -1;
    }

    // ------------------------------------------------------------------ lienzo con zoom

    private abstract class ZoomCanvas extends View {
        float zoom = 1f, panX = 0f, panY = 0f;
        private float lastX, lastY;
        private boolean resetLast;
        private final ScaleGestureDetector scale;
        private final GestureDetector taps;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Path path = new Path();
        final float d;
        final DashPathEffect dash;

        ZoomCanvas(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
            dash = new DashPathEffect(new float[]{6 * d, 4 * d}, 0);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            halo.setStyle(Paint.Style.STROKE);
            halo.setStrokeWidth(3.2f * d);
            halo.setStrokeJoin(Paint.Join.ROUND);
            scale = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScale(ScaleGestureDetector det) {
                    float nz = Math.max(1f, Math.min(10f, zoom * det.getScaleFactor()));
                    float f = nz / zoom;
                    float cx = getWidth() / 2f, cy = getHeight() / 2f;
                    panX = det.getFocusX() - cx - (det.getFocusX() - cx - panX) * f;
                    panY = det.getFocusY() - cy - (det.getFocusY() - cy - panY) * f;
                    zoom = nz;
                    if (zoom <= 1.001f) { panX = 0; panY = 0; }
                    invalidate();
                    return true;
                }
            });
            taps = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
                @Override public boolean onDown(MotionEvent e) { return true; }
                @Override public boolean onDoubleTap(MotionEvent e) {
                    zoom = 1f; panX = 0; panY = 0;
                    invalidate();
                    return true;
                }
            });
        }

        float zx(float bx) { return getWidth() / 2f + (bx - getWidth() / 2f) * zoom + panX; }
        float zy(float by) { return getHeight() / 2f + (by - getHeight() / 2f) * zoom + panY; }

        @Override public boolean onTouchEvent(MotionEvent e) {
            scale.onTouchEvent(e);
            taps.onTouchEvent(e);
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = e.getX(); lastY = e.getY(); resetLast = false;
                    if (zoom > 1.01f && getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                    break;
                case MotionEvent.ACTION_POINTER_DOWN:
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                    break;
                case MotionEvent.ACTION_POINTER_UP:
                    resetLast = true;
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (resetLast) { lastX = e.getX(); lastY = e.getY(); resetLast = false; break; }
                    if (!scale.isInProgress() && e.getPointerCount() == 1 && zoom > 1.01f) {
                        panX += e.getX() - lastX;
                        panY += e.getY() - lastY;
                        invalidate();
                    }
                    lastX = e.getX(); lastY = e.getY();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                    break;
                default:
                    break;
            }
            return true;
        }

        void paper(Canvas cv, float W, float H) {
            p.setShader(null);
            p.setPathEffect(null);
            p.setStyle(Paint.Style.FILL);
            p.setColor(light ? Color.rgb(253, 254, 255) : Color.rgb(4, 18, 32));
            RectF r = new RectF(0, 0, W, H);
            cv.drawRoundRect(r, 14 * d, 14 * d, p);
        }

        void border(Canvas cv, float W, float H) {
            p.setShader(null);
            p.setPathEffect(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(d);
            p.setColor(withAlpha(borderColor, 120));
            cv.drawRoundRect(new RectF(d / 2, d / 2, W - d / 2, H - d / 2), 14 * d, 14 * d, p);
        }

        void text(Canvas cv, String s, float x, float y, float sizeDp, int color, boolean bold, Paint.Align align) {
            t.setTextSize(sizeDp * d);
            t.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            t.setTextAlign(align);
            halo.setTextSize(sizeDp * d);
            halo.setTypeface(t.getTypeface());
            halo.setTextAlign(align);
            halo.setColor(light ? Color.argb(235, 255, 255, 255) : Color.argb(230, 4, 18, 32));
            cv.drawText(s, x, y, halo);
            t.setColor(color);
            cv.drawText(s, x, y, t);
        }

        void line(Canvas cv, float x1, float y1, float x2, float y2, int color, float wDp, boolean dashed) {
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(wDp * d);
            p.setColor(color);
            p.setPathEffect(dashed ? dash : null);
            cv.drawLine(x1, y1, x2, y2, p);
            p.setPathEffect(null);
        }

        void empty(Canvas cv, float W, float H, String msg) {
            text(cv, msg, W / 2f, H / 2f, 13, inkSoft, false, Paint.Align.CENTER);
        }

        double niceStep(double raw) {
            if (!(raw > 0)) return 1;
            double pow = Math.pow(10, Math.floor(Math.log10(raw)));
            double f = raw / pow;
            double nice = f < 1.5 ? 1 : (f < 3.5 ? 2 : (f < 7.5 ? 5 : 10));
            return nice * pow;
        }

        String meters(double v) {
            if (v >= 1) return (Math.abs(v - Math.rint(v)) < 1e-9 ? String.valueOf((long) Math.rint(v)) : f1(v)) + " m";
            return f2(v) + " m";
        }
    }

    // ------------------------------------------------------------------ croquis en planta

    private class PlanView extends ZoomCanvas {
        PlanView(Context c) { super(c); }

        @Override protected void onDraw(Canvas cv) {
            float W = getWidth(), H = getHeight();
            if (W <= 0 || H <= 0) return;
            paper(cv, W, H);
            cv.save();
            path.reset();
            path.addRoundRect(new RectF(0, 0, W, H), 14 * d, 14 * d, Path.Direction.CW);
            cv.clipPath(path);

            ArrayList<Integer> idx = new ArrayList<>();
            for (int i = 0; i < rows.size(); i++) if (ok(rows.get(i).eC) && ok(rows.get(i).nC)) idx.add(i);

            double minE = Double.MAX_VALUE, maxE = -Double.MAX_VALUE, minN = Double.MAX_VALUE, maxN = -Double.MAX_VALUE;
            for (int i : idx) {
                Row r = rows.get(i);
                minE = Math.min(minE, r.eC); maxE = Math.max(maxE, r.eC);
                minN = Math.min(minN, r.nC); maxN = Math.max(maxN, r.nC);
            }
            if (idx.size() < 2) {
                drawGrid(cv, W, H, 0, 0, 1, 0, 0, 10);
                drawCornerNorth(cv, W);
                cv.restore();
                empty(cv, W, H, "Completa la libreta para ver el croquis");
                border(cv, W, H);
                return;
            }
            float pad = 46 * d;
            double spanE = Math.max(maxE - minE, 1e-6), spanN = Math.max(maxN - minN, 1e-6);
            double span = Math.max(spanE, spanN);
            double sc = Math.min((W - 2 * pad) / Math.max(spanE, span * 0.25),
                    (H - 2 * pad) / Math.max(spanN, span * 0.25));
            final double cE = (minE + maxE) / 2d, cN = (minN + maxN) / 2d;
            final double baseScale = sc;
            int n = idx.size();
            float[] xs = new float[n], ys = new float[n];
            for (int k = 0; k < n; k++) {
                Row r = rows.get(idx.get(k));
                xs[k] = zx((float) (W / 2f + (r.eC - cE) * baseScale));
                ys[k] = zy((float) (H / 2f - (r.nC - cN) * baseScale));
            }
            double pxPerM = baseScale * zoom;
            double gridM = niceStep(34 * d / pxPerM);
            drawGrid(cv, W, H, cE, cN, pxPerM, W / 2f + panX, H / 2f + panY, gridM);

            // Labor subterránea (galería) desde la bocamina hasta el último punto
            int portal = portalIndex();
            int startK = 0;
            float sx0 = xs[0], sy0 = ys[0];
            boolean hasPortal = false;
            if (portal > 0) {
                for (int k = 0; k < n; k++) {
                    if (idx.get(k) == portal) {
                        startK = Math.max(0, k - 1);
                        sx0 = xs[startK] + (xs[k] - xs[startK]) * 0.55f;
                        sy0 = ys[startK] + (ys[k] - ys[startK]) * 0.55f;
                        hasPortal = k > 0;
                        break;
                    }
                    startK = n; // portal sin coordenadas todavía
                }
            }
            if (portal != -1 && startK < n) {
                ArrayList<float[]> axis = new ArrayList<>();
                axis.add(new float[]{sx0, sy0});
                for (int k = hasPortal ? startK + 1 : 0; k < n; k++) axis.add(new float[]{xs[k], ys[k]});
                float half = (float) Math.max(9 * d, Math.min(28 * d, 1.6 * pxPerM));
                drawGallery(cv, axis, half, hasPortal);
            }

            // Eje de la poligonal
            p.setStyle(Paint.Style.STROKE);
            p.setPathEffect(null);
            p.setStrokeWidth(2.6f * d);
            p.setColor(borderColor);
            path.reset();
            for (int k = 0; k < n; k++) { if (k == 0) path.moveTo(xs[k], ys[k]); else path.lineTo(xs[k], ys[k]); }
            cv.drawPath(path, p);

            // Norte y azimut inicial en el primer punto
            Row first = rows.get(idx.get(0));
            if (idx.size() > 1 && ok(rows.get(idx.get(1)).azC)) {
                float nl = 46 * d;
                line(cv, xs[0], ys[0], xs[0], ys[0] - nl, borderColor, 2f, false);
                arrowHead(cv, xs[0], ys[0] - nl, -90, borderColor);
                text(cv, "N", xs[0], ys[0] - nl - 6 * d, 13, borderColor, true, Paint.Align.CENTER);
                double az = rows.get(idx.get(1)).azC;
                angleArc(cv, xs[0], ys[0], -90f, (float) az, 26 * d, red, shortAngle(az));
            }

            // Ángulos a la derecha en cada estación
            for (int k = 1; k < n - 1; k++) {
                Row r = rows.get(idx.get(k));
                double a = ang(r.ang);
                if (!ok(a)) continue;
                float back = (float) Math.toDegrees(Math.atan2(ys[k - 1] - ys[k], xs[k - 1] - xs[k]));
                angleArc(cv, xs[k], ys[k], back, (float) a, 20 * d, red, shortAngle(a));
            }

            // Distancias en verde
            for (int k = 1; k < n; k++) {
                Row r = rows.get(idx.get(k));
                double dd = num(r.dist);
                if (!ok(dd)) continue;
                float mx = (xs[k - 1] + xs[k]) / 2f, my = (ys[k - 1] + ys[k]) / 2f;
                float dx = xs[k] - xs[k - 1], dy = ys[k] - ys[k - 1];
                float len = (float) Math.hypot(dx, dy);
                if (len < 1) continue;
                float nx = dy / len, ny = -dx / len; // normal a la izquierda del avance
                text(cv, trimNum(dd), mx + nx * 15 * d, my + ny * 15 * d + 4 * d, 12.5f, green, true, Paint.Align.CENTER);
            }

            // Puntos
            for (int k = 0; k < n; k++) {
                Row r = rows.get(idx.get(k));
                if (isBm(r)) triangle(cv, xs[k], ys[k], 8 * d);
                else station(cv, xs[k], ys[k], 6.5f * d);
                float lx = xs[k], ly;
                // etiqueta al lado contrario de la llegada
                float dx = k > 0 ? xs[k] - xs[k - 1] : (n > 1 ? xs[1] - xs[0] : 1);
                float dy = k > 0 ? ys[k] - ys[k - 1] : (n > 1 ? ys[1] - ys[0] : 0);
                float len = (float) Math.max(1, Math.hypot(dx, dy));
                float nx = -dy / len, ny = dx / len; // normal a la derecha
                lx += nx * 20 * d;
                ly = ys[k] + ny * 20 * d + 5 * d;
                text(cv, r.name.isEmpty() ? "P" + (idx.get(k) + 1) : r.name, lx, ly, 13.5f, ink, true, Paint.Align.CENTER);
            }
            cv.restore();

            drawCornerNorth(cv, W);
            scaleBar(cv, W, H, pxPerM);
            if (first != null) {
                text(cv, "Planta · E/N en metros", 12 * d, H - 12 * d, 10.5f, inkSoft, false, Paint.Align.LEFT);
            }
            border(cv, W, H);
        }

        private String trimNum(double v) {
            if (Math.abs(v - Math.rint(v)) < 1e-9) return String.valueOf((long) Math.rint(v));
            return f2(v);
        }

        private void drawGrid(Canvas cv, float W, float H, double cE, double cN, double pxPerM,
                              float ox, float oy, double gridM) {
            float step = (float) (gridM * pxPerM);
            if (step < 6 * d) step = 24 * d;
            p.setShader(null);
            p.setPathEffect(null);
            p.setStyle(Paint.Style.STROKE);
            int minor = light ? Color.rgb(226, 234, 244) : Color.argb(52, 90, 150, 215);
            int major = light ? Color.rgb(200, 214, 232) : Color.argb(92, 90, 150, 215);
            // origen de la cuadrícula alineado a múltiplos de gridM
            double e0 = Math.floor(cE / gridM) * gridM, n0 = Math.floor(cN / gridM) * gridM;
            float gx = (float) (ox + (e0 - cE) * pxPerM);
            float gy = (float) (oy - (n0 - cN) * pxPerM);
            long ie = Math.round(e0 / gridM), in = Math.round(n0 / gridM);
            int kx0 = (int) Math.floor(-gx / step) - 1, kx1 = (int) Math.ceil((W - gx) / step) + 1;
            for (int k = kx0; k <= kx1; k++) {
                float x = gx + k * step;
                boolean mj = ((ie + k) % 5 + 5) % 5 == 0;
                p.setColor(mj ? major : minor);
                p.setStrokeWidth(mj ? 1.1f * d : 0.7f * d);
                cv.drawLine(x, 0, x, H, p);
            }
            int ky0 = (int) Math.floor((gy - H) / step) - 1, ky1 = (int) Math.ceil(gy / step) + 1;
            for (int k = ky0; k <= ky1; k++) {
                float y = gy - k * step;
                boolean mj = ((in + k) % 5 + 5) % 5 == 0;
                p.setColor(mj ? major : minor);
                p.setStrokeWidth(mj ? 1.1f * d : 0.7f * d);
                cv.drawLine(0, y, W, y, p);
            }
        }

        private void drawGallery(Canvas cv, ArrayList<float[]> axis, float half, boolean portal) {
            int m = axis.size();
            if (m < 2) return;
            ArrayList<float[]> left = new ArrayList<>(), right = new ArrayList<>();
            int seed = 7;
            for (int i = 0; i < m - 1; i++) {
                float[] a = axis.get(i), b = axis.get(i + 1);
                float dx = b[0] - a[0], dy = b[1] - a[1];
                float len = (float) Math.hypot(dx, dy);
                if (len < 0.5f) continue;
                float ux = dx / len, uy = dy / len, nx = -uy, ny = ux;
                int steps = Math.max(2, (int) (len / (9 * d)));
                for (int s = (i == 0 ? 0 : 1); s <= steps; s++) {
                    float tt = s / (float) steps;
                    float x = a[0] + dx * tt, y = a[1] + dy * tt;
                    seed = seed * 1103515245 + 12345;
                    float j1 = (((seed >>> 16) & 0xff) / 255f - .5f) * 2.6f * d;
                    seed = seed * 1103515245 + 12345;
                    float j2 = (((seed >>> 16) & 0xff) / 255f - .5f) * 2.6f * d;
                    left.add(new float[]{x + nx * (half + j1), y + ny * (half + j1)});
                    right.add(new float[]{x - nx * (half + j2), y - ny * (half + j2)});
                }
            }
            if (left.size() < 2) return;
            // Frente de avance redondeado al final
            float[] a = axis.get(m - 2), b = axis.get(m - 1);
            float dx = b[0] - a[0], dy = b[1] - a[1];
            float len = (float) Math.max(1, Math.hypot(dx, dy));
            float ux = dx / len, uy = dy / len;
            float ex = b[0] + ux * half * 1.15f, ey = b[1] + uy * half * 1.15f;

            path.reset();
            for (int i = 0; i < left.size(); i++) {
                float[] q = left.get(i);
                if (i == 0) path.moveTo(q[0], q[1]); else path.lineTo(q[0], q[1]);
            }
            float[] lEnd = left.get(left.size() - 1), rEnd = right.get(right.size() - 1);
            path.quadTo(ex + (lEnd[0] - b[0]) * .6f, ey + (lEnd[1] - b[1]) * .6f, ex, ey);
            path.quadTo(ex + (rEnd[0] - b[0]) * .6f, ey + (rEnd[1] - b[1]) * .6f, rEnd[0], rEnd[1]);
            for (int i = right.size() - 1; i >= 0; i--) path.lineTo(right.get(i)[0], right.get(i)[1]);
            path.close();
            p.setStyle(Paint.Style.FILL);
            p.setColor(withAlpha(rock, light ? 40 : 46));
            cv.drawPath(path, p);

            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.2f * d);
            p.setColor(rock);
            Path wall = new Path();
            for (int i = 0; i < left.size(); i++) {
                float[] q = left.get(i);
                if (i == 0) wall.moveTo(q[0], q[1]); else wall.lineTo(q[0], q[1]);
            }
            wall.quadTo(ex + (lEnd[0] - b[0]) * .6f, ey + (lEnd[1] - b[1]) * .6f, ex, ey);
            wall.quadTo(ex + (rEnd[0] - b[0]) * .6f, ey + (rEnd[1] - b[1]) * .6f, rEnd[0], rEnd[1]);
            for (int i = right.size() - 1; i >= 0; i--) wall.lineTo(right.get(i)[0], right.get(i)[1]);
            cv.drawPath(wall, p);

            if (portal) {
                float[] l0 = left.get(0), r0 = right.get(0);
                line(cv, l0[0], l0[1], r0[0], r0[1], rock, 3f, false);
                float[] a0 = axis.get(0), a1 = axis.get(1);
                float ddx = a1[0] - a0[0], ddy = a1[1] - a0[1];
                float l = (float) Math.max(1, Math.hypot(ddx, ddy));
                text(cv, "Bocamina", a0[0] - ddy / l * (half + 14 * d), a0[1] + ddx / l * (half + 14 * d) + 4 * d,
                        10.5f, rock, true, Paint.Align.CENTER);
            }
        }

        private void angleArc(Canvas cv, float x, float y, float startDeg, float sweep, float r, int color, String label) {
            p.setShader(null);
            p.setPathEffect(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.8f * d);
            p.setColor(color);
            RectF o = new RectF(x - r, y - r, x + r, y + r);
            cv.drawArc(o, startDeg, sweep, false, p);
            float end = (float) Math.toRadians(startDeg + sweep);
            float ex = x + (float) Math.cos(end) * r, ey = y + (float) Math.sin(end) * r;
            arrowHead(cv, ex, ey, startDeg + sweep + 90f, color);
            float mid = (float) Math.toRadians(startDeg + sweep / 2f);
            float lr = r + 17 * d;
            text(cv, label, x + (float) Math.cos(mid) * lr, y + (float) Math.sin(mid) * lr + 4 * d,
                    11.5f, color, true, Paint.Align.CENTER);
        }

        private void arrowHead(Canvas cv, float x, float y, float dirDeg, int color) {
            float a = (float) Math.toRadians(dirDeg);
            float s = 6.5f * d;
            float bx = x - (float) Math.cos(a) * s, by = y - (float) Math.sin(a) * s;
            float px = -(float) Math.sin(a) * s * .55f, py = (float) Math.cos(a) * s * .55f;
            Path h = new Path();
            h.moveTo(x, y);
            h.lineTo(bx + px, by + py);
            h.lineTo(bx - px, by - py);
            h.close();
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            cv.drawPath(h, p);
        }

        private void triangle(Canvas cv, float x, float y, float s) {
            Path tri = new Path();
            tri.moveTo(x, y - s);
            tri.lineTo(x + s * .9f, y + s * .62f);
            tri.lineTo(x - s * .9f, y + s * .62f);
            tri.close();
            p.setPathEffect(null);
            p.setStyle(Paint.Style.FILL);
            p.setColor(light ? Color.WHITE : Color.rgb(4, 18, 32));
            cv.drawPath(tri, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.2f * d);
            p.setColor(borderColor);
            cv.drawPath(tri, p);
            p.setStyle(Paint.Style.FILL);
            cv.drawCircle(x, y, 1.8f * d, p);
        }

        private void station(Canvas cv, float x, float y, float r) {
            p.setPathEffect(null);
            p.setStyle(Paint.Style.FILL);
            p.setColor(light ? Color.WHITE : Color.rgb(4, 18, 32));
            cv.drawCircle(x, y, r, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.2f * d);
            p.setColor(ink);
            cv.drawCircle(x, y, r, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(borderColor);
            cv.drawCircle(x, y, r * .38f, p);
        }

        private void drawCornerNorth(Canvas cv, float W) {
            float cx = W - 26 * d, cy = 34 * d;
            p.setStyle(Paint.Style.FILL);
            p.setColor(light ? Color.argb(230, 255, 255, 255) : Color.argb(220, 6, 22, 38));
            cv.drawCircle(cx, cy, 17 * d, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(d);
            p.setColor(withAlpha(borderColor, 150));
            cv.drawCircle(cx, cy, 17 * d, p);
            Path nArrow = new Path();
            nArrow.moveTo(cx, cy - 12 * d);
            nArrow.lineTo(cx + 5 * d, cy + 6 * d);
            nArrow.lineTo(cx, cy + 2.5f * d);
            nArrow.lineTo(cx - 5 * d, cy + 6 * d);
            nArrow.close();
            p.setStyle(Paint.Style.FILL);
            p.setColor(red);
            cv.drawPath(nArrow, p);
            text(cv, "N", cx, cy - 19 * d, 11, ink, true, Paint.Align.CENTER);
        }

        private void scaleBar(Canvas cv, float W, float H, double pxPerM) {
            double m = niceStep(80 * d / pxPerM);
            float len = (float) (m * pxPerM);
            float x1 = W - 16 * d - len, y = H - 16 * d;
            line(cv, x1, y, x1 + len, y, ink, 2f, false);
            line(cv, x1, y - 4 * d, x1, y + 2 * d, ink, 2f, false);
            line(cv, x1 + len, y - 4 * d, x1 + len, y + 2 * d, ink, 2f, false);
            text(cv, meters(m), x1 + len / 2f, y - 7 * d, 10.5f, ink, true, Paint.Align.CENTER);
        }
    }

    // ------------------------------------------------------------------ perfil longitudinal

    private class ProfileView extends ZoomCanvas {
        ProfileView(Context c) { super(c); }

        private float X(double chain, double c0, double sx, float left) {
            return zx((float) (left + (chain - c0) * sx));
        }

        private float Y(double z, double z0, double sy, float bottom) {
            return zy((float) (bottom - (z - z0) * sy));
        }

        @Override protected void onDraw(Canvas cv) {
            float W = getWidth(), H = getHeight();
            if (W <= 0 || H <= 0) return;
            paper(cv, W, H);
            int n = rows.size();
            int portal = portalIndex();

            // Altura de labor solo para dibujar: se adapta a las lecturas de mira.
            double maxRead = 0;
            for (int i = 0; i < n; i++) {
                if (portal != -1 && i >= portal) {
                    double va = num(rows.get(i).va), vad = num(rows.get(i).vad);
                    if (ok(va)) maxRead = Math.max(maxRead, Math.abs(va));
                    if (ok(vad)) maxRead = Math.max(maxRead, Math.abs(vad));
                }
            }
            final double G = maxRead > 0 ? Math.max(0.9, maxRead * 1.6) : 1.5;
            // Piso y techo de cada punto (o terreno para BM de superficie)
            double[] floor = new double[n], roof = new double[n];
            boolean[] surface = new boolean[n];
            double zMin = Double.MAX_VALUE, zMax = -Double.MAX_VALUE;
            int valid = 0;
            for (int i = 0; i < n; i++) {
                Row r = rows.get(i);
                surface[i] = portal == -1 || i < portal;
                floor[i] = Double.NaN; roof[i] = Double.NaN;
                if (!ok(r.cotaC)) continue;
                valid++;
                if (surface[i]) { floor[i] = r.cotaC; roof[i] = Double.NaN; }
                else if (r.roof) { roof[i] = r.cotaC; floor[i] = r.cotaC - G; }
                else { floor[i] = r.cotaC; roof[i] = r.cotaC + G; }
                zMin = Math.min(zMin, floor[i]);
                zMax = Math.max(zMax, ok(roof[i]) ? roof[i] : floor[i]);
                if (ok(r.aiC)) zMax = Math.max(zMax, r.aiC);
            }
            if (valid < 2) {
                cv.save();
                path.reset();
                path.addRoundRect(new RectF(0, 0, W, H), 14 * d, 14 * d, Path.Direction.CW);
                cv.clipPath(path);
                gridOnly(cv, W, H);
                cv.restore();
                empty(cv, W, H, "Completa la libreta para ver el perfil");
                border(cv, W, H);
                return;
            }
            // Las miras sobresalen un poco de la visual
            for (int i = 0; i < n; i++) {
                Row r = rows.get(i);
                if (ok(r.aiC)) zMax = Math.max(zMax, r.aiC + 0.25);
            }
            double maxChain = 0;
            for (int i = 0; i < n; i++) if (ok(rows.get(i).cotaC) && ok(rows.get(i).chain)) maxChain = Math.max(maxChain, rows.get(i).chain);
            if (maxChain <= 0) maxChain = 1;
            float left = 84 * d, right = W - 34 * d, top = 40 * d, bottom = H - 62 * d;
            double zr = Math.max(zMax - zMin, 0.5);
            zMin -= zr * 0.10;
            zMax += zr * 0.12;
            double sx = (right - left) / maxChain;
            double sy = (bottom - top) / (zMax - zMin);
            final double z0 = zMin;

            cv.save();
            path.reset();
            path.addRoundRect(new RectF(0, 0, W, H), 14 * d, 14 * d, Path.Direction.CW);
            cv.clipPath(path);

            // Cuadrícula de cotas
            double stepZ = niceStep((zMax - zMin) / 5.0);
            p.setStyle(Paint.Style.STROKE);
            p.setPathEffect(null);
            for (double z = Math.ceil(zMin / stepZ) * stepZ; z <= zMax; z += stepZ) {
                float y = Y(z, z0, sy, bottom);
                p.setColor(light ? Color.rgb(226, 234, 244) : Color.argb(55, 90, 150, 215));
                p.setStrokeWidth(0.8f * d);
                cv.drawLine(0, y, W, y, p);
            }
            for (int i = 0; i < n; i++) {
                if (!ok(rows.get(i).cotaC)) continue;
                float x = X(rows.get(i).chain, 0, sx, left);
                p.setColor(light ? Color.rgb(232, 238, 246) : Color.argb(40, 90, 150, 215));
                p.setStrokeWidth(0.8f * d);
                cv.drawLine(x, 0, x, H, p);
            }

            // Terreno de superficie
            Path ground = new Path();
            boolean gStarted = false;
            float lastGx = 0, lastGy = 0;
            for (int i = 0; i < n; i++) {
                if (!surface[i] || !ok(floor[i])) continue;
                float x = X(rows.get(i).chain, 0, sx, left), y = Y(floor[i], z0, sy, bottom);
                if (!gStarted) { ground.moveTo(x - 30 * d, y); ground.lineTo(x, y); gStarted = true; }
                else ground.lineTo(x, y);
                lastGx = x; lastGy = y;
            }
            // Bocamina: entre el último BM y el primer punto de la labor
            int firstIn = -1;
            for (int i = 0; i < n; i++) if (!surface[i] && ok(floor[i])) { firstIn = i; break; }
            float portalX = Float.NaN;
            if (gStarted) {
                if (firstIn > 0) {
                    float fx = X(rows.get(firstIn).chain, 0, sx, left);
                    portalX = lastGx + (fx - lastGx) * 0.45f;
                    ground.lineTo(portalX, lastGy);
                } else {
                    ground.lineTo(lastGx + 30 * d, lastGy);
                }
                Path fill = new Path(ground);
                fill.lineTo(gStarted ? (Float.isNaN(portalX) ? lastGx + 30 * d : portalX) : 0, H + 10 * d);
                fill.lineTo(-40 * d, H + 10 * d);
                fill.close();
                p.setStyle(Paint.Style.FILL);
                p.setColor(withAlpha(rock, light ? 34 : 40));
                cv.drawPath(fill, p);
                hatch(cv, fill);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2.2f * d);
                p.setColor(rock);
                cv.drawPath(ground, p);
            }

            // Labor: piso y techo
            if (firstIn >= 0) {
                ArrayList<float[]> fl = new ArrayList<>(), rf = new ArrayList<>();
                if (!Float.isNaN(portalX)) {
                    double fz = floor[firstIn];
                    fl.add(new float[]{portalX, Y(fz, z0, sy, bottom)});
                    rf.add(new float[]{portalX, Y(fz + G, z0, sy, bottom)});
                }
                float lastX = 0;
                for (int i = firstIn; i < n; i++) {
                    if (surface[i] || !ok(floor[i])) continue;
                    float x = X(rows.get(i).chain, 0, sx, left);
                    fl.add(new float[]{x, Y(floor[i], z0, sy, bottom)});
                    rf.add(new float[]{x, Y(roof[i], z0, sy, bottom)});
                    lastX = x;
                }
                if (fl.size() >= 1) {
                    float[] lf = fl.get(fl.size() - 1), lr = rf.get(rf.size() - 1);
                    fl.add(new float[]{lastX + 22 * d, lf[1]});
                    rf.add(new float[]{lastX + 22 * d, lr[1]});
                    // roca sobre el techo y bajo el piso
                    Path above = new Path();
                    above.moveTo(rf.get(0)[0], -20 * d);
                    for (float[] q : rf) above.lineTo(q[0], q[1]);
                    above.lineTo(rf.get(rf.size() - 1)[0], -20 * d);
                    above.close();
                    Path below = new Path();
                    below.moveTo(fl.get(0)[0], H + 20 * d);
                    for (float[] q : fl) below.lineTo(q[0], q[1]);
                    below.lineTo(fl.get(fl.size() - 1)[0], H + 20 * d);
                    below.close();
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(withAlpha(rock, light ? 34 : 40));
                    cv.drawPath(above, p);
                    cv.drawPath(below, p);
                    hatch(cv, above);
                    hatch(cv, below);
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2.2f * d);
                    p.setColor(rock);
                    Path a = new Path(), b = new Path();
                    for (int k = 0; k < fl.size(); k++) {
                        if (k == 0) { a.moveTo(fl.get(k)[0], fl.get(k)[1]); b.moveTo(rf.get(k)[0], rf.get(k)[1]); }
                        else { a.lineTo(fl.get(k)[0], fl.get(k)[1]); b.lineTo(rf.get(k)[0], rf.get(k)[1]); }
                    }
                    cv.drawPath(a, p);
                    cv.drawPath(b, p);
                    // frente de la labor
                    line(cv, fl.get(fl.size() - 1)[0], fl.get(fl.size() - 1)[1],
                            rf.get(rf.size() - 1)[0], rf.get(rf.size() - 1)[1], rock, 2.2f, false);
                    if (!Float.isNaN(portalX)) {
                        line(cv, portalX, fl.get(0)[1], portalX, rf.get(0)[1], rock, 3f, false);
                        text(cv, "Bocamina", portalX - 6 * d, rf.get(0)[1] + 4 * d, 10.5f, rock, true, Paint.Align.RIGHT);
                    }
                }
            }

            // Estaciones: visual, instrumento y miras
            float staffW = 7 * d;
            for (int i = 0; i < n; i++) {
                Row b = rows.get(i);
                if (!ok(b.aiC)) continue;
                int end = i;
                for (int j = i + 1; j < n; j++) {
                    if (ok(num(rows.get(j).vad))) end = j;
                    if (ok(num(rows.get(j).va))) break;
                }
                if (end == i) continue;
                float xb = X(b.chain, 0, sx, left), xe = X(rows.get(end).chain, 0, sx, left);
                float yAi = Y(b.aiC, z0, sy, bottom);
                line(cv, xb, yAi, xe, yAi, borderColor, 1.6f, true);
                // instrumento a media distancia
                float xi = (xb + xe) / 2f;
                double groundAt = interpFloor(floor, surface, i, end, (b.chain + rows.get(end).chain) / 2d);
                level(cv, xi, yAi, ok(groundAt) ? Y(groundAt, z0, sy, bottom) : yAi + 40 * d);
                String aiText = f3(b.aiC);
                t.setTextSize(10.5f * d);
                t.setTypeface(Typeface.DEFAULT_BOLD);
                float room = Math.abs(xe - xb) - staffW - 70 * d;
                if (t.measureText(aiText) < room) {
                    text(cv, aiText, xi, yAi - 12 * d, 10.5f, borderColor, true, Paint.Align.CENTER);
                }
                // vista atrás
                staff(cv, xb, b, b.aiC, z0, sy, bottom, staffW);
                text(cv, f3(num(b.va)), xb + staffW / 2f + 4 * d, yAi - 6 * d, 11, ink, true, Paint.Align.LEFT);
                // vistas adelante
                for (int j = i + 1; j <= end; j++) {
                    Row f = rows.get(j);
                    double vad = num(f.vad);
                    if (!ok(vad) || !ok(f.cotaC)) continue;
                    float xf = X(f.chain, 0, sx, left);
                    staff(cv, xf, f, b.aiC, z0, sy, bottom, staffW);
                    text(cv, f3(vad), xf - staffW / 2f - 4 * d, yAi + 15 * d, 11, ink, true, Paint.Align.RIGHT);
                }
            }

            // Nombres y cotas
            for (int i = 0; i < n; i++) {
                Row r = rows.get(i);
                if (!ok(r.cotaC)) continue;
                float x = X(r.chain, 0, sx, left);
                float y = Y(r.cotaC, z0, sy, bottom);
                p.setStyle(Paint.Style.FILL);
                p.setColor(r.roof && !surface[i] ? amber : green);
                cv.drawCircle(x, y, 3.6f * d, p);
                String nm = r.name.isEmpty() ? "P" + (i + 1) : r.name;
                if (r.roof && !surface[i]) {
                    text(cv, nm, x, y - 10 * d, 13, ink, true, Paint.Align.CENTER);
                    text(cv, f3(r.cotaC), x, y - 24 * d, 11, amber, true, Paint.Align.CENTER);
                } else {
                    text(cv, nm, x, y + 17 * d, 13, ink, true, Paint.Align.CENTER);
                    text(cv, f3(r.cotaC), x, y + 30 * d, 11, green, true, Paint.Align.CENTER);
                }
            }

            // Distancias horizontales abajo
            Row prev = null;
            for (int i = 0; i < n; i++) {
                Row r = rows.get(i);
                if (!ok(r.cotaC)) continue;
                if (prev != null) {
                    double dd = num(r.dist);
                    float xm = (X(prev.chain, 0, sx, left) + X(r.chain, 0, sx, left)) / 2f;
                    if (ok(dd)) text(cv, meters(dd), xm, H - 14 * d, 11, green, true, Paint.Align.CENTER);
                }
                prev = r;
            }
            cv.restore();

            // Eje de cotas (fijo a la izquierda)
            p.setStyle(Paint.Style.FILL);
            p.setColor(light ? Color.argb(235, 253, 254, 255) : Color.argb(235, 4, 18, 32));
            cv.drawRect(0, 0, 52 * d, H, p);
            for (double z = Math.ceil(zMin / stepZ) * stepZ; z <= zMax; z += stepZ) {
                float y = Y(z, z0, sy, bottom);
                if (y < 12 * d || y > H - 8 * d) continue;
                text(cv, stepZ >= 1 ? String.valueOf((long) Math.rint(z)) : f1(z), 46 * d, y + 4 * d,
                        10, inkSoft, false, Paint.Align.RIGHT);
            }
            line(cv, 52 * d, 0, 52 * d, H, withAlpha(borderColor, 120), 1f, false);
            text(cv, "Cota", 26 * d, 18 * d, 10.5f, inkSoft, true, Paint.Align.CENTER);
            text(cv, "Esc. vertical exagerada", W - 12 * d, 18 * d, 10, inkSoft, false, Paint.Align.RIGHT);
            border(cv, W, H);
        }

        private double interpFloor(double[] floor, boolean[] surface, int a, int b, double chain) {
            double fa = floor[a], fb = floor[b];
            if (!ok(fa)) return fb;
            if (!ok(fb)) return fa;
            double ca = rows.get(a).chain, cb = rows.get(b).chain;
            if (Math.abs(cb - ca) < 1e-9) return fa;
            double t = (chain - ca) / (cb - ca);
            return fa + (fb - fa) * t;
        }

        private void gridOnly(Canvas cv, float W, float H) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(0.8f * d);
            p.setColor(light ? Color.rgb(226, 234, 244) : Color.argb(52, 90, 150, 215));
            for (float x = 0; x < W; x += 24 * d) cv.drawLine(x, 0, x, H, p);
            for (float y = 0; y < H; y += 24 * d) cv.drawLine(0, y, W, y, p);
        }

        private void hatch(Canvas cv, Path area) {
            cv.save();
            cv.clipPath(area);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(0.9f * d);
            p.setColor(withAlpha(rock, light ? 70 : 60));
            float W = getWidth(), H = getHeight();
            for (float x = -H; x < W + H; x += 11 * d) cv.drawLine(x, H + 20 * d, x + H + 40 * d, -20 * d, p);
            cv.restore();
        }

        /** Mira graduada: parada en el piso o colgando del techo, hasta pasar la visual. */
        private void staff(Canvas cv, float x, Row r, double ai, double z0, double sy, float bottom, float w) {
            boolean hang = r.roof;
            double zBase = r.cotaC;
            double zTip = hang ? Math.min(ai - 0.18, zBase - 0.25) : Math.max(ai + 0.18, zBase + 0.25);
            float y1 = Y(zBase, z0, sy, bottom), y2 = Y(zTip, z0, sy, bottom);
            float top = Math.min(y1, y2), bot = Math.max(y1, y2);
            float left = x - w / 2f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(246, 248, 250));
            cv.drawRect(left, top, left + w, bot, p);
            double len = Math.abs(zTip - zBase);
            double step = 0.1;
            while (step * sy * zoom < 3.2 * d && step < 10) step *= 5;
            int k = 0;
            for (double s = 0; s < len; s += step, k++) {
                float ya = Y(hang ? zBase - s : zBase + s, z0, sy, bottom);
                float yb = Y(hang ? zBase - Math.min(len, s + step / 2) : zBase + Math.min(len, s + step / 2), z0, sy, bottom);
                p.setColor((k / 5) % 2 == 0 ? Color.rgb(215, 40, 48) : Color.rgb(24, 34, 48));
                cv.drawRect(left, Math.min(ya, yb), left + w * (k % 5 == 0 ? 1f : .55f), Math.max(ya, yb), p);
            }
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1f * d);
            p.setColor(hang ? amber : Color.rgb(120, 150, 180));
            cv.drawRect(left, top, left + w, bot, p);
        }

        /** Nivel en trípode, con el anteojo a la altura de la visual. */
        private void level(Canvas cv, float x, float y, float groundY) {
            float bw = 22 * d, bh = 8 * d;
            float baseY = y + bh / 2f + 4 * d;
            float footY = Math.max(baseY + 14 * d, groundY);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.6f * d);
            p.setColor(inkSoft);
            cv.drawLine(x, baseY, x - 13 * d, footY, p);
            cv.drawLine(x, baseY, x, footY, p);
            cv.drawLine(x, baseY, x + 13 * d, footY, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(borderColor);
            cv.drawRoundRect(new RectF(x - bw / 2f, y - bh / 2f, x + bw / 2f, y + bh / 2f), 3 * d, 3 * d, p);
            p.setColor(light ? Color.rgb(30, 60, 100) : Color.rgb(160, 205, 255));
            cv.drawRect(x - 3 * d, y + bh / 2f, x + 3 * d, baseY, p);
            cv.drawCircle(x + bw / 2f, y, 2.4f * d, p);
        }
    }
}
