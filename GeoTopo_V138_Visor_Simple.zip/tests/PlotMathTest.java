import com.bph.geotopo.PlotMath;
import com.bph.geotopo.PlotMath.PlotPoint;

import java.util.ArrayList;
import java.util.List;

/** Pruebas sin Internet del Visor de coordenadas (lectura de Excel, líneas, medidas, 3D y DXF). */
public final class PlotMathTest {
    private static int checks;

    private static void eq(double actual, double expected, double tol) {
        checks++;
        if (Math.abs(actual - expected) > tol) throw new AssertionError(actual + " != " + expected);
    }
    private static void eq(String actual, String expected) {
        checks++;
        if (!actual.equals(expected)) throw new AssertionError("'" + actual + "' != '" + expected + "'");
    }
    private static void yes(boolean v, String msg) {
        checks++;
        if (!v) throw new AssertionError(msg);
    }

    public static void main(String[] args) {
        // Números con punto, coma, miles.
        eq(PlotMath.parseNumber("8654321.125"), 8654321.125, 1e-9);
        eq(PlotMath.parseNumber("8654321,125"), 8654321.125, 1e-9);
        eq(PlotMath.parseNumber("8,654,321.125"), 8654321.125, 1e-9);
        eq(PlotMath.parseNumber("8.654.321,125"), 8654321.125, 1e-9);
        eq(PlotMath.parseNumber("-12.5"), -12.5, 1e-9);
        eq(PlotMath.parseNumber("3500 m"), 3500, 1e-9);
        yes(Double.isNaN(PlotMath.parseNumber("P1")), "texto no es número");
        yes(Double.isNaN(PlotMath.parseNumber("")), "vacío no es número");

        // Excel con encabezado (tabulaciones), coma decimal y cota vacía.
        String excel = "Punto\tEste\tNorte\tCota\tDescripción\n"
                + "BM-1\t345678,120\t8654321,450\t3500,250\tbm\n"
                + "P2\t345690.5\t8654330.0\t\tgaleria\n"
                + "\n"
                + "P3\t345700\t8654340\t3498.1\tgaleria\n";
        PlotMath.ParseResult r = PlotMath.parse(excel, PlotMath.ORDER_AUTO, 1);
        yes(r.headerFound, "encabezado");
        eq(r.points.size(), 3, 0);
        eq(r.ignored, 0, 0);
        eq(r.points.get(0).name, "BM-1");
        eq(r.points.get(0).east, 345678.12, 1e-9);
        eq(r.points.get(0).north, 8654321.45, 1e-9);
        eq(r.points.get(0).z, 3500.25, 1e-9);
        yes(!r.points.get(1).hasZ, "P2 sin cota");
        eq(r.points.get(1).desc, "galeria");
        yes(r.points.get(2).breakBefore, "fila vacía = línea nueva");

        // Encabezado en otro orden: Norte antes que Este.
        r = PlotMath.parse("N°\tNorte\tEste\tCota\n1\t8654321\t345678\t3500\n", PlotMath.ORDER_AUTO, 1);
        eq(r.points.get(0).east, 345678, 1e-9);
        eq(r.points.get(0).north, 8654321, 1e-9);
        eq(r.points.get(0).name, "1");

        // Sin encabezado: Norte grande primero se detecta solo.
        r = PlotMath.parse("8654321.1 345678.2 3500\n8654330 345690 3501\n", PlotMath.ORDER_AUTO, 10);
        eq(r.points.get(0).east, 345678.2, 1e-9);
        eq(r.points.get(0).north, 8654321.1, 1e-9);
        eq(r.points.get(0).name, "10");
        eq(r.points.get(1).name, "11");

        // P,E,N,Z numéricos y descripción con espacios.
        r = PlotMath.parse("1 500.0 1000.0 100.0 eje de rampa\n2 510 1010 99\n", PlotMath.ORDER_AUTO, 1);
        eq(r.points.get(0).name, "1");
        eq(r.points.get(0).east, 500, 1e-9);
        eq(r.points.get(0).z, 100, 1e-9);
        eq(r.points.get(0).desc, "eje de rampa");

        // CSV con comas y puntos.
        r = PlotMath.parse("P1,100.5,200.5,10\nP2,110,210,11\n", PlotMath.ORDER_AUTO, 1);
        eq(r.points.size(), 2, 0);
        eq(r.points.get(1).north, 210, 1e-9);

        // Punto y coma con coma decimal; título antes de los datos.
        r = PlotMath.parse("LEVANTAMIENTO NV 3400\nP1;100,5;200,5;10,25\n", PlotMath.ORDER_AUTO, 1);
        eq(r.points.size(), 1, 0);
        eq(r.points.get(0).z, 10.25, 1e-9);

        // Orden manual P,N,E y fila mala.
        r = PlotMath.parse("A\t200\t100\t5\nB\tx\t100\t5\n", PlotMath.ORDER_PNEZD, 1);
        eq(r.points.size(), 1, 0);
        eq(r.points.get(0).east, 100, 1e-9);
        eq(r.ignored, 1, 0);

        // Sin límite: 20 000 filas.
        StringBuilder big = new StringBuilder();
        for (int i = 0; i < 20000; i++) big.append("P").append(i).append('\t').append(1000 + i).append('\t').append(2000 + i).append('\t').append(i % 50).append('\n');
        r = PlotMath.parse(big.toString(), PlotMath.ORDER_AUTO, 1);
        eq(r.points.size(), 20000, 0);

        // Medidas.
        PlotPoint a = new PlotPoint("A", 0, 0, 100, true, "", false);
        PlotPoint b = new PlotPoint("B", 100, -100, 90, true, "", false);
        eq(PlotMath.horizontal(a, b), Math.sqrt(20000), 1e-9);
        eq(PlotMath.azimuth(a, b), 135, 1e-9);
        eq(PlotMath.bearing(135), "S 45°00'00\" E");
        eq(PlotMath.bearing(300), "N 60°00'00\" O");

        // Área de un cuadrado 100 x 100 con coordenadas UTM grandes.
        List<PlotPoint> sq = new ArrayList<>();
        sq.add(new PlotPoint("1", 345000, 8650000, 0, false, "", false));
        sq.add(new PlotPoint("2", 345100, 8650000, 0, false, "", false));
        sq.add(new PlotPoint("3", 345100, 8650100, 0, false, "", false));
        sq.add(new PlotPoint("4", 345000, 8650100, 0, false, "", false));
        eq(PlotMath.area(sq, new int[]{0, 1, 2, 3}), 10000, 1e-6);
        eq(PlotMath.length(sq, new int[]{0, 1, 2, 3}, true), 400, 1e-9);

        // Líneas en orden con corte, y por código.
        List<PlotPoint> pts = new ArrayList<>();
        pts.add(new PlotPoint("1", 0, 0, 0, false, "gal", false));
        pts.add(new PlotPoint("2", 1, 0, 0, false, "rampa", false));
        pts.add(new PlotPoint("3", 2, 0, 0, false, "gal", false));
        pts.add(new PlotPoint("4", 3, 0, 0, false, "rampa", true));
        pts.add(new PlotPoint("5", 4, 0, 0, false, "gal", false));
        List<PlotMath.Run> runs = PlotMath.buildRuns(pts, PlotMath.LINES_ORDER, false);
        eq(runs.size(), 2, 0);
        eq(runs.get(0).idx.length, 3, 0);
        runs = PlotMath.buildRuns(pts, PlotMath.LINES_CODE, false);
        // gal: 1-3-5 ; rampa: 2 sola y 4 sola (corte) → no forman línea
        eq(runs.size(), 1, 0);
        eq(runs.get(0).idx.length, 3, 0);
        eq(runs.get(0).code, "gal");
        runs = PlotMath.buildRuns(pts, PlotMath.LINES_ORDER, true);
        yes(runs.get(0).closed, "cerrada");

        // Polígono que repite el primer punto al final = cerrado.
        List<PlotPoint> rect = new ArrayList<>(sq);
        rect.add(sq.get(0).copy());
        List<PlotMath.Run> rr = PlotMath.buildRuns(rect, PlotMath.LINES_ORDER, false);
        yes(PlotMath.isLoop(rect, rr.get(0)), "rectángulo con P1 repetido es polígono");
        eq(PlotMath.area(rect, rr.get(0).idx), 10000, 1e-6);
        yes(!PlotMath.isLoop(pts, PlotMath.buildRuns(pts, PlotMath.LINES_ORDER, false).get(0)), "línea abierta");

        // 3D: planta, frente, isométrico.
        double[] o = new double[3];
        PlotMath.project(10, 20, 5, 0, Math.toRadians(90), o);
        eq(o[0], 10, 1e-9); eq(o[1], 20, 1e-9);
        PlotMath.project(10, 20, 5, 0, 0, o);
        eq(o[0], 10, 1e-9); eq(o[1], 5, 1e-9); eq(o[2], 20, 1e-9);
        PlotMath.project(1, 1, 0, Math.toRadians(-45), Math.toRadians(35.264), o);
        yes(o[0] > 1.4, "isométrico SE: Este y Norte van a la derecha");

        // Orden por profundidad.
        double[] key = {3, 9, 1, 7, 5};
        int[] idx = {0, 1, 2, 3, 4};
        PlotMath.sortDesc(idx, key, 5);
        eq(idx[0], 1, 0); eq(idx[1], 3, 0); eq(idx[4], 2, 0);

        // Cuadrícula y nombres.
        eq(PlotMath.niceStep(37), 50, 1e-9);
        eq(PlotMath.niceStep(0.13), 0.1, 1e-12);
        eq(PlotMath.niceStep(240), 200, 1e-9);
        eq(PlotMath.decimalsFor(0.05), 2, 0);
        eq(PlotMath.nextName("P9"), "P10");
        eq(PlotMath.nextName("007"), "008");
        eq(PlotMath.nextName("BM"), "BM1");

        // Guardar y volver a leer.
        List<PlotPoint> back = PlotMath.deserialize(PlotMath.serialize(pts));
        eq(back.size(), 5, 0);
        yes(back.get(3).breakBefore, "corte guardado");
        eq(back.get(1).desc, "rampa");

        // DXF.
        String dxf = PlotMath.toDxf(sq, PlotMath.buildRuns(sq, PlotMath.LINES_ORDER, true));
        yes(dxf.startsWith("0\nSECTION\n"), "DXF inicio");
        yes(dxf.endsWith("0\nEOF\n"), "DXF fin");
        yes(dxf.contains("POLYLINE") && dxf.contains("\n70\n9\n"), "polilínea cerrada");
        yes(PlotMath.toTable(sq).startsWith("Punto\tEste\tNorte"), "tabla Excel");

        System.out.println("PlotMath OK: " + checks + " comprobaciones");
    }
}
