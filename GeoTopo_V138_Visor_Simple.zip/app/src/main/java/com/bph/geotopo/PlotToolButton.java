package com.bph.geotopo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/** V138: botón redondo con ícono dibujado y una palabra debajo (barra lateral del Visor). */
public class PlotToolButton extends View {
    public static final String CUBE = "cube", PLAN = "plan", FIT = "fit", MEASURE = "measure",
            STYLE = "style", TEXT = "text", SPIN = "spin", MORE = "more";

    private final float d;
    private final Paint s = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint f = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final int accent;
    private String icon;
    private String caption;
    private boolean active;

    public PlotToolButton(Context c, String icon, String caption, int accent) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        this.icon = icon;
        this.caption = caption;
        this.accent = accent;
        s.setStyle(Paint.Style.STROKE);
        s.setStrokeCap(Paint.Cap.ROUND);
        s.setStrokeJoin(Paint.Join.ROUND);
        f.setStyle(Paint.Style.FILL);
        t.setTextAlign(Paint.Align.CENTER);
        t.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        setClickable(true);
        setContentDescription(caption);
    }

    public void set(String icon, String caption) {
        this.icon = icon;
        this.caption = caption;
        setContentDescription(caption);
        invalidate();
    }

    public void setActive(boolean on) {
        active = on;
        invalidate();
    }

    @Override protected void onMeasure(int wSpec, int hSpec) {
        setMeasuredDimension(Math.round(54 * d), Math.round(56 * d));
    }

    @Override protected void onDraw(Canvas cv) {
        float w = getWidth();
        float cx = w / 2, cy = 21 * d, r = 19 * d;
        f.setColor(active ? accent : Color.argb(215, 18, 28, 40));
        cv.drawCircle(cx, cy, r, f);
        s.setColor(active ? Color.WHITE : Color.argb(140, 120, 160, 200));
        s.setStrokeWidth(1f * d);
        cv.drawCircle(cx, cy, r, s);
        int ink = Color.WHITE;
        s.setColor(ink);
        s.setStrokeWidth(1.8f * d);
        f.setColor(ink);
        float u = 7.5f * d;
        switch (icon) {
            case CUBE: {
                // Cubo isométrico
                path.reset();
                path.moveTo(cx, cy - u);
                path.lineTo(cx + u, cy - u * 0.5f);
                path.lineTo(cx + u, cy + u * 0.6f);
                path.lineTo(cx, cy + u * 1.1f);
                path.lineTo(cx - u, cy + u * 0.6f);
                path.lineTo(cx - u, cy - u * 0.5f);
                path.close();
                cv.drawPath(path, s);
                cv.drawLine(cx - u, cy - u * 0.5f, cx, cy, s);
                cv.drawLine(cx + u, cy - u * 0.5f, cx, cy, s);
                cv.drawLine(cx, cy, cx, cy + u * 1.1f, s);
                break;
            }
            case PLAN: {
                // Hoja con cuadrícula (planta)
                cv.drawRect(cx - u, cy - u, cx + u, cy + u, s);
                s.setStrokeWidth(1f * d);
                cv.drawLine(cx, cy - u, cx, cy + u, s);
                cv.drawLine(cx - u, cy, cx + u, cy, s);
                break;
            }
            case FIT: {
                float k = u * 0.55f;
                cv.drawLine(cx - u, cy - u, cx - u + k, cy - u, s); cv.drawLine(cx - u, cy - u, cx - u, cy - u + k, s);
                cv.drawLine(cx + u, cy - u, cx + u - k, cy - u, s); cv.drawLine(cx + u, cy - u, cx + u, cy - u + k, s);
                cv.drawLine(cx - u, cy + u, cx - u + k, cy + u, s); cv.drawLine(cx - u, cy + u, cx - u, cy + u - k, s);
                cv.drawLine(cx + u, cy + u, cx + u - k, cy + u, s); cv.drawLine(cx + u, cy + u, cx + u, cy + u - k, s);
                cv.drawCircle(cx, cy, 2 * d, f);
                break;
            }
            case MEASURE: {
                cv.save();
                cv.rotate(-35, cx, cy);
                cv.drawRect(cx - u * 1.2f, cy - u * 0.42f, cx + u * 1.2f, cy + u * 0.42f, s);
                s.setStrokeWidth(1.2f * d);
                for (int i = -2; i <= 2; i++) {
                    float x = cx + i * u * 0.45f;
                    cv.drawLine(x, cy - u * 0.42f, x, cy - u * (i % 2 == 0 ? 0.0f : 0.15f), s);
                }
                cv.restore();
                break;
            }
            case STYLE: {
                // Ojo
                path.reset();
                path.moveTo(cx - u * 1.15f, cy);
                path.quadTo(cx, cy - u * 1.1f, cx + u * 1.15f, cy);
                path.quadTo(cx, cy + u * 1.1f, cx - u * 1.15f, cy);
                path.close();
                cv.drawPath(path, s);
                cv.drawCircle(cx, cy, u * 0.38f, f);
                break;
            }
            case TEXT: {
                t.setColor(ink);
                t.setTextSize(15 * d);
                cv.drawText("Aa", cx, cy + 5 * d, t);
                break;
            }
            case SPIN: {
                RectF oval = new RectF(cx - u, cy - u, cx + u, cy + u);
                cv.drawArc(oval, 200, 290, false, s);
                // Punta de flecha
                double a = Math.toRadians(200 + 290);
                float ex = cx + (float) Math.cos(a) * u, ey = cy + (float) Math.sin(a) * u;
                path.reset();
                path.moveTo(ex + 3.5f * d, ey - 3.5f * d);
                path.lineTo(ex, ey);
                path.lineTo(ex + 4.5f * d, ey + 2f * d);
                cv.drawPath(path, s);
                break;
            }
            case MORE:
            default: {
                cv.drawCircle(cx - u * 0.75f, cy, 2.1f * d, f);
                cv.drawCircle(cx, cy, 2.1f * d, f);
                cv.drawCircle(cx + u * 0.75f, cy, 2.1f * d, f);
                break;
            }
        }
        // Palabra debajo
        t.setTextSize(9.5f * d);
        t.setColor(Color.WHITE);
        t.setShadowLayer(2.5f * d, 0, 0, Color.BLACK);
        cv.drawText(caption, cx, 52 * d, t);
        t.setShadowLayer(0, 0, 0, 0);
    }
}
