package com.bph.geotopo;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * V138: Visor de coordenadas, versión simple.
 * Datos: pegar de Excel o agregar a mano. Gráfico: pantalla completa con íconos al costado,
 * cubo de vistas, giro libre y estilos (Normal, Rayos X, Sólido, Alambre).
 */
public class PlotActivity extends BaseToolActivity implements PlotView.Listener {
    private static final String FILE_NAME = "visor_coordenadas.txt";
    private static final String SP = "geo_topo_plot_viewer";
    private static final int REQ_DXF = 7301;
    private static final int REQ_CSV = 7302;
    private static final double[] EXAGGERATIONS = {1, 2, 5, 10};
    private static final String[] TEXT_CAPTIONS = {"Textos", "Nombres", "Sin texto"};
    private static final String[] LINE_NAMES = {"Sin líneas", "En orden", "Por código"};
    private static final ExecutorService SAVER = Executors.newSingleThreadExecutor();

    private final List<PlotMath.PlotPoint> points = new ArrayList<>();

    private PlotView plot;
    private View pageData, pageList, pageGraph;
    private Button tabData, tabList, tabGraph;

    private EditText inName, inDesc, inEast, inNorth, inZ;
    private CheckBox inBreak;
    private int pasteOrder = PlotMath.ORDER_AUTO;
    private TextView pasteResult;

    private TextView listHeader;
    private PointAdapter adapter;

    private PlotToolButton b3d, bMeasure, bStyle, bText, bSpin;
    private TextView infoBox;

    private int optText, optStyle, optLines, exagIndex;
    private boolean optDesc, optDist, optColor, optClose;

    private String pendingExport;

    // ------------------------------------------------------------ ciclo de vida
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        NativeUi.styleWindow(this);
        loadOptions();
        loadPoints();
        setContentView(buildScreen());
        showPage(points.isEmpty() ? 0 : 2);
    }

    @Override public void onContentChanged() {
        super.onContentChanged();
        View content = findViewById(android.R.id.content);
        if (!(content instanceof ViewGroup) || ((ViewGroup) content).getChildCount() == 0) return;
        View root = ((ViewGroup) content).getChildAt(0);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top, bottom, left, right;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(android.view.WindowInsets.Type.systemBars()
                        | android.view.WindowInsets.Type.displayCutout());
                android.graphics.Insets ime = insets.getInsets(android.view.WindowInsets.Type.ime());
                top = bars.top; left = bars.left; right = bars.right;
                // Desde Android 15 la ventana ya no se achica sola con el teclado.
                bottom = Build.VERSION.SDK_INT >= 35 ? Math.max(bars.bottom, ime.bottom) : bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
                left = insets.getSystemWindowInsetLeft();
                right = insets.getSystemWindowInsetRight();
            }
            v.setPadding(left, top, right, bottom);
            return insets;
        });
        root.requestApplyInsets();
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (plot != null) plot.invalidate();
    }

    @Override protected void onPause() {
        super.onPause();
        if (plot != null && plot.isSpinning()) plot.setSpinning(false);
    }

    // ------------------------------------------------------------ pantalla
    private View buildScreen() {
        LinearLayout root = page("Visor de coordenadas", null);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(dp(10), dp(7), dp(10), dp(6));
        tabs.setBackgroundColor(bgColor);
        tabData = tabButton("Datos");
        tabList = tabButton("Lista");
        tabGraph = tabButton("Gráfico");
        tabData.setOnClickListener(v -> showPage(0));
        tabList.setOnClickListener(v -> showPage(1));
        tabGraph.setOnClickListener(v -> showPage(2));
        tabs.addView(tabData, tabParams());
        tabs.addView(tabList, tabParams());
        tabs.addView(tabGraph, tabParams());
        root.addView(tabs);

        FrameLayout pages = new FrameLayout(this);
        pageData = buildDataPage();
        pageList = buildListPage();
        pageGraph = buildGraphPage();
        pages.addView(pageData, matchParams());
        pages.addView(pageList, matchParams());
        pages.addView(pageGraph, matchParams());
        root.addView(pages, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    private FrameLayout.LayoutParams matchParams() {
        return new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private LinearLayout.LayoutParams tabParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(40), 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    private Button tabButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        ResponsiveUi.configureCompactText(b, 14f, 10, 1);
        b.setPadding(dp(4), 0, dp(4), 0);
        return b;
    }

    private void styleChoice(Button b, boolean on) {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(11));
        if (on) {
            bg.setColor(accent);
            b.setTextColor(Color.WHITE);
        } else {
            bg.setColor(inputColor);
            bg.setStroke(dp(1), withAlpha(borderColor, 150));
            b.setTextColor(textColor);
        }
        b.setBackground(bg);
    }

    private void showPage(int index) {
        pageData.setVisibility(index == 0 ? View.VISIBLE : View.GONE);
        pageList.setVisibility(index == 1 ? View.VISIBLE : View.GONE);
        pageGraph.setVisibility(index == 2 ? View.VISIBLE : View.GONE);
        styleChoice(tabData, index == 0);
        styleChoice(tabList, index == 1);
        styleChoice(tabGraph, index == 2);
        tabList.setText("Lista (" + points.size() + ")");
        if (index != 0) hideKeyboard();
        if (index != 2 && plot.isSpinning()) plot.setSpinning(false);
        if (index == 1) refreshList();
        if (index == 2) { plot.invalidate(); updateInfo(); }
    }

    private void hideKeyboard() {
        View focus = getCurrentFocus();
        if (focus == null) return;
        android.view.inputmethod.InputMethodManager imm =
                (android.view.inputmethod.InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(focus.getWindowToken(), 0);
        focus.clearFocus();
    }

    // ------------------------------------------------------------ página Datos
    private View buildDataPage() {
        LinearLayout c = vertical();

        LinearLayout paste = card();
        paste.addView(sectionTitle("📋 Pegar de Excel"));
        paste.addView(small("Copia en Excel: Punto · Este · Norte · Cota"));
        Button fromClip = primaryButton("Pegar");
        fromClip.setOnClickListener(v -> pasteFromClipboard());
        paste.addView(fromClip);
        pasteResult = resultBox("");
        pasteResult.setVisibility(View.GONE);
        paste.addView(pasteResult);
        c.addView(paste);

        LinearLayout manual = card();
        manual.addView(sectionTitle("＋ Punto a mano"));
        inName = textInput("P1");
        inName.setText(PlotMath.nextName(points.isEmpty() ? "" : points.get(points.size() - 1).name));
        inZ = numberInput("Opcional");
        inEast = numberInput("345678.12");
        inNorth = numberInput("8654321.45");
        inDesc = textInput("Opcional");
        LinearLayout r1 = horizontal();
        r1.addView(labeled("Punto", inName), weight());
        r1.addView(labeled("Cota (Z)", inZ), weight());
        manual.addView(r1);
        LinearLayout r2 = horizontal();
        r2.addView(labeled("Este (X)", inEast), weight());
        r2.addView(labeled("Norte (Y)", inNorth), weight());
        manual.addView(r2);
        LinearLayout r3 = horizontal();
        r3.addView(labeled("Descripción", inDesc), weight());
        inBreak = new CheckBox(this);
        inBreak.setText("Línea nueva");
        inBreak.setTextColor(textColor);
        LinearLayout.LayoutParams cb = weight();
        cb.setMargins(dp(6), dp(14), 0, 0);
        r3.addView(inBreak, cb);
        manual.addView(r3);
        Button add = primaryButton("Agregar");
        add.setOnClickListener(v -> addManualPoint());
        manual.addView(add);
        c.addView(manual);

        Button more = secondaryButton("⋯  Más: importar, exportar, borrar");
        more.setOnClickListener(v -> dataMenu());
        c.addView(more);

        return scrollWith(c);
    }

    private void dataMenu() {
        String[] items = {
                "Escribir varias filas",
                "Orden de columnas: " + PlotMath.ORDER_LABELS[pasteOrder],
                "Traer de la libreta de campo",
                "Traer puntos GPS (a UTM)",
                "Copiar tabla para Excel",
                "Guardar DXF para AutoCAD",
                "Guardar CSV",
                "Borrar todos los puntos"
        };
        new AlertDialog.Builder(this)
                .setTitle("Más")
                .setItems(items, (d, which) -> {
                    switch (which) {
                        case 0: typeRows(); break;
                        case 1: chooseOrder(); break;
                        case 2: importNotebook(); break;
                        case 3: importGpsPoints(); break;
                        case 4: copyTable(); break;
                        case 5: saveDxf(); break;
                        case 6: saveCsv(); break;
                        case 7: confirmClearAll(); break;
                        default: break;
                    }
                })
                .show();
    }

    private void typeRows() {
        EditText box = textInput("P1  345678.12  8654321.45  3500.25");
        box.setSingleLine(false);
        box.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        box.setGravity(Gravity.TOP | Gravity.START);
        box.setMinLines(6);
        box.setMaxLines(12);
        box.setHorizontallyScrolling(false);
        box.setPadding(dp(10), dp(9), dp(10), dp(9));
        FrameLayout wrap = new FrameLayout(this);
        wrap.setPadding(dp(18), dp(8), dp(18), 0);
        wrap.addView(box, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        new AlertDialog.Builder(this)
                .setTitle("Una fila por punto")
                .setView(wrap)
                .setPositiveButton("Cargar", (d, w) -> loadText(box.getText().toString(), "lo escrito"))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void chooseOrder() {
        new AlertDialog.Builder(this)
                .setTitle("Orden de columnas")
                .setSingleChoiceItems(PlotMath.ORDER_LABELS, pasteOrder, (dialog, which) -> {
                    pasteOrder = which;
                    dialog.dismiss();
                })
                .show();
    }

    private void addManualPoint() {
        double e = PlotMath.parseNumber(inEast.getText().toString());
        double n = PlotMath.parseNumber(inNorth.getText().toString());
        if (Double.isNaN(e)) { inEast.setError("Falta el Este"); inEast.requestFocus(); return; }
        if (Double.isNaN(n)) { inNorth.setError("Falta el Norte"); inNorth.requestFocus(); return; }
        String zRaw = inZ.getText().toString().trim();
        double z = zRaw.isEmpty() ? Double.NaN : PlotMath.parseNumber(zRaw);
        if (!zRaw.isEmpty() && Double.isNaN(z)) { inZ.setError("Cota no válida"); inZ.requestFocus(); return; }
        String name = inName.getText().toString().trim();
        if (name.isEmpty()) name = String.valueOf(points.size() + 1);
        points.add(new PlotMath.PlotPoint(name, e, n, Double.isNaN(z) ? 0 : z, !Double.isNaN(z),
                inDesc.getText().toString(), inBreak.isChecked() && !points.isEmpty()));
        savePoints();
        plot.dataChanged();
        plot.requestFit();
        tabList.setText("Lista (" + points.size() + ")");
        showToast(name + " agregado (" + points.size() + ")");
        inName.setText(PlotMath.nextName(name));
        inEast.setText("");
        inNorth.setText("");
        inZ.setText("");
        inBreak.setChecked(false);
        inEast.requestFocus();
    }

    private void pasteFromClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        String value = null;
        try {
            if (cm != null && cm.hasPrimaryClip()) {
                ClipData clip = cm.getPrimaryClip();
                if (clip != null && clip.getItemCount() > 0) {
                    CharSequence cs = clip.getItemAt(0).coerceToText(this);
                    if (cs != null) value = cs.toString();
                }
            }
        } catch (Exception ignored) { }
        if (value == null || value.trim().isEmpty()) {
            showResult("No hay nada copiado. Copia primero en Excel.", false);
            return;
        }
        loadText(value, "lo copiado");
    }

    private void loadText(String raw, String source) {
        if (raw == null || raw.trim().isEmpty()) {
            showResult("No hay nada para cargar.", false);
            return;
        }
        final int order = pasteOrder;
        final int first = points.size() + 1;
        showResult("Leyendo…", true);
        new Thread(() -> {
            final PlotMath.ParseResult r = PlotMath.parse(raw, order, first);
            runOnUiThread(() -> {
                if (isFinishing()) return;
                if (r.points.isEmpty()) {
                    StringBuilder sb = new StringBuilder("No encontré puntos en ").append(source).append('.');
                    if (!r.problems.isEmpty()) sb.append('\n').append(r.problems.get(0));
                    showResult(sb.toString(), false);
                    return;
                }
                String msg = "✓ " + r.points.size() + " puntos";
                if (r.ignored > 0) msg += " · " + r.ignored + " filas no leídas";
                showResult(msg, r.ignored == 0);
                importPoints(r.points);
            });
        }).start();
    }

    private void showResult(String msg, boolean ok) {
        pasteResult.setVisibility(View.VISIBLE);
        pasteResult.setText(msg);
        pasteResult.setTextColor(ok ? textColor : Color.rgb(255, 190, 90));
    }

    private void importPoints(List<PlotMath.PlotPoint> incoming) {
        if (incoming == null || incoming.isEmpty()) return;
        if (points.isEmpty()) { applyImport(incoming, false); return; }
        new AlertDialog.Builder(this)
                .setTitle(incoming.size() + " puntos nuevos")
                .setMessage("Ya tienes " + points.size() + " puntos.")
                .setPositiveButton("Reemplazar", (d, w) -> applyImport(incoming, true))
                .setNegativeButton("Sumar", (d, w) -> applyImport(incoming, false))
                .setNeutralButton("Cancelar", null)
                .show();
    }

    private void applyImport(List<PlotMath.PlotPoint> incoming, boolean replace) {
        if (replace) points.clear();
        else if (!points.isEmpty()) incoming.get(0).breakBefore = true;
        points.addAll(incoming);
        savePoints();
        plot.clearSelection();
        plot.dataChanged();
        plot.requestFit();
        inName.setText(PlotMath.nextName(points.get(points.size() - 1).name));
        showPage(2);
    }

    private void importNotebook() {
        List<NotebookStore.Entry> entries = NotebookStore.load(this);
        List<PlotMath.PlotPoint> list = new ArrayList<>();
        int k = points.size() + 1;
        for (NotebookStore.Entry e : entries) {
            double east = PlotMath.parseNumber(e.east), north = PlotMath.parseNumber(e.north);
            if (Double.isNaN(east) || Double.isNaN(north)) continue;
            double z = PlotMath.parseNumber(e.elevation);
            String name = e.code.isEmpty() ? String.valueOf(k) : e.code;
            String desc = !e.description.isEmpty() ? e.description : e.type;
            list.add(new PlotMath.PlotPoint(name, east, north, Double.isNaN(z) ? 0 : z, !Double.isNaN(z), desc, false));
            k++;
        }
        if (list.isEmpty()) { showResult("La libreta no tiene puntos con Este y Norte.", false); return; }
        importPoints(list);
    }

    private void importGpsPoints() {
        JSONArray arr;
        try {
            arr = new JSONArray(getSharedPreferences("geo_topo_gps_points", MODE_PRIVATE).getString("points_json", "[]"));
        } catch (Exception e) {
            arr = new JSONArray();
        }
        List<PlotMath.PlotPoint> list = new ArrayList<>();
        int zone = 0;
        int k = points.size() + 1;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            double lat = o.optDouble("latitude", Double.NaN), lon = o.optDouble("longitude", Double.NaN);
            if (Double.isNaN(lat) || Double.isNaN(lon)) continue;
            CoordinateUtils.Utm u = zone == 0 ? CoordinateUtils.toUtm(lat, lon) : CoordinateUtils.toUtm(lat, lon, zone);
            if (u == null || !u.valid) continue;
            if (zone == 0) zone = u.zone;
            double alt = o.isNull("altitude") ? Double.NaN : o.optDouble("altitude", Double.NaN);
            String name = o.optString("name", "").trim();
            if (name.isEmpty()) name = String.valueOf(k);
            list.add(new PlotMath.PlotPoint(name, u.easting, u.northing, Double.isNaN(alt) ? 0 : alt,
                    !Double.isNaN(alt), o.optString("description", ""), false));
            k++;
        }
        if (list.isEmpty()) { showResult("No hay puntos GPS guardados.", false); return; }
        importPoints(list);
    }

    private void copyTable() {
        if (points.isEmpty()) { showToast("No hay puntos."); return; }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Puntos GeoTopo", PlotMath.toTable(points)));
        showToast("Copiado. Pégalo en Excel.");
    }

    private void saveDxf() {
        if (points.isEmpty()) { showToast("No hay puntos."); return; }
        pendingExport = PlotMath.toDxf(points, plot.getRuns());
        createDocument("application/dxf", "GeoTopo_plano_" + stamp() + ".dxf", REQ_DXF);
    }

    private void saveCsv() {
        if (points.isEmpty()) { showToast("No hay puntos."); return; }
        StringBuilder sb = new StringBuilder("Punto,Este,Norte,Cota,Descripcion\n");
        for (PlotMath.PlotPoint p : points) {
            sb.append(csv(p.name)).append(',').append(PlotMath.fmt(p.east, 3)).append(',')
              .append(PlotMath.fmt(p.north, 3)).append(',').append(p.hasZ ? PlotMath.fmt(p.z, 3) : "")
              .append(',').append(csv(p.desc)).append('\n');
        }
        pendingExport = sb.toString();
        createDocument("text/csv", "GeoTopo_puntos_" + stamp() + ".csv", REQ_CSV);
    }

    private static String csv(String v) {
        if (v.contains(",") || v.contains("\"")) return "\"" + v.replace("\"", "\"\"") + "\"";
        return v;
    }

    private static String stamp() {
        return new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date());
    }

    private void createDocument(String mime, String title, int request) {
        try {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType(mime);
            intent.putExtra(Intent.EXTRA_TITLE, title);
            startActivityForResult(intent, request);
        } catch (Exception e) {
            showToast("No se puede guardar en este celular.");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode != REQ_DXF && requestCode != REQ_CSV) || resultCode != RESULT_OK
                || data == null || data.getData() == null || pendingExport == null) return;
        try {
            Uri uri = data.getData();
            OutputStream out = getContentResolver().openOutputStream(uri);
            if (out == null) throw new IllegalStateException();
            out.write(pendingExport.getBytes(StandardCharsets.UTF_8));
            out.close();
            showToast(requestCode == REQ_DXF ? "DXF guardado" : "CSV guardado");
        } catch (Exception e) {
            showToast("No se pudo guardar.");
        }
        pendingExport = null;
    }

    private void confirmClearAll() {
        if (points.isEmpty()) { showToast("No hay puntos."); return; }
        new AlertDialog.Builder(this)
                .setTitle("¿Borrar los " + points.size() + " puntos?")
                .setPositiveButton("Borrar", (d, w) -> {
                    points.clear();
                    savePoints();
                    plot.clearSelection();
                    plot.dataChanged();
                    plot.requestFit();
                    inName.setText("1");
                    showPage(0);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ------------------------------------------------------------ página Lista
    private View buildListPage() {
        LinearLayout box = vertical();
        box.setBackgroundColor(bgColor);
        box.setPadding(dp(10), dp(4), dp(10), 0);
        listHeader = small("");
        box.addView(listHeader);
        ListView list = new ListView(this);
        list.setDivider(new ColorDrawable(Color.TRANSPARENT));
        list.setDividerHeight(dp(7));
        list.setSelector(new ColorDrawable(Color.TRANSPARENT));
        list.setFastScrollEnabled(true);
        list.setClipToPadding(false);
        list.setPadding(0, 0, 0, dp(20));
        adapter = new PointAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> editPoint(position));
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            showPage(2);
            plot.focusPoint(position);
            return true;
        });
        box.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return box;
    }

    private void refreshList() {
        if (adapter == null) return;
        listHeader.setText(points.isEmpty() ? "Sin puntos." : "Toca para editar · Mantén para verlo en el gráfico");
        adapter.notifyDataSetChanged();
        tabList.setText("Lista (" + points.size() + ")");
    }

    private final class PointAdapter extends BaseAdapter {
        @Override public int getCount() { return points.size(); }
        @Override public Object getItem(int position) { return points.get(position); }
        @Override public long getItemId(int position) { return position; }

        @Override public View getView(int position, View convertView, ViewGroup parent) {
            LinearLayout row;
            TextView title, sub;
            if (convertView instanceof LinearLayout && convertView.getTag() instanceof TextView[]) {
                row = (LinearLayout) convertView;
                TextView[] h = (TextView[]) convertView.getTag();
                title = h[0]; sub = h[1];
            } else {
                row = vertical();
                row.setPadding(dp(12), dp(9), dp(12), dp(9));
                GradientDrawable bg = new GradientDrawable();
                bg.setColor(cardColor);
                bg.setCornerRadius(dp(11));
                bg.setStroke(dp(1), withAlpha(borderColor, 70));
                row.setBackground(bg);
                title = text("", 15, true);
                sub = text("", 12, false);
                sub.setTextColor(subTextColor);
                row.addView(title);
                row.addView(sub);
                row.setTag(new TextView[]{title, sub});
                row.setLayoutParams(new AbsListView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            PlotMath.PlotPoint p = points.get(position);
            String head = p.name + (p.desc.isEmpty() ? "" : "  · " + p.desc);
            if (p.breakBefore) head = "↳ " + head;
            title.setText(head);
            sub.setText("E " + PlotMath.fmt(p.east, 3) + "   N " + PlotMath.fmt(p.north, 3)
                    + "   Z " + (p.hasZ ? PlotMath.fmt(p.z, 3) : "—"));
            return row;
        }
    }

    private void editPoint(int index) {
        if (index < 0 || index >= points.size()) return;
        PlotMath.PlotPoint p = points.get(index);
        LinearLayout form = vertical();
        form.setPadding(dp(18), dp(8), dp(18), 0);
        EditText name = textInput("Punto");
        name.setText(p.name);
        EditText east = numberInput("Este");
        east.setText(PlotMath.fmt(p.east, 4));
        EditText north = numberInput("Norte");
        north.setText(PlotMath.fmt(p.north, 4));
        EditText z = numberInput("Vacío = sin cota");
        z.setText(p.hasZ ? PlotMath.fmt(p.z, 4) : "");
        EditText desc = textInput("Descripción");
        desc.setText(p.desc);
        form.addView(dialogField("Punto", name));
        form.addView(dialogField("Este (X)", east));
        form.addView(dialogField("Norte (Y)", north));
        form.addView(dialogField("Cota (Z)", z));
        form.addView(dialogField("Descripción", desc));
        CheckBox br = new CheckBox(this);
        br.setText("Línea nueva desde aquí");
        br.setTextColor(Color.rgb(225, 232, 240));
        br.setChecked(p.breakBefore);
        form.addView(br);
        ScrollView sc = new ScrollView(this);
        sc.addView(form);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(p.name)
                .setView(sc)
                .setPositiveButton("Guardar", null)
                .setNeutralButton("Eliminar", (d, w) -> confirmDelete(index))
                .setNegativeButton("Cancelar", null)
                .create();
        dialog.setOnShowListener(di -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            double e = PlotMath.parseNumber(east.getText().toString());
            double n = PlotMath.parseNumber(north.getText().toString());
            String zr = z.getText().toString().trim();
            double zz = zr.isEmpty() ? Double.NaN : PlotMath.parseNumber(zr);
            if (Double.isNaN(e)) { east.setError("Este no válido"); return; }
            if (Double.isNaN(n)) { north.setError("Norte no válido"); return; }
            if (!zr.isEmpty() && Double.isNaN(zz)) { z.setError("Cota no válida"); return; }
            String nm = name.getText().toString().trim();
            p.name = nm.isEmpty() ? String.valueOf(index + 1) : PlotMath.clean(nm);
            p.east = e;
            p.north = n;
            p.hasZ = !Double.isNaN(zz);
            p.z = p.hasZ ? zz : 0;
            p.desc = PlotMath.clean(desc.getText().toString());
            p.breakBefore = br.isChecked() && index > 0;
            savePoints();
            plot.dataChanged();
            refreshList();
            dialog.dismiss();
        }));
        dialog.show();
    }

    private View dialogField(String label, EditText input) {
        LinearLayout box = vertical();
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(Color.rgb(190, 204, 220));
        t.setTextSize(12);
        box.addView(t);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        lp.setMargins(0, dp(2), 0, dp(8));
        box.addView(input, lp);
        return box;
    }

    private void confirmDelete(int index) {
        if (index < 0 || index >= points.size()) return;
        new AlertDialog.Builder(this)
                .setTitle("¿Eliminar " + points.get(index).name + "?")
                .setPositiveButton("Eliminar", (d, w) -> {
                    points.remove(index);
                    savePoints();
                    plot.clearSelection();
                    plot.dataChanged();
                    refreshList();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ------------------------------------------------------------ página Gráfico
    private View buildGraphPage() {
        LinearLayout box = vertical();
        box.setBackgroundColor(bgColor);

        FrameLayout stage = new FrameLayout(this);
        plot = new PlotView(this);
        plot.setPoints(points);
        plot.setListener(this);
        applyPlotOptions();
        plot.setStyle(optStyle);
        plot.setExaggeration(EXAGGERATIONS[exagIndex]);
        stage.addView(plot, matchParams());

        // Barra de íconos a la derecha
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setGravity(Gravity.CENTER_HORIZONTAL);
        b3d = tool(PlotToolButton.CUBE, "3D", v -> plot.setMode3d(!plot.isMode3d()));
        PlotToolButton bFit = tool(PlotToolButton.FIT, "Todo", v -> plot.zoomExtents());
        bMeasure = tool(PlotToolButton.MEASURE, "Medir", v -> {
            plot.setMeasureMode(!plot.isMeasureMode());
            refreshTools();
        });
        bStyle = tool(PlotToolButton.STYLE, PlotView.STYLE_NAMES[optStyle], v -> cycleStyle());
        bText = tool(PlotToolButton.TEXT, TEXT_CAPTIONS[optText], v -> cycleText());
        bSpin = tool(PlotToolButton.SPIN, "Girar", v -> plot.setSpinning(!plot.isSpinning()));
        PlotToolButton bMore = tool(PlotToolButton.MORE, "Más", v -> graphMenu());
        bar.addView(b3d);
        bar.addView(bFit);
        bar.addView(bMeasure);
        bar.addView(bStyle);
        bar.addView(bText);
        bar.addView(bSpin);
        bar.addView(bMore);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END | Gravity.BOTTOM);
        blp.setMargins(0, 0, dp(2), dp(6));
        stage.addView(bar, blp);
        box.addView(stage, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        infoBox = new TextView(this);
        infoBox.setTextColor(Color.rgb(232, 240, 248));
        ResponsiveUi.configureText(infoBox, 12.5f);
        infoBox.setLineSpacing(0, 1.1f);
        infoBox.setPadding(dp(14), dp(8), dp(14), dp(9));
        infoBox.setBackgroundColor(Color.rgb(12, 18, 26));
        box.addView(infoBox, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        refreshTools();
        return box;
    }

    private PlotToolButton tool(String icon, String caption, View.OnClickListener click) {
        PlotToolButton b = new PlotToolButton(this, icon, caption, accent);
        b.setOnClickListener(click);
        return b;
    }

    private void applyPlotOptions() {
        plot.setOptions(optText <= 1, optText == 0, optDesc && optText == 0, optDist, optColor);
        plot.setLines(optLines, optClose);
    }

    private void refreshTools() {
        boolean three = plot.isMode3d();
        if (three) b3d.set(PlotToolButton.PLAN, "2D"); else b3d.set(PlotToolButton.CUBE, "3D");
        bMeasure.setActive(plot.isMeasureMode());
        bStyle.set(PlotToolButton.STYLE, PlotView.STYLE_NAMES[optStyle]);
        bStyle.setActive(optStyle != PlotView.STYLE_NORMAL);
        bText.set(PlotToolButton.TEXT, TEXT_CAPTIONS[optText]);
        bText.setActive(optText != 0);
        bSpin.setVisibility(three ? View.VISIBLE : View.GONE);
        bSpin.setActive(plot.isSpinning());
    }

    private void cycleStyle() {
        optStyle = (optStyle + 1) % PlotView.STYLE_NAMES.length;
        plot.setStyle(optStyle);
        saveOptions();
        refreshTools();
    }

    private void cycleText() {
        optText = (optText + 1) % TEXT_CAPTIONS.length;
        applyPlotOptions();
        saveOptions();
        refreshTools();
    }

    private void graphMenu() {
        String[] items = {
                "Líneas: " + LINE_NAMES[optLines],
                "Altura (Z): ×" + PlotMath.fmt(EXAGGERATIONS[exagIndex], 0),
                mark(optClose) + "Cerrar polígonos",
                mark(optDist) + "Distancias",
                mark(optDesc) + "Descripción",
                mark(optColor) + "Colores por cota"
        };
        new AlertDialog.Builder(this)
                .setItems(items, (d, which) -> {
                    switch (which) {
                        case 0:
                            new AlertDialog.Builder(this).setTitle("Líneas")
                                    .setSingleChoiceItems(LINE_NAMES, optLines, (dd, w) -> {
                                        optLines = w;
                                        applyPlotOptions();
                                        saveOptions();
                                        updateInfo();
                                        dd.dismiss();
                                    }).show();
                            return;
                        case 1:
                            String[] ex = {"×1 (real)", "×2", "×5", "×10"};
                            new AlertDialog.Builder(this).setTitle("Altura (Z)")
                                    .setSingleChoiceItems(ex, exagIndex, (dd, w) -> {
                                        exagIndex = w;
                                        plot.setExaggeration(EXAGGERATIONS[exagIndex]);
                                        saveOptions();
                                        dd.dismiss();
                                    }).show();
                            return;
                        case 2: optClose = !optClose; break;
                        case 3: optDist = !optDist; break;
                        case 4: optDesc = !optDesc; break;
                        case 5: optColor = !optColor; break;
                        default: break;
                    }
                    applyPlotOptions();
                    saveOptions();
                    updateInfo();
                })
                .show();
    }

    private static String mark(boolean on) { return on ? "✓  " : "○  "; }

    @Override public void onSelectionChanged() { updateInfo(); }

    @Override public void onModeChanged() {
        refreshTools();
        updateInfo();
    }

    private void updateInfo() {
        if (infoBox == null || plot == null) return;
        int a = plot.getSelA(), b = plot.getSelB();
        if (plot.isMeasureMode()) {
            if (a < 0) { infoBox.setText("📏 Toca el punto A"); return; }
            if (b < 0) { infoBox.setText("📏 A = " + points.get(a).name + " · toca el punto B"); return; }
            infoBox.setText(measureText(points.get(a), points.get(b)));
            return;
        }
        if (a >= 0 && a < points.size()) {
            PlotMath.PlotPoint p = points.get(a);
            String s = "● " + p.name + (p.desc.isEmpty() ? "" : "  · " + p.desc)
                    + "\nE " + PlotMath.fmt(p.east, 3) + "   N " + PlotMath.fmt(p.north, 3)
                    + "   Z " + (p.hasZ ? PlotMath.fmt(p.z, 3) : "—");
            infoBox.setText(s);
            return;
        }
        infoBox.setText(summaryText());
    }

    private String measureText(PlotMath.PlotPoint a, PlotMath.PlotPoint b) {
        double dh = PlotMath.horizontal(a, b);
        StringBuilder sb = new StringBuilder();
        sb.append(a.name).append(" → ").append(b.name).append("   Dist: ").append(PlotMath.fmt(dh, 3)).append(" m");
        if (a.hasZ && b.hasZ) {
            double dz = b.z - a.z;
            sb.append("\nDesnivel ").append(String.format(Locale.US, "%+.3f", dz)).append(" m");
            if (dh > 1e-9) sb.append("   Pend. ").append(String.format(Locale.US, "%+.2f", dz / dh * 100)).append(" %");
        }
        if (dh > 1e-9) sb.append("\nAzimut ").append(PlotMath.dms(PlotMath.azimuth(a, b)));
        return sb.toString();
    }

    private String summaryText() {
        if (points.isEmpty()) return "Sin puntos";
        PlotMath.Bounds bd = PlotMath.bounds(points);
        StringBuilder sb = new StringBuilder();
        sb.append(points.size()).append(" puntos");
        if (bd.withZ > 0) sb.append("  ·  Cota ").append(PlotMath.fmt(bd.minZ, 1)).append(" a ").append(PlotMath.fmt(bd.maxZ, 1));
        double area = 0;
        for (PlotMath.Run r : plot.getRuns()) if (PlotMath.isLoop(points, r)) area += PlotMath.area(points, r.idx);
        if (area > 0) sb.append("\nÁrea ").append(PlotMath.fmt(area, 2)).append(" m²");
        return sb.toString();
    }

    // ------------------------------------------------------------ guardar
    private File dataFile() {
        return new File(getFilesDir(), FILE_NAME);
    }

    private void loadPoints() {
        points.clear();
        File f = dataFile();
        if (!f.exists()) return;
        try {
            InputStream in = new FileInputStream(f);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int r;
            while ((r = in.read(buf)) > 0) bos.write(buf, 0, r);
            in.close();
            points.addAll(PlotMath.deserialize(new String(bos.toByteArray(), StandardCharsets.UTF_8)));
        } catch (Exception ignored) { }
    }

    private void savePoints() {
        final String raw = PlotMath.serialize(points);
        final File f = dataFile();
        SAVER.execute(() -> {
            try {
                File tmp = new File(f.getParentFile(), FILE_NAME + ".tmp");
                FileOutputStream out = new FileOutputStream(tmp);
                out.write(raw.getBytes(StandardCharsets.UTF_8));
                out.close();
                if (!tmp.renameTo(f)) {
                    FileOutputStream direct = new FileOutputStream(f);
                    direct.write(raw.getBytes(StandardCharsets.UTF_8));
                    direct.close();
                    //noinspection ResultOfMethodCallIgnored
                    tmp.delete();
                }
            } catch (Exception ignored) { }
        });
    }

    private void loadOptions() {
        SharedPreferences sp = getSharedPreferences(SP, MODE_PRIVATE);
        optText = clampInt(sp.getInt("text", 0), 0, 2);
        optStyle = clampInt(sp.getInt("style", 0), 0, 3);
        optDesc = sp.getBoolean("desc", false);
        optDist = sp.getBoolean("dist", false);
        optColor = sp.getBoolean("color", true);
        optClose = sp.getBoolean("close", false);
        optLines = clampInt(sp.getInt("lines", PlotMath.LINES_ORDER), 0, 2);
        exagIndex = clampInt(sp.getInt("exag", 0), 0, EXAGGERATIONS.length - 1);
    }

    private static int clampInt(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }

    private void saveOptions() {
        getSharedPreferences(SP, MODE_PRIVATE).edit()
                .putInt("text", optText).putInt("style", optStyle)
                .putBoolean("desc", optDesc).putBoolean("dist", optDist).putBoolean("color", optColor)
                .putBoolean("close", optClose).putInt("lines", optLines).putInt("exag", exagIndex)
                .apply();
    }
}
