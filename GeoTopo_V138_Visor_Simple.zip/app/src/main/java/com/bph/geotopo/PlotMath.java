package com.bph.geotopo;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * V137: cálculos del Visor de coordenadas (sin Android, se prueba en GitHub Actions).
 * Lee filas copiadas de Excel, arma líneas, mide, proyecta en 3D y genera DXF para AutoCAD.
 */
public final class PlotMath {
    private PlotMath() {}

    // ---------------------------------------------------------------- punto
    public static final class PlotPoint {
        public String name;
        public double east;
        public double north;
        public double z;
        public boolean hasZ;
        public String desc;
        /** true = este punto empieza una línea nueva (no se une con el anterior). */
        public boolean breakBefore;

        public PlotPoint(String name, double east, double north, double z, boolean hasZ, String desc, boolean breakBefore) {
            this.name = clean(name);
            this.east = east;
            this.north = north;
            this.z = hasZ ? z : 0d;
            this.hasZ = hasZ;
            this.desc = clean(desc);
            this.breakBefore = breakBefore;
        }

        public PlotPoint copy() {
            return new PlotPoint(name, east, north, z, hasZ, desc, breakBefore);
        }
    }

    static String clean(String v) {
        if (v == null) return "";
        return v.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim();
    }

    // ---------------------------------------------------------------- lectura de Excel / texto
    public static final int ORDER_AUTO = 0;
    public static final int ORDER_PENZD = 1;
    public static final int ORDER_PNEZD = 2;
    public static final int ORDER_ENZD = 3;
    public static final int ORDER_NEZD = 4;

    public static final String[] ORDER_LABELS = {
            "Automático (recomendado)",
            "Punto, Este, Norte, Cota, Descripción",
            "Punto, Norte, Este, Cota, Descripción",
            "Este, Norte, Cota, Descripción",
            "Norte, Este, Cota, Descripción"
    };

    public static final class ParseResult {
        public final List<PlotPoint> points = new ArrayList<>();
        public int ignored;
        public final List<String> problems = new ArrayList<>();
        public String layout = "";
        public boolean headerFound;
    }

    /** Posición de cada columna; -1 = no existe. */
    static final class Layout {
        int name = -1, east = -1, north = -1, z = -1, desc = -1;
        String label() {
            String[] cols = new String[Math.max(Math.max(Math.max(name, east), Math.max(north, z)), desc) + 1];
            if (name >= 0) cols[name] = "Punto";
            if (east >= 0) cols[east] = "Este";
            if (north >= 0) cols[north] = "Norte";
            if (z >= 0) cols[z] = "Cota";
            if (desc >= 0) cols[desc] = "Descripción";
            StringBuilder sb = new StringBuilder();
            for (String c : cols) {
                if (c == null) continue;
                if (sb.length() > 0) sb.append(", ");
                sb.append(c);
            }
            return sb.toString();
        }
    }

    /**
     * Lee texto pegado (Excel, CSV, bloc de notas). Sin límite de filas.
     * Una fila vacía entre puntos hace que el siguiente punto empiece una línea nueva.
     * @param firstNumber número usado para nombrar puntos sin nombre.
     */
    public static ParseResult parse(String text, int order, int firstNumber) {
        ParseResult result = new ParseResult();
        if (text == null) return result;
        String[] lines = text.split("\r\n|\r|\n", -1);
        Layout layout = null;
        boolean pendingBreak = false;
        int autoName = firstNumber;

        for (int li = 0; li < lines.length; li++) {
            String line = lines[li];
            if (line.trim().isEmpty()) {
                if (!result.points.isEmpty()) pendingBreak = true;
                continue;
            }
            Split split = split(line);
            String[] tok = split.tokens;
            if (layout == null) {
                Layout header = headerLayout(tok);
                if (header != null) {
                    result.headerFound = true;
                    if (order == ORDER_AUTO) layout = header;
                    continue;
                }
                if (!hasAnyNumber(tok)) continue; // título o fila de texto antes de los datos
                layout = order == ORDER_AUTO ? guessLayout(tok) : fixedLayout(order);
                if (layout == null) {
                    result.ignored++;
                    addProblem(result, "Fila " + (li + 1) + ": no se encontraron Este y Norte.");
                    continue;
                }
            } else if (headerLayout(tok) != null) {
                continue; // encabezado repetido
            }

            double e = layout.east < tok.length ? parseNumber(tok[layout.east]) : Double.NaN;
            double n = layout.north < tok.length ? parseNumber(tok[layout.north]) : Double.NaN;
            if (Double.isNaN(e) || Double.isNaN(n)) {
                result.ignored++;
                addProblem(result, "Fila " + (li + 1) + ": Este o Norte no es un número.");
                continue;
            }
            double z = Double.NaN;
            if (layout.z >= 0 && layout.z < tok.length && !tok[layout.z].trim().isEmpty()) {
                z = parseNumber(tok[layout.z]);
            }
            String name = layout.name >= 0 && layout.name < tok.length ? tok[layout.name].trim() : "";
            if (name.isEmpty()) name = String.valueOf(autoName);
            autoName++;
            String desc = "";
            if (layout.desc >= 0 && layout.desc < tok.length) {
                StringBuilder sb = new StringBuilder();
                for (int k = layout.desc; k < tok.length; k++) {
                    String part = tok[k].trim();
                    if (part.isEmpty()) continue;
                    if (sb.length() > 0) sb.append(' ');
                    sb.append(part);
                }
                desc = sb.toString();
            }
            result.points.add(new PlotPoint(name, e, n, Double.isNaN(z) ? 0 : z, !Double.isNaN(z), desc, pendingBreak));
            pendingBreak = false;
        }
        if (layout != null) result.layout = layout.label();
        return result;
    }

    private static void addProblem(ParseResult r, String msg) {
        if (r.problems.size() < 8) r.problems.add(msg);
    }

    static final class Split {
        final String[] tokens;
        final boolean whitespace;
        Split(String[] tokens, boolean whitespace) { this.tokens = tokens; this.whitespace = whitespace; }
    }

    static Split split(String line) {
        String l = line.replace(' ', ' ');
        if (l.indexOf('\t') >= 0) return new Split(trimAll(l.split("\t", -1)), false);
        if (l.indexOf(';') >= 0) return new Split(trimAll(l.split(";", -1)), false);
        String t = l.trim();
        if (t.indexOf(',') >= 0) {
            boolean hasDot = t.indexOf('.') >= 0;
            boolean commaSpace = t.contains(", ");
            boolean noSpaces = !t.matches(".*\\s.*");
            if (hasDot || commaSpace || noSpaces) return new Split(trimAll(t.split(",", -1)), false);
        }
        return new Split(t.split("\\s+"), true);
    }

    private static String[] trimAll(String[] a) {
        for (int i = 0; i < a.length; i++) a[i] = a[i].trim();
        return a;
    }

    /** Número con punto o coma decimal, con o sin separador de miles. NaN si no es número. */
    public static double parseNumber(String raw) {
        if (raw == null) return Double.NaN;
        String s = raw.trim().replace(" ", "").replace(" ", "").replace("'", "");
        if (s.endsWith("m") || s.endsWith("M")) s = s.substring(0, s.length() - 1);
        if (s.isEmpty()) return Double.NaN;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            boolean ok = (c >= '0' && c <= '9') || c == '.' || c == ',' || c == '-' || c == '+' || c == 'e' || c == 'E';
            if (!ok) return Double.NaN;
        }
        int dots = count(s, '.'), commas = count(s, ',');
        if (dots > 0 && commas > 0) {
            int last = Math.max(s.lastIndexOf('.'), s.lastIndexOf(','));
            char decimal = s.charAt(last);
            char other = decimal == '.' ? ',' : '.';
            s = s.replace(String.valueOf(other), "");
            if (count(s, decimal) > 1) return Double.NaN;
            s = s.replace(decimal, '.');
        } else if (commas > 1) {
            s = s.replace(",", "");
        } else if (commas == 1) {
            s = s.replace(',', '.');
        } else if (dots > 1) {
            s = s.replace(".", "");
        }
        try {
            double v = Double.parseDouble(s);
            return Double.isNaN(v) || Double.isInfinite(v) ? Double.NaN : v;
        } catch (NumberFormatException ex) {
            return Double.NaN;
        }
    }

    private static int count(String s, char c) {
        int k = 0;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) == c) k++;
        return k;
    }

    static Layout fixedLayout(int order) {
        Layout l = new Layout();
        switch (order) {
            case ORDER_PNEZD: l.name = 0; l.north = 1; l.east = 2; l.z = 3; l.desc = 4; break;
            case ORDER_ENZD: l.east = 0; l.north = 1; l.z = 2; l.desc = 3; break;
            case ORDER_NEZD: l.north = 0; l.east = 1; l.z = 2; l.desc = 3; break;
            case ORDER_PENZD:
            default: l.name = 0; l.east = 1; l.north = 2; l.z = 3; l.desc = 4; break;
        }
        return l;
    }

    static String norm(String s) {
        String n = Normalizer.normalize(s == null ? "" : s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return n.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
    }

    static final int ROLE_NONE = 0, ROLE_NAME = 1, ROLE_EAST = 2, ROLE_NORTH = 3, ROLE_Z = 4, ROLE_DESC = 5;

    private static boolean hasAnyNumber(String[] tok) {
        for (String t : tok) if (!Double.isNaN(parseNumber(t))) return true;
        return false;
    }

    static int role(String raw) {
        String r = raw == null ? "" : raw.trim().toLowerCase(Locale.ROOT);
        if (r.equals("n°") || r.equals("nº") || r.equals("no.") || r.equals("n.°") || r.startsWith("n° ")
                || r.startsWith("nº ")) return ROLE_NAME;
        String h = norm(raw);
        if (h.isEmpty()) return ROLE_NONE;
        if (h.equals("e") || h.equals("x") || h.equals("east") || h.equals("easting") || h.startsWith("este")
                || h.equals("coord e") || h.equals("coord x") || h.equals("e m") || h.equals("x m"))
            return ROLE_EAST;
        if (h.equals("n") || h.equals("y") || h.equals("north") || h.equals("northing") || h.startsWith("norte")
                || h.equals("coord n") || h.equals("coord y") || h.equals("n m") || h.equals("y m"))
            return ROLE_NORTH;
        if (h.equals("z") || h.equals("h") || h.equals("alt") || h.startsWith("cota") || h.startsWith("elev")
                || h.startsWith("altitud") || h.startsWith("altura") || h.equals("nivel") || h.equals("z m")
                || h.equals("h m"))
            return ROLE_Z;
        if (h.equals("p") || h.equals("pt") || h.equals("pto") || h.equals("pts") || h.startsWith("punto")
                || h.startsWith("nombre") || h.equals("id") || h.equals("name") || h.equals("est")
                || h.startsWith("estacion") || h.equals("nro") || h.equals("num") || h.startsWith("numero")
                || h.equals("n punto") || h.equals("no"))
            return ROLE_NAME;
        if (h.startsWith("desc") || h.startsWith("cod") || h.startsWith("obs") || h.equals("d")
                || h.equals("code") || h.equals("detalle") || h.equals("tipo") || h.equals("nota")
                || h.equals("notas") || h.equals("capa") || h.equals("layer"))
            return ROLE_DESC;
        return ROLE_NONE;
    }

    /** Encabezado tipo "Punto | Este | Norte | Cota". null si la fila no es encabezado. */
    static Layout headerLayout(String[] tok) {
        Layout l = new Layout();
        int numbers = 0;
        for (int i = 0; i < tok.length; i++) {
            if (!Double.isNaN(parseNumber(tok[i]))) { numbers++; continue; }
            int r = role(tok[i]);
            if (r == ROLE_NAME && l.name < 0) l.name = i;
            else if (r == ROLE_EAST && l.east < 0) l.east = i;
            else if (r == ROLE_NORTH && l.north < 0) l.north = i;
            else if (r == ROLE_Z && l.z < 0) l.z = i;
            else if (r == ROLE_DESC && l.desc < 0) l.desc = i;
        }
        if (numbers > 0 || l.east < 0 || l.north < 0) return null;
        return l;
    }

    /** Adivina las columnas a partir de la primera fila con datos. */
    static Layout guessLayout(String[] tok) {
        int first = -1;
        for (int i = 0; i < tok.length; i++) if (!tok[i].trim().isEmpty()) { first = i; break; }
        if (first < 0) return null;
        Layout l = new Layout();
        int start;
        if (Double.isNaN(parseNumber(tok[first]))) {
            l.name = first;
            start = first + 1;
        } else {
            int k = 0;
            for (int i = first; i < tok.length && !Double.isNaN(parseNumber(tok[i])); i++) k++;
            if (k >= 4) { l.name = first; start = first + 1; } else start = first;
        }
        List<Integer> nums = new ArrayList<>();
        int afterNums = start;
        int emptyZ = -1;
        for (int i = start; i < tok.length; i++) {
            if (Double.isNaN(parseNumber(tok[i]))) {
                // Celda de cota vacía en Excel: la columna existe aunque esta fila no tenga cota.
                if (tok[i].trim().isEmpty() && nums.size() == 2) { emptyZ = i; afterNums = i + 1; }
                break;
            }
            nums.add(i);
            afterNums = i + 1;
            if (nums.size() == 3) break;
        }
        if (nums.size() < 2) return null;
        double a = Math.abs(parseNumber(tok[nums.get(0)]));
        double b = Math.abs(parseNumber(tok[nums.get(1)]));
        if (a >= 1000000d && b < 1000000d) { l.north = nums.get(0); l.east = nums.get(1); }
        else { l.east = nums.get(0); l.north = nums.get(1); }
        if (nums.size() >= 3) l.z = nums.get(2);
        else if (emptyZ >= 0) l.z = emptyZ;
        if (afterNums < tok.length) l.desc = afterNums;
        return l;
    }

    // ---------------------------------------------------------------- líneas
    public static final int LINES_NONE = 0;
    public static final int LINES_ORDER = 1;
    public static final int LINES_CODE = 2;

    public static final class Run {
        public final int[] idx;
        public final boolean closed;
        public final String code;
        Run(int[] idx, boolean closed, String code) { this.idx = idx; this.closed = closed; this.code = code; }
    }

    /**
     * Arma las líneas: en orden de la lista, o uniendo puntos con la misma descripción (código).
     * Un punto con "línea nueva" corta la línea. Con close=true cada línea de 3+ puntos se cierra.
     */
    public static List<Run> buildRuns(List<PlotPoint> pts, int mode, boolean close) {
        List<Run> runs = new ArrayList<>();
        if (pts == null || pts.isEmpty() || mode == LINES_NONE) return runs;
        if (mode == LINES_ORDER) {
            List<Integer> cur = new ArrayList<>();
            for (int i = 0; i < pts.size(); i++) {
                if (pts.get(i).breakBefore && !cur.isEmpty()) {
                    addRun(runs, cur, close, "");
                    cur = new ArrayList<>();
                }
                cur.add(i);
            }
            addRun(runs, cur, close, "");
            return runs;
        }
        Map<String, List<Integer>> open = new LinkedHashMap<>();
        Map<String, String> label = new HashMap<>();
        List<Object[]> finished = new ArrayList<>();
        for (int i = 0; i < pts.size(); i++) {
            String code = norm(pts.get(i).desc);
            if (code.isEmpty()) continue;
            List<Integer> cur = open.get(code);
            if (cur != null && pts.get(i).breakBefore && !cur.isEmpty()) {
                finished.add(new Object[]{cur, label.get(code)});
                cur = null;
            }
            if (cur == null) {
                cur = new ArrayList<>();
                open.put(code, cur);
                label.put(code, pts.get(i).desc);
            }
            cur.add(i);
        }
        for (Map.Entry<String, List<Integer>> en : open.entrySet())
            finished.add(new Object[]{en.getValue(), label.get(en.getKey())});
        for (Object[] f : finished) {
            @SuppressWarnings("unchecked") List<Integer> list = (List<Integer>) f[0];
            addRun(runs, list, close, (String) f[1]);
        }
        return runs;
    }

    private static void addRun(List<Run> runs, List<Integer> list, boolean close, String code) {
        if (list.size() < 2) return;
        int[] idx = new int[list.size()];
        for (int i = 0; i < idx.length; i++) idx[i] = list.get(i);
        runs.add(new Run(idx, close && idx.length >= 3, code == null ? "" : code));
    }

    /** true si la línea forma un polígono: está cerrada o el último punto repite al primero. */
    public static boolean isLoop(List<PlotPoint> pts, Run r) {
        if (r == null || r.idx.length < 3) return false;
        if (r.closed) return true;
        if (r.idx.length < 4) return false;
        PlotPoint a = pts.get(r.idx[0]), b = pts.get(r.idx[r.idx.length - 1]);
        return Math.abs(a.east - b.east) < 1e-6 && Math.abs(a.north - b.north) < 1e-6;
    }

    // ---------------------------------------------------------------- medidas
    public static double horizontal(PlotPoint a, PlotPoint b) {
        return Math.hypot(b.east - a.east, b.north - a.north);
    }

    /** Azimut desde el Norte, en sentido horario, 0..360. */
    public static double azimuth(PlotPoint a, PlotPoint b) {
        double az = Math.toDegrees(Math.atan2(b.east - a.east, b.north - a.north));
        az %= 360d;
        return az < 0 ? az + 360d : az;
    }

    /** Rumbo tipo "S 56°14'00\" E" a partir del azimut. */
    public static String bearing(double az) {
        double a = az % 360d;
        if (a < 0) a += 360d;
        String ns, ew;
        double ang;
        if (a <= 90) { ns = "N"; ew = "E"; ang = a; }
        else if (a <= 180) { ns = "S"; ew = "E"; ang = 180 - a; }
        else if (a <= 270) { ns = "S"; ew = "O"; ang = a - 180; }
        else { ns = "N"; ew = "O"; ang = 360 - a; }
        return ns + " " + dms(ang) + " " + ew;
    }

    public static String dms(double deg) {
        long total = Math.round(Math.abs(deg) * 3600d);
        long d = total / 3600L, m = (total % 3600L) / 60L, s = total % 60L;
        return String.format(Locale.US, "%d°%02d'%02d\"", d, m, s);
    }

    /** Área (fórmula de Gauss) del polígono formado por los índices dados, en m². */
    public static double area(List<PlotPoint> pts, int[] idx) {
        if (idx == null || idx.length < 3) return 0;
        double ox = pts.get(idx[0]).east, oy = pts.get(idx[0]).north;
        double sum = 0;
        for (int i = 0; i < idx.length; i++) {
            PlotPoint p = pts.get(idx[i]);
            PlotPoint q = pts.get(idx[(i + 1) % idx.length]);
            sum += (p.east - ox) * (q.north - oy) - (q.east - ox) * (p.north - oy);
        }
        return Math.abs(sum) / 2d;
    }

    public static double length(List<PlotPoint> pts, int[] idx, boolean closed) {
        if (idx == null || idx.length < 2) return 0;
        double total = 0;
        for (int i = 1; i < idx.length; i++) total += horizontal(pts.get(idx[i - 1]), pts.get(idx[i]));
        if (closed && idx.length >= 3) total += horizontal(pts.get(idx[idx.length - 1]), pts.get(idx[0]));
        return total;
    }

    public static final class Bounds {
        public double minE = Double.MAX_VALUE, maxE = -Double.MAX_VALUE;
        public double minN = Double.MAX_VALUE, maxN = -Double.MAX_VALUE;
        public double minZ = Double.MAX_VALUE, maxZ = -Double.MAX_VALUE;
        public int count, withZ;
        public boolean empty() { return count == 0; }
        public double zRange() { return withZ == 0 ? 0 : maxZ - minZ; }
        public double baseZ() { return withZ == 0 ? 0 : minZ; }
    }

    public static Bounds bounds(List<PlotPoint> pts) {
        Bounds b = new Bounds();
        if (pts == null) return b;
        for (PlotPoint p : pts) {
            b.count++;
            b.minE = Math.min(b.minE, p.east); b.maxE = Math.max(b.maxE, p.east);
            b.minN = Math.min(b.minN, p.north); b.maxN = Math.max(b.maxN, p.north);
            if (p.hasZ) {
                b.withZ++;
                b.minZ = Math.min(b.minZ, p.z); b.maxZ = Math.max(b.maxZ, p.z);
            }
        }
        if (b.withZ == 0) { b.minZ = 0; b.maxZ = 0; }
        return b;
    }

    /** Paso "bonito" de cuadrícula: 1, 2 o 5 × 10^k. */
    public static double niceStep(double raw) {
        if (!(raw > 0) || Double.isInfinite(raw)) return 1;
        double exp = Math.floor(Math.log10(raw));
        double base = Math.pow(10, exp);
        double f = raw / base;
        double nf = f < 1.5 ? 1 : f < 3.5 ? 2 : f < 7.5 ? 5 : 10;
        return nf * base;
    }

    public static int decimalsFor(double step) {
        if (step >= 1 || !(step > 0)) return 0;
        return Math.min(6, (int) Math.ceil(-Math.log10(step) - 1e-9));
    }

    // ---------------------------------------------------------------- 3D
    /**
     * Proyección paralela (como la órbita de AutoCAD). x=Este, y=Norte, z=Cota.
     * yaw gira alrededor de la vertical; pitch=90° es planta (mirando hacia abajo), 0° es vista de frente.
     * out[0]=x pantalla (derecha +), out[1]=y pantalla (arriba +), out[2]=profundidad (más lejos +).
     */
    public static void project(double x, double y, double z, double yaw, double pitch, double[] out) {
        double cy = Math.cos(yaw), sy = Math.sin(yaw);
        double cp = Math.cos(pitch), sp = Math.sin(pitch);
        double sx = x * cy - y * sy;
        double d0 = x * sy + y * cy;
        out[0] = sx;
        out[1] = z * cp + d0 * sp;
        out[2] = d0 * cp - z * sp;
    }

    /** Ordena idx[0..count) de mayor a menor key (lo lejano primero). Sin recursión, sin límite. */
    public static void sortDesc(int[] idx, double[] key, int count) {
        for (int start = count / 2 - 1; start >= 0; start--) siftDown(idx, key, start, count);
        for (int end = count - 1; end > 0; end--) {
            int t = idx[0]; idx[0] = idx[end]; idx[end] = t;
            siftDown(idx, key, 0, end);
        }
    }

    /** Montículo de mínimos: al terminar queda de mayor a menor. */
    private static void siftDown(int[] idx, double[] key, int root, int size) {
        while (true) {
            int child = 2 * root + 1;
            if (child >= size) return;
            if (child + 1 < size && key[idx[child + 1]] < key[idx[child]]) child++;
            if (key[idx[child]] < key[idx[root]]) {
                int t = idx[root]; idx[root] = idx[child]; idx[child] = t;
                root = child;
            } else return;
        }
    }

    // ---------------------------------------------------------------- nombres
    private static final Pattern TRAILING_NUMBER = Pattern.compile("^(.*?)(\\d+)$");

    /** Siguiente nombre: P9 → P10, 007 → 008, BM → BM1. */
    public static String nextName(String last) {
        String s = last == null ? "" : last.trim();
        if (s.isEmpty()) return "1";
        Matcher m = TRAILING_NUMBER.matcher(s);
        if (!m.matches()) return s + "1";
        String digits = m.group(2);
        if (digits.length() > 15) return s + "-1";
        long next = Long.parseLong(digits) + 1;
        String n = String.valueOf(next);
        while (n.length() < digits.length()) n = "0" + n;
        return m.group(1) + n;
    }

    // ---------------------------------------------------------------- guardar / exportar
    public static String fmt(double v, int decimals) {
        return String.format(Locale.US, "%." + decimals + "f", v);
    }

    /** Formato interno de guardado: una fila por punto, separada por tabulaciones. */
    public static String serialize(List<PlotPoint> pts) {
        StringBuilder sb = new StringBuilder(pts.size() * 48 + 16);
        sb.append("GEOTOPO_VISOR_1\n");
        for (PlotPoint p : pts) {
            sb.append(clean(p.name)).append('\t')
              .append(Double.toString(p.east)).append('\t')
              .append(Double.toString(p.north)).append('\t')
              .append(p.hasZ ? Double.toString(p.z) : "").append('\t')
              .append(clean(p.desc)).append('\t')
              .append(p.breakBefore ? '1' : '0').append('\n');
        }
        return sb.toString();
    }

    public static List<PlotPoint> deserialize(String raw) {
        List<PlotPoint> list = new ArrayList<>();
        if (raw == null) return list;
        String[] lines = raw.split("\n");
        for (String line : lines) {
            if (line.isEmpty() || line.startsWith("GEOTOPO_VISOR")) continue;
            String[] t = line.split("\t", -1);
            if (t.length < 3) continue;
            try {
                double e = Double.parseDouble(t[1]);
                double n = Double.parseDouble(t[2]);
                boolean hasZ = t.length > 3 && !t[3].isEmpty();
                double z = hasZ ? Double.parseDouble(t[3]) : 0;
                String desc = t.length > 4 ? t[4] : "";
                boolean br = t.length > 5 && "1".equals(t[5]);
                list.add(new PlotPoint(t[0], e, n, z, hasZ, desc, br));
            } catch (NumberFormatException ignored) { }
        }
        return list;
    }

    /** Tabla con tabulaciones: se pega directo en Excel. */
    public static String toTable(List<PlotPoint> pts) {
        StringBuilder sb = new StringBuilder(pts.size() * 48 + 64);
        sb.append("Punto\tEste\tNorte\tCota\tDescripción\n");
        for (PlotPoint p : pts) {
            sb.append(p.name).append('\t').append(fmt(p.east, 3)).append('\t').append(fmt(p.north, 3)).append('\t')
              .append(p.hasZ ? fmt(p.z, 3) : "").append('\t').append(p.desc).append('\n');
        }
        return sb.toString();
    }

    /** DXF R12 (lo abre AutoCAD, Civil 3D, ZWCAD, DraftSight...). Capas: PUNTOS, NOMBRES, COTAS, LINEAS. */
    public static String toDxf(List<PlotPoint> pts, List<Run> runs) {
        Bounds b = bounds(pts);
        double size = b.empty() ? 10 : Math.max(b.maxE - b.minE, b.maxN - b.minN);
        double h = niceStep(Math.max(size / 250d, 0.05));
        StringBuilder sb = new StringBuilder(pts.size() * 220 + 512);
        g(sb, 0, "SECTION"); g(sb, 2, "HEADER");
        g(sb, 9, "$ACADVER"); g(sb, 1, "AC1009");
        if (!b.empty()) {
            g(sb, 9, "$EXTMIN"); n(sb, 10, b.minE); n(sb, 20, b.minN); n(sb, 30, b.baseZ());
            g(sb, 9, "$EXTMAX"); n(sb, 10, b.maxE); n(sb, 20, b.maxN); n(sb, 30, b.withZ == 0 ? 0 : b.maxZ);
        }
        g(sb, 0, "ENDSEC");
        g(sb, 0, "SECTION"); g(sb, 2, "ENTITIES");
        for (PlotPoint p : pts) {
            double z = p.hasZ ? p.z : 0;
            g(sb, 0, "POINT"); g(sb, 8, "PUNTOS"); g(sb, 62, "7");
            n(sb, 10, p.east); n(sb, 20, p.north); n(sb, 30, z);
            g(sb, 0, "TEXT"); g(sb, 8, "NOMBRES"); g(sb, 62, "2");
            n(sb, 10, p.east + h * 0.6); n(sb, 20, p.north + h * 0.4); n(sb, 30, z);
            n(sb, 40, h); g(sb, 1, dxfText(p.name));
            if (p.hasZ) {
                g(sb, 0, "TEXT"); g(sb, 8, "COTAS"); g(sb, 62, "3");
                n(sb, 10, p.east + h * 0.6); n(sb, 20, p.north - h * 1.2); n(sb, 30, z);
                n(sb, 40, h * 0.8); g(sb, 1, fmt(p.z, 3));
            }
            if (!p.desc.isEmpty()) {
                g(sb, 0, "TEXT"); g(sb, 8, "DESCRIPCION"); g(sb, 62, "4");
                n(sb, 10, p.east + h * 0.6); n(sb, 20, p.north - h * 2.6); n(sb, 30, z);
                n(sb, 40, h * 0.7); g(sb, 1, dxfText(p.desc));
            }
        }
        if (runs != null) {
            for (Run r : runs) {
                g(sb, 0, "POLYLINE"); g(sb, 8, "LINEAS"); g(sb, 62, "1"); g(sb, 66, "1");
                n(sb, 10, 0); n(sb, 20, 0); n(sb, 30, 0);
                g(sb, 70, r.closed ? "9" : "8");
                for (int i : r.idx) {
                    PlotPoint p = pts.get(i);
                    g(sb, 0, "VERTEX"); g(sb, 8, "LINEAS");
                    n(sb, 10, p.east); n(sb, 20, p.north); n(sb, 30, p.hasZ ? p.z : 0);
                    g(sb, 70, "32");
                }
                g(sb, 0, "SEQEND"); g(sb, 8, "LINEAS");
            }
        }
        g(sb, 0, "ENDSEC");
        g(sb, 0, "EOF");
        return sb.toString();
    }

    private static String dxfText(String s) {
        String c = clean(s);
        return c.isEmpty() ? "-" : c;
    }

    private static void g(StringBuilder sb, int code, String value) {
        sb.append(code).append('\n').append(value).append('\n');
    }

    private static void n(StringBuilder sb, int code, double value) {
        sb.append(code).append('\n').append(fmt(value, 4)).append('\n');
    }
}
