package com.bph.geotopo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * V138: lienzo del Visor de coordenadas.
 * 2D (planta) y 3D con cubo de vistas como AutoCAD, giro libre y suave (con inercia),
 * cambios de vista animados y estilos: Normal, Rayos X, Sólido y Alambre.
 */
public class PlotView extends View {
    public interface Listener {
        void onSelectionChanged();
        void onModeChanged();
    }

    public static final int STYLE_NORMAL = 0;
    public static final int STYLE_XRAY = 1;
    public static final int STYLE_SOLID = 2;
    public static final int STYLE_WIRE = 3;
    public static final String[] STYLE_NAMES = {"Normal", "Rayos X", "Sólido", "Alambre"};

    private static final int BG = Color.rgb(24, 29, 36);
    private static final int BG_XRAY = Color.rgb(10, 16, 26);
    private static final int GRID = Color.argb(46, 160, 190, 220);
    private static final int GRID_TEXT = Color.rgb(140, 160, 182);
    private static final int LINE = Color.rgb(80, 205, 255);
    private static final int[] CODE_COLORS = {
            Color.rgb(80, 205, 255), Color.rgb(255, 214, 10), Color.rgb(255, 120, 90), Color.rgb(120, 230, 120),
            Color.rgb(230, 130, 255), Color.rgb(255, 170, 60), Color.rgb(90, 160, 255), Color.rgb(240, 240, 240)
    };
    private static final double HALF_PI = Math.PI / 2;
    private static final double ISO_PITCH = Math.toRadians(35.264);

    private final float d;
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint grid = new Paint();
    private final Path path = new Path();
    private final DashPathEffect dash;
    private final ScaleGestureDetector scaleDetector;
    private final GestureDetector gestures;

    private List<PlotMath.PlotPoint> pts = new ArrayList<>();
    private List<PlotMath.Run> runs = new ArrayList<>();
    private PlotMath.Bounds bounds = new PlotMath.Bounds();
    private Listener listener;

    // Opciones
    private boolean showNames = true, showZ = true, showDesc = false, showDist = false, colorByZ = true;
    private boolean measureMode = false, mode3d = false;
    private int lineMode = PlotMath.LINES_ORDER;
    private boolean closeLines = false;
    private double exaggeration = 1;
    private int style = STYLE_NORMAL;

    // Vista 2D
    private double cE, cN, s2 = 1;
    // Vista 3D
    private double yaw = Math.toRadians(-45), pitch = ISO_PITCH, s3 = 1, panX, panY;
    private double c3E, c3N, c3Z;
    private boolean fitted;

    // Movimiento suave
    private boolean animating, spinning, inertia, loopPosted;
    private long animStart, lastFrame;
    private static final long ANIM_MS = 520;
    private double aYaw0, aYaw1, aPitch0, aPitch1, aS0, aS1, aPx0, aPx1, aPy0, aPy1;
    private Runnable animEnd;
    private double velYaw, velPitch;

    // Selección
    private int selA = -1, selB = -1;

    // Cubo de vistas (pantalla)
    private final float[][] cubeFace = new float[6][8];
    private final boolean[] cubeVisible = new boolean[6];
    private float homeX, homeY, homeR;

    // Último dibujo
    private float[] sx = new float[0], sy = new float[0];
    private double[] depth = new double[0];
    private int[] order = new int[0];
    private boolean[] labelGrid = new boolean[0];
    private float[] buf = new float[0];
    private final double[] tmp = new double[3];

    private final Runnable frame = new Runnable() {
        @Override public void run() { stepFrame(); }
    };

    public PlotView(Context context) {
        super(context);
        d = context.getResources().getDisplayMetrics().density;
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        fill.setStyle(Paint.Style.FILL);
        text.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL));
        grid.setStyle(Paint.Style.STROKE);
        grid.setStrokeWidth(Math.max(1f, d * 0.7f));
        dash = new DashPathEffect(new float[]{6 * d, 4 * d}, 0);
        setBackgroundColor(BG);
        setFocusable(true);

        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector det) {
                zoomAt(det.getFocusX(), det.getFocusY(), det.getScaleFactor());
                return true;
            }
        });
        gestures = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }

            @Override public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                if (mode3d && e2.getPointerCount() == 1 && !scaleDetector.isInProgress()) orbit(dx, dy);
                else pan(dx, dy);
                return true;
            }

            @Override public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (!mode3d || e2.getPointerCount() > 1 || scaleDetector.isInProgress()) return false;
                velYaw = vx * 0.0055;
                velPitch = vy * 0.0055;
                inertia = true;
                ensureLoop();
                return true;
            }

            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                tap(e.getX(), e.getY());
                return true;
            }

            @Override public boolean onDoubleTap(MotionEvent e) {
                zoomAt(e.getX(), e.getY(), 2f);
                return true;
            }
        });
    }

    // ------------------------------------------------------------ API
    public void setListener(Listener l) { listener = l; }

    public void setPoints(List<PlotMath.PlotPoint> list) {
        pts = list == null ? new ArrayList<PlotMath.PlotPoint>() : list;
        dataChanged();
    }

    public void dataChanged() {
        bounds = PlotMath.bounds(pts);
        runs = PlotMath.buildRuns(pts, lineMode, closeLines);
        if (selA >= pts.size()) selA = -1;
        if (selB >= pts.size()) selB = -1;
        invalidate();
    }

    public List<PlotMath.Run> getRuns() { return runs; }

    public void setOptions(boolean names, boolean z, boolean desc, boolean dist, boolean byZ) {
        showNames = names; showZ = z; showDesc = desc; showDist = dist; colorByZ = byZ;
        invalidate();
    }

    public void setLines(int mode, boolean close) {
        lineMode = mode; closeLines = close;
        runs = PlotMath.buildRuns(pts, lineMode, closeLines);
        invalidate();
    }

    public void setStyle(int s) {
        style = Math.max(0, Math.min(3, s));
        setBackgroundColor(style == STYLE_XRAY ? BG_XRAY : BG);
        invalidate();
    }

    public int getStyle() { return style; }

    public void setExaggeration(double v) {
        exaggeration = v <= 0 ? 1 : v;
        if (mode3d && getWidth() > 0) {
            c3Z = (bounds.minZ + bounds.maxZ) / 2;
            double[] f = computeFit(yaw, pitch);
            animateTo(yaw, pitch, f[0], f[1], f[2], null);
        }
        invalidate();
    }

    public boolean isMode3d() { return mode3d; }

    /** Cambia entre 2D y 3D con una transición suave desde/hacia la planta. */
    public void setMode3d(boolean on) {
        stopMotion();
        if (on == mode3d) return;
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0 || bounds.empty()) {
            mode3d = on;
            fitted = false;
            invalidate();
            if (listener != null) listener.onModeChanged();
            return;
        }
        if (on) {
            // Empieza en planta, igual a lo que se ve en 2D, y baja a isométrico.
            c3E = (bounds.minE + bounds.maxE) / 2;
            c3N = (bounds.minN + bounds.maxN) / 2;
            c3Z = (bounds.minZ + bounds.maxZ) / 2;
            yaw = 0;
            pitch = HALF_PI;
            s3 = s2;
            panX = (c3E - cE) * s2;
            panY = (cN - c3N) * s2;
            mode3d = true;
            double ty = Math.toRadians(-45);
            double[] f = computeFit(ty, ISO_PITCH);
            animateTo(ty, ISO_PITCH, f[0], f[1], f[2], null);
        } else {
            // Sube a planta con el norte arriba y recién pasa a 2D.
            animateTo(0, HALF_PI, s3, panX, panY, () -> {
                double px = -panX / s3, py = panY / s3;
                cE = c3E + px;
                cN = c3N + py;
                s2 = s3;
                mode3d = false;
                invalidate();
                if (listener != null) listener.onModeChanged();
            });
            return;
        }
        if (listener != null) listener.onModeChanged();
    }

    public void setMeasureMode(boolean on) {
        measureMode = on;
        selA = -1; selB = -1;
        invalidate();
        if (listener != null) listener.onSelectionChanged();
    }

    public boolean isMeasureMode() { return measureMode; }
    public int getSelA() { return selA; }
    public int getSelB() { return selB; }

    public void clearSelection() {
        selA = -1; selB = -1;
        invalidate();
        if (listener != null) listener.onSelectionChanged();
    }

    public boolean isSpinning() { return spinning; }

    /** Giro automático (como mesa giratoria) para ver la forma. */
    public void setSpinning(boolean on) {
        if (on && !mode3d) return;
        animating = false;
        inertia = false;
        spinning = on;
        if (on) ensureLoop();
        if (listener != null) listener.onModeChanged();
    }

    public void focusPoint(int index) {
        if (index < 0 || index >= pts.size()) return;
        stopMotion();
        selA = index; selB = -1;
        PlotMath.PlotPoint p = pts.get(index);
        if (mode3d) {
            project3(p, tmp);
            animateTo(yaw, pitch, s3, -tmp[0] * s3, tmp[1] * s3, null);
        } else {
            cE = p.east; cN = p.north;
            if (getWidth() > 0 && s2 < getWidth() / 60.0) s2 = getWidth() / 60.0;
        }
        invalidate();
        if (listener != null) listener.onSelectionChanged();
    }

    public void requestFit() {
        fitted = false;
        invalidate();
    }

    /** Ver todo, con movimiento suave. */
    public void zoomExtents() {
        stopMotion();
        if (getWidth() <= 0) { fitted = false; return; }
        if (mode3d) {
            c3E = (bounds.minE + bounds.maxE) / 2;
            c3N = (bounds.minN + bounds.maxN) / 2;
            c3Z = (bounds.minZ + bounds.maxZ) / 2;
            double[] f = computeFit(yaw, pitch);
            animateTo(yaw, pitch, f[0], f[1], f[2], null);
        } else {
            fit2d();
            invalidate();
        }
    }

    private void goToView(double targetYaw, double targetPitch) {
        stopMotion();
        double[] f = computeFit(targetYaw, targetPitch);
        animateTo(targetYaw, targetPitch, f[0], f[1], f[2], null);
    }

    // ------------------------------------------------------------ encuadre
    private void fit2d() {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        fitted = true;
        if (bounds.empty()) { cE = 0; cN = 0; s2 = Math.min(w, h) / 100.0; return; }
        cE = (bounds.minE + bounds.maxE) / 2;
        cN = (bounds.minN + bounds.maxN) / 2;
        double re = bounds.maxE - bounds.minE, rn = bounds.maxN - bounds.minN;
        if (re < 1e-6 && rn < 1e-6) { s2 = Math.min(w, h) / 20.0; return; }
        double sE = re < 1e-6 ? Double.MAX_VALUE : w * 0.72 / re;
        double sN = rn < 1e-6 ? Double.MAX_VALUE : h * 0.70 / rn;
        s2 = clamp(Math.min(sE, sN), 1e-7, 1e5);
        cE += 18 * d / s2; // deja libre la barra de íconos de la derecha
    }

    private void fit3d() {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        fitted = true;
        c3E = (bounds.minE + bounds.maxE) / 2;
        c3N = (bounds.minN + bounds.maxN) / 2;
        c3Z = (bounds.minZ + bounds.maxZ) / 2;
        double[] f = computeFit(yaw, pitch);
        s3 = f[0]; panX = f[1]; panY = f[2];
    }

    /** Escala y desplazamiento para ver todo con ese ángulo: {escala, panX, panY}. */
    private double[] computeFit(double yw, double pt) {
        int w = Math.max(1, getWidth()), h = Math.max(1, getHeight());
        if (bounds.empty()) return new double[]{Math.min(w, h) / 100.0, 0, 0};
        double minX = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, minY = Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (int i = 0; i < 8; i++) {
            double e = (i & 1) == 0 ? bounds.minE : bounds.maxE;
            double n = (i & 2) == 0 ? bounds.minN : bounds.maxN;
            double z = (i & 4) == 0 ? bounds.minZ : bounds.maxZ;
            PlotMath.project(e - c3E, n - c3N, (z - c3Z) * exaggeration, yw, pt, tmp);
            minX = Math.min(minX, tmp[0]); maxX = Math.max(maxX, tmp[0]);
            minY = Math.min(minY, tmp[1]); maxY = Math.max(maxY, tmp[1]);
        }
        double rx = maxX - minX, ry = maxY - minY, s;
        if (rx < 1e-6 && ry < 1e-6) s = Math.min(w, h) / 20.0;
        else {
            double a = rx < 1e-6 ? Double.MAX_VALUE : w * 0.70 / rx;
            double b = ry < 1e-6 ? Double.MAX_VALUE : h * 0.62 / ry;
            s = clamp(Math.min(a, b), 1e-7, 1e5);
        }
        double px = -(minX + maxX) / 2 * s - 18 * d;
        double py = (minY + maxY) / 2 * s + 20 * d;
        return new double[]{s, px, py};
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (!fitted) { if (mode3d) fit3d(); else fit2d(); }
    }

    // ------------------------------------------------------------ movimiento
    private void animateTo(double yw, double pt, double s, double px, double py, Runnable onEnd) {
        spinning = false;
        inertia = false;
        double y0 = yaw;
        double y1 = yw;
        // Camino más corto
        while (y1 - y0 > Math.PI) y1 -= 2 * Math.PI;
        while (y1 - y0 < -Math.PI) y1 += 2 * Math.PI;
        aYaw0 = y0; aYaw1 = y1;
        aPitch0 = pitch; aPitch1 = pt;
        aS0 = s3; aS1 = s;
        aPx0 = panX; aPx1 = px;
        aPy0 = panY; aPy1 = py;
        animEnd = onEnd;
        animStart = SystemClock.uptimeMillis();
        animating = true;
        ensureLoop();
    }

    private void stopMotion() {
        boolean wasSpinning = spinning;
        animating = false;
        inertia = false;
        spinning = false;
        if (animEnd != null) { Runnable r = animEnd; animEnd = null; r.run(); }
        if (wasSpinning && listener != null) listener.onModeChanged();
    }

    private void ensureLoop() {
        if (loopPosted) return;
        loopPosted = true;
        lastFrame = SystemClock.uptimeMillis();
        postOnAnimation(frame);
    }

    private void stepFrame() {
        loopPosted = false;
        long now = SystemClock.uptimeMillis();
        double dt = Math.min(0.05, Math.max(0, (now - lastFrame) / 1000.0));
        lastFrame = now;
        boolean more = false;
        if (animating) {
            double t = Math.min(1, (now - animStart) / (double) ANIM_MS);
            double e = 1 - Math.pow(1 - t, 3);
            yaw = aYaw0 + (aYaw1 - aYaw0) * e;
            pitch = aPitch0 + (aPitch1 - aPitch0) * e;
            // Zoom suave en escala logarítmica
            s3 = Math.exp(Math.log(aS0) + (Math.log(aS1) - Math.log(aS0)) * e);
            panX = aPx0 + (aPx1 - aPx0) * e;
            panY = aPy0 + (aPy1 - aPy0) * e;
            if (t < 1) more = true;
            else {
                animating = false;
                if (animEnd != null) { Runnable r = animEnd; animEnd = null; r.run(); }
            }
        } else if (spinning) {
            yaw -= 0.55 * dt;
            more = true;
        } else if (inertia) {
            yaw += velYaw * dt;
            pitch = clamp(pitch + velPitch * dt, -HALF_PI, HALF_PI);
            double k = Math.exp(-dt * 3.2);
            velYaw *= k;
            velPitch *= k;
            if (Math.abs(velYaw) < 0.03 && Math.abs(velPitch) < 0.03) inertia = false;
            else more = true;
        }
        invalidate();
        if (more) {
            loopPosted = true;
            postOnAnimation(frame);
        }
    }

    // ------------------------------------------------------------ gestos
    @Override public boolean onTouchEvent(MotionEvent ev) {
        if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
            if (animating || inertia || spinning) stopMotion();
        }
        scaleDetector.onTouchEvent(ev);
        gestures.onTouchEvent(ev);
        return true;
    }

    private void zoomAt(float fx, float fy, float factor) {
        if (Float.isNaN(factor) || factor <= 0) return;
        float w = getWidth(), h = getHeight();
        if (mode3d) {
            double ns = clamp(s3 * factor, 1e-7, 1e5);
            double px = (fx - w / 2 - panX) / s3, py = (fy - h / 2 - panY) / s3;
            panX = fx - w / 2 - px * ns;
            panY = fy - h / 2 - py * ns;
            s3 = ns;
        } else {
            double wE = cE + (fx - w / 2) / s2, wN = cN - (fy - h / 2) / s2;
            double ns = clamp(s2 * factor, 1e-7, 1e5);
            cE = wE - (fx - w / 2) / ns;
            cN = wN + (fy - h / 2) / ns;
            s2 = ns;
        }
        invalidate();
    }

    private void pan(float dx, float dy) {
        if (mode3d) { panX -= dx; panY -= dy; }
        else { cE += dx / s2; cN -= dy / s2; }
        invalidate();
    }

    /** Giro libre: horizontal sin límite, vertical desde abajo hasta arriba. */
    private void orbit(float dx, float dy) {
        yaw -= dx * 0.0075; // dedo a la derecha: el modelo gira a la derecha
        pitch = clamp(pitch - dy * 0.0075, -HALF_PI, HALF_PI);
        invalidate();
    }

    private void tap(float x, float y) {
        if (mode3d && tapCube(x, y)) return;
        int best = -1;
        float bestD = 30 * d;
        int n = Math.min(pts.size(), sx.length);
        for (int i = 0; i < n; i++) {
            float ddx = sx[i] - x, ddy = sy[i] - y;
            float dist = (float) Math.sqrt(ddx * ddx + ddy * ddy);
            if (dist < bestD) { bestD = dist; best = i; }
        }
        if (best < 0) {
            if (!measureMode) { selA = -1; selB = -1; }
        } else if (measureMode) {
            if (selA < 0 || selB >= 0) { selA = best; selB = -1; }
            else if (best != selA) selB = best;
        } else {
            selA = best; selB = -1;
        }
        invalidate();
        if (listener != null) listener.onSelectionChanged();
    }

    // ------------------------------------------------------------ dibujo
    @Override protected void onDraw(Canvas cv) {
        super.onDraw(cv);
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        if (!fitted) { if (mode3d) fit3d(); else fit2d(); }
        int n = pts.size();
        ensureArrays(n);
        if (n == 0) {
            drawEmpty(cv, w, h);
            return;
        }
        if (mode3d) draw3d(cv, w, h, n); else draw2d(cv, w, h, n);
        if (colorByZ && bounds.zRange() > 1e-9 && style != STYLE_WIRE) drawLegend(cv);
    }

    private void ensureArrays(int n) {
        if (sx.length < n) {
            int cap = Math.max(n, 16);
            sx = new float[cap]; sy = new float[cap]; depth = new double[cap]; order = new int[cap];
        }
    }

    private void drawEmpty(Canvas cv, int w, int h) {
        drawGrid2d(cv, w, h);
        label(cv, "Sin puntos", w / 2f, h / 2f - 8 * d, 17, Color.rgb(220, 232, 245), true, Paint.Align.CENTER);
        label(cv, "Pégalos en «Datos»", w / 2f, h / 2f + 16 * d, 13, GRID_TEXT, false, Paint.Align.CENTER);
    }

    // ---------- 2D
    private float toX(double e, int w) { return (float) (w / 2.0 + (e - cE) * s2); }
    private float toY(double n, int h) { return (float) (h / 2.0 - (n - cN) * s2); }

    private void draw2d(Canvas cv, int w, int h, int n) {
        if (style != STYLE_XRAY) drawGrid2d(cv, w, h);
        for (int i = 0; i < n; i++) {
            PlotMath.PlotPoint p = pts.get(i);
            sx[i] = toX(p.east, w);
            sy[i] = toY(p.north, h);
        }
        drawFaces(cv, false);
        drawRuns(cv, w, h);
        if (showDist && style != STYLE_WIRE) drawDistances(cv, w, h);
        drawMeasureLine(cv);
        drawPoints(cv, w, h, n, null);
        drawSelection(cv);
        drawNorth2d(cv, w);
        drawScaleBar(cv, h, s2);
    }

    private void drawGrid2d(Canvas cv, int w, int h) {
        double step = PlotMath.niceStep(w / s2 / 5.0);
        int dec = PlotMath.decimalsFor(step);
        double minE = cE - w / 2.0 / s2, maxE = cE + w / 2.0 / s2;
        double minN = cN - h / 2.0 / s2, maxN = cN + h / 2.0 / s2;
        grid.setColor(GRID);
        text.setShadowLayer(0, 0, 0, 0);
        int guard = 0;
        for (double e = Math.ceil(minE / step) * step; e <= maxE && guard < 200; e += step, guard++) {
            float x = toX(e, w);
            cv.drawLine(x, 0, x, h, grid);
            label(cv, PlotMath.fmt(e, dec), x + 3 * d, h - 6 * d, 9, GRID_TEXT, false, Paint.Align.LEFT);
        }
        guard = 0;
        for (double nn = Math.ceil(minN / step) * step; nn <= maxN && guard < 200; nn += step, guard++) {
            float y = toY(nn, h);
            cv.drawLine(0, y, w, y, grid);
            label(cv, PlotMath.fmt(nn, dec), 4 * d, y - 3 * d, 9, GRID_TEXT, false, Paint.Align.LEFT);
        }
    }

    private void drawDistances(Canvas cv, int w, int h) {
        int drawn = 0;
        text.setTextSize(10.5f * d);
        text.setTextAlign(Paint.Align.CENTER);
        text.setColor(Color.rgb(255, 230, 140));
        text.setShadowLayer(3 * d, 0, 0, Color.BLACK);
        for (PlotMath.Run r : runs) {
            int segs = r.closed ? r.idx.length : r.idx.length - 1;
            for (int k = 0; k < segs && drawn < 500; k++) {
                int a = r.idx[k], b = r.idx[(k + 1) % r.idx.length];
                float x1 = sx[a], y1 = sy[a], x2 = sx[b], y2 = sy[b];
                float len = (float) Math.hypot(x2 - x1, y2 - y1);
                if (len < 70 * d) continue;
                float mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
                if (mx < 0 || my < 0 || mx > w || my > h) continue;
                float ang = (float) Math.toDegrees(Math.atan2(y2 - y1, x2 - x1));
                if (ang > 90) ang -= 180; else if (ang < -90) ang += 180;
                cv.save();
                cv.rotate(ang, mx, my);
                cv.drawText(PlotMath.fmt(PlotMath.horizontal(pts.get(a), pts.get(b)), 2) + " m", mx, my - 4 * d, text);
                cv.restore();
                drawn++;
            }
        }
        text.setShadowLayer(0, 0, 0, 0);
    }

    private void drawNorth2d(Canvas cv, int w) {
        float cx = w - 30 * d, cy = 34 * d, r = 15 * d;
        fill.setColor(Color.argb(150, 10, 16, 24));
        cv.drawCircle(cx, cy, r + 5 * d, fill);
        drawArrow(cv, cx, cy, 0f, -1f, r);
        label(cv, "N", cx, cy - r - 8 * d, 12, Color.WHITE, true, Paint.Align.CENTER);
    }

    private void drawArrow(Canvas cv, float cx, float cy, float ux, float uy, float r) {
        float px = -uy, py = ux;
        float tipX = cx + ux * r, tipY = cy + uy * r;
        float tailX = cx - ux * r * 0.75f, tailY = cy - uy * r * 0.75f;
        float wdt = r * 0.38f;
        path.reset();
        path.moveTo(tipX, tipY);
        path.lineTo(cx + px * wdt, cy + py * wdt);
        path.lineTo(tailX, tailY);
        path.close();
        fill.setColor(Color.WHITE);
        cv.drawPath(path, fill);
        path.reset();
        path.moveTo(tipX, tipY);
        path.lineTo(cx - px * wdt, cy - py * wdt);
        path.lineTo(tailX, tailY);
        path.close();
        fill.setColor(Color.rgb(230, 70, 60));
        cv.drawPath(path, fill);
    }

    private void drawScaleBar(Canvas cv, int h, double pxPerM) {
        if (!(pxPerM > 0)) return;
        double len = PlotMath.niceStep(100 * d / pxPerM);
        float px = (float) (len * pxPerM);
        float x0 = 14 * d, y0 = h - 24 * d, bh = 5 * d;
        fill.setColor(Color.argb(150, 10, 16, 24));
        cv.drawRoundRect(new RectF(x0 - 6 * d, y0 - 19 * d, x0 + px + 30 * d, y0 + bh + 6 * d), 6 * d, 6 * d, fill);
        for (int i = 0; i < 4; i++) {
            fill.setColor(i % 2 == 0 ? Color.WHITE : Color.rgb(40, 46, 54));
            cv.drawRect(x0 + px * i / 4f, y0, x0 + px * (i + 1) / 4f, y0 + bh, fill);
        }
        label(cv, "0", x0, y0 - 5 * d, 10, Color.WHITE, false, Paint.Align.CENTER);
        label(cv, scaleText(len), x0 + px, y0 - 5 * d, 10, Color.WHITE, true, Paint.Align.CENTER);
    }

    private static String scaleText(double m) {
        if (m >= 1000) return PlotMath.fmt(m / 1000, m % 1000 == 0 ? 0 : 1) + " km";
        if (m >= 1) return PlotMath.fmt(m, 0) + " m";
        if (m >= 0.01) return PlotMath.fmt(m * 100, 0) + " cm";
        return PlotMath.fmt(m * 1000, 0) + " mm";
    }

    // ---------- 3D
    private void project3(PlotMath.PlotPoint p, double[] out) {
        double z = p.hasZ ? p.z : bounds.baseZ();
        PlotMath.project(p.east - c3E, p.north - c3N, (z - c3Z) * exaggeration, yaw, pitch, out);
    }

    private float sx3(double px, int w) { return (float) (w / 2.0 + panX + px * s3); }
    private float sy3(double py, int h) { return (float) (h / 2.0 + panY - py * s3); }

    private void draw3d(Canvas cv, int w, int h, int n) {
        double baseZ = (bounds.baseZ() - c3Z) * exaggeration;
        if (style != STYLE_XRAY) drawGround(cv, w, h, baseZ);
        for (int i = 0; i < n; i++) {
            project3(pts.get(i), tmp);
            sx[i] = sx3(tmp[0], w);
            sy[i] = sy3(tmp[1], h);
            depth[i] = tmp[2];
            order[i] = i;
        }
        if (style == STYLE_NORMAL && bounds.zRange() > 1e-9 && n <= 6000) {
            line.setPathEffect(null);
            line.setStrokeWidth(Math.max(1f, 0.8f * d));
            line.setColor(Color.argb(45, 200, 210, 225));
            for (int i = 0; i < n; i++) {
                PlotMath.PlotPoint p = pts.get(i);
                if (!p.hasZ) continue;
                PlotMath.project(p.east - c3E, p.north - c3N, baseZ, yaw, pitch, tmp);
                cv.drawLine(sx[i], sy[i], sx3(tmp[0], w), sy3(tmp[1], h), line);
            }
        }
        drawFaces(cv, true);
        drawRuns(cv, w, h);
        drawMeasureLine(cv);
        PlotMath.sortDesc(order, depth, n);
        drawPoints(cv, w, h, n, order);
        drawSelection(cv);
        drawAxes(cv, h);
        drawCube(cv, w);
    }

    private void drawGround(Canvas cv, int w, int h, double baseZ) {
        if (bounds.empty()) return;
        double span = Math.max(bounds.maxE - bounds.minE, bounds.maxN - bounds.minN);
        if (span < 1e-6) span = 20;
        double step = PlotMath.niceStep(span / 8.0);
        double e0 = Math.floor(bounds.minE / step) * step - step, e1 = Math.ceil(bounds.maxE / step) * step + step;
        double n0 = Math.floor(bounds.minN / step) * step - step, n1 = Math.ceil(bounds.maxN / step) * step + step;
        grid.setColor(Color.argb(38, 160, 190, 220));
        int guard = 0;
        for (double e = e0; e <= e1 + 1e-9 && guard < 80; e += step, guard++) {
            PlotMath.project(e - c3E, n0 - c3N, baseZ, yaw, pitch, tmp);
            float ax = sx3(tmp[0], w), ay = sy3(tmp[1], h);
            PlotMath.project(e - c3E, n1 - c3N, baseZ, yaw, pitch, tmp);
            cv.drawLine(ax, ay, sx3(tmp[0], w), sy3(tmp[1], h), grid);
        }
        guard = 0;
        for (double nn = n0; nn <= n1 + 1e-9 && guard < 80; nn += step, guard++) {
            PlotMath.project(e0 - c3E, nn - c3N, baseZ, yaw, pitch, tmp);
            float ax = sx3(tmp[0], w), ay = sy3(tmp[1], h);
            PlotMath.project(e1 - c3E, nn - c3N, baseZ, yaw, pitch, tmp);
            cv.drawLine(ax, ay, sx3(tmp[0], w), sy3(tmp[1], h), grid);
        }
    }

    private void drawAxes(Canvas cv, int h) {
        float ox = 36 * d, oy = h - 40 * d, len = 22 * d;
        fill.setColor(Color.argb(140, 10, 16, 24));
        cv.drawCircle(ox, oy, len + 10 * d, fill);
        double[][] axes = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
        int[] colors = {Color.rgb(240, 80, 70), Color.rgb(90, 220, 110), Color.rgb(90, 150, 255)};
        String[] names = {"E", "N", "Z"};
        line.setPathEffect(null);
        line.setStrokeWidth(2.2f * d);
        for (int i = 0; i < 3; i++) {
            PlotMath.project(axes[i][0], axes[i][1], axes[i][2], yaw, pitch, tmp);
            float ex = ox + (float) tmp[0] * len, ey = oy - (float) tmp[1] * len;
            line.setColor(colors[i]);
            cv.drawLine(ox, oy, ex, ey, line);
            label(cv, names[i], ox + (float) tmp[0] * (len + 7 * d), oy - (float) tmp[1] * (len + 7 * d) + 4 * d,
                    10, colors[i], true, Paint.Align.CENTER);
        }
    }

    // ---------- Cubo de vistas (como AutoCAD)
    // Caras: 0 arriba, 1 abajo, 2 sur (frente), 3 norte, 4 este, 5 oeste.
    private static final int[][] FACE_V = {
            {4, 5, 7, 6}, {0, 2, 3, 1}, {0, 1, 5, 4}, {2, 6, 7, 3}, {1, 3, 7, 5}, {0, 4, 6, 2}};
    private static final double[][] FACE_N = {
            {0, 0, 1}, {0, 0, -1}, {0, -1, 0}, {0, 1, 0}, {1, 0, 0}, {-1, 0, 0}};
    private static final String[] FACE_LABEL = {"ARRIBA", "ABAJO", "SUR", "NORTE", "ESTE", "OESTE"};

    private float cubeCx(int w) { return w - 50 * d; }
    private float cubeCy() { return 56 * d; }
    private float cubeA() { return 19 * d; }

    /**
     * Ángulos con los que se dibuja el cubo: casi los mismos de la vista, pero siempre
     * un poco de lado para que se vean 3 caras y se pueda tocar cualquiera.
     */
    private double cubeYaw() {
        double q = Math.PI / 2;
        double base = Math.floor(yaw / q) * q;
        double off = yaw - base;
        if (off < 0.32) off = 0.32;
        if (off > q - 0.32) off = q - 0.32;
        return base + off;
    }

    private double cubePitch() {
        double p = pitch;
        if (p > 1.2) p = 1.2;
        if (p < -1.2) p = -1.2;
        if (Math.abs(p) < 0.32) p = p < 0 ? -0.32 : 0.32;
        return p;
    }

    private void drawCube(Canvas cv, int w) {
        float cx = cubeCx(w), cy = cubeCy(), a = cubeA();
        double cyaw = cubeYaw(), cpitch = cubePitch();
        // Fondo y brújula
        fill.setColor(Color.argb(120, 10, 16, 24));
        cv.drawCircle(cx, cy, a * 2.35f, fill);
        line.setPathEffect(null);
        line.setStrokeWidth(1.4f * d);
        line.setColor(Color.argb(170, 170, 190, 210));
        path.reset();
        for (int k = 0; k <= 36; k++) {
            double ang = k * Math.PI * 2 / 36;
            PlotMath.project(Math.cos(ang) * 1.75, Math.sin(ang) * 1.75, -1, cyaw, cpitch, tmp);
            float x = cx + (float) tmp[0] * a, y = cy - (float) tmp[1] * a;
            if (k == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        cv.drawPath(path, line);
        PlotMath.project(0, 2.05, -1, cyaw, cpitch, tmp);
        label(cv, "N", cx + (float) tmp[0] * a, cy - (float) tmp[1] * a + 4 * d, 11, Color.rgb(255, 110, 100), true, Paint.Align.CENTER);

        // Vértices del cubo
        float[] vx = new float[8], vy = new float[8];
        for (int i = 0; i < 8; i++) {
            double x = (i & 1) == 0 ? -1 : 1, y = (i & 2) == 0 ? -1 : 1, z = (i & 4) == 0 ? -1 : 1;
            PlotMath.project(x, y, z, cyaw, cpitch, tmp);
            vx[i] = cx + (float) tmp[0] * a;
            vy[i] = cy - (float) tmp[1] * a;
        }
        for (int f = 0; f < 6; f++) {
            PlotMath.project(FACE_N[f][0], FACE_N[f][1], FACE_N[f][2], cyaw, cpitch, tmp);
            double facing = -tmp[2];
            cubeVisible[f] = facing > 0.02;
            for (int k = 0; k < 4; k++) {
                cubeFace[f][k * 2] = vx[FACE_V[f][k]];
                cubeFace[f][k * 2 + 1] = vy[FACE_V[f][k]];
            }
            if (!cubeVisible[f]) continue;
            path.reset();
            path.moveTo(cubeFace[f][0], cubeFace[f][1]);
            for (int k = 1; k < 4; k++) path.lineTo(cubeFace[f][k * 2], cubeFace[f][k * 2 + 1]);
            path.close();
            int shade = (int) (95 + 120 * facing);
            fill.setColor(Color.rgb(Math.min(255, shade - 10), Math.min(255, shade + 5), Math.min(255, shade + 25)));
            cv.drawPath(path, fill);
            line.setColor(Color.rgb(30, 40, 54));
            line.setStrokeWidth(1.2f * d);
            cv.drawPath(path, line);
            if (facing > 0.45) {
                float mx = 0, my = 0;
                for (int k = 0; k < 4; k++) { mx += cubeFace[f][k * 2]; my += cubeFace[f][k * 2 + 1]; }
                label(cv, FACE_LABEL[f], mx / 4, my / 4 + 3 * d, 7.5f, Color.rgb(20, 30, 44), true, Paint.Align.CENTER);
            }
        }
        // Botón casa (isométrico)
        homeX = cx - a * 2.05f;
        homeY = cy - a * 1.85f;
        homeR = 11 * d;
        fill.setColor(Color.argb(190, 30, 44, 62));
        cv.drawCircle(homeX, homeY, homeR, fill);
        fill.setColor(Color.rgb(220, 232, 245));
        path.reset();
        float hs = 6 * d;
        path.moveTo(homeX, homeY - hs);
        path.lineTo(homeX + hs, homeY);
        path.lineTo(homeX + hs * 0.65f, homeY);
        path.lineTo(homeX + hs * 0.65f, homeY + hs * 0.85f);
        path.lineTo(homeX - hs * 0.65f, homeY + hs * 0.85f);
        path.lineTo(homeX - hs * 0.65f, homeY);
        path.lineTo(homeX - hs, homeY);
        path.close();
        cv.drawPath(path, fill);
    }

    private boolean tapCube(float x, float y) {
        int w = getWidth();
        float cx = cubeCx(w), cy = cubeCy(), a = cubeA();
        if (Math.hypot(x - homeX, y - homeY) <= homeR + 8 * d) {
            goToView(Math.toRadians(-45), ISO_PITCH);
            return true;
        }
        if (Math.hypot(x - cx, y - cy) > a * 2.35f) return false;
        for (int f = 0; f < 6; f++) {
            if (!cubeVisible[f]) continue;
            if (inside(cubeFace[f], x, y)) {
                switch (f) {
                    case 0: goToView(0, HALF_PI); break;                 // planta
                    case 1: goToView(0, -HALF_PI); break;                // desde abajo
                    case 2: goToView(0, 0); break;                       // desde el sur
                    case 3: goToView(Math.PI, 0); break;                 // desde el norte
                    case 4: goToView(-HALF_PI, 0); break;                // desde el este
                    case 5: goToView(HALF_PI, 0); break;                 // desde el oeste
                    default: break;
                }
                return true;
            }
        }
        return true; // tocó cerca del cubo: no selecciona puntos
    }

    private static boolean inside(float[] poly, float x, float y) {
        boolean in = false;
        for (int i = 0, j = 3; i < 4; j = i++) {
            float xi = poly[i * 2], yi = poly[i * 2 + 1], xj = poly[j * 2], yj = poly[j * 2 + 1];
            if ((yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi + 1e-9f) + xi) in = !in;
        }
        return in;
    }

    // ---------- común
    /** Polígonos cerrados con relleno (Sólido) o transparente (Rayos X). */
    private void drawFaces(Canvas cv, boolean three) {
        if (style != STYLE_SOLID && style != STYLE_XRAY) return;
        List<PlotMath.Run> loops = new ArrayList<>();
        for (PlotMath.Run r : runs) if (PlotMath.isLoop(pts, r)) loops.add(r);
        if (loops.isEmpty()) return;
        int m = loops.size();
        double[] key = new double[m];
        int[] idx = new int[m];
        for (int k = 0; k < m; k++) {
            idx[k] = k;
            double sum = 0;
            for (int i : loops.get(k).idx) sum += three ? depth[i] : -pts.get(i).z;
            key[k] = sum / loops.get(k).idx.length;
        }
        PlotMath.sortDesc(idx, key, m);
        for (int k = 0; k < m; k++) {
            PlotMath.Run r = loops.get(idx[k]);
            path.reset();
            double zSum = 0;
            int zc = 0;
            for (int j = 0; j < r.idx.length; j++) {
                int i = r.idx[j];
                if (j == 0) path.moveTo(sx[i], sy[i]); else path.lineTo(sx[i], sy[i]);
                if (pts.get(i).hasZ) { zSum += pts.get(i).z; zc++; }
            }
            path.close();
            int base = colorByZ && zc > 0 && bounds.zRange() > 1e-9
                    ? rampColor((zSum / zc - bounds.minZ) / bounds.zRange()) : Color.rgb(90, 170, 230);
            fill.setColor(Color.argb(style == STYLE_SOLID ? 165 : 34,
                    Color.red(base), Color.green(base), Color.blue(base)));
            cv.drawPath(path, fill);
        }
    }

    private void drawRuns(Canvas cv, int w, int h) {
        line.setPathEffect(null);
        int colorIndex = 0;
        for (PlotMath.Run r : runs) {
            int segs = r.closed ? r.idx.length : r.idx.length - 1;
            if (buf.length < segs * 4) buf = new float[Math.max(segs * 4, 64)];
            int k = 0;
            for (int s = 0; s < segs; s++) {
                int a = r.idx[s], b = r.idx[(s + 1) % r.idx.length];
                float x1 = sx[a], y1 = sy[a], x2 = sx[b], y2 = sy[b];
                if ((x1 < 0 && x2 < 0) || (y1 < 0 && y2 < 0) || (x1 > w && x2 > w) || (y1 > h && y2 > h)) continue;
                buf[k++] = x1; buf[k++] = y1; buf[k++] = x2; buf[k++] = y2;
            }
            int c = lineMode == PlotMath.LINES_CODE ? CODE_COLORS[colorIndex % CODE_COLORS.length] : LINE;
            colorIndex++;
            if (k == 0) continue;
            if (style == STYLE_XRAY) {
                line.setStrokeWidth(6f * d);
                line.setColor(Color.argb(40, Color.red(c), Color.green(c), Color.blue(c)));
                cv.drawLines(buf, 0, k, line);
                line.setStrokeWidth(1.6f * d);
                line.setColor(Color.argb(200, Color.red(c), Color.green(c), Color.blue(c)));
            } else if (style == STYLE_SOLID) {
                line.setStrokeWidth(1.6f * d);
                line.setColor(Color.argb(230, 20, 26, 34));
            } else {
                line.setStrokeWidth((style == STYLE_WIRE ? 2.2f : 1.8f) * d);
                line.setColor(c);
            }
            cv.drawLines(buf, 0, k, line);
        }
    }

    private void drawPoints(Canvas cv, int w, int h, int n, int[] drawOrder) {
        boolean hidePoints = style == STYLE_WIRE && !runs.isEmpty();
        int visible = 0;
        for (int i = 0; i < n; i++) if (sx[i] >= -10 && sy[i] >= -10 && sx[i] <= w + 10 && sy[i] <= h + 10) visible++;
        boolean light = visible > 4000 || style == STYLE_XRAY || style == STYLE_SOLID;
        float r = (visible > 4000 ? 2.2f : style == STYLE_XRAY ? 2.6f : mode3d ? 3.6f : 3.2f) * d;
        line.setPathEffect(null);

        if (!hidePoints) {
            for (int k = 0; k < n; k++) {
                int i = drawOrder == null ? k : drawOrder[k];
                float x = sx[i], y = sy[i];
                if (x < -10 || y < -10 || x > w + 10 || y > h + 10) continue;
                int c = pointColor(pts.get(i));
                if (mode3d || light) {
                    fill.setColor(style == STYLE_XRAY ? Color.argb(170, Color.red(c), Color.green(c), Color.blue(c)) : c);
                    cv.drawCircle(x, y, r, fill);
                    if (!light) {
                        line.setColor(Color.argb(200, 0, 0, 0));
                        line.setStrokeWidth(1f * d);
                        cv.drawCircle(x, y, r, line);
                    }
                } else {
                    line.setColor(c);
                    line.setStrokeWidth(1.4f * d);
                    float a = r * 1.6f;
                    cv.drawLine(x - a, y, x + a, y, line);
                    cv.drawLine(x, y - a, x, y + a, line);
                    cv.drawCircle(x, y, r, line);
                }
            }
        }
        if (style == STYLE_WIRE || (!showNames && !showZ && !showDesc)) return;
        float cell = 64 * d, cellH = 16 * d;
        int cols = (int) (w / cell) + 2, rows = (int) (h / cellH) + 2;
        if (labelGrid.length < cols * rows) labelGrid = new boolean[cols * rows];
        Arrays.fill(labelGrid, 0, cols * rows, false);
        for (int k = n - 1; k >= 0; k--) {
            int i = drawOrder == null ? n - 1 - k : drawOrder[k];
            float x = sx[i], y = sy[i];
            if (x < 0 || y < 0 || x > w || y > h) continue;
            PlotMath.PlotPoint p = pts.get(i);
            int lines = (showNames ? 1 : 0) + (showZ && p.hasZ ? 1 : 0) + (showDesc && !p.desc.isEmpty() ? 1 : 0);
            if (lines == 0) continue;
            int gx = (int) (x / cell), gy = (int) (y / cellH);
            boolean free = true;
            for (int j = 0; j < lines && free; j++) {
                int row = gy - 1 + j;
                if (row < 0 || row >= rows || gx >= cols) { free = false; break; }
                if (labelGrid[row * cols + gx] || (gx + 1 < cols && labelGrid[row * cols + gx + 1])) free = false;
            }
            if (!free) continue;
            for (int j = 0; j < lines; j++) {
                int row = gy - 1 + j;
                labelGrid[row * cols + gx] = true;
                if (gx + 1 < cols) labelGrid[row * cols + gx + 1] = true;
            }
            float tx = x + 6 * d, ty = y - 5 * d;
            text.setShadowLayer(2.5f * d, 0, 0, Color.BLACK);
            if (showNames) {
                label(cv, p.name, tx, ty, 11, Color.WHITE, true, Paint.Align.LEFT);
                ty += 12.5f * d;
            }
            if (showZ && p.hasZ) {
                label(cv, PlotMath.fmt(p.z, 2), tx, ty, 10, Color.rgb(150, 235, 160), false, Paint.Align.LEFT);
                ty += 12f * d;
            }
            if (showDesc && !p.desc.isEmpty()) label(cv, p.desc, tx, ty, 10, Color.rgb(255, 214, 120), false, Paint.Align.LEFT);
            text.setShadowLayer(0, 0, 0, 0);
        }
    }

    private void drawMeasureLine(Canvas cv) {
        if (selA < 0 || selB < 0 || selA >= pts.size() || selB >= pts.size()) return;
        line.setPathEffect(dash);
        line.setColor(Color.rgb(255, 214, 10));
        line.setStrokeWidth(2.2f * d);
        cv.drawLine(sx[selA], sy[selA], sx[selB], sy[selB], line);
        line.setPathEffect(null);
    }

    private void drawSelection(Canvas cv) {
        line.setPathEffect(null);
        line.setStrokeWidth(2.6f * d);
        if (selA >= 0 && selA < pts.size()) {
            line.setColor(Color.rgb(90, 230, 140));
            cv.drawCircle(sx[selA], sy[selA], 11 * d, line);
            if (measureMode) label(cv, "A", sx[selA] - 15 * d, sy[selA] - 12 * d, 12, Color.rgb(90, 230, 140), true, Paint.Align.CENTER);
        }
        if (selB >= 0 && selB < pts.size()) {
            line.setColor(Color.rgb(255, 150, 60));
            cv.drawCircle(sx[selB], sy[selB], 11 * d, line);
            label(cv, "B", sx[selB] - 15 * d, sy[selB] - 12 * d, 12, Color.rgb(255, 150, 60), true, Paint.Align.CENTER);
        }
    }

    /** Leyenda de cotas pequeña, arriba a la izquierda. */
    private void drawLegend(Canvas cv) {
        float x = 10 * d, y = 10 * d, bw = 96 * d, bh = 7 * d;
        fill.setColor(Color.argb(150, 10, 16, 24));
        cv.drawRoundRect(new RectF(x - 4 * d, y - 4 * d, x + bw + 4 * d, y + bh + 18 * d), 6 * d, 6 * d, fill);
        int[] colors = {rampColor(0), rampColor(0.25), rampColor(0.5), rampColor(0.75), rampColor(1)};
        fill.setShader(new LinearGradient(x, 0, x + bw, 0, colors, new float[]{0f, 0.25f, 0.5f, 0.75f, 1f}, Shader.TileMode.CLAMP));
        cv.drawRect(x, y, x + bw, y + bh, fill);
        fill.setShader(null);
        label(cv, PlotMath.fmt(bounds.minZ, 1), x, y + bh + 12 * d, 9, Color.WHITE, false, Paint.Align.LEFT);
        label(cv, PlotMath.fmt(bounds.maxZ, 1), x + bw, y + bh + 12 * d, 9, Color.WHITE, false, Paint.Align.RIGHT);
        if (mode3d && Math.abs(exaggeration - 1) > 1e-9)
            label(cv, "Z×" + PlotMath.fmt(exaggeration, 0), x + bw / 2, y + bh + 12 * d, 9, Color.rgb(255, 214, 10), true, Paint.Align.CENTER);
    }

    private int pointColor(PlotMath.PlotPoint p) {
        if (!colorByZ || !p.hasZ || bounds.zRange() <= 1e-9) return p.hasZ || !colorByZ ? Color.WHITE : Color.rgb(170, 178, 190);
        return rampColor((p.z - bounds.minZ) / bounds.zRange());
    }

    static int rampColor(double t) {
        t = clamp(t, 0, 1);
        int[][] c = {{50, 100, 255}, {0, 200, 255}, {50, 220, 120}, {255, 214, 10}, {255, 70, 60}};
        double pos = t * 4;
        int i = Math.min(3, (int) Math.floor(pos));
        double f = pos - i;
        return Color.rgb((int) (c[i][0] + (c[i + 1][0] - c[i][0]) * f),
                (int) (c[i][1] + (c[i + 1][1] - c[i][1]) * f),
                (int) (c[i][2] + (c[i + 1][2] - c[i][2]) * f));
    }

    private void label(Canvas cv, String value, float x, float y, float sizeSp, int color, boolean bold, Paint.Align align) {
        text.setTextSize(sizeSp * d);
        text.setColor(color);
        text.setTextAlign(align);
        text.setFakeBoldText(bold);
        cv.drawText(value, x, y, text);
        text.setFakeBoldText(false);
    }

    private static double clamp(double v, double min, double max) {
        return v < min ? min : v > max ? max : v;
    }
}
