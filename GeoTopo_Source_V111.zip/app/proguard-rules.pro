# GeoTopo - reglas de ofuscacion para el build de release.

# MapLibre usa reflexion e interfaces nativas: se conserva completo.
-keep class org.maplibre.** { *; }
-keep interface org.maplibre.** { *; }
-dontwarn org.maplibre.**

# Las Activities se declaran por nombre en el AndroidManifest.
-keep class com.bph.geotopo.** extends android.app.Activity
-keep class com.bph.geotopo.TrackService

# Metodos llamados desde XML o por reflexion del framework.
-keepclassmembers class * {
    public void onContentChanged();
    public void *(android.view.View);
}

# Anotaciones y firmas necesarias para JSON y genericos.
-keepattributes Signature, InnerClasses, EnclosingMethod, *Annotation*

# Evita avisos por clases opcionales que no se empaquetan.
-dontwarn javax.annotation.**
-dontwarn org.jetbrains.annotations.**
