package com.bph.geotopo;

import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AreaActivity extends BaseToolActivity {
    private static final int REQ_EXPORT = 9501;

    // Dedicated palette for the approved Area/Perimeter design 2.
    private static final int SCREEN_BG = Color.rgb(3, 20, 33);
    private static final int BAR_A = Color.rgb(5, 45, 72);
    private static final int BAR_B = Color.rgb(4, 29, 47);
    private static final int CARD_A = Color.rgb(13, 36, 57);
    private static final int CARD_B = Color.rgb(8, 27, 43);
    private static final int FIELD_BG = Color.rgb(7, 25, 40);
    private static final int BORDER = Color.rgb(42, 100, 159);
    private static final int BORDER_BRIGHT = Color.rgb(31, 130, 242);
    private static final int TEXT = Color.rgb(246, 249, 252);
    private static final int SUBTEXT = Color.rgb(191, 205, 219);
    private static final int MUTED = Color.rgb(118, 143, 170);
    private static final int BLUE = Color.rgb(48, 139, 255);
    private static final int BLUE_2 = Color.rgb(19, 95, 234);
    private static final int GREEN = Color.rgb(119, 209, 71);
    private static final int RED = Color.rgb(255, 107, 107);

    private final List<Row> rows = new ArrayList<>();
    private LinearLayout rowContainer;
    private TextView vertexCountValue;
    private TextView vertexCountPill;
    private TextView statusValue;
    private TextView areaValue;
    private TextView perimeterValue;
    private TextView resultNote;
    private Button exportButton;
    private String lastCsv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();

        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(Color.rgb(2, 13, 23));
            getWindow().setNavigationBarColor(Color.BLACK);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(SCREEN_BG);
        root.addView(buildTopBar(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setBackgroundColor(SCREEN_BG);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12), dp(11), dp(12), dp(28));
        content.setBackgroundColor(SCREEN_BG);

        content.addView(buildTerrainSummary());
        content.addView(buildInstructionStrip());
        content.addView(buildVertexCard());
        content.addView(buildActionArea());
        content.addView(buildResultPanel());

        scroll.addView(content, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        updateVertexSummary();
    }

    private View buildTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(7), dp(8), dp(9), dp(9));
        bar.setBackground(gradient(BAR_A, BAR_B, 0, 0, 0));

        TextView back = label("‹", 33f, true, Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(54), dp(55)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = label("Área y perímetro", 22f, true, TEXT);
        titles.addView(title);
        TextView subtitle = label("Cálculo por coordenadas planas ordenadas", 12.8f, false, Color.rgb(213, 226, 239));
        subtitle.setLineSpacing(0, 1.04f);
        titles.addView(subtitle);
        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView action = label("◎", 19f, true, BLUE);
        action.setGravity(Gravity.CENTER);
        action.setBackground(gradient(Color.rgb(10, 35, 57), Color.rgb(7, 25, 41), 13, 1, BORDER));
        bar.addView(action, new LinearLayout.LayoutParams(dp(40), dp(40)));
        return bar;
    }

    private View buildTerrainSummary() {
        LinearLayout card = cardBox();
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(12), dp(12), dp(12), dp(12));

        LinearLayout graphic = new LinearLayout(this);
        graphic.setOrientation(LinearLayout.VERTICAL);
        graphic.setGravity(Gravity.CENTER);
        graphic.setBackground(gradient(Color.rgb(8, 32, 52), Color.rgb(7, 27, 43), 14, 1, Color.rgb(31, 76, 120)));

        TextView polygon = label("⬡", 48f, true, BLUE);
        polygon.setGravity(Gravity.CENTER);
        graphic.addView(polygon, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));
        TextView north = label("N   ▲", 10.5f, true, SUBTEXT);
        north.setGravity(Gravity.CENTER);
        graphic.addView(north);

        card.addView(graphic, new LinearLayout.LayoutParams(dp(118), dp(106)));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(12), 0, 0, 0);

        TextView title = label("Terreno", 19f, true, TEXT);
        info.addView(title);

        LinearLayout metrics = new LinearLayout(this);
        metrics.setOrientation(LinearLayout.HORIZONTAL);
        metrics.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams metricsLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        metricsLp.setMargins(0, dp(9), 0, 0);
        metrics.setLayoutParams(metricsLp);

        vertexCountValue = label("4", 17f, true, TEXT);
        statusValue = label("Listo", 15.5f, true, TEXT);
        TextView closeValue = label("Automático", 14.5f, true, GREEN);

        metrics.addView(summaryMetric("⌖", "Vértices", vertexCountValue), weighted(1f, 0, 0, 5, 0));
        metrics.addView(summaryMetric("□", "Estado", statusValue), weighted(1f, 5, 0, 5, 0));
        metrics.addView(summaryMetric("✓", "Cierre", closeValue), weighted(1f, 5, 0, 0, 0));
        info.addView(metrics);

        card.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return card;
    }

    private View summaryMetric(String icon, String labelText, TextView value) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER);
        TextView ic = label(icon, 13f, true, BLUE);
        head.addView(ic);
        TextView label = label(labelText, 10.2f, false, SUBTEXT);
        label.setPadding(dp(4), 0, 0, 0);
        head.addView(label);
        box.addView(head);

        value.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams valueLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        valueLp.setMargins(0, dp(4), 0, 0);
        box.addView(value, valueLp);
        return box;
    }

    private View buildInstructionStrip() {
        LinearLayout strip = new LinearLayout(this);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setGravity(Gravity.CENTER_VERTICAL);
        strip.setPadding(dp(11), dp(10), dp(11), dp(10));
        strip.setBackground(gradient(Color.rgb(10, 34, 54), Color.rgb(8, 29, 46), 13, 1, BORDER));
        strip.setLayoutParams(blockLp(0, 0, 0, 10));

        TextView infoIcon = label("i", 17f, true, BLUE);
        infoIcon.setGravity(Gravity.CENTER);
        infoIcon.setBackground(gradient(Color.rgb(14, 48, 78), Color.rgb(10, 35, 58), 13, 1, Color.rgb(44, 101, 157)));
        strip.addView(infoIcon, new LinearLayout.LayoutParams(dp(34), dp(34)));

        TextView text = label("Ingresa los puntos en orden alrededor del perímetro.\nEl último se une automáticamente con el primero.", 12.5f, false, SUBTEXT);
        text.setLineSpacing(0, 1.1f);
        text.setPadding(dp(9), 0, dp(6), 0);
        strip.addView(text, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView closeGraphic = label("○····○", 13f, true, Color.rgb(219, 230, 241));
        closeGraphic.setGravity(Gravity.CENTER);
        strip.addView(closeGraphic);
        return strip;
    }

    private View buildVertexCard() {
        LinearLayout card = cardBox();
        card.setPadding(dp(12), dp(12), dp(12), dp(12));

        LinearLayout heading = new LinearLayout(this);
        heading.setOrientation(LinearLayout.HORIZONTAL);
        heading.setGravity(Gravity.CENTER_VERTICAL);

        TextView listIcon = label("☷", 21f, true, Color.WHITE);
        listIcon.setGravity(Gravity.CENTER);
        heading.addView(listIcon, new LinearLayout.LayoutParams(dp(35), dp(35)));

        TextView title = label("Vértices del terreno", 18f, true, TEXT);
        title.setPadding(dp(5), 0, 0, 0);
        heading.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        vertexCountPill = label("4 puntos", 11.3f, true, BLUE);
        vertexCountPill.setGravity(Gravity.CENTER);
        vertexCountPill.setPadding(dp(10), 0, dp(10), 0);
        vertexCountPill.setBackground(gradient(Color.rgb(9, 35, 58), Color.rgb(8, 29, 48), 13, 1, BORDER));
        heading.addView(vertexCountPill, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(32)));
        card.addView(heading);

        LinearLayout tableHead = new LinearLayout(this);
        tableHead.setOrientation(LinearLayout.HORIZONTAL);
        tableHead.setGravity(Gravity.CENTER_VERTICAL);
        tableHead.setPadding(dp(4), dp(7), dp(4), dp(7));
        tableHead.setBackground(gradient(Color.rgb(15, 42, 65), Color.rgb(12, 36, 56), 8, 0, 0));
        tableHead.setLayoutParams(blockLp(0, 9, 0, 7));

        TextView pHead = label("Punto", 11.5f, true, Color.rgb(153, 177, 201));
        pHead.setGravity(Gravity.CENTER);
        tableHead.addView(pHead, new LinearLayout.LayoutParams(dp(58), ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView nHead = label("Norte (N)", 11.5f, true, Color.rgb(153, 177, 201));
        nHead.setGravity(Gravity.CENTER);
        tableHead.addView(nHead, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView eHead = label("Este (E)", 11.5f, true, Color.rgb(153, 177, 201));
        eHead.setGravity(Gravity.CENTER);
        tableHead.addView(eHead, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(tableHead);

        rowContainer = new LinearLayout(this);
        rowContainer.setOrientation(LinearLayout.VERTICAL);
        card.addView(rowContainer);
        for (int i = 0; i < 4; i++) addRow();

        return card;
    }

    private View buildActionArea() {
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.VERTICAL);
        actions.setLayoutParams(blockLp(0, 0, 0, 10));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutParams(blockLp(0, 0, 0, 8));

        Button add = secondaryAction("＋  Punto");
        add.setOnClickListener(v -> addRow());
        row.addView(add, weighted(1f, 0, 0, 5, 0));

        Button remove = secondaryAction("−  Punto");
        remove.setOnClickListener(v -> removeRow());
        row.addView(remove, weighted(1f, 5, 0, 5, 0));

        Button clear = dangerAction("🗑  Limpiar");
        clear.setOnClickListener(v -> clearRows());
        row.addView(clear, weighted(1f, 5, 0, 0, 0));
        actions.addView(row);

        Button calc = primaryAction("▦   Calcular terreno");
        calc.setOnClickListener(v -> calculate());
        actions.addView(calc);

        exportButton = secondaryWide("⇧   Exportar resultado CSV");
        exportButton.setOnClickListener(v -> exportCsv());
        actions.addView(exportButton);
        return actions;
    }

    private View buildResultPanel() {
        LinearLayout card = cardBox();
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(11), dp(12), dp(11), dp(12));

        TextView icon = label("⌁", 34f, true, BLUE);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(gradient(Color.rgb(9, 46, 76), Color.rgb(8, 35, 57), 32, 1, BORDER_BRIGHT));
        card.addView(icon, new LinearLayout.LayoutParams(dp(74), dp(74)));

        LinearLayout resultContent = new LinearLayout(this);
        resultContent.setOrientation(LinearLayout.VERTICAL);
        resultContent.setPadding(dp(12), 0, 0, 0);

        LinearLayout areaRow = resultLine("▦", "Área", "m²");
        areaValue = (TextView) areaRow.getTag();
        resultContent.addView(areaRow);

        TextView divider = new TextView(this);
        divider.setBackgroundColor(Color.rgb(25, 61, 91));
        LinearLayout.LayoutParams dLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        dLp.setMargins(0, dp(7), 0, dp(7));
        resultContent.addView(divider, dLp);

        LinearLayout perimeterRow = resultLine("⌘", "Perímetro", "m");
        perimeterValue = (TextView) perimeterRow.getTag();
        resultContent.addView(perimeterRow);

        resultNote = label("Ingresa todos los vértices y presiona “Calcular terreno”.", 11.2f, false, Color.rgb(145, 169, 193));
        resultNote.setLineSpacing(0, 1.08f);
        resultNote.setPadding(0, dp(8), 0, 0);
        resultContent.addView(resultNote);

        card.addView(resultContent, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return card;
    }

    private LinearLayout resultLine(String iconText, String titleText, String unit) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView icon = label(iconText, 15f, true, BLUE);
        icon.setGravity(Gravity.CENTER);
        row.addView(icon, new LinearLayout.LayoutParams(dp(28), dp(28)));

        TextView title = label(titleText, 14.3f, false, TEXT);
        title.setPadding(dp(5), 0, 0, 0);
        row.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView value = label("—", 18f, true, TEXT);
        value.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        value.setGravity(Gravity.END);
        row.addView(value);

        TextView suffix = label("  " + unit, 13f, false, Color.rgb(153, 184, 216));
        row.addView(suffix);
        row.setTag(value);
        return row;
    }

    private void addRow() {
        int index = rows.size() + 1;
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rowLp.setMargins(0, 0, 0, dp(7));
        row.setLayoutParams(rowLp);

        TextView label = label("P" + index, 13.5f, true, TEXT);
        label.setGravity(Gravity.CENTER);
        label.setBackground(gradient(Color.rgb(10, 37, 61), Color.rgb(8, 29, 48), 10, 1, Color.rgb(35, 86, 137)));
        row.addView(label, new LinearLayout.LayoutParams(dp(50), dp(50)));

        EditText north = coordinateInput("0.0000");
        EditText east = coordinateInput("0.0000");

        LinearLayout.LayoutParams nLp = new LinearLayout.LayoutParams(0, dp(50), 1f);
        nLp.setMargins(dp(8), 0, dp(5), 0);
        row.addView(north, nLp);

        LinearLayout.LayoutParams eLp = new LinearLayout.LayoutParams(0, dp(50), 1f);
        eLp.setMargins(dp(5), 0, 0, 0);
        row.addView(east, eLp);

        rows.add(new Row(row, north, east));
        rowContainer.addView(row);
        updateVertexSummary();
        invalidateResult();
    }

    private EditText coordinateInput(String hint) {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setSingleLine(true);
        input.setHint(hint);
        input.setHintTextColor(MUTED);
        input.setTextColor(TEXT);
        input.setPadding(dp(10), 0, dp(10), 0);
        ResponsiveUi.configureText(input, 13.7f);
        input.setBackground(gradient(FIELD_BG, FIELD_BG, 10, 1, Color.rgb(45, 83, 123)));
        return input;
    }

    private void removeRow() {
        if (rows.size() <= 3) {
            showToast("Se necesitan al menos tres puntos.");
            return;
        }
        Row r = rows.remove(rows.size() - 1);
        rowContainer.removeView(r.container);
        updateVertexSummary();
        invalidateResult();
    }

    private void clearRows() {
        for (Row r : rows) {
            r.north.setText("");
            r.east.setText("");
        }
        invalidateResult();
        statusValue.setText("Listo");
        statusValue.setTextColor(TEXT);
    }

    private void updateVertexSummary() {
        if (vertexCountValue != null) vertexCountValue.setText(String.valueOf(rows.size()));
        if (vertexCountPill != null) vertexCountPill.setText(rows.size() + " puntos");
    }

    private void invalidateResult() {
        lastCsv = null;
        if (areaValue != null) areaValue.setText("—");
        if (perimeterValue != null) perimeterValue.setText("—");
        if (resultNote != null) {
            resultNote.setText("Ingresa todos los vértices y presiona “Calcular terreno”.");
            resultNote.setTextColor(Color.rgb(145, 169, 193));
        }
    }

    private List<double[]> readPoints() {
        List<double[]> points = new ArrayList<>();
        for (Row r : rows) {
            String n = r.north.getText().toString().trim();
            String e = r.east.getText().toString().trim();
            if (n.isEmpty() && e.isEmpty()) continue;
            if (n.isEmpty() || e.isEmpty()) throw new IllegalArgumentException();
            points.add(new double[]{parse(r.north), parse(r.east)});
        }
        return points;
    }

    private void calculate() {
        try {
            List<double[]> p = readPoints();
            if (p.size() < 3) throw new IllegalArgumentException();

            double twice = 0;
            double perimeter = 0;
            StringBuilder csv = new StringBuilder("punto,norte,este,lado_siguiente,distancia,azimut,rumbo\n");

            for (int i = 0; i < p.size(); i++) {
                double[] a = p.get(i);
                double[] b = p.get((i + 1) % p.size());
                twice += a[1] * b[0] - b[1] * a[0];
                double dn = b[0] - a[0];
                double de = b[1] - a[1];
                double distance = Math.hypot(dn, de);
                double az = normalizeBearing(Math.toDegrees(Math.atan2(de, dn)));
                perimeter += distance;

                csv.append("P").append(i + 1).append(',')
                        .append(f3(a[0])).append(',')
                        .append(f3(a[1])).append(',')
                        .append("P").append((i + 1) % p.size() + 1).append(',')
                        .append(f3(distance)).append(',')
                        .append(f4(az)).append(',')
                        .append('"').append(bearingToQuadrant(az)).append('"').append('\n');
            }

            double area = Math.abs(twice) / 2.0;
            areaValue.setText(f3(area));
            perimeterValue.setText(f3(perimeter));
            resultNote.setText("Resultado calculado con " + p.size() + " vértices. El cierre con P1 fue automático.");
            resultNote.setTextColor(Color.rgb(129, 190, 246));
            statusValue.setText("Calculado");
            statusValue.setTextColor(GREEN);
            lastCsv = csv.toString();
        } catch (Exception e) {
            areaValue.setText("—");
            perimeterValue.setText("—");
            resultNote.setText("Revisa los puntos. Se requieren al menos 3 filas completas con Norte y Este.");
            resultNote.setTextColor(RED);
            statusValue.setText("Revisar");
            statusValue.setTextColor(RED);
            lastCsv = null;
        }
    }

    private void exportCsv() {
        if (lastCsv == null) calculate();
        if (lastCsv == null) return;

        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/csv");
        intent.putExtra(Intent.EXTRA_TITLE,
                "GeoTopo_Terreno_" + new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date()) + ".csv");
        startActivityForResult(intent, REQ_EXPORT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_EXPORT && resultCode == RESULT_OK && data != null && data.getData() != null && lastCsv != null) {
            try {
                ContentResolver resolver = getContentResolver();
                Uri uri = data.getData();
                OutputStream out = resolver.openOutputStream(uri);
                if (out == null) throw new IllegalStateException();
                out.write(lastCsv.getBytes(StandardCharsets.UTF_8));
                out.close();
                showToast("Resultado exportado.");
            } catch (Exception e) {
                showToast("No se pudo exportar el CSV.");
            }
        }
    }

    private LinearLayout cardBox() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(gradient(CARD_A, CARD_B, 17, 1, BORDER));
        if (Build.VERSION.SDK_INT >= 21) card.setElevation(dp(1.2f));
        card.setLayoutParams(blockLp(0, 0, 0, 10));
        return card;
    }

    private Button primaryAction(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setGravity(Gravity.CENTER);
        button.setBackground(gradient(Color.rgb(44, 137, 255), BLUE_2, 12, 0, 0));
        ResponsiveUi.configureCompactText(button, 15f, 11f, 1);
        if (Build.VERSION.SDK_INT >= 21) {
            button.setStateListAnimator(null);
            button.setElevation(dp(2));
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        lp.setMargins(0, 0, 0, dp(8));
        button.setLayoutParams(lp);
        return button;
    }

    private Button secondaryAction(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextColor(TEXT);
        button.setBackground(gradient(Color.rgb(8, 27, 43), Color.rgb(7, 23, 38), 10, 1, BORDER_BRIGHT));
        ResponsiveUi.configureCompactText(button, 13f, 10f, 1);
        if (Build.VERSION.SDK_INT >= 21) button.setStateListAnimator(null);
        return button;
    }

    private Button dangerAction(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextColor(RED);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setBackground(gradient(Color.rgb(25, 12, 18), Color.rgb(18, 9, 14), 10, 1, Color.rgb(186, 67, 67)));
        ResponsiveUi.configureCompactText(button, 13f, 10f, 1);
        if (Build.VERSION.SDK_INT >= 21) button.setStateListAnimator(null);
        return button;
    }

    private Button secondaryWide(String text) {
        Button button = secondaryAction(text);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        button.setLayoutParams(lp);
        return button;
    }

    private TextView label(String text, float size, boolean bold, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(color);
        view.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        ResponsiveUi.configureText(view, size);
        return view;
    }

    private GradientDrawable gradient(int start, int end, int radiusDp, int strokeDp, int strokeColor) {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT, new int[]{start, end});
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), strokeColor);
        return drawable;
    }

    private LinearLayout.LayoutParams blockLp(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return lp;
    }

    private LinearLayout.LayoutParams weighted(float weight, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(52), weight);
        lp.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return lp;
    }

    private static class Row {
        final LinearLayout container;
        final EditText north;
        final EditText east;

        Row(LinearLayout container, EditText north, EditText east) {
            this.container = container;
            this.north = north;
            this.east = east;
        }
    }
}
