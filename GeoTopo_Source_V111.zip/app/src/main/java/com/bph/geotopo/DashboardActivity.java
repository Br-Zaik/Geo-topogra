package com.bph.geotopo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

/** Native, responsive Geo Topo dashboard. No full-screen reference bitmap is used. */
public class DashboardActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NativeUi.styleWindow(this);
        setContentView(buildScreen());
    }

    private View buildScreen() {
        FrameLayout root = NativeUi.screen(this);
        LinearLayout content = NativeUi.column(this);
        content.setPadding(NativeUi.dp(this, 14), 0, NativeUi.dp(this, 14), NativeUi.dp(this, 28));

        content.addView(NativeUi.dashboardHeader(this, v -> openSettings()));

        LinearLayout heroes = NativeUi.row(this);
        heroes.setBaselineAligned(false);
        View gps = NativeUi.dashboardHeroImageCard(this, true, v -> open(GpsOverviewActivity.class));
        View field = NativeUi.dashboardHeroImageCard(this, false, v -> open(FieldToolsActivity.class));
        LinearLayout.LayoutParams heroLeft = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        heroLeft.setMargins(0, NativeUi.dp(this, 6), NativeUi.dp(this, 6), 0);
        LinearLayout.LayoutParams heroRight = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        heroRight.setMargins(NativeUi.dp(this, 6), NativeUi.dp(this, 6), 0, 0);
        heroes.addView(gps, heroLeft);
        heroes.addView(field, heroRight);
        content.addView(heroes);

        content.addView(NativeUi.simpleSectionHeader(this, "ACCESO RÁPIDO", null, null));
        content.addView(twoCardRow(
                NativeUi.dashboardToolImageCard(this, "converter", "Conversor de unidades",
                        v -> open(ConverterActivity.class)),
                NativeUi.dashboardToolImageCard(this, "compass", "Orientación y brújula",
                        v -> openTool("compass"))));
        content.addView(twoCardRow(
                NativeUi.dashboardToolImageCard(this, "azimuth", "Azimut y rumbo",
                        v -> openTool("azimuth")),
                NativeUi.dashboardToolImageCard(this, "coordinates", "Coordenadas parciales",
                        v -> openTool("coordinates"))));
        content.addView(twoCardRow(
                NativeUi.dashboardToolImageCard(this, "distance", "Distancia y pendiente",
                        v -> openTool("distance")),
                NativeUi.dashboardToolImageCard(this, "two_hair", "Distancia por dos hilos",
                        v -> openTool("two_hair"))));

        content.addView(NativeUi.simpleSectionHeader(this, "CÁLCULOS", null, null));
        View polygon = NativeUi.dashboardWideImageCard(this, "Poligonal cerrada",
                v -> openTool("polygon"));
        LinearLayout.LayoutParams wide = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wide.setMargins(0, 0, 0, NativeUi.dp(this, 8));
        content.addView(polygon, wide);

        content.addView(NativeUi.simpleSectionHeader(this, "NIVELACIÓN", null, null));
        content.addView(twoCardRow(
                NativeUi.dashboardToolImageCard(this, "level", "Nivelación",
                        v -> openTool("level")),
                NativeUi.dashboardToolImageCard(this, "stadia", "Nivelación con tres hilos",
                        v -> openTool("stadia"))));

        root.addView(NativeUi.scroll(this, content), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        return root;
    }

    private View twoCardRow(View left, View right) {
        LinearLayout row = NativeUi.row(this);
        row.setBaselineAligned(false);
        LinearLayout.LayoutParams lpLeft = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lpLeft.setMargins(0, 0, NativeUi.dp(this, 6), NativeUi.dp(this, 12));
        LinearLayout.LayoutParams lpRight = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lpRight.setMargins(NativeUi.dp(this, 6), 0, 0, NativeUi.dp(this, 12));
        row.addView(left, lpLeft);
        row.addView(right, lpRight);
        return row;
    }

    private void open(Class<?> target) {
        startActivity(new Intent(this, target));
    }

    private void openTool(String key) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("single_tool", key);
        startActivity(intent);
    }

    private void openSettings() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("show_settings", true);
        intent.putExtra("settings_only", true);
        startActivity(intent);
    }

    @Override public void onContentChanged() {
        super.onContentChanged();
        NativeUi.applySystemBarInsets(this);
    }
}
