package com.bph.geotopo;

import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TraverseActivity extends BaseToolActivity {
    private static final int REQ_EXPORT = 9510;

    private static final int SCREEN_BG = Color.rgb(3, 20, 33);
    private static final int BAR_A = Color.rgb(6, 44, 70);
    private static final int BAR_B = Color.rgb(4, 27, 45);
    private static final int CARD_A = Color.rgb(9, 28, 47);
    private static final int CARD_B = Color.rgb(7, 22, 37);
    private static final int INNER_A = Color.rgb(8, 25, 41);
    private static final int INNER_B = Color.rgb(6, 20, 33);
    private static final int FIELD_BG = Color.rgb(6, 24, 40);
    private static final int FIELD_STROKE = Color.rgb(54, 102, 162);
    private static final int STROKE = Color.rgb(28, 107, 198);
    private static final int PRIMARY_A = Color.rgb(49, 130, 255);
    private static final int PRIMARY_B = Color.rgb(21, 80, 228);
    private static final int TEXT = Color.rgb(244, 248, 252);
    private static final int SUBTEXT = Color.rgb(191, 205, 218);
    private static final int MUTED = Color.rgb(135, 157, 180);
    private static final int BLUE = Color.rgb(58, 142, 255);
    private static final int BLUE_SOFT = Color.rgb(126, 187, 255);
    private static final int GREEN = Color.rgb(97, 217, 110);
    private static final int GREEN_BG = Color.rgb(44, 104, 32);
    private static final int RED = Color.rgb(255, 110, 110);
    private static final int RED_BG = Color.rgb(120, 39, 45);
    private static final int ORANGE = Color.rgb(255, 187, 59);

    private EditText startN;
    private EditText startE;
    private EditText knownEndN;
    private EditText knownEndE;
    private EditText toleranceInput;
    private CheckBox compensateCheck;
    private Button chipOpen;
    private Button chipClosed;
    private Button chipKnown;
    private Button angleModeButton;
    private Button exportButton;
    private LinearLayout knownEndRow;
    private LinearLayout angleTolRow;
    private TextView configHint;
    private LinearLayout rowsContainer;
    private final List<LegRow> rows = new ArrayList<>();
    private TextView metricDn;
    private TextView metricDe;
    private TextView metricError;
    private TextView metricPrecision;
    private TextView statusBadge;
    private TextView footerNote;
    private LinearLayout bowditchRows;
    private SketchView sketchView;
    private String lastCsv;

    private int polygonType = 1; // 0 abierta, 1 cerrada, 2 punto final conocido
    private int angleMode = 0; // 0 azimut, 1 dms, 2 angulos

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(Color.rgb(2, 14, 24));
            getWindow().setNavigationBarColor(Color.BLACK);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(SCREEN_BG);
        root.addView(buildTopBar(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setBackgroundColor(SCREEN_BG);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundColor(SCREEN_BG);
        content.setPadding(dp(11), dp(12), dp(11), dp(28));
        content.addView(buildConfigCard());
        content.addView(buildTramosCard());
        content.addView(buildResultsCard());

        scroll.addView(content, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        updateTypeUi();
        calculate();
    }

    private View buildTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(7), dp(8), dp(10), dp(9));
        bar.setBackground(gradient(BAR_A, BAR_B, 0, 0, 0));

        TextView back = label("‹", 33f, true, Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(52), dp(54)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(label("Poligonales", 21.5f, true, TEXT));
        TextView subtitle = label("Abierta o cerrada con compensación Bowditch", 12.8f, false, Color.rgb(214, 225, 236));
        subtitle.setLineSpacing(0, 1.04f);
        titles.addView(subtitle);
        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView help = label("?", 18f, true, BLUE);
        help.setGravity(Gravity.CENTER);
        help.setBackground(gradient(Color.rgb(11, 34, 57), Color.rgb(7, 24, 39), 17, 1, STROKE));
        LinearLayout.LayoutParams helpLp = new LinearLayout.LayoutParams(dp(40), dp(40));
        bar.addView(help, helpLp);
        return bar;
    }


    private View buildConfigCard() {
        LinearLayout card = sectionCard();
        card.addView(sectionHead("⚙", "Configuración"));

        LinearLayout firstRow = new LinearLayout(this);
        firstRow.setOrientation(LinearLayout.HORIZONTAL);
        firstRow.setLayoutParams(blockLp(0, 6, 0, 0));
        startN = numericInput("0.000");
        startE = numericInput("0.000");
        startN.setText("0.000");
        startE.setText("0.000");
        firstRow.addView(field("N inicial", startN, "m"), weighted(1f, 0, 0, 5, 0));
        firstRow.addView(field("E inicial", startE, "m"), weighted(1f, 5, 0, 0, 0));
        card.addView(firstRow);

        TextView typeLabel = label("Tipo de poligonal", 13f, true, BLUE_SOFT);
        typeLabel.setLayoutParams(blockLp(2, 8, 2, 5));
        card.addView(typeLabel);

        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setLayoutParams(blockLp(0, 0, 0, 4));
        chipOpen = chipButton("Abierta");
        chipClosed = chipButton("Cerrada");
        chipKnown = chipButton("Punto final conocido");
        chipOpen.setOnClickListener(v -> { polygonType = 0; updateTypeUi(); });
        chipClosed.setOnClickListener(v -> { polygonType = 1; updateTypeUi(); });
        chipKnown.setOnClickListener(v -> { polygonType = 2; updateTypeUi(); });
        chips.addView(chipOpen, weighted(1f, 0, 0, 4, 0));
        chips.addView(chipClosed, weighted(1f, 4, 0, 4, 0));
        chips.addView(chipKnown, weighted(1.25f, 4, 0, 0, 0));
        card.addView(chips);

        compensateCheck = new CheckBox(this);
        compensateCheck.setText("Compensar con Bowditch");
        compensateCheck.setTextColor(TEXT);
        compensateCheck.setChecked(true);
        compensateCheck.setButtonTintList(android.content.res.ColorStateList.valueOf(BLUE));
        compensateCheck.setLayoutParams(blockLp(0, 6, 0, 0));
        card.addView(compensateCheck);

        knownEndRow = new LinearLayout(this);
        knownEndRow.setOrientation(LinearLayout.HORIZONTAL);
        knownEndRow.setLayoutParams(blockLp(0, 6, 0, 0));
        knownEndN = numericInput("Vacío = N inicial");
        knownEndE = numericInput("Vacío = E inicial");
        knownEndRow.addView(field("N final esperado", knownEndN, "m"), weighted(1f, 0, 0, 5, 0));
        knownEndRow.addView(field("E final esperado", knownEndE, "m"), weighted(1f, 5, 0, 0, 0));
        card.addView(knownEndRow);

        angleTolRow = new LinearLayout(this);
        angleTolRow.setOrientation(LinearLayout.HORIZONTAL);
        angleTolRow.setGravity(Gravity.CENTER_VERTICAL);
        angleTolRow.setLayoutParams(blockLp(0, 8, 0, 0));

        LinearLayout angleBox = new LinearLayout(this);
        angleBox.setOrientation(LinearLayout.VERTICAL);
        TextView angleTitle = label("Formato de ángulo", 13f, true, BLUE_SOFT);
        angleTitle.setLayoutParams(blockLp(2, 0, 2, 5));
        angleBox.addView(angleTitle);
        angleModeButton = secondaryAction("Azimut ▼");
        angleModeButton.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        angleModeButton.setOnClickListener(v -> showAngleMenu(v));
        angleBox.addView(angleModeButton);
        angleTolRow.addView(angleBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout tolBox = new LinearLayout(this);
        tolBox.setOrientation(LinearLayout.VERTICAL);
        TextView tolTitle = label("Tolerancia de cierre", 13f, true, BLUE_SOFT);
        tolTitle.setLayoutParams(blockLp(2, 0, 2, 5));
        tolBox.addView(tolTitle);
        toleranceInput = numericInput("0.010");
        toleranceInput.setText("0.010");
        tolBox.addView(fieldShell(toleranceInput, "m"), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        angleTolRow.addView(tolBox, weighted(0.95f, 8, 0, 0, 0));
        card.addView(angleTolRow);

        configHint = infoNote("En cerrada el cierre esperado coincide con el punto inicial. Usa punto final conocido solo si quieres cerrar en otra coordenada.");
        card.addView(configHint);
        return card;
    }

    private View buildTramosCard() {
        LinearLayout card = sectionCard();
        LinearLayout head = sectionHead("☰", "Tramos");
        card.addView(head);
        TextView sub = label("Ingrese azimut (grados) y distancia (metros) por tramo.", 12.4f, false, SUBTEXT);
        sub.setLayoutParams(blockLp(2, 0, 2, 8));
        card.addView(sub);

        LinearLayout table = new LinearLayout(this);
        table.setOrientation(LinearLayout.VERTICAL);
        table.setBackground(gradient(INNER_A, INNER_B, 12, 1, FIELD_STROKE));
        table.setPadding(dp(8), dp(8), dp(8), dp(8));
        card.addView(table);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setLayoutParams(blockLp(0, 0, 0, 6));
        header.addView(tableHeader("#", dp(42)));
        header.addView(tableHeaderFlex("Tramo", 1.15f));
        header.addView(tableHeaderFlex("Azimut °", 1.0f));
        header.addView(tableHeaderFlex("Dist. m", 1.0f));
        header.addView(tableHeader("🗑", dp(36)));
        table.addView(header);

        rowsContainer = new LinearLayout(this);
        rowsContainer.setOrientation(LinearLayout.VERTICAL);
        table.addView(rowsContainer);
        for (int i = 0; i < 4; i++) addRow();

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setLayoutParams(blockLp(0, 8, 0, 0));
        Button add = outlineAction("+ Tramo", BLUE, false);
        add.setOnClickListener(v -> addRow());
        Button clear = outlineAction("🗑 Limpiar", RED, false);
        clear.setOnClickListener(v -> clearRows());
        actions.addView(add, weighted(1f, 0, 0, 4, 0));
        actions.addView(clear, weighted(1f, 4, 0, 0, 0));
        card.addView(actions);

        Button calc = primaryAction("Calcular poligonal");
        calc.setOnClickListener(v -> calculate());
        card.addView(calc);

        exportButton = secondaryAction("Exportar tabla CSV");
        exportButton.setOnClickListener(v -> export());
        exportButton.setVisibility(View.GONE);
        card.addView(exportButton);
        return card;
    }

    private View buildResultsCard() {
        LinearLayout card = sectionCard();
        card.addView(sectionHead("▣", "Resultados"));
        TextView desc = label("Resultados de cierre y compensación.", 12.4f, false, SUBTEXT);
        desc.setLayoutParams(blockLp(2, 0, 2, 8));
        card.addView(desc);

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setLayoutParams(blockLp(0, 0, 0, 6));
        metricDn = metricCard(topRow, "Error de cierre ΔN", "0.000 m", 1f, 0, 0, 4, 0);
        metricDe = metricCard(topRow, "Error de cierre ΔE", "0.000 m", 1f, 4, 0, 4, 0);
        metricError = metricCard(topRow, "Error lineal", "0.000 m", 1f, 4, 0, 4, 0);
        metricPrecision = metricCard(topRow, "Precisión 1:n", "1:0", 1f, 4, 0, 4, 0);
        card.addView(topRow);

        LinearLayout badgeRow = new LinearLayout(this);
        badgeRow.setOrientation(LinearLayout.HORIZONTAL);
        badgeRow.setGravity(Gravity.END);
        statusBadge = label("Aceptable", 13f, true, Color.WHITE);
        statusBadge.setPadding(dp(12), dp(7), dp(12), dp(7));
        statusBadge.setBackground(gradient(GREEN_BG, GREEN_BG, 12, 0, 0));
        badgeRow.addView(statusBadge);
        badgeRow.setLayoutParams(blockLp(0, 0, 0, 8));
        card.addView(badgeRow);

        LinearLayout middle = new LinearLayout(this);
        middle.setOrientation(LinearLayout.HORIZONTAL);
        middle.setLayoutParams(blockLp(0, 0, 0, 8));

        LinearLayout corrCard = new LinearLayout(this);
        corrCard.setOrientation(LinearLayout.VERTICAL);
        corrCard.setPadding(dp(10), dp(10), dp(10), dp(10));
        corrCard.setBackground(gradient(INNER_A, INNER_B, 12, 1, FIELD_STROKE));
        TextView corrTitle = label("Corrección Bowditch (por tramo)", 15f, true, TEXT);
        corrTitle.setLayoutParams(blockLp(0, 0, 0, 8));
        corrCard.addView(corrTitle);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout tableWrap = new LinearLayout(this);
        tableWrap.setOrientation(LinearLayout.VERTICAL);
        LinearLayout tableHead = new LinearLayout(this);
        tableHead.setOrientation(LinearLayout.HORIZONTAL);
        tableHead.addView(headerCell("#", 58));
        tableHead.addView(headerCell("Tramo", 96));
        tableHead.addView(headerCell("ΔN calc.", 92));
        tableHead.addView(headerCell("ΔE calc.", 92));
        tableHead.addView(headerCell("Corr. ΔN", 92));
        tableHead.addView(headerCell("Corr. ΔE", 92));
        tableHead.addView(headerCell("N ajust.", 92));
        tableHead.addView(headerCell("E ajust.", 92));
        tableWrap.addView(tableHead);
        bowditchRows = new LinearLayout(this);
        bowditchRows.setOrientation(LinearLayout.VERTICAL);
        tableWrap.addView(bowditchRows);
        hsv.addView(tableWrap, new HorizontalScrollView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        corrCard.addView(hsv);
        middle.addView(corrCard, weighted(1.8f, 0, 0, 5, 0));

        LinearLayout sketchCard = new LinearLayout(this);
        sketchCard.setOrientation(LinearLayout.VERTICAL);
        sketchCard.setPadding(dp(10), dp(10), dp(10), dp(10));
        sketchCard.setBackground(gradient(INNER_A, INNER_B, 12, 1, FIELD_STROKE));
        TextView skTitle = label("Croquis", 15f, true, TEXT);
        skTitle.setLayoutParams(blockLp(0, 0, 0, 8));
        sketchCard.addView(skTitle);
        sketchView = new SketchView(this);
        sketchCard.addView(sketchView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220)));
        middle.addView(sketchCard, weighted(1f, 5, 0, 0, 0));
        card.addView(middle);

        footerNote = infoNote("Los resultados se mostrarán después de calcular la poligonal.");
        card.addView(footerNote);
        return card;
    }


    private void updateTypeUi() {
        styleChip(chipOpen, polygonType == 0);
        styleChip(chipClosed, polygonType == 1);
        styleChip(chipKnown, polygonType == 2);

        boolean isCloseControl = polygonType != 0;
        boolean isKnownEnd = polygonType == 2;

        compensateCheck.setVisibility(isCloseControl ? View.VISIBLE : View.GONE);
        compensateCheck.setEnabled(isCloseControl);
        if (!isCloseControl) compensateCheck.setChecked(false); else if (!compensateCheck.isChecked()) compensateCheck.setChecked(true);

        knownEndRow.setVisibility(isKnownEnd ? View.VISIBLE : View.GONE);
        knownEndN.setEnabled(isKnownEnd);
        knownEndE.setEnabled(isKnownEnd);
        knownEndN.setAlpha(isKnownEnd ? 1f : 0.65f);
        knownEndE.setAlpha(isKnownEnd ? 1f : 0.65f);
        if (!isKnownEnd) {
            knownEndN.setText("");
            knownEndE.setText("");
        }

        angleTolRow.setVisibility(isCloseControl ? View.VISIBLE : View.GONE);
        configHint.setText(polygonType == 0
                ? "Poligonal abierta: solo registra tramos y calcula. No se aplica control de cierre."
                : (polygonType == 1
                ? "Poligonal cerrada: el cierre esperado coincide con el punto inicial."
                : "Punto final conocido: ingresa el cierre esperado para comparar y compensar."));
        setAngleMode(angleMode);
    }

    private void showAngleMenu(View anchor) {
        PopupMenu menu = new PopupMenu(this, anchor);
        menu.getMenu().add(0, 0, 0, "Azimut");
        menu.getMenu().add(0, 1, 1, "DMS");
        menu.getMenu().add(0, 2, 2, "Ángulos");
        menu.setOnMenuItemClickListener(item -> {
            setAngleMode(item.getItemId());
            return true;
        });
        menu.show();
    }

    private void setAngleMode(int mode) {
        angleMode = mode;
        String text = mode == 1 ? "DMS ▼" : (mode == 2 ? "Ángulos ▼" : "Azimut ▼");
        if (angleModeButton != null) angleModeButton.setText(text);
        if (mode != 0) showToast("Diseño preparado. El cálculo actual usa azimut decimal.");
    }

    private void addRow() {
        int index = rows.size() + 1;
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutParams(blockLp(0, 0, 0, 6));

        TextView number = label("T" + index, 14f, true, TEXT);
        number.setGravity(Gravity.CENTER);
        number.setBackground(gradient(Color.rgb(15, 37, 60), Color.rgb(10, 29, 47), 10, 1, Color.rgb(57, 87, 119)));
        row.addView(number, new LinearLayout.LayoutParams(dp(42), dp(44)));

        EditText station = inlineTextInput("P" + index + "-P" + (index + 1));
        EditText az = inlineNumberInput("0.0000");
        EditText dist = inlineNumberInput("0.000");
        Button delete = outlineAction("×", RED, true);
        delete.setOnClickListener(v -> removeSpecificRow(row));

        row.addView(stationShell(station), tableWeight(1.15f, 6, 0, 4, 0));
        row.addView(stationShell(az), tableWeight(1f, 4, 0, 4, 0));
        row.addView(stationShell(dist), tableWeight(1f, 4, 0, 4, 0));
        row.addView(delete, new LinearLayout.LayoutParams(dp(36), dp(44)));

        rows.add(new LegRow(row, station, az, dist));
        rowsContainer.addView(row);
    }

    private void removeSpecificRow(View rowView) {
        if (rows.size() <= 2) {
            showToast("Conserva al menos dos tramos.");
            return;
        }
        LegRow target = null;
        for (LegRow row : rows) {
            if (row.container == rowView) { target = row; break; }
        }
        if (target != null) {
            rows.remove(target);
            rowsContainer.removeView(target.container);
            renumberRows();
            calculate();
        }
    }


    private void renumberRows() {
        for (int i = 0; i < rows.size(); i++) {
            LegRow row = rows.get(i);
            row.name.setHint("P" + (i + 1) + "-P" + (i + 2));
            if (row.name.getText().toString().trim().isEmpty()) {
                row.name.setText("P" + (i + 1) + "-P" + (i + 2));
            }
            TextView tag = (TextView) row.container.getChildAt(0);
            tag.setText("T" + (i + 1));
        }
    }

    private void clearRows() {
        for (int i = 0; i < rows.size(); i++) {
            LegRow r = rows.get(i);
            r.name.setText("P" + (i + 1) + "-P" + (i + 2));
            r.azimuth.setText("");
            r.distance.setText("");
        }
        knownEndN.setText("");
        knownEndE.setText("");
        lastCsv = null;
        if (exportButton != null) exportButton.setVisibility(View.GONE);
        calculate();
    }

    private void calculate() {
        try {
            double n0 = parse(startN), e0 = parse(startE);
            double tolerance = blank(toleranceInput) ? 0.010 : Math.max(0.0, parse(toleranceInput));
            List<LegCalc> legs = new ArrayList<>();
            double sumN = 0, sumE = 0, perimeter = 0;
            for (int i = 0; i < rows.size(); i++) {
                LegRow row = rows.get(i);
                if (blank(row.azimuth) && blank(row.distance)) continue;
                if (blank(row.azimuth) || blank(row.distance)) throw new IllegalArgumentException();
                double az = normalizeBearing(parse(row.azimuth));
                double d = parse(row.distance);
                if (d <= 0) throw new IllegalArgumentException();
                double dn = d * Math.cos(Math.toRadians(az));
                double de = d * Math.sin(Math.toRadians(az));
                String name = row.name.getText().toString().trim();
                if (name.isEmpty()) name = "P" + (i + 1) + "-P" + (i + 2);
                LegCalc leg = new LegCalc(name, az, d, dn, de);
                legs.add(leg);
                sumN += dn;
                sumE += de;
                perimeter += d;
            }
            if (legs.size() < 2) throw new IllegalArgumentException();

            boolean close = polygonType != 0;
            boolean adjust = close && compensateCheck.isChecked();
            double expectedN = close ? (blank(knownEndN) ? n0 : parse(knownEndN)) : n0 + sumN;
            double expectedE = close ? (blank(knownEndE) ? e0 : parse(knownEndE)) : e0 + sumE;
            double rawEndN = n0 + sumN;
            double rawEndE = e0 + sumE;
            double fN = rawEndN - expectedN;
            double fE = rawEndE - expectedE;
            double linearError = close ? Math.hypot(fN, fE) : 0.0;
            double precision = (close && linearError > 0) ? perimeter / linearError : Double.POSITIVE_INFINITY;
            boolean acceptable = !close || linearError <= tolerance;

            StringBuilder csv = new StringBuilder("tramo,azimut,distancia,dN,dE,corrN,corrE,dN_ajustada,dE_ajustada,N,E\n");
            ArrayList<PlotPoint> plot = new ArrayList<>();
            plot.add(new PlotPoint("P1", n0, e0));

            double n = n0;
            double e = e0;
            double sumCorrN = 0;
            double sumCorrE = 0;
            bowditchRows.removeAllViews();
            for (int i = 0; i < legs.size(); i++) {
                LegCalc leg = legs.get(i);
                leg.corrN = adjust ? -fN * (leg.distance / perimeter) : 0.0;
                leg.corrE = adjust ? -fE * (leg.distance / perimeter) : 0.0;
                leg.adjDn = leg.dn + leg.corrN;
                leg.adjDe = leg.de + leg.corrE;
                sumCorrN += leg.corrN;
                sumCorrE += leg.corrE;
                n += leg.adjDn;
                e += leg.adjDe;
                leg.endN = n;
                leg.endE = e;
                plot.add(new PlotPoint("P" + (i + 2), n, e));
                bowditchRows.addView(rowCells(
                        "T" + (i + 1), leg.name, signed(leg.dn), signed(leg.de),
                        signed(leg.corrN), signed(leg.corrE), f3(leg.endN), f3(leg.endE)
                ));
                csv.append(csvCell(leg.name)).append(',').append(f4(leg.azimuth)).append(',').append(f3(leg.distance)).append(',')
                        .append(f3(leg.dn)).append(',').append(f3(leg.de)).append(',').append(f3(leg.corrN)).append(',').append(f3(leg.corrE)).append(',')
                        .append(f3(leg.adjDn)).append(',').append(f3(leg.adjDe)).append(',').append(f3(leg.endN)).append(',').append(f3(leg.endE)).append('\n');
            }
            bowditchRows.addView(sumRow(sumCorrN, sumCorrE, n, e));
            lastCsv = csv.toString();
            if (exportButton != null) exportButton.setVisibility(View.VISIBLE);

            metricDn.setText(signed(fN) + " m");
            metricDe.setText(signed(fE) + " m");
            metricError.setText(f3(linearError) + " m");
            metricPrecision.setText(Double.isInfinite(precision) ? "1:∞" : "1:" + String.format(Locale.US, "%,.0f", precision));
            statusBadge.setText(acceptable ? "Aceptable" : "Fuera de tolerancia");
            statusBadge.setBackground(gradient(acceptable ? GREEN_BG : RED_BG, acceptable ? GREEN_BG : RED_BG, 12, 0, 0));
            footerNote.setText(close
                    ? (acceptable
                    ? "Cierre dentro de la tolerancia definida. Resultados compensados con Bowditch."
                    : "El cierre supera la tolerancia definida. Revisa los tramos o el punto de cierre esperado.")
                    : "Poligonal abierta: se muestran coordenadas calculadas sin control de cierre.");
            footerNote.setTextColor(acceptable || !close ? BLUE_SOFT : RED);
            sketchView.setPoints(plot);
        } catch (Exception e) {
            lastCsv = null;
            if (exportButton != null) exportButton.setVisibility(View.GONE);
            bowditchRows.removeAllViews();
            metricDn.setText("—");
            metricDe.setText("—");
            metricError.setText("—");
            metricPrecision.setText("—");
            statusBadge.setText("Sin cálculo");
            statusBadge.setBackground(gradient(Color.rgb(53, 71, 90), Color.rgb(53, 71, 90), 12, 0, 0));
            footerNote.setText("Revisa la configuración y los tramos. Cada fila usada necesita azimut y distancia positiva.");
            footerNote.setTextColor(RED);
            sketchView.setPoints(new ArrayList<>());
            bowditchRows.addView(emptyRow("Calcula la poligonal para ver las correcciones Bowditch por tramo."));
        }
    }

    private String csvCell(String v) {
        return '"' + v.replace("\"", "\"\"") + '"';
    }

    private void export() {
        if (lastCsv == null) calculate();
        if (lastCsv == null) return;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/csv");
        intent.putExtra(Intent.EXTRA_TITLE, "GeoTopo_Poligonal_" + new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date()) + ".csv");
        startActivityForResult(intent, REQ_EXPORT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_EXPORT && resultCode == RESULT_OK && data != null && data.getData() != null && lastCsv != null) {
            try {
                ContentResolver resolver = getContentResolver();
                Uri uri = data.getData();
                OutputStream out = resolver.openOutputStream(uri);
                if (out == null) throw new IllegalStateException();
                out.write(lastCsv.getBytes(StandardCharsets.UTF_8));
                out.close();
                showToast("Poligonal exportada.");
            } catch (Exception e) {
                showToast("No se pudo exportar.");
            }
        }
    }

    private LinearLayout sectionCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(12), dp(12), dp(12));
        card.setBackground(gradient(CARD_A, CARD_B, 18, 1, STROKE));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(12));
        card.setLayoutParams(lp);
        return card;
    }

    private LinearLayout sectionHead(String iconText, String titleText) {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = label(iconText, 18f, true, BLUE);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(gradient(Color.rgb(16, 47, 82), Color.rgb(10, 31, 51), 14, 1, FIELD_STROKE));
        header.addView(icon, new LinearLayout.LayoutParams(dp(38), dp(38)));
        TextView title = label(titleText, 19f, true, TEXT);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        titleLp.setMargins(dp(10), 0, 0, 0);
        header.addView(title, titleLp);
        return header;
    }

    private LinearLayout field(String labelText, EditText input, String unit) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        TextView label = label(labelText, 12.5f, false, SUBTEXT);
        label.setLayoutParams(blockLp(2, 0, 2, 5));
        box.addView(label);
        box.addView(fieldShell(input, unit));
        return box;
    }

    private View fieldShell(EditText input, String unit) {
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.HORIZONTAL);
        shell.setGravity(Gravity.CENTER_VERTICAL);
        shell.setPadding(dp(10), 0, dp(10), 0);
        shell.setBackground(gradient(FIELD_BG, FIELD_BG, 11, 1, FIELD_STROKE));
        shell.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        input.setBackgroundColor(Color.TRANSPARENT);
        input.setPadding(0, 0, dp(10), 0);
        shell.addView(input, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        TextView suffix = label(unit, 12.6f, false, SUBTEXT);
        suffix.setGravity(Gravity.CENTER);
        shell.addView(suffix);
        return shell;
    }

    private EditText numericInput(String hint) {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setSingleLine(true);
        input.setHint(hint);
        input.setHintTextColor(MUTED);
        input.setTextColor(TEXT);
        ResponsiveUi.configureText(input, 14.2f);
        return input;
    }

    private EditText inlineNumberInput(String hint) {
        EditText input = numericInput(hint);
        input.setGravity(Gravity.CENTER);
        return input;
    }

    private EditText inlineTextInput(String hint) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint(hint);
        input.setText(hint);
        input.setHintTextColor(MUTED);
        input.setTextColor(TEXT);
        input.setGravity(Gravity.CENTER);
        ResponsiveUi.configureText(input, 13.4f);
        input.setBackgroundColor(Color.TRANSPARENT);
        return input;
    }

    private View stationShell(EditText input) {
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.HORIZONTAL);
        shell.setGravity(Gravity.CENTER_VERTICAL);
        shell.setPadding(dp(6), 0, dp(6), 0);
        shell.setBackground(gradient(FIELD_BG, FIELD_BG, 9, 1, FIELD_STROKE));
        shell.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));
        return shell;
    }

    private Button chipButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextColor(TEXT);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        ResponsiveUi.configureCompactText(button, 13.2f, 10f, 1);
        styleChip(button, false);
        return button;
    }

    private void styleChip(Button button, boolean selected) {
        button.setBackground(gradient(selected ? PRIMARY_A : Color.rgb(9, 28, 47), selected ? PRIMARY_B : Color.rgb(7, 24, 40), 12, 1, selected ? BLUE_SOFT : FIELD_STROKE));
        button.setTextColor(Color.WHITE);
    }



    private Button primaryAction(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setBackground(gradient(PRIMARY_A, PRIMARY_B, 12, 0, 0));
        ResponsiveUi.configureCompactText(button, 14.8f, 11f, 1);
        if (Build.VERSION.SDK_INT >= 21) {
            button.setStateListAnimator(null);
            button.setElevation(dp(2));
        }
        button.setLayoutParams(blockLp(0, 10, 0, 8));
        return button;
    }

    private Button secondaryAction(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextColor(TEXT);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setBackground(gradient(Color.rgb(11, 35, 56), Color.rgb(7, 26, 43), 11, 1, STROKE));
        ResponsiveUi.configureCompactText(button, 13.8f, 10f, 1);
        if (Build.VERSION.SDK_INT >= 21) button.setStateListAnimator(null);
        button.setLayoutParams(blockLp(0, 0, 0, 2));
        return button;
    }

    private Button outlineAction(String text, int strokeColor, boolean compact) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextColor(strokeColor == ORANGE ? ORANGE : (strokeColor == RED ? RED : BLUE_SOFT));
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setBackground(gradient(FIELD_BG, FIELD_BG, 10, 1, strokeColor));
        ResponsiveUi.configureCompactText(button, compact ? 18f : 13.6f, 10f, 1);
        if (compact) {
            button.setPadding(0, 0, 0, 0);
            button.setMinWidth(0);
            button.setMinimumWidth(0);
        }
        if (Build.VERSION.SDK_INT >= 21) button.setStateListAnimator(null);
        return button;
    }

    private TextView metricCard(LinearLayout parent, String title, String value, float weight, int l, int t, int r, int b) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(10), dp(10), dp(10));
        box.setBackground(gradient(INNER_A, INNER_B, 12, 1, FIELD_STROKE));
        TextView titleView = label(title, 11.8f, false, SUBTEXT);
        box.addView(titleView);
        TextView valueView = label(value, 16.2f, true, TEXT);
        valueView.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        valueView.setLayoutParams(blockLp(0, 6, 0, 0));
        box.addView(valueView);
        parent.addView(box, weighted(weight, l, t, r, b));
        return valueView;
    }

    private TextView tableHeader(String text, int width) {
        TextView tv = label(text, 12.4f, true, SUBTEXT);
        tv.setGravity(Gravity.CENTER);
        tv.setLayoutParams(new LinearLayout.LayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT));
        return tv;
    }

    private TextView tableHeaderFlex(String text, float weight) {
        TextView tv = label(text, 12.4f, true, SUBTEXT);
        tv.setGravity(Gravity.CENTER);
        tv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight));
        return tv;
    }

    private TextView headerCell(String text, int widthDp) {
        TextView view = label(text, 11.8f, true, SUBTEXT);
        view.setGravity(Gravity.CENTER);
        view.setBackground(gradient(Color.rgb(12, 42, 70), Color.rgb(8, 28, 46), 0, 1, FIELD_STROKE));
        view.setPadding(dp(6), dp(8), dp(6), dp(8));
        view.setLayoutParams(new LinearLayout.LayoutParams(dp(widthDp), ViewGroup.LayoutParams.WRAP_CONTENT));
        return view;
    }

    private LinearLayout rowCells(String c1, String c2, String c3, String c4, String c5, String c6, String c7, String c8) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(dataCell(c1, 58, false));
        row.addView(dataCell(c2, 96, false));
        row.addView(dataCell(c3, 92, false));
        row.addView(dataCell(c4, 92, false));
        row.addView(dataCell(c5, 92, false));
        row.addView(dataCell(c6, 92, false));
        row.addView(dataCell(c7, 92, false));
        row.addView(dataCell(c8, 92, false));
        return row;
    }

    private LinearLayout sumRow(double sumCorrN, double sumCorrE, double endN, double endE) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(dataCell("Σ", 58, true));
        row.addView(dataCell("Suma", 96, true));
        row.addView(dataCell("", 92, true));
        row.addView(dataCell("", 92, true));
        row.addView(dataCell(f3(sumCorrN), 92, true));
        row.addView(dataCell(f3(sumCorrE), 92, true));
        row.addView(dataCell(f3(endN), 92, true));
        row.addView(dataCell(f3(endE), 92, true));
        return row;
    }

    private TextView dataCell(String text, int widthDp, boolean bold) {
        TextView view = label(text.isEmpty() ? "—" : text, 11.6f, bold, bold ? (text.startsWith("-") ? RED : (text.equals("Suma") || text.equals("Σ") ? TEXT : GREEN)) : TEXT);
        if (text.isEmpty()) view.setTextColor(SUBTEXT);
        view.setGravity(Gravity.CENTER);
        view.setBackground(gradient(FIELD_BG, FIELD_BG, 0, 1, Color.rgb(40, 74, 115)));
        view.setPadding(dp(6), dp(8), dp(6), dp(8));
        view.setLayoutParams(new LinearLayout.LayoutParams(dp(widthDp), ViewGroup.LayoutParams.WRAP_CONTENT));
        return view;
    }

    private TextView emptyRow(String text) {
        TextView view = label(text, 12.2f, false, SUBTEXT);
        view.setPadding(dp(10), dp(10), dp(10), dp(10));
        view.setBackground(gradient(FIELD_BG, FIELD_BG, 0, 1, Color.rgb(40, 74, 115)));
        return view;
    }

    private TextView infoNote(String text) {
        TextView note = label(text, 12.4f, false, SUBTEXT);
        note.setLineSpacing(0, 1.12f);
        note.setPadding(dp(10), dp(9), dp(10), dp(9));
        note.setBackground(gradient(INNER_A, INNER_A, 11, 1, Color.rgb(34, 74, 118)));
        note.setLayoutParams(blockLp(0, 8, 0, 0));
        return note;
    }

    private TextView label(String text, float size, boolean bold, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(color);
        view.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        ResponsiveUi.configureText(view, size);
        return view;
    }

    private GradientDrawable gradient(int start, int end, int radiusDp, int strokeDp, int strokeColor) {
        GradientDrawable drawable = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{start, end});
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), strokeColor);
        return drawable;
    }

    private LinearLayout.LayoutParams weighted(float weight, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        lp.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return lp;
    }

    private LinearLayout.LayoutParams tableWeight(float weight, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), weight);
        lp.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return lp;
    }

    private LinearLayout.LayoutParams blockLp(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return lp;
    }

    private static class LegRow {
        final LinearLayout container;
        final EditText name;
        final EditText azimuth;
        final EditText distance;

        LegRow(LinearLayout c, EditText n, EditText a, EditText d) {
            container = c;
            name = n;
            azimuth = a;
            distance = d;
        }
    }

    private static class LegCalc {
        final String name;
        final double azimuth;
        final double distance;
        final double dn;
        final double de;
        double corrN;
        double corrE;
        double adjDn;
        double adjDe;
        double endN;
        double endE;

        LegCalc(String n, double a, double d, double dn, double de) {
            name = n;
            azimuth = a;
            distance = d;
            this.dn = dn;
            this.de = de;
        }
    }

    private static class PlotPoint {
        final String label;
        final double n;
        final double e;

        PlotPoint(String label, double n, double e) {
            this.label = label;
            this.n = n;
            this.e = e;
        }
    }

    private class SketchView extends View {
        private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint node = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint north = new Paint(Paint.ANTI_ALIAS_FLAG);
        private List<PlotPoint> points = new ArrayList<>();

        SketchView(TraverseActivity ctx) {
            super(ctx);
            grid.setColor(Color.argb(55, 73, 127, 183));
            grid.setStrokeWidth(dp(1));
            line.setColor(BLUE_SOFT);
            line.setStrokeWidth(dp(2));
            line.setStyle(Paint.Style.STROKE);
            node.setColor(BLUE);
            text.setColor(TEXT);
            text.setTextSize(dp(4.1f));
            text.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            north.setColor(SUBTEXT);
            north.setStrokeWidth(dp(2));
            north.setStyle(Paint.Style.STROKE);
        }

        void setPoints(List<PlotPoint> values) {
            points = values == null ? new ArrayList<>() : values;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            canvas.drawColor(Color.rgb(5, 21, 36));
            for (int x = dp(10); x < w; x += dp(18)) canvas.drawLine(x, dp(10), x, h - dp(10), grid);
            for (int y = dp(10); y < h; y += dp(18)) canvas.drawLine(dp(10), y, w - dp(10), y, grid);

            drawNorth(canvas, w, h);
            if (points == null || points.size() < 2) return;

            double minN = points.get(0).n, maxN = points.get(0).n, minE = points.get(0).e, maxE = points.get(0).e;
            for (PlotPoint p : points) {
                minN = Math.min(minN, p.n); maxN = Math.max(maxN, p.n);
                minE = Math.min(minE, p.e); maxE = Math.max(maxE, p.e);
            }
            double spanN = Math.max(1e-6, maxN - minN);
            double spanE = Math.max(1e-6, maxE - minE);
            float left = dp(26), top = dp(20), right = w - dp(24), bottom = h - dp(24);
            float scale = (float) Math.min((right - left) / spanE, (bottom - top) / spanN);
            float offsetX = left + ((right - left) - (float) (spanE * scale)) / 2f;
            float offsetY = bottom - ((bottom - top) - (float) (spanN * scale)) / 2f;

            Path path = new Path();
            PointF prev = null;
            for (int i = 0; i < points.size(); i++) {
                PlotPoint p = points.get(i);
                float x = offsetX + (float) ((p.e - minE) * scale);
                float y = offsetY - (float) ((p.n - minN) * scale);
                if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
                canvas.drawCircle(x, y, dp(4), node);
                canvas.drawText(p.label, x + dp(5), y - dp(5), text);
                if (prev != null) drawArrow(canvas, prev.x, prev.y, x, y);
                prev = new PointF(x, y);
            }
            canvas.drawPath(path, line);
        }

        private void drawNorth(Canvas canvas, int w, int h) {
            float x = w - dp(28);
            float y = dp(24);
            canvas.drawText("N", x - dp(4), y - dp(4), text);
            canvas.drawLine(x, y + dp(16), x, y + dp(42), north);
            canvas.drawLine(x, y + dp(16), x - dp(6), y + dp(24), north);
            canvas.drawLine(x, y + dp(16), x + dp(6), y + dp(24), north);
        }

        private void drawArrow(Canvas canvas, float x1, float y1, float x2, float y2) {
            float mx = (x1 + x2) / 2f;
            float my = (y1 + y2) / 2f;
            double ang = Math.atan2(y2 - y1, x2 - x1);
            float len = dp(8);
            float ax1 = (float) (mx - len * Math.cos(ang - Math.PI / 6));
            float ay1 = (float) (my - len * Math.sin(ang - Math.PI / 6));
            float ax2 = (float) (mx - len * Math.cos(ang + Math.PI / 6));
            float ay2 = (float) (my - len * Math.sin(ang + Math.PI / 6));
            canvas.drawLine(mx, my, ax1, ay1, line);
            canvas.drawLine(mx, my, ax2, ay2, line);
        }
    }
}
