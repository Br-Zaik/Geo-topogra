package com.bph.geotopo;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class CogoActivity extends BaseToolActivity {
    private static final int SCREEN_BG = Color.rgb(3, 20, 33);
    private static final int BAR_A = Color.rgb(6, 44, 70);
    private static final int BAR_B = Color.rgb(4, 27, 45);
    private static final int CARD_A = Color.rgb(9, 28, 47);
    private static final int CARD_B = Color.rgb(7, 22, 37);
    private static final int INNER_A = Color.rgb(8, 25, 41);
    private static final int INNER_B = Color.rgb(6, 20, 33);
    private static final int FIELD_BG = Color.rgb(6, 24, 40);
    private static final int FIELD_STROKE = Color.rgb(54, 102, 162);
    private static final int STROKE = Color.rgb(28, 107, 198);
    private static final int PRIMARY_A = Color.rgb(49, 130, 255);
    private static final int PRIMARY_B = Color.rgb(21, 80, 228);
    private static final int TEXT = Color.rgb(244, 248, 252);
    private static final int SUBTEXT = Color.rgb(191, 205, 218);
    private static final int MUTED = Color.rgb(135, 157, 180);
    private static final int BLUE = Color.rgb(58, 142, 255);
    private static final int BLUE_SOFT = Color.rgb(126, 187, 255);
    private static final int RED = Color.rgb(255, 110, 110);
    private static final int INFO_BG = Color.rgb(6, 27, 44);

    private static class MetricView {
        final LinearLayout box;
        final TextView value;

        MetricView(LinearLayout box, TextView value) {
            this.box = box;
            this.value = value;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(Color.rgb(2, 14, 24));
            getWindow().setNavigationBarColor(Color.BLACK);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(SCREEN_BG);
        root.addView(buildTopBar(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setBackgroundColor(SCREEN_BG);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundColor(SCREEN_BG);
        content.setPadding(dp(11), dp(12), dp(11), dp(28));

        content.addView(buildDirectSection());
        content.addView(buildInverseSection());
        content.addView(buildAzimuthIntersectionSection());
        content.addView(buildDistanceIntersectionSection());
        content.addView(buildProjectionSection());
        content.addView(buildDivisionSection());

        scroll.addView(content, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private View buildTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(7), dp(8), dp(10), dp(9));
        bar.setBackground(gradient(BAR_A, BAR_B, 0, 0, 0));

        TextView back = label("‹", 33f, true, Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(52), dp(54)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = label("COGO completo", 21.5f, true, TEXT);
        titles.addView(title);
        TextView subtitle = label("Geometría de coordenadas para cálculo de campo", 12.8f, false, Color.rgb(214, 225, 236));
        subtitle.setLineSpacing(0, 1.04f);
        titles.addView(subtitle);
        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView aim = label("◎", 18f, true, BLUE);
        aim.setGravity(Gravity.CENTER);
        aim.setBackground(gradient(Color.rgb(11, 34, 57), Color.rgb(7, 24, 39), 17, 1, STROKE));
        LinearLayout.LayoutParams aimLp = new LinearLayout.LayoutParams(dp(40), dp(40));
        bar.addView(aim, aimLp);
        return bar;
    }

    private View buildDirectSection() {
        LinearLayout body = verticalBox();
        body.addView(descriptionText("Coordenada final desde Norte/Este inicial, azimut medido desde el Norte en sentido horario y distancia horizontal."));

        EditText n0 = numericInput("Ingrese valor");
        EditText e0 = numericInput("Ingrese valor");
        EditText az = numericInput("Ingrese valor");
        EditText dist = numericInput("Ingrese valor");

        body.addView(twoCol(field("N inicial", "N", "m", n0), field("E inicial", "E", "m", e0)));
        body.addView(twoCol(field("Azimut °", "◔", "°", az), field("Distancia m", "⌁", "m", dist)));

        Button calc = primaryAction("Calcular directa");
        body.addView(calc);

        LinearLayout results = resultPanel("Resultado");
        MetricView nFinal = metric("N final", "m");
        MetricView eFinal = metric("E final", "m");
        MetricView dN = metric("ΔN", "m");
        MetricView dE = metric("ΔE", "m");
        results.addView(twoCol(nFinal.box, eFinal.box));
        results.addView(twoCol(dN.box, dE.box));
        TextView note = infoNote("Ingresa coordenadas, azimut y distancia para calcular el punto final.");
        results.addView(note);
        body.addView(results);

        calc.setOnClickListener(v -> {
            try {
                double a = Math.toRadians(normalizeBearing(parse(az)));
                double d = parse(dist);
                if (d < 0) throw new IllegalArgumentException();
                double dn = d * Math.cos(a);
                double de = d * Math.sin(a);
                nFinal.value.setText(f3(parse(n0) + dn));
                eFinal.value.setText(f3(parse(e0) + de));
                dN.value.setText(signed(dn));
                dE.value.setText(signed(de));
                note.setText("Punto calculado correctamente. El azimut se normalizó en el rango 0° a 360°.");
                note.setTextColor(BLUE_SOFT);
            } catch (Exception ex) {
                clearMetrics(nFinal, eFinal, dN, dE);
                note.setText("Revisa los datos. La distancia no puede ser negativa y todos los campos deben tener un número válido.");
                note.setTextColor(RED);
            }
        });

        return collapsibleSection("→", "Cálculo directo", body, false);
    }

    private View buildInverseSection() {
        LinearLayout body = verticalBox();
        body.addView(descriptionText("Distancia, azimut, rumbo y diferencias entre dos coordenadas planas."));

        EditText n1 = numericInput("Ingrese valor");
        EditText e1 = numericInput("Ingrese valor");
        EditText n2 = numericInput("Ingrese valor");
        EditText e2 = numericInput("Ingrese valor");

        body.addView(twoCol(field("N1", "N", "m", n1), field("E1", "E", "m", e1)));
        body.addView(twoCol(field("N2", "N", "m", n2), field("E2", "E", "m", e2)));

        Button calc = primaryAction("Calcular inversa");
        body.addView(calc);

        LinearLayout results = resultPanel("Resultado");
        MetricView distance = metric("Distancia", "m");
        MetricView azOut = metric("Azimut", "°");
        MetricView rumbo = metric("Rumbo", "");
        rumbo.value.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        ResponsiveUi.configureCompactText(rumbo.value, 15f, 7f, 1);
        rumbo.value.setSingleLine(true);
        rumbo.value.setGravity(Gravity.CENTER_VERTICAL);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) rumbo.value.setLetterSpacing(-0.02f);
        MetricView dn = metric("ΔN", "m");
        MetricView de = metric("ΔE", "m");
        results.addView(threeCol(distance.box, azOut.box, rumbo.box));
        results.addView(twoCol(dn.box, de.box));
        TextView note = infoNote("Con dos puntos distintos obtendrás la distancia, el azimut y el rumbo del tramo.");
        results.addView(note);
        body.addView(results);

        calc.setOnClickListener(v -> {
            try {
                double deltaN = parse(n2) - parse(n1);
                double deltaE = parse(e2) - parse(e1);
                double d = Math.hypot(deltaN, deltaE);
                if (d == 0) throw new IllegalArgumentException();
                double a = normalizeBearing(Math.toDegrees(Math.atan2(deltaE, deltaN)));
                distance.value.setText(f3(d));
                azOut.value.setText(f4(a));
                rumbo.value.setText(compactBearingToQuadrant(a));
                dn.value.setText(signed(deltaN));
                de.value.setText(signed(deltaE));
                note.setText("Resultado listo. El azimut está medido desde el Norte en sentido horario.");
                note.setTextColor(BLUE_SOFT);
            } catch (Exception ex) {
                clearMetrics(distance, azOut, rumbo, dn, de);
                note.setText("Revisa las coordenadas. Los dos puntos no deben coincidir y todos los valores deben ser válidos.");
                note.setTextColor(RED);
            }
        });

        return collapsibleSection("↔", "Cálculo inverso", body, false);
    }

    private View buildAzimuthIntersectionSection() {
        LinearLayout body = verticalBox();
        body.addView(descriptionText("Obtiene la coordenada de intersección a partir de dos puntos conocidos y dos direcciones."));

        EditText n1 = numericInput("Ingrese valor");
        EditText e1 = numericInput("Ingrese valor");
        EditText az1 = numericInput("Ingrese valor");
        EditText n2 = numericInput("Ingrese valor");
        EditText e2 = numericInput("Ingrese valor");
        EditText az2 = numericInput("Ingrese valor");

        body.addView(twoCol(field("N1", "N", "m", n1), field("E1", "E", "m", e1)));
        body.addView(twoCol(field("Azimut 1", "◔", "°", az1), field("N2", "N", "m", n2)));
        body.addView(twoCol(field("E2", "E", "m", e2), field("Azimut 2", "◔", "°", az2)));

        Button calc = primaryAction("Calcular intersección");
        body.addView(calc);

        LinearLayout results = resultPanel("Resultado");
        MetricView nInt = metric("N intersección", "m");
        MetricView eInt = metric("E intersección", "m");
        MetricView d1 = metric("Dist. desde P1", "m");
        MetricView d2 = metric("Dist. desde P2", "m");
        results.addView(twoCol(nInt.box, eInt.box));
        results.addView(twoCol(d1.box, d2.box));
        TextView note = infoNote("Si las dos direcciones son paralelas o casi paralelas, la intersección no existe.");
        results.addView(note);
        body.addView(results);

        calc.setOnClickListener(v -> {
            try {
                double A1 = Math.toRadians(normalizeBearing(parse(az1)));
                double A2 = Math.toRadians(normalizeBearing(parse(az2)));
                double d1n = Math.cos(A1), d1e = Math.sin(A1);
                double d2n = Math.cos(A2), d2e = Math.sin(A2);
                double deltaN = parse(n2) - parse(n1);
                double deltaE = parse(e2) - parse(e1);
                double det = d1n * (-d2e) - d1e * (-d2n);
                if (Math.abs(det) < 1e-10) throw new IllegalArgumentException();
                double t1 = (deltaN * (-d2e) - deltaE * (-d2n)) / det;
                double t2 = (d1n * deltaE - d1e * deltaN) / det;
                double ni = parse(n1) + t1 * d1n;
                double ei = parse(e1) + t1 * d1e;
                nInt.value.setText(f3(ni));
                eInt.value.setText(f3(ei));
                d1.value.setText(f3(Math.abs(t1)));
                d2.value.setText(f3(Math.abs(t2)));
                StringBuilder msg = new StringBuilder("Intersección calculada.");
                if (t1 < 0) msg.append(" La solución queda detrás del azimut 1.");
                if (t2 < 0) msg.append(" La solución queda detrás del azimut 2.");
                note.setText(msg.toString());
                note.setTextColor(BLUE_SOFT);
            } catch (Exception ex) {
                clearMetrics(nInt, eInt, d1, d2);
                note.setText("Las líneas son paralelas, casi paralelas o faltan datos válidos.");
                note.setTextColor(RED);
            }
        });

        return collapsibleSection("✕", "Intersección por dos azimuts", body, false);
    }

    private View buildDistanceIntersectionSection() {
        LinearLayout body = verticalBox();
        body.addView(descriptionText("Calcula la posición a partir de dos puntos conocidos y dos radios o distancias."));

        EditText n1 = numericInput("Ingrese valor");
        EditText e1 = numericInput("Ingrese valor");
        EditText d1 = numericInput("Ingrese valor");
        EditText n2 = numericInput("Ingrese valor");
        EditText e2 = numericInput("Ingrese valor");
        EditText d2 = numericInput("Ingrese valor");

        body.addView(twoCol(field("N1", "N", "m", n1), field("E1", "E", "m", e1)));
        body.addView(twoCol(field("Distancia 1", "⌁", "m", d1), field("N2", "N", "m", n2)));
        body.addView(twoCol(field("E2", "E", "m", e2), field("Distancia 2", "⌁", "m", d2)));

        Button calc = primaryAction("Calcular intersección");
        body.addView(calc);

        LinearLayout results = resultPanel("Posibles soluciones");
        MetricView aN = metric("Solución A · N", "m");
        MetricView aE = metric("Solución A · E", "m");
        MetricView bN = metric("Solución B · N", "m");
        MetricView bE = metric("Solución B · E", "m");
        results.addView(twoCol(aN.box, aE.box));
        results.addView(twoCol(bN.box, bE.box));
        TextView note = infoNote("Puede existir una sola solución (tangencia) o dos soluciones reales.");
        results.addView(note);
        body.addView(results);

        calc.setOnClickListener(v -> {
            try {
                double N1 = parse(n1), E1 = parse(e1), N2 = parse(n2), E2 = parse(e2);
                double R1 = parse(d1), R2 = parse(d2);
                if (R1 <= 0 || R2 <= 0) throw new IllegalArgumentException();
                double deltaN = N2 - N1, deltaE = E2 - E1, distBase = Math.hypot(deltaN, deltaE);
                if (distBase == 0 || distBase > R1 + R2 || distBase < Math.abs(R1 - R2)) {
                    throw new IllegalArgumentException();
                }
                double a = (R1 * R1 - R2 * R2 + distBase * distBase) / (2 * distBase);
                double h2 = R1 * R1 - a * a;
                if (h2 < -1e-8) throw new IllegalArgumentException();
                double h = Math.sqrt(Math.max(0, h2));
                double baseN = N1 + a * deltaN / distBase;
                double baseE = E1 + a * deltaE / distBase;
                double offN = -deltaE * h / distBase;
                double offE = deltaN * h / distBase;

                aN.value.setText(f3(baseN + offN));
                aE.value.setText(f3(baseE + offE));
                bN.value.setText(f3(baseN - offN));
                bE.value.setText(f3(baseE - offE));
                if (h < 1e-7) {
                    note.setText("Los círculos son tangentes: ambas soluciones coinciden en el mismo punto.");
                } else {
                    note.setText("Se obtuvieron dos soluciones reales. Verifica en campo cuál corresponde.");
                }
                note.setTextColor(BLUE_SOFT);
            } catch (Exception ex) {
                clearMetrics(aN, aE, bN, bE);
                note.setText("No existe intersección real, los radios son inválidos o los puntos base coinciden.");
                note.setTextColor(RED);
            }
        });

        return collapsibleSection("◉", "Intersección por dos distancias", body, false);
    }

    private View buildProjectionSection() {
        LinearLayout body = verticalBox();
        body.addView(descriptionText("Proyecta un punto sobre una línea y calcula la distancia longitudinal y el offset lateral."));

        EditText n1 = numericInput("Ingrese valor");
        EditText e1 = numericInput("Ingrese valor");
        EditText n2 = numericInput("Ingrese valor");
        EditText e2 = numericInput("Ingrese valor");
        EditText nP = numericInput("Ingrese valor");
        EditText eP = numericInput("Ingrese valor");

        body.addView(twoCol(field("N1", "N", "m", n1), field("E1", "E", "m", e1)));
        body.addView(twoCol(field("N2", "N", "m", n2), field("E2", "E", "m", e2)));
        body.addView(twoCol(field("N punto", "N", "m", nP), field("E punto", "E", "m", eP)));

        Button calc = primaryAction("Calcular proyección");
        body.addView(calc);

        LinearLayout results = resultPanel("Resultado");
        MetricView nProj = metric("N proyectado", "m");
        MetricView eProj = metric("E proyectado", "m");
        MetricView abscisa = metric("Abscisa", "m");
        MetricView offset = metric("Offset", "m");
        MetricView side = metric("Lado", "");
        results.addView(twoCol(nProj.box, eProj.box));
        results.addView(twoCol(abscisa.box, offset.box));
        results.addView(singleRow(side.box));
        TextView note = infoNote("Offset positivo = izquierda y offset negativo = derecha, mirando de A hacia B.");
        results.addView(note);
        body.addView(results);

        calc.setOnClickListener(v -> {
            try {
                double dN = parse(n2) - parse(n1);
                double dE = parse(e2) - parse(e1);
                double len2 = dN * dN + dE * dE;
                if (len2 == 0) throw new IllegalArgumentException();
                double pN = parse(nP) - parse(n1);
                double pE = parse(eP) - parse(e1);
                double t = (pN * dN + pE * dE) / len2;
                double qN = parse(n1) + t * dN;
                double qE = parse(e1) + t * dE;
                double len = Math.sqrt(len2);
                double chainage = t * len;
                double cross = dN * pE - dE * pN;
                double off = cross / len;

                nProj.value.setText(f3(qN));
                eProj.value.setText(f3(qE));
                abscisa.value.setText(f3(chainage));
                offset.value.setText(signed(off));
                side.value.setText(off > 0 ? "Izquierda" : (off < 0 ? "Derecha" : "Sobre la línea"));
                String position = t < 0 ? "antes de A" : (t > 1 ? "después de B" : "dentro del segmento");
                note.setText("La proyección cae " + position + ". Offset positivo = izquierda mirando A→B.");
                note.setTextColor(BLUE_SOFT);
            } catch (Exception ex) {
                clearMetrics(nProj, eProj, abscisa, offset, side);
                note.setText("Revisa los puntos. La línea base no puede tener longitud cero.");
                note.setTextColor(RED);
            }
        });

        return collapsibleSection("⊥", "Proyección y offset a una línea", body, false);
    }

    private View buildDivisionSection() {
        LinearLayout body = verticalBox();
        body.addView(descriptionText("Calcula el punto medio o un punto sobre el tramo A–B usando una fracción o una distancia desde A."));

        EditText n1 = numericInput("Ingrese valor");
        EditText e1 = numericInput("Ingrese valor");
        EditText n2 = numericInput("Ingrese valor");
        EditText e2 = numericInput("Ingrese valor");
        EditText factor = numericInput("0.5 para punto medio");
        EditText distance = numericInput("Opcional");
        factor.setText("0.5");

        body.addView(twoCol(field("N1", "N", "m", n1), field("E1", "E", "m", e1)));
        body.addView(twoCol(field("N2", "N", "m", n2), field("E2", "E", "m", e2)));

        LinearLayout quickRow = new LinearLayout(this);
        quickRow.setOrientation(LinearLayout.HORIZONTAL);
        quickRow.setGravity(Gravity.CENTER_VERTICAL);
        quickRow.setLayoutParams(blockLp(0, 0, 0, 6));
        Button midButton = secondaryAction("Usar punto medio");
        Button freeButton = secondaryAction("Usar fracción / distancia");
        quickRow.addView(midButton, weighted(1f, 0, 0, 5, 0));
        quickRow.addView(freeButton, weighted(1f, 5, 0, 0, 0));
        body.addView(quickRow);

        body.addView(twoCol(field("Fracción", "ƒ", "", factor), field("Distancia desde A", "⌁", "m", distance)));

        Button calc = primaryAction("Calcular punto");
        body.addView(calc);

        LinearLayout results = resultPanel("Resultado");
        MetricView nCalc = metric("N calculado", "m");
        MetricView eCalc = metric("E calculado", "m");
        MetricView frac = metric("Fracción", "");
        MetricView dFromA = metric("Distancia desde A", "m");
        results.addView(twoCol(nCalc.box, eCalc.box));
        results.addView(twoCol(frac.box, dFromA.box));
        TextView note = infoNote("Si llenas la distancia, la fracción se calculará automáticamente según la longitud del tramo.");
        results.addView(note);
        body.addView(results);

        midButton.setOnClickListener(v -> {
            factor.setText("0.5");
            distance.setText("");
            showToast("Modo punto medio preparado.");
        });
        freeButton.setOnClickListener(v -> showToast("Puedes ingresar una fracción o una distancia desde A."));

        calc.setOnClickListener(v -> {
            try {
                double dN = parse(n2) - parse(n1);
                double dE = parse(e2) - parse(e1);
                double len = Math.hypot(dN, dE);
                if (len == 0) throw new IllegalArgumentException();
                double t = blank(distance) ? parse(factor) : parse(distance) / len;
                double n = parse(n1) + t * dN;
                double e = parse(e1) + t * dE;
                nCalc.value.setText(f3(n));
                eCalc.value.setText(f3(e));
                frac.value.setText(f4(t));
                dFromA.value.setText(f3(t * len));
                if (t < 0 || t > 1) {
                    note.setText("El punto calculado queda fuera del segmento A–B.");
                } else if (Math.abs(t - 0.5) < 1e-9) {
                    note.setText("Se calculó el punto medio exacto del tramo.");
                } else {
                    note.setText("Punto calculado dentro del tramo según la fracción o distancia indicada.");
                }
                note.setTextColor(BLUE_SOFT);
            } catch (Exception ex) {
                clearMetrics(nCalc, eCalc, frac, dFromA);
                note.setText("Revisa las coordenadas y la fracción o distancia. El tramo A–B no puede ser nulo.");
                note.setTextColor(RED);
            }
        });

        return collapsibleSection("÷", "Punto medio y división de línea", body, false);
    }

    private View collapsibleSection(String iconText, String titleText, LinearLayout body, boolean open) {
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.setPadding(dp(12), dp(12), dp(12), dp(12));
        wrapper.setBackground(gradient(CARD_A, CARD_B, 18, 1, STROKE));
        if (Build.VERSION.SDK_INT >= 21) wrapper.setElevation(dp(1.2f));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(12));
        wrapper.setLayoutParams(lp);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView icon = label(iconText, 22f, true, BLUE);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(gradient(Color.rgb(16, 47, 82), Color.rgb(10, 31, 51), 14, 1, FIELD_STROKE));
        header.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(48)));

        TextView title = label(titleText, 18.5f, true, TEXT);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        titleLp.setMargins(dp(10), 0, 0, 0);
        header.addView(title, titleLp);

        TextView arrow = label(open ? "⌃" : "›", 24f, true, Color.WHITE);
        arrow.setGravity(Gravity.CENTER);
        header.addView(arrow, new LinearLayout.LayoutParams(dp(36), dp(36)));
        wrapper.addView(header);

        body.setVisibility(open ? View.VISIBLE : View.GONE);
        body.setPadding(0, dp(10), 0, 0);
        wrapper.addView(body);

        header.setOnClickListener(v -> {
            boolean show = body.getVisibility() != View.VISIBLE;
            body.setVisibility(show ? View.VISIBLE : View.GONE);
            arrow.setText(show ? "⌃" : "›");
        });
        return wrapper;
    }

    private LinearLayout verticalBox() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        return box;
    }

    private TextView descriptionText(String value) {
        TextView view = label(value, 13.2f, false, SUBTEXT);
        view.setLineSpacing(0, 1.13f);
        view.setLayoutParams(blockLp(0, 0, 0, 10));
        return view;
    }

    private LinearLayout field(String labelText, String prefix, String unit, EditText input) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);

        TextView label = label("• " + labelText, 12.2f, false, BLUE_SOFT);
        label.setLayoutParams(blockLp(2, 0, 2, 5));
        box.addView(label);

        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.HORIZONTAL);
        shell.setGravity(Gravity.CENTER_VERTICAL);
        shell.setPadding(dp(10), 0, dp(10), 0);
        shell.setBackground(gradient(FIELD_BG, FIELD_BG, 11, 1, FIELD_STROKE));

        TextView badge = label(prefix, 13.5f, true, SUBTEXT);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(gradient(Color.rgb(15, 37, 60), Color.rgb(10, 29, 47), 14, 1, Color.rgb(57, 87, 119)));
        shell.addView(badge, new LinearLayout.LayoutParams(dp(30), dp(30)));

        input.setBackgroundColor(Color.TRANSPARENT);
        input.setPadding(dp(10), 0, dp(10), 0);
        shell.addView(input, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        TextView suffix = label(unit, 13.2f, false, SUBTEXT);
        suffix.setGravity(Gravity.CENTER);
        shell.addView(suffix, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        box.addView(shell, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        return box;
    }

    private EditText numericInput(String hint) {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setSingleLine(true);
        input.setHint(hint);
        input.setHintTextColor(MUTED);
        input.setTextColor(TEXT);
        ResponsiveUi.configureText(input, 14.2f);
        return input;
    }

    private Button primaryAction(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setBackground(gradient(PRIMARY_A, PRIMARY_B, 12, 0, 0));
        ResponsiveUi.configureCompactText(button, 14.8f, 11f, 1);
        if (Build.VERSION.SDK_INT >= 21) {
            button.setStateListAnimator(null);
            button.setElevation(dp(2));
        }
        button.setLayoutParams(blockLp(2, 6, 2, 8));
        return button;
    }

    private Button secondaryAction(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextColor(TEXT);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setBackground(gradient(Color.rgb(11, 35, 56), Color.rgb(7, 26, 43), 11, 1, STROKE));
        ResponsiveUi.configureCompactText(button, 13.2f, 10f, 1);
        if (Build.VERSION.SDK_INT >= 21) button.setStateListAnimator(null);
        return button;
    }

    private LinearLayout resultPanel(String titleText) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(10), dp(10), dp(10));
        panel.setBackground(gradient(INNER_A, INNER_B, 16, 1, FIELD_STROKE));
        panel.setLayoutParams(blockLp(0, 2, 0, 0));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setLayoutParams(blockLp(0, 0, 0, 8));

        TextView icon = label("▣", 15f, true, BLUE);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(gradient(Color.rgb(12, 42, 70), Color.rgb(8, 28, 46), 12, 1, FIELD_STROKE));
        head.addView(icon, new LinearLayout.LayoutParams(dp(34), dp(34)));

        TextView title = label(titleText, 16f, true, TEXT);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        titleLp.setMargins(dp(8), 0, 0, 0);
        head.addView(title, titleLp);

        TextView sparkle = label("✦", 16f, true, BLUE);
        sparkle.setGravity(Gravity.CENTER);
        head.addView(sparkle, new LinearLayout.LayoutParams(dp(24), dp(24)));

        panel.addView(head);
        return panel;
    }

    private MetricView metric(String labelText, String unit) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutParams(blockLp(0, 0, 0, 8));
        box.setMinimumHeight(dp(76));

        TextView label = label(labelText, 12.2f, false, SUBTEXT);
        ResponsiveUi.configureCompactText(label, 12.2f, 9.5f, 1);
        label.setSingleLine(true);
        label.setGravity(Gravity.CENTER_VERTICAL);
        label.setLayoutParams(blockLp(2, 0, 2, 4));
        box.addView(label);

        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.HORIZONTAL);
        shell.setGravity(Gravity.CENTER_VERTICAL);
        shell.setPadding(dp(9), 0, dp(9), 0);
        shell.setBackground(gradient(FIELD_BG, FIELD_BG, 10, 1, Color.rgb(40, 74, 115)));
        shell.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        TextView value = label("—", 16f, true, TEXT);
        value.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        ResponsiveUi.configureCompactText(value, 16f, 10f, 1);
        value.setSingleLine(true);
        value.setGravity(Gravity.CENTER_VERTICAL);
        value.setIncludeFontPadding(false);
        LinearLayout.LayoutParams valueLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        valueLp.setMarginEnd(unit == null || unit.isEmpty() ? 0 : dp(4));
        shell.addView(value, valueLp);

        TextView suffix = label(unit == null ? "" : unit, 12.5f, false, SUBTEXT);
        ResponsiveUi.configureCompactText(suffix, 12.5f, 9f, 1);
        suffix.setSingleLine(true);
        suffix.setGravity(Gravity.CENTER_VERTICAL);
        suffix.setIncludeFontPadding(false);
        shell.addView(suffix, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        box.addView(shell);
        return new MetricView(box, value);
    }

    private TextView infoNote(String text) {
        TextView note = label(text, 12.4f, false, SUBTEXT);
        note.setLineSpacing(0, 1.12f);
        note.setPadding(dp(10), dp(9), dp(10), dp(9));
        note.setBackground(gradient(INFO_BG, INFO_BG, 11, 1, Color.rgb(34, 74, 118)));
        note.setLayoutParams(blockLp(0, 2, 0, 0));
        return note;
    }

    private LinearLayout twoCol(View left, View right) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.TOP);
        row.setLayoutParams(blockLp(0, 0, 0, 8));
        int gap = ResponsiveUi.isNarrow(this) ? 3 : 5;
        row.addView(left, weighted(1f, 0, 0, gap, 0));
        row.addView(right, weighted(1f, gap, 0, 0, 0));
        return row;
    }

    private LinearLayout threeCol(View a, View b, View c) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.TOP);
        row.setLayoutParams(blockLp(0, 0, 0, 8));
        int gap = ResponsiveUi.isNarrow(this) ? 2 : 4;
        row.addView(a, weighted(1f, 0, 0, gap, 0));
        row.addView(b, weighted(1f, gap, 0, gap, 0));
        row.addView(c, weighted(1f, gap, 0, 0, 0));
        return row;
    }

    private LinearLayout singleRow(View child) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutParams(blockLp(0, 0, 0, 8));
        row.addView(child, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return row;
    }


    private String compactBearingToQuadrant(double azimuth) {
        double az = normalizeBearing(azimuth);
        if (az <= 90.0) return "N " + f3(az) + "° E";
        if (az <= 180.0) return "S " + f3(180.0 - az) + "° E";
        if (az <= 270.0) return "S " + f3(az - 180.0) + "° O";
        return "N " + f3(360.0 - az) + "° O";
    }

    private void clearMetrics(MetricView... metrics) {
        if (metrics == null) return;
        for (MetricView metric : metrics) {
            if (metric != null && metric.value != null) metric.value.setText("—");
        }
    }

    private TextView label(String text, float size, boolean bold, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(color);
        view.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        ResponsiveUi.configureText(view, size);
        return view;
    }

    private GradientDrawable gradient(int start, int end, int radiusDp, int strokeDp, int strokeColor) {
        GradientDrawable drawable = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{start, end});
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), strokeColor);
        return drawable;
    }

    private LinearLayout.LayoutParams weighted(float weight, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        lp.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return lp;
    }

    private LinearLayout.LayoutParams blockLp(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return lp;
    }
}
