package com.bph.geotopo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MapColorScheme;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Mapa online principal de GeoTopo.
 *
 * Los mapas online usan exclusivamente Google Maps SDK (normal, oscuro,
 * hibrido/satelite y terreno). Los MBTiles siguen en OfflineMapActivity.
 * Los puntos guardados se mantienen ocultos hasta que el usuario pulsa Puntos.
 */
public class GoogleMapActivity extends Activity implements LocationListener {
    private static final int REQ_LOCATION = 9501;
    private static final String PREFS = "geo_topo_prefs";
    private static final String GPS_PREFS = "geo_topo_gps_points";
    private static final String KEY_POINTS = "points_json";
    private static final String KEY_MAP_MODE = "map_mode";
    private static final double DEFAULT_ZOOM = 15.0;

    private MapView mapView;
    private GoogleMap map;
    private LocationManager locationManager;
    private Location currentLocation;
    private String currentMode = "standard";
    private boolean centerWhenLocationArrives;
    private boolean pointsVisible;

    private TextView statusView;
    private LinearLayout measurePanel;
    private TextView measureResultView;
    private LinearLayout selectedPanel;
    private TextView selectedTitle;
    private TextView selectedCoords;
    private Marker selectedMarker;
    private LatLng selectedPoint;

    private final List<Marker> savedMarkers = new ArrayList<>();
    private final List<PointInfo> savedPoints = new ArrayList<>();
    private final List<LatLng> measurementPoints = new ArrayList<>();
    private final List<Marker> measurementMarkers = new ArrayList<>();
    private Polyline measurementLine;
    private Polygon measurementPolygon;
    private boolean measurementActive;
    private boolean areaMode;

    private LatLng orientationA;
    private LatLng orientationB;
    private double orientationBearing;
    private double orientationDistance;
    private Polyline orientationLine;
    private Marker orientationMarkerA;
    private Marker orientationMarkerB;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        currentMode = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_MAP_MODE, "standard");
        if ("offline".equals(currentMode)) currentMode = "standard";
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        readIntent();
        buildUi(savedInstanceState);
    }

    private void buildUi(Bundle savedInstanceState) {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(12, 18, 25));

        if (!mapsApiConfigured()) {
            root.addView(buildMissingKeyPanel(), new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            setContentView(root);
            return;
        }

        mapView = new MapView(this);
        mapView.onCreate(savedInstanceState);
        root.addView(mapView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        root.addView(buildTopBar(), topBarLp());
        addRightControls(root);
        addBottomControls(root);
        setContentView(root);

        mapView.getMapAsync(googleMap -> {
            map = googleMap;
            configureGoogleMap();
            applyMapMode(currentMode, false);
            initializeCameraAndContent();
        });
    }

    private boolean mapsApiConfigured() {
        try {
            ApplicationInfo info = getPackageManager().getApplicationInfo(getPackageName(), PackageManager.GET_META_DATA);
            if (info.metaData == null) return false;
            String key = info.metaData.getString("com.google.android.geo.API_KEY", "");
            return key != null && !key.trim().isEmpty()
                    && !key.contains("YOUR_GOOGLE_MAPS_API_KEY")
                    && !key.contains("CHANGE_ME");
        } catch (Exception e) {
            return false;
        }
    }

    private View buildMissingKeyPanel() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER);
        page.setPadding(dp(28), dp(28), dp(28), dp(28));
        page.setBackgroundColor(Color.rgb(8, 19, 31));

        TextView title = text("Google Maps no está configurado", 22, true, Color.WHITE);
        title.setGravity(Gravity.CENTER);
        page.addView(title);

        TextView body = text("Agrega el secreto MAPS_API_KEY en GitHub Actions. GeoTopo no mostrará mapas online con una clave prestada o incrustada. El mapa offline sigue disponible.", 14, false, Color.rgb(190, 211, 229));
        body.setGravity(Gravity.CENTER);
        body.setPadding(0, dp(10), 0, dp(18));
        page.addView(body);

        Button offline = button("Abrir mapa offline");
        offline.setOnClickListener(v -> startActivity(new Intent(this, OfflineMapActivity.class)));
        page.addView(offline, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        Button back = button("Volver");
        back.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        lp.setMargins(0, dp(10), 0, 0);
        page.addView(back, lp);
        return page;
    }

    private void configureGoogleMap() {
        if (map == null) return;
        map.getUiSettings().setZoomControlsEnabled(false);
        map.getUiSettings().setMapToolbarEnabled(false);
        map.getUiSettings().setMyLocationButtonEnabled(false);
        map.getUiSettings().setCompassEnabled(true);
        map.getUiSettings().setScrollGesturesEnabled(true);
        map.getUiSettings().setZoomGesturesEnabled(true);
        map.getUiSettings().setRotateGesturesEnabled(true);
        map.getUiSettings().setTiltGesturesEnabled(true);
        map.setMinZoomPreference(2f);
        map.setMaxZoomPreference(21f);
        // Keep Google attribution/logo and built-in UI clear of GeoTopo overlays.
        map.setPadding(dp(4), dp(66), dp(64), dp(138));

        map.setOnMapLongClickListener(this::selectPoint);
        map.setOnMapClickListener(point -> {
            if (!measurementActive) return;
            measurementPoints.add(point);
            redrawMeasurement();
        });
        map.setOnMarkerClickListener(marker -> {
            Object tag = marker.getTag();
            if (tag instanceof PointInfo) {
                PointInfo p = (PointInfo) tag;
                status("Punto " + p.name + " · " + p.project);
                return false;
            }
            return false;
        });
        enableGoogleLocationLayer();
    }

    private View buildTopBar() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView back = text("‹", 31, true, Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setBackground(round(Color.argb(240, 38, 42, 48), 24, 1, Color.argb(75, 255, 255, 255)));
        back.setOnClickListener(v -> finish());
        row.addView(back, new LinearLayout.LayoutParams(dp(46), dp(46)));

        TextView search = text("⌕   Buscar aquí", 16.5f, false, Color.rgb(232, 236, 241));
        search.setGravity(Gravity.CENTER_VERTICAL);
        search.setSingleLine(true);
        search.setPadding(dp(16), 0, dp(10), 0);
        search.setBackground(round(Color.argb(247, 47, 51, 57), 24, 1, Color.argb(70, 255, 255, 255)));
        search.setOnClickListener(v -> showSearchDialog());
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        searchLp.setMargins(dp(8), 0, dp(8), 0);
        row.addView(search, searchLp);

        TextView more = text("⋮", 25, true, Color.WHITE);
        more.setGravity(Gravity.CENTER);
        more.setBackground(round(Color.argb(240, 38, 42, 48), 24, 1, Color.argb(75, 255, 255, 255)));
        more.setOnClickListener(v -> showInfo());
        row.addView(more, new LinearLayout.LayoutParams(dp(46), dp(46)));
        return row;
    }

    private FrameLayout.LayoutParams topBarLp() {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54), Gravity.TOP);
        lp.setMargins(dp(12), dp(10), dp(12), 0);
        return lp;
    }

    private void addRightControls(FrameLayout root) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);

        ImageButton layers = floatingButton(R.drawable.ic_map_layers, "Mapas y capas", v -> showLayers());
        col.addView(layers, new LinearLayout.LayoutParams(dp(46), dp(46)));

        ImageButton locate = floatingButton(R.drawable.ic_map_location, "Mi ubicación", v -> centerOnLocation(true));
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(dp(46), dp(46));
        llp.setMargins(0, dp(8), 0, 0);
        col.addView(locate, llp);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.END);
        lp.setMargins(0, dp(76), dp(12), 0);
        root.addView(col, lp);
    }

    private void addBottomControls(FrameLayout root) {
        statusView = text("Mapa listo", 11.2f, true, Color.WHITE);
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(dp(12), dp(7), dp(12), dp(7));
        statusView.setBackground(round(Color.argb(238, 20, 37, 54), 18, 1, Color.argb(70, 255, 255, 255)));
        statusView.setOnClickListener(v -> showLocationData());
        FrameLayout.LayoutParams statusLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        statusLp.setMargins(dp(34), 0, dp(34), dp(68));
        root.addView(statusView, statusLp);

        LinearLayout dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setGravity(Gravity.CENTER);
        dock.setPadding(dp(6), dp(5), dp(6), dp(5));
        dock.setBackground(round(Color.argb(244, 18, 34, 50), 22, 1, Color.argb(70, 255, 255, 255)));
        dock.addView(toolButton(R.drawable.ic_map_points, "Puntos", v -> showSavedPointsPanel()), weightLp());
        dock.addView(toolButton(R.drawable.ic_map_measure, "Medir", v -> showMeasureChooser()), weightLp());
        FrameLayout.LayoutParams dockLp = new FrameLayout.LayoutParams(dp(220), dp(58), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        dockLp.setMargins(0, 0, 0, dp(7));
        root.addView(dock, dockLp);

        measurePanel = buildMeasurePanel();
        measurePanel.setVisibility(View.GONE);
        FrameLayout.LayoutParams measureLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        measureLp.setMargins(dp(12), 0, dp(12), dp(70));
        root.addView(measurePanel, measureLp);

        selectedPanel = buildSelectedPanel();
        selectedPanel.setVisibility(View.GONE);
        FrameLayout.LayoutParams selectedLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        selectedLp.setMargins(dp(12), 0, dp(12), dp(70));
        root.addView(selectedPanel, selectedLp);
    }

    private LinearLayout buildMeasurePanel() {
        LinearLayout panel = panel();
        measureResultView = text("Toca el mapa para medir", 13, true, Color.WHITE);
        measureResultView.setPadding(0, 0, 0, dp(7));
        panel.addView(measureResultView);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button undo = button("Deshacer");
        undo.setOnClickListener(v -> undoMeasurement());
        row.addView(undo, weightLp());
        Button clear = button("Limpiar");
        clear.setOnClickListener(v -> clearMeasurement());
        row.addView(clear, weightLp());
        Button done = button("Listo");
        done.setOnClickListener(v -> finishMeasurement());
        row.addView(done, weightLp());
        panel.addView(row);
        return panel;
    }

    private LinearLayout buildSelectedPanel() {
        LinearLayout panel = panel();
        selectedTitle = text("Punto del mapa", 15, true, Color.WHITE);
        selectedCoords = text("—", 12, false, Color.rgb(194, 219, 237));
        selectedCoords.setPadding(0, dp(2), 0, dp(8));
        panel.addView(selectedTitle);
        panel.addView(selectedCoords);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button save = button("Guardar punto");
        save.setOnClickListener(v -> saveSelectedPoint());
        row.addView(save, weightLp());
        Button measure = button("Medir desde aquí");
        measure.setOnClickListener(v -> {
            if (selectedPoint != null) {
                clearMeasurement();
                measurementPoints.add(selectedPoint);
                startMeasurement(false, false);
            }
        });
        row.addView(measure, weightLp());
        Button close = button("Cerrar");
        close.setOnClickListener(v -> closeSelectedPoint());
        row.addView(close, weightLp());
        panel.addView(row);
        return panel;
    }

    private void initializeCameraAndContent() {
        Intent i = getIntent();
        if (i != null && i.hasExtra("camera_lat") && i.hasExtra("camera_lon")) {
            CameraPosition cp = new CameraPosition.Builder()
                    .target(new LatLng(i.getDoubleExtra("camera_lat", 0), i.getDoubleExtra("camera_lon", 0)))
                    .zoom((float) i.getDoubleExtra("camera_zoom", DEFAULT_ZOOM))
                    .bearing((float) i.getDoubleExtra("camera_bearing", 0))
                    .tilt(0)
                    .build();
            map.moveCamera(CameraUpdateFactory.newCameraPosition(cp));
        } else if (currentLocation != null) {
            moveTo(currentLocation.getLatitude(), currentLocation.getLongitude(), DEFAULT_ZOOM, false);
        } else {
            Location remembered = readRememberedLocation();
            if (remembered != null) {
                currentLocation = remembered;
                moveTo(remembered.getLatitude(), remembered.getLongitude(), DEFAULT_ZOOM, false);
            } else {
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(-9.19, -75.015), 5.2f));
                status("Activa Ubicación para centrar tu posición");
            }
        }

        if (orientationA != null && orientationB != null) drawOrientation();
        if (getIntent() != null && getIntent().getBooleanExtra("show_saved_points", false)) {
            showPointsRequestedByIntent();
        }
        requestLocationUpdatesIfPermitted();
    }

    private void applyMapMode(String mode, boolean animate) {
        if (map == null) return;
        if (mode == null || mode.trim().isEmpty()) mode = "standard";
        if ("offline".equals(mode)) {
            startActivity(new Intent(this, OfflineMapActivity.class));
            return;
        }
        currentMode = mode;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_MAP_MODE, currentMode).apply();
        CameraPosition camera = map.getCameraPosition();

        if ("satellite".equals(mode)) {
            map.setMapType(GoogleMap.MAP_TYPE_HYBRID);
            try { map.setMapColorScheme(MapColorScheme.LIGHT); } catch (Throwable ignored) { }
            status("Satélite híbrido");
        } else if ("topo".equals(mode)) {
            map.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
            try { map.setMapColorScheme(MapColorScheme.LIGHT); } catch (Throwable ignored) { }
            status("Terreno");
        } else if ("dark".equals(mode)) {
            map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
            try { map.setMapColorScheme(MapColorScheme.DARK); } catch (Throwable ignored) { }
            status("Mapa oscuro");
        } else {
            map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
            try { map.setMapColorScheme(MapColorScheme.LIGHT); } catch (Throwable ignored) { }
            status("Mapa");
        }
        if (camera != null) {
            if (animate) map.animateCamera(CameraUpdateFactory.newCameraPosition(camera), 250, null);
            else map.moveCamera(CameraUpdateFactory.newCameraPosition(camera));
        }
    }

    private void showLayers() {
        MapLayerPicker.show(this, currentMode, new MapLayerPicker.Listener() {
            @Override public void onLayerSelected(String mode) {
                if ("offline".equals(mode)) {
                    startActivity(new Intent(GoogleMapActivity.this, OfflineMapActivity.class));
                    return;
                }
                applyMapMode(mode, false);
            }
            @Override public void onManageOffline() {
                startActivity(new Intent(GoogleMapActivity.this, OfflineMapActivity.class));
            }
        });
    }

    private void centerOnLocation(boolean forceFresh) {
        if (hasLocationPermission()) {
            enableGoogleLocationLayer();
            if (forceFresh) {
                centerWhenLocationArrives = true;
                requestLocationUpdatesIfPermitted();
            }
            if (currentLocation != null) {
                moveTo(currentLocation.getLatitude(), currentLocation.getLongitude(), DEFAULT_ZOOM, true);
                centerWhenLocationArrives = false;
            }
            return;
        }
        requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void enableGoogleLocationLayer() {
        if (map == null || !hasLocationPermission()) return;
        try { map.setMyLocationEnabled(true); } catch (SecurityException ignored) { }
    }

    private void requestLocationUpdatesIfPermitted() {
        if (!hasLocationPermission() || locationManager == null) return;
        try {
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper());
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000L, 0f, this, Looper.getMainLooper());
        } catch (Exception ignored) { }
    }

    @Override public void onLocationChanged(Location location) {
        if (location == null) return;
        if (currentLocation == null || isBetter(location, currentLocation)) currentLocation = new Location(location);
        if (currentLocation != null) {
            saveRememberedLocation(currentLocation);
            updateLocationStatus();
            if (centerWhenLocationArrives) {
                moveTo(currentLocation.getLatitude(), currentLocation.getLongitude(), DEFAULT_ZOOM, true);
                centerWhenLocationArrives = false;
            }
        }
    }

    private boolean isBetter(Location candidate, Location current) {
        long dt = candidate.getTime() - current.getTime();
        if (dt > 10000L) return true;
        if (dt < -30000L) return false;
        if (!candidate.hasAccuracy()) return false;
        return !current.hasAccuracy() || candidate.getAccuracy() <= current.getAccuracy() + 30f;
    }

    private void moveTo(double lat, double lon, double zoom, boolean animate) {
        if (map == null) return;
        CameraPosition pos = new CameraPosition.Builder()
                .target(new LatLng(lat, lon)).zoom((float) zoom).bearing(0f).tilt(0f).build();
        if (animate) map.animateCamera(CameraUpdateFactory.newCameraPosition(pos), 450, null);
        else map.moveCamera(CameraUpdateFactory.newCameraPosition(pos));
    }

    private void updateLocationStatus() {
        if (currentLocation == null) return;
        float accuracy = currentLocation.hasAccuracy() ? currentLocation.getAccuracy() : 0f;
        SharedPreferences sp = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
        int used = sp.getInt("last_satellites_used", 0);
        int visible = sp.getInt("last_satellites_visible", 0);
        status("±" + format1(accuracy) + " m · " + used + "/" + visible + " sat · GPS");
    }

    private void showLocationData() {
        Location loc = currentLocation != null ? currentLocation : readRememberedLocation();
        if (loc == null) {
            Toast.makeText(this, "Aún no hay una lectura de ubicación.", Toast.LENGTH_SHORT).show();
            return;
        }
        CoordinateUtils.Utm utm = CoordinateUtils.toUtm(loc.getLatitude(), loc.getLongitude());
        SharedPreferences sp = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
        String msg = String.format(Locale.US,
                "Latitud: %.8f\nLongitud: %.8f\nUTM: %s  %.3f E / %.3f N\nPrecisión: ±%.1f m\nSatélites: %d / %d\nProveedor: %s",
                loc.getLatitude(), loc.getLongitude(), (utm.zone + utm.hemisphere()), utm.easting, utm.northing,
                loc.hasAccuracy() ? loc.getAccuracy() : 0f,
                sp.getInt("last_satellites_used", 0), sp.getInt("last_satellites_visible", 0),
                loc.getProvider() == null ? "—" : loc.getProvider());
        new AlertDialog.Builder(this).setTitle("Ubicación actual").setMessage(msg).setPositiveButton("Cerrar", null).show();
    }

    private void showSearchDialog() {
        EditText input = new EditText(this);
        input.setHint("Lugar, dirección o latitud,longitud");
        input.setSingleLine(true);
        int p = dp(16);
        input.setPadding(p, p, p, p);
        new AlertDialog.Builder(this)
                .setTitle("Buscar en el mapa")
                .setView(input)
                .setPositiveButton("Buscar", (d, w) -> search(input.getText().toString().trim()))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void search(String query) {
        if (query == null || query.trim().isEmpty()) return;
        LatLng direct = parseCoordinates(query);
        if (direct != null) {
            moveTo(direct.latitude, direct.longitude, 17, true);
            selectPoint(direct);
            return;
        }
        status("Buscando…");
        executor.execute(() -> {
            LatLng found = null;
            String label = query;
            try {
                Geocoder geocoder = new Geocoder(this, Locale.getDefault());
                List<Address> list = geocoder.getFromLocationName(query, 1);
                if (list != null && !list.isEmpty()) {
                    Address a = list.get(0);
                    found = new LatLng(a.getLatitude(), a.getLongitude());
                    if (a.getFeatureName() != null) label = a.getFeatureName();
                }
            } catch (Exception ignored) { }
            final LatLng result = found;
            final String resultLabel = label;
            runOnUiThread(() -> {
                if (result == null) {
                    status("No se encontró “" + query + "”");
                    return;
                }
                moveTo(result.latitude, result.longitude, 16.5, true);
                selectPoint(result);
                selectedTitle.setText(resultLabel);
            });
        });
    }

    private LatLng parseCoordinates(String value) {
        try {
            String normalized = value.trim().replace(';', ',');
            String[] parts = normalized.split(",");
            if (parts.length != 2) return null;
            double lat = Double.parseDouble(parts[0].trim());
            double lon = Double.parseDouble(parts[1].trim());
            if (lat < -90 || lat > 90 || lon < -180 || lon > 180) return null;
            return new LatLng(lat, lon);
        } catch (Exception e) {
            return null;
        }
    }

    private void selectPoint(LatLng point) {
        selectedPoint = point;
        if (selectedMarker != null) selectedMarker.remove();
        selectedMarker = map.addMarker(new MarkerOptions().position(point).title("Punto seleccionado")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));
        selectedTitle.setText("Punto del mapa");
        CoordinateUtils.Utm utm = CoordinateUtils.toUtm(point.latitude, point.longitude);
        selectedCoords.setText(String.format(Locale.US, "%.8f, %.8f · UTM %s %.3f E / %.3f N",
                point.latitude, point.longitude, (utm.zone + utm.hemisphere()), utm.easting, utm.northing));
        selectedPanel.setVisibility(View.VISIBLE);
        measurePanel.setVisibility(View.GONE);
    }

    private void closeSelectedPoint() {
        selectedPanel.setVisibility(View.GONE);
        selectedPoint = null;
        if (selectedMarker != null) selectedMarker.remove();
        selectedMarker = null;
    }

    private void saveSelectedPoint() {
        if (selectedPoint == null) return;
        final EditText input = new EditText(this);
        input.setHint(nextPointName());
        input.setSingleLine(true);
        new AlertDialog.Builder(this)
                .setTitle("Guardar punto")
                .setMessage("Se guardará la coordenada seleccionada. El marcador no queda visible automáticamente.")
                .setView(input)
                .setPositiveButton("Guardar", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) name = nextPointName();
                    persistPoint(name, selectedPoint);
                    closeSelectedPoint();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void persistPoint(String name, LatLng point) {
        try {
            String raw = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]");
            JSONArray array = new JSONArray(raw == null ? "[]" : raw);
            JSONObject o = new JSONObject();
            o.put("project", "Proyecto general");
            o.put("name", name);
            o.put("description", "");
            o.put("latitude", point.latitude);
            o.put("longitude", point.longitude);
            o.put("timestamp", System.currentTimeMillis());
            o.put("provider", "mapa");
            o.put("photoUri", "");
            array.put(o);
            getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit().putString(KEY_POINTS, array.toString()).apply();
            Toast.makeText(this, "Punto " + name + " guardado.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo guardar el punto.", Toast.LENGTH_LONG).show();
        }
    }

    private String nextPointName() {
        List<PointInfo> list = readPoints();
        int n = 1;
        while (true) {
            String candidate = "P" + n;
            boolean found = false;
            for (PointInfo p : list) if (candidate.equalsIgnoreCase(p.name)) { found = true; break; }
            if (!found) return candidate;
            n++;
        }
    }

    private void showSavedPointsPanel() {
        final List<PointInfo> points = readPoints();
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout sheet = panel();
        sheet.setPadding(dp(16), dp(12), dp(16), dp(16));
        sheet.addView(text("Puntos guardados · " + points.size(), 19, true, Color.WHITE));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button show = button("Mostrar todos");
        show.setOnClickListener(v -> { dialog.dismiss(); showAllSavedPoints(); });
        actions.addView(show, weightLp());
        Button hide = button("Ocultar");
        hide.setOnClickListener(v -> { dialog.dismiss(); hideSavedPoints(); });
        actions.addView(hide, weightLp());
        sheet.addView(actions);

        int max = Math.min(points.size(), 8);
        for (int i = 0; i < max; i++) {
            PointInfo p = points.get(i);
            TextView row = text(p.name + " · " + p.project + "\n" + String.format(Locale.US, "%.6f, %.6f", p.lat, p.lon), 13, true, Color.WHITE);
            row.setPadding(dp(12), dp(10), dp(12), dp(10));
            row.setBackground(round(Color.rgb(24, 44, 62), 13, 1, Color.rgb(59, 89, 116)));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, dp(7), 0, 0);
            sheet.addView(row, lp);
            row.setOnClickListener(v -> {
                dialog.dismiss();
                hideSavedPoints();
                Marker marker = addSavedPointMarker(p, true);
                savedMarkers.add(marker);
                pointsVisible = true;
                moveTo(p.lat, p.lon, 17.5, true);
            });
        }

        dialog.setContentView(sheet);
        dialog.setCanceledOnTouchOutside(true);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setGravity(Gravity.BOTTOM);
            WindowManager.LayoutParams p = window.getAttributes();
            p.width = WindowManager.LayoutParams.MATCH_PARENT;
            p.height = WindowManager.LayoutParams.WRAP_CONTENT;
            p.dimAmount = .28f;
            window.setAttributes(p);
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
        dialog.show();
        if (window != null) window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private void showAllSavedPoints() {
        hideSavedPoints();
        List<PointInfo> points = readPoints();
        if (points.isEmpty()) {
            Toast.makeText(this, "No hay puntos guardados.", Toast.LENGTH_SHORT).show();
            return;
        }
        LatLngBounds.Builder bounds = new LatLngBounds.Builder();
        for (PointInfo p : points) {
            savedMarkers.add(addSavedPointMarker(p, false));
            bounds.include(new LatLng(p.lat, p.lon));
        }
        pointsVisible = true;
        try { map.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds.build(), dp(70)), 500, null); }
        catch (Exception ignored) { }
        status(points.size() + " puntos visibles · Puntos para ocultarlos");
    }

    private Marker addSavedPointMarker(PointInfo p, boolean selected) {
        Marker marker = map.addMarker(new MarkerOptions()
                .position(new LatLng(p.lat, p.lon))
                .title(p.name)
                .snippet(p.project)
                .icon(BitmapDescriptorFactory.defaultMarker(selected ? BitmapDescriptorFactory.HUE_AZURE : BitmapDescriptorFactory.HUE_ORANGE)));
        if (marker != null) marker.setTag(p);
        return marker;
    }

    private void hideSavedPoints() {
        for (Marker marker : savedMarkers) if (marker != null) marker.remove();
        savedMarkers.clear();
        pointsVisible = false;
        status("Puntos ocultos");
    }

    private void showPointsRequestedByIntent() {
        Intent i = getIntent();
        boolean all = i.getBooleanExtra("show_all_saved_points", false);
        if (all) {
            showAllSavedPoints();
            return;
        }
        String name = i.getStringExtra("selected_saved_point_name");
        double lat = i.getDoubleExtra("selected_saved_point_lat", Double.NaN);
        double lon = i.getDoubleExtra("selected_saved_point_lon", Double.NaN);
        if (!Double.isNaN(lat) && !Double.isNaN(lon)) {
            PointInfo p = new PointInfo(name == null || name.isEmpty() ? "Punto" : name,
                    i.getStringExtra("saved_points_project"), lat, lon, 0);
            savedMarkers.add(addSavedPointMarker(p, true));
            pointsVisible = true;
            moveTo(lat, lon, 17.5, false);
        }
    }

    private List<PointInfo> readPoints() {
        List<PointInfo> list = new ArrayList<>();
        try {
            String raw = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]");
            JSONArray a = new JSONArray(raw == null ? "[]" : raw);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                double lat = o.optDouble("latitude", Double.NaN);
                double lon = o.optDouble("longitude", Double.NaN);
                if (Double.isNaN(lat) || Double.isNaN(lon)) continue;
                list.add(new PointInfo(o.optString("name", "Punto"), o.optString("project", "Proyecto general"), lat, lon, i));
            }
        } catch (Exception ignored) { }
        return list;
    }

    private void showMeasureChooser() {
        String[] items = {"Distancia por tramos", "Área y perímetro", "Limpiar medición"};
        new AlertDialog.Builder(this).setTitle("Medir sobre el mapa").setItems(items, (d, which) -> {
            if (which == 0) startMeasurement(false, true);
            else if (which == 1) startMeasurement(true, true);
            else clearMeasurement();
        }).setNegativeButton("Cancelar", null).show();
    }

    private void startMeasurement(boolean area, boolean clear) {
        areaMode = area;
        measurementActive = true;
        if (clear) clearMeasurementGraphics(true);
        closeSelectedPoint();
        measurePanel.setVisibility(View.VISIBLE);
        redrawMeasurement();
        status(area ? "Área: toca los vértices" : "Distancia: toca los puntos");
    }

    private void undoMeasurement() {
        if (!measurementPoints.isEmpty()) measurementPoints.remove(measurementPoints.size() - 1);
        redrawMeasurement();
    }

    private void clearMeasurement() {
        measurementActive = false;
        clearMeasurementGraphics(true);
        if (measurePanel != null) measurePanel.setVisibility(View.GONE);
        status("Medición limpiada");
    }

    private void finishMeasurement() {
        measurementActive = false;
        if (measurePanel != null) measurePanel.setVisibility(View.GONE);
        status(measurementSummary());
    }

    private void clearMeasurementGraphics(boolean clearPoints) {
        if (measurementLine != null) { measurementLine.remove(); measurementLine = null; }
        if (measurementPolygon != null) { measurementPolygon.remove(); measurementPolygon = null; }
        for (Marker m : measurementMarkers) if (m != null) m.remove();
        measurementMarkers.clear();
        if (clearPoints) measurementPoints.clear();
    }

    private void redrawMeasurement() {
        if (map == null) return;
        if (measurementLine != null) { measurementLine.remove(); measurementLine = null; }
        if (measurementPolygon != null) { measurementPolygon.remove(); measurementPolygon = null; }
        for (Marker m : measurementMarkers) if (m != null) m.remove();
        measurementMarkers.clear();

        for (int i = 0; i < measurementPoints.size(); i++) {
            Marker m = map.addMarker(new MarkerOptions().position(measurementPoints.get(i))
                    .title("P" + (i + 1)).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));
            if (m != null) measurementMarkers.add(m);
        }
        if (measurementPoints.size() >= 2) {
            measurementLine = map.addPolyline(new PolylineOptions().addAll(measurementPoints)
                    .color(Color.rgb(41, 121, 255)).width(7f));
        }
        if (areaMode && measurementPoints.size() >= 3) {
            measurementPolygon = map.addPolygon(new PolygonOptions().addAll(measurementPoints)
                    .strokeColor(Color.rgb(41, 121, 255)).strokeWidth(5f)
                    .fillColor(Color.argb(45, 41, 121, 255)));
        }
        if (measureResultView != null) measureResultView.setText(measurementSummary());
    }

    private String measurementSummary() {
        double distance = totalDistance(measurementPoints);
        if (areaMode && measurementPoints.size() >= 3) {
            double perimeter = distance + haversine(measurementPoints.get(measurementPoints.size() - 1), measurementPoints.get(0));
            double area = polygonArea(measurementPoints);
            return "Área " + formatArea(area) + " · perímetro " + formatDistance(perimeter);
        }
        return "Distancia " + formatDistance(distance) + " · " + measurementPoints.size() + " puntos";
    }

    private void drawOrientation() {
        if (map == null || orientationA == null || orientationB == null) return;
        if (orientationLine != null) orientationLine.remove();
        if (orientationMarkerA != null) orientationMarkerA.remove();
        if (orientationMarkerB != null) orientationMarkerB.remove();
        orientationLine = map.addPolyline(new PolylineOptions().add(orientationA, orientationB).color(Color.rgb(255, 149, 0)).width(7f));
        orientationMarkerA = map.addMarker(new MarkerOptions().position(orientationA).title("A").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
        orientationMarkerB = map.addMarker(new MarkerOptions().position(orientationB).title("B").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));
        LatLngBounds.Builder bounds = new LatLngBounds.Builder().include(orientationA).include(orientationB);
        try { map.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds.build(), dp(80)), 500, null); } catch (Exception ignored) { }
        status(String.format(Locale.US, "Línea A–B · %.2f m · azimut %.2f°", orientationDistance, orientationBearing));
    }

    private void readIntent() {
        Intent i = getIntent();
        if (i == null) return;
        if (i.hasExtra("latitude") && i.hasExtra("longitude")) {
            Location supplied = new Location("enviada");
            supplied.setLatitude(i.getDoubleExtra("latitude", 0));
            supplied.setLongitude(i.getDoubleExtra("longitude", 0));
            supplied.setAccuracy(i.getFloatExtra("location_accuracy", 0f));
            supplied.setTime(System.currentTimeMillis());
            currentLocation = supplied;
        }
        if (i.hasExtra("ab_a_lat") && i.hasExtra("ab_b_lat")) {
            orientationA = new LatLng(i.getDoubleExtra("ab_a_lat", 0), i.getDoubleExtra("ab_a_lon", 0));
            orientationB = new LatLng(i.getDoubleExtra("ab_b_lat", 0), i.getDoubleExtra("ab_b_lon", 0));
            orientationBearing = i.getDoubleExtra("ab_bearing", 0);
            orientationDistance = i.getDoubleExtra("ab_distance", haversine(orientationA, orientationB));
        }
    }

    private Location readRememberedLocation() {
        try {
            SharedPreferences sp = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
            String lat = sp.getString("last_latitude", "");
            String lon = sp.getString("last_longitude", "");
            if (lat == null || lon == null || lat.isEmpty() || lon.isEmpty()) return null;
            long time = sp.getLong("last_location_time", 0L);
            if (time <= 0 || System.currentTimeMillis() - time > 30L * 60L * 1000L) return null;
            Location loc = new Location(sp.getString("last_provider", "recordada"));
            loc.setLatitude(Double.parseDouble(lat));
            loc.setLongitude(Double.parseDouble(lon));
            loc.setAccuracy(sp.getFloat("last_accuracy", 0f));
            loc.setTime(time);
            return loc;
        } catch (Exception e) {
            return null;
        }
    }

    private void saveRememberedLocation(Location location) {
        if (location == null) return;
        getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit()
                .putString("last_latitude", Double.toString(location.getLatitude()))
                .putString("last_longitude", Double.toString(location.getLongitude()))
                .putFloat("last_accuracy", location.hasAccuracy() ? location.getAccuracy() : 0f)
                .putLong("last_location_time", location.getTime() > 0 ? location.getTime() : System.currentTimeMillis())
                .putString("last_provider", location.getProvider() == null ? "" : location.getProvider())
                .apply();
    }

    private void showInfo() {
        new AlertDialog.Builder(this)
                .setTitle("GeoTopo · Mapa")
                .setMessage("Mapa online: Google Maps SDK.\n\nMapa: calles de Google.\nOscuro: mapa normal en esquema oscuro.\nSatélite: Google Hybrid (imagen + calles y nombres).\nTerreno: relieve de Google.\nOffline: tus paquetes MBTiles en el visor offline.\n\nLos puntos guardados permanecen ocultos hasta que pulses Puntos.")
                .setPositiveButton("Cerrar", null).show();
    }

    private void status(String text) {
        if (statusView != null) statusView.setText(text == null ? "" : text);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            if (hasLocationPermission()) {
                enableGoogleLocationLayer();
                centerWhenLocationArrives = true;
                requestLocationUpdatesIfPermitted();
            } else Toast.makeText(this, "GeoTopo necesita ubicación para centrar el GPS.", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onStart() { super.onStart(); if (mapView != null) mapView.onStart(); }
    @Override protected void onResume() { super.onResume(); if (mapView != null) mapView.onResume(); }
    @Override protected void onPause() {
        if (mapView != null) mapView.onPause();
        if (locationManager != null) try { locationManager.removeUpdates(this); } catch (Exception ignored) { }
        super.onPause();
    }
    @Override protected void onStop() { if (mapView != null) mapView.onStop(); super.onStop(); }
    @Override public void onLowMemory() { super.onLowMemory(); if (mapView != null) mapView.onLowMemory(); }
    @Override protected void onDestroy() { executor.shutdownNow(); if (mapView != null) mapView.onDestroy(); super.onDestroy(); }
    @Override protected void onSaveInstanceState(Bundle outState) { super.onSaveInstanceState(outState); if (mapView != null) mapView.onSaveInstanceState(outState); }

    private LinearLayout panel() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(14), dp(11), dp(14), dp(12));
        p.setBackground(round(Color.argb(247, 13, 32, 49), 18, 1, Color.rgb(47, 82, 113)));
        return p;
    }

    private ImageButton floatingButton(int drawable, String description, View.OnClickListener click) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(drawable);
        b.setColorFilter(Color.WHITE);
        b.setScaleType(android.widget.ImageView.ScaleType.CENTER);
        b.setPadding(dp(10), dp(10), dp(10), dp(10));
        b.setContentDescription(description);
        b.setBackground(round(Color.argb(244, 38, 42, 48), 23, 1, Color.argb(85, 255, 255, 255)));
        b.setOnClickListener(click);
        return b;
    }

    private View toolButton(int icon, String label, View.OnClickListener click) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        ImageButton image = new ImageButton(this);
        image.setImageResource(icon);
        image.setColorFilter(Color.WHITE);
        image.setPadding(dp(7), dp(7), dp(7), dp(7));
        image.setBackground(round(Color.rgb(42, 112, 231), 18, 0, Color.TRANSPARENT));
        image.setOnClickListener(click);
        box.addView(image, new LinearLayout.LayoutParams(dp(34), dp(34)));
        TextView text = text(label, 10.5f, false, Color.WHITE);
        text.setGravity(Gravity.CENTER);
        text.setOnClickListener(click);
        box.addView(text);
        box.setOnClickListener(click);
        return box;
    }

    private Button button(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12.5f);
        b.setAllCaps(false);
        b.setBackground(round(Color.rgb(37, 87, 145), 13, 1, Color.rgb(64, 125, 190)));
        return b;
    }

    private LinearLayout.LayoutParams weightLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        return lp;
    }

    private TextView text(String value, float sp, boolean bold, int color) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextColor(color);
        v.setTextSize(sp);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private GradientDrawable round(int fill, int radiusDp, int strokeDp, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(Math.max(1, dp(strokeDp)), strokeColor);
        return d;
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private String format1(double v) { return String.format(Locale.US, "%.1f", v); }

    private double totalDistance(List<LatLng> points) {
        double sum = 0;
        for (int i = 1; i < points.size(); i++) sum += haversine(points.get(i - 1), points.get(i));
        return sum;
    }

    private double haversine(LatLng a, LatLng b) {
        double r = 6371000.0;
        double p1 = Math.toRadians(a.latitude), p2 = Math.toRadians(b.latitude);
        double dp = Math.toRadians(b.latitude - a.latitude), dl = Math.toRadians(b.longitude - a.longitude);
        double x = Math.sin(dp / 2) * Math.sin(dp / 2) + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
        return 2 * r * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
    }

    private double polygonArea(List<LatLng> points) {
        if (points.size() < 3) return 0;
        double sum = 0;
        double refLat = 0;
        for (LatLng p : points) refLat += p.latitude;
        refLat = Math.toRadians(refLat / points.size());
        double r = 6378137.0;
        for (int i = 0; i < points.size(); i++) {
            LatLng a = points.get(i), b = points.get((i + 1) % points.size());
            double ax = Math.toRadians(a.longitude) * r * Math.cos(refLat);
            double ay = Math.toRadians(a.latitude) * r;
            double bx = Math.toRadians(b.longitude) * r * Math.cos(refLat);
            double by = Math.toRadians(b.latitude) * r;
            sum += ax * by - bx * ay;
        }
        return Math.abs(sum) / 2.0;
    }

    private String formatDistance(double meters) {
        if (meters >= 1000) return String.format(Locale.US, "%.2f km", meters / 1000.0);
        return String.format(Locale.US, "%.2f m", meters);
    }

    private String formatArea(double area) {
        if (area >= 10000) return String.format(Locale.US, "%.3f ha", area / 10000.0);
        return String.format(Locale.US, "%.2f m²", area);
    }

    private static final class PointInfo {
        final String name, project;
        final double lat, lon;
        final int sourceIndex;
        PointInfo(String name, String project, double lat, double lon, int sourceIndex) {
            this.name = name == null || name.isEmpty() ? "Punto" : name;
            this.project = project == null || project.isEmpty() ? "Proyecto general" : project;
            this.lat = lat; this.lon = lon; this.sourceIndex = sourceIndex;
        }
    }
}
