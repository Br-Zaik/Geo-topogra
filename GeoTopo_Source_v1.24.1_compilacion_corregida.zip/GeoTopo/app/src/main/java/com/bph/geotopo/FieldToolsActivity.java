package com.bph.geotopo;

import android.content.Intent;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.LinearLayout;

/** Main organized launcher for all field-oriented tools. */
public class FieldToolsActivity extends BaseToolActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyPalette();

        LinearLayout root = page("Herramientas de campo", "Captura, cálculo, control y archivos para trabajo topográfico");
        LinearLayout content = vertical();

        content.addView(categoryTitle("Captura y ubicación"));
        content.addView(menuCard("⌖", "Replanteo de punto",
                "Navega hacia una coordenada con distancia, azimut, ΔN/ΔE y tolerancia.",
                v -> open(StakeoutActivity.class)));
        content.addView(menuCard("≋", "Registro de recorrido GPS",
                "Registra un trayecto, distancia, tiempo y puntos, incluso con la pantalla apagada.",
                v -> open(TrackActivity.class)));
        content.addView(menuCard("◎", "Calidad GNSS",
                "Satélites, precisión, constelaciones, C/N0 y datos NMEA disponibles.",
                v -> open(GnssQualityActivity.class)));
        content.addView(menuCard("BT", "GNSS externo Bluetooth",
                "Lee receptores NMEA emparejados y muestra tipo de solución, satélites y HDOP.",
                v -> open(ExternalGnssActivity.class)));

        content.addView(categoryTitle("Cálculos topográficos"));
        content.addView(menuCard("Δ", "COGO completo",
                "Directa, inversa, intersecciones, proyección, punto medio y offset.",
                v -> open(CogoActivity.class)));
        content.addView(menuCard("◇", "Área y perímetro",
                "Calcula terrenos por coordenadas, lados, rumbos, área y perímetro.",
                v -> open(AreaActivity.class)));
        content.addView(menuCard("⬡", "Poligonales",
                "Poligonal abierta o cerrada, cierres y compensación Bowditch.",
                v -> open(TraverseActivity.class)));
        content.addView(menuCard("≋", "Nivelación de campo",
                "Vista atrás, intermedia y adelante, altura de instrumento, cierre y ajuste.",
                v -> open(LevelingFieldActivity.class)));
        content.addView(menuCard("⌁", "Perfiles y secciones",
                "Progresivas, cotas, pendientes, perfil longitudinal y secciones transversales.",
                v -> open(ProfileActivity.class)));

        content.addView(categoryTitle("Mapas, proyectos y archivos"));
        content.addView(menuCard("▧", "Mapas sin internet",
                "Abre paquetes MBTiles propios o autorizados sin descargar desde servidores públicos.",
                v -> open(OfflineMapActivity.class)));
        content.addView(menuCard("▤", "Libreta de campo",
                "Guarda puntos, códigos, cotas, precisión, fecha y observaciones por proyecto.",
                v -> open(NotebookActivity.class)));
        content.addView(menuCard("⇄", "Importar y exportar",
                "CSV, GeoJSON, KML y copia JSON de la libreta y datos de campo.",
                v -> open(DataExchangeActivity.class)));

        root.addView(scrollWith(content), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private void open(Class<?> target) {
        startActivity(new Intent(this, target));
    }
}
