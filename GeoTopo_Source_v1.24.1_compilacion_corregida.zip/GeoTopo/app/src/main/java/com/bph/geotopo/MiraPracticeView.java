package com.bph.geotopo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

import java.util.Locale;
import java.util.Random;

/**
 * Semi-realistic metric E-staff exercise viewed through an optical level.
 * The scale is internally coherent: every pattern subdivision represents 1 cm,
 * while the user estimates the final millimetres from the crosshair position.
 */
public class MiraPracticeView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random();
    private final int panelColor;
    private final int subTextColor;
    private final float density;

    private double upperReading;
    private double middleReading;
    private double lowerReading;
    private double visibleMin;
    private double visibleMax;

    public MiraPracticeView(Context context, int accentColor, int textColor, int subTextColor, int panelColor) {
        super(context);
        this.panelColor = panelColor;
        this.subTextColor = subTextColor;
        this.density = getResources().getDisplayMetrics().density;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        newExercise();
    }

    public void newExercise() {
        // 32 cm visible window, aligned to a decimetre like a real sight through a level.
        int baseDm = 4 + random.nextInt(43); // 0.40 m to 4.60 m
        visibleMin = baseDm / 10.0;
        visibleMax = visibleMin + 0.32;

        int minMm = (int) Math.round(visibleMin * 1000.0) + 20;
        int maxMm = (int) Math.round(visibleMax * 1000.0) - 20;
        int middleMm = (minMm + maxMm) / 2 + random.nextInt(35) - 17;
        int halfSpan = 48 + random.nextInt(35); // 48–82 mm on each side.
        if (middleMm - halfSpan < minMm) middleMm = minMm + halfSpan;
        if (middleMm + halfSpan > maxMm) middleMm = maxMm - halfSpan;

        // Avoid putting every exercise exactly on a centimetre line.
        int rem = floorMod(middleMm, 10);
        if (rem == 0 || rem == 1 || rem == 9) middleMm += 4;

        middleReading = middleMm / 1000.0;
        upperReading = (middleMm + halfSpan) / 1000.0;
        lowerReading = (middleMm - halfSpan) / 1000.0;
        invalidate();
    }

    public double getUpperReading() { return upperReading; }
    public double getMiddleReading() { return middleReading; }
    public double getLowerReading() { return lowerReading; }

    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int desired = Math.round(width * 0.98f);
        setMeasuredDimension(width, resolveSize(desired, heightMeasureSpec));
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(panelColor);
        canvas.drawRoundRect(new RectF(0, 0, w, h), dp(16), dp(16), paint);

        float footer = dp(32);
        float cx = w / 2f;
        float cy = (h - footer) / 2f;
        float radius = Math.min(w * 0.455f, (h - footer) * 0.455f);
        drawScope(canvas, cx, cy, radius);

        paint.setStyle(Paint.Style.FILL);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(dp(10.5f));
        paint.setColor(subTextColor);
        canvas.drawText("Mira métrica tipo E · cada división = 1 cm · estima el último milímetro", cx, h - dp(8), paint);
    }

    private void drawScope(Canvas canvas, float cx, float cy, float radius) {
        paint.setStyle(Paint.Style.FILL);
        paint.setShadowLayer(dp(10), 0, dp(3), Color.argb(145, 0, 0, 0));
        paint.setColor(Color.rgb(14, 17, 21));
        canvas.drawCircle(cx, cy, radius + dp(7), paint);
        paint.clearShadowLayer();

        Path lens = new Path(); lens.addCircle(cx, cy, radius, Path.Direction.CW);
        int save = canvas.save(); canvas.clipPath(lens);
        paint.setColor(Color.rgb(242, 243, 241)); canvas.drawRect(cx - radius, cy - radius, cx + radius, cy + radius, paint);

        // Subtle optical illumination without hiding the graduations.
        paint.setColor(Color.argb(18, 255, 255, 255)); canvas.drawCircle(cx - radius * 0.38f, cy - radius * 0.34f, radius * 0.76f, paint);
        paint.setColor(Color.argb(11, 0, 0, 0)); canvas.drawCircle(cx + radius * 0.34f, cy + radius * 0.18f, radius * 0.91f, paint);

        drawStaff(canvas, cx, cy, radius);
        drawCrosshairs(canvas, cx, cy, radius);
        drawVignette(canvas, cx, cy, radius);
        canvas.restoreToCount(save);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(3)); paint.setColor(Color.rgb(28, 31, 36)); canvas.drawCircle(cx, cy, radius, paint);
        paint.setStrokeWidth(dp(1)); paint.setColor(Color.rgb(135, 139, 142)); canvas.drawCircle(cx, cy, radius - dp(3), paint);
    }

    private void drawStaff(Canvas canvas, float cx, float cy, float radius) {
        float staffWidth = Math.min(dp(156), radius * 0.72f);
        float left = cx - staffWidth / 2f;
        float right = cx + staffWidth / 2f;
        float top = cy - radius - dp(10);
        float bottom = cy + radius + dp(10);
        float rail = Math.max(dp(4), staffWidth * 0.045f);
        float innerLeft = left + rail;
        float innerRight = right - rail;
        float patternRight = innerLeft + (innerRight - innerLeft) * 0.66f;

        // Aluminium rails and white painted face.
        paint.setStyle(Paint.Style.FILL);
        paint.setShadowLayer(dp(5), dp(2), dp(2), Color.argb(80, 0, 0, 0));
        paint.setColor(Color.rgb(170, 176, 181)); canvas.drawRect(left, top, right, bottom, paint); paint.clearShadowLayer();
        paint.setColor(Color.WHITE); canvas.drawRect(innerLeft, top, innerRight, bottom, paint);
        paint.setColor(Color.rgb(225, 228, 230)); canvas.drawRect(left + dp(1), top, innerLeft, bottom, paint); canvas.drawRect(innerRight, top, right - dp(1), bottom, paint);

        int firstDm = (int) Math.floor(visibleMin * 10.0);
        int lastDm = (int) Math.ceil(visibleMax * 10.0);
        for (int dm = firstDm; dm < lastDm; dm++) {
            float yTop = readingToY((dm + 1) / 10.0, top, bottom);
            float yBottom = readingToY(dm / 10.0, top, bottom);
            int color = ((dm / 10) & 1) == 1 ? Color.rgb(224, 28, 36) : Color.rgb(20, 22, 24);
            boolean eOnUpperHalf = floorMod(dm, 2) != 0;
            boolean opensRight = floorMod(dm, 2) == 0;
            drawDecimeter(canvas, innerLeft, patternRight, yTop, yBottom, color, eOnUpperHalf, opensRight);
            drawNumber(canvas, dm, patternRight, innerRight, yTop, yBottom, color);
        }

        // Exact centimetre guide lines, subtle like printed staff edges.
        int firstCm = (int) Math.floor(visibleMin * 100.0);
        int lastCm = (int) Math.ceil(visibleMax * 100.0);
        paint.setStyle(Paint.Style.STROKE);
        for (int cm = firstCm; cm <= lastCm; cm++) {
            float y = readingToY(cm / 100.0, top, bottom);
            boolean decimeter = cm % 10 == 0;
            paint.setColor(decimeter ? Color.argb(120, 45, 45, 45) : Color.argb(32, 80, 80, 80));
            paint.setStrokeWidth(decimeter ? dp(0.9f) : dp(0.35f));
            canvas.drawLine(decimeter ? innerLeft : patternRight, y, innerRight, y, paint);
        }

        paint.setColor(Color.rgb(55, 57, 60)); paint.setStrokeWidth(dp(0.9f));
        canvas.drawLine(patternRight, top, patternRight, bottom, paint);
        canvas.drawRect(innerLeft, top, innerRight, bottom, paint);
    }

    private void drawDecimeter(Canvas canvas, float left, float right, float top, float bottom, int color,
                                boolean eUpper, boolean opensRight) {
        float mid = (top + bottom) / 2f;
        if (eUpper) {
            drawEHalf(canvas, left, right, top, mid, color, opensRight);
            drawFiveCentimeterBlocks(canvas, left, right, mid, bottom, color, !opensRight);
        } else {
            drawFiveCentimeterBlocks(canvas, left, right, top, mid, color, opensRight);
            drawEHalf(canvas, left, right, mid, bottom, color, !opensRight);
        }
    }

    private void drawEHalf(Canvas canvas, float left, float right, float top, float bottom, int color, boolean opensRight) {
        float w = right - left, h = bottom - top;
        float marginX = w * 0.06f;
        float l = left + marginX, r = right - marginX;
        float spine = w * 0.18f;
        float bar = h * 0.17f;
        paint.setStyle(Paint.Style.FILL); paint.setColor(color);
        if (opensRight) {
            canvas.drawRect(l, top, l + spine, bottom, paint);
            canvas.drawRect(l, top + h * 0.03f, r, top + h * 0.03f + bar, paint);
            canvas.drawRect(l, (top + bottom) / 2f - bar / 2f, r - w * 0.13f, (top + bottom) / 2f + bar / 2f, paint);
            canvas.drawRect(l, bottom - h * 0.03f - bar, r, bottom - h * 0.03f, paint);
        } else {
            canvas.drawRect(r - spine, top, r, bottom, paint);
            canvas.drawRect(l, top + h * 0.03f, r, top + h * 0.03f + bar, paint);
            canvas.drawRect(l + w * 0.13f, (top + bottom) / 2f - bar / 2f, r, (top + bottom) / 2f + bar / 2f, paint);
            canvas.drawRect(l, bottom - h * 0.03f - bar, r, bottom - h * 0.03f, paint);
        }
    }

    private void drawFiveCentimeterBlocks(Canvas canvas, float left, float right, float top, float bottom, int color, boolean fromLeft) {
        float cm = (bottom - top) / 5f;
        float w = right - left;
        // Three one-centimetre bars; the two white spaces between them are also readable centimetres.
        float[] widths = {0.88f, 0.0f, 0.58f, 0.0f, 0.88f};
        paint.setStyle(Paint.Style.FILL); paint.setColor(color);
        for (int i = 0; i < 5; i++) {
            if (widths[i] <= 0f) continue;
            float y1 = top + i * cm + cm * 0.05f;
            float y2 = top + (i + 1) * cm - cm * 0.05f;
            float bw = w * widths[i];
            boolean leftSide = (i == 2) ? !fromLeft : fromLeft;
            if (leftSide) canvas.drawRect(left, y1, left + bw, y2, paint);
            else canvas.drawRect(right - bw, y1, right, y2, paint);
        }
    }

    private void drawNumber(Canvas canvas, int dm, float left, float right, float top, float bottom, int color) {
        paint.setStyle(Paint.Style.FILL); paint.setColor(color);
        paint.setTextAlign(Paint.Align.CENTER); paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(Math.min(dp(19), Math.abs(bottom - top) * 0.28f));
        float x = left + (right - left) * 0.52f;
        float center = (top + bottom) / 2f;
        canvas.drawText(String.format(Locale.US, "%02d", Math.max(0, dm)), x, centeredBaseline(center), paint);
    }

    private void drawCrosshairs(Canvas canvas, float cx, float cy, float radius) {
        float top = cy - radius - dp(10), bottom = cy + radius + dp(10);
        drawHair(canvas, "LS", upperReading, cx, radius, top, bottom, false);
        drawHair(canvas, "LM", middleReading, cx, radius, top, bottom, true);
        drawHair(canvas, "LI", lowerReading, cx, radius, top, bottom, false);

        paint.setStyle(Paint.Style.STROKE); paint.setColor(Color.rgb(12, 12, 12)); paint.setStrokeWidth(dp(0.9f));
        canvas.drawLine(cx, cy - radius * 0.94f, cx, cy - dp(5), paint);
        canvas.drawLine(cx, cy + dp(5), cx, cy + radius * 0.94f, paint);
    }

    private void drawHair(Canvas canvas, String label, double reading, float cx, float radius, float top, float bottom, boolean middle) {
        float y = readingToY(reading, top, bottom);
        float fullLeft = cx - radius + dp(5), fullRight = cx + radius - dp(5);
        float shortLeft = cx - radius * 0.58f, shortRight = cx + radius * 0.58f;
        paint.setStyle(Paint.Style.STROKE); paint.setColor(Color.rgb(8, 8, 8)); paint.setStrokeWidth(middle ? dp(1.55f) : dp(1.0f));
        canvas.drawLine(middle ? fullLeft : shortLeft, y, middle ? fullRight : shortRight, y, paint);

        paint.setStyle(Paint.Style.FILL); paint.setColor(Color.rgb(22, 22, 22)); paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(dp(10.5f)); paint.setTextAlign(Paint.Align.LEFT);
        float labelX = middle ? fullLeft + dp(12) : cx - radius * 0.76f;
        canvas.drawText(label, labelX, y - dp(4), paint);
    }

    private void drawVignette(Canvas canvas, float cx, float cy, float radius) {
        paint.setStyle(Paint.Style.STROKE);
        for (int i = 0; i < 8; i++) {
            paint.setColor(Color.argb(8 + i * 5, 0, 0, 0)); paint.setStrokeWidth(dp(2.0f));
            canvas.drawCircle(cx, cy, radius - dp(1.5f) - i * dp(1.8f), paint);
        }
    }

    private float readingToY(double reading, float top, float bottom) {
        double fraction = (visibleMax - reading) / Math.max(0.01, visibleMax - visibleMin);
        return (float) (top + fraction * (bottom - top));
    }

    private float centeredBaseline(float centerY) {
        Paint.FontMetrics fm = paint.getFontMetrics(); return centerY - (fm.ascent + fm.descent) / 2f;
    }
    private int floorMod(int v, int d) { int r = v % d; return r < 0 ? r + d : r; }
    private int dp(float v) { return Math.round(v * density); }
}
