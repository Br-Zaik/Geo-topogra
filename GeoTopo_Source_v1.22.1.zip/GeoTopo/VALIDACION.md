# Validación GeoTopo 1.22.0

## Comportamiento esperado del GPS

1. Al pulsar **Promediar 10, 20, 30 o 60 s**, el contador comienza inmediatamente.
2. Ya no existe una búsqueda previa de 90 s ni aparece la ventana blanca de espera.
3. El contador termina siempre al llegar a 0.
4. El número de satélites visibles o usados se muestra solo como información y no bloquea el proceso.
5. En **Solo satélites GNSS** únicamente se usan lecturas del receptor satelital del teléfono.
6. En **Automático**, la red puede dar una posición inicial; si llegan lecturas GNSS, el resultado final utiliza las GNSS y descarta la red.
7. Si durante el tiempo elegido solo llega ubicación asistida, se entrega un resultado referencial claramente identificado.
8. Las lecturas se solicitan sin distancia mínima para recibir más actualizaciones mientras el teléfono está quieto.
9. Al finalizar se utiliza el grupo más estable de lecturas y se descartan las más alejadas.
10. Una lectura individual con una precisión demasiado optimista ya no domina por completo el promedio.
11. Si llegó al menos una lectura utilizable, se entrega el mejor resultado disponible aunque la calidad sea regular.
12. El resultado queda congelado para guardarlo sin que una lectura posterior lo cambie.

## Práctica de lectura de mira

1. La nueva tarjeta aparece debajo de **Distancia y pendiente** y encima de **Distancia por dos hilos**.
2. Al abrirla se genera automáticamente una mira aleatoria distinta.
3. El botón **Nueva mira** vuelve a generar el ejercicio y limpia LS, LM y LI.
4. La escala se dibuja por código con números decimétricos, franjas rojas de 1 cm y los tres hilos LS, LM y LI.
5. La lectura se introduce en metros con tres decimales.
6. La comprobación exige LS > LM > LI y compara cada hilo con tolerancia de ±2 mm.
7. Una respuesta correcta muestra la distancia estadimétrica.
8. Una respuesta incorrecta muestra el error en milímetros y las lecturas correctas.
9. No se añadieron imágenes ni archivos bitmap, por lo que el aumento de peso es mínimo.

## Textos de ayuda

- Automático: “Puede usar internet, Wi-Fi o red móvil para ubicarte más rápido.”
- Solo satélites GNSS: “No requiere internet; la primera ubicación puede tardar más.”
- Estas explicaciones aparecen únicamente dentro de la configuración GPS.

## Prueba necesaria en teléfono

- Probar al aire libre con el teléfono quieto.
- Seleccionar 10 s y confirmar que termina exactamente al llegar a 0.
- Seleccionar 60 s y confirmar que no agrega ninguna espera antes ni después.
- En Automático, comprobar que el resultado indique GPS/GNSS cuando hayan llegado lecturas satelitales.
- En Solo GNSS, comprobar que nunca use ubicación de red.
- Confirmar que no aparece la ventana blanca de 90 s.
- Verificar que el resultado final permanece congelado al guardar el punto.

## Validación estructural

- compileSdk 35.
- targetSdk 35.
- MapLibre Android 11.8.0.
- Versión 1.22.0, versionCode 31.
