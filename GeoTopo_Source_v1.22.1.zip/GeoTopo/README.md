# GeoTopo

Versión actual: **1.22.0**

## GPS/GNSS sin bloqueo por satélites

- Mantiene solo dos modos: **Automático: GPS + red** y **Solo satélites GNSS**.
- En la configuración GPS se indica en letras pequeñas:
  - Automático puede usar internet, Wi-Fi o red móvil para ubicar más rápido.
  - Solo satélites GNSS no requiere internet, aunque puede tardar más al iniciar.
- La cantidad de satélites queda como información y no bloquea el proceso.
- El promedio comienza inmediatamente y dura exactamente 10, 20, 30 o 60 segundos.
- No existe una espera previa de 90 segundos ni una ventana adicional al terminar.
- En Automático se prefieren las lecturas GNSS y la red queda como respaldo referencial.
- En Solo GNSS se usan únicamente datos satelitales.
- El resultado usa el grupo más estable de lecturas, descarta posiciones alejadas y evita que una sola lectura optimista domine el cálculo.
- Si llega al menos una lectura utilizable, entrega el mejor resultado disponible y lo congela para guardar.

## Práctica de lectura de mira

- Nueva opción ubicada entre **Distancia y pendiente** y **Distancia por dos hilos**.
- La mira tipo E se dibuja completamente por código, sin fotografías ni imágenes pesadas.
- Cada vez que se abre la opción se genera un ejercicio distinto con tres hilos: **LS, LM y LI**.
- Permite escribir lecturas en metros con tres decimales, por ejemplo `1.455`.
- Comprueba el orden LS > LM > LI, acepta una tolerancia visual de ±2 mm y señala si la lectura es correcta.
- Cuando la lectura no coincide, informa el error de cada hilo y muestra la respuesta correcta.
- Calcula también la distancia estadimétrica mediante `(LS − LI) × 100`.

## Puntos y mapa

- Los puntos GPS y el mapa usan el mismo almacenamiento.
- Se pueden mostrar juntos todos los puntos de un proyecto.
- El mapa ajusta el zoom y mantiene resaltado el punto seleccionado.

## Otras funciones

- Capas de calles, satélite, satélite con nombres y topográfico.
- Búsqueda de lugares y coordenadas.
- Medición de distancia y área con puntos movibles y apariencia configurable.

## Cambio 1.22.0
Se añadió una práctica aleatoria y liviana de lectura de mira tipo E con tres hilos, validación en milímetros y cálculo de distancia estadimétrica.
