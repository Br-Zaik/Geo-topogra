package com.bph.geotopo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

import java.util.Locale;
import java.util.Random;

/**
 * Vista dibujada por código para practicar lecturas de una mira tipo E.
 * Se genera de forma liviana, sin bitmaps, con una apariencia más cercana a una mira real.
 */
public class MiraPracticeView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random();
    private final int textColor;
    private final int subTextColor;
    private final int panelColor;
    private final float density;

    private double upperReading;
    private double middleReading;
    private double lowerReading;
    private double visibleMin;
    private double visibleMax;

    public MiraPracticeView(Context context, int accentColor, int textColor, int subTextColor, int panelColor) {
        super(context);
        this.textColor = textColor;
        this.subTextColor = subTextColor;
        this.panelColor = panelColor;
        this.density = getResources().getDisplayMetrics().density;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        newExercise();
    }

    public void newExercise() {
        int halfSpanMm = 35 + random.nextInt(76); // 35 mm a 110 mm por lado.
        int middleMm = 500 + random.nextInt(4001); // 0.500 m a 4.500 m.
        if (middleMm - halfSpanMm < 120) middleMm = 120 + halfSpanMm;
        if (middleMm + halfSpanMm > 4880) middleMm = 4880 - halfSpanMm;

        // Evita que todos los ejercicios caigan exactamente en una marca de centímetro.
        if (middleMm % 10 == 0) middleMm += 3 + random.nextInt(5);

        middleReading = middleMm / 1000.0;
        upperReading = (middleMm + halfSpanMm) / 1000.0;
        lowerReading = (middleMm - halfSpanMm) / 1000.0;

        double span = Math.max(0.36, (upperReading - lowerReading) + 0.18);
        double center = middleReading;
        visibleMin = Math.floor((center - span / 2.0) * 100.0) / 100.0;
        visibleMax = Math.ceil((center + span / 2.0) * 100.0) / 100.0;
        if (visibleMin < 0.0) {
            visibleMax -= visibleMin;
            visibleMin = 0.0;
        }
        if (visibleMax > 5.0) {
            visibleMin -= (visibleMax - 5.0);
            visibleMax = 5.0;
        }
        invalidate();
    }

    public double getUpperReading() {
        return upperReading;
    }

    public double getMiddleReading() {
        return middleReading;
    }

    public double getLowerReading() {
        return lowerReading;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int desiredHeight = dp(420);
        int height = resolveSize(desiredHeight, heightMeasureSpec);
        setMeasuredDimension(width, height);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        float footerHeight = dp(54);
        float cx = w / 2f;
        float cy = (h - footerHeight) / 2f;
        float radius = Math.min(w * 0.46f, (h - footerHeight) * 0.47f);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(panelColor);
        canvas.drawRoundRect(new RectF(0, 0, w, h), dp(14), dp(14), paint);

        // Bisel del ocular.
        paint.setColor(Color.rgb(17, 21, 27));
        paint.setShadowLayer(dp(10), 0f, dp(2), Color.argb(120, 0, 0, 0));
        canvas.drawCircle(cx, cy, radius + dp(7), paint);
        paint.clearShadowLayer();
        paint.setColor(Color.rgb(236, 238, 242));
        canvas.drawCircle(cx, cy, radius, paint);

        Path fieldPath = new Path();
        fieldPath.addCircle(cx, cy, radius - dp(2), Path.Direction.CW);
        int save = canvas.save();
        canvas.clipPath(fieldPath);

        drawScopeBackground(canvas, cx, cy, radius);

        float staffWidth = Math.min(dp(138), radius * 0.82f);
        float staffLeft = cx - staffWidth / 2f;
        float staffRight = cx + staffWidth / 2f;
        float staffTop = cy - radius - dp(14);
        float staffBottom = cy + radius + dp(14);
        float staffHeight = staffBottom - staffTop;

        // Cuerpo principal de la mira.
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
        canvas.drawRect(staffLeft, staffTop, staffRight, staffBottom, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.rgb(96, 96, 96));
        paint.setStrokeWidth(dp(1));
        canvas.drawRect(staffLeft, staffTop, staffRight, staffBottom, paint);

        float numberColLeft = staffLeft;
        float numberColRight = staffLeft + staffWidth * 0.53f;
        float patternColLeft = numberColRight;
        float patternColRight = staffRight;
        float centerLineX = patternColLeft;

        // Línea vertical central de lectura.
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.rgb(28, 28, 28));
        paint.setStrokeWidth(dp(1.25f));
        canvas.drawLine(centerLineX, staffTop, centerLineX, staffBottom, paint);

        drawStaffScale(canvas, staffTop, staffBottom, numberColLeft, numberColRight, patternColLeft, patternColRight);
        drawThreads(canvas, cx, radius, staffTop, staffBottom);

        canvas.restoreToCount(save);

        // Aro exterior discreto, sin azul para que se vea más real.
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(5));
        paint.setColor(Color.rgb(18, 24, 30));
        canvas.drawCircle(cx, cy, radius, paint);
        paint.setStrokeWidth(dp(1.2f));
        paint.setColor(Color.rgb(72, 72, 72));
        canvas.drawCircle(cx, cy, radius - dp(4), paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(dp(11.2f));
        paint.setColor(subTextColor);
        canvas.drawText("Mira tipo E · números negros y patrón rojo", cx, h - dp(26), paint);
        canvas.drawText("El último milímetro se estima visualmente", cx, h - dp(9), paint);
    }

    private void drawScopeBackground(Canvas canvas, float cx, float cy, float radius) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(249, 249, 247));
        canvas.drawRect(cx - radius, cy - radius, cx + radius, cy + radius, paint);

        // Ligero sombreado interno para evitar un blanco plano/feo.
        paint.setColor(Color.argb(22, 0, 0, 0));
        canvas.drawCircle(cx + radius * 0.16f, cy - radius * 0.18f, radius * 0.98f, paint);
    }

    private void drawStaffScale(Canvas canvas, float staffTop, float staffBottom,
                                float numberColLeft, float numberColRight,
                                float patternColLeft, float patternColRight) {
        int startCm = (int) Math.floor(visibleMin * 100.0) - 1;
        int endCm = (int) Math.ceil(visibleMax * 100.0) + 1;

        // Cuadrícula fina de 1 cm y principal de 5/10 cm.
        for (int cm = startCm; cm <= endCm; cm++) {
            double value = cm / 100.0;
            float y = readingToY(value, staffTop, staffBottom);
            if (y < staffTop - dp(2) || y > staffBottom + dp(2)) continue;

            boolean decimeter = floorMod(cm, 10) == 0;
            boolean fiveCm = floorMod(cm, 5) == 0;
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(decimeter ? Color.rgb(88, 88, 88)
                    : (fiveCm ? Color.rgb(165, 165, 165) : Color.rgb(220, 220, 220)));
            paint.setStrokeWidth(decimeter ? dp(1.1f) : (fiveCm ? dp(0.75f) : dp(0.5f)));
            canvas.drawLine(numberColLeft, y, patternColRight, y, paint);
        }

        // Números grandes en negro por decímetro.
        int startDm = (int) Math.floor(visibleMin * 10.0) - 1;
        int endDm = (int) Math.ceil(visibleMax * 10.0) + 1;
        for (int dm = startDm; dm <= endDm; dm++) {
            double dmValue = dm / 10.0;
            double nextDmValue = dmValue + 0.10;
            float y1 = readingToY(nextDmValue, staffTop, staffBottom);
            float y2 = readingToY(dmValue, staffTop, staffBottom);
            float top = Math.min(y1, y2);
            float bottom = Math.max(y1, y2);
            float centerY = (top + bottom) / 2f;
            if (bottom < staffTop || top > staffBottom) continue;

            paint.setStyle(Paint.Style.FILL);
            paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            paint.setTextAlign(Paint.Align.RIGHT);
            paint.setTextSize(Math.min(dp(25), Math.max(dp(16), (bottom - top) * 0.48f)));
            paint.setColor(Color.rgb(22, 22, 22));
            canvas.drawText(String.format(Locale.US, "%02d", Math.max(0, dm)),
                    numberColRight - dp(7), centerY + dp(9), paint);
        }

        // Patrón rojo tipo E más realista, alternando lado por decímetro.
        for (int dm = startDm; dm <= endDm; dm++) {
            double dmValue = dm / 10.0;
            double nextDmValue = dmValue + 0.10;
            float y1 = readingToY(nextDmValue, staffTop, staffBottom);
            float y2 = readingToY(dmValue, staffTop, staffBottom);
            float top = Math.min(y1, y2);
            float bottom = Math.max(y1, y2);
            if (bottom < staffTop || top > staffBottom) continue;
            drawDecimeterPattern(canvas, top, bottom, dm, patternColLeft, patternColRight);
        }
    }

    private void drawDecimeterPattern(Canvas canvas, float top, float bottom, int dm,
                                      float patternLeft, float patternRight) {
        float colWidth = patternRight - patternLeft;
        float cmH = (bottom - top) / 10f;
        boolean toRight = floorMod(dm, 2) == 0;

        float spineW = colWidth * 0.16f;
        float armLong = colWidth * 0.82f;
        float armShort = colWidth * 0.40f;

        float spineLeft = toRight ? patternLeft : patternRight - spineW;
        float spineRight = spineLeft + spineW;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(220, 24, 24));

        // Espina vertical principal del patrón E.
        float eTop = top + cmH * 1f;
        float eBottom = top + cmH * 9f;
        canvas.drawRect(spineLeft, eTop, spineRight, eBottom, paint);

        // Brazos superior, medio e inferior.
        drawArm(canvas, toRight, patternLeft, patternRight, top + cmH * 1f, top + cmH * 3f, armLong, spineW);
        drawArm(canvas, toRight, patternLeft, patternRight, top + cmH * 4f, top + cmH * 6f, armShort, spineW);
        drawArm(canvas, toRight, patternLeft, patternRight, top + cmH * 7f, top + cmH * 9f, armLong, spineW);

        // Marcas cortas superior e inferior para que la mira no se vea "vacía".
        drawSmallBar(canvas, toRight, patternLeft, patternRight, top + cmH * 0.2f, top + cmH * 1.0f, colWidth * 0.55f);
        drawSmallBar(canvas, toRight, patternLeft, patternRight, top + cmH * 9.0f, top + cmH * 9.8f, colWidth * 0.55f);

        // Línea tenue lateral para dar acabado más real.
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(0.6f));
        paint.setColor(Color.rgb(188, 188, 188));
        canvas.drawLine(patternRight - dp(1), top, patternRight - dp(1), bottom, paint);
    }

    private void drawArm(Canvas canvas, boolean toRight, float patternLeft, float patternRight,
                         float top, float bottom, float width, float spineW) {
        if (toRight) {
            canvas.drawRect(patternLeft, top, Math.min(patternLeft + width, patternRight), bottom, paint);
        } else {
            canvas.drawRect(Math.max(patternRight - width, patternLeft), top, patternRight, bottom, paint);
        }
    }

    private void drawSmallBar(Canvas canvas, boolean toRight, float patternLeft, float patternRight,
                              float top, float bottom, float width) {
        float left;
        float right;
        if (toRight) {
            left = patternLeft;
            right = Math.min(patternLeft + width, patternRight);
        } else {
            left = Math.max(patternRight - width, patternLeft);
            right = patternRight;
        }
        canvas.drawRect(left, top, right, bottom, paint);
    }

    private void drawThreads(Canvas canvas, float cx, float radius, float staffTop, float staffBottom) {
        drawThread(canvas, "LS", upperReading, cx, radius, staffTop, staffBottom, false);
        drawThread(canvas, "LM", middleReading, cx, radius, staffTop, staffBottom, true);
        drawThread(canvas, "LI", lowerReading, cx, radius, staffTop, staffBottom, false);

        // Hilo vertical central.
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1.2f));
        paint.setColor(Color.rgb(16, 16, 16));
        canvas.drawLine(cx, cyFromScope(staffTop, staffBottom, radius, true), cx,
                cyFromScope(staffTop, staffBottom, radius, false), paint);
    }

    private float cyFromScope(float staffTop, float staffBottom, float radius, boolean top) {
        float mid = (staffTop + staffBottom) / 2f;
        return top ? mid - radius * 0.90f : mid + radius * 0.90f;
    }

    private void drawThread(Canvas canvas, String label, double reading, float cx, float radius,
                            float staffTop, float staffBottom, boolean middle) {
        float y = readingToY(reading, staffTop, staffBottom);
        float left = cx - radius + dp(8);
        float right = cx + radius - dp(8);

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.rgb(20, 20, 20));
        paint.setStrokeWidth(middle ? dp(2.5f) : dp(1.7f));
        canvas.drawLine(left, y, right, y, paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(34, 34, 34));
        paint.setTextSize(dp(13));
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextAlign(Paint.Align.LEFT);
        canvas.drawText(label, left + dp(10), y - dp(5), paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.rgb(16, 16, 16));
        paint.setStrokeWidth(dp(1.2f));
        canvas.drawLine(cx, y - dp(7), cx, y + dp(7), paint);
    }

    private float readingToY(double reading, float top, float bottom) {
        double range = Math.max(0.01, visibleMax - visibleMin);
        double t = (visibleMax - reading) / range;
        return (float) (top + t * (bottom - top));
    }

    private int floorMod(int value, int divisor) {
        int result = value % divisor;
        return result < 0 ? result + divisor : result;
    }

    private int dp(float value) {
        return Math.round(value * density);
    }
}
