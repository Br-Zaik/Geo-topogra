package com.bph.geotopo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.maplibre.android.MapLibre;
import org.maplibre.android.annotations.IconFactory;
import org.maplibre.android.annotations.Marker;
import org.maplibre.android.annotations.MarkerOptions;
import org.maplibre.android.annotations.Polygon;
import org.maplibre.android.annotations.Polyline;
import org.maplibre.android.annotations.PolylineOptions;
import org.maplibre.android.camera.CameraPosition;
import org.maplibre.android.camera.CameraUpdateFactory;
import org.maplibre.android.geometry.LatLng;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapView;
import org.maplibre.android.maps.Style;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Visor principal nativo. Usa MapLibre para que el zoom y el desplazamiento
 * se procesen con la GPU en lugar de redibujar un mapa dentro de WebView.
 */
public class MapActivity extends Activity implements LocationListener {
    private static final int REQ_LOCATION = 9002;
    private static final String PREFS = "geo_topo_prefs";
    private static final String GPS_PREFS = "geo_topo_gps_points";
    private static final String LEGACY_MAP_PREFS = "geotopo_gps";
    private static final String KEY_POINTS = "points_json";
    private static final String KEY_MEASURE_COLOR = "measure_color";
    private static final String KEY_MEASURE_POINT_SIZE = "measure_point_size";
    private static final String KEY_MEASURE_LABEL_SIZE = "measure_label_size";
    private static final String KEY_MEASURE_SUMMARY_SIZE = "measure_summary_size";
    private static final String KEY_MEASURE_LINE_WIDTH = "measure_line_width";
    private static final int[] MEASURE_COLORS = {
            Color.rgb(25, 132, 255),
            Color.rgb(0, 150, 136),
            Color.rgb(229, 57, 53),
            Color.rgb(255, 145, 0)
    };
    private static final String[] MEASURE_COLOR_NAMES = {
            "Azul profesional", "Verde topográfico", "Rojo obra", "Naranja obra"
    };
    private static final String[] MEASURE_POINT_SIZE_NAMES = {"Pequeños", "Medianos", "Grandes", "Muy grandes"};
    private static final String[] MEASURE_LABEL_SIZE_NAMES = {"Pequeños", "Normales", "Grandes", "Muy grandes"};
    private static final String[] MEASURE_SUMMARY_SIZE_NAMES = {"Compacto", "Normal", "Grande", "Muy grande"};
    private static final String[] MEASURE_LINE_WIDTH_NAMES = {"Fina", "Normal", "Gruesa", "Muy gruesa"};

    private MapView mapView;
    private MapLibreMap map;
    private LocationManager locationManager;
    private Location currentLocation;
    private Marker locationMarker;
    private Polygon accuracyPolygon;
    private Marker selectedMarker;
    private final List<Marker> savedPointMarkers = new ArrayList<>();
    private final List<SavedPointInfo> visibleSavedPointInfos = new ArrayList<>();
    private final List<Marker> measurementMarkers = new ArrayList<>();
    private final List<Marker> measurementVertexMarkers = new ArrayList<>();
    private int selectedMeasurementIndex = -1;
    private int draggingMeasurementIndex = -1;
    private float measurementTouchDownX;
    private float measurementTouchDownY;
    private boolean measurementDragStarted;
    private Polyline measurementOutlineLine;
    private Polyline measurementLine;
    private Polygon measurementPolygon;
    private Polyline orientationLine;
    private final List<Marker> orientationMarkers = new ArrayList<>();
    private LatLng orientationPointA;
    private LatLng orientationPointB;
    private double orientationBearing;
    private double orientationDistance;
    private final List<LatLng> measurementPoints = new ArrayList<>();
    private boolean measurementActive;
    private boolean areaMode;
    private String currentMode = "standard";
    private String currentPlaceName = "";
    private boolean focusSavedPointsPending;
    private String savedPointsProjectFilter = "";
    private String selectedSavedPointName = "";
    private String selectedSavedPointProject = "";
    private int measureColorIndex = 0;
    private int measurePointSizeIndex = 1;
    private int measureLabelSizeIndex = 2;
    private int measureSummarySizeIndex = 1;
    private int measureLineWidthIndex = 1;

    private TextView subtitleView;
    private ImageButton compassView;
    private TextView statusView;
    private LinearLayout measurePanel;
    private TextView measureResultView;
    private LinearLayout selectedPanel;
    private TextView selectedPlaceView;
    private TextView selectedCoordsView;
    private TextView selectedUtmView;
    private LatLng selectedPoint;

    private int accentColor = Color.rgb(41, 121, 255);
    private int appBarColor = Color.rgb(3, 45, 73);
    private int cardColor = Color.rgb(4, 36, 58);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService lookupExecutor = Executors.newSingleThreadExecutor();
    private long locationRequestStartedAt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadPalette();
        loadMeasurementAppearance();
        MapLibre.getInstance(this);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        migrateLegacyMapData();
        loadRememberedLocation();
        readLaunchIntent();
        buildUi(savedInstanceState);
    }

    private void loadPalette() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        int[] accents = {
                Color.rgb(41, 121, 255), Color.rgb(0, 188, 212), Color.rgb(0, 150, 136),
                Color.rgb(0, 184, 148), Color.rgb(118, 210, 34), Color.rgb(255, 214, 10),
                Color.rgb(255, 171, 0), Color.rgb(255, 112, 20), Color.rgb(244, 67, 54),
                Color.rgb(255, 64, 129), Color.rgb(142, 68, 173), Color.rgb(92, 92, 210)
        };
        int index = sp.getInt("accent", 0);
        int normalizedIndex = ((index % accents.length) + accents.length) % accents.length;
        accentColor = accents[normalizedIndex];
    }

    private void loadMeasurementAppearance() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        measureColorIndex = clampIndex(sp.getInt(KEY_MEASURE_COLOR, 0), MEASURE_COLORS.length);
        measurePointSizeIndex = clampIndex(sp.getInt(KEY_MEASURE_POINT_SIZE, 1), MEASURE_POINT_SIZE_NAMES.length);
        measureLabelSizeIndex = clampIndex(sp.getInt(KEY_MEASURE_LABEL_SIZE, 2), MEASURE_LABEL_SIZE_NAMES.length);
        measureSummarySizeIndex = clampIndex(sp.getInt(KEY_MEASURE_SUMMARY_SIZE, 1), MEASURE_SUMMARY_SIZE_NAMES.length);
        measureLineWidthIndex = clampIndex(sp.getInt(KEY_MEASURE_LINE_WIDTH, 1), MEASURE_LINE_WIDTH_NAMES.length);
    }

    private void saveMeasurementAppearance() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt(KEY_MEASURE_COLOR, measureColorIndex)
                .putInt(KEY_MEASURE_POINT_SIZE, measurePointSizeIndex)
                .putInt(KEY_MEASURE_LABEL_SIZE, measureLabelSizeIndex)
                .putInt(KEY_MEASURE_SUMMARY_SIZE, measureSummarySizeIndex)
                .putInt(KEY_MEASURE_LINE_WIDTH, measureLineWidthIndex)
                .apply();
    }

    private int clampIndex(int value, int size) {
        if (size <= 0) return 0;
        if (value < 0) return 0;
        if (value >= size) return size - 1;
        return value;
    }

    private int getMeasureColor() {
        return MEASURE_COLORS[clampIndex(measureColorIndex, MEASURE_COLORS.length)];
    }

    private float getMeasurePointScale() {
        switch (measurePointSizeIndex) {
            case 0: return 0.92f;
            case 2: return 1.38f;
            case 3: return 1.68f;
            default: return 1.14f;
        }
    }

    private float getMeasureLabelScale() {
        switch (measureLabelSizeIndex) {
            case 0: return 1.00f;
            case 2: return 1.55f;
            case 3: return 1.90f;
            default: return 1.28f;
        }
    }

    private float getMeasureSummaryScale() {
        switch (measureSummarySizeIndex) {
            case 0: return 0.92f;
            case 2: return 1.34f;
            case 3: return 1.58f;
            default: return 1.10f;
        }
    }

    private float getMeasureLineWidth() {
        switch (measureLineWidthIndex) {
            case 0: return 3.0f;
            case 2: return 5.6f;
            case 3: return 7.0f;
            default: return 4.3f;
        }
    }

    private int darkenColor(int color, float factor) {
        float f = Math.max(0f, Math.min(1f, factor));
        return Color.rgb(
                Math.round(Color.red(color) * f),
                Math.round(Color.green(color) * f),
                Math.round(Color.blue(color) * f)
        );
    }

    private void buildUi(Bundle savedInstanceState) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(232, 239, 244));
        root.addView(buildTopBar());

        FrameLayout mapFrame = new FrameLayout(this);
        mapView = new MapView(this);
        mapView.onCreate(savedInstanceState);
        mapFrame.addView(mapView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(mapFrame, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        addMapOverlays(mapFrame);
        mapView.getMapAsync(mapLibreMap -> {
            map = mapLibreMap;
            map.getUiSettings().setCompassEnabled(false);
            map.getUiSettings().setLogoEnabled(false);
            map.getUiSettings().setAttributionEnabled(false);
            map.addOnCameraMoveListener(this::updateCompass);
            map.setMinZoomPreference(2.0);
            map.setMaxZoomPreference(20.0);
            map.addOnMapLongClickListener(point -> {
                showSelectedPoint(point);
                return true;
            });
            map.addOnMapClickListener(point -> {
                if (!measurementActive) return false;
                measurementPoints.add(point);
                selectedMeasurementIndex = measurementPoints.size() - 1;
                redrawMeasurement();
                return true;
            });
            map.setOnMarkerClickListener(marker -> {
                if (handleMeasurementMarkerClick(marker)) return true;
                return handleSavedPointMarkerClick(marker);
            });
            installMeasurementDragHandler();
            updateCompass();
            setMapMode("standard");
            loadSavedPoints();
            if (orientationPointA != null && orientationPointB != null) centerOnOrientation();
            else if (!focusSavedPointsPending) centerOnCurrentLocation(false);
        });
    }

    private View buildTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(4), dp(4), dp(8), dp(4));
        bar.setBackgroundColor(appBarColor);

        TextView back = text("‹", 30, true, Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(38), dp(44)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("Mapa topográfico", 18, true, Color.WHITE);
        title.setSingleLine(true);
        titles.addView(title);
        subtitleView = text("Mapa nativo · calles y lugares", 10, false, Color.rgb(193, 218, 240));
        subtitleView.setSingleLine(true);
        titles.addView(subtitleView);
        bar.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        ImageButton search = new ImageButton(this);
        search.setImageResource(R.drawable.ic_map_search);
        search.setColorFilter(Color.WHITE);
        search.setScaleType(android.widget.ImageView.ScaleType.CENTER);
        search.setPadding(dp(9), dp(9), dp(9), dp(9));
        search.setContentDescription("Buscar lugar o coordenadas");
        search.setBackground(pill(Color.argb(145, 12, 45, 73), dp(19), Color.argb(105, 255, 255, 255)));
        search.setOnClickListener(v -> showPlaceSearchDialog());
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(dp(38), dp(38));
        searchLp.setMargins(0, 0, dp(6), 0);
        bar.addView(search, searchLp);

        TextView info = roundText("⋮", "Opciones e información");
        info.setTextSize(20);
        info.setOnClickListener(v -> showInfo());
        bar.addView(info, new LinearLayout.LayoutParams(dp(38), dp(38)));
        return bar;
    }

    private void addMapOverlays(FrameLayout frame) {
        compassView = buildCompass();
        FrameLayout.LayoutParams compassLp = new FrameLayout.LayoutParams(dp(46), dp(46));
        compassLp.gravity = Gravity.TOP | Gravity.END;
        compassLp.setMargins(0, dp(10), dp(10), 0);
        frame.addView(compassView, compassLp);

        statusView = text("Preparando mapa…", 10.5f, true, Color.WHITE);
        statusView.setGravity(Gravity.CENTER);
        statusView.setMaxLines(2);
        statusView.setPadding(dp(9), dp(6), dp(9), dp(6));
        statusView.setBackground(pill(Color.argb(232, 4, 36, 58), dp(15), Color.argb(65, 255, 255, 255)));
        FrameLayout.LayoutParams statusLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        statusLp.gravity = Gravity.BOTTOM;
        statusLp.setMargins(dp(34), 0, dp(34), dp(72));
        frame.addView(statusView, statusLp);

        LinearLayout dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setGravity(Gravity.CENTER);
        dock.setPadding(dp(5), dp(5), dp(5), dp(4));
        dock.setBackground(pill(Color.argb(244, 4, 36, 58), dp(19), Color.argb(70, 255, 255, 255)));
        dock.setElevation(dp(10));
        dock.addView(mapTool(R.drawable.ic_map_location, "Ubicación", v -> centerOnCurrentLocation(true)), toolParams());
        dock.addView(mapTool(R.drawable.ic_map_layers, "Capas", v -> showLayers()), toolParams());
        dock.addView(mapTool(R.drawable.ic_map_points, "Puntos", v -> showAllSavedPointsOnMap()), toolParams());
        dock.addView(mapTool(R.drawable.ic_map_measure, "Medir", v -> showMeasureChooser()), toolParams());
        FrameLayout.LayoutParams dockLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60));
        dockLp.gravity = Gravity.BOTTOM;
        dockLp.setMargins(dp(12), 0, dp(12), dp(8));
        frame.addView(dock, dockLp);

        measurePanel = buildMeasurePanel();
        measurePanel.setVisibility(View.GONE);
        FrameLayout.LayoutParams measureLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        measureLp.gravity = Gravity.BOTTOM;
        measureLp.setMargins(dp(12), 0, dp(12), dp(74));
        frame.addView(measurePanel, measureLp);

        selectedPanel = buildSelectedPanel();
        selectedPanel.setVisibility(View.GONE);
        FrameLayout.LayoutParams selectedLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        selectedLp.gravity = Gravity.BOTTOM;
        selectedLp.setMargins(dp(12), 0, dp(12), dp(74));
        frame.addView(selectedPanel, selectedLp);
    }

    private ImageButton buildCompass() {
        ImageButton view = new ImageButton(this);
        view.setImageResource(R.drawable.ic_map_compass);
        view.setColorFilter(null);
        view.setScaleType(android.widget.ImageView.ScaleType.CENTER);
        view.setPadding(dp(8), dp(8), dp(8), dp(8));
        view.setContentDescription("Brújula: tocar para orientar el norte arriba");
        view.setBackground(pill(Color.argb(238, 10, 24, 38), dp(23), Color.argb(115, 255, 255, 255)));
        view.setElevation(dp(7));
        view.setOnClickListener(v -> {
            if (map != null) {
                CameraPosition p = new CameraPosition.Builder(map.getCameraPosition()).bearing(0).tilt(0).build();
                map.animateCamera(CameraUpdateFactory.newCameraPosition(p), 350);
            }
        });
        return view;
    }

    private void updateCompass() {
        if (compassView == null || map == null) return;
        double bearing = map.getCameraPosition().bearing;
        compassView.setRotation((float) -bearing);
        compassView.setAlpha(1f);
    }

    private LinearLayout buildMeasurePanel() {
        LinearLayout panel = floatingPanel();
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Medición referencial sobre mapa", 17, true, Color.WHITE);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = text("×", 28, true, Color.WHITE);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> {
            measurementActive = false;
            draggingMeasurementIndex = -1;
            measurementDragStarted = false;
            if (map != null) map.getUiSettings().setAllGesturesEnabled(true);
            panel.setVisibility(View.GONE);
            setStatus("La medición queda dibujada. Pulsa Medir para continuar o limpiar.");
        });
        header.addView(close, new LinearLayout.LayoutParams(dp(44), dp(40)));
        panel.addView(header);

        measureResultView = text("Toca el mapa para agregar el primer punto.", 15, true, Color.WHITE);
        measureResultView.setPadding(0, dp(5), 0, dp(3));
        panel.addView(measureResultView);
        TextView note = text("Cada tramo es una línea recta entre los puntos tocados. Resultado aproximado; no sustituye un levantamiento topográfico.", 11, false, Color.rgb(194, 220, 239));
        panel.addView(note);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(8), 0, 0);
        Button undo = panelButton("← Atrás");
        undo.setOnClickListener(v -> undoMeasure());
        row.addView(undo, weightButton());
        Button finish = panelButton("✓ Finalizar");
        finish.setOnClickListener(v -> {
            measurementActive = false;
            redrawMeasurement();
        });
        row.addView(finish, weightButton());
        Button clear = panelButton("Limpiar");
        clear.setOnClickListener(v -> clearMeasurement());
        row.addView(clear, weightButton());
        panel.addView(row);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setPadding(0, dp(8), 0, 0);
        Button appearance = panelButton("⚙ Apariencia de medición");
        appearance.setOnClickListener(v -> showMeasurementAppearanceDialog());
        row2.addView(appearance, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));
        panel.addView(row2);

        TextView hint = text("Cambia números T1/T2, puntos P1/P2, resumen, color y grosor.", 11, false, Color.rgb(194, 220, 239));
        hint.setPadding(dp(4), dp(6), dp(4), 0);
        panel.addView(hint);
        return panel;
    }

    private LinearLayout buildSelectedPanel() {
        LinearLayout panel = floatingPanel();
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Lugar seleccionado", 17, true, Color.WHITE);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = text("×", 28, true, Color.WHITE);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> closeSelectedPoint());
        header.addView(close, new LinearLayout.LayoutParams(dp(44), dp(40)));
        panel.addView(header);

        selectedPlaceView = text("Buscando nombre del lugar…", 13, false, Color.rgb(194, 220, 239));
        selectedPlaceView.setPadding(0, dp(3), 0, dp(5));
        panel.addView(selectedPlaceView);
        selectedCoordsView = text("Latitud / longitud: —", 13, true, Color.WHITE);
        panel.addView(selectedCoordsView);
        selectedUtmView = text("UTM: —", 12, false, Color.rgb(194, 220, 239));
        selectedUtmView.setPadding(0, dp(3), 0, dp(8));
        panel.addView(selectedUtmView);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        Button save = panelButton("Guardar");
        save.setOnClickListener(v -> showSaveSelectedPoint());
        row1.addView(save, weightButton());
        Button copy = panelButton("Copiar");
        copy.setOnClickListener(v -> copySelectedPoint());
        row1.addView(copy, weightButton());
        Button share = panelButton("Compartir");
        share.setOnClickListener(v -> shareSelectedPoint());
        row1.addView(share, weightButton());
        panel.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button measure = panelButton("Medir desde aquí");
        measure.setOnClickListener(v -> startMeasureFromSelected());
        row2.addView(measure, weightButton());
        Button maps = panelButton("Abrir en Maps");
        maps.setOnClickListener(v -> openSelectedInMaps());
        row2.addView(maps, weightButton());
        panel.addView(row2);
        return panel;
    }

    private void setMapMode(String mode) {
        currentMode = mode;
        if (map == null) return;
        String label;
        String tiles;
        int maxZoom;
        if ("satellite".equals(mode)) {
            label = "Satélite";
            tiles = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}";
            maxZoom = 17;
        } else if ("hybrid".equals(mode)) {
            label = "Satélite + nombres";
            map.setStyle(new Style.Builder().fromJson(hybridStyleJson()), style -> onStyleReady(label));
            return;
        } else if ("topo".equals(mode)) {
            label = "Topográfico";
            tiles = "https://a.tile.opentopomap.org/{z}/{x}/{y}.png";
            maxZoom = 17;
        } else if ("relief".equals(mode)) {
            // La capa relieve se retira porque en varias zonas devuelve
            // mosaicos vacíos o incompletos y empeora la experiencia.
            label = "Topográfico";
            tiles = "https://a.tile.opentopomap.org/{z}/{x}/{y}.png";
            maxZoom = 17;
        } else {
            label = "Calles y lugares";
            tiles = "https://tile.openstreetmap.org/{z}/{x}/{y}.png";
            maxZoom = 19;
        }
        map.setStyle(new Style.Builder().fromJson(rasterStyleJson(tiles, maxZoom)), style -> onStyleReady(label));
    }

    private void onStyleReady(String label) {
        subtitleView.setText("Mapa nativo · " + label.toLowerCase(Locale.ROOT));
        redrawAllAnnotations();
        if (focusSavedPointsPending) {
            focusSavedPointsPending = false;
            focusVisibleSavedPoints();
        } else {
            setStatus(label + " · zoom fluido con dos dedos");
        }
    }

    private String rasterStyleJson(String tileUrl, int maxZoom) {
        return "{\"version\":8,\"sources\":{\"base\":{\"type\":\"raster\",\"tiles\":[\""
                + tileUrl + "\"],\"tileSize\":256,\"maxzoom\":" + maxZoom
                + "}},\"layers\":[{\"id\":\"base\",\"type\":\"raster\",\"source\":\"base\",\"paint\":{\"raster-fade-duration\":120}}]}";
    }

    private String hybridStyleJson() {
        return "{\"version\":8,\"sources\":{"
                + "\"imagery\":{\"type\":\"raster\",\"tiles\":[\"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}\"],\"tileSize\":256,\"maxzoom\":17},"
                + "\"labels\":{\"type\":\"raster\",\"tiles\":[\"https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}\"],\"tileSize\":256,\"maxzoom\":17}"
                + "},\"layers\":["
                + "{\"id\":\"imagery\",\"type\":\"raster\",\"source\":\"imagery\",\"paint\":{\"raster-fade-duration\":120}},"
                + "{\"id\":\"labels\",\"type\":\"raster\",\"source\":\"labels\",\"paint\":{\"raster-opacity\":0.92}}]}";
    }

    private String reliefStyleJson() {
        // Composición de terreno real: base física + sombreado de elevación + nombres.
        // Cada fuente declara su zoom máximo para que MapLibre amplíe el último mosaico
        // disponible en vez de solicitar niveles inexistentes.
        return "{\"version\":8,\"sources\":{"
                + "\"terrain\":{\"type\":\"raster\",\"tiles\":[\"https://server.arcgisonline.com/ArcGIS/rest/services/World_Terrain_Base/MapServer/tile/{z}/{y}/{x}\"],\"tileSize\":256,\"maxzoom\":13},"
                + "\"hillshade\":{\"type\":\"raster\",\"tiles\":[\"https://server.arcgisonline.com/ArcGIS/rest/services/Elevation/World_Hillshade/MapServer/tile/{z}/{y}/{x}\"],\"tileSize\":256,\"maxzoom\":15},"
                + "\"labels\":{\"type\":\"raster\",\"tiles\":[\"https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}\"],\"tileSize\":256,\"maxzoom\":17}"
                + "},\"layers\":["
                + "{\"id\":\"terrain\",\"type\":\"raster\",\"source\":\"terrain\",\"paint\":{\"raster-opacity\":1.0,\"raster-fade-duration\":120}},"
                + "{\"id\":\"hillshade\",\"type\":\"raster\",\"source\":\"hillshade\",\"paint\":{\"raster-opacity\":0.72,\"raster-contrast\":0.22,\"raster-fade-duration\":120}},"
                + "{\"id\":\"labels\",\"type\":\"raster\",\"source\":\"labels\",\"paint\":{\"raster-opacity\":0.96,\"raster-fade-duration\":120}}]}";
    }

    private void showLayers() {
        String[] items = {"Calles y lugares", "Satélite", "Satélite + nombres", "Topográfico"};
        new AlertDialog.Builder(this)
                .setTitle("Capas del mapa")
                .setItems(items, (d, which) -> {
                    if (which == 0) setMapMode("standard");
                    else if (which == 1) setMapMode("satellite");
                    else if (which == 2) setMapMode("hybrid");
                    else if (which == 3) setMapMode("topo");
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showMeasureChooser() {
        String[] items = {"Medir distancia por tramos", "Medir área y perímetro", "Continuar medición", "Apariencia de medición", "Limpiar medición"};
        new AlertDialog.Builder(this)
                .setTitle("Medición referencial")
                .setItems(items, (d, which) -> {
                    if (which == 0) startMeasurement(false, true);
                    else if (which == 1) startMeasurement(true, true);
                    else if (which == 2) startMeasurement(areaMode, false);
                    else if (which == 3) showMeasurementAppearanceDialog();
                    else clearMeasurement();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showMeasurementAppearanceDialog() {
        String[] items = {
                "Color de líneas y puntos: " + MEASURE_COLOR_NAMES[measureColorIndex],
                "Tamaño de puntos P1, P2…: " + MEASURE_POINT_SIZE_NAMES[measurePointSizeIndex],
                "Números de tramos T1, T2…: " + MEASURE_LABEL_SIZE_NAMES[measureLabelSizeIndex],
                "Resumen central: " + MEASURE_SUMMARY_SIZE_NAMES[measureSummarySizeIndex],
                "Grosor de líneas: " + MEASURE_LINE_WIDTH_NAMES[measureLineWidthIndex],
                "Restaurar estilo profesional"
        };
        new AlertDialog.Builder(this)
                .setTitle("Apariencia de la medición")
                .setItems(items, (d, which) -> {
                    if (which == 0) showMeasurementColorDialog();
                    else if (which == 1) showMeasurementPointSizeDialog();
                    else if (which == 2) showMeasurementLabelSizeDialog();
                    else if (which == 3) showMeasurementSummarySizeDialog();
                    else if (which == 4) showMeasurementLineWidthDialog();
                    else restoreMeasurementAppearance();
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void showMeasurementColorDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Color de líneas y puntos")
                .setSingleChoiceItems(MEASURE_COLOR_NAMES, measureColorIndex, (dialog, which) -> {
                    measureColorIndex = which;
                    saveMeasurementAppearance();
                    redrawMeasurement();
                    setStatus("Color de medición: " + MEASURE_COLOR_NAMES[measureColorIndex]);
                    dialog.dismiss();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showMeasurementPointSizeDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Tamaño de puntos")
                .setSingleChoiceItems(MEASURE_POINT_SIZE_NAMES, measurePointSizeIndex, (dialog, which) -> {
                    measurePointSizeIndex = which;
                    saveMeasurementAppearance();
                    redrawMeasurement();
                    setStatus("Tamaño de puntos: " + MEASURE_POINT_SIZE_NAMES[measurePointSizeIndex]);
                    dialog.dismiss();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showMeasurementLabelSizeDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Tamaño de números de tramos")
                .setSingleChoiceItems(MEASURE_LABEL_SIZE_NAMES, measureLabelSizeIndex, (dialog, which) -> {
                    measureLabelSizeIndex = which;
                    saveMeasurementAppearance();
                    redrawMeasurement();
                    setStatus("Números de tramos: " + MEASURE_LABEL_SIZE_NAMES[measureLabelSizeIndex]);
                    dialog.dismiss();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showMeasurementSummarySizeDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Tamaño del resumen central")
                .setSingleChoiceItems(MEASURE_SUMMARY_SIZE_NAMES, measureSummarySizeIndex, (dialog, which) -> {
                    measureSummarySizeIndex = which;
                    saveMeasurementAppearance();
                    redrawMeasurement();
                    setStatus("Resumen central: " + MEASURE_SUMMARY_SIZE_NAMES[measureSummarySizeIndex]);
                    dialog.dismiss();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showMeasurementLineWidthDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Grosor de líneas")
                .setSingleChoiceItems(MEASURE_LINE_WIDTH_NAMES, measureLineWidthIndex, (dialog, which) -> {
                    measureLineWidthIndex = which;
                    saveMeasurementAppearance();
                    redrawMeasurement();
                    setStatus("Grosor de líneas: " + MEASURE_LINE_WIDTH_NAMES[measureLineWidthIndex]);
                    dialog.dismiss();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void restoreMeasurementAppearance() {
        measureColorIndex = 0;
        measurePointSizeIndex = 1;
        measureLabelSizeIndex = 2;
        measureSummarySizeIndex = 1;
        measureLineWidthIndex = 1;
        saveMeasurementAppearance();
        redrawMeasurement();
        setStatus("Apariencia de medición restaurada.");
    }

    private void startMeasurement(boolean area, boolean clear) {
        areaMode = area;
        measurementActive = true;
        if (clear) {
            measurementPoints.clear();
            selectedMeasurementIndex = -1;
            draggingMeasurementIndex = -1;
            measurementDragStarted = false;
            if (map != null) {
                if (measurementOutlineLine != null) map.removePolyline(measurementOutlineLine);
                if (measurementLine != null) map.removePolyline(measurementLine);
                if (measurementPolygon != null) map.removePolygon(measurementPolygon);
                clearMeasurementMarkers();
            }
            measurementOutlineLine = null;
            measurementLine = null;
            measurementPolygon = null;
        }
        selectedPanel.setVisibility(View.GONE);
        measurePanel.setVisibility(View.VISIBLE);
        redrawMeasurement();
    }

    private void undoMeasure() {
        if (!measurementPoints.isEmpty()) {
            measurementPoints.remove(measurementPoints.size() - 1);
            if (selectedMeasurementIndex >= measurementPoints.size()) selectedMeasurementIndex = measurementPoints.size() - 1;
        }
        redrawMeasurement();
    }

    private void clearMeasurement() {
        measurementPoints.clear();
        selectedMeasurementIndex = -1;
        measurementActive = false;
        draggingMeasurementIndex = -1;
        measurementDragStarted = false;
        if (map != null) {
            map.getUiSettings().setAllGesturesEnabled(true);
            if (measurementOutlineLine != null) map.removePolyline(measurementOutlineLine);
            if (measurementLine != null) map.removePolyline(measurementLine);
            if (measurementPolygon != null) map.removePolygon(measurementPolygon);
            clearMeasurementMarkers();
        }
        measurementOutlineLine = null;
        measurementLine = null;
        measurementPolygon = null;
        measurePanel.setVisibility(View.GONE);
        setStatus("Medición eliminada.");
    }

    private void redrawMeasurement() {
        if (map == null) return;
        if (measurementOutlineLine != null) map.removePolyline(measurementOutlineLine);
        if (measurementLine != null) map.removePolyline(measurementLine);
        if (measurementPolygon != null) map.removePolygon(measurementPolygon);
        clearMeasurementMarkers();
        measurementOutlineLine = null;
        measurementLine = null;
        measurementPolygon = null;

        int lineColor = getMeasureColor();
        float lineWidth = getMeasureLineWidth();

        if (measurementPoints.size() >= 2) {
            List<LatLng> borderPoints = new ArrayList<>(measurementPoints);
            if (areaMode && measurementPoints.size() >= 3) {
                borderPoints.add(measurementPoints.get(0));
            }
            measurementOutlineLine = map.addPolyline(new PolylineOptions()
                    .addAll(borderPoints)
                    .color(Color.argb(170, 255, 255, 255))
                    .width(lineWidth + 2.2f));
            measurementLine = map.addPolyline(new PolylineOptions()
                    .addAll(borderPoints)
                    .color(lineColor)
                    .width(lineWidth));

            for (int i = 1; i < measurementPoints.size(); i++) {
                LatLng a = measurementPoints.get(i - 1);
                LatLng b = measurementPoints.get(i);
                String label = "T" + i + " · " + formatDistance(haversine(a, b));
                measurementMarkers.add(map.addMarker(new MarkerOptions()
                        .position(midpoint(a, b))
                        .icon(IconFactory.getInstance(this).fromBitmap(createMeasurementLabelBitmap(label)))));
            }
        }

        double distance = totalDistance(measurementPoints);
        if (areaMode && measurementPoints.size() >= 3) {
            LatLng last = measurementPoints.get(measurementPoints.size() - 1);
            LatLng first = measurementPoints.get(0);
            double closingDistance = haversine(last, first);
            measurementMarkers.add(map.addMarker(new MarkerOptions()
                    .position(midpoint(last, first))
                    .icon(IconFactory.getInstance(this).fromBitmap(
                            createMeasurementLabelBitmap("Cierre · " + formatDistance(closingDistance))))));
            double perimeter = distance + closingDistance;
            double area = polygonArea(measurementPoints);
            measureResultView.setText(String.format(Locale.US, "≈ %.1f m² (%.4f ha) · perímetro ≈ %.1f m · %d lados",
                    area, area / 10000.0, perimeter, measurementPoints.size()));
            measurementMarkers.add(map.addMarker(new MarkerOptions()
                    .position(measurementCenter(measurementPoints, true))
                    .icon(IconFactory.getInstance(this).fromBitmap(
                            createMeasurementSummaryBitmap("Perímetro · " + formatDistance(perimeter), formatArea(area))))));
        } else {
            String km = distance >= 1000 ? String.format(Locale.US, " (%.3f km)", distance / 1000.0) : "";
            measureResultView.setText(String.format(Locale.US, "Distancia total ≈ %.1f m%s · %d tramos",
                    distance, km, Math.max(0, measurementPoints.size() - 1)));
            if (measurementPoints.size() >= 2) {
                measurementMarkers.add(map.addMarker(new MarkerOptions()
                        .position(measurementCenter(measurementPoints, false))
                        .icon(IconFactory.getInstance(this).fromBitmap(
                                createMeasurementSummaryBitmap("Total · " + formatDistance(distance),
                                        Math.max(0, measurementPoints.size() - 1) + " tramos")))));
            }
        }

        for (int i = 0; i < measurementPoints.size(); i++) {
            String pointName = pointLabel(i);
            measurementVertexMarkers.add(map.addMarker(new MarkerOptions()
                    .position(measurementPoints.get(i))
                    .icon(IconFactory.getInstance(this).fromBitmap(createMeasurementPointBitmap(pointName, i == selectedMeasurementIndex)))));
        }
    }

    private void clearMeasurementMarkers() {
        if (map != null) {
            for (Marker marker : measurementMarkers) {
                try { map.removeMarker(marker); } catch (Exception ignored) { }
            }
            for (Marker marker : measurementVertexMarkers) {
                try { map.removeMarker(marker); } catch (Exception ignored) { }
            }
        }
        measurementMarkers.clear();
        measurementVertexMarkers.clear();
    }

    private Bitmap createLocationDotBitmap() {
        int size = dp(22);
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        float center = size / 2f;

        paint.setColor(Color.argb(70, 66, 133, 244));
        canvas.drawCircle(center, center, dp(8.0f), paint);

        paint.setColor(Color.WHITE);
        canvas.drawCircle(center, center, dp(5.2f), paint);

        paint.setColor(Color.rgb(66, 133, 244));
        canvas.drawCircle(center, center, dp(3.8f), paint);
        return bitmap;
    }

    private Bitmap createSavedPointBitmap(String text, boolean selected) {
        int size = dp(selected ? 38 : 32);
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        float center = size / 2f;

        paint.setColor(Color.argb(selected ? 90 : 45, 0, 0, 0));
        canvas.drawCircle(center + dp(0.8f), center + dp(1.5f), dp(selected ? 15.5f : 13.0f), paint);
        paint.setColor(Color.WHITE);
        canvas.drawCircle(center, center, dp(selected ? 15.0f : 12.7f), paint);
        paint.setColor(selected ? Color.rgb(255, 149, 0) : Color.rgb(25, 132, 255));
        canvas.drawCircle(center, center, dp(selected ? 12.2f : 10.2f), paint);

        paint.setColor(Color.WHITE);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(dp(text.length() > 3 ? 6.2f : 7.2f));
        Paint.FontMetrics fm = paint.getFontMetrics();
        float y = center - (fm.ascent + fm.descent) / 2f;
        canvas.drawText(text, center, y, paint);
        return bitmap;
    }

    private Bitmap createMeasurementPointBitmap(String text, boolean selected) {
        float scale = getMeasurePointScale();
        int size = dp(Math.round((selected ? 24f : 20f) * scale));
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        float center = size / 2f;
        float outerRadius = dp((selected ? 10.4f : 8.8f) * scale);
        float innerRadius = dp((selected ? 7.8f : 6.6f) * scale);
        int measureColor = getMeasureColor();

        paint.setColor(selected ? darkenColor(measureColor, 0.55f) : Color.WHITE);
        canvas.drawCircle(center, center, outerRadius, paint);
        paint.setColor(measureColor);
        canvas.drawCircle(center, center, innerRadius, paint);

        paint.setColor(Color.WHITE);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(dp((text.length() > 2 ? 5.2f : 6.0f) * scale));
        paint.setTextAlign(Paint.Align.CENTER);
        Paint.FontMetrics fm = paint.getFontMetrics();
        float y = center - (fm.ascent + fm.descent) / 2f;
        canvas.drawText(text, center, y, paint);
        return bitmap;
    }

    private Bitmap createMeasurementLabelBitmap(String text) {
        // Etiqueta compacta con halo blanco para que se lea sobre satélite, calles o topografía.
        float scale = getMeasureLabelScale();
        Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setTextSize(dp(7.3f * scale));
        float horizontal = dp(5f * scale);
        int width = Math.max(dp(48), Math.round(textPaint.measureText(text) + horizontal * 2));
        int height = Math.max(dp(19), Math.round(dp(19f * scale)));
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        textPaint.setTextAlign(Paint.Align.CENTER);
        Paint.FontMetrics fm = textPaint.getFontMetrics();
        float y = height / 2f - (fm.ascent + fm.descent) / 2f;

        textPaint.setStyle(Paint.Style.STROKE);
        textPaint.setStrokeJoin(Paint.Join.ROUND);
        textPaint.setStrokeWidth(dp(3.2f * scale));
        textPaint.setColor(Color.argb(245, 255, 255, 255));
        canvas.drawText(text, width / 2f, y, textPaint);

        textPaint.setStyle(Paint.Style.FILL);
        textPaint.setColor(darkenColor(getMeasureColor(), 0.42f));
        canvas.drawText(text, width / 2f, y, textPaint);
        return bitmap;
    }

    private Bitmap createMeasurementSummaryBitmap(String line1, String line2) {
        float scale = getMeasureSummaryScale();
        Paint titlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        titlePaint.setTypeface(Typeface.DEFAULT_BOLD);
        titlePaint.setTextSize(dp(9.2f * scale));

        Paint bodyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        bodyPaint.setTypeface(Typeface.DEFAULT_BOLD);
        bodyPaint.setTextSize(dp(7.5f * scale));

        int paddingH = dp(10);
        int paddingV = dp(7);
        int gap = dp(3);
        int width = Math.max(dp(104), Math.round(Math.max(titlePaint.measureText(line1), bodyPaint.measureText(line2)) + paddingH * 2));
        int height = paddingV * 2 + dp(18) + dp(13) + gap;
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);

        Paint shadow = new Paint(Paint.ANTI_ALIAS_FLAG);
        shadow.setColor(Color.argb(62, 0, 0, 0));
        canvas.drawRoundRect(dp(1.6f), dp(2.2f), width - dp(0.2f), height - dp(0.2f), dp(12), dp(12), shadow);

        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setColor(Color.argb(248, 255, 255, 255));
        canvas.drawRoundRect(0, 0, width - dp(1.6f), height - dp(1.6f), dp(12), dp(12), bg);

        Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(1.35f));
        stroke.setColor(Color.argb(225, Color.red(getMeasureColor()), Color.green(getMeasureColor()), Color.blue(getMeasureColor())));
        canvas.drawRoundRect(dp(0.7f), dp(0.7f), width - dp(2.3f), height - dp(2.3f), dp(12), dp(12), stroke);

        titlePaint.setColor(darkenColor(getMeasureColor(), 0.36f));
        bodyPaint.setColor(Color.rgb(33, 53, 74));
        titlePaint.setTextAlign(Paint.Align.CENTER);
        bodyPaint.setTextAlign(Paint.Align.CENTER);
        Paint.FontMetrics titleFm = titlePaint.getFontMetrics();
        Paint.FontMetrics bodyFm = bodyPaint.getFontMetrics();
        float y1 = paddingV + dp(9) - (titleFm.ascent + titleFm.descent) / 2f;
        float y2 = y1 + dp(15) + gap - (bodyFm.ascent + bodyFm.descent) / 2f;
        canvas.drawText(line1, (width - dp(1.6f)) / 2f, y1, titlePaint);
        canvas.drawText(line2, (width - dp(1.6f)) / 2f, y2, bodyPaint);
        return bitmap;
    }

    private void installMeasurementDragHandler() {
        if (mapView == null) return;
        mapView.setOnTouchListener((view, event) -> {
            if (!measurementActive || map == null || measurementPoints.isEmpty()) return false;

            int action = event.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) {
                int index = findMeasurementPointNear(event.getX(), event.getY(), dp(24));
                if (index < 0) return false;

                draggingMeasurementIndex = index;
                selectedMeasurementIndex = index;
                measurementTouchDownX = event.getX();
                measurementTouchDownY = event.getY();
                measurementDragStarted = false;
                map.getUiSettings().setAllGesturesEnabled(false);
                redrawMeasurement();
                return true;
            }

            if (draggingMeasurementIndex < 0) return false;

            if (action == MotionEvent.ACTION_MOVE) {
                float dx = event.getX() - measurementTouchDownX;
                float dy = event.getY() - measurementTouchDownY;
                if (!measurementDragStarted && dx * dx + dy * dy >= dp(5) * dp(5)) {
                    measurementDragStarted = true;
                }
                if (measurementDragStarted) {
                    LatLng moved = map.getProjection().fromScreenLocation(new PointF(event.getX(), event.getY()));
                    measurementPoints.set(draggingMeasurementIndex, moved);
                    redrawMeasurement();
                    setStatus("Moviendo " + pointLabel(draggingMeasurementIndex) + "…");
                }
                return true;
            }

            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                int finishedIndex = draggingMeasurementIndex;
                boolean moved = measurementDragStarted;
                draggingMeasurementIndex = -1;
                measurementDragStarted = false;
                map.getUiSettings().setAllGesturesEnabled(true);
                redrawMeasurement();
                setStatus(moved
                        ? pointLabel(finishedIndex) + " movido. La medición se actualizó."
                        : pointLabel(finishedIndex) + " seleccionado. Arrástralo para moverlo.");
                return true;
            }

            return true;
        });
    }

    private int findMeasurementPointNear(float x, float y, float maxDistancePx) {
        if (map == null) return -1;
        int bestIndex = -1;
        float bestDistanceSquared = maxDistancePx * maxDistancePx;
        for (int i = 0; i < measurementPoints.size(); i++) {
            PointF screen = map.getProjection().toScreenLocation(measurementPoints.get(i));
            float dx = screen.x - x;
            float dy = screen.y - y;
            float distanceSquared = dx * dx + dy * dy;
            if (distanceSquared <= bestDistanceSquared) {
                bestDistanceSquared = distanceSquared;
                bestIndex = i;
            }
        }
        return bestIndex;
    }

    private boolean handleMeasurementMarkerClick(Marker marker) {
        int index = indexOfMeasurementVertex(marker);
        if (index < 0) return false;
        selectedMeasurementIndex = index;
        redrawMeasurement();
        setStatus(pointLabel(index) + " seleccionado. Arrástralo para moverlo.");
        return true;
    }

    private int indexOfMeasurementVertex(Marker marker) {
        if (marker == null) return -1;
        for (int i = 0; i < measurementVertexMarkers.size(); i++) {
            if (marker.equals(measurementVertexMarkers.get(i))) return i;
        }
        return -1;
    }

    private String pointLabel(int index) {
        return "P" + (index + 1);
    }

    private LatLng midpoint(LatLng a, LatLng b) {
        return new LatLng((a.getLatitude() + b.getLatitude()) / 2.0,
                (a.getLongitude() + b.getLongitude()) / 2.0);
    }

    private LatLng measurementCenter(List<LatLng> points, boolean polygon) {
        if (points == null || points.isEmpty()) return new LatLng(0, 0);
        if (!polygon || points.size() < 3) {
            double sumLat = 0;
            double sumLon = 0;
            for (LatLng point : points) {
                sumLat += point.getLatitude();
                sumLon += point.getLongitude();
            }
            return new LatLng(sumLat / points.size(), sumLon / points.size());
        }

        double twiceArea = 0;
        double centerX = 0;
        double centerY = 0;
        for (int i = 0; i < points.size(); i++) {
            LatLng a = points.get(i);
            LatLng b = points.get((i + 1) % points.size());
            double cross = a.getLongitude() * b.getLatitude() - b.getLongitude() * a.getLatitude();
            twiceArea += cross;
            centerX += (a.getLongitude() + b.getLongitude()) * cross;
            centerY += (a.getLatitude() + b.getLatitude()) * cross;
        }
        if (Math.abs(twiceArea) < 1e-12) {
            double sumLat = 0;
            double sumLon = 0;
            for (LatLng point : points) {
                sumLat += point.getLatitude();
                sumLon += point.getLongitude();
            }
            return new LatLng(sumLat / points.size(), sumLon / points.size());
        }
        return new LatLng(centerY / (3.0 * twiceArea), centerX / (3.0 * twiceArea));
    }

    private String formatDistance(double meters) {
        return meters >= 1000.0
                ? String.format(Locale.US, "%.2f km", meters / 1000.0)
                : String.format(Locale.US, "%.1f m", meters);
    }

    private String formatArea(double areaMeters) {
        if (areaMeters >= 10000.0) {
            return String.format(Locale.US, "Área · %.4f ha", areaMeters / 10000.0);
        }
        return String.format(Locale.US, "Área · %.1f m²", areaMeters);
    }

    private void showSelectedPoint(LatLng point) {
        showSelectedPoint(point, "");
    }

    private void showSelectedPoint(LatLng point, String knownPlace) {
        selectedPoint = point;
        selectedPanel.setVisibility(View.VISIBLE);
        measurePanel.setVisibility(View.GONE);
        if (selectedMarker != null && map != null) map.removeMarker(selectedMarker);
        if (map != null) selectedMarker = map.addMarker(new MarkerOptions().position(point).title("Lugar seleccionado"));
        selectedCoordsView.setText(String.format(Locale.US, "Lat/Lon: %.8f, %.8f", point.getLatitude(), point.getLongitude()));
        UtmCoordinate utm = toUtm(point.getLatitude(), point.getLongitude());
        selectedUtmView.setText(utm.valid
                ? String.format(Locale.US, "UTM %d %s · E %.3f m · N %.3f m", utm.zone, utm.hemisphere, utm.easting, utm.northing)
                : "UTM no disponible");
        if (knownPlace != null && !knownPlace.trim().isEmpty()) {
            selectedPlaceView.setText("Lugar: " + knownPlace.trim());
        } else {
            selectedPlaceView.setText("Buscando nombre del lugar y dirección…");
            lookupAddress(point, true);
        }
    }

    private void closeSelectedPoint() {
        selectedPanel.setVisibility(View.GONE);
        selectedPoint = null;
        if (selectedMarker != null && map != null) map.removeMarker(selectedMarker);
        selectedMarker = null;
    }

    private void lookupAddress(LatLng point, boolean selected) {
        lookupExecutor.execute(() -> {
            String result = geocodeWithAndroid(point.getLatitude(), point.getLongitude());
            if (result.isEmpty()) result = geocodeWithNominatim(point.getLatitude(), point.getLongitude());
            final String address = result;
            runOnUiThread(() -> {
                if (selected) {
                    if (selectedPoint == null) return;
                    selectedPlaceView.setText(address.isEmpty()
                            ? "Lugar no identificado. Las coordenadas sí son válidas."
                            : "Lugar: " + address);
                } else {
                    currentPlaceName = address;
                    updateLocationStatus();
                }
            });
        });
    }

    private String geocodeWithAndroid(double lat, double lon) {
        try {
            Geocoder geocoder = new Geocoder(this, new Locale("es", "PE"));
            List<Address> addresses = geocoder.getFromLocation(lat, lon, 1);
            if (addresses == null || addresses.isEmpty()) return "";
            Address a = addresses.get(0);
            String line = a.getMaxAddressLineIndex() >= 0 ? a.getAddressLine(0) : "";
            if (line != null && !line.trim().isEmpty()) return line.trim();
            StringBuilder out = new StringBuilder();
            appendPart(out, a.getThoroughfare());
            appendPart(out, a.getSubLocality());
            appendPart(out, a.getLocality());
            appendPart(out, a.getAdminArea());
            return out.toString();
        } catch (Exception ignored) {
            return "";
        }
    }

    private String geocodeWithNominatim(double lat, double lon) {
        HttpURLConnection connection = null;
        try {
            String address = "https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=18&addressdetails=1&lat="
                    + URLEncoder.encode(Double.toString(lat), "UTF-8") + "&lon="
                    + URLEncoder.encode(Double.toString(lon), "UTF-8");
            connection = (HttpURLConnection) new URL(address).openConnection();
            connection.setConnectTimeout(8000);
            connection.setReadTimeout(10000);
            connection.setRequestProperty("User-Agent", "GeoTopo/1.15 Android");
            connection.setRequestProperty("Accept-Language", "es");
            if (connection.getResponseCode() < 200 || connection.getResponseCode() >= 300) return "";
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder json = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) json.append(line);
            return new JSONObject(json.toString()).optString("display_name", "");
        } catch (Exception ignored) {
            return "";
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private void showSaveSelectedPoint() {
        if (selectedPoint == null) return;
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(6), dp(18), 0);
        EditText name = new EditText(this);
        name.setHint("Nombre del punto");
        name.setText(nextMapPointName());
        panel.addView(name);
        EditText project = new EditText(this);
        project.setHint("Proyecto");
        project.setText(getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString("current_project", "Puntos de mapa"));
        panel.addView(project);
        EditText description = new EditText(this);
        description.setHint("Descripción");
        description.setText(selectedPlaceView.getText().toString().replace("Lugar: ", ""));
        panel.addView(description);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Guardar punto")
                .setView(panel)
                .setPositiveButton("Guardar", null)
                .setNegativeButton("Cancelar", null)
                .create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(b -> {
            String pointName = name.getText().toString().trim();
            if (pointName.isEmpty()) {
                name.setError("Escribe un nombre");
                return;
            }
            persistSelectedPoint(project.getText().toString().trim(), pointName, description.getText().toString().trim());
            dialog.dismiss();
        }));
        dialog.show();
    }

    private void persistSelectedPoint(String project, String name, String description) {
        if (selectedPoint == null) return;
        if (project.isEmpty()) project = "Puntos de mapa";
        try {
            SharedPreferences sp = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
            JSONArray array;
            try { array = new JSONArray(sp.getString(KEY_POINTS, "[]")); }
            catch (JSONException ex) { array = new JSONArray(); }
            JSONObject p = new JSONObject();
            p.put("project", project);
            p.put("name", name);
            p.put("description", description);
            p.put("latitude", selectedPoint.getLatitude());
            p.put("longitude", selectedPoint.getLongitude());
            p.put("altitude", JSONObject.NULL);
            p.put("accuracy", JSONObject.NULL);
            p.put("speedKmh", JSONObject.NULL);
            p.put("bearing", JSONObject.NULL);
            p.put("timestamp", System.currentTimeMillis());
            p.put("provider", "map_selection");
            p.put("photoUri", "");
            array.put(p);
            sp.edit().putString(KEY_POINTS, array.toString()).putString("current_project", project).apply();
            loadSavedPoints();
            Toast.makeText(this, "Punto guardado", Toast.LENGTH_SHORT).show();
        } catch (JSONException ex) {
            Toast.makeText(this, "No se pudo guardar el punto.", Toast.LENGTH_LONG).show();
        }
    }

    private void copySelectedPoint() {
        if (selectedPoint == null) return;
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("Punto GeoTopo", selectedPointText()));
        Toast.makeText(this, "Punto copiado", Toast.LENGTH_SHORT).show();
    }

    private void shareSelectedPoint() {
        if (selectedPoint == null) return;
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, selectedPointText());
        startActivity(Intent.createChooser(intent, "Compartir punto"));
    }

    private String selectedPointText() {
        if (selectedPoint == null) return "";
        StringBuilder out = new StringBuilder();
        String place = selectedPlaceView.getText().toString();
        if (!place.startsWith("Buscando") && !place.startsWith("Lugar no")) out.append(place).append('\n');
        out.append(String.format(Locale.US, "Latitud: %.8f\nLongitud: %.8f", selectedPoint.getLatitude(), selectedPoint.getLongitude()));
        UtmCoordinate utm = toUtm(selectedPoint.getLatitude(), selectedPoint.getLongitude());
        if (utm.valid) out.append(String.format(Locale.US, "\nUTM %d %s\nEste: %.3f m\nNorte: %.3f m", utm.zone, utm.hemisphere, utm.easting, utm.northing));
        return out.toString();
    }

    private void startMeasureFromSelected() {
        if (selectedPoint == null) return;
        measurementPoints.clear();
        measurementPoints.add(selectedPoint);
        selectedMeasurementIndex = 0;
        startMeasurement(false, false);
        closeSelectedPoint();
    }

    private void openSelectedInMaps() {
        if (selectedPoint == null) return;
        Uri uri = Uri.parse(String.format(Locale.US, "geo:%.8f,%.8f?q=%.8f,%.8f", selectedPoint.getLatitude(), selectedPoint.getLongitude(), selectedPoint.getLatitude(), selectedPoint.getLongitude()));
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
        catch (Exception ex) { Toast.makeText(this, "No hay una app de mapas disponible.", Toast.LENGTH_LONG).show(); }
    }

    private void loadSavedPoints() {
        if (map == null) return;
        for (Marker marker : savedPointMarkers) {
            try { map.removeMarker(marker); } catch (Exception ignored) { }
        }
        savedPointMarkers.clear();
        visibleSavedPointInfos.clear();
        try {
            JSONArray array = new JSONArray(getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                double lat = item.optDouble("latitude", Double.NaN);
                double lon = item.optDouble("longitude", Double.NaN);
                if (Double.isNaN(lat) || Double.isNaN(lon)) continue;
                String name = item.optString("name", "P" + (i + 1)).trim();
                String project = item.optString("project", "Proyecto general").trim();
                String description = item.optString("description", "").trim();
                if (!savedPointsProjectFilter.isEmpty()
                        && !savedPointsProjectFilter.equalsIgnoreCase(project)) continue;

                boolean selected = !selectedSavedPointName.isEmpty()
                        && selectedSavedPointName.equalsIgnoreCase(name)
                        && (selectedSavedPointProject.isEmpty()
                        || selectedSavedPointProject.equalsIgnoreCase(project));
                SavedPointInfo info = new SavedPointInfo(name, project, description, new LatLng(lat, lon));
                visibleSavedPointInfos.add(info);
                savedPointMarkers.add(map.addMarker(new MarkerOptions()
                        .position(info.point)
                        .title(name + " · " + project)
                        .snippet(description)
                        .icon(IconFactory.getInstance(this).fromBitmap(createSavedPointBitmap(name, selected)))));
            }
            if (visibleSavedPointInfos.isEmpty()) {
                setStatus(savedPointsProjectFilter.isEmpty()
                        ? "No hay puntos guardados."
                        : "No hay puntos guardados en “" + savedPointsProjectFilter + "”.");
            } else {
                String scope = savedPointsProjectFilter.isEmpty()
                        ? "puntos guardados"
                        : "puntos de “" + savedPointsProjectFilter + "”";
                setStatus("Mostrando " + visibleSavedPointInfos.size() + " " + scope + ".");
            }
        } catch (Exception ex) {
            setStatus("No se pudieron cargar los puntos guardados.");
        }
    }

    private void showAllSavedPointsOnMap() {
        savedPointsProjectFilter = "";
        selectedSavedPointName = "";
        selectedSavedPointProject = "";
        loadSavedPoints();
        focusVisibleSavedPoints();
    }

    private boolean handleSavedPointMarkerClick(Marker marker) {
        if (marker == null) return false;
        int index = savedPointMarkers.indexOf(marker);
        if (index < 0 || index >= visibleSavedPointInfos.size()) return false;
        SavedPointInfo info = visibleSavedPointInfos.get(index);
        selectedSavedPointName = info.name;
        selectedSavedPointProject = info.project;
        loadSavedPoints();
        CameraPosition position = new CameraPosition.Builder(map.getCameraPosition())
                .target(info.point)
                .zoom(Math.max(17.0, map.getCameraPosition().zoom))
                .build();
        map.animateCamera(CameraUpdateFactory.newCameraPosition(position), 450);
        String detail = info.description.isEmpty() ? "" : " · " + info.description;
        setStatus(info.name + " · " + info.project + detail);
        return true;
    }

    private void focusVisibleSavedPoints() {
        if (map == null || visibleSavedPointInfos.isEmpty()) return;
        double minLat = Double.POSITIVE_INFINITY;
        double maxLat = Double.NEGATIVE_INFINITY;
        double minLon = Double.POSITIVE_INFINITY;
        double maxLon = Double.NEGATIVE_INFINITY;
        for (SavedPointInfo info : visibleSavedPointInfos) {
            minLat = Math.min(minLat, info.point.getLatitude());
            maxLat = Math.max(maxLat, info.point.getLatitude());
            minLon = Math.min(minLon, info.point.getLongitude());
            maxLon = Math.max(maxLon, info.point.getLongitude());
        }
        LatLng center = new LatLng((minLat + maxLat) / 2.0, (minLon + maxLon) / 2.0);
        double diagonal = haversine(new LatLng(minLat, minLon), new LatLng(maxLat, maxLon));
        double zoom;
        if (visibleSavedPointInfos.size() == 1 || diagonal < 25.0) zoom = 18.5;
        else if (diagonal < 80.0) zoom = 18.0;
        else if (diagonal < 250.0) zoom = 17.0;
        else if (diagonal < 700.0) zoom = 16.0;
        else if (diagonal < 2000.0) zoom = 14.5;
        else if (diagonal < 6000.0) zoom = 13.0;
        else if (diagonal < 20000.0) zoom = 11.0;
        else zoom = 9.0;
        CameraPosition position = new CameraPosition.Builder()
                .target(center)
                .zoom(zoom)
                .bearing(0)
                .tilt(0)
                .build();
        map.animateCamera(CameraUpdateFactory.newCameraPosition(position), 650);
        String scope = savedPointsProjectFilter.isEmpty()
                ? "todos los puntos guardados"
                : "el proyecto “" + savedPointsProjectFilter + "”";
        setStatus("Mostrando " + visibleSavedPointInfos.size() + " puntos de " + scope + ".");
    }

    private void centerOnCurrentLocation(boolean forceNew) {
        if (currentLocation != null) {
            moveCameraToLocation(currentLocation, 17.0);
            updateLocationStatus();
        }
        if (forceNew || currentLocation == null || System.currentTimeMillis() - currentLocation.getTime() > 30000L) {
            requestLocationUpdates();
        }
    }

    private void requestLocationUpdates() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
            return;
        }
        try {
            locationRequestStartedAt = System.currentTimeMillis();
            setStatus("Buscando tu ubicación actual…");
            Location gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location network = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            Location last = chooseBetter(gps, network);
            if (last != null && System.currentTimeMillis() - last.getTime() < 10 * 60 * 1000L) {
                onLocationChanged(last);
            }
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0.5f, this);
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1500L, 1f, this);
            }
            handler.removeCallbacks(locationTimeout);
            handler.postDelayed(locationTimeout, 15000L);
        } catch (Exception ex) {
            setStatus("No se pudo iniciar la ubicación. Revisa el permiso y el GPS.");
        }
    }

    private final Runnable locationTimeout = () -> {
        if (currentLocation == null) {
            setStatus("No llegó una ubicación nueva. Pulsa Ubicación para reintentar o abre GPS y puntos.");
        } else {
            updateLocationStatus();
        }
    };

    @Override
    public void onLocationChanged(Location location) {
        if (location == null || !location.hasAccuracy()) return;
        if (currentLocation == null || isBetterLocation(location, currentLocation)) {
            currentLocation = new Location(location);
            saveRememberedLocation(currentLocation);
            redrawLocation();
            if (map != null && (locationRequestStartedAt > 0 || map.getCameraPosition().zoom < 10)) {
                moveCameraToLocation(currentLocation, 17.0);
            }
            currentPlaceName = "";
            lookupAddress(new LatLng(location.getLatitude(), location.getLongitude()), false);
            updateLocationStatus();
        }
    }

    private void redrawLocation() {
        if (map == null || currentLocation == null) return;
        if (locationMarker != null) map.removeMarker(locationMarker);
        if (accuracyPolygon != null) {
            map.removePolygon(accuracyPolygon);
            accuracyPolygon = null;
        }
        LatLng p = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());
        locationMarker = map.addMarker(new MarkerOptions()
                .position(p)
                .title("Tu ubicación")
                .icon(IconFactory.getInstance(this).fromBitmap(createLocationDotBitmap())));
    }

    private void redrawAllAnnotations() {
        locationMarker = null;
        accuracyPolygon = null;
        measurementOutlineLine = null;
        measurementLine = null;
        measurementPolygon = null;
        measurementMarkers.clear();
        measurementVertexMarkers.clear();
        orientationLine = null;
        orientationMarkers.clear();
        selectedMarker = null;
        savedPointMarkers.clear();
        visibleSavedPointInfos.clear();
        redrawLocation();
        redrawMeasurement();
        redrawOrientation();
        loadSavedPoints();
        if (selectedPoint != null) showSelectedPoint(selectedPoint);
    }

    private void moveCameraToLocation(Location location, double zoom) {
        if (map == null || location == null) return;
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(location.getLatitude(), location.getLongitude()), zoom), 650);
    }

    private void updateLocationStatus() {
        if (currentLocation == null) return;
        String provider = LocationManager.GPS_PROVIDER.equals(currentLocation.getProvider()) ? "GPS/GNSS" : "ubicación asistida";
        String place = currentPlaceName == null || currentPlaceName.isEmpty() ? "Tu ubicación" : shortPlace(currentPlaceName);
        setStatus(place + " · ± " + String.format(Locale.US, "%.1f", currentLocation.getAccuracy()) + " m · " + provider);
    }

    private String shortPlace(String value) {
        String[] parts = value.split(",");
        if (parts.length <= 3) return value;
        return parts[0].trim() + ", " + parts[1].trim() + ", " + parts[2].trim();
    }

    private void readLaunchIntent() {
        Intent intent = getIntent();
        if (intent == null) return;

        focusSavedPointsPending = intent.getBooleanExtra("show_saved_points", false);
        boolean showAllSaved = intent.getBooleanExtra("show_all_saved_points", false);
        if (focusSavedPointsPending) {
            savedPointsProjectFilter = showAllSaved ? ""
                    : intent.getStringExtra("saved_points_project");
            if (savedPointsProjectFilter == null) savedPointsProjectFilter = "";
            selectedSavedPointName = intent.getStringExtra("selected_saved_point_name");
            if (selectedSavedPointName == null) selectedSavedPointName = "";
            selectedSavedPointProject = savedPointsProjectFilter;
        }

        if (!focusSavedPointsPending && intent.hasExtra("latitude") && intent.hasExtra("longitude")) {
            Location supplied = new Location("enviada");
            supplied.setLatitude(intent.getDoubleExtra("latitude", -9.19));
            supplied.setLongitude(intent.getDoubleExtra("longitude", -75.015));
            supplied.setAccuracy(intent.getFloatExtra("location_accuracy", 0f));
            supplied.setBearing(intent.getFloatExtra("location_bearing", 0f));
            supplied.setTime(System.currentTimeMillis());
            currentLocation = supplied;
        }
        if (intent.hasExtra("ab_a_lat") && intent.hasExtra("ab_b_lat")) {
            orientationPointA = new LatLng(intent.getDoubleExtra("ab_a_lat", 0), intent.getDoubleExtra("ab_a_lon", 0));
            orientationPointB = new LatLng(intent.getDoubleExtra("ab_b_lat", 0), intent.getDoubleExtra("ab_b_lon", 0));
            orientationBearing = intent.getDoubleExtra("ab_bearing", 0);
            orientationDistance = intent.getDoubleExtra("ab_distance", haversine(orientationPointA, orientationPointB));
        }
    }

    private void redrawOrientation() {
        if (map == null) return;
        if (orientationLine != null) {
            try { map.removePolyline(orientationLine); } catch (Exception ignored) { }
        }
        for (Marker marker : orientationMarkers) {
            try { map.removeMarker(marker); } catch (Exception ignored) { }
        }
        orientationMarkers.clear();
        orientationLine = null;
        if (orientationPointA == null || orientationPointB == null) return;
        List<LatLng> points = new ArrayList<>();
        points.add(orientationPointA);
        points.add(orientationPointB);
        orientationLine = map.addPolyline(new PolylineOptions()
                .addAll(points)
                .color(Color.rgb(255, 149, 0))
                .width(6f));
        orientationMarkers.add(map.addMarker(new MarkerOptions()
                .position(orientationPointA)
                .icon(IconFactory.getInstance(this).fromBitmap(createMeasurementPointBitmap("A", false)))));
        orientationMarkers.add(map.addMarker(new MarkerOptions()
                .position(orientationPointB)
                .icon(IconFactory.getInstance(this).fromBitmap(createMeasurementPointBitmap("B", false)))));
        setStatus(String.format(Locale.US, "Línea A–B: %.2f m · azimut %.2f°", orientationDistance, orientationBearing));
    }

    private void centerOnOrientation() {
        if (map == null || orientationPointA == null || orientationPointB == null) return;
        LatLng centerPoint = midpoint(orientationPointA, orientationPointB);
        double distance = Math.max(1.0, haversine(orientationPointA, orientationPointB));
        double targetZoom;
        if (distance < 50) targetZoom = 19.0;
        else if (distance < 200) targetZoom = 18.0;
        else if (distance < 600) targetZoom = 17.0;
        else if (distance < 2000) targetZoom = 15.5;
        else if (distance < 10000) targetZoom = 13.0;
        else targetZoom = 10.0;
        CameraPosition position = new CameraPosition.Builder()
                .target(centerPoint)
                .zoom(targetZoom)
                .bearing(0)
                .tilt(0)
                .build();
        map.animateCamera(CameraUpdateFactory.newCameraPosition(position), 600);
    }

    private void migrateLegacyMapData() {
        SharedPreferences primary = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
        SharedPreferences legacy = getSharedPreferences(LEGACY_MAP_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = primary.edit();
        boolean changed = false;
        if (!primary.contains(KEY_POINTS) && legacy.contains(KEY_POINTS)) {
            editor.putString(KEY_POINTS, legacy.getString(KEY_POINTS, "[]"));
            changed = true;
        }
        if (!primary.contains("last_latitude") && legacy.contains("last_latitude")) {
            editor.putString("last_latitude", legacy.getString("last_latitude", ""));
            editor.putString("last_longitude", legacy.getString("last_longitude", ""));
            editor.putFloat("last_accuracy", legacy.getFloat("last_accuracy", 0f));
            editor.putLong("last_location_time", legacy.getLong("last_location_time", System.currentTimeMillis()));
            changed = true;
        }
        if (changed) editor.apply();
    }

    private void loadRememberedLocation() {
        SharedPreferences sp = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
        try {
            String lat = sp.getString("last_latitude", "");
            String lon = sp.getString("last_longitude", "");
            if (lat.isEmpty() || lon.isEmpty()) return;
            Location remembered = new Location("guardada");
            remembered.setLatitude(Double.parseDouble(lat));
            remembered.setLongitude(Double.parseDouble(lon));
            remembered.setAccuracy(sp.getFloat("last_accuracy", 0f));
            remembered.setTime(sp.getLong("last_location_time", System.currentTimeMillis()));
            currentLocation = remembered;
        } catch (Exception ignored) { }
    }

    private void saveRememberedLocation(Location location) {
        getSharedPreferences(GPS_PREFS, MODE_PRIVATE).edit()
                .putString("last_latitude", Double.toString(location.getLatitude()))
                .putString("last_longitude", Double.toString(location.getLongitude()))
                .putFloat("last_accuracy", location.getAccuracy())
                .putLong("last_location_time", location.getTime() > 0 ? location.getTime() : System.currentTimeMillis())
                .apply();
    }

    private Location chooseBetter(Location a, Location b) {
        if (a == null) return b;
        if (b == null) return a;
        if (a.hasAccuracy() && b.hasAccuracy() && a.getAccuracy() != b.getAccuracy()) return a.getAccuracy() < b.getAccuracy() ? a : b;
        return a.getTime() >= b.getTime() ? a : b;
    }

    private boolean isBetterLocation(Location candidate, Location current) {
        if (current == null) return true;
        long dt = candidate.getTime() - current.getTime();
        if (dt > 30000L) return true;
        if (dt < -120000L) return false;
        float ca = candidate.hasAccuracy() ? candidate.getAccuracy() : 9999f;
        float oa = current.hasAccuracy() ? current.getAccuracy() : 9999f;
        return ca <= oa + 5f || dt > 5000L;
    }

    private void showPlaceSearchDialog() {
        EditText input = new EditText(this);
        input.setHint("Ciudad, distrito, calle o coordenadas");
        input.setSingleLine(true);
        input.setPadding(dp(16), dp(8), dp(16), dp(8));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Buscar lugar")
                .setMessage("Escribe una ciudad, distrito, comunidad, calle o dos coordenadas.")
                .setView(input)
                .setPositiveButton("Buscar", null)
                .setNegativeButton("Cancelar", null)
                .create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(b -> {
            String query = input.getText().toString().trim();
            if (query.isEmpty()) {
                input.setError("Escribe un lugar o coordenadas");
                return;
            }
            dialog.dismiss();
            searchPlace(query);
        }));
        dialog.show();
        input.requestFocus();
    }

    private void searchPlace(String query) {
        LatLng coordinates = parseCoordinates(query);
        if (coordinates != null) {
            centerSearchResult(coordinates, "Coordenadas buscadas");
            return;
        }
        setStatus("Buscando “" + query + "”…");
        lookupExecutor.execute(() -> {
            List<SearchResult> results = searchWithNominatim(query);
            String lower = query.toLowerCase(Locale.ROOT);
            if (results.isEmpty() && !lower.contains("perú") && !lower.contains("peru")) {
                results = searchWithNominatim(query + ", Perú");
            }
            final List<SearchResult> finalResults = results;
            runOnUiThread(() -> showSearchResults(query, finalResults));
        });
    }

    private LatLng parseCoordinates(String value) {
        try {
            String normalized = value.trim().replace(';', ',');
            String[] parts = normalized.contains(",") ? normalized.split(",") : normalized.split("\\s+");
            if (parts.length != 2) return null;
            double lat = Double.parseDouble(parts[0].trim());
            double lon = Double.parseDouble(parts[1].trim());
            if (lat < -90 || lat > 90 || lon < -180 || lon > 180) return null;
            return new LatLng(lat, lon);
        } catch (Exception ignored) {
            return null;
        }
    }

    private List<SearchResult> searchWithNominatim(String query) {
        List<SearchResult> results = new ArrayList<>();
        HttpURLConnection connection = null;
        try {
            String endpoint = "https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&limit=8&accept-language=es&q="
                    + URLEncoder.encode(query, "UTF-8");
            connection = (HttpURLConnection) new URL(endpoint).openConnection();
            connection.setConnectTimeout(8000);
            connection.setReadTimeout(12000);
            connection.setRequestProperty("User-Agent", "GeoTopo/1.19 Android (com.bph.geotopo)");
            connection.setRequestProperty("Accept-Language", "es-PE,es;q=0.9");
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) return results;
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder json = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) json.append(line);
            JSONArray array = new JSONArray(json.toString());
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                double lat = item.optDouble("lat", Double.NaN);
                double lon = item.optDouble("lon", Double.NaN);
                String name = item.optString("display_name", "").trim();
                if (Double.isNaN(lat) || Double.isNaN(lon) || name.isEmpty()) continue;
                results.add(new SearchResult(name, new LatLng(lat, lon)));
            }
        } catch (Exception ignored) {
            // Se informa al usuario en showSearchResults.
        } finally {
            if (connection != null) connection.disconnect();
        }
        return results;
    }

    private void showSearchResults(String query, List<SearchResult> results) {
        if (results == null || results.isEmpty()) {
            setStatus("No se encontraron resultados para “" + query + "”.");
            Toast.makeText(this, "No se encontró el lugar. Revisa internet o escribe provincia y región.", Toast.LENGTH_LONG).show();
            return;
        }
        String[] labels = new String[results.size()];
        for (int i = 0; i < results.size(); i++) labels[i] = results.get(i).name;
        new AlertDialog.Builder(this)
                .setTitle("Resultados de búsqueda")
                .setItems(labels, (dialog, which) -> {
                    SearchResult result = results.get(which);
                    centerSearchResult(result.point, result.name);
                })
                .setNegativeButton("Cancelar", null)
                .show();
        setStatus(results.size() + " resultados encontrados.");
    }

    private void centerSearchResult(LatLng point, String name) {
        if (map == null) return;
        CameraPosition position = new CameraPosition.Builder(map.getCameraPosition())
                .target(point)
                .zoom(Math.max(15.5, map.getCameraPosition().zoom))
                .build();
        map.animateCamera(CameraUpdateFactory.newCameraPosition(position), 650);
        showSelectedPoint(point, name);
        setStatus(shortPlace(name) + " · resultado de búsqueda");
    }

    private void showInfo() {
        new AlertDialog.Builder(this)
                .setTitle("Mapa nativo GeoTopo")
                .setMessage("El mapa ahora usa MapLibre y la GPU del teléfono para mover y ampliar con mayor fluidez.\n\n"
                        + "Mantén pulsado un lugar para ver su nombre, dirección, coordenadas y UTM.\n\n"
                        + "Usa la lupa para buscar lugares o coordenadas. Las mediciones sobre imagen son referenciales.")
                .setPositiveButton("Entendido", null)
                .show();
    }

    private void setStatus(String text) {
        if (statusView != null) statusView.setText(text);
    }

    private void appendPart(StringBuilder out, String value) {
        if (value == null || value.trim().isEmpty()) return;
        if (out.length() > 0) out.append(", ");
        out.append(value.trim());
    }

    private double totalDistance(List<LatLng> points) {
        double total = 0;
        for (int i = 1; i < points.size(); i++) total += haversine(points.get(i - 1), points.get(i));
        return total;
    }

    private double haversine(LatLng a, LatLng b) {
        final double r = 6371008.8;
        double p1 = Math.toRadians(a.getLatitude());
        double p2 = Math.toRadians(b.getLatitude());
        double dp = Math.toRadians(b.getLatitude() - a.getLatitude());
        double dl = Math.toRadians(b.getLongitude() - a.getLongitude());
        double q = Math.sin(dp / 2) * Math.sin(dp / 2)
                + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
        return 2 * r * Math.atan2(Math.sqrt(q), Math.sqrt(1 - q));
    }

    private double polygonArea(List<LatLng> points) {
        if (points.size() < 3) return 0;
        double meanLat = 0;
        for (LatLng p : points) meanLat += p.getLatitude();
        meanLat = Math.toRadians(meanLat / points.size());
        double scaleX = 111320.0 * Math.cos(meanLat);
        double scaleY = 110540.0;
        double area = 0;
        for (int i = 0; i < points.size(); i++) {
            LatLng a = points.get(i);
            LatLng b = points.get((i + 1) % points.size());
            area += (a.getLongitude() * scaleX) * (b.getLatitude() * scaleY)
                    - (b.getLongitude() * scaleX) * (a.getLatitude() * scaleY);
        }
        return Math.abs(area) / 2.0;
    }

    private List<LatLng> circlePoints(LatLng center, double radiusMeters, int count) {
        List<LatLng> points = new ArrayList<>();
        double lat = Math.toRadians(center.getLatitude());
        double lon = Math.toRadians(center.getLongitude());
        double angular = radiusMeters / 6371008.8;
        for (int i = 0; i <= count; i++) {
            double bearing = 2.0 * Math.PI * i / count;
            double lat2 = Math.asin(Math.sin(lat) * Math.cos(angular)
                    + Math.cos(lat) * Math.sin(angular) * Math.cos(bearing));
            double lon2 = lon + Math.atan2(Math.sin(bearing) * Math.sin(angular) * Math.cos(lat),
                    Math.cos(angular) - Math.sin(lat) * Math.sin(lat2));
            points.add(new LatLng(Math.toDegrees(lat2), Math.toDegrees(lon2)));
        }
        return points;
    }

    private String nextMapPointName() {
        try {
            JSONArray array = new JSONArray(getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]"));
            int n = 1;
            while (true) {
                String candidate = "M" + n;
                boolean used = false;
                for (int i = 0; i < array.length(); i++) {
                    JSONObject item = array.optJSONObject(i);
                    if (item != null && candidate.equalsIgnoreCase(item.optString("name"))) { used = true; break; }
                }
                if (!used) return candidate;
                n++;
            }
        } catch (Exception ignored) {
            return "M1";
        }
    }

    private static UtmCoordinate toUtm(double latitude, double longitude) {
        if (latitude < -80.0 || latitude > 84.0 || longitude < -180.0 || longitude > 180.0) return UtmCoordinate.invalid();
        final double a = 6378137.0;
        final double eccSquared = 0.00669438;
        final double k0 = 0.9996;
        int zoneNumber = (int) Math.floor((longitude + 180.0) / 6.0) + 1;
        if (longitude == 180.0) zoneNumber = 60;
        if (latitude >= 56.0 && latitude < 64.0 && longitude >= 3.0 && longitude < 12.0) zoneNumber = 32;
        if (latitude >= 72.0 && latitude < 84.0) {
            if (longitude < 9.0) zoneNumber = 31;
            else if (longitude < 21.0) zoneNumber = 33;
            else if (longitude < 33.0) zoneNumber = 35;
            else if (longitude < 42.0) zoneNumber = 37;
        }
        double lonOrigin = (zoneNumber - 1) * 6.0 - 180.0 + 3.0;
        double latRad = Math.toRadians(latitude);
        double lonRad = Math.toRadians(longitude);
        double lonOriginRad = Math.toRadians(lonOrigin);
        double eccPrimeSquared = eccSquared / (1.0 - eccSquared);
        double sinLat = Math.sin(latRad);
        double cosLat = Math.cos(latRad);
        double tanLat = Math.tan(latRad);
        double n = a / Math.sqrt(1.0 - eccSquared * sinLat * sinLat);
        double t = tanLat * tanLat;
        double c = eccPrimeSquared * cosLat * cosLat;
        double aa = cosLat * (lonRad - lonOriginRad);
        double m = a * ((1.0 - eccSquared / 4.0 - 3.0 * eccSquared * eccSquared / 64.0 - 5.0 * Math.pow(eccSquared, 3) / 256.0) * latRad
                - (3.0 * eccSquared / 8.0 + 3.0 * eccSquared * eccSquared / 32.0 + 45.0 * Math.pow(eccSquared, 3) / 1024.0) * Math.sin(2.0 * latRad)
                + (15.0 * eccSquared * eccSquared / 256.0 + 45.0 * Math.pow(eccSquared, 3) / 1024.0) * Math.sin(4.0 * latRad)
                - (35.0 * Math.pow(eccSquared, 3) / 3072.0) * Math.sin(6.0 * latRad));
        double easting = k0 * n * (aa + (1.0 - t + c) * Math.pow(aa, 3) / 6.0
                + (5.0 - 18.0 * t + t * t + 72.0 * c - 58.0 * eccPrimeSquared) * Math.pow(aa, 5) / 120.0) + 500000.0;
        double northing = k0 * (m + n * tanLat * (aa * aa / 2.0
                + (5.0 - t + 9.0 * c + 4.0 * c * c) * Math.pow(aa, 4) / 24.0
                + (61.0 - 58.0 * t + t * t + 600.0 * c - 330.0 * eccPrimeSquared) * Math.pow(aa, 6) / 720.0));
        String hemisphere = latitude < 0.0 ? "S" : "N";
        if (latitude < 0.0) northing += 10000000.0;
        return new UtmCoordinate(true, zoneNumber, hemisphere, easting, northing);
    }

    private LinearLayout floatingPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(11), dp(14), dp(11));
        panel.setBackground(pill(Color.argb(247, 4, 36, 58), dp(20), Color.argb(90, 255, 255, 255)));
        panel.setElevation(dp(14));
        return panel;
    }

    private Button panelButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setBackground(pill(accentColor, dp(12), Color.argb(80, 255, 255, 255)));
        return b;
    }

    private LinearLayout.LayoutParams weightButton() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(50), 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    private View mapTool(int iconRes, String label, View.OnClickListener listener) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setContentDescription(label);
        item.setOnClickListener(listener);

        ImageButton icon = new ImageButton(this);
        icon.setImageResource(iconRes);
        icon.setScaleType(android.widget.ImageView.ScaleType.CENTER);
        icon.setPadding(dp(7), dp(7), dp(7), dp(7));
        icon.setColorFilter(Color.WHITE);
        icon.setContentDescription(label);
        icon.setOnClickListener(listener);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setShape(GradientDrawable.OVAL);
        iconBg.setColor(Color.argb(210, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)));
        iconBg.setStroke(dp(1), Color.argb(95, 255, 255, 255));
        icon.setBackground(iconBg);
        icon.setElevation(dp(4));
        item.addView(icon, new LinearLayout.LayoutParams(dp(34), dp(34)));

        TextView caption = text(label, 8.3f, false, Color.WHITE);
        caption.setGravity(Gravity.CENTER);
        caption.setMaxLines(1);
        item.addView(caption, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(15)));
        return item;
    }

    private LinearLayout.LayoutParams toolParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        return lp;
    }

    private TextView roundText(String value, String description) {
        TextView view = text(value, 24, true, Color.WHITE);
        view.setGravity(Gravity.CENTER);
        view.setContentDescription(description);
        view.setBackground(pill(accentColor, dp(24), Color.argb(110, 255, 255, 255)));
        return view;
    }

    private TextView text(String value, float size, boolean bold, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private GradientDrawable pill(int fill, int radius, int stroke) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(fill);
        gd.setCornerRadius(radius);
        gd.setStroke(dp(1), stroke);
        return gd;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            boolean granted = false;
            for (int value : grantResults) if (value == PackageManager.PERMISSION_GRANTED) granted = true;
            if (granted) requestLocationUpdates();
            else setStatus("Permiso de ubicación denegado.");
        }
    }

    @Override protected void onStart() { super.onStart(); mapView.onStart(); }
    @Override protected void onResume() { super.onResume(); mapView.onResume(); }
    @Override protected void onPause() { try { if (locationManager != null) locationManager.removeUpdates(this); } catch (Exception ignored) { } mapView.onPause(); super.onPause(); }
    @Override protected void onStop() { mapView.onStop(); super.onStop(); }
    @Override public void onLowMemory() { super.onLowMemory(); mapView.onLowMemory(); }
    @Override protected void onDestroy() { lookupExecutor.shutdownNow(); handler.removeCallbacksAndMessages(null); mapView.onDestroy(); super.onDestroy(); }
    @Override protected void onSaveInstanceState(Bundle outState) { super.onSaveInstanceState(outState); mapView.onSaveInstanceState(outState); }

    private static final class SavedPointInfo {
        final String name;
        final String project;
        final String description;
        final LatLng point;

        SavedPointInfo(String name, String project, String description, LatLng point) {
            this.name = name;
            this.project = project;
            this.description = description;
            this.point = point;
        }
    }

    private static final class SearchResult {
        final String name;
        final LatLng point;

        SearchResult(String name, LatLng point) {
            this.name = name;
            this.point = point;
        }
    }

    private static final class UtmCoordinate {
        final boolean valid;
        final int zone;
        final String hemisphere;
        final double easting;
        final double northing;

        UtmCoordinate(boolean valid, int zone, String hemisphere, double easting, double northing) {
            this.valid = valid;
            this.zone = zone;
            this.hemisphere = hemisphere;
            this.easting = easting;
            this.northing = northing;
        }

        static UtmCoordinate invalid() {
            return new UtmCoordinate(false, 0, "", Double.NaN, Double.NaN);
        }
    }
}
