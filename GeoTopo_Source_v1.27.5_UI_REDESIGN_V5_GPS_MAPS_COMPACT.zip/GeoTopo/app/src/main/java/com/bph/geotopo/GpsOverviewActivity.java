package com.bph.geotopo;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.maplibre.android.MapLibre;
import org.maplibre.android.annotations.MarkerOptions;
import org.maplibre.android.camera.CameraPosition;
import org.maplibre.android.camera.CameraUpdateFactory;
import org.maplibre.android.geometry.LatLng;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapView;
import org.maplibre.android.maps.Style;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Pantalla principal GPS rediseñada. Todos los paneles son nativos y los
 * accesos abren funciones reales existentes (GPS, mapa, GNSS y puntos).
 */
public class GpsOverviewActivity extends Activity {
    private static final String GPS_PREFS = "geo_topo_gps_points";
    private static final String KEY_POINTS = "points_json";
    private MapView overviewMapView;
    private MapLibreMap overviewMap;
    private LastPosition overviewPosition;
    private Bundle mapSavedState;
    private boolean overviewMarkerAdded;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MapLibre.getInstance(this);
        mapSavedState = savedInstanceState;
        NativeUi.styleWindow(this);
        setContentView(buildScreen());
    }

    @Override protected void onRestart() {
        super.onRestart();
        if (overviewMapView != null) {
            try { overviewMapView.onDestroy(); } catch (Exception ignored) {}
        }
        overviewMapView = null;
        overviewMap = null;
        overviewMarkerAdded = false;
        mapSavedState = null;
        setContentView(buildScreen());
    }

    @Override protected void onStart() { super.onStart(); if (overviewMapView != null) overviewMapView.onStart(); }
    @Override protected void onResume() { super.onResume(); if (overviewMapView != null) overviewMapView.onResume(); }
    @Override protected void onPause() { if (overviewMapView != null) overviewMapView.onPause(); super.onPause(); }
    @Override protected void onStop() { if (overviewMapView != null) overviewMapView.onStop(); super.onStop(); }
    @Override public void onLowMemory() { super.onLowMemory(); if (overviewMapView != null) overviewMapView.onLowMemory(); }
    @Override protected void onDestroy() { if (overviewMapView != null) overviewMapView.onDestroy(); super.onDestroy(); }
    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (overviewMapView != null) overviewMapView.onSaveInstanceState(outState);
    }

    private View buildScreen() {
        FrameLayout root = NativeUi.screen(this);
        LinearLayout page = NativeUi.column(this);
        page.addView(NativeUi.pageHeader(this, "GPS y mapas",
                "Ubicación, puntos y mapas offline", v -> finish(), "⌖",
                v -> open(MapActivity.class)));

        LinearLayout content = NativeUi.column(this);
        content.setPadding(NativeUi.dp(this, 12), NativeUi.dp(this, 9),
                NativeUi.dp(this, 12), NativeUi.dp(this, 24));

        LastPosition p = readLastPosition();
        overviewPosition = p;

        View mapCard = buildFunctionalMapCard();
        LinearLayout.LayoutParams mapLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 232));
        mapLp.setMargins(0, 0, 0, NativeUi.dp(this, 9));
        content.addView(mapCard, mapLp);

        content.addView(buildStatusPanel(p));
        content.addView(buildPrimaryActions());
        content.addView(buildReadingPanel(p));
        content.addView(buildSecondaryActions());

        content.addView(NativeUi.sectionHeader(this, "◷", "PUNTOS RECIENTES", "Ver todos",
                v -> openGps("points")));
        content.addView(recentPointsCard());

        page.addView(NativeUi.scroll(this, content), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(page, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return root;
    }

    private View buildFunctionalMapCard() {
        FrameLayout card = new FrameLayout(this);
        card.setBackground(NativeUi.gradient(Color.rgb(5, 34, 69), Color.rgb(2, 18, 37), 18,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 160), this));
        card.setClipToOutline(true);
        card.setElevation(NativeUi.dp(this, 2));

        overviewMapView = new MapView(this);
        overviewMapView.onCreate(mapSavedState);
        card.addView(overviewMapView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        overviewMapView.getMapAsync(mapLibreMap -> {
            overviewMap = mapLibreMap;
            overviewMap.getUiSettings().setLogoEnabled(false);
            overviewMap.getUiSettings().setAttributionEnabled(false);
            overviewMap.getUiSettings().setCompassEnabled(false);
            overviewMap.setMinZoomPreference(2.0);
            overviewMap.setMaxZoomPreference(20.0);
            overviewMap.setStyle(new Style.Builder().fromJson(overviewRasterStyle()), style -> centerOverviewMap(false));
        });

        TextView offline = NativeUi.text(this, "⇩  Offline", 11.5f, true, NativeUi.TEXT);
        offline.setGravity(Gravity.CENTER);
        offline.setBackground(NativeUi.rounded(NativeUi.withAlpha(NativeUi.BG_DEEP, 225), 14, 1,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 145), this));
        offline.setOnClickListener(v -> open(OfflineMapActivity.class));
        FrameLayout.LayoutParams olp = new FrameLayout.LayoutParams(
                NativeUi.dp(this, 104), NativeUi.dp(this, 34), Gravity.START | Gravity.TOP);
        olp.setMargins(NativeUi.dp(this, 10), NativeUi.dp(this, 10), 0, 0);
        card.addView(offline, olp);

        LinearLayout controls = NativeUi.column(this);
        controls.setGravity(Gravity.CENTER);
        controls.addView(mapControl("▱", "Capas", v -> open(MapActivity.class)));
        controls.addView(mapControl("N", "Norte arriba", v -> resetOverviewBearing()));
        controls.addView(mapControl("⌖", "Centrar", v -> centerOverviewMap(true)));
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(
                NativeUi.dp(this, 42), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END | Gravity.CENTER_VERTICAL);
        clp.setMargins(0, 0, NativeUi.dp(this, 9), 0);
        card.addView(controls, clp);

        TextView open = NativeUi.text(this, "Abrir mapa completo  ›", 12.6f, true, Color.WHITE);
        open.setGravity(Gravity.CENTER);
        open.setBackground(NativeUi.gradient(Color.rgb(46, 133, 255), Color.rgb(23, 83, 211), 13,
                NativeUi.withAlpha(Color.WHITE, 55), this));
        open.setOnClickListener(v -> open(MapActivity.class));
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(
                NativeUi.dp(this, 164), NativeUi.dp(this, 38), Gravity.END | Gravity.BOTTOM);
        blp.setMargins(0, 0, NativeUi.dp(this, 10), NativeUi.dp(this, 10));
        card.addView(open, blp);
        return card;
    }

    private String overviewRasterStyle() {
        String tiles = "https://a.tile.opentopomap.org/{z}/{x}/{y}.png";
        return "{\"version\":8,\"sources\":{\"base\":{\"type\":\"raster\",\"tiles\":[\""
                + tiles + "\"],\"tileSize\":256,\"maxzoom\":17}},\"layers\":[{\"id\":\"base\",\"type\":\"raster\",\"source\":\"base\"}]}";
    }

    private void centerOverviewMap(boolean animate) {
        if (overviewMap == null) return;
        double lat = overviewPosition != null && overviewPosition.valid ? overviewPosition.latitude : -12.0464;
        double lon = overviewPosition != null && overviewPosition.valid ? overviewPosition.longitude : -77.0428;
        double zoom = overviewPosition != null && overviewPosition.valid ? 16.0 : 10.0;
        CameraPosition camera = new CameraPosition.Builder().target(new LatLng(lat, lon)).zoom(zoom).bearing(0).tilt(0).build();
        if (animate) overviewMap.animateCamera(CameraUpdateFactory.newCameraPosition(camera), 420);
        else overviewMap.moveCamera(CameraUpdateFactory.newCameraPosition(camera));
        if (overviewPosition != null && overviewPosition.valid && !overviewMarkerAdded) {
            overviewMap.addMarker(new MarkerOptions().position(new LatLng(lat, lon)).title("Posición actual"));
            overviewMarkerAdded = true;
        }
    }

    private void zoomOverview(double delta) {
        if (overviewMap == null) return;
        CameraPosition current = overviewMap.getCameraPosition();
        double next = Math.max(2.0, Math.min(20.0, current.zoom + delta));
        overviewMap.animateCamera(CameraUpdateFactory.zoomTo(next), 220);
    }

    private void resetOverviewBearing() {
        if (overviewMap == null) return;
        CameraPosition current = overviewMap.getCameraPosition();
        CameraPosition next = new CameraPosition.Builder(current).bearing(0).tilt(0).build();
        overviewMap.animateCamera(CameraUpdateFactory.newCameraPosition(next), 260);
    }

    private View mapControl(String glyph, String description, View.OnClickListener click) {
        TextView b = NativeUi.text(this, glyph, 16.5f, true, Color.WHITE);
        b.setGravity(Gravity.CENTER);
        b.setContentDescription(description);
        b.setBackground(NativeUi.rounded(NativeUi.withAlpha(NativeUi.BG_DEEP, 235), 18, 1,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 130), this));
        b.setOnClickListener(click);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                NativeUi.dp(this, 38), NativeUi.dp(this, 38));
        lp.setMargins(0, NativeUi.dp(this, 2), 0, NativeUi.dp(this, 2));
        b.setLayoutParams(lp);
        return b;
    }

    private View buildStatusPanel(LastPosition p) {
        LinearLayout panel = NativeUi.row(this);
        panel.setPadding(NativeUi.dp(this, 5), NativeUi.dp(this, 5),
                NativeUi.dp(this, 5), NativeUi.dp(this, 5));
        panel.setBackground(NativeUi.gradient(NativeUi.CARD_LIGHT, NativeUi.CARD_DARK, 15,
                NativeUi.withAlpha(NativeUi.BORDER, 130), this));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 72));
        plp.setMargins(0, 0, 0, NativeUi.dp(this, 9));
        panel.setLayoutParams(plp);

        panel.addView(metric("Calidad", qualityLabel(p), qualityColor(p)), metricLp());
        panel.addView(metric("Precisión", p.valid ? "±" + format1(p.accuracy) + " m" : "—", NativeUi.BLUE_LIGHT), metricLp());
        panel.addView(metric("Satélites", p.valid ? p.satellitesUsed + " / " + p.satellitesVisible : "0 / 0", Color.rgb(170, 122, 255)), metricLp());
        panel.addView(metric("Hora", p.valid ? formatTime(p.timestamp) : "—", Color.rgb(255, 198, 82)), metricLp());
        return panel;
    }

    private LinearLayout.LayoutParams metricLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lp.setMargins(NativeUi.dp(this, 2), NativeUi.dp(this, 2), NativeUi.dp(this, 2), NativeUi.dp(this, 2));
        return lp;
    }

    private View metric(String title, String value, int color) {
        LinearLayout box = NativeUi.column(this);
        box.setGravity(Gravity.CENTER);
        box.setPadding(NativeUi.dp(this, 5), NativeUi.dp(this, 6), NativeUi.dp(this, 5), NativeUi.dp(this, 6));
        box.setBackground(NativeUi.rounded(NativeUi.withAlpha(NativeUi.BG_DEEP, 120), 12, 1,
                NativeUi.withAlpha(NativeUi.BORDER, 85), this));
        TextView t = NativeUi.text(this, title, 10.2f, false, NativeUi.SUB);
        t.setGravity(Gravity.CENTER);
        TextView v = NativeUi.text(this, value, 12.2f, true, color);
        v.setGravity(Gravity.CENTER);
        v.setMaxLines(2);
        box.addView(t);
        box.addView(v);
        return box;
    }

    private View buildPrimaryActions() {
        LinearLayout row = NativeUi.row(this);
        row.addView(actionCard("play", "Iniciar\nGPS", v -> openGps("start")), actionLp(false, true));
        row.addView(actionCard("clock", "Promediar\n20 s", v -> openGps("average")), actionLp(true, true));
        row.addView(actionCard("pin", "Guardar\npunto", v -> openGps("save")), actionLp(true, false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 88));
        lp.setMargins(0, 0, 0, NativeUi.dp(this, 9));
        row.setLayoutParams(lp);
        return row;
    }

    private View buildReadingPanel(LastPosition p) {
        LinearLayout panel = NativeUi.column(this);
        panel.setPadding(NativeUi.dp(this, 14), NativeUi.dp(this, 13), NativeUi.dp(this, 14), NativeUi.dp(this, 13));
        panel.setBackground(NativeUi.gradient(NativeUi.CARD_LIGHT, NativeUi.CARD_DARK, 18,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 135), this));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        plp.setMargins(0, 0, 0, NativeUi.dp(this, 12));
        panel.setLayoutParams(plp);

        LinearLayout head = NativeUi.row(this);
        TextView title = NativeUi.text(this, "⌁  LECTURA ACTUAL", 15.5f, true, NativeUi.TEXT);
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView update = NativeUi.text(this, p.valid ? "●  " + relativeTime(p.timestamp) : "Sin lectura", 11.5f, true,
                p.valid ? Color.rgb(53, 220, 145) : NativeUi.SUB);
        head.addView(update);
        panel.addView(head);

        CoordinateUtils.Utm utm = p.valid ? CoordinateUtils.toUtm(p.latitude, p.longitude) : null;
        LinearLayout row1 = NativeUi.row(this);
        row1.addView(readingCell("Latitud", p.valid ? format6(p.latitude) + "°" : "Sin lectura"), readLp(true));
        row1.addView(readingCell("Longitud", p.valid ? format6(p.longitude) + "°" : "Sin lectura"), readLp(false));
        panel.addView(row1);

        LinearLayout row2 = NativeUi.row(this);
        row2.addView(readingCell("Este UTM", utm != null && utm.valid ? format3(utm.easting) + " m" : "Sin lectura"), readLp(true));
        row2.addView(readingCell("Norte UTM", utm != null && utm.valid ? format3(utm.northing) + " m" : "Sin lectura"), readLp(false));
        panel.addView(row2);

        LinearLayout row3 = NativeUi.row(this);
        row3.addView(readingCell("Altitud GNSS", !Float.isNaN(p.altitudeM) ? format1(p.altitudeM) + " m" : "No disponible"), readLp(true));
        row3.addView(readingCell("Precisión", p.valid ? "±" + format1(p.accuracy) + " m" : "Sin lectura"), readLp(false));
        panel.addView(row3);

        LinearLayout row4 = NativeUi.row(this);
        row4.addView(readingCell("Zona UTM", utm != null && utm.valid ? utm.zone + utm.hemisphere() : "Sin lectura"), readLp(true));
        row4.addView(readingCell("Datum", "WGS84 / UTM"), readLp(false));
        panel.addView(row4);
        return panel;
    }

    private LinearLayout.LayoutParams readLp(boolean left) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, NativeUi.dp(this, 58), 1f);
        lp.setMargins(left ? 0 : NativeUi.dp(this, 4), NativeUi.dp(this, 4), left ? NativeUi.dp(this, 4) : 0, 0);
        return lp;
    }

    private View readingCell(String title, String value) {
        LinearLayout box = NativeUi.column(this);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(NativeUi.dp(this, 9), NativeUi.dp(this, 6), NativeUi.dp(this, 7), NativeUi.dp(this, 6));
        box.setBackground(NativeUi.rounded(NativeUi.withAlpha(NativeUi.BG_DEEP, 125), 10, 1,
                NativeUi.withAlpha(NativeUi.BORDER, 85), this));
        TextView t = NativeUi.text(this, title, 9.5f, false, NativeUi.SUB);
        TextView v = NativeUi.text(this, value, 12.1f, true, NativeUi.TEXT);
        v.setPadding(0, NativeUi.dp(this, 2), 0, 0);
        v.setSingleLine(true);
        box.addView(t);
        box.addView(v);
        return box;
    }

    private View buildSecondaryActions() {
        LinearLayout row = NativeUi.row(this);
        row.setBaselineAligned(false);
        row.addView(actionCard("bookmark", "Puntos", v -> openGps("points")), actionLp(false, true));
        row.addView(actionCard("satellite", "Datos GNSS", v -> open(GnssQualityActivity.class)), actionLp(true, true));
        row.addView(actionCard("file", "Exportar", v -> open(DataExchangeActivity.class)), actionLp(true, false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 76));
        lp.setMargins(0, 0, 0, NativeUi.dp(this, 7));
        row.setLayoutParams(lp);
        return row;
    }

    private LinearLayout.LayoutParams actionLp(boolean leftMargin, boolean rightMargin) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lp.setMargins(leftMargin ? NativeUi.dp(this, 4) : 0, 0,
                rightMargin ? NativeUi.dp(this, 4) : 0, 0);
        return lp;
    }

    private View actionCard(String icon, String label, View.OnClickListener click) {
        LinearLayout box = NativeUi.column(this);
        box.setPadding(NativeUi.dp(this, 6), NativeUi.dp(this, 7), NativeUi.dp(this, 6), NativeUi.dp(this, 6));
        box.setGravity(Gravity.CENTER);
        box.setBackground(NativeUi.gradient(NativeUi.CARD_LIGHT, NativeUi.CARD_DARK, 13,
                NativeUi.withAlpha(NativeUi.BLUE_LIGHT, 110), this));
        box.setOnClickListener(click);
        FrameLayout iconBox = NativeUi.iconTile(this, icon, 31);
        box.addView(iconBox, new LinearLayout.LayoutParams(NativeUi.dp(this, 31), NativeUi.dp(this, 31)));
        TextView title = NativeUi.text(this, label, 10.6f, true, NativeUi.TEXT);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, NativeUi.dp(this, 4), 0, 0);
        title.setMaxLines(2);
        box.addView(title);
        return box;
    }

    private View recentPointsCard() {
        LinearLayout card = NativeUi.column(this);
        card.setBackground(NativeUi.gradient(NativeUi.CARD_LIGHT, NativeUi.CARD_DARK, 18,
                NativeUi.withAlpha(NativeUi.BORDER, 165), this));
        List<PointRow> points = readRecentPoints();
        if (points.isEmpty()) {
            TextView empty = NativeUi.text(this,
                    "Todavía no hay puntos guardados. Usa Guardar punto para registrar el primero.",
                    13.2f, false, NativeUi.SUB);
            empty.setPadding(NativeUi.dp(this, 16), NativeUi.dp(this, 18),
                    NativeUi.dp(this, 16), NativeUi.dp(this, 18));
            card.addView(empty);
            return card;
        }
        for (int i = 0; i < points.size(); i++) {
            PointRow point = points.get(i);
            card.addView(recentRow(point));
            if (i < points.size() - 1) {
                View divider = new View(this);
                divider.setBackgroundColor(NativeUi.withAlpha(NativeUi.BORDER, 80));
                card.addView(divider, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, NativeUi.dp(this, 1)));
            }
        }
        return card;
    }

    private View recentRow(PointRow point) {
        LinearLayout row = NativeUi.row(this);
        row.setPadding(NativeUi.dp(this, 12), NativeUi.dp(this, 13),
                NativeUi.dp(this, 10), NativeUi.dp(this, 13));
        row.setOnClickListener(v -> openGps("points"));
        NativeUi.IconGlyphView icon = new NativeUi.IconGlyphView(this, "pin");
        row.addView(icon, new LinearLayout.LayoutParams(NativeUi.dp(this, 38), NativeUi.dp(this, 38)));
        LinearLayout labels = NativeUi.column(this);
        labels.setPadding(NativeUi.dp(this, 9), 0, NativeUi.dp(this, 5), 0);
        labels.addView(NativeUi.text(this, point.name, 14.5f, true, NativeUi.TEXT));
        TextView sub = NativeUi.text(this, point.summary, 11.2f, false, NativeUi.SUB);
        sub.setSingleLine(true);
        labels.addView(sub);
        row.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView time = NativeUi.text(this, point.time + "  ›", 11.5f, false, NativeUi.SUB);
        row.addView(time);
        return row;
    }

    private LastPosition readLastPosition() {
        SharedPreferences prefs = getSharedPreferences(GPS_PREFS, MODE_PRIVATE);
        try {
            String lat = prefs.getString("last_latitude", "");
            String lon = prefs.getString("last_longitude", "");
            LastPosition p = new LastPosition();
            p.satellitesVisible = prefs.getInt("last_satellites_visible", 0);
            p.satellitesUsed = prefs.getInt("last_satellites_used", 0);
            p.speedMps = prefs.getFloat("last_speed_mps", -1f);
            p.altitudeM = prefs.getFloat("last_altitude_m", Float.NaN);
            p.provider = prefs.getString("last_provider", "");
            if (lat == null || lon == null || lat.trim().isEmpty() || lon.trim().isEmpty()) return p;
            p.latitude = Double.parseDouble(lat);
            p.longitude = Double.parseDouble(lon);
            p.accuracy = prefs.getFloat("last_accuracy", 0f);
            p.timestamp = prefs.getLong("last_location_time", 0L);
            p.valid = true;
            return p;
        } catch (Exception ignored) {
            return new LastPosition();
        }
    }

    private List<PointRow> readRecentPoints() {
        List<PointRow> rows = new ArrayList<>();
        String json = getSharedPreferences(GPS_PREFS, MODE_PRIVATE).getString(KEY_POINTS, "[]");
        try {
            JSONArray array = new JSONArray(json == null ? "[]" : json);
            for (int i = array.length() - 1; i >= 0 && rows.size() < 3; i--) {
                JSONObject object = array.optJSONObject(i);
                if (object == null) continue;
                PointRow row = new PointRow();
                row.name = object.optString("name", "Punto");
                double lat = object.optDouble("latitude", Double.NaN);
                double lon = object.optDouble("longitude", Double.NaN);
                double alt = object.optDouble("altitude", Double.NaN);
                CoordinateUtils.Utm utm = CoordinateUtils.toUtm(lat, lon);
                if (utm.valid) {
                    row.summary = "UTM " + utm.zone + utm.hemisphere() + " · "
                            + format3(utm.easting) + " E · " + format3(utm.northing) + " N"
                            + (Double.isNaN(alt) ? "" : " · " + format1(alt) + " m");
                } else {
                    row.summary = format6(lat) + ", " + format6(lon);
                }
                row.time = relativeTime(object.optLong("timestamp", System.currentTimeMillis()));
                rows.add(row);
            }
        } catch (Exception ignored) {
        }
        return rows;
    }

    private void open(Class<?> target) { startActivity(new Intent(this, target)); }

    private void openGps(String action) {
        Intent intent = new Intent(this, GpsActivity.class);
        if (action != null) intent.putExtra("overview_action", action);
        startActivity(intent);
    }

    private void shareLastCoordinates() {
        LastPosition p = readLastPosition();
        if (!p.valid) {
            Toast.makeText(this, "Primero obtén una lectura GPS.", Toast.LENGTH_LONG).show();
            openGps("start");
            return;
        }
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT, "Coordenadas GeoTopo\nLatitud: "
                + format6(p.latitude) + "\nLongitud: " + format6(p.longitude));
        startActivity(Intent.createChooser(share, "Compartir coordenadas"));
    }

    private String qualityLabel(LastPosition p) {
        if (!p.valid) return "Sin lectura";
        if (p.accuracy <= 2.0) return "Excelente";
        if (p.accuracy <= 5.0) return "Buena";
        if (p.accuracy <= 10.0) return "Aceptable";
        if (p.accuracy <= 25.0) return "Media";
        return "Débil";
    }

    private int qualityColor(LastPosition p) {
        if (!p.valid) return NativeUi.SUB;
        if (p.accuracy <= 5.0) return Color.rgb(51, 220, 145);
        if (p.accuracy <= 15.0) return Color.rgb(255, 193, 74);
        return Color.rgb(255, 103, 116);
    }

    private String providerLabel(String provider) {
        if (provider == null || provider.trim().isEmpty()) return "Sin lectura";
        if ("gps".equalsIgnoreCase(provider)) return "GPS / GNSS";
        if ("network".equalsIgnoreCase(provider)) return "Red";
        if (provider.startsWith("promedio")) return "Promedio GNSS";
        return provider;
    }

    private String format3(double value) { return String.format(Locale.US, "%,.3f", value).replace(',', ' '); }
    private String format6(double value) { return String.format(Locale.US, "%.6f", value); }
    private String format1(double value) { return String.format(Locale.US, "%.1f", value); }
    private String formatTime(long timestamp) {
        if (timestamp <= 0) return "sin hora";
        return new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date(timestamp));
    }
    private String relativeTime(long timestamp) {
        if (timestamp <= 0) return "Sin lectura";
        long diff = Math.max(0, System.currentTimeMillis() - timestamp);
        String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(timestamp));
        if (diff < 60000L) return "Ahora";
        if (diff < 60L * 60000L) return "Hace " + Math.max(1, diff / 60000L) + " min";
        if (diff < 24L * 60L * 60L * 1000L) return "Hoy, " + time;
        if (diff < 48L * 60L * 60L * 1000L) return "Ayer, " + time;
        return new SimpleDateFormat("dd/MM, HH:mm", Locale.getDefault()).format(new Date(timestamp));
    }

    private static final class LastPosition {
        boolean valid;
        double latitude;
        double longitude;
        double accuracy;
        long timestamp;
        int satellitesVisible;
        int satellitesUsed;
        float speedMps = -1f;
        float altitudeM = Float.NaN;
        String provider = "";
    }

    private static final class PointRow {
        String name;
        String summary;
        String time;
    }
}
